import { createWorkspaceSeed } from './support/workspace-seed.js';
import {
  CHARTING_DATA,
  type ChartingSeed,
} from '../libs/charting/src/lib/core/data-access/charting-data';
export const seed = () => createWorkspaceSeed() as unknown as ChartingSeed;
export const dataProvider = { provide: CHARTING_DATA, useValue: { createSeed: seed } };
