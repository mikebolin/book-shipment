import '@angular/compiler';
import test from 'node:test';
import assert from 'node:assert/strict';
import { createEnvironmentInjector } from '@angular/core';
import { createWorkspaceSeed } from '../src/data/workspace-seed.js';
import {
  createInitialState,
  getResource,
} from '../libs/charting/src/lib/core/state/workspace-state';
import {
  exportWorkspaceDocument,
  hydrateWorkspaceDocument,
  validateWorkspaceDocument,
} from '../libs/charting/src/lib/core/state/workspace-document';
import { WorkspaceStore } from '../libs/charting/src/lib/core/state/workspace.store';
import { WorkspaceRepository } from '../libs/charting/src/lib/core/data-access/workspace-repository.service';
import { CHARTING_WORKSPACE_PERSISTENCE } from '../libs/charting/src/lib/core/data-access/workspace-persistence';
import {
  CHARTING_DATA,
  type ChartingSeed,
} from '../libs/charting/src/lib/core/data-access/charting-data';
import { seed } from './fixtures';

const activity = () => createWorkspaceSeed() as unknown as ChartingSeed;
const initial = () => createInitialState(activity());
test('workspace metadata JSON round-trips generic and activity configurations with immutable pins and no rows/UI', () => {
  for (const configuration of [seed(), activity()]) {
    const state = createInitialState(configuration);
    state.datasets.secret = [{ id: 'private-observation', amount: 123 }];
    state.ui.open = { dialog: true };
    const document = exportWorkspaceDocument(state);
    assert.deepEqual(Object.keys(document).sort(), [
      'format',
      'resources',
      'revisions',
      'schemaVersion',
      'sources',
    ]);
    const text = JSON.stringify(document);
    assert.ok(!text.includes('private-observation'));
    assert.ok(!text.includes('"datasets"'));
    assert.ok(!/"rows"\s*:/.test(text));
    const restored = hydrateWorkspaceDocument(JSON.parse(text));
    assert.deepEqual(restored.datasets, {});
    assert.deepEqual(restored.ui, {});
    assert.deepEqual(exportWorkspaceDocument(restored), document);
    for (const dashboard of restored.resources.dashboards)
      for (const placement of dashboard.body.items)
        if (placement.widgetId)
          assert.ok(
            getResource(restored, 'widgets', placement.widgetId, true, placement.widgetRevision),
          );
    restored.resources.models[0].name = 'Isolated copy';
    assert.notEqual(document.resources.models[0].name, 'Isolated copy');
  }
});

test('portable metadata preserves generated pivot sizing/sorts and allows empty model descriptions', () => {
  const document = exportWorkspaceDocument(initial());
  const model = document.resources.models[0].body;
  model.description = '';
  document.sources[0].description = '';
  const dimension = model.columns.find((column: any) => column.kind === 'text')!.id;
  const measure = model.columns.find((column: any) => column.kind === 'number')!.id;
  const generated = 'Failed%7Cwith%20errors|' + measure;
  const view = document.resources.widgets[0].body;
  view.gridState = {
    pivot: { pivotMode: true, pivotColIds: [dimension] },
    aggregation: { aggregationModel: [{ colId: measure, aggFunc: 'sum' }] },
    sort: { sortModel: [{ colId: generated, sort: 'desc' }] },
    columnSizing: { columnSizingModel: [{ colId: generated, width: 220 }] },
  };
  view.serverGrid = {
    cacheBlockSize: 75,
    maxBlocksInCache: 2,
    maxConcurrentRequests: 1,
    blockLoadDebounceMillis: 80,
  };
  view.viewLayout = { tablePosition: 'bottom', showRecordCounts: false };
  const restored = hydrateWorkspaceDocument(document);
  assert.deepEqual(restored.resources.widgets[0].body.gridState, view.gridState);
  assert.deepEqual(restored.resources.widgets[0].body.serverGrid, view.serverGrid);
  const broken = structuredClone(document);
  broken.resources.widgets[0].body.gridState.sort.sortModel[0].colId = 'Failed|missing';
  assert.throws(() => validateWorkspaceDocument(broken), /unknown column/);
});

test('metadata export removes snapshot previews, volatile grid selections and native chart render IDs', () => {
  const state = initial();
  const view = state.resources.widgets[0];
  view.body.preview = {
    schemaVersion: 1,
    type: 'chart',
    chartType: 'column',
    title: 'Portable schematic',
    rows: [{ secret: 'thumbnail-observation' }],
  };
  view.body.gridState.rowSelection = ['private-id'];
  view.body.gridState.scroll = { top: 200, left: 20 };
  const chart = view.body.chart;
  chart.presentation = { chartId: 'native-session-id', model: { chartId: 'native-session-id' } };
  const document = exportWorkspaceDocument(state);
  const saved = document.resources.widgets[0].body;
  assert.equal(saved.preview.rows, undefined);
  assert.equal(saved.gridState.rowSelection, undefined);
  assert.equal(saved.gridState.scroll, undefined);
  assert.equal(saved.chart.presentation.chartId, undefined);
  assert.equal(saved.chart.presentation.model.chartId, undefined);
  assert.ok(state.resources.widgets[0].body.preview.rows, 'Export must not mutate the live state.');
});

test('metadata validation rejects missing pins, unknown fields, invalid mappings and unsupported JSON atomically', () => {
  const original = exportWorkspaceDocument(initial());
  const mutations = [
    (value: any) => {
      value.schemaVersion = 2;
    },
    (value: any) => {
      value.datasets = {};
    },
    (value: any) => {
      value.resources.models[0].body.columns[0].kind = 'bigint';
    },
    (value: any) => {
      value.resources.models[0].body.sqlDataset.rowIdColumn = 'missing';
    },
    (value: any) => {
      value.resources.widgets[0].modelId = 'missing';
    },
    (value: any) => {
      value.resources.widgets[0].body.columnHighlights = { missing: '1' };
    },
    (value: any) => {
      value.resources.widgets[0].body.gridState.rowGroup = { groupColIds: ['missing'] };
    },
    (value: any) => {
      value.resources.widgets[0].body.serverGrid = { cacheBlockSize: null };
    },
    (value: any) => {
      value.resources.widgets[0].body.serverGrid = { cacheBlockSize: 501 };
    },
    (value: any) => {
      value.resources.widgets[0].body.serverGrid = { invented: 1 };
    },
    (value: any) => {
      value.resources.widgets[0].body.viewLayout = { showTitle: 'false' };
    },
    (value: any) => {
      value.resources.dashboards[0].body.items[0].widgetRevision = 999;
    },
    (value: any) => {
      value.revisions[value.resources.widgets[0].id][1].version = 2;
    },
    (value: any) => {
      value.resources.widgets[0].body.gridState.filter = {
        advancedFilterModel: { filterType: 'text', colId: 'missing', type: 'equals', filter: 'x' },
      };
    },
    (value: any) => {
      value.resources.widgets[0].body.preview = { rows: [{ secret: 'row' }] };
    },
    (value: any) => {
      value.sources[0].rowCount = Infinity;
    },
    (value: any) => {
      value.resources.widgets[0].body.onRender = () => {};
    },
  ];
  const root = createEnvironmentInjector(
    [WorkspaceStore, { provide: CHARTING_DATA, useValue: { createSeed: activity } }],
    null as any,
  );
  const store = root.get(WorkspaceStore);
  store.setUi('session', 'opened', true);
  store.setDataset('secret', [{ id: 'row' }]);
  const before = store.resources();
  for (const mutate of mutations) {
    const bad = structuredClone(original);
    mutate(bad);
    assert.throws(() => store.importDocument(bad));
    assert.equal(store.resources(), before);
    assert.equal(store.ui().session.opened, true);
    assert.equal(store.datasets().secret.length, 1);
  }
  const cycle: any = structuredClone(original);
  cycle.circular = cycle;
  assert.throws(() => validateWorkspaceDocument(cycle), /acyclic JSON/);
  const sparse = structuredClone(original);
  delete sparse.resources.widgets[0];
  assert.throws(() => validateWorkspaceDocument(sparse), /holes or accessors/);
  root.destroy();
});

test('explicit repository persistence saves isolated metadata, hydrates atomically and preserves user preferences', async () => {
  const document = exportWorkspaceDocument(initial());
  const saved: unknown[] = [];
  let loads = 0;
  const root = createEnvironmentInjector(
    [
      WorkspaceStore,
      WorkspaceRepository,
      { provide: CHARTING_DATA, useValue: { createSeed: () => createInitialState() } },
      {
        provide: CHARTING_WORKSPACE_PERSISTENCE,
        useValue: {
          load: async () => {
            loads++;
            return document;
          },
          save: async (value: unknown) => {
            saved.push(value);
          },
        },
      },
    ],
    null as any,
  );
  const repository = root.get(WorkspaceRepository);
  const store = root.get(WorkspaceStore);
  assert.equal(loads, 0, 'Providing storage must not cause implicit network work.');
  store.savePreferences({ themeId: 'rose-red', density: 'comfortable', reducedMotion: true }, 0);
  store.setUi('session', 'opened', true);
  await repository.loadDocument();
  assert.equal(loads, 1);
  assert.equal(store.resources.models().length, 1);
  assert.equal(store.currentPreferences().themeId, 'rose-red');
  assert.deepEqual(store.ui(), {});
  await repository.saveDocument();
  assert.deepEqual(saved[0], document);
  (saved[0] as any).resources.models[0].name = 'Adapter changed copy';
  assert.notEqual(store.resources.models()[0].name, 'Adapter changed copy');
  const ui = store.ui();
  store.clearUi('absent');
  assert.equal(store.ui(), ui);
  store.setUi('stable', 'value', 1);
  const unchanged = store.ui();
  store.setUi('stable', 'value', 1);
  assert.equal(store.ui(), unchanged);
  root.destroy();
});

test('workspace replacement prevents an older snapshot load from repopulating imported metadata', async () => {
  const resolvers: ((response: Response) => void)[] = [];
  const root = createEnvironmentInjector(
    [
      WorkspaceStore,
      WorkspaceRepository,
      {
        provide: CHARTING_DATA,
        useValue: {
          createSeed: activity,
          loadSnapshot: () =>
            new Promise<Response>((done) => {
              resolvers.push(done);
            }),
        },
      },
    ],
    null as any,
  );
  const repository = root.get(WorkspaceRepository);
  const model = root.get(WorkspaceStore).resources.models()[0];
  const old = repository.lease(model).result;
  const rejected = assert.rejects(old, /workspace changed/);
  repository.importDocument(exportWorkspaceDocument(initial()));
  const current = repository.lease(model).result;
  const response = (id: string) =>
    new Response(
      [
        { type: 'start', schemaVersion: model.body.schemaVersion, totalRows: 1 },
        { type: 'batch', rows: [{ id, startedDateTime: '2024-03-10 05:00:00' }] },
        { type: 'complete', totalRows: 1 },
      ]
        .map((event) => JSON.stringify(event))
        .join('\n') + '\n',
      {
        headers: { 'Content-Type': 'application/x-ndjson' },
      },
    );
  resolvers[0](response('old-row'));
  await rejected;
  assert.deepEqual(root.get(WorkspaceStore).datasets(), {});
  assert.equal(
    repository.lease(model).result,
    current,
    'The old finally handler must not evict the new shared load.',
  );
  resolvers[1](response('new-row'));
  assert.equal((await current).rows[0].id, 'new-row');
  assert.equal(root.get(WorkspaceStore).datasets()[model.body.sourceKey][0].id, 'new-row');
  root.destroy();
});
