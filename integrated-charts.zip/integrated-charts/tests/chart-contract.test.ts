import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {
  CHART_TYPES,
  COMBO_SERIES_TYPES,
  ENTERPRISE_ONLY_CHART_TYPES,
  type ChartPlan,
} from '../libs/charting/src/lib/core/domain/integrated-chart';
import {
  buildChartDataset,
  validateChartPlan,
} from '../libs/charting/src/lib/core/domain/chart-data';
import { buildGuideFilters, defaultGuidePlan } from '../libs/charting/src/lib/explorer/chart-guide';
import {
  CHART_DEMO_VARIANTS,
  normalizeChartDemoType,
} from '../libs/charting/src/lib/explorer/chart-demo-types';
import { fromModel, toModel } from '../libs/charting/src/lib/core/domain/grid-model';
import { canonical, evaluate } from '../libs/charting/src/lib/core/domain/engine';
import { compileStudioQuery } from '../libs/charting/src/lib/core/domain/studio-query';
import type { ColumnSpec } from '../libs/charting/src/lib/core/domain/schema';

const columns: ColumnSpec[] = [
  { id: 'eventId', kind: 'text', chartRole: 'identifier' },
  { id: 'category', kind: 'text', chartRole: 'dimension' },
  { id: 'time', kind: 'datetime', chartRole: 'temporal' },
  { id: 'amount', kind: 'number', chartRole: 'measure', unit: 'USD' },
  { id: 'cost', kind: 'number', chartRole: 'measure', unit: 'USD' },
  { id: 'size', kind: 'number', chartRole: 'measure', unit: 'USD' },
].map((column) => ({
  ...column,
  nullable: false,
  sql: column.id.toUpperCase(),
  label: column.id,
  aliases: [],
  description: column.id,
})) as ColumnSpec[];
const rows = [
  { eventId: 'e1', category: 'A', time: '2024-03-10 05:00:00', amount: 10, cost: 4, size: 2 },
  { eventId: 'e2', category: 'A', time: '2024-03-10 07:00:00', amount: 20, cost: 5, size: 3 },
  { eventId: 'e3', category: 'B', time: '2024-03-11 04:00:00', amount: 30, cost: 6, size: 4 },
];

test('chart catalog covers the installed integrated Community families and explicitly recognizes Enterprise-only families', () => {
  const source = fs.readFileSync(
    'node_modules/ag-grid-community/dist/types/src/interfaces/iChartOptions.d.ts',
    'utf8',
  );
  const union = /export type ChartType = ([^;]+);/.exec(source)?.[1];
  assert.ok(union, 'The installed AG Grid ChartType contract must remain inspectable.');
  const installed = [...union.matchAll(/'([^']+)'/g)].map((match) => match[1]).sort();
  assert.deepEqual([...CHART_TYPES, ...ENTERPRISE_ONLY_CHART_TYPES, 'doughnut'].sort(), installed);
  assert.deepEqual(
    [...new Set(CHART_TYPES.map(normalizeChartDemoType))].sort(),
    CHART_DEMO_VARIANTS.map((type) => type.id).sort(),
  );
});

test('every installed Community chart plan builds valid data including raw X/Y/size and combination series', () => {
  for (const type of CHART_TYPES) {
    const plan = { ...defaultGuidePlan(type, columns), title: `Example ${type}` };
    const result = buildChartDataset(plan, columns, rows);
    assert.equal(result.type, type);
    assert.equal(result.title, plan.title);
    assert.ok(result.rows.length > 0, `${type} must have an honest plotted dataset.`);
    const measures = result.columns.filter((column) => column.dataType === 'series');
    assert.equal(measures.length, plan.measureColumnIds.length);
    if (type === 'scatter' || type === 'bubble' || type === 'histogram') {
      assert.equal(
        result.rows.length,
        rows.length,
        'Raw charts must preserve eligible observations.',
      );
      assert.equal(result.rows[0][measures[0].id], 10);
      if (type !== 'histogram') assert.equal(result.rows[0][measures[1].id], 4);
      if (type === 'bubble') assert.equal(result.rows[0][measures[2].id], 2);
    } else {
      assert.equal(
        result.rows.reduce((sum, row) => sum + Number(row[measures[0].id]), 0),
        60,
        `${type} sums must reconcile to the source.`,
      );
    }
    if (type === 'customCombo')
      assert.deepEqual(
        result.seriesChartTypes?.map((series) => series.colId).sort(),
        measures.map((measure) => measure.id).sort(),
      );
  }
  assert.equal(
    validateChartPlan(
      { ...defaultGuidePlan('donut', columns), type: 'doughnut', title: 'Legacy donut' },
      columns,
    ).type,
    'donut',
  );
});

test('unsupported saved chart types fail clearly instead of being presented as a supported fallback', () => {
  const base = { ...defaultGuidePlan('groupedColumn', columns), title: 'Stored chart' };
  for (const type of ENTERPRISE_ONLY_CHART_TYPES)
    assert.throws(
      () => validateChartPlan({ ...base, type }, columns),
      /requires AG Charts Enterprise/,
    );
  assert.throws(
    () => validateChartPlan({ ...base, type: 'imaginaryChart' }, columns),
    /supported chart/,
  );
});

test('custom combinations accept only installed series/axes and keep shared-unit validation', () => {
  const base = { ...defaultGuidePlan('customCombo', columns), title: 'Combination' };
  for (const chartType of COMBO_SERIES_TYPES) {
    const plan = {
      ...base,
      seriesChartTypes: [
        { colId: 'amount', chartType, secondaryAxis: false },
        { colId: 'cost', chartType: 'line', secondaryAxis: true },
      ],
    } as ChartPlan;
    assert.doesNotThrow(() => validateChartPlan(plan, columns));
    const secondary = {
      ...plan,
      seriesChartTypes: [
        { ...plan.seriesChartTypes![0], secondaryAxis: true },
        plan.seriesChartTypes![1],
      ],
    };
    if (['line', 'area'].includes(chartType))
      assert.doesNotThrow(() => validateChartPlan(secondary, columns));
    else assert.throws(() => validateChartPlan(secondary, columns), /secondary axis/);
  }
  const mixedUnits = columns.map((column) =>
    column.id === 'cost' ? { ...column, unit: 'days' } : column,
  );
  assert.doesNotThrow(() =>
    validateChartPlan(
      {
        ...base,
        seriesChartTypes: [
          { colId: 'amount', chartType: 'groupedColumn', secondaryAxis: false },
          { colId: 'cost', chartType: 'line', secondaryAxis: true },
        ],
      },
      mixedUnits,
    ),
  );
  assert.throws(
    () =>
      validateChartPlan(
        {
          ...base,
          seriesChartTypes: [
            { colId: 'amount', chartType: 'groupedColumn', secondaryAxis: false },
            { colId: 'cost', chartType: 'line', secondaryAxis: false },
          ],
        },
        mixedUnits,
      ),
    /different or unspecified units/,
  );
  assert.throws(
    () =>
      validateChartPlan(
        {
          ...base,
          seriesChartTypes: [
            { colId: 'amount', chartType: 'scatter', secondaryAxis: false },
            { colId: 'cost', chartType: 'line', secondaryAxis: false },
          ],
        },
        columns,
      ),
    /supported chart/,
  );
});

test('chart-builder datetime conditions produce canonical UTC operands that work in advanced and grouped SQL', () => {
  for (const [value, expected] of [
    ['2024-03-10T05:00', '2024-03-10 05:00:00'],
    ['2024-03-10T05:00:00Z', '2024-03-10 05:00:00'],
    ['2024-03-10T01:00:00-04:00', '2024-03-10 05:00:00'],
    ['2024-03-09T23:00:00-06:00', '2024-03-10 05:00:00'],
  ]) {
    const [node] = buildGuideFilters(
      [{ columnId: 'time', operator: 'greaterThanOrEqual', value }],
      columns,
    );
    assert.deepEqual(node, {
      kind: 'rule',
      field: 'time',
      op: 'greaterThanOrEqual',
      value: expected,
    });
    assert.deepEqual(
      rows.filter((row) => evaluate(node, row)).map((row) => row.eventId),
      ['e1', 'e2', 'e3'],
    );
    const model = toModel(node, 'advanced', columns);
    assert.equal(canonical(fromModel(model, 'advanced', columns)), canonical(node));
    const query = compileStudioQuery(
      {
        mode: 'advanced',
        calculatedColumnIds: [],
        request: {
          startRow: 0,
          endRow: 250,
          filterModel: model,
          sortModel: [],
          rowGroupCols: [{ id: 'category' }],
          valueCols: [{ id: 'amount', aggFunc: 'sum' }],
          pivotCols: [],
          pivotMode: false,
          groupKeys: [],
        },
      },
      'tenant-a',
      { columns, table: ['EVENTS'], tenantColumn: 'TENANT_ID', rowIdColumn: 'eventId' },
    );
    assert.deepEqual(query.matching.binds, ['tenant-a', expected]);
    assert.match(query.rows.sql, /"TIME" >= TO_TIMESTAMP_NTZ\(\?, 'YYYY-MM-DD HH24:MI:SS'\)/);
  }
  for (const value of ['2024-02-30T05:00', '2024-03-10T24:00', '2024-03-10T05:00:00.001Z'])
    assert.throws(() =>
      buildGuideFilters([{ columnId: 'time', operator: 'equals', value }], columns),
    );
});
