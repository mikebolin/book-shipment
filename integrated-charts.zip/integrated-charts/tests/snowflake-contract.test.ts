import test from 'node:test';
import assert from 'node:assert/strict';
import {
  canonical,
  dayRange,
  evaluate,
  filterTimestamp,
  plainDate,
  utcTimestamp,
} from '../libs/charting/src/lib/core/domain/engine';
import { fromModel, toModel } from '../libs/charting/src/lib/core/domain/grid-model';
import {
  compileStudioPivotDiscovery,
  compileStudioQuery,
  type StudioQueryResult,
} from '../libs/charting/src/lib/core/domain/studio-query';
import { queryAnalyticsRows } from '../libs/charting/src/lib/core/domain/analytics-engine';
import {
  calculatedColumnSpec,
  type CalculatedColumnDefinition,
} from '../libs/charting/src/lib/core/domain/calculated-columns';
import { createStudioDatasource } from '../libs/charting/src/lib/explorer/studio-server-datasource';
import { validateStudioQueryResult } from '../libs/charting/src/lib/explorer/studio-query-result';
import type { AnalyticsRowsRequest } from '../libs/charting/src/lib/core/domain/analytics-query';
import type { GridModel, Mode } from '../libs/charting/src/lib/core/domain/contracts';
import type { SqlDataset } from '../libs/charting/src/lib/core/domain/sql-dataset';
import type { ColumnSpec } from '../libs/charting/src/lib/core/domain/schema';

const columns: ColumnSpec[] = [
  ['eventId', 'text', false],
  ['category', 'text', true],
  ['amount', 'number', true],
  ['day', 'date', true],
  ['time', 'datetime', true],
].map(([id, kind, nullable]) => ({
  id: id as string,
  kind: kind as ColumnSpec['kind'],
  nullable: nullable as boolean,
  sql: String(id).toUpperCase(),
  label: String(id),
  aliases: [],
  description: String(id),
}));
const dataset: SqlDataset = {
  columns,
  table: ['EVENTS'],
  rowIdColumn: 'eventId',
  tenantColumn: 'TENANT_ID',
};
const rows = [
  ['a', '2024-03-09 23:59:59', -1, 'Alpha'],
  ['b', '2024-03-10 00:00:00', 0, 'Alpha'],
  ['c', '2024-03-10 05:00:00', 10, 'Alpha'],
  ['d', '2024-03-10 07:00:00', 20, 'Beta'],
  ['e', '2024-03-11 03:59:59', 30, 'Beta'],
  ['f', '2024-03-11 04:00:00', 40, 'Beta'],
  ['g', '2024-11-03 04:00:00', 50, 'Alpha'],
  ['h', '2024-11-04 04:59:59', 60, 'Beta'],
  ['i', '2024-11-04 05:00:00', 70, 'Beta'],
  ['n', null, null, null],
].map(([eventId, time, amount, category]) => ({
  eventId: eventId as string,
  time: time as string | null,
  day: typeof time === 'string' ? time.slice(0, 10) : null,
  amount: amount as number | null,
  category: category as string | null,
}));
function input(
  mode: Mode,
  filterModel: GridModel = null,
  options: Partial<AnalyticsRowsRequest['request']> = {},
): AnalyticsRowsRequest {
  return {
    mode,
    calculatedColumnIds: [],
    request: {
      startRow: 0,
      endRow: 250,
      filterModel,
      sortModel: [],
      rowGroupCols: [],
      valueCols: [],
      pivotCols: [],
      pivotMode: false,
      groupKeys: [],
      ...options,
    },
  };
}
function execute(request: AnalyticsRowsRequest) {
  return queryAnalyticsRows(null, request, {
    columns,
    rows,
    rowIdColumn: 'eventId',
    rawGroupKeys: true,
    includeGroupCount: true,
  });
}
const ids = (request: AnalyticsRowsRequest) => execute(request).rowData.map((row) => row.eventId);

test('native and advanced numeric/date/datetime ranges retain inclusive bounds and round-trip exactly', () => {
  const cases = [
    {
      field: 'amount',
      native: { filterType: 'number', type: 'inRange', filter: 10, filterTo: 30 },
      advanced: {
        filterType: 'number',
        colId: 'amount',
        type: 'inRange',
        filter: 10,
        filterTo: 30,
      },
      expected: ['c', 'd', 'e'],
    },
    {
      field: 'day',
      native: {
        filterType: 'date',
        type: 'inRange',
        dateFrom: '2024-03-09 00:00:00',
        dateTo: '2024-03-10 00:00:00',
      },
      advanced: {
        filterType: 'dateString',
        colId: 'day',
        type: 'inRange',
        filter: '2024-03-09',
        filterTo: '2024-03-10',
      },
      expected: ['a', 'b', 'c', 'd'],
    },
    {
      field: 'time',
      native: {
        filterType: 'date',
        type: 'inRange',
        dateFrom: '2024-03-10T00:00:00-05:00',
        dateTo: '2024-03-10T03:00:00-04:00',
      },
      advanced: {
        filterType: 'dateTimeString',
        colId: 'time',
        type: 'inRange',
        filter: '2024-03-10 05:00:00',
        filterTo: '2024-03-10T07:00:00Z',
      },
      expected: ['c', 'd'],
    },
  ];
  for (const { field, native, advanced, expected } of cases) {
    const columnModel = { [field]: native };
    const columnNode = fromModel(columnModel, 'columns', columns)!;
    const advancedNode = fromModel(advanced, 'advanced', columns)!;
    assert.equal(canonical(columnNode), canonical(advancedNode));
    assert.deepEqual(ids(input('columns', columnModel)), expected);
    assert.deepEqual(ids(input('advanced', advanced)), expected);
    for (const mode of ['columns', 'advanced'] as const)
      assert.equal(
        canonical(fromModel(toModel(columnNode, mode, columns), mode, columns)),
        canonical(columnNode),
      );
    const compiled = compileStudioQuery(input('columns', columnModel), 'tenant-a', dataset);
    assert.deepEqual(compiled.rows.binds.slice(0, -2), compiled.matching.binds);
    assert.deepEqual(compiled.count.binds, compiled.matching.binds);
    assert.match(compiled.rows.sql, />=/);
    assert.match(compiled.rows.sql, /<=/);
    assert.deepEqual(compiled.total.binds, ['tenant-a']);
  }
});

test('two native ranges can join with AND or OR without losing nested range logic', () => {
  for (const operator of ['AND', 'OR']) {
    const filter = {
      amount: {
        filterType: 'number',
        operator,
        conditions: [
          { filterType: 'number', type: 'inRange', filter: -1, filterTo: 20 },
          { filterType: 'number', type: 'inRange', filter: 10, filterTo: 40 },
        ],
      },
    };
    const node = fromModel(filter, 'columns', columns)!;
    const roundTrip = toModel(node, 'columns', columns);
    assert.equal(canonical(fromModel(roundTrip, 'columns', columns)), canonical(node));
    assert.deepEqual(
      ids(input('columns', roundTrip)),
      operator === 'AND' ? ['c', 'd'] : ['a', 'b', 'c', 'd', 'e', 'f'],
    );
  }
});

test('calendar-date equality includes that date while datetime equality is an exact instant', () => {
  assert.deepEqual(
    ids(
      input('columns', {
        day: { filterType: 'date', type: 'equals', dateFrom: '2024-03-10 00:00:00', dateTo: null },
      }),
    ),
    ['b', 'c', 'd'],
  );
  assert.deepEqual(
    ids(
      input('columns', {
        time: { filterType: 'date', type: 'equals', dateFrom: '2024-03-10', dateTo: null },
      }),
    ),
    ['b'],
  );
  const sameInstant = input('advanced', {
    filterType: 'dateTimeString',
    colId: 'time',
    type: 'equals',
    filter: '2024-03-09T19:00:00-05:00',
  });
  assert.deepEqual(ids(sameInstant), ['b']);
  const query = compileStudioQuery(sameInstant, 'tenant-a', dataset);
  assert.match(query.rows.sql, /"TIME" = TO_TIMESTAMP_NTZ\(\?, 'YYYY-MM-DD HH24:MI:SS'\)/);
  assert.deepEqual(query.matching.binds, ['tenant-a', '2024-03-10 00:00:00']);
  const singleton = {
    time: {
      filterType: 'date',
      type: 'inRange',
      dateFrom: '2024-03-10 05:00:00',
      dateTo: '2024-03-10 05:00:00',
    },
  };
  assert.deepEqual(ids(input('columns', singleton)), ['c']);
});

test('local calendar days use half-open UTC bounds across 23-hour and 25-hour DST days', () => {
  for (const [day, expected, hours] of [
    ['2024-03-10', ['c', 'd', 'e'], 23],
    ['2024-11-03', ['g', 'h'], 25],
  ] as const) {
    const node = dayRange('time', day, { timeZone: 'America/New_York' } as any);
    assert.deepEqual(
      rows.filter((row) => evaluate(node, row)).map((row) => row.eventId),
      expected,
    );
    assert.equal(node.kind, 'group');
    if (node.kind !== 'group') assert.fail('Expected the two half-open day bounds.');
    const values = node.children.map((child) => (child.kind === 'rule' ? String(child.value) : ''));
    assert.equal(
      (Date.parse(values[1].replace(' ', 'T') + 'Z') -
        Date.parse(values[0].replace(' ', 'T') + 'Z')) /
        3_600_000,
      hours,
    );
    const query = compileStudioQuery(
      input('advanced', toModel(node, 'advanced', columns)),
      'tenant-a',
      dataset,
    );
    assert.match(query.rows.sql, /"TIME" >= TO_TIMESTAMP_NTZ/);
    assert.match(query.rows.sql, /"TIME" < TO_TIMESTAMP_NTZ/);
    assert.doesNotMatch(query.rows.sql, /"TIME" <=/);
  }
});

test('malformed dates, incomplete/reversed ranges and unsupported precision fail before any SQL', () => {
  assert.equal(plainDate('2024-02-29'), '2024-02-29');
  assert.equal(filterTimestamp('2024-01-01T00:30:00+01:00'), '2023-12-31 23:30:00');
  for (const value of ['2023-02-29', '2024-04-31', '0000-01-01'])
    assert.throws(() => plainDate(value));
  for (const value of [
    '2024-02-30 00:00:00',
    '2024-01-01 24:00:00',
    '2024-01-01 00:60:00',
    '2024-01-01 00:00:60',
    '2024-01-01 00:00:00.001',
    '2024-01-01T00:00:00+25:00',
    '0000-01-01 00:00:00',
  ])
    assert.throws(() => filterTimestamp(value), value);
  assert.throws(() => utcTimestamp('0001-01-01T00:00:00+01:00'));
  for (const filter of [
    { amount: { filterType: 'number', type: 'inRange', filter: 20 } },
    { amount: { filterType: 'number', type: 'inRange', filter: 20, filterTo: 10 } },
    { amount: { filterType: 'number', type: 'inRange', filter: 10, filterTo: Infinity } },
    {
      time: {
        filterType: 'date',
        type: 'inRange',
        dateFrom: '2024-03-11 00:00:00',
        dateTo: '2024-03-10 00:00:00',
      },
    },
    { time: { filterType: 'date', type: 'equals', filter: '2024-03-10 00:00:00' } },
    { day: { filterType: 'date', type: 'equals', dateFrom: '2024-03-10 01:00:00' } },
    { category: { filterType: 'text', type: 'inRange', filter: 'a', filterTo: 'z' } },
    { amount: { filterType: 'number', type: 'equals', filter: 1, filterTo: 2 } },
    { amount: { filterType: 'number', type: 'blank', filter: 1 } },
  ])
    assert.throws(() => compileStudioQuery(input('columns', filter), 'tenant-a', dataset));
});

test('ranges exclude SQL nulls while explicit blank OR preserves them and tenant binds stay outside OR', () => {
  const filter = {
    filterType: 'join',
    type: 'OR',
    conditions: [
      {
        filterType: 'dateTimeString',
        colId: 'time',
        type: 'inRange',
        filter: '2024-03-10 05:00:00',
        filterTo: '2024-03-10 07:00:00',
      },
      { filterType: 'dateTimeString', colId: 'time', type: 'blank' },
    ],
  };
  assert.deepEqual(ids(input('advanced', filter)), ['c', 'd', 'n']);
  const query = compileStudioQuery(input('advanced', filter), "tenant' OR 1=1 --", dataset);
  assert.match(query.rows.sql, /WHERE "TENANT_ID" = \? AND/);
  assert.match(query.rows.sql, / OR "TIME" IS NULL/);
  assert.deepEqual(query.matching.binds, [
    "tenant' OR 1=1 --",
    '2024-03-10 05:00:00',
    '2024-03-10 07:00:00',
  ]);
  assert.ok(!query.rows.sql.includes("tenant'"));
});

test('typed group routes normalize instants and reject invalid calendar/numeric keys', () => {
  for (const [field, key, expected, bound] of [
    ['amount', '1e1', ['c'], 10],
    ['day', '2024-03-10', ['b', 'c', 'd'], '2024-03-10'],
    ['time', '2024-03-10T01:00:00-04:00', ['c'], '2024-03-10 05:00:00'],
    ['time', '(Blanks)', ['n'], null],
  ] as const) {
    const request = input('advanced', null, { rowGroupCols: [{ id: field }], groupKeys: [key] });
    const query = compileStudioQuery(request, 'tenant-a', dataset);
    assert.deepEqual(ids(request), expected);
    assert.deepEqual(query.count.binds, bound === null ? ['tenant-a'] : ['tenant-a', bound]);
  }
  for (const [field, key] of [
    ['amount', ' '],
    ['amount', '0x10'],
    ['amount', 'Infinity'],
    ['amount', '9007199254740993'],
    ['day', '2024-02-30'],
    ['time', '2024-03-10'],
    ['time', '2024-03-10 05:00:00.1'],
    ['category', 1],
  ] as const)
    assert.throws(() =>
      compileStudioQuery(
        input('advanced', null, { rowGroupCols: [{ id: field }], groupKeys: [key] }),
        'tenant-a',
        dataset,
      ),
    );
});

test('typed pivot discovery normalizes datetime keys, preserves null tuples and uses independent ordered binds', () => {
  const request = input(
    'columns',
    { day: { filterType: 'date', type: 'inRange', dateFrom: '2024-03-10', dateTo: '2024-03-11' } },
    {
      rowGroupCols: [{ id: 'category' }],
      groupKeys: ['Alpha'],
      pivotMode: true,
      pivotCols: [{ id: 'time' }],
      valueCols: [{ id: 'amount', aggFunc: 'sum' }],
    },
  );
  const discovery = compileStudioPivotDiscovery(request, 'tenant-a', dataset);
  assert.ok(!discovery.binds.includes('Alpha'), 'Discovery must cover the full filtered cohort.');
  const query = compileStudioQuery(
    request,
    'tenant-a',
    dataset,
    [],
    [[null], ['2024-03-10T01:00:00-04:00']],
  );
  assert.deepEqual(query.pivotResultFields, [
    '(Blanks)|amount',
    '2024-03-10%2005%3A00%3A00|amount',
  ]);
  assert.deepEqual(query.count.binds, [
    'tenant-a',
    '2024-03-10',
    '2024-03-11',
    'Alpha',
    '2024-03-10 05:00:00',
  ]);
  assert.deepEqual(query.rows.binds, [...query.count.binds, 250, 0]);
  assert.deepEqual(query.matching.binds, ['tenant-a', '2024-03-10', '2024-03-11']);
  assert.deepEqual(query.total.binds, ['tenant-a']);
  assert.match(query.rows.sql, /IFF\("time" IS NULL, "amount", NULL\)/);
  assert.match(query.rows.sql, /"time" = TO_TIMESTAMP_NTZ\(\?, 'YYYY-MM-DD HH24:MI:SS'\)/);
  assert.equal(
    query.grandTotal,
    undefined,
    'Only the root route returns the complete cohort total.',
  );
  for (const tuples of [
    [[123]],
    [['2024-02-30 00:00:00']],
    [['2024-03-10 05:00:00'], ['2024-03-10T01:00:00-04:00']],
  ])
    assert.throws(() => compileStudioQuery(request, 'tenant-a', dataset, [], tuples));
});

test('pivot summaries retain detail sorts for leaves without sorting missing summary columns', () => {
  const request = input('advanced', null, {
    pivotMode: true,
    pivotCols: [{ id: 'category' }],
    valueCols: [{ id: 'amount', aggFunc: 'sum' }],
    sortModel: [{ colId: 'time', sort: 'desc' }],
  });
  const query = compileStudioQuery(request, 'tenant-a', dataset, [], [['Alpha'], ['Beta'], [null]]);
  assert.doesNotMatch(query.rows.sql, /ORDER BY "time"/);
  assert.equal(execute(request).rowCount, 1);
  assert.equal(execute(request).rowData[0]['Alpha|amount'], 59);
});

test('calculated range filters run before grouping and pivot projections with ordered constants', () => {
  const definition: CalculatedColumnDefinition = {
    id: 'calc_double',
    label: 'Twice amount',
    expression: {
      kind: 'binary',
      operator: 'multiply',
      left: { kind: 'field', field: 'amount' },
      right: { kind: 'number', value: 2 },
    },
  };
  const request = input(
    'advanced',
    { filterType: 'number', colId: 'calc_double', type: 'inRange', filter: 20, filterTo: 60 },
    {
      rowGroupCols: [{ id: 'category' }],
      valueCols: [{ id: 'calc_double', aggFunc: 'sum' }],
      sortModel: [{ colId: 'calc_double', sort: 'desc' }],
    },
  );
  request.calculatedColumnIds = [definition.id];
  const query = compileStudioQuery(request, 'tenant-a', dataset, [definition]);
  assert.deepEqual(query.matching.binds, ['tenant-a', 2, 20, 60]);
  assert.match(query.rows.sql, /"DERIVED_ROWS"/);
  assert.match(query.rows.sql, /SUM\("calc_double"\)/);
  const result = queryAnalyticsRows(
    null,
    request,
    { columns, rows, rowIdColumn: 'eventId', rawGroupKeys: true, includeGroupCount: true },
    undefined,
    [definition],
  );
  assert.equal(result.rowData[0]['category'], 'Beta');
  assert.equal(result.rowData[0]['calc_double'], 100);
  assert.equal(result.grandTotalData?.['calc_double'], 120);
  assert.throws(() =>
    compileStudioQuery({ ...request, calculatedColumnIds: [] }, 'tenant-a', dataset, [definition]),
  );
  assert.throws(() =>
    calculatedColumnSpec({ ...definition, expression: { kind: 'field', field: 'time' } }, columns),
  );
});

test('executor results reject inconsistent paging, unsafe counts, missing/duplicate keys and bad group aliases', () => {
  const leaf = compileStudioQuery(input('advanced', null, { endRow: 2 }), 'tenant-a', dataset);
  const valid: StudioQueryResult = {
    rowData: [rows[0], rows[1]],
    rowCount: rows.length,
    matchedRowCount: rows.length,
    totalRowCount: rows.length,
  };
  assert.doesNotThrow(() => validateStudioQueryResult(leaf, valid, dataset));
  for (const bad of [
    { ...valid, rowCount: -1 },
    { ...valid, totalRowCount: Number.MAX_SAFE_INTEGER + 1 },
    { ...valid, totalRowCount: 1 },
    { ...valid, rowData: [rows[0]] },
    { ...valid, rowData: [rows[0], rows[0]] },
    { ...valid, rowData: [{ amount: 1 }, rows[0]] },
    { ...valid, rowData: [{ eventId: null }, rows[0]] },
    { ...valid, pivotResultFields: ['invented'] },
  ])
    assert.throws(() => validateStudioQueryResult(leaf, bad as StudioQueryResult, dataset));
  const group = compileStudioQuery(
    input('advanced', null, { rowGroupCols: [{ id: 'day' }] }),
    'tenant-a',
    dataset,
  );
  const groupResult = {
    rowData: [{ day: '2024-03-10', __groupCount: 3 }],
    rowCount: 1,
    matchedRowCount: 3,
    totalRowCount: 10,
  };
  assert.doesNotThrow(() => validateStudioQueryResult(group, groupResult, dataset));
  for (const row of [
    { DAY: '2024-03-10', __groupCount: 3 },
    { day: '2024-02-30', __groupCount: 3 },
    { day: '2024-03-10', __groupCount: 0 },
    { day: '2024-03-10', __groupCount: 4 },
  ])
    assert.throws(() =>
      validateStudioQueryResult(
        group,
        { ...groupResult, rowData: [row] } as StudioQueryResult,
        dataset,
      ),
    );
  const afterEnd = compileStudioQuery(
    input('advanced', null, { startRow: 20, endRow: 22 }),
    'tenant-a',
    dataset,
  );
  assert.doesNotThrow(() =>
    validateStudioQueryResult(afterEnd, { ...valid, rowData: [] }, dataset),
  );
});

test('metadata-only host grids execute without a browser snapshot and source changes cancel stale blocks', async () => {
  let sourceId = 'remote-one';
  const pending: {
    context: unknown;
    signal: AbortSignal;
    resolve: (value: StudioQueryResult) => void;
  }[] = [];
  const datasource = createStudioDatasource({
    context: () => ({
      mode: 'advanced',
      tenant: 'host-placeholder',
      sourceId,
      dataset,
      definitions: [],
    }),
    executor: {
      discoverPivots: async () => [],
      summarize: async () => [],
      execute: (_query, signal, context) =>
        new Promise((resolve) => pending.push({ context, signal, resolve })),
    },
  });
  const received: string[] = [];
  const block = {
    request: input('advanced', null, { endRow: 1 }).request,
    api: { isDestroyed: () => false },
    success: (result: any) => received.push(result.rowData[0].eventId),
    fail: () => assert.fail('A metadata-only host result should succeed.'),
  };
  datasource.getRows(block as any);
  sourceId = 'remote-two';
  datasource.getRows(block as any);
  assert.equal(pending[0].signal.aborted, true);
  assert.equal((pending[1].context as any).sourceId, 'remote-two');
  pending[0].resolve({
    rowData: [{ eventId: 'old' }],
    rowCount: 1,
    matchedRowCount: 1,
    totalRowCount: 1,
  });
  pending[1].resolve({
    rowData: [{ eventId: 'new' }],
    rowCount: 1,
    matchedRowCount: 1,
    totalRowCount: 1,
  });
  await new Promise((resolve) => setImmediate(resolve));
  assert.deepEqual(received, ['new']);
  datasource.destroy?.();
});

test('datasource reports invalid backend result aliases and sparse pages through fail', async () => {
  for (const invalid of [
    { rowData: [{ EVENTID: 'e1' }], rowCount: 1, matchedRowCount: 1, totalRowCount: 1 },
    { rowData: [], rowCount: 1, matchedRowCount: 1, totalRowCount: 1 },
  ]) {
    let failure = 0;
    let message = '';
    const datasource = createStudioDatasource({
      context: () => ({
        mode: 'advanced',
        tenant: 'tenant-a',
        sourceId: 'remote-only',
        dataset,
        definitions: [],
      }),
      executor: {
        discoverPivots: async () => [],
        summarize: async () => [],
        execute: async () => invalid as StudioQueryResult,
      },
      error: (error) => {
        message = error.message;
      },
    });
    datasource.getRows({
      request: input('advanced', null, { endRow: 1 }).request,
      api: { isDestroyed: () => false },
      success: () => assert.fail('An invalid backend page must not enter the AG cache.'),
      fail: () => {
        failure++;
      },
    } as any);
    await new Promise((resolve) => setImmediate(resolve));
    assert.equal(failure, 1);
    assert.match(message, /row-ID alias|block length/);
    datasource.destroy?.();
  }
});
