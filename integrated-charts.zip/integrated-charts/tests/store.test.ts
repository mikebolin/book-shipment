import { seed, dataProvider } from './fixtures';
import '@angular/compiler';
import test from 'node:test';
import assert from 'node:assert/strict';
import { createEnvironmentInjector, runInInjectionContext, DestroyRef } from '@angular/core';
import { WorkspaceStore, injectUiState } from '../libs/charting/src/lib/core/state/index';
import {
  createInitialState,
  getResource,
  publishResource,
  saveResource,
  removeResource,
  cards,
} from '../libs/charting/src/lib/core/state/workspace-state';

function seededState() {
  return createInitialState(seed());
}
const dashboardInput = (name: string) => ({ name, body: { schemaVersion: 2, items: [] } });
test('the original seeded gallery has all models, views, dashboards and 2,000-row featured samples', () => {
  const s = seededState();
  // Seven original models plus the Activity monitor demo: three grouped views and two triage
  // dashboards built from them.
  assert.equal(s.resources.models.length, 8);
  assert.equal(s.resources.widgets.length, 10);
  assert.equal(s.resources.dashboards.length, 8);
  assert.equal(s.datasets['finance-demo'].length, 2000);
  assert.equal(s.datasets['healthcare-demo'].length, 2000);
  assert.equal(cards(s, 'widgets', true).length, 10);
  assert.equal(cards(s, 'dashboards', true).length, 8);
  const activity = s.resources.models.find((m) => m.body.sourceKey === 'activity-monitor')!;
  assert.equal(activity.body.rowCount, 60000);
  assert.equal(activity.body.sqlDataset.rowIdColumn, 'id');
  const grouped = s.resources.widgets.filter((w) => w.modelId === activity.id);
  assert.equal(grouped.length, 3);
  for (const view of grouped) {
    assert.ok(view.publishedVersion);
    assert.ok(view.body.gridState.rowGroup.groupColIds.length >= 1);
    assert.ok(view.body.gridState.aggregation.aggregationModel.length >= 1);
  }
  const triage = s.resources.dashboards.filter((d) =>
    d.body.items.some((item) => item.kind === 'filter'),
  );
  assert.deepEqual(triage.map((d) => d.name).sort(), [
    'Explore failure activity',
    'Failure triage',
  ]);
  for (const dashboard of triage) {
    const controls = dashboard.body.items.find((item) => item.kind === 'filter');
    assert.equal(controls.filter.mode, 'advanced');
    assert.equal(controls.filter.filterModel.conditions.length, 3);
    assert.deepEqual(
      controls.controls.map((control) => control.type),
      ['window', 'bucket', 'values', 'values', 'groupBy'],
    );
    assert.ok(
      dashboard.body.items.some((item) => item.kind === 'chart' && item.interactions?.selectFilter),
    );
    assert.ok(
      dashboard.body.items.some((item) => item.kind === 'view' && item.displayMode === 'grid'),
    );
  }
  for (const d of s.resources.dashboards)
    for (const p of d.body.items)
      if (p.widgetId) assert.ok(getResource(s, 'widgets', p.widgetId, true, p.widgetRevision));
});
test('draft edits leave immutable publications intact and reject stale saves', () => {
  let s = seededState();
  const original = s.resources.widgets[0];
  const published = getResource<any>(s, 'widgets', original.id, true);
  const result = saveResource(
    s,
    'widgets',
    {
      name: 'Changed',
      description: 'Draft only',
      modelId: original.modelId,
      body: { ...original.body, displayMode: 'grid' },
    },
    original,
  );
  s = result.state;
  assert.equal(getResource(s, 'widgets', original.id).name, 'Changed');
  assert.deepEqual(getResource(s, 'widgets', original.id, true), published);
  assert.throws(() => saveResource(s, 'widgets', { name: 'Stale' }, original), /changed/);
  const next = publishResource(s, 'widgets', result.resource);
  s = next.state;
  assert.equal(getResource(s, 'widgets', original.id, true).name, 'Changed');
  assert.equal(getResource(s, 'widgets', original.id, true, 1).name, published.name);
});
test('create, rename, publish, duplicate and delete a dashboard entirely in memory', () => {
  let s = seededState();
  let result = saveResource(s, 'dashboards', dashboardInput('Local board'));
  s = result.state;
  let resource = result.resource;
  result = saveResource(s, 'dashboards', dashboardInput('Renamed board'), resource);
  s = result.state;
  resource = result.resource;
  const publication = publishResource(s, 'dashboards', resource);
  s = publication.state;
  resource = publication.resource;
  const copy = saveResource(s, 'dashboards', { ...dashboardInput('Copy'), body: resource.body });
  s = copy.state;
  assert.notEqual(copy.resource.id, resource.id);
  s = removeResource(s, 'dashboards', copy.resource);
  s = removeResource(s, 'dashboards', resource);
  assert.equal(s.resources.dashboards.length, 8);
  assert.ok(!s.revisions[resource.id]);
});
test('model/view referential integrity protects pinned dashboard data', () => {
  const s = seededState();
  assert.throws(
    () =>
      removeResource(
        s,
        'models',
        s.resources.models.find((m) => m.body.sourceKey === 'finance-demo')!,
      ),
    /used by saved views/,
  );
  assert.throws(() => removeResource(s, 'widgets', s.resources.widgets[0]), /pinned/);
  const broken = {
    name: 'Broken',
    body: { schemaVersion: 2, items: [{ id: 'x', widgetId: 'missing', widgetRevision: 1 }] },
  };
  assert.throws(() => saveResource(s, 'dashboards', broken), /no longer available/);
});
test('host seeds are isolated and writes require no session', () => {
  const a = seededState(),
    b = seededState();
  a.resources.models[0].name = 'MUTATED';
  assert.notEqual(b.resources.models[0].name, 'MUTATED');
  assert.equal(
    saveResource(b, 'dashboards', dashboardInput('Open workspace')).state.resources.dashboards
      .length,
    9,
  );
  assert.equal('user' in b, false);
});
test('NgRx root store is shared by child injectors, preferences update reactively, UI scopes dispose', () => {
  const root = createEnvironmentInjector([WorkspaceStore, dataProvider], null as any);
  const child = createEnvironmentInjector([], root);
  const store = root.get(WorkspaceStore);
  assert.equal(child.get(WorkspaceStore), store);
  assert.equal(store.currentPreferences().themeId, 'azure-blue');
  store.savePreferences({ themeId: 'rose-red', density: 'comfortable', reducedMotion: true }, 0);
  assert.equal(store.currentPreferences().themeId, 'rose-red');
  assert.throws(
    () =>
      store.savePreferences({ themeId: 'azure-blue', density: 'compact', reducedMotion: false }, 0),
    /changed/,
  );
  const lens = runInInjectionContext(child, () => injectUiState('test').signal(1));
  assert.equal(lens(), 1);
  lens.update((x) => x + 2);
  assert.equal(lens(), 3);
  assert.equal(Object.keys(store.ui()).length, 1);
  child.destroy();
  assert.equal(Object.keys(store.ui()).length, 0);
  lens.set(99);
  assert.equal(Object.keys(store.ui()).length, 0);
  store.resetDemo();
  assert.equal(store.resources.dashboards().length, 8);
  assert.equal(store.currentPreferences().themeId, 'azure-blue');
  root.destroy();
});

test('resource selectors ignore unrelated UI state and react to domain mutations', async () => {
  const { computed } = await import('@angular/core');
  const root = createEnvironmentInjector([WorkspaceStore, dataProvider], null as any),
    store = root.get(WorkspaceStore);
  let evaluations = 0;
  const gallery = computed(() => {
    evaluations++;
    return store.cards('dashboards', false);
  });
  assert.equal(gallery().length, 8);
  store.setUi('temporary', 'search', 'term');
  assert.equal(gallery().length, 8);
  assert.equal(evaluations, 1);
  store.create('dashboards', dashboardInput('Reactive board'));
  assert.equal(gallery().length, 9);
  assert.equal(evaluations, 2);
  root.destroy();
});

test('Charting works with an empty default host and no demo imports', () => {
  const root = createEnvironmentInjector(
    [WorkspaceStore, { ...dataProvider, useValue: { createSeed: () => createInitialState() } }],
    null as any,
  );
  const store = root.get(WorkspaceStore);
  assert.equal(store.resources.models().length, 0);
  store.create('dashboards', dashboardInput('Host without fixtures'));
  assert.equal(store.resources.dashboards().length, 1);
  root.destroy();
});
