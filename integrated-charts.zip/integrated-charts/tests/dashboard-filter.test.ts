import test from 'node:test';
import assert from 'node:assert/strict';
import type { ColumnSpec } from '../libs/charting/src/lib/core/domain/schema';
import {
  buildChartDataset,
  chartTimeBucket,
  resolveChartTimeRange,
} from '../libs/charting/src/lib/core/domain/chart-data';
import { timeDomain } from '../libs/charting/src/lib/core/domain/chart-extensions';
import { fromModel } from '../libs/charting/src/lib/core/domain/grid-model';
import type { ChartPlan } from '../libs/charting/src/lib/core/domain/integrated-chart';
import {
  applyFilterParameters,
  filterParameters,
} from '../libs/charting/src/lib/rendering/filter-parameters';
import {
  bucketFromSeconds,
  bucketSecondsLabel,
  bucketSpan,
  selectChartCategory,
  toggleEquals,
  withTimeBounds,
} from '../libs/dashboards/src/lib/dashboard-filter';
import {
  composeDashboardControls,
  dashboardControlDraft,
  dashboardDefaultScope,
} from '../libs/dashboards/src/lib/dashboard-control-settings';
import type { DashboardControl } from '../libs/charting/src/lib/core/domain/workspace.types';

const column = (
  id: string,
  kind: ColumnSpec['kind'],
  extra: Partial<ColumnSpec> = {},
): ColumnSpec => ({
  id,
  kind,
  nullable: false,
  sql: id.toUpperCase(),
  label: id,
  aliases: [],
  description: id,
  ...extra,
});
const columns = [
  column('id', 'text', { chartRole: 'identifier' }),
  column('type', 'text', { chartRole: 'dimension' }),
  column('status', 'text', { chartRole: 'dimension' }),
  column('startedAt', 'datetime', { chartRole: 'temporal' }),
  column('events', 'number', { chartRole: 'measure', unit: 'events' }),
];
const rows = [
  { id: 'a', type: 'Ingestion', status: 'Failed', startedAt: '2026-10-03 11:35:10', events: 1 },
  { id: 'b', type: 'Ingestion', status: 'Failed', startedAt: '2026-10-03 11:35:50', events: 1 },
  { id: 'c', type: 'Inbound Job', status: 'Breached', startedAt: '2026-10-03 11:38:00', events: 1 },
  { id: 'd', type: 'SLA', status: 'Completed', startedAt: '2026-10-03 11:41:00', events: 1 },
];
const window = {
  filterType: 'join',
  type: 'AND',
  conditions: [
    {
      filterType: 'dateTimeString',
      colId: 'startedAt',
      type: 'greaterThanOrEqual',
      filter: '2026-10-03T11:30:00',
    },
    {
      filterType: 'dateTimeString',
      colId: 'startedAt',
      type: 'lessThan',
      filter: '2026-10-03T11:45:00',
    },
    {
      filterType: 'join',
      type: 'OR',
      conditions: [
        { filterType: 'text', colId: 'status', type: 'equals', filter: 'Failed' },
        { filterType: 'text', colId: 'status', type: 'equals', filter: 'Breached' },
      ],
    },
  ],
};
const timeline: ChartPlan = {
  type: 'column',
  categoryColumnId: 'startedAt',
  measureColumnIds: [],
  aggregation: 'count',
  timeBucket: 'minute',
  bucketSize: 5,
  timeRange: { fill: 'zero' },
  title: 'Failures over time',
};

test('minute buckets align to the epoch and the filter supplies the zero-filled domain', () => {
  assert.equal(chartTimeBucket('2026-10-03 11:37:59', 'minute', 5), '2026-10-03 11:35');
  assert.equal(chartTimeBucket('2026-10-03T11:37:59Z', 'minute'), '2026-10-03 11:37');
  assert.equal(chartTimeBucket('2026-10-03 11:37:59', 'hour'), '2026-10-03 11:00');
  const node = fromModel(window, 'advanced', columns);
  const resolved = resolveChartTimeRange(timeline, node);
  assert.deepEqual(resolved.timeRange, {
    start: '2026-10-03 11:30:00',
    endExclusive: '2026-10-03 11:45:00',
    fill: 'zero',
  });
  assert.deepEqual(
    timeDomain(resolved, (value, bucket) => chartTimeBucket(value, bucket, 5)),
    ['2026-10-03 11:30', '2026-10-03 11:35', '2026-10-03 11:40'],
  );
  // Without bounds on the category column the chart keeps its observed buckets only.
  assert.equal(
    resolveChartTimeRange(timeline, fromModel(window.conditions[2], 'advanced', columns)).timeRange,
    undefined,
  );
  const dataset = buildChartDataset(resolved, columns, rows.slice(0, 3));
  assert.deepEqual(
    dataset.rows.map((row) => [row['category'], row['measure0']]),
    [
      ['2026-10-03 11:30', 0],
      ['2026-10-03 11:35', 3],
      ['2026-10-03 11:40', 0],
    ],
  );
  assert.deepEqual(dataset.categoryDisplayLabels, {
    '2026-10-03 11:30': '11:30',
    '2026-10-03 11:35': '11:35',
    '2026-10-03 11:40': '11:40',
  });
  assert.throws(() =>
    buildChartDataset({ ...timeline, timeBucket: 'day', bucketSize: 5 }, columns, rows),
  );
});

test('second buckets slice to six seconds and a twelve-hour window still completes its domain', () => {
  assert.equal(chartTimeBucket('2026-10-03 11:37:59', 'second', 6), '2026-10-03 11:37:54');
  assert.equal(chartTimeBucket('2026-10-03T11:37:59Z', 'second'), '2026-10-03 11:37:59');
  const fine: ChartPlan = { ...timeline, timeBucket: 'second', bucketSize: 6 };
  const resolved = resolveChartTimeRange(fine, fromModel(window, 'advanced', columns));
  const bucketOf = (value: string, bucket: ChartPlan['timeBucket']) =>
    chartTimeBucket(value, bucket, 6);
  const domain = timeDomain(resolved, bucketOf);
  assert.equal(domain.length, 150);
  assert.equal(domain[0], '2026-10-03 11:30:00');
  assert.equal(domain.at(-1), '2026-10-03 11:44:54');
  const dataset = buildChartDataset(resolved, columns, rows.slice(0, 3));
  assert.equal(dataset.rows.length, 150);
  assert.deepEqual(
    dataset.rows.filter((row) => row['measure0']).map((row) => [row['category'], row['measure0']]),
    [
      ['2026-10-03 11:35:06', 1],
      ['2026-10-03 11:35:48', 1],
      ['2026-10-03 11:38:00', 1],
    ],
  );
  assert.equal(dataset.categoryDisplayLabels?.['2026-10-03 11:35:06'], '11:35:06');
  // Twelve hours of six-second slices is the widest offered combination; one-second slices over
  // the same window exceed the time-axis cap.
  const halfDay = {
    ...fine,
    timeRange: {
      start: '2026-10-03 00:00:00',
      endExclusive: '2026-10-03 12:00:00',
      fill: 'zero' as const,
    },
  };
  assert.equal(timeDomain(halfDay, bucketOf).length, 7200);
  assert.throws(
    () =>
      timeDomain({ ...halfDay, bucketSize: 1 }, (value, bucket) =>
        chartTimeBucket(value, bucket, 1),
      ),
    /7,200 buckets/,
  );
  // The dashboard bucket control speaks seconds; charts receive the matching unit and size.
  assert.deepEqual(bucketFromSeconds(6), { timeBucket: 'second', bucketSize: 6 });
  assert.deepEqual(bucketFromSeconds(300), { timeBucket: 'minute', bucketSize: 5 });
  assert.deepEqual(bucketFromSeconds(3600), { timeBucket: 'hour', bucketSize: 1 });
  assert.deepEqual([6, 30, 60, 90, 300, 900, 3600].map(bucketSecondsLabel), [
    '6 s',
    '30 s',
    '1 min',
    '90 s',
    '5 min',
    '15 min',
    '1 h',
  ]);
  assert.deepEqual(bucketSpan('2026-10-03 11:35:06', 'second', 6), {
    start: new Date('2026-10-03T11:35:06Z'),
    end: new Date('2026-10-03T11:35:12Z'),
  });
  const narrowed = selectChartCategory(
    window,
    fine,
    columns[3],
    '2026-10-03 11:35:06',
  ) as typeof window;
  assert.deepEqual(
    narrowed.conditions.filter((rule) => rule.colId === 'startedAt').map((rule) => rule.filter),
    ['2026-10-03T11:35:06', '2026-10-03T11:35:12'],
  );
});

test('datetime filter values become datetime-local inputs that store the canonical UTC form', () => {
  const parameters = filterParameters(window, 'advanced', columns);
  const start = parameters.find((parameter) => parameter.operator === 'greater than or equal')!;
  assert.equal(start.kind, 'datetime');
  const applied = applyFilterParameters(window, parameters, {
    [start.id]: '2026-10-03T11:35',
  }) as typeof window;
  assert.equal(applied.conditions[0].filter, '2026-10-03T11:35:00');
  const zoned = applyFilterParameters(window, parameters, {
    [start.id]: '2026-10-03T13:35:00+02:00',
  }) as typeof window;
  assert.equal(zoned.conditions[0].filter, '2026-10-03T11:35:00');
  assert.throws(() => applyFilterParameters(window, parameters, { [start.id]: 'noon' }));
  // The stored form still validates and compiles through the shared filter engine.
  assert.ok(fromModel(applied, 'advanced', columns));
});

test('chart clicks rewrite dashboard filter values without changing its predicates', () => {
  const started = columns[3];
  const type = columns[1];
  assert.deepEqual(bucketSpan('2026-10-03 11:35', 'minute', 5), {
    start: new Date('2026-10-03T11:35:00Z'),
    end: new Date('2026-10-03T11:40:00Z'),
  });
  assert.deepEqual(bucketSpan('2026 Q4', 'quarter'), {
    start: new Date('2026-10-01T00:00:00Z'),
    end: new Date('2027-01-01T00:00:00Z'),
  });
  const narrowed = selectChartCategory(
    window,
    timeline,
    started,
    '2026-10-03 11:35',
  ) as typeof window;
  assert.equal(narrowed.conditions.length, 3);
  assert.deepEqual(
    narrowed.conditions.filter((rule) => rule.colId === 'startedAt').map((rule) => rule.filter),
    ['2026-10-03T11:35:00', '2026-10-03T11:40:00'],
  );
  assert.deepEqual(narrowed.conditions[0], window.conditions[2]);
  const selected = toggleEquals(window, type, 'Ingestion') as typeof window;
  assert.deepEqual(selected.conditions.at(-1), {
    filterType: 'text',
    colId: 'type',
    type: 'equals',
    filter: 'Ingestion',
  });
  const replaced = toggleEquals(selected, type, 'SLA') as typeof window;
  assert.equal(replaced.conditions.filter((rule) => rule.colId === 'type').length, 1);
  assert.equal(replaced.conditions.at(-1)!.filter, 'SLA');
  assert.deepEqual(toggleEquals(replaced, type, 'SLA'), window);
  assert.deepEqual(
    withTimeBounds(
      null,
      started,
      new Date('2026-10-03T11:00:00Z'),
      new Date('2026-10-03T12:00:00Z'),
    ),
    {
      filterType: 'join',
      type: 'AND',
      conditions: [
        {
          filterType: 'dateTimeString',
          colId: 'startedAt',
          type: 'greaterThanOrEqual',
          filter: '2026-10-03T11:00:00',
        },
        {
          filterType: 'dateTimeString',
          colId: 'startedAt',
          type: 'lessThan',
          filter: '2026-10-03T12:00:00',
        },
      ],
    },
  );
  for (const model of [narrowed, selected, replaced])
    assert.ok(fromModel(model, 'advanced', columns));
});

test('configured reader controls preserve status OR logic and persist bucket/grouping defaults', () => {
  const controls: DashboardControl[] = [
    { type: 'window', columnId: 'startedAt', options: [15, 30, 60], endsAt: '2026-10-03T11:45:00' },
    {
      type: 'values',
      columnId: 'status',
      options: ['Failed', 'Breached', 'Completed'],
      multiple: true,
    },
    { type: 'bucket', options: [6, 60, 300], seconds: 300 },
    {
      type: 'groupBy',
      options: [{ columnId: 'type', label: 'Event type' }, { columnId: 'status' }],
      allowNone: true,
    },
  ];
  const drafts = controls.map((control, index) =>
    dashboardControlDraft(control, window, String(index)),
  );
  drafts[0].defaultMinutes = 30;
  drafts[3].defaultGroupBy = 'status';
  const configuration = composeDashboardControls(drafts, window, columns);
  const serialized = JSON.parse(JSON.stringify(configuration));
  const scope = dashboardDefaultScope(serialized.filterModel, serialized.controls, columns);
  assert.equal(scope.bucketSeconds, 300);
  assert.equal(scope.groupBy, 'status');
  const model = scope.filterModel as typeof window;
  assert.equal(model.conditions[0].filter, '2026-10-03T11:15:00');
  assert.deepEqual(model.conditions.at(-1), window.conditions[2]);
  assert.ok(fromModel(model, 'advanced', columns));
  const grouping = configuration.controls.at(-1) as Extract<DashboardControl, { type: 'groupBy' }>;
  assert.equal(grouping.options[0].label, 'Event type');
  drafts[3].defaultGroupBy = '';
  const ungrouped = composeDashboardControls(drafts, window, columns);
  assert.equal(
    dashboardDefaultScope(ungrouped.filterModel, ungrouped.controls, columns).groupBy,
    null,
  );
});

test('relative reader windows evaluate against current time and leave saved predicates unchanged', () => {
  const now = new Date('2030-01-02T12:00:00Z');
  const controls: DashboardControl[] = [
    { type: 'window', columnId: 'startedAt', options: [15, 30, 60], minutes: 30, anchor: 'now' },
  ];
  const scope = dashboardDefaultScope(window, controls, columns, now);
  const bounds = (scope.filterModel as typeof window).conditions.filter(
    (rule) => rule.colId === 'startedAt',
  );
  assert.deepEqual(
    bounds.map((rule) => rule.filter),
    ['2030-01-02T11:30:00', '2030-01-02T12:00:00'],
  );
  assert.equal(window.conditions[0].filter, '2026-10-03T11:30:00');
  assert.deepEqual((scope.filterModel as typeof window).conditions[0], window.conditions[2]);
  assert.ok(fromModel(scope.filterModel, 'advanced', columns));
});

test('custom controls reject invalid bindings and unusable defaults before they reach a dashboard', () => {
  const make = (control: DashboardControl) => dashboardControlDraft(control, window, 'control');
  const values = make({
    type: 'values',
    columnId: 'status',
    options: ['Failed', 'Breached'],
    multiple: true,
  });
  values.defaultValuesText = 'Completed';
  assert.throws(() => composeDashboardControls([values], window, columns), /default value/);
  const bucket = make({ type: 'bucket', options: [6, 60], seconds: 300 });
  assert.throws(() => composeDashboardControls([bucket], window, columns), /default bucket/);
  const numericWindow = make({ type: 'window', columnId: 'events', options: [60] });
  assert.throws(
    () => composeDashboardControls([numericWindow], window, columns),
    /date or timestamp/,
  );
  const grouping = make({ type: 'groupBy', options: [{ columnId: 'type' }], allowNone: false });
  grouping.defaultGroupBy = '';
  assert.throws(() => composeDashboardControls([grouping], window, columns), /default grouping/);
  const duplicate = make({ type: 'bucket', options: [60], seconds: 60 });
  assert.throws(
    () => composeDashboardControls([duplicate, duplicate], window, columns),
    /one bucket control/,
  );
});
