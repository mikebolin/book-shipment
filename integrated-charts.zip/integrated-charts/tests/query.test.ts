import { seed } from './fixtures';
import test from 'node:test';
import assert from 'node:assert/strict';
import { createInitialState } from '../libs/charting/src/lib/core/state/workspace-state';
import { BrowserDataCache } from '../libs/charting/src/lib/explorer/browser-data-cache';
import { LocalDataRouter } from '../libs/charting/src/lib/explorer/local-data-router';
import {
  ClientDatasetRegistry,
  type LocalDataset,
} from '../libs/charting/src/lib/explorer/client-data-sources';
const state = createInitialState(seed());
const model = state.resources.models.find((m) => m.body.sourceKey === 'finance-demo')!;
const source = model.body.clientSourceId;
function setup() {
  const rows = state.datasets['finance-demo'];
  const dataset = {
    metadata: { ...model.body, id: source, local: true },
    rows,
    originalFields: model.body.columns.map((c: any) => ({
      originalName: c.id,
      columnId: c.id,
      inferredType: c.kind,
      gridType: c.kind,
      nullable: c.nullable,
      identifier: c.id === 'id',
      unique: c.id === 'id',
    })),
    warnings: [],
    provenance: {
      kind: 'local-json',
      fileName: 'finance.json',
      bytes: 0,
      importedAt: '2026-10-01',
      rowCount: rows.length,
    },
  } as LocalDataset;
  const registry = new ClientDatasetRegistry();
  registry.register(dataset);
  const cache = new BrowserDataCache();
  const router = new LocalDataRouter(registry, cache);
  router.register(source);
  return { cache, router };
}
test('local chart aggregation matches the original 2,000-row dataset', async () => {
  const { cache } = setup();
  const plan = state.resources.widgets[0].body.chart.plan;
  const result: any = await cache.query(source, 'analytics/chart', {
    mode: 'advanced',
    filterModel: null,
    calculatedColumnIds: [],
    plan,
  });
  assert.equal(result.matchedRowCount, 2000);
  assert.equal(result.rows.length, 5);
  const total = state.datasets['finance-demo'].reduce(
    (sum, row) => sum + Number(row.marketValue),
    0,
  );
  const aggregate = result.rows.reduce((sum: number, row: any) => sum + row.measure0, 0);
  assert.ok(Math.abs(aggregate - total) < 0.0001, 'Chart totals must reconcile to the source rows');
});
test('nested advanced filter OR/AND is evaluated locally for chart data', async () => {
  const { cache } = setup();
  const filter = {
    filterType: 'join',
    type: 'AND',
    conditions: [
      {
        filterType: 'join',
        type: 'OR',
        conditions: [
          { filterType: 'text', colId: 'region', type: 'equals', filter: 'Europe' },
          { filterType: 'text', colId: 'region', type: 'equals', filter: 'North America' },
        ],
      },
      { filterType: 'number', colId: 'marketValue', type: 'greaterThan', filter: 100000 },
    ],
  };
  const plan = state.resources.widgets[0].body.chart.plan;
  const result: any = await cache.query(source, 'analytics/chart', {
    mode: 'advanced',
    filterModel: filter,
    calculatedColumnIds: [],
    plan,
  });
  const expected = state.datasets['finance-demo'].filter(
    (row) =>
      ['Europe', 'North America'].includes(String(row.region)) && Number(row.marketValue) > 100000,
  );
  assert.equal(result.matchedRowCount, expected.length);
  assert.ok(result.matchedRowCount < 2000);
});
test('offline schema and guided chart proposal support confirmation without transport', async () => {
  const { router } = setup();
  const schema: any = router.request(source, 'schema');
  assert.equal(schema.streamingEnabled, false);
  assert.equal(schema.provider, 'mock');
  assert.equal(schema.columns.length, 18);
  const plan = state.resources.widgets[0].body.chart.plan;
  const input = { mode: 'advanced', currentState: {}, calculatedColumnIds: [], plan };
  const proposal: any = await router.request(source, 'grid/chart-proposal', input);
  assert.equal(proposal.status, 'proposal');
  const confirmation: any = await router.request(source, 'nl/grid/confirm', {
    ...input,
    id: proposal.id,
  });
  assert.equal(confirmation.chart.title, plan.title);
});

test('focused previews filter and aggregate a private result without mutating source or saved state', async () => {
  const { previewFilter } = await import('../libs/charting/src/lib/rendering/filter-preview');
  const source = {
    rows: state.datasets['finance-demo'],
    chart: state.resources.widgets[0].body.chart,
  };
  const before = JSON.stringify(source);
  const scope = {
    mode: 'advanced' as const,
    filterModel: { filterType: 'text', colId: 'region', type: 'equals', filter: 'Europe' },
  };
  const preview = previewFilter(source, model.body.columns, scope);
  const expected = source.rows.filter((row) => row.region === 'Europe');
  assert.equal(preview.count, expected.length);
  assert.equal(preview.chart?.matchedRowCount, expected.length);
  assert.deepEqual(preview.rows, expected);
  assert.equal(JSON.stringify(source), before);
  assert.equal(
    previewFilter(source, model.body.columns, { mode: 'advanced', filterModel: null }).count,
    2000,
  );
});
