import '@angular/compiler';
import test from 'node:test';
import assert from 'node:assert/strict';
import { createEnvironmentInjector, runInInjectionContext } from '@angular/core';
import { WorkspaceStore } from '../libs/charting/src/lib/core/state/index';
import { FilterValuesFormComponent } from '../libs/charting/src/lib/rendering/filter-values-form.component';
import { dataProvider, seed } from './fixtures';

test('value form updates natural language reactively, preserves grouping, validates numbers and applies explicitly', () => {
  const root = createEnvironmentInjector([WorkspaceStore, dataProvider], null as any);
  const form = runInInjectionContext(root, () => new FilterValuesFormComponent());
  const original = {
    mode: 'advanced' as const,
    filterModel: {
      filterType: 'join',
      type: 'OR',
      conditions: [
        { filterType: 'text', colId: 'region', type: 'equals', filter: 'Europe' },
        { filterType: 'number', colId: 'marketValue', type: 'greaterThan', filter: 100000 },
      ],
    },
  };
  form.columns = seed().resources!.models![0].body.columns;
  form.scope = structuredClone(original);
  form.ngOnChanges();
  const emitted: unknown[] = [];
  form.scopeChange.subscribe((value) => emitted.push(value));
  form.form.controls[form.parameters[0].id].setValue('North America');
  assert.match(form.summary(), /North America.*or.*100000/);
  assert.equal(emitted.length, 0);
  assert.deepEqual(form.scope, original);
  form.apply();
  assert.equal(emitted.length, 1);
  assert.equal((emitted[0] as any).filterModel.type, 'OR');
  form.form.controls[form.parameters[1].id].setValue(null);
  assert.match(form.error(), /number/);
  form.apply();
  assert.equal(emitted.length, 1);
  form.reset();
  assert.equal(form.changed(), false);
  assert.equal(form.error(), '');
  assert.match(form.summary(), /Europe/);
  form.ngOnDestroy();
  root.destroy();
});
