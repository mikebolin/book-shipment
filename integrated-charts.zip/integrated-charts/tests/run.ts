import './store.test';
import './query.test';
import './architecture.test';

import './filter-values.test';
import './studio-query.test';
import './dashboard-filter.test';
import './activity-monitor.test';
import './snowflake-contract.test';
import './chart-contract.test';
import './workspace-document.test';
import './widget-view.test';
import './server-grid-settings.test';
