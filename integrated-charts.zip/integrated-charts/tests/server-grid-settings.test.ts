import test from 'node:test';
import assert from 'node:assert/strict';
import {
  SERVER_GRID_DEFAULTS,
  SERVER_GRID_LIMITS,
  normalizeServerGridSettings,
} from '../libs/charting/src/lib/core/domain/server-grid-settings';
import { configurationKey } from '../libs/charting/src/lib/studio/studio-state';

test('saved grid policy defaults legacy views and validates every bounded request/cache setting', () => {
  assert.deepEqual(normalizeServerGridSettings(), SERVER_GRID_DEFAULTS);
  assert.deepEqual(normalizeServerGridSettings({ cacheBlockSize: 100 }), {
    ...SERVER_GRID_DEFAULTS,
    cacheBlockSize: 100,
  });
  for (const [key, limits] of Object.entries(SERVER_GRID_LIMITS)) {
    for (const valid of [limits.min, limits.max])
      assert.equal(
        normalizeServerGridSettings({ [key]: valid })[key as keyof typeof SERVER_GRID_DEFAULTS],
        valid,
      );
    for (const invalid of [limits.min - 1, limits.max + 1, 1.5, NaN, Infinity, '100', null])
      assert.throws(() => normalizeServerGridSettings({ [key]: invalid } as never), /whole number/);
  }
  assert.throws(() => normalizeServerGridSettings([] as never), /object/);
  assert.throws(() => normalizeServerGridSettings('250' as never), /object/);
});

test('grid loading changes are saved user intent, independently of scrolling and preview data', () => {
  const first = { serverGrid: normalizeServerGridSettings(), gridState: {} };
  const changed = { ...first, serverGrid: normalizeServerGridSettings({ cacheBlockSize: 100 }) };
  assert.notEqual(configurationKey(first), configurationKey(changed));
  const reopened = JSON.parse(JSON.stringify(changed));
  assert.equal(configurationKey(changed), configurationKey(reopened));
});
