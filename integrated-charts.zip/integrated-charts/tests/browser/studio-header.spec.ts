import { test, expect } from '@playwright/test';

for (const width of [1440, 768, 390]) {
  test(`draft Studio keeps source context and controls compact at ${width}px`, async ({ page }) => {
    await page.setViewportSize({ width, height: 1000 });
    await page.goto('/library');
    await page
      .getByRole('link', { name: 'Open Activity volume by status and type', exact: true })
      .click();
    await page.getByRole('button', { name: 'Edit draft', exact: true }).click();
    const editor = page.locator('.studio-editor:not([hidden])');
    await expect(editor.locator('.results')).toBeVisible();
    const navigator = page.getByRole('button', { name: 'Close view navigator', exact: true });
    if (await navigator.isVisible()) await navigator.click();

    await editor.getByRole('button', { name: 'View layout', exact: true }).click();
    await page
      .getByRole('combobox', { name: 'Visible sections', exact: true })
      .selectOption('both');
    await page.getByRole('combobox', { name: 'Table position', exact: true }).selectOption('top');
    await page.keyboard.press('Escape');
    await expect(editor.locator('.grid-shell .ag-row').first()).toBeVisible();
    await expect(editor.locator('.dataset-title .model-name')).toBeVisible();
    await expect(editor.locator('.dataset-title')).toContainText('Activity monitor');
    await expect(editor.locator('.dataset-record-count')).toHaveText('60,000 records');
    await expect(
      editor.getByRole('tab', { name: 'Table and charts', exact: true }),
    ).toHaveAttribute('aria-selected', 'true');

    const geometry = await editor.evaluate((element) => {
      const rect = (selector: string) => element.querySelector(selector)!.getBoundingClientRect();
      const results = rect('.results');
      const title = rect('.dataset-title');
      const filters = rect('.filter-toolbar');
      const controls = rect('.workspace-view-controls');
      const table = rect('.grid-shell');
      const filterButtons = [...element.querySelectorAll('.filter-toolbar button')].map((button) =>
        button.getBoundingClientRect(),
      );
      return {
        sourceHeight: title.height,
        sourceBottom: title.bottom,
        controlTop: controls.top,
        filterHeight: filters.height,
        filtersContained: filterButtons.every(
          (button) => button.left >= filters.left && button.right <= filters.right,
        ),
        tableOffset: table.top - results.top,
        controlLeft: controls.left,
        controlRight: controls.right,
        resultRight: results.right,
        overflow: document.documentElement.scrollWidth > window.innerWidth,
      };
    });
    expect(geometry.sourceHeight).toBeLessThanOrEqual(60);
    expect(geometry.filterHeight).toBeLessThanOrEqual(38);
    expect(geometry.filtersContained).toBe(true);
    expect(geometry.tableOffset).toBeLessThanOrEqual(width > 900 ? 104 : 182);
    if (width <= 900) expect(geometry.sourceBottom).toBeLessThanOrEqual(geometry.controlTop);
    expect(geometry.controlLeft).toBeGreaterThanOrEqual(0);
    expect(geometry.controlRight).toBeLessThanOrEqual(geometry.resultRight);
    expect(geometry.overflow).toBe(false);
    await page.screenshot({
      path: `evidence/studio-draft-header-${width}.png`,
      animations: 'disabled',
    });

    await editor.getByRole('button', { name: 'View layout', exact: true }).click();
    await page
      .getByRole('combobox', { name: 'Visible sections', exact: true })
      .selectOption('grid');
    await page.keyboard.press('Escape');
    await expect(editor.locator('.grid-shell .ag-row').first()).toBeVisible();
    await expect(editor.locator('.dataset-record-count')).toBeVisible();
    const tableOnlyHeader = await editor.locator('.results-header').boundingBox();
    expect(tableOnlyHeader!.height).toBeLessThanOrEqual(
      width > 1050 ? 70 : width > 540 ? 120 : 180,
    );
  });
}
