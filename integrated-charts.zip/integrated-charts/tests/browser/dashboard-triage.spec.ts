import { test, expect, type Page } from '@playwright/test';

/** Open a seeded dashboard from the gallery and wait for every data tile to finish loading. */
async function openDashboard(page: Page, name: string) {
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto('/dashboards');
  await page.getByRole('link', { name: new RegExp(`^Open ${name}`) }).click();
  await expect(page.getByRole('heading', { name, level: 1 })).toBeVisible();
  await expect(page.getByTestId('filter-values-summary')).toContainText(/Started at/i, {
    timeout: 30000,
  });
  await expect(page.locator('workspace-chart-tile canvas')).toHaveCount(2, { timeout: 90000 });
  await expect(page.locator('workspace-widget-view .ag-group-value').first()).toBeVisible({
    timeout: 60000,
  });
  return errors;
}
const recordCounts = async (page: Page) =>
  (await page.locator('workspace-chart-tile .record-count').allTextContents()).map((text) =>
    Number(text.replace(/\D/g, '')),
  );
const gridCount = async (page: Page) => {
  const text = (await page.locator('workspace-widget-view').first().textContent()) ?? '';
  return Number(/([\d,]+)\s+records/.exec(text)?.[1]?.replace(/\D/g, '') ?? 0);
};

test('Failure triage: the filter controls scope the timeline, the ranked types and the server grid', async ({
  page,
}) => {
  const errors = await openDashboard(page, 'Failure triage');
  const summary = page.getByTestId('filter-values-summary');
  await expect(summary).toContainText('11:00:00');
  await expect(summary).toContainText('Breached');
  await expect(summary).toContainText('1 min buckets');
  const [timeline, ranked] = await recordCounts(page);
  expect(timeline).toBeGreaterThan(100);
  expect(timeline).toBe(ranked);
  await expect.poll(() => gridCount(page)).toBe(timeline);
  await page.screenshot({ path: 'evidence/dashboard-failure-triage.png', fullPage: true });
  // A shorter recent window narrows every element; the window control reads the bounds back.
  await page.getByLabel('Recent window').selectOption({ label: '15 minutes' });
  await expect(summary).toContainText('11:45:00');
  await expect.poll(async () => (await recordCounts(page))[0]).toBeLessThan(timeline);
  await expect.poll(() => gridCount(page)).toBeLessThan(timeline);
  // Six-second slices re-plot the same window at second resolution without changing the counts.
  const narrowed = (await recordCounts(page))[0];
  await page.getByLabel('Time buckets').selectOption({ label: '6 s' });
  await expect(summary).toContainText('6 s buckets');
  await expect(page.locator('workspace-chart-tile').first()).toContainText(
    'Failures over time · 6 s',
  );
  await expect.poll(async () => (await recordCounts(page))[0]).toBe(narrowed);
  await page.screenshot({ path: 'evidence/dashboard-failure-triage-6s.png', fullPage: true });
  // Coarser buckets re-plot the same window; the grid regroups from the grouping control.
  await page.getByLabel('Time buckets').selectOption({ label: '5 min' });
  await expect(summary).toContainText('5 min buckets');
  await expect(page.locator('workspace-chart-tile').first()).toContainText(
    'Failures over time · 5 min',
  );
  await page.getByLabel('Group grid by').selectOption({ label: 'Source system' });
  await expect(page.locator('workspace-widget-view .ag-group-value').first()).toHaveText(
    /^[A-Z ]+$/,
  );
  await page.screenshot({ path: 'evidence/dashboard-failure-triage-narrowed.png', fullPage: true });
  // The widest window reaches back twelve hours and widens every element beyond the saved hour.
  await page.getByLabel('Recent window').selectOption({ label: '12 hours' });
  await expect(summary).toContainText('2026-10-03 00:00:00');
  await expect.poll(async () => (await recordCounts(page))[0]).toBeGreaterThan(timeline);
  await expect.poll(() => gridCount(page)).toBeGreaterThan(timeline);
  // Reset returns to the saved hour, buckets and grouping.
  await page.getByTestId('dashboard-filter-reset').click();
  await expect(summary).toContainText('11:00:00');
  await expect.poll(async () => (await recordCounts(page))[0]).toBe(timeline);
  await expect(page.locator('workspace-widget-view .ag-group-value').first()).toHaveText(
    /^[A-Z][a-z]/,
  );
  expect(errors).toEqual([]);
});

test('Explore failure activity puts the grouped server grid first and toggles a status chip', async ({
  page,
}) => {
  const errors = await openDashboard(page, 'Explore failure activity');
  const summary = page.getByTestId('filter-values-summary');
  await expect(summary).toContainText('11:30:00');
  const tiles = page.locator('.grid-stack-item');
  await expect(tiles.nth(1).locator('workspace-widget-view')).toBeVisible();
  const [timeline, ranked] = await recordCounts(page);
  expect(timeline).toBeGreaterThan(50);
  expect(timeline).toBe(ranked);
  await page.screenshot({
    path: 'evidence/dashboard-explore-failure-activity.png',
    fullPage: true,
  });
  // Deselecting a status chip removes it from the shared filter and shrinks every count.
  await page.getByRole('button', { name: 'Breached', exact: true }).click();
  await expect(summary).not.toContainText('Breached');
  await expect.poll(async () => (await recordCounts(page))[0]).toBeLessThan(timeline);
  await page.getByTestId('dashboard-filter-reset').click();
  await expect(summary).toContainText('Breached');
  expect(errors).toEqual([]);
});
