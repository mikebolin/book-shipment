﻿import { test, expect, type Page, type Locator } from '@playwright/test';

async function studio(page: Page) {
  await page.goto('/studio/activity-monitor');
  await expect(page.locator('.studio-editor:not([hidden]) .ag-row').first()).toBeVisible();
  const close = page.getByRole('button', { name: 'Close view navigator', exact: true });
  if (await close.isVisible()) await close.click();
}
async function hit(locator: Locator) {
  await expect
    .poll(() =>
      locator.evaluate((n) => {
        const b = n.getBoundingClientRect();
        return n.contains(document.elementFromPoint(b.x + b.width / 2, b.y + b.height / 2));
      }),
    )
    .toBe(true);
}
async function editStatus(
  container: Locator,
  page: Page,
  status = 'Failed',
  columnName = 'Execution status',
) {
  const column = container
    .getByRole('combobox', { name: 'Choose filter column', exact: true })
    .last();
  await column.fill(columnName);
  const choice = page.getByRole('option').filter({ hasText: columnName }).first();
  await hit(choice);
  const popup = await choice.evaluate((node) => {
    const box = node.closest('[role="listbox"]')!.getBoundingClientRect();
    return { left: box.left, right: box.right, width: box.width };
  });
  const viewportWidth = page.viewportSize()!.width;
  expect(popup.left).toBeGreaterThanOrEqual(0);
  expect(popup.right).toBeLessThanOrEqual(viewportWidth);
  if (viewportWidth >= 700) expect(popup.width).toBeGreaterThanOrEqual(360);
  await choice.click();
  await container
    .getByRole('textbox', { name: 'Condition value', exact: true })
    .last()
    .fill(status);
}
async function tableCount(page: Page) {
  const text = await page
    .locator('.studio-editor:not([hidden]) .dataset-record-count')
    .textContent();
  return Number(text?.replace(/\D/g, ''));
}
async function sameLine(row: Locator) {
  const geometry = await row.locator('.rule-fields').evaluate((node) => {
    const fields = [
      'input[aria-label="Choose filter column"]',
      '[aria-label="Condition operator"]',
      'input[aria-label="Condition value"]',
    ].map((selector) => node.querySelector<HTMLElement>(selector)!.getBoundingClientRect());
    return {
      centers: fields.map((field) => field.y + field.height / 2),
      lefts: fields.map((field) => field.x),
    };
  });
  expect(Math.max(...geometry.centers) - Math.min(...geometry.centers)).toBeLessThan(4);
  expect(geometry.lefts[0]).toBeLessThan(geometry.lefts[1]);
  expect(geometry.lefts[1]).toBeLessThan(geometry.lefts[2]);
}

test('table filters are compact inline rows; Cancel preserves data and Apply commits direct edits', async ({
  page,
}) => {
  await studio(page);
  const original = await tableCount(page);
  await page.getByRole('button', { name: 'Advanced filters', exact: true }).click();
  let dialog = page.getByRole('dialog', { name: 'Activity monitor', exact: true });
  await expect(dialog.locator('ag-grid-angular')).toHaveCount(0);
  await expect(dialog.locator('.condition-row, .nested-group')).toHaveCount(0);
  await expect(dialog.getByRole('textbox', { name: 'Filter expression', exact: true })).toHaveCount(
    0,
  );
  await expect(dialog.getByRole('button', { name: 'Apply changes', exact: true })).toBeDisabled();
  await page.screenshot({ path: 'evidence/filter-focus-empty.png', animations: 'disabled' });
  await dialog.getByRole('button', { name: 'Add filter', exact: true }).click();
  await expect(dialog.getByRole('button', { name: 'Apply changes', exact: true })).toBeDisabled();
  await editStatus(dialog, page);
  await sameLine(dialog.locator('.condition-row'));
  const selectedColumn = dialog.getByRole('combobox', {
    name: 'Choose filter column',
    exact: true,
  });
  await selectedColumn.click();
  await page.getByRole('option').filter({ hasText: 'Execution status' }).first().click();
  await expect(dialog.getByRole('textbox', { name: 'Condition value', exact: true })).toHaveValue(
    'Failed',
  );
  await expect(dialog.getByRole('button', { name: /(?:Expand|Collapse) condition:/ })).toHaveCount(
    0,
  );
  await expect(dialog.getByRole('button', { name: 'Apply changes', exact: true })).toBeEnabled();
  await page.screenshot({ path: 'evidence/filter-focus-table.png', animations: 'disabled' });
  await dialog.getByRole('button', { name: 'Cancel', exact: true }).click();
  expect(await tableCount(page)).toBe(original);
  await page.getByRole('button', { name: 'Advanced filters', exact: true }).click();
  dialog = page.getByRole('dialog', { name: 'Activity monitor', exact: true });
  await dialog.getByRole('button', { name: 'Add filter', exact: true }).click();
  await editStatus(dialog, page);
  await dialog.getByRole('button', { name: 'Apply changes', exact: true }).click();
  await expect.poll(() => tableCount(page)).toBeLessThan(original);
  const filtered = await tableCount(page);
  expect(filtered).toBeGreaterThan(0);
  await page.getByRole('button', { name: 'Advanced filters', exact: true }).click();
  dialog = page.getByRole('dialog', { name: 'Activity monitor', exact: true });
  await expect(
    dialog.getByRole('combobox', { name: 'Choose filter column', exact: true }),
  ).toHaveValue('Execution status');
  await expect(dialog.getByRole('textbox', { name: 'Condition value', exact: true })).toBeVisible();
  await sameLine(dialog.locator('.condition-row'));
  await expect(dialog.getByRole('button', { name: 'Apply changes', exact: true })).toBeDisabled();
  await dialog.getByRole('button', { name: 'Remove filter', exact: true }).click();
  await dialog.getByRole('button', { name: 'Apply changes', exact: true }).click();
  await expect.poll(() => tableCount(page)).toBe(original);
});

test('nested groups clearly preserve OR logic and expose direct add and remove actions', async ({
  page,
}) => {
  await studio(page);
  await page.getByRole('button', { name: 'Advanced filters', exact: true }).click();
  let dialog = page.getByRole('dialog', { name: 'Activity monitor', exact: true });
  await dialog.getByRole('button', { name: 'Add group', exact: true }).click();
  const group = dialog.locator('.nested-group').first();
  await group.getByRole('combobox', { name: 'Join conditions', exact: true }).click();
  await page.getByRole('option', { name: 'Any filter (OR)', exact: true }).click();
  await editStatus(group, page);
  await group.getByRole('button', { name: 'Add filter', exact: true }).click();
  await expect(group.locator('.condition-row')).toHaveCount(2);
  await editStatus(group, page, 'Breached');
  await dialog.getByRole('button', { name: 'Add filter', exact: true }).first().click();
  const rootCondition = dialog.locator(
    '.filter-tree > .filter-group > .group-content > .group-conditions > .filter-node > .condition-row',
  );
  await expect(rootCondition).toHaveCount(1);
  await editStatus(rootCondition, page, 'Ingestion', 'Activity type');
  await dialog.getByRole('button', { name: 'Apply changes', exact: true }).click();
  await page.getByRole('button', { name: 'Advanced filters', exact: true }).click();
  dialog = page.getByRole('dialog', { name: 'Activity monitor', exact: true });
  await expect(dialog.locator('.group-caption')).toContainText('Any filter (OR)');
  await expect(dialog.locator('.group-caption')).toContainText('2 filters');
  await expect(dialog.locator('.nested-group .group-content')).toBeHidden();
  await page.screenshot({ path: 'evidence/filter-focus-hierarchy.png', animations: 'disabled' });
  await dialog.getByRole('button', { name: 'Expand Group 1', exact: true }).click();
  await expect(
    dialog.locator('.nested-group').getByRole('textbox', { name: 'Condition value', exact: true }),
  ).toHaveCount(2);
  await sameLine(dialog.locator('.nested-group .condition-row').first());
  await expect(dialog.getByRole('button', { name: /(?:Expand|Collapse) condition:/ })).toHaveCount(
    0,
  );
  await dialog.getByRole('button', { name: 'Remove filter', exact: true }).last().click();
  await dialog.getByRole('button', { name: 'Remove group', exact: true }).click();
  await expect(dialog.locator('.nested-group')).toHaveCount(0);
  await dialog.getByRole('button', { name: 'Cancel', exact: true }).click();
});

test('published filters remain inspectable as a hierarchy without a blank editor or preview', async ({
  page,
}) => {
  await page.goto('/dashboards');
  await page.getByRole('link', { name: 'Open Explore failure activity', exact: true }).click();
  const tile = page.locator('workspace-widget-view').first();
  await expect(tile.locator('.ag-row').first()).toBeVisible();
  await tile.locator('workspace-filter-scope-chip button').first().click();
  const dialog = page.getByRole('dialog').last();
  await expect(dialog.locator('.condition-row')).toHaveCount(4);
  await expect(dialog.locator('ag-grid-angular, app-integrated-chart')).toHaveCount(0);
  await expect(dialog.getByRole('button', { name: 'Add filter', exact: true })).toHaveCount(0);
  await expect(dialog.getByRole('button', { name: 'Apply changes', exact: true })).toHaveCount(0);
  await page.screenshot({
    path: 'evidence/filter-focus-readonly-collapsed.png',
    animations: 'disabled',
  });
  await dialog.getByRole('button', { name: 'Expand Group 1', exact: true }).click();
  await expect(dialog.locator('.nested-group')).toContainText('Execution status');
  await page.screenshot({ path: 'evidence/filter-focus-readonly.png', animations: 'disabled' });
  await dialog.getByRole('button', { name: 'Done', exact: true }).click();
});

test('date and datetime filters keep all three fields inline and preserve calendar and UTC bounds on Apply', async ({
  page,
}) => {
  await studio(page);
  const original = await tableCount(page);
  await page.getByRole('button', { name: 'Advanced filters', exact: true }).click();
  let dialog = page.getByRole('dialog', { name: 'Activity monitor', exact: true });
  await dialog.getByRole('button', { name: 'Add filter', exact: true }).click();
  await editStatus(dialog, page, '10/03/2026', 'Business date');
  await dialog.getByRole('textbox', { name: 'Condition value', exact: true }).press('Tab');
  await sameLine(dialog.locator('.condition-row'));
  await expect(dialog.getByRole('button', { name: 'Apply changes', exact: true })).toBeEnabled();
  await dialog.getByRole('button', { name: 'Apply changes', exact: true }).click();
  await expect.poll(() => tableCount(page)).toBeLessThan(original);
  expect(await tableCount(page)).toBeGreaterThan(0);
  await page.getByRole('button', { name: 'Advanced filters', exact: true }).click();
  dialog = page.getByRole('dialog', { name: 'Activity monitor', exact: true });
  await expect(
    dialog.getByRole('combobox', { name: 'Choose filter column', exact: true }),
  ).toHaveValue('Business date');
  await expect(dialog.getByRole('textbox', { name: 'Condition value', exact: true })).toHaveValue(
    /10\/3\/2026/,
  );
  await dialog.getByRole('button', { name: 'Clear all', exact: true }).click();
  await dialog.getByRole('button', { name: 'Add filter', exact: true }).click();
  await editStatus(dialog, page, '2026-10-03T11:00:00Z', 'Started at (UTC)');
  let row = dialog.locator('.condition-row').first();
  await row.getByRole('combobox', { name: 'Condition operator', exact: true }).click();
  await page.getByRole('option', { name: 'On or after', exact: true }).click();
  await sameLine(row);
  await dialog.getByRole('button', { name: 'Add filter', exact: true }).click();
  await expect(dialog.locator('.condition-row')).toHaveCount(2);
  row = dialog.locator('.condition-row').last();
  await editStatus(row, page, '2026-10-03T12:00:00Z', 'Started at (UTC)');
  await row.getByRole('combobox', { name: 'Condition operator', exact: true }).click();
  await page.getByRole('option', { name: 'Before', exact: true }).click();
  await sameLine(row);
  await page.screenshot({
    path: 'evidence/filter-focus-inline-datetime.png',
    animations: 'disabled',
  });
  await dialog.getByRole('button', { name: 'Apply changes', exact: true }).click();
  await expect.poll(() => tableCount(page)).toBeLessThan(original);
  expect(await tableCount(page)).toBeGreaterThan(0);
  await page.getByRole('button', { name: 'Advanced filters', exact: true }).click();
  dialog = page.getByRole('dialog', { name: 'Activity monitor', exact: true });
  await expect(dialog.getByRole('textbox', { name: 'Condition value', exact: true })).toHaveCount(
    2,
  );
  await expect(
    dialog.getByRole('textbox', { name: 'Condition value', exact: true }).first(),
  ).toHaveValue(/2026-10-03.*11:00:00/);
  await expect(
    dialog.getByRole('textbox', { name: 'Condition value', exact: true }).last(),
  ).toHaveValue(/2026-10-03.*12:00:00/);
  await expect(dialog.getByRole('button', { name: 'Expand all groups', exact: true })).toHaveCount(
    0,
  );
  await dialog.getByRole('button', { name: 'Cancel', exact: true }).click();
});

test('optional expressions keep suggestions above nested dialogs and validate before Apply', async ({
  page,
}) => {
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await studio(page);
  await page.getByRole('button', { name: 'Explorer tools', exact: true }).click();
  await page.getByRole('menuitem', { name: 'Filters overview', exact: true }).click();
  const overview = page.getByRole('dialog', { name: 'Filters overview', exact: true });
  await overview.locator('workspace-filter-scope-chip button').first().click();
  const dialog = page.getByRole('dialog', { name: 'Table', exact: true });
  await dialog.getByRole('button', { name: 'Edit expression', exact: true }).click();
  const input = dialog.getByRole('textbox', { name: 'Filter expression', exact: true });
  await input.fill('Execution');
  const option = page
    .locator('.ag-autocomplete-row')
    .filter({ hasText: 'Execution status' })
    .first();
  await hit(option);
  await option.click();
  await input.fill('[Execution status] equals "Failed"');
  await dialog.getByRole('button', { name: 'Use expression', exact: true }).click();
  await expect(dialog.getByRole('button', { name: 'Apply changes', exact: true })).toBeEnabled();
  await input.fill('Source');
  const source = page.locator('.ag-autocomplete-row').filter({ hasText: 'Source system' }).first();
  await hit(source);
  await page.screenshot({ path: 'evidence/filter-expression-popup.png', animations: 'disabled' });
  await expect(dialog.getByRole('button', { name: 'Apply changes', exact: true })).toBeDisabled();
  await dialog.getByRole('button', { name: 'Use filter builder', exact: true }).click();
  await expect(
    dialog.getByRole('combobox', { name: 'Choose filter column', exact: true }),
  ).toHaveValue('Execution status');
  await expect(dialog.getByRole('textbox', { name: 'Condition value', exact: true })).toBeVisible();
  await expect(dialog.getByRole('button', { name: 'Apply changes', exact: true })).toBeEnabled();
  await dialog.getByRole('button', { name: 'Cancel', exact: true }).click();
  await expect(overview).toBeVisible();
  await overview.getByRole('button', { name: 'Done', exact: true }).click();
  expect(errors).toEqual([]);
});

test('compact filters scroll horizontally on a narrow screen while remove and Apply remain reachable', async ({
  page,
}) => {
  await studio(page);
  await page.setViewportSize({ width: 390, height: 844 });
  await page.getByRole('button', { name: 'Advanced filters', exact: true }).click();
  const dialog = page.getByRole('dialog', { name: 'Activity monitor', exact: true });
  await dialog.getByRole('button', { name: 'Add filter', exact: true }).click();
  await editStatus(dialog, page);
  const fields = dialog.locator('.rule-fields');
  expect(await fields.evaluate((n) => n.scrollWidth > n.clientWidth)).toBe(true);
  expect(await dialog.evaluate((n) => n.scrollWidth <= n.clientWidth + 2)).toBe(true);
  await sameLine(dialog.locator('.condition-row'));
  await dialog
    .getByRole('textbox', { name: 'Condition value', exact: true })
    .scrollIntoViewIfNeeded();
  await hit(dialog.getByRole('textbox', { name: 'Condition value', exact: true }));
  await hit(dialog.getByRole('button', { name: 'Remove filter', exact: true }));
  await hit(dialog.getByRole('button', { name: 'Apply changes', exact: true }));
  await page.screenshot({ path: 'evidence/mobile-filter-focus.png', animations: 'disabled' });
  await dialog.getByRole('button', { name: 'Cancel', exact: true }).click();
});
