import { test, expect, type Page } from '@playwright/test';

async function openDashboard(page: Page, name: string) {
  await page.goto('/dashboards');
  await page.getByRole('link', { name: `Open ${name}`, exact: true }).click();
  await expect(page.getByRole('heading', { name, level: 1 })).toBeVisible();
}

test('dashboard creation edits Material tag chips and keeps metadata in the draft gallery', async ({
  page,
}) => {
  test.setTimeout(120000);
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await page.goto('/dashboards');
  await page.getByRole('button', { name: 'Create dashboard', exact: true }).click();
  const dialog = page.getByRole('dialog', { name: 'Create dashboard', exact: true });
  await dialog.getByLabel('Name', { exact: true }).fill('Activity workspace');
  await dialog
    .getByLabel('Description', { exact: true })
    .fill('Activity investigation for Operations.');
  await dialog.getByLabel('Group', { exact: true }).fill('Operations');
  const tagInput = dialog.getByLabel('Add dashboard tag', { exact: true });
  await tagInput.fill('Triage');
  await tagInput.press('Enter');
  await tagInput.fill('Temporary');
  await tagInput.press(',');
  await tagInput.fill('triage');
  await tagInput.press('Enter');
  await expect(dialog.locator('mat-chip-row')).toHaveCount(2);
  const first = dialog.locator('mat-chip-row').filter({ hasText: 'Triage' });
  await first.locator('.mdc-evolution-chip__text-label').dblclick();
  await first.getByRole('textbox').fill('Activity');
  await first.getByRole('textbox').press('Enter');
  await dialog.getByRole('button', { name: 'Remove tag Temporary', exact: true }).click();
  await tagInput.fill('Operations');
  await tagInput.press('Enter');
  await expect(dialog.locator('mat-chip-row .mdc-evolution-chip__text-label')).toHaveText([
    'Activity',
    'Operations',
  ]);
  await dialog.getByRole('button', { name: 'Create dashboard', exact: true }).click();
  await expect(page.locator('.dashboard-title')).toHaveValue('Activity workspace');
  await page.getByRole('link', { name: 'Back to dashboards', exact: true }).click();
  await page.getByRole('button', { name: 'Drafts', exact: true }).click();
  const card = page
    .locator('workspace-resource-card')
    .filter({ has: page.getByRole('heading', { name: 'Activity workspace', exact: true }) });
  await expect(card).toContainText('Activity investigation for Operations.');
  await expect(card.getByRole('button', { name: 'Activity', exact: true })).toBeVisible();
  await expect(card.getByRole('button', { name: 'Operations', exact: true })).toBeVisible();
  await expect(card).not.toContainText('Temporary');
  expect(errors).toEqual([]);
});

test('dashboard gallery uses compact chart-type SVG previews without downloading datasets', async ({
  page,
}) => {
  const snapshots: string[] = [];
  page.on('request', (request) => {
    if (/activity-monitor.*ndjson/.test(request.url())) snapshots.push(request.url());
  });
  await page.goto('/dashboards');
  const card = page
    .locator('workspace-resource-card')
    .filter({ has: page.getByRole('heading', { name: 'Operations monitor', exact: true }) });
  await expect(card.locator('workspace-resource-preview')).toHaveAttribute(
    'data-preview-kind',
    'chart',
  );
  await expect(card.locator('workspace-resource-preview')).toHaveAttribute(
    'data-chart-type',
    'bar',
  );
  await expect(card.locator('svg')).toHaveCount(1);
  await expect(
    page.locator(
      'workspace-resource-card canvas, workspace-resource-card img, workspace-resource-card ag-grid-angular',
    ),
  ).toHaveCount(0);
  const size = await card.boundingBox();
  expect(size!.width).toBeLessThan(360);
  expect(size!.height).toBeLessThan(410);
  const preview = await card.locator('.card-preview').boundingBox();
  expect(preview!.width / preview!.height).toBeCloseTo(320 / 152, 1);
  expect(preview!.height).toBeLessThan(180);
  expect(snapshots).toHaveLength(0);
});

test('Studio Both mode gives the table full space when there are no saved charts', async ({
  page,
}) => {
  await page.goto('/studio/activity-monitor');
  await expect(page.getByTestId('server-cache-rows')).toHaveText('250 loaded', { timeout: 60000 });
  const close = page.getByRole('button', { name: 'Close view navigator', exact: true });
  if (await close.isVisible()) await close.click();
  await page.getByRole('tab', { name: 'Table and charts', exact: true }).click();
  const editor = page.locator('.studio-editor:not([hidden])');
  await expect(editor.locator('.chart-explorer')).toHaveCount(0);
  await expect(editor.locator('.results')).not.toHaveClass(/combined-view/);
  await expect(editor.locator('.grid-shell .ag-row').first()).toBeVisible();
  const table = await editor.locator('.grid-shell').boundingBox();
  expect(table!.y).toBeLessThan(400);
  expect(table!.height).toBeGreaterThan(400);
});

test('dashboard views have one header per chart and table with a pinned source link', async ({
  page,
}) => {
  test.setTimeout(120000);
  const errors: string[] = [];
  const snapshots: string[] = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.on('request', (request) => {
    if (/activity-monitor.*ndjson/.test(request.url())) snapshots.push(request.url());
  });
  await openDashboard(page, 'Operations monitor');
  const tiles = page
    .locator('.grid-stack-item')
    .filter({ has: page.locator('workspace-widget-view') });
  await expect(tiles).toHaveCount(2);
  await expect(page.locator('workspace-widget-view canvas')).toHaveCount(2);
  await expect(page.locator('.data-tile > .tile-heading')).toHaveCount(0);
  await expect(page.locator('workspace-chart-carousel')).toHaveCount(0);
  for (let index = 0; index < 2; index++) {
    const tile = tiles.nth(index);
    await expect(tile.locator('workspace-widget-view .scope-header')).toHaveCount(2);
    await expect(tile.getByRole('button', { name: 'View source', exact: true })).toHaveCount(1);
    const tableName = (await tile.locator('.table-header strong').textContent())!.trim();
    await tile.getByRole('button', { name: 'View source', exact: true }).click();
    await expect(page.locator('.source-details strong')).toHaveText(tableName);
    await expect(page.locator('.source-details')).toContainText(
      'Activity monitor - published revision 1',
    );
    await expect(
      page.getByRole('menuitem', { name: 'Open source view', exact: true }),
    ).toHaveAttribute('href', /^\/views\//);
    await page.keyboard.press('Escape');
    await tile.getByRole('button', { name: 'Show chart', exact: true }).click();
    await expect(tile.locator('workspace-widget-view .scope-header')).toHaveCount(1);
    await expect(tile.getByRole('button', { name: 'View source', exact: true })).toBeVisible();
    await tile.getByRole('button', { name: 'Show grid', exact: true }).click();
    await expect(tile.locator('workspace-widget-view .scope-header')).toHaveCount(1);
    await expect(tile.locator('.ag-row').first()).toBeVisible();
    await expect(tile.getByRole('button', { name: 'View source', exact: true })).toBeVisible();
    await tile.getByRole('button', { name: 'Show chart and table', exact: true }).click();
    await expect(tile.locator('workspace-widget-view .scope-header')).toHaveCount(2);
  }
  expect(snapshots).toHaveLength(1);
  expect(errors).toEqual([]);
});

test('dashboard authors configure and separate a whole view from its integrated header', async ({
  page,
}) => {
  test.setTimeout(120000);
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await openDashboard(page, 'Operations monitor');
  await page.getByRole('link', { name: 'Edit dashboard', exact: true }).click();
  const tile = page
    .locator('.grid-stack-item')
    .filter({ has: page.locator('workspace-widget-view') })
    .first();
  await expect(tile.locator('canvas')).toHaveCount(1);
  const sourceName = (await tile.locator('.table-header strong').textContent())!.trim();
  const sourceChartId = await tile.locator('[data-chart-id]').first().getAttribute('data-chart-id');
  await tile.getByRole('button', { name: 'Configure view', exact: true }).click();
  const dialog = page.getByRole('dialog', { name: 'Configure dashboard view', exact: true });
  await expect(dialog).toContainText(sourceName);
  await dialog.getByLabel('View title', { exact: true }).fill('Activity detail');
  await dialog.getByRole('button', { name: 'Apply view settings', exact: true }).click();
  await expect(tile.locator('.table-header strong')).toHaveText('Activity detail');
  await tile.getByRole('button', { name: 'Element actions', exact: true }).click();
  await page.getByRole('menuitem', { name: 'Separate charts and table', exact: true }).click();
  const separateTiles = page
    .locator('.grid-stack-item')
    .filter({ has: page.locator('workspace-chart-tile, workspace-table-tile') });
  await expect(separateTiles).toHaveCount(2);
  await expect(page.locator('workspace-chart-tile')).toHaveCount(1);
  await expect(page.locator('workspace-table-tile')).toHaveCount(1);
  await expect(page.locator('workspace-chart-tile')).toHaveAttribute(
    'data-chart-id',
    sourceChartId!,
  );
  for (let index = 0; index < 2; index++) {
    const separate = separateTiles.nth(index);
    await expect(separate.locator('.scope-header')).toHaveCount(1);
    await expect(separate.locator('.tile-heading')).toHaveCount(0);
    await separate.getByRole('button', { name: 'View source', exact: true }).click();
    await expect(page.locator('.source-details strong')).toHaveText(sourceName);
    await expect(page.locator('.source-details')).toContainText('published revision 1');
    await page.keyboard.press('Escape');
    await separate.getByRole('button', { name: 'Element actions', exact: true }).click();
    await expect(
      page.getByRole('menuitem', { name: 'Edit element settings', exact: true }),
    ).toBeVisible();
    await page.keyboard.press('Escape');
  }
  await page.getByRole('button', { name: 'Save layout', exact: true }).click();
  await expect(page.locator('.workspace-notice')).toContainText('Saved layout');
  expect(errors).toEqual([]);
});

test('authors manage filter controls and their defaults survive save and reopen', async ({
  page,
}) => {
  test.setTimeout(120000);
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await openDashboard(page, 'Explore failure activity');
  await page.getByRole('link', { name: 'Edit dashboard', exact: true }).click();
  await page.getByRole('button', { name: 'Configure filter controls', exact: true }).click();
  const dialog = page.getByRole('dialog', { name: 'Filter controls', exact: true });
  const cards = dialog.locator('.control-card');
  await expect(cards).toHaveCount(5);
  await expect(dialog.locator('.control-card[open]')).toHaveCount(0);
  await dialog.getByLabel('Filter controls title', { exact: true }).fill('Shared controls');
  await cards.nth(0).locator('summary').click();
  await cards
    .nth(0)
    .getByLabel('Default window', { exact: true })
    .selectOption({ label: '15 minutes' });
  await cards.nth(1).locator('summary').click();
  await cards
    .nth(1)
    .getByLabel('Default bucket', { exact: true })
    .selectOption({ label: '6 seconds' });
  await cards.nth(3).locator('summary').click();
  await cards.nth(3).getByLabel('Default selections', { exact: true }).fill('Failed');
  await cards.nth(4).locator('summary').click();
  await cards
    .nth(4)
    .getByLabel('Default grouping', { exact: true })
    .selectOption({ label: 'No grouping' });
  await dialog.getByRole('button', { name: 'Apply filter control settings', exact: true }).click();
  await expect(dialog).toBeHidden();
  const summary = page.getByTestId('filter-values-summary');
  await expect(summary).toContainText('11:45:00');
  await expect(summary).toContainText('6 s buckets');
  await expect(summary).toContainText('no grouping');
  await expect(summary).not.toContainText('Breached');
  await page.getByRole('button', { name: 'Save layout', exact: true }).click();
  await expect(page.locator('.workspace-notice')).toContainText('Saved layout');
  await page.getByRole('link', { name: 'Back to dashboards', exact: true }).click();
  await page.getByRole('link', { name: 'Open Explore failure activity', exact: true }).click();
  await expect(
    page.getByRole('heading', { name: 'Explore failure activity', level: 1 }),
  ).toBeVisible();
  await page.getByRole('link', { name: 'Edit dashboard', exact: true }).click();
  await page.getByRole('button', { name: 'Configure filter controls', exact: true }).click();
  await expect(dialog.getByLabel('Filter controls title', { exact: true })).toHaveValue(
    'Shared controls',
  );
  await cards.nth(4).locator('summary').click();
  await expect(cards.nth(4).getByLabel('Default grouping', { exact: true })).toHaveValue('');
  await dialog.getByRole('button', { name: 'Cancel', exact: true }).click();
  await expect(summary).toContainText('6 s buckets');
  await expect(page.locator('workspace-widget-view .ag-group-value')).toHaveCount(0);
  const chartTile = page
    .locator('.grid-stack-item')
    .filter({ has: page.locator('workspace-chart-tile') })
    .first();
  await chartTile.getByRole('button', { name: 'Element actions', exact: true }).click();
  await page.getByRole('menuitem', { name: 'Edit element settings', exact: true }).click();
  const chartSettings = page.getByRole('dialog', { name: 'Element settings', exact: true });
  await expect(
    chartSettings.getByRole('checkbox', { name: 'Click chart to filter dashboard', exact: true }),
  ).toBeChecked();
  await chartSettings
    .getByRole('checkbox', { name: 'Click chart to filter dashboard', exact: true })
    .uncheck();
  await chartSettings.getByRole('button', { name: 'Apply element settings', exact: true }).click();
  await chartTile.getByRole('button', { name: 'Element actions', exact: true }).click();
  await page.getByRole('menuitem', { name: 'Edit element settings', exact: true }).click();
  await expect(
    chartSettings.getByRole('checkbox', { name: 'Click chart to filter dashboard', exact: true }),
  ).not.toBeChecked();
  await chartSettings.getByRole('button', { name: 'Cancel element changes', exact: true }).click();
  expect(errors).toEqual([]);
});

test('a single chart breaks out in place with the same chart and source scope', async ({
  page,
}) => {
  test.setTimeout(120000);
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await openDashboard(page, 'Operations monitor');
  await page.getByRole('link', { name: 'Edit dashboard', exact: true }).click();
  const tile = page
    .locator('.grid-stack-item')
    .filter({ has: page.locator('workspace-widget-view') })
    .first();
  await expect(tile.locator('canvas')).toHaveCount(1);
  const id = (await tile.getAttribute('gs-id'))!;
  const geometry = await tile.evaluate((element) =>
    ['gs-x', 'gs-y', 'gs-w', 'gs-h'].map((name) => element.getAttribute(name)),
  );
  const chartId = await tile.locator('[data-chart-id]').first().getAttribute('data-chart-id');
  const count = await tile.locator('.chart-card-content .record-count').first().textContent();
  const numberOfTiles = await page.locator('.grid-stack-item').count();
  await tile.getByRole('button', { name: 'Element actions', exact: true }).click();
  await page.getByRole('menuitem', { name: 'Break out chart', exact: true }).click();
  const brokenOut = page.locator(`[gs-id="${id}"]`);
  await expect(brokenOut.locator('workspace-chart-tile canvas')).toHaveCount(1);
  await expect(brokenOut.locator('workspace-chart-tile')).toHaveAttribute(
    'data-chart-id',
    chartId!,
  );
  await expect(brokenOut.locator('workspace-chart-tile .record-count')).toHaveText(count!);
  await expect(brokenOut.locator('workspace-widget-view, workspace-table-tile')).toHaveCount(0);
  await expect(page.locator('.grid-stack-item')).toHaveCount(numberOfTiles);
  expect(
    await brokenOut.evaluate((element) =>
      ['gs-x', 'gs-y', 'gs-w', 'gs-h'].map((name) => element.getAttribute(name)),
    ),
  ).toEqual(geometry);
  await expect(
    page.getByRole('button', { name: 'Download chart as PNG', exact: true }),
  ).toHaveCount(0);
  await expect(page.getByRole('button', { name: 'Download all', exact: true })).toHaveCount(1);
  expect(errors).toEqual([]);
});

test('a dashboard can adopt a newer published view including its column highlight', async ({
  page,
}) => {
  test.setTimeout(180000);
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(error.message));
  const sourceName = 'Breached activities by source and type';
  await page.goto('/library');
  await page.getByRole('link', { name: `Open ${sourceName}`, exact: true }).click();
  await page.getByRole('button', { name: 'Edit draft', exact: true }).click();
  const close = page.getByRole('button', { name: 'Close view navigator', exact: true });
  if (await close.isVisible()) await close.click();
  const header = page
    .locator('.studio-editor:not([hidden]) .ag-header-cell[col-id="name"]')
    .first();
  await expect(header).toBeVisible();
  await header.hover();
  await header.locator('.ag-header-cell-menu-button').click();
  await page.getByRole('menuitem', { name: 'Highlight column', exact: true }).click();
  await expect(header).toHaveClass(/explorer-column-highlight-1/);
  await page.getByRole('button', { name: `Rename ${sourceName}`, exact: true }).click();
  await page.getByLabel('View name', { exact: true }).fill('Updated breach view');
  await page.getByLabel('View name', { exact: true }).press('Enter');
  await page.getByRole('button', { name: 'Publish', exact: true }).click();
  const confirmation = page.getByRole('dialog');
  await expect(confirmation).toBeVisible();
  await confirmation.getByRole('button', { name: 'Publish', exact: true }).click();
  await expect(page.locator('.studio-status-chip')).toContainText('Published');
  await page.getByRole('link', { name: 'Dashboards', exact: true }).click();
  await page.getByRole('link', { name: 'Open Operations monitor', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'Operations monitor', level: 1 })).toBeVisible();
  await page.getByRole('link', { name: 'Edit dashboard', exact: true }).click();
  const tile = page.locator('.grid-stack-item').filter({ hasText: sourceName }).first();
  await expect(tile.locator('.ag-header-cell[col-id="name"]')).toBeVisible();
  await expect(tile.locator('.ag-header-cell[col-id="name"]')).not.toHaveClass(
    /explorer-column-highlight-1/,
  );
  await tile.getByRole('button', { name: 'Element actions', exact: true }).click();
  await page
    .getByRole('menuitem', { name: 'Update to latest published view', exact: true })
    .click();
  const updated = page
    .locator('.grid-stack-item')
    .filter({ hasText: 'Updated breach view' })
    .first();
  await expect(updated.locator('.ag-header-cell[col-id="name"]')).toHaveClass(
    /explorer-column-highlight-1/,
  );
  await expect(page.locator('.workspace-notice')).toContainText(
    'Dashboard settings and placement are preserved',
  );
  expect(errors).toEqual([]);
});
