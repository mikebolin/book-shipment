﻿import { test, expect } from '@playwright/test';

test('values-only permissions offer one dialog Apply and preserve the saved scope for dashboard imports', async ({
  page,
}) => {
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto('/library');
  await page
    .getByRole('link', { name: 'Open Activity volume by status and type', exact: true })
    .click();
  await page.getByRole('button', { name: 'Edit draft', exact: true }).click();
  const close = page.getByRole('button', { name: 'Close view navigator', exact: true });
  if (await close.isVisible()) await close.click();
  const chart = page.locator('.studio-editor:not([hidden]) app-saved-chart').first();
  await chart.locator('workspace-filter-scope-chip button').click();
  let dialog = page.getByRole('dialog').last();
  await dialog.getByRole('button', { name: 'Edit expression', exact: true }).click();
  await dialog
    .getByRole('textbox', { name: 'Filter expression', exact: true })
    .fill('[Execution status] equals "Failed"');
  await dialog.getByRole('button', { name: 'Use expression', exact: true }).click();
  await dialog.getByRole('button', { name: 'Apply changes', exact: true }).click();
  await page.getByRole('button', { name: 'View actions', exact: true }).click();
  await page.getByRole('menuitem', { name: 'View settings', exact: true }).click();
  dialog = page.getByRole('dialog', { name: 'View settings', exact: true });
  await dialog.getByRole('tab', { name: 'Reader experience', exact: true }).click();
  await dialog.getByRole('combobox', { name: 'What readers can change', exact: true }).click();
  await page.getByRole('option', { name: 'Values only', exact: true }).click();
  await dialog.getByRole('button', { name: 'Apply settings', exact: true }).click();
  await expect(chart.locator('workspace-filter-values-form')).toBeVisible();
  await page.getByRole('button', { name: 'Publish', exact: true }).click();
  dialog = page.getByRole('dialog');
  await expect(dialog).toBeVisible();
  await dialog.getByRole('button', { name: 'Publish', exact: true }).click();
  const view = page.locator('workspace-widget-view').first();
  const form = view.locator('workspace-filter-values-form');
  await expect(form).toBeVisible();
  const chartCount = view.locator('.chart-card-content .record-count').first();
  const initial = await chartCount.textContent();
  await view.locator('.chart-card-content workspace-filter-scope-chip button').first().click();
  dialog = page.getByRole('dialog').last();
  await expect(dialog.getByRole('button', { name: 'Add filter', exact: true })).toHaveCount(0);
  await expect(dialog.getByRole('button', { name: 'Edit expression', exact: true })).toHaveCount(0);
  await expect(dialog.getByRole('button', { name: 'Apply changes', exact: true })).toHaveCount(1);
  const modalValue = dialog.getByLabel('Execution status filter value', { exact: true });
  await modalValue.selectOption({ label: 'Breached' });
  await expect(dialog.getByRole('button', { name: 'Apply changes', exact: true })).toBeEnabled();
  await dialog.getByRole('button', { name: 'Cancel', exact: true }).click();
  await expect(chartCount).toHaveText(initial!);
  await view.locator('.chart-card-content workspace-filter-scope-chip button').first().click();
  dialog = page.getByRole('dialog').last();
  await dialog
    .getByLabel('Execution status filter value', { exact: true })
    .selectOption({ label: 'Breached' });
  await dialog.getByRole('button', { name: 'Apply changes', exact: true }).click();
  await expect(chartCount).not.toHaveText(initial!);
  await expect(view.locator('.table-header .record-count')).toHaveText('60,000 records');
  await view
    .locator('.chart-card-content')
    .getByRole('button', { name: 'Reset chart filters', exact: true })
    .click();
  await expect(chartCount).toHaveText(initial!);
  const value = form.getByLabel('Execution status filter value', { exact: true });
  await value.selectOption({ label: 'Breached' });
  await expect(form.locator('.natural-summary')).toContainText('Breached');
  await expect(form.locator('.draft-badge')).toHaveText('Not applied');
  await expect(chartCount).toHaveText(initial!);
  await form.getByRole('button', { name: 'Reset draft', exact: true }).click();
  await expect(form.locator('.natural-summary')).toContainText('Failed');
  await value.selectOption({ label: 'Breached' });
  await form.getByRole('button', { name: 'Apply filters', exact: true }).click();
  await expect(chartCount).not.toHaveText(initial!);
  await expect(form.getByRole('button', { name: 'Apply filters', exact: true })).toBeDisabled();
  await page.screenshot({ path: 'evidence/chart-value-draft.png', animations: 'disabled' });
  await page.getByRole('button', { name: 'Add to dashboard', exact: true }).click();
  dialog = page.getByRole('dialog', { name: 'Add to dashboard', exact: true });
  await dialog.getByRole('button', { name: 'Add and open composer', exact: true }).click();
  const tile = page.locator('workspace-chart-tile');
  await expect(tile.locator('workspace-filter-values-form')).toBeVisible();
  await expect(tile.locator('.natural-summary')).toContainText('Failed');
  expect(errors).toEqual([]);
});
