import {test,expect} from '@playwright/test';
import {readFile} from 'node:fs/promises';

test('one dashboard Download all creates one ZIP with two charts and two tables', async ({
  page,
}) => {
  test.setTimeout(120000);
  const downloads: string[] = [];
  page.on('download', (d) => downloads.push(d.suggestedFilename()));
  await page.goto('/dashboards');
  await page.getByRole('link', { name: 'Open Operations monitor', exact: true }).click();
  await expect(page.locator('workspace-widget-view app-integrated-chart canvas')).toHaveCount(2);
  await expect(page.locator('workspace-widget-view .ag-group-value').first()).toBeVisible();
  await expect(page.getByRole('button', { name: 'Download chart as PNG', exact: true })).toHaveCount(0);
  const action = page.getByRole('button', { name: 'Download all', exact: true });
  await expect(action).toHaveCount(1);
  const promise = page.waitForEvent('download');
  await action.click();
  const download = await promise;
  const data = await readFile((await download.path())!);
  const entries: { name: string; data: Buffer }[] = [];
  let offset = 0;
  while (data.readUInt32LE(offset) === 0x04034b50) {
    const size = data.readUInt32LE(offset + 18),
      length = data.readUInt16LE(offset + 26),
      extra = data.readUInt16LE(offset + 28);
    const start = offset + 30 + length + extra;
    entries.push({
      name: data.toString('utf8', offset + 30, offset + 30 + length),
      data: data.subarray(start, start + size),
    });
    offset = start + size;
  }
  expect(entries.filter((e) => e.name.endsWith('.png'))).toHaveLength(2);
  expect(entries.filter((e) => e.name.endsWith('.csv'))).toHaveLength(2);
  expect(new Set(entries.map((e) => e.name)).size).toBe(4);
  for (const e of entries.filter((e) => e.name.endsWith('.png')))
    expect([...e.data.subarray(0, 8)]).toEqual([137, 80, 78, 71, 13, 10, 26, 10]);
  for (const e of entries.filter((e) => e.name.endsWith('.csv')))
    expect(e.data.toString('utf8').trim().split(/\r?\n/).length).toBeGreaterThan(1);
  expect(downloads).toHaveLength(1);
});

