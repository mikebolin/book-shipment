import { test, expect } from '@playwright/test';

test('Studio finder presents neutral source and view groups with one current choice', async ({
  page,
}) => {
  await page.goto(
    '/studio/activity-monitor?widget=breached-activities-by-source-and-type-2&view=published',
  );
  await expect(
    page.locator('.studio-readonly workspace-widget-view .grid-pane .ag-row').first(),
  ).toBeVisible();
  const input = page.getByRole('combobox', { name: 'Data source or view', exact: true });
  await input.click();
  const picker = page.locator('.studio-source-panel');
  await expect(picker).toBeVisible();
  await expect(picker.locator('.mat-mdc-optgroup-label')).toContainText([
    'Data sources',
    'Views in Activity monitor',
  ]);
  await expect(picker.locator('mat-option.current')).toHaveCount(1);
  await expect(picker.locator('mat-option.current .option-name')).toHaveText(
    'Breached activities by source and type',
  );
  await expect(picker.locator('.status-pill')).toHaveCount(0);
  const style = await picker.evaluate((panel) => {
    const current = panel.querySelector('mat-option.current')!;
    const metadata = current.querySelector('small')!;
    const rect = panel.getBoundingClientRect();
    return {
      width: rect.width,
      right: rect.right,
      background: getComputedStyle(panel).backgroundColor,
      currentBackground: getComputedStyle(current).backgroundColor,
      metadataSize: Number.parseFloat(getComputedStyle(metadata).fontSize),
      indicatorCount: panel.querySelectorAll('.current-indicator').length,
    };
  });
  expect(style.width).toBeGreaterThanOrEqual(480);
  expect(style.right).toBeLessThanOrEqual(page.viewportSize()!.width);
  expect(style.background).not.toBe('rgba(0, 0, 0, 0)');
  expect(style.currentBackground).toBe('rgba(0, 0, 0, 0)');
  expect(style.metadataSize).toBeGreaterThanOrEqual(12);
  expect(style.indicatorCount).toBe(1);
  await page.screenshot({ path: 'evidence/studio-view-finder-clean.png', animations: 'disabled' });
  await picker
    .getByRole('option')
    .filter({ has: page.locator('.option-name').filter({ hasText: /^Activity monitor$/ }) })
    .click();
  await expect(page.locator('.studio-editor:not([hidden]) .dataset-record-count')).toContainText(
    '60,000 records',
  );
  await input.click();
  await expect(picker.locator('mat-option.current')).toHaveCount(1);
  await expect(picker.locator('mat-option.current .option-name')).toHaveText('Activity monitor');
  await page.keyboard.press('Escape');
});
