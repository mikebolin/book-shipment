import { test, expect, type Page } from '@playwright/test';
import { readFile } from 'node:fs/promises';

async function openStudio(page: Page) {
  await page.goto('/studio/activity-monitor');
  await expect(page.getByTestId('server-cache-rows')).toHaveText('250 loaded', { timeout: 60000 });
  await expect(page.getByTestId('matching-rows')).toContainText('60,000');
  await page.getByRole('button', { name: 'Close view navigator', exact: true }).click();
}
async function analyze(page: Page, column: string, action: string) {
  await page.getByRole('button', { name: 'Columns', exact: true }).click();
  await page.locator('mat-button-toggle').filter({ hasText: 'Organize' }).click();
  await page.getByLabel('Find a column', { exact: true }).fill(column);
  await page.getByRole('button', { name: 'Actions for ' + column, exact: true }).click();
  await page.getByRole('menuitem', { name: 'Analyze data', exact: true }).click();
  await page.getByRole('menuitem', { name: action, exact: true }).click();
  await page.getByRole('button', { name: 'Close columns', exact: true }).click();
}
async function sql(page: Page) {
  await page.getByRole('button', { name: 'Explorer tools', exact: true }).click();
  await page.getByRole('menuitem', { name: 'View SQL query', exact: true }).click();
  await expect(page.getByTestId('count-sql')).toBeAttached();
}
async function loaded(page: Page) {
  return Number((await page.getByTestId('server-cache-rows').textContent())!.replace(/\D/g, ''));
}
const childCounts = async (page: Page) =>
  (await page.locator('.grid-shell .ag-group-child-count').allTextContents())
    .map((s) => Number(s.replace(/\D/g, '')))
    .reduce((a, b) => a + b, 0);

test('saved per-view grid policy validates limits, remounts grouped tables and reaches published readers', async ({
  page,
}) => {
  test.setTimeout(150000);
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await openStudio(page);
  await analyze(page, 'Source system', 'Group records by this column');
  await expect(page.locator('.grid-shell .ag-group-value')).toHaveCount(11);
  await page.getByRole('button', { name: 'Save as view', exact: true }).click();
  let dialog = page.getByRole('dialog');
  await dialog.getByLabel('Name', { exact: true }).fill('Bounded grid policy');
  await dialog.getByRole('button', { name: 'Create view', exact: true }).click();
  await expect(dialog).toBeHidden();
  await page.getByRole('button', { name: 'View actions', exact: true }).click();
  await page.getByRole('menuitem', { name: 'View settings', exact: true }).click();
  dialog = page.getByRole('dialog');
  await dialog.getByRole('tab', { name: 'Grid loading', exact: true }).click();
  await expect(dialog.getByLabel('Rows per request', { exact: true })).toHaveValue('250');
  await dialog.getByLabel('Rows per request', { exact: true }).fill('501');
  await expect(dialog.getByRole('button', { name: 'Apply settings', exact: true })).toBeDisabled();
  await dialog.getByLabel('Rows per request', { exact: true }).fill('100');
  await dialog.getByLabel('Cached pages per group', { exact: true }).fill('2');
  await dialog.getByLabel('Concurrent requests', { exact: true }).fill('1');
  await dialog.getByLabel('Scroll debounce (ms)', { exact: true }).fill('0');
  await dialog.getByRole('button', { name: 'Apply settings', exact: true }).click();
  await expect(dialog).toBeHidden();
  await expect(page.locator('.grid-shell .ag-group-value')).toHaveCount(11);
  expect(await childCounts(page)).toBe(60000);
  await page.getByRole('button', { name: 'Columns', exact: true }).click();
  await page.locator('mat-button-toggle').filter({ hasText: 'Organize' }).click();
  await page
    .getByRole('button', { name: 'Remove Source system from row groups', exact: true })
    .click();
  await page.getByRole('button', { name: 'Close columns', exact: true }).click();
  await expect(page.getByTestId('server-cache-rows')).toHaveText('100 loaded');
  await analyze(page, 'Source system', 'Group records by this column');
  await expect(page.locator('.grid-shell .ag-group-value')).toHaveCount(11);
  await page.getByRole('button', { name: 'Publish', exact: true }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Publish', exact: true }).click();
  await expect(page.locator('.studio-status-chip')).toContainText('Published');
  await page.getByRole('link', { name: 'Published views', exact: true }).click();
  const published = page.getByRole('link', { name: 'Open Bounded grid policy', exact: true });
  await published.click();
  const view = page.locator('workspace-widget-view');
  await expect(view.locator('.ag-group-value')).toHaveCount(11);
  await view.getByRole('button', { name: 'Ungroup all', exact: true }).click();
  await expect(view.locator('.ag-group-value')).toHaveCount(0);
  await expect.poll(() => view.locator('.ag-row[row-id]').count()).toBeGreaterThan(0);
  await page.getByRole('button', { name: 'Edit draft', exact: true }).click();
  await page.getByRole('button', { name: 'View actions', exact: true }).click();
  await page.getByRole('menuitem', { name: /^Open published/ }).click();
  await expect(page.locator('.studio-readonly .ag-group-value').first()).toBeVisible({
    timeout: 60000,
  });
  await page.getByRole('button', { name: 'View actions', exact: true }).click();
  await page.getByRole('menuitem', { name: 'View settings', exact: true }).click();
  dialog = page.getByRole('dialog');
  await dialog.getByRole('tab', { name: 'Grid loading', exact: true }).click();
  await expect(dialog.getByLabel('Rows per request', { exact: true })).toHaveValue('100');
  await expect(dialog.getByLabel('Rows per request', { exact: true })).toBeDisabled();
  await expect(dialog.getByLabel('Concurrent requests', { exact: true })).toHaveValue('1');
  expect(errors).toEqual([]);
});

test('bundled compact models render every column in server blocks, not just the identifier', async ({
  page,
}) => {
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto('/studio/activity-monitor');
  await expect(page.getByTestId('server-cache-rows')).toHaveText('250 loaded', { timeout: 45000 });
  await expect(page.getByTestId('matching-rows')).toContainText('60,000');
  const first = page.locator('.grid-shell .ag-row[row-id]').first();
  await expect(first.locator('.ag-cell[col-id="name"]')).toContainText(/\S/);
  await expect(first.locator('.ag-cell[col-id="executionStatus"]')).toContainText(/\S/);
  expect(errors).toEqual([]);
});

test('Activity monitor: 60,000 records group by source and type, drill into a type and page its records', async ({
  page,
}) => {
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto('/studio/activity-monitor');
  await expect(page.getByTestId('server-cache-rows')).toHaveText('250 loaded', { timeout: 60000 });
  await expect(page.getByTestId('matching-rows')).toContainText('60,000');
  await page.getByRole('button', { name: 'Close view navigator', exact: true }).click();
  const firstRow = page.locator('.grid-shell .ag-row[row-id]').first();
  await expect(firstRow.locator('.ag-cell[col-id="name"]')).toContainText(/\S/);
  await expect(firstRow.locator('.ag-cell[col-id="executionStatus"]')).toContainText(/\S/);
  await analyze(page, 'Source system', 'Group records by this column');
  await expect(page.locator('.grid-shell .ag-group-value')).toHaveCount(11);
  expect(await childCounts(page)).toBe(60000);
  await analyze(page, 'Activity type', 'Group records by this column');
  await expect(page.locator('.grid-shell .ag-group-value')).toHaveCount(11);
  await page.screenshot({ path: 'evidence/studio-activity-monitor-groups.png' });
  // Expand the first source: only its activity-type groups are requested.
  await page.locator('.grid-shell .ag-row-level-0 .ag-group-contracted:visible').first().click();
  await expect(page.locator('.grid-shell .ag-row-level-1 .ag-group-value').first()).toBeVisible();
  const typeGroups = await page.locator('.grid-shell .ag-row-level-1').count();
  expect(typeGroups).toBeGreaterThan(0);
  // Expand the first type beneath it: the first 250 matching records load.
  await page.locator('.grid-shell .ag-row-level-1 .ag-group-contracted:visible').first().click();
  await expect.poll(() => loaded(page)).toBe(11 + typeGroups + 250);
  const leaf = page.locator('.grid-shell .ag-row.ag-row-level-2[row-id]').first();
  await expect(leaf.locator('.ag-cell[col-id="name"]')).toContainText(/\S/);
  // Scrolling inside the expanded group requests its next block.
  await page.locator('.grid-shell .ag-body-vertical-scroll-viewport').evaluate((e) => {
    e.scrollTop = 11000;
  });
  await expect.poll(() => loaded(page)).toBeGreaterThan(11 + typeGroups + 250);
  await sql(page);
  await expect(page.getByTestId('count-sql')).toContainText('WHERE "source" = ? AND "type" = ?');
  await expect(page.getByTestId('sql-binds')).toContainText('AUTOMATION');
  await page.getByRole('tab', { name: 'Preview', exact: true }).click();
  await page.screenshot({ path: 'evidence/studio-activity-monitor-drilldown.png' });
  expect(errors).toEqual([]);
});

test('the seeded Activity monitor view reopens grouped, aggregated, filtered and sorted', async ({
  page,
}) => {
  test.setTimeout(120000);
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto('/library');
  await page
    .getByRole('link', { name: 'Open Breached activities by source and type', exact: true })
    .click();
  const view = page.locator('workspace-widget-view');
  await expect(view.locator('.ag-group-value').first()).toBeVisible({ timeout: 60000 });
  // Eleven sources, each auto-expanded to its activity types; every record counted is a breach.
  await expect.poll(async () => (await view.locator('.ag-row-level-0').count()) >= 1).toBe(true);
  await expect(view.locator('.ag-row-level-1 .ag-group-value').first()).toBeVisible();
  await page.screenshot({ path: 'evidence/view-activity-monitor-breaches.png' });
  const matching = await view.locator('.table-header .record-count').textContent();
  await view.getByRole('button', { name: 'Ungroup all', exact: true }).click();
  await expect(view.locator('.ag-group-value')).toHaveCount(0);
  await expect(view.locator('.ag-cell[col-id="name"]').first()).toContainText(/\S/);
  await expect(view.locator('.table-header .record-count')).toHaveText(matching!);
  await view.getByRole('button', { name: 'Restore grouping', exact: true }).click();
  await expect(view.locator('.ag-row-level-1 .ag-group-value').first()).toBeVisible();
  // Reader grouping is temporary; reopening the pinned publication restores its saved hierarchy.
  await view.getByRole('button', { name: 'Ungroup all', exact: true }).click();
  await page.getByRole('link', { name: 'Published views', exact: true }).click();
  await page
    .getByRole('link', { name: 'Open Breached activities by source and type', exact: true })
    .click();
  await expect(view.locator('.ag-row-level-1 .ag-group-value').first()).toBeVisible({
    timeout: 60000,
  });
  expect(errors).toEqual([]);
});

test('Studio pages through distinct blocks and exports the full result', async ({ page }) => {
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await openStudio(page);
  const row = page.locator('.grid-shell .ag-row[row-id]').first();
  const first = await row.getAttribute('row-id');
  await page.locator('.grid-shell .ag-body-vertical-scroll-viewport').evaluate((e) => {
    e.scrollTop = 13000;
  });
  await expect(row).not.toHaveAttribute('row-id', first!);
  await expect
    .poll(async () =>
      Number((await page.getByTestId('server-cache-rows').textContent())!.replace(/\D/g, '')),
    )
    .toBeGreaterThan(250);
  expect(
    Number((await page.getByTestId('server-cache-rows').textContent())!.replace(/\D/g, '')),
  ).toBeLessThanOrEqual(750);
  await page.getByRole('button', { name: 'Explorer tools', exact: true }).click();
  await page.getByRole('menuitem', { name: 'Grid options', exact: true }).click();
  const downloadPromise = page.waitForEvent('download');
  await page.getByRole('menuitem', { name: 'Export view as CSV', exact: true }).click();
  const download = await downloadPromise;
  const csv = await readFile((await download.path())!, 'utf8');
  expect(csv.trim().split(/\r?\n/)).toHaveLength(60001);
  expect(errors).toEqual([]);
});

test('grouping returns full counts, aggregates, drillthrough SQL, and preserves column order', async ({
  page,
}) => {
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await openStudio(page);
  const columns = page.locator('.grid-shell .ag-header-cell');
  // AG Grid reuses header DOM nodes; visual order is their horizontal position.
  const before = await columns.evaluateAll((nodes) =>
    nodes
      .sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left)
      .map((n) => n.getAttribute('col-id')),
  );
  await analyze(page, 'Source system', 'Group records by this column');
  await expect(page.locator('.grid-shell .ag-group-value')).toHaveCount(11);
  const counts = await page.locator('.grid-shell .ag-group-child-count').allTextContents();
  expect(counts.map((s) => Number(s.replace(/\D/g, ''))).reduce((a, b) => a + b, 0)).toBe(60000);
  await analyze(page, 'Processed rows', 'Summarize this column');
  await expect(page.locator('.grid-shell .ag-row').filter({ hasText: 'Total' })).toBeVisible();
  await sql(page);
  await expect(page.getByTestId('count-sql')).toContainText('GROUP BY "source"');
  await expect(page.getByTestId('count-sql')).toContainText('SUM("processedRowCount")');
  await page.getByRole('tab', { name: 'Preview', exact: true }).click();
  await page.screenshot({ path: 'evidence/studio-server-grouping.png' });
  await page.locator('.grid-shell .ag-group-contracted:visible').first().click();
  await expect(page.getByTestId('server-cache-rows')).toHaveText('261 loaded');
  await sql(page);
  await expect(page.getByTestId('count-sql')).toContainText('WHERE "source" = ?');
  await expect(page.getByTestId('sql-binds')).toContainText('AUTOMATION');
  await page.getByRole('tab', { name: 'Preview', exact: true }).click();
  await page.getByRole('button', { name: 'Columns', exact: true }).click();
  await page
    .getByRole('button', { name: 'Remove Source system from row groups', exact: true })
    .click();
  await page.getByRole('button', { name: 'Close columns', exact: true }).click();
  await expect(page.getByTestId('server-cache-rows')).toHaveText('250 loaded');
  const after = await columns.evaluateAll((nodes) =>
    nodes
      .sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left)
      .map((n) => n.getAttribute('col-id')),
  );
  expect(after).toEqual(before);
  expect(errors).toEqual([]);
});

test('a grouped saved view retains sorting and highlights when published and imported as a dashboard table', async ({
  page,
}) => {
  test.setTimeout(120000);
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await openStudio(page);
  const highlightedHeader = page.locator('.grid-shell .ag-header-cell[col-id="name"]');
  await highlightedHeader.hover();
  await highlightedHeader.locator('.ag-header-cell-menu-button').click();
  await page.getByRole('menuitem', { name: 'Highlight column', exact: true }).click();
  await expect(highlightedHeader).toHaveClass(/explorer-column-highlight-1/);
  const savedHighlight = await highlightedHeader.evaluate(
    (node) => getComputedStyle(node).backgroundColor,
  );
  await analyze(page, 'Source system', 'Group records by this column');
  const heading = page.locator(
    '.grid-shell .ag-header-cell[col-id="ag-Grid-AutoColumn"] .ag-header-cell-label',
  );
  await heading.click();
  await heading.click();
  await expect(page.locator('.grid-shell .ag-group-value').first()).toHaveText('WORKFLOW');
  await page.getByRole('button', { name: 'Save as view', exact: true }).click();
  const dialog = page.getByRole('dialog');
  await dialog.getByLabel('Name', { exact: true }).fill('Server grouped sources');
  await dialog.getByRole('button', { name: 'Create view', exact: true }).click();
  await expect(dialog).toBeHidden();
  await page.getByRole('button', { name: 'Publish', exact: true }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Publish', exact: true }).click();
  await expect(page.locator('.studio-status-chip')).toContainText('Published');
  await page.getByRole('link', { name: 'Published views', exact: true }).click();
  await page.getByRole('link', { name: 'Open Server grouped sources', exact: true }).click();
  await expect(page.locator('workspace-widget-view .ag-group-value').first()).toHaveText(
    'WORKFLOW',
  );
  const publishedHeader = page.locator('workspace-widget-view .ag-header-cell[col-id="name"]');
  await expect(publishedHeader).toHaveClass(/explorer-column-highlight-1/);
  expect(await publishedHeader.evaluate((node) => getComputedStyle(node).backgroundColor)).toBe(
    savedHighlight,
  );
  await page.getByRole('button', { name: 'Add to dashboard', exact: true }).click();
  const importDialog = page.getByRole('dialog', { name: 'Add to dashboard', exact: true });
  await importDialog.getByLabel('Dashboard name', { exact: true }).fill('Highlighted source table');
  await importDialog.getByRole('button', { name: 'Add and open composer', exact: true }).click();
  const table = page.locator('workspace-table-tile');
  await expect(table).toHaveCount(1);
  await expect(table.locator('.ag-row-level-0 .ag-group-value').first()).toHaveText('WORKFLOW');
  const tableHeader = table.locator('.ag-header-cell[col-id="name"]');
  await expect(tableHeader).toHaveClass(/explorer-column-highlight-1/);
  expect(await tableHeader.evaluate((node) => getComputedStyle(node).backgroundColor)).toBe(
    savedHighlight,
  );
  await table.getByRole('button', { name: 'Ungroup all', exact: true }).click();
  const highlightedCell = table.locator('.ag-cell[col-id="name"]').first();
  await expect(highlightedCell).toContainText(/\S/);
  await expect(highlightedCell).toHaveClass(/explorer-column-highlight-1/);
  expect(errors).toEqual([]);
});
