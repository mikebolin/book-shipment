import { test, expect, type Page } from '@playwright/test';

const viewName = 'Breached activities by source and type';

async function openDraft(page: Page) {
  await page.goto('/library');
  await page.getByRole('link', { name: `Open ${viewName}`, exact: true }).click();
  await page.getByRole('button', { name: /^(Edit draft|Open draft v)/ }).click();
  const editor = page.locator('.studio-editor:not([hidden])');
  await expect(editor.locator('.ag-row').first()).toBeAttached();
  const close = page.getByRole('button', { name: 'Close view navigator', exact: true });
  if (await close.isVisible()) await close.click();
  await page.getByRole('button', { name: 'View layout', exact: true }).click();
  await page.getByLabel('Visible sections', { exact: true }).selectOption('both');
  await page.keyboard.press('Escape');
  const chart = editor.locator('app-saved-chart').first();
  await expect(chart.locator('canvas').first()).toBeVisible();
  return { editor, chart };
}

test('removing the chart being edited discards its preview and preserves removal when saved', async ({
  page,
}) => {
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(error.message));
  const { editor, chart } = await openDraft(page);
  await expect(editor.locator('app-saved-chart')).toHaveCount(1);
  await chart.getByRole('button', { name: 'Refine in chat', exact: true }).click();
  const builder = page.getByRole('region', { name: 'Guided chart builder', exact: true });
  await expect(builder).toBeVisible();
  await builder.getByLabel('Guided chart title', { exact: true }).fill('Unsaved chart edit');
  await chart.getByRole('button', { name: 'More chart actions', exact: true }).click();
  await page.getByRole('menuitem', { name: 'Remove chart', exact: true }).click();
  const confirmation = page.getByRole('dialog');
  await expect(confirmation).toContainText('Remove Breached activities by type?');
  await confirmation.getByRole('button', { name: 'Remove chart', exact: true }).click();
  await expect(editor.locator('app-saved-chart')).toHaveCount(0);
  await expect(builder).toBeHidden();
  await expect(editor.locator('.chart-explorer')).toHaveCount(0);
  await expect(editor.locator('.grid-shell .ag-row').first()).toBeVisible();
  await page.getByRole('button', { name: 'Save', exact: true }).click();
  await expect(page.locator('.workspace-notice')).toContainText(`Saved ${viewName}.`);
  await page.getByRole('link', { name: 'Published views', exact: true }).click();
  await page.getByRole('link', { name: `Open ${viewName}`, exact: true }).click();
  await page.getByRole('button', { name: /^(Edit draft|Open draft v)/ }).click();
  await expect(editor.locator('.ag-row').first()).toBeVisible();
  await expect(editor.locator('app-saved-chart')).toHaveCount(0);
  expect(errors).toEqual([]);
});

test('canceling chart removal keeps the chart and its open editor', async ({ page }) => {
  const { chart, editor } = await openDraft(page);
  await chart.getByRole('button', { name: 'Refine in chat', exact: true }).click();
  const builder = page.getByRole('region', { name: 'Guided chart builder', exact: true });
  await expect(builder).toBeVisible();
  await chart.getByRole('button', { name: 'More chart actions', exact: true }).click();
  await page.getByRole('menuitem', { name: 'Remove chart', exact: true }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Cancel', exact: true }).click();
  await expect(editor.locator('app-saved-chart')).toHaveCount(1);
  await expect(builder).toBeVisible();
});
