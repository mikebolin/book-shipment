import { test, expect, type Page } from '@playwright/test';

const galleries = [
  {
    path: '/dashboards',
    search: 'Search dashboards',
    name: 'Operations monitor',
    query: 'Operations monitor',
    tag: 'Triage',
    taggedCount: 2,
  },
  {
    path: '/library',
    search: 'Search published views',
    name: 'Breached activities by source and type',
    query: 'Breached activities by source and type',
    tag: 'Server grid',
    taggedCount: 3,
  },
] as const;

function watchGallery(page: Page) {
  const errors: string[] = [];
  const datasetRequests: string[] = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.on('request', (request) => {
    if (/\.ndjson(?:\.gz)?(?:[?#]|$)|\/datasets\//.test(request.url()))
      datasetRequests.push(request.url());
  });
  return { errors, datasetRequests };
}

async function openGallery(page: Page, path: string) {
  await page.goto(path);
  await expect(page.locator('workspace-resource-card')).toHaveCount(3);
  await expect(page.locator('.skeleton-grid')).toHaveCount(0);
}

async function expectGalleryFits(page: Page) {
  const viewport = page.viewportSize()!;
  const dimensions = await page.evaluate(() => ({
    pageWidth: document.documentElement.scrollWidth,
    windowWidth: window.innerWidth,
  }));
  expect(dimensions.pageWidth).toBeLessThanOrEqual(dimensions.windowWidth + 1);
  for (const card of await page.locator('workspace-resource-card').all()) {
    const box = (await card.boundingBox())!;
    expect(box.x).toBeGreaterThanOrEqual(0);
    expect(box.x + box.width).toBeLessThanOrEqual(viewport.width + 1);
    await expect(card.getByRole('link', { name: /^Open / })).toBeVisible();
    await expect(card.getByRole('button', { name: /^More actions for / })).toBeVisible();
  }
}

async function showUnpublishedMetadata(page: Page) {
  // Exercise the longer real draft label without loading a dataset or changing a saved resource.
  await page.locator('workspace-resource-card .status-pill').evaluateAll((statuses) => {
    for (const status of statuses) {
      status.textContent = 'Unpublished changes · v12';
      status.classList.remove('tone-accent');
      status.classList.add('tone-tertiary');
    }
  });
}

async function expectMetadataFits(page: Page) {
  for (const card of await page.locator('workspace-resource-card').all()) {
    const box = (await card.boundingBox())!;
    await expect(card.locator('.status-pill')).toHaveText('Unpublished changes · v12');
    for (const metadata of await card.locator('.card-footer > *').all()) {
      const child = (await metadata.boundingBox())!;
      expect(child.x).toBeGreaterThanOrEqual(box.x);
      expect(child.x + child.width).toBeLessThanOrEqual(box.x + box.width + 1);
    }
  }
}

test('dashboard and view galleries keep compact, proportional previews on large screens', async ({
  page,
}) => {
  const seen = watchGallery(page);
  for (const width of [1440, 2560]) {
    await page.setViewportSize({ width, height: 1000 });
    for (const gallery of galleries) {
      await openGallery(page, gallery.path);
      await expectGalleryFits(page);
      for (const card of await page.locator('workspace-resource-card').all()) {
        const box = (await card.boundingBox())!;
        expect(box.width).toBeGreaterThanOrEqual(240);
        expect(box.width).toBeLessThanOrEqual(360);
        expect(box.height).toBeLessThanOrEqual(410);
        const preview = (await card.locator('.card-preview').boundingBox())!;
        expect(preview.width / preview.height).toBeCloseTo(320 / 152, 1);
        expect(preview.height).toBeGreaterThan(110);
        const svg = card.locator('workspace-resource-preview svg');
        await expect(svg).toHaveCount(1);
        await expect(svg).toHaveAttribute('viewBox', '0 0 320 152');
        expect((await svg.getAttribute('preserveAspectRatio')) ?? 'xMidYMid meet').toBe(
          'xMidYMid meet',
        );
      }
      await expect(
        page.locator(
          'workspace-resource-card canvas, workspace-resource-card img, workspace-resource-card ag-grid-angular',
        ),
      ).toHaveCount(0);
    }
  }
  expect(seen.datasetRequests).toEqual([]);
  expect(seen.errors).toEqual([]);
});

test('dashboard and view galleries fit phone and tablet widths in grid and list layouts', async ({
  page,
}) => {
  const seen = watchGallery(page);
  for (const width of [375, 540, 768]) {
    await page.setViewportSize({ width, height: 1000 });
    for (const gallery of galleries) {
      await openGallery(page, gallery.path);
      await page.getByRole('button', { name: 'Grid layout', exact: true }).click();
      await expect(page.getByRole('button', { name: 'Grid layout', exact: true })).toHaveAttribute(
        'aria-pressed',
        'true',
      );
      await showUnpublishedMetadata(page);
      await expectGalleryFits(page);
      await expectMetadataFits(page);
      await page.getByRole('button', { name: 'List layout', exact: true }).click();
      await expect(page.getByRole('button', { name: 'List layout', exact: true })).toHaveAttribute(
        'aria-pressed',
        'true',
      );
      await showUnpublishedMetadata(page);
      await expectGalleryFits(page);
      await expectMetadataFits(page);
      await expect(
        page.getByRole('searchbox', { name: gallery.search, exact: true }),
      ).toBeVisible();
      await expect(page.getByRole('combobox', { name: 'Tag', exact: true })).toBeVisible();
    }
  }
  expect(seen.datasetRequests).toEqual([]);
  expect(seen.errors).toEqual([]);
});

test('touch gallery controls stay visible and operable in grid and list layouts', async ({
  browser,
  baseURL,
}) => {
  const context = await browser.newContext({
    baseURL,
    viewport: { width: 375, height: 1000 },
    isMobile: true,
    hasTouch: true,
  });
  const page = await context.newPage();
  const seen = watchGallery(page);
  try {
    for (const gallery of galleries) {
      await openGallery(page, gallery.path);
      for (const layout of ['Grid layout', 'List layout']) {
        await page.getByRole('button', { name: layout, exact: true }).tap();
        const card = page.locator('workspace-resource-card').first();
        await expect(card.locator('.card-actions')).toHaveCSS('opacity', '1');
        for (const action of await card.locator('.card-actions .card-action').all()) {
          const box = (await action.boundingBox())!;
          expect(box.width).toBeGreaterThanOrEqual(40);
          expect(box.height).toBeGreaterThanOrEqual(40);
        }
        await card.getByRole('button', { name: /^More actions for / }).tap();
        await expect(
          page.getByRole('menuitem', { name: 'Open published', exact: true }),
        ).toBeVisible();
        await page.keyboard.press('Escape');
      }
    }
    expect(seen.datasetRequests).toEqual([]);
    expect(seen.errors).toEqual([]);
  } finally {
    await context.close();
  }
});

test('gallery search, tags and keyboard actions remain independent of the card opening link', async ({
  page,
}) => {
  const seen = watchGallery(page);
  for (const gallery of galleries) {
    await openGallery(page, gallery.path);
    const search = page.getByRole('searchbox', { name: gallery.search, exact: true });
    await search.fill(gallery.query);
    await expect(page.locator('workspace-resource-card')).toHaveCount(1);
    await page.getByRole('button', { name: 'Clear search', exact: true }).click();
    await expect(page.locator('workspace-resource-card')).toHaveCount(3);
    await page
      .locator('workspace-resource-card')
      .getByRole('button', { name: gallery.tag, exact: true })
      .first()
      .click();
    await expect(page.locator('workspace-resource-card')).toHaveCount(gallery.taggedCount);
    for (const tag of await page
      .locator('workspace-resource-card')
      .getByRole('button', {
        name: gallery.tag,
        exact: true,
      })
      .all()) {
      await expect(tag).toHaveAttribute('aria-pressed', 'true');
    }
    await expect(page).toHaveURL(
      new RegExp(`tag=${encodeURIComponent(gallery.tag).replace(/%20/g, '(?:%20|\\+)')}`),
    );
    await page.getByRole('button', { name: 'Clear filters', exact: true }).click();
    await expect(page.locator('workspace-resource-card')).toHaveCount(3);
    const group = page.getByRole('combobox', {
      name: 'Group',
      exact: true,
    });
    await group.click();
    await page.getByRole('option', { name: 'Operations', exact: true }).click();
    await expect(group).toContainText('Operations');
    await page.getByRole('button', { name: 'Clear filters', exact: true }).click();
    const card = page.locator('workspace-resource-card').filter({
      has: page.getByRole('heading', { name: gallery.name, exact: true }),
    });
    const open = card.getByRole('link', { name: `Open ${gallery.name}`, exact: true });
    await page.keyboard.press('Tab');
    await open.focus();
    await expect(open).toBeFocused();
    await expect(open).toHaveCSS('outline-style', 'solid');
    const actions = card.getByRole('button', {
      name: `More actions for ${gallery.name}`,
      exact: true,
    });
    await actions.focus();
    await page.keyboard.press('Enter');
    await expect(page.getByRole('menuitem', { name: 'Open published', exact: true })).toBeVisible();
    await page.getByRole('menuitem', { name: 'Delete', exact: true }).click();
    const dialog = page.getByRole('dialog', { name: `Delete ${gallery.name}?`, exact: true });
    await expect(dialog).toBeVisible();
    await dialog.getByRole('button', { name: 'Cancel', exact: true }).click();
    await expect(dialog).toBeHidden();
    await expect(page.locator('workspace-resource-card')).toHaveCount(3);
  }
  expect(seen.datasetRequests).toEqual([]);
  expect(seen.errors).toEqual([]);
  await page.goto('/dashboards');
  const open = page.getByRole('link', { name: 'Open Operations monitor', exact: true });
  await open.focus();
  await page.keyboard.press('Enter');
  await expect(page.getByRole('heading', { name: 'Operations monitor', level: 1 })).toBeVisible();
});
