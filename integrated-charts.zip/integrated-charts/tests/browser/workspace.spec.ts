import { test, expect, type Page } from '@playwright/test';
async function openWorkspace(page: Page) {
  await page.goto('/');
  await expect(page.getByLabel('Search published views')).toBeVisible();
}
function watch(page: Page) {
  const errors: string[] = [],
    network: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  page.on('request', (r) => {
    const url = new URL(r.url());
    if (url.pathname.startsWith('/api/') || !['127.0.0.1', 'localhost'].includes(url.hostname))
      network.push(r.url());
  });
  return { errors, network };
}
async function closeNavigator(page: Page) {
  const close = page.getByRole('button', { name: 'Close view navigator', exact: true });
  if (await close.isVisible()) await close.click();
}

test('activity monitor galleries and dashboard render entirely locally', async ({ page }) => {
  const seen = watch(page);
  await openWorkspace(page);
  await expect(page.getByRole('link', { name: 'Data models', exact: true })).toHaveCount(0);
  await expect(
    page.getByRole('link', { name: 'Open Breached activities by source and type', exact: true }),
  ).toBeVisible();
  await page.getByRole('link', { name: 'Dashboards', exact: true }).click();
  await expect(
    page.getByRole('link', { name: 'Open Operations monitor', exact: true }),
  ).toBeVisible();
  await page.getByRole('link', { name: 'Open Operations monitor', exact: true }).click();
  await expect(page.locator('workspace-widget-view app-integrated-chart canvas')).toHaveCount(2);
  await expect(page.locator('workspace-widget-view .ag-group-value').first()).toBeVisible();
  await page.screenshot({
    path: 'evidence/dashboard-overview.png',
    fullPage: true,
    animations: 'disabled',
  });
  await page.getByRole('link', { name: 'Data studio', exact: true }).click();
  await expect(page.locator('.studio-editor:not([hidden]) .ag-row').first()).toBeVisible();
  const navigator = page.locator('.studio-navigation');
  await expect(navigator).toBeVisible();
  expect((await navigator.boundingBox())!.width).toBeGreaterThanOrEqual(300);
  await page.getByRole('combobox', { name: 'Data source or view', exact: true }).click();
  const suggestions = page.locator('.studio-source-panel');
  await expect(suggestions).toBeVisible();
  const bounds = (await suggestions.boundingBox())!;
  expect(bounds.width).toBeGreaterThanOrEqual(480);
  expect(bounds.x + bounds.width).toBeLessThanOrEqual(page.viewportSize()!.width);
  await page.screenshot({ path: 'evidence/studio-view-finder.png', animations: 'disabled' });
  await page.keyboard.press('Escape');
  await closeNavigator(page);
  await page.screenshot({ path: 'evidence/studio-finance.png', animations: 'disabled' });
  expect(seen.errors).toEqual([]);
  expect(seen.network).toEqual([]);
});

test('published Studio combines locked view controls with the visible content header', async ({
  page,
}) => {
  const seen = watch(page);
  await page.goto(
    '/studio/activity-monitor?widget=breached-activities-by-source-and-type-2&view=published',
  );
  const reader = page.locator('.studio-readonly workspace-widget-view');
  await expect(reader.locator('.ag-group-value').first()).toBeVisible({ timeout: 60000 });
  await expect(page.locator('.studio-preview-toolbar')).toHaveCount(0);
  await expect(reader.locator('.table-header .published-lock')).toContainText(
    'Configuration locked',
  );
  await expect(
    reader.getByRole('button', { name: 'Download all charts and table', exact: true }),
  ).toHaveCount(1);
  await expect(reader.locator('button[aria-label="Download table CSV"]')).toHaveCount(0);
  await reader.getByRole('button', { name: 'Show chart', exact: true }).click();
  await expect(reader.locator('.scope-header')).toHaveCount(1);
  await expect(reader.locator('.scope-header .published-lock')).toBeVisible();
  await reader.getByRole('button', { name: 'Show chart and grid', exact: true }).click();
  await expect(reader.locator('.scope-header')).toHaveCount(2);
  await expect(reader.locator('.scope-header .published-lock')).toHaveCount(1);
  await page.screenshot({ path: 'evidence/studio-combined-header.png', animations: 'disabled' });
  expect(seen.errors).toEqual([]);
});

test('create and publish a view; preserve it across navigation; reload resets memory', async ({
  page,
}) => {
  test.setTimeout(120000);
  const seen = watch(page);
  await openWorkspace(page);
  await page.getByRole('button', { name: 'Create a view', exact: true }).click();
  await page.getByRole('menuitem', { name: 'Activity monitor', exact: true }).click();
  const dialog = page.getByRole('dialog');
  await expect(dialog).toBeVisible();
  await dialog.getByLabel('Name', { exact: true }).fill('Local test view');
  await dialog.getByRole('button', { name: 'Create view', exact: true }).click();
  await expect(dialog).toBeHidden();
  await expect(page.locator('.studio-editor:not([hidden]) .ag-row').first()).toBeVisible();
  await closeNavigator(page);
  await page.getByRole('button', { name: 'Publish', exact: true }).click();
  const confirmation = page.getByRole('dialog');
  await expect(confirmation).toBeVisible();
  await confirmation.getByRole('button', { name: 'Publish', exact: true }).click();
  await expect(page.locator('.studio-status-chip')).toContainText('Published');
  await page.getByRole('link', { name: 'Published views', exact: true }).click();
  await expect(page.getByRole('link', { name: 'Open Local test view', exact: true })).toBeVisible();
  await page.getByRole('link', { name: 'Open Local test view', exact: true }).click();
  await expect(page.locator('.ag-row').first()).toBeVisible();
  await page.reload();
  await page.getByRole('link', { name: 'Published views', exact: true }).click();
  await expect(page.getByRole('link', { name: 'Open Local test view', exact: true })).toHaveCount(
    0,
  );
  expect(seen.errors).toEqual([]);
  expect(seen.network).toEqual([]);
});

test('activity monitor snapshot loads from bundled data and renders rows', async ({ page }) => {
  test.setTimeout(90000);
  const seen = watch(page);
  await openWorkspace(page);
  await page.getByRole('link', { name: 'Data studio', exact: true }).click();
  await expect(page.locator('.studio-editor:not([hidden]) .ag-row').first()).toBeVisible({
    timeout: 60000,
  });
  await closeNavigator(page);
  await expect(page.locator('.studio-editor:not([hidden])')).toContainText('60,000');
  await page.screenshot({ path: 'evidence/accounts.png', animations: 'disabled' });
  expect(seen.errors).toEqual([]);
  expect(seen.network).toEqual([]);
});

test('deep links open directly without authentication', async ({ page }) => {
  const seen = watch(page);
  await page.goto('/models');
  await expect(page.getByRole('listitem')).toHaveCount(1);
  await expect(page.getByRole('link', { name: 'Data studio', exact: true })).toBeVisible();
  await expect(page.getByRole('button', { name: /sign in|sign out|my account/i })).toHaveCount(0);
  expect(seen.errors).toEqual([]);
  expect(seen.network).toEqual([]);
});

test('CSV import and guided chart creation work without services', async ({ page }) => {
  test.setTimeout(120000);
  const seen = watch(page);
  await openWorkspace(page);
  await page.getByRole('button', { name: 'Create a view', exact: true }).click();
  await page.getByRole('menuitem', { name: 'Import CSV or JSON', exact: true }).click();
  const csv =
    'id,region,revenue,orders\n1,North,100,4\n2,South,200,6\n3,North,150,5\n4,East,80,2\n5,South,120,3\n6,East,170,7\n';
  await page
    .getByLabel('JSON or CSV data file', { exact: true })
    .setInputFiles({ name: 'sales.csv', mimeType: 'text/csv', buffer: Buffer.from(csv) });
  await expect(page.getByRole('button', { name: 'Explore data', exact: true })).toBeEnabled();
  await page.getByRole('button', { name: 'Explore data', exact: true }).click();
  await expect(page.locator('app-data-explorer .ag-row').first()).toBeVisible();
  await page.getByRole('tab', { name: 'Charts', exact: true }).click();
  await page
    .getByRole('button', { name: /^(Add chart|Add another chart)$/ })
    .first()
    .click();
  const guide = page.getByRole('region', { name: 'Guided chart builder', exact: true });
  await expect(guide).toBeVisible();
  await guide
    .locator('[data-chart-style]')
    .filter({ has: page.getByRole('button', { name: /^Choose /, disabled: false }) })
    .first()
    .getByRole('button', { name: /^Choose / })
    .first()
    .click();
  await guide.getByLabel('Guided chart title', { exact: true }).fill('Imported sales');
  await guide.getByRole('button', { name: 'Continue', exact: true }).click();
  await expect(guide.locator('app-integrated-chart canvas').first()).toBeVisible();
  await guide.getByRole('button', { name: 'Add chart', exact: true }).click();
  await expect(
    page.locator('.saved-chart-card').filter({ hasText: 'Imported sales' }),
  ).toBeVisible();
  await page.screenshot({ path: 'evidence/import-chart.png', animations: 'disabled' });
  expect(seen.errors).toEqual([]);
  expect(seen.network).toEqual([]);
});

test('dashboard CRUD and preferences remain available in memory', async ({ page }) => {
  const seen = watch(page);
  await openWorkspace(page);
  await page.getByRole('link', { name: 'Dashboards', exact: true }).click();
  await page.getByRole('button', { name: 'Create dashboard', exact: true }).click();
  const dialog = page.getByRole('dialog');
  await dialog.getByLabel('Name', { exact: true }).fill('Local board');
  await dialog.getByRole('button', { name: 'Create dashboard', exact: true }).click();
  await expect(page.getByRole('textbox', { name: 'Dashboard name', exact: true })).toHaveValue(
    'Local board',
  );
  await page.screenshot({ path: 'evidence/dashboard-editor.png', animations: 'disabled' });
  await page.getByRole('button', { name: 'Preferences', exact: true }).click();
  await expect(page.getByRole('dialog').last()).toContainText('Preferences');
  await page.getByRole('button', { name: 'Comfortable', exact: true }).click();
  await page.getByRole('button', { name: 'Save preferences', exact: true }).click();
  await expect(page.locator('html')).toHaveAttribute('data-ui-density', 'comfortable');
  expect(seen.errors).toEqual([]);
  expect(seen.network).toEqual([]);
});
