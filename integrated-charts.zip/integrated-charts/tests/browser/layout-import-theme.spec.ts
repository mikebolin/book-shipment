import { test, expect, type Page } from '@playwright/test';
async function openPublished(page: Page) {
  await page.goto('/library');
  await page.getByRole('link', { name: 'Open Breached activities by source and type', exact: true }).click();
  await expect(page.locator('workspace-widget-view canvas').first()).toBeVisible();
}
async function publish(page: Page) {
  await page.getByRole('button', { name: 'Publish', exact: true }).click();
  const dialog = page.getByRole('dialog');
  await expect(dialog).toBeVisible();
  await dialog.getByRole('button', { name: 'Publish', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Add to dashboard', exact: true })).toBeVisible();
}
test('Studio layout survives publishing and whole-view import; individual import creates independent tiles', async ({
  page,
}) => {
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await openPublished(page);
  await page.getByRole('button', { name: /^(Edit draft|Open draft v)/ }).click();
  await expect(page.locator('.studio-editor:not([hidden]) .ag-row').first()).toBeAttached();
  const close = page.getByRole('button', { name: 'Close view navigator', exact: true });
  if (await close.isVisible()) await close.click();
  await page.getByRole('button', { name: 'View layout', exact: true }).click();
  await page.getByLabel('Visible sections', { exact: true }).selectOption('both');
  await page.getByLabel('Table position', { exact: true }).selectOption('top');
  await page.getByRole('checkbox', { name: 'Record counts', exact: true }).uncheck();
  await page.getByRole('checkbox', { name: 'Filter summaries', exact: true }).uncheck();
  await page.keyboard.press('Escape');
  const results = page.locator('.studio-editor:not([hidden]) .results');
  await expect(results).toHaveClass(/table-first/);
  expect(
    await results.locator('.grid-shell').evaluate((n) => {
      const chart = n.parentElement!.querySelector('.chart-explorer')!;
      return n.getBoundingClientRect().top < chart.getBoundingClientRect().top;
    }),
  ).toBe(true);
  await expect(results.locator('.dataset-record-count')).toBeHidden();
  await page.screenshot({ path: 'evidence/studio-table-first.png', animations: 'disabled' });
  // Duplicate creates two separately selectable charts while preserving the originals.
  await results.getByRole('button', { name: 'More chart actions', exact: true }).first().click();
  await page.getByRole('menuitem', { name: 'Duplicate chart', exact: true }).click();
  await expect(results.locator('app-saved-chart')).toHaveCount(2);
  await publish(page);
  const view = page.locator('workspace-widget-view').first();
  await expect(view.locator('.view-content')).toHaveClass(/table-first/);
  await expect(view.locator('.record-count').first()).toBeHidden();
  await page.getByRole('button', { name: 'Add to dashboard', exact: true }).click();
  let dialog = page.getByRole('dialog', { name: 'Add to dashboard', exact: true });
  await expect(dialog.getByRole('radio', { name: /Individual charts and table/ })).toBeChecked();
  const choices = dialog.locator('.element-checklist mat-checkbox');
  await expect(choices).toHaveCount(4);
  await choices.nth(1).getByRole('checkbox').uncheck();
  await choices.nth(2).getByRole('checkbox').check();
  await choices.nth(3).getByRole('checkbox').uncheck();
  await dialog.getByLabel('Dashboard name', { exact: true }).fill('Independent test');
  await page.screenshot({ path: 'evidence/dashboard-import-choice.png', animations: 'disabled' });
  await dialog.getByRole('button', { name: 'Add and open composer', exact: true }).click();
  await expect(page.locator('.dashboard-tile')).toHaveCount(2);
  await expect(page.locator('workspace-chart-tile')).toHaveCount(1);
  await expect(page.locator('workspace-table-tile')).toHaveCount(1);
  await expect(page.locator('workspace-widget-view')).toHaveCount(1); // shared renderer inside the independent table
  await page.screenshot({
    path: 'evidence/dashboard-independent-elements.png',
    animations: 'disabled',
  });
  await page.getByRole('link', { name: 'Published views', exact: true }).click();
  await page.getByRole('link', { name: 'Open Breached activities by source and type', exact: true }).click();
  await page.getByRole('button', { name: 'Add to dashboard', exact: true }).click();
  dialog = page.getByRole('dialog', { name: 'Add to dashboard', exact: true });
  await dialog.getByRole('radio', { name: /Whole view with its container/ }).check();
  await dialog.getByLabel('Dashboard name', { exact: true }).fill('Whole view test');
  await dialog.getByRole('button', { name: 'Add and open composer', exact: true }).click();
  await expect(page.locator('.dashboard-tile')).toHaveCount(1);
  await expect(page.locator('workspace-widget-view .view-content')).toHaveClass(/table-first/);
  await expect(page.locator('workspace-widget-view .record-count').first()).toBeHidden();
  expect(errors).toEqual([]);
});

test('theme picker updates the session across routes and refresh restores default', async ({
  page,
}) => {
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto('/library');
  await page.getByRole('button', { name: 'Theme', exact: true }).click();
  await page.getByRole('menuitem', { name: 'Magenta / violet', exact: true }).click();
  await expect(page.locator('html')).toHaveAttribute('data-app-theme', 'magenta-violet');
  await page.getByRole('link', { name: 'Dashboards', exact: true }).click();
  await expect(page.locator('html')).toHaveAttribute('data-app-theme', 'magenta-violet');
  await page.getByRole('link', { name: 'Open Operations monitor', exact: true }).click();
  await expect(page.locator('canvas')).toHaveCount(2);
  await page.screenshot({ path: 'evidence/theme-session.png', animations: 'disabled' });
  await page.reload();
  await expect(page.locator('html')).toHaveAttribute('data-app-theme', 'azure-blue');
  expect(errors).toEqual([]);
});
