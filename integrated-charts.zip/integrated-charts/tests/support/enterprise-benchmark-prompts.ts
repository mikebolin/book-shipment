import type { PromptExample } from '@prism/charting';

/** Prompt-only library. Selecting an example does not call a model. */
export const ENTERPRISE_BENCHMARK_PROMPTS: readonly PromptExample[] = [
  {
    id: 'V001',
    title: 'V001 · Status distribution',
    category: 'charts',
    prompt:
      'Create a pie chart of case counts by current status. Keep all statuses, count cases rather than clients, and label the slices with status and percentage.',
    outcome: 'apply',
    expectation:
      'Complexity 1/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'pie',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V002',
    title: 'V002 · Billed USD by region',
    category: 'charts',
    prompt:
      "Show each region's share of total billed amount in USD as a donut. Sum the already converted USD amount, not mixed local currencies.",
    outcome: 'apply',
    expectation:
      'Complexity 1/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'donut',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V003',
    title: 'V003 · Business-unit workload',
    category: 'charts',
    prompt:
      'Compare case volume across business units in a column chart. Count every case once and sort business units alphabetically.',
    outcome: 'apply',
    expectation:
      'Complexity 1/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V004',
    title: 'V004 · Service labor expenditure',
    category: 'charts',
    prompt:
      'Show total labor cost in USD for each service as horizontal bars. Include all services and use alphabetical service order.',
    outcome: 'apply',
    expectation:
      'Complexity 1/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V005',
    title: 'V005 · Priority distribution',
    category: 'charts',
    prompt:
      'Count cases by priority in a column chart, ordered P1, P2, P3, P4. Do not sum the priority digits.',
    outcome: 'apply',
    expectation:
      'Complexity 1/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V006',
    title: 'V006 · Support-tier mix',
    category: 'charts',
    prompt:
      'Create a donut showing the number of cases in each support tier. Count cases, not distinct customers.',
    outcome: 'apply',
    expectation:
      'Complexity 1/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'donut',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V007',
    title: 'V007 · Resolved cases by contact channel',
    category: 'charts',
    prompt:
      'Show a pie of resolved case counts by contact channel. Exclude cancelled and still-open cases.',
    outcome: 'apply',
    expectation:
      'Complexity 1/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'pie',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V008',
    title: 'V008 · Typical first response by team',
    category: 'charts',
    prompt:
      'Compare average first-response time by support team using horizontal bars in minutes. Exclude missing response times from the average; do not make them zero.',
    outcome: 'apply',
    expectation:
      'Complexity 2/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V009',
    title: 'V009 · Typical resolution by service',
    category: 'charts',
    prompt:
      'Use a column chart to compare average resolution duration in hours for resolved cases by service. Do not include open or cancelled cases.',
    outcome: 'apply',
    expectation:
      'Complexity 1/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V010',
    title: 'V010 · Impact by issue class',
    category: 'charts',
    prompt:
      'Sum affected user incidences by issue type and show horizontal bars. Label the measure user-case incidences, not unique people.',
    outcome: 'apply',
    expectation:
      'Complexity 1/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V011',
    title: 'V011 · Monthly arrivals',
    category: 'charts',
    prompt:
      'Show a chronological line of cases opened in each calendar month from July 2025 through June 2026. Include all twelve months.',
    outcome: 'apply',
    expectation:
      'Complexity 1/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'line',
    requirements: [
      'calendar_or_category_domain',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V012',
    title: 'V012 · Weekly Q2 workload',
    category: 'charts',
    prompt:
      'Show weekly case-opening volume for April through June 2026 as an area chart. Weeks start Monday in UTC; label the boundary weeks as partial when they cross the selected range.',
    outcome: 'apply',
    expectation:
      'Complexity 2/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'area',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V013',
    title: 'V013 · March daily arrivals',
    category: 'charts',
    prompt:
      'Show daily case-opening counts for March 2026 as a line. Include all 31 UTC dates, fill missing count dates with zero, and sort chronologically.',
    outcome: 'apply',
    expectation:
      'Complexity 2/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'line',
    requirements: [
      'calendar_or_category_domain',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V014',
    title: 'V014 · Monthly labor expense',
    category: 'charts',
    prompt:
      'Plot total labor cost in USD by opening month from July 2025 through June 2026 as a line, in chronological order.',
    outcome: 'apply',
    expectation:
      'Complexity 1/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'line',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V015',
    title: 'V015 · Revenue and contribution trend',
    category: 'charts',
    prompt:
      'For each opening month, plot net revenue as columns and contribution profit as a line on the same USD axis. Include losses and all cases, including zero-revenue cases.',
    outcome: 'apply',
    expectation:
      'Complexity 2/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'columnLineCombo',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V016',
    title: 'V016 · Weekday arrival pattern',
    category: 'charts',
    prompt:
      'Count openings by UTC weekday as columns ordered Monday through Sunday. These are total counts, not average volume per day.',
    outcome: 'apply',
    expectation:
      'Complexity 1/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V017',
    title: 'V017 · Hour-of-day workload',
    category: 'charts',
    prompt:
      'Count openings by UTC hour in columns ordered 0 through 23. Treat the hour as a category, not an amount to aggregate.',
    outcome: 'apply',
    expectation:
      'Complexity 1/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V018',
    title: 'V018 · Quarterly resolved cohorts',
    category: 'charts',
    prompt:
      'Count cases currently resolved by their calendar opening quarter, as columns in chronological quarter order. Label this an opening-cohort view, not cases resolved in that quarter.',
    outcome: 'apply',
    expectation:
      'Complexity 2/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V019',
    title: 'V019 · Resolution events by closing month',
    category: 'charts',
    prompt:
      'Show monthly resolution-event counts as a line, grouped by final exit month rather than opening month. Include only Resolved cases and use all available source opening dates.',
    outcome: 'apply',
    expectation:
      'Complexity 2/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'line',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V020',
    title: 'V020 · Daily February critical arrivals',
    category: 'charts',
    prompt:
      'Show P1 case openings for every day of February 2026 as an area chart. Fill missing dates with zero and preserve chronological order.',
    outcome: 'apply',
    expectation:
      'Complexity 2/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'area',
    requirements: [
      'calendar_or_category_domain',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V021',
    title: 'V021 · Two regions and two priorities',
    category: 'charts',
    prompt:
      'Show case counts by service as horizontal bars for (North America OR Europe) AND (P1 OR P2). Preserve both OR groups under one AND.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V022',
    title: 'V022 · Paired regional channel scopes',
    category: 'charts',
    prompt:
      'For January through March 2026, count cases by service in columns where (region is North America AND channel is Phone) OR (region is Europe AND channel is Portal). Apply the date restriction to both branches.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V023',
    title: 'V023 · Bounded resolution duration',
    category: 'charts',
    prompt:
      'For resolved cases with resolution duration at least 8 hours and strictly less than 48 hours, count cases by priority in columns.',
    outcome: 'apply',
    expectation:
      'Complexity 2/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V024',
    title: 'V024 · Missing causes in resolved work',
    category: 'charts',
    prompt:
      'Among resolved cases whose root cause is null OR an empty string, show case counts by contact channel as horizontal bars. Do not include every unresolved case merely because its root cause is blank.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V025',
    title: 'V025 · Digital non-cancelled workload',
    category: 'charts',
    prompt:
      'For April through June 2026, exclude Cancelled cases, keep Chat OR API channels, and show monthly case counts as a line.',
    outcome: 'apply',
    expectation:
      'Complexity 2/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'line',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V026',
    title: 'V026 · Cost exception or criticality',
    category: 'charts',
    prompt:
      'Within February 2026, count cases by issue type in columns when labor cost is greater than 300 USD OR priority is P1. The February restriction must apply to either condition.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V027',
    title: 'V027 · Exclusion-based status mix',
    category: 'charts',
    prompt:
      'Create a status donut for cases outside APAC and not opened by Email. Keep all statuses and apply both exclusions together.',
    outcome: 'apply',
    expectation:
      'Complexity 2/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'donut',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V028',
    title: 'V028 · Service text search',
    category: 'charts',
    prompt:
      'Count cases by region in columns for services whose name contains Data, using case-insensitive matching. Do not confuse the service field with business unit.',
    outcome: 'apply',
    expectation:
      'Complexity 2/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V029',
    title: 'V029 · Known cause distribution',
    category: 'charts',
    prompt:
      'For resolved cases with a non-null, non-empty root cause, show counts by root cause as horizontal bars. Exclude missing causes instead of relabeling them as a real cause.',
    outcome: 'apply',
    expectation:
      'Complexity 2/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V030',
    title: 'V030 · Low-priority assisted work',
    category: 'charts',
    prompt:
      'Count cases by service as columns when automation assisted the case AND it was not escalated AND priority was P3 OR P4. The priority alternatives must form one group.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V031',
    title: 'V031 · Outcome counts by region',
    category: 'charts',
    prompt:
      'Create stacked columns by region with resolved, still-open, and cancelled case counts. Sum the three mutually exclusive case indicators.',
    outcome: 'apply',
    expectation:
      'Complexity 2/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'stackedColumn',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V032',
    title: 'V032 · Outcome percentages by channel',
    category: 'charts',
    prompt:
      'Create 100% stacked columns by channel for resolved, still-open, and cancelled case counts. Normalize within each channel; keep the underlying counts for tooltips.',
    outcome: 'apply',
    expectation:
      'Complexity 2/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'normalizedColumn',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V033',
    title: 'V033 · Service priority composition',
    category: 'charts',
    prompt:
      'Show stacked horizontal bars of case counts by service, with a separate series for each priority in P1-to-P4 legend order.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'stackedBar',
    requirements: [
      'group_aggregate',
      'pivot_or_conditional_series',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V034',
    title: 'V034 · Regional issue-type share',
    category: 'charts',
    prompt:
      'Show a 100% stacked horizontal bar per region, split into issue types. Compute percentages from case counts inside each region.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'normalizedBar',
    requirements: [
      'group_aggregate',
      'pivot_or_conditional_series',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V035',
    title: 'V035 · Channel volume over time',
    category: 'charts',
    prompt:
      'Create a stacked area chart of monthly case openings, with a series for each contact channel and chronological month order.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'stackedArea',
    requirements: [
      'group_aggregate',
      'pivot_or_conditional_series',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V036',
    title: 'V036 · Regional share over time',
    category: 'charts',
    prompt:
      'Create a 100% stacked area chart of monthly case openings by region. Normalize each month, not the whole year.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'normalizedArea',
    requirements: [
      'group_aggregate',
      'pivot_or_conditional_series',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V037',
    title: 'V037 · Cumulative stack by priority',
    category: 'charts',
    prompt:
      "Create a stacked line chart of monthly opening counts by priority in P1-to-P4 series order. Use the chart's stacked-line display, not a running total across months.",
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'stackedLine',
    requirements: [
      'group_aggregate',
      'pivot_or_conditional_series',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V038',
    title: 'V038 · Tier shares as normalized lines',
    category: 'charts',
    prompt:
      'Create a normalized stacked line chart of monthly case counts by support tier. Each month must represent 100% across Premium, Standard and Basic. This is not month-over-month growth.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'normalizedLine',
    requirements: [
      'group_aggregate',
      'pivot_or_conditional_series',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V039',
    title: 'V039 · Quarterly regional comparison',
    category: 'charts',
    prompt:
      'For each calendar opening quarter, show side-by-side columns of case volume for the four regions. Keep a stable region legend and chronological quarters.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: [
      'group_aggregate',
      'pivot_or_conditional_series',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V040',
    title: 'V040 · Cost components by team',
    category: 'charts',
    prompt:
      'Show stacked horizontal bars of labor cost, vendor cost and service credits by support team in USD. Label this cost and credit composition, not revenue.',
    outcome: 'apply',
    expectation:
      'Complexity 2/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'stackedBar',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V041',
    title: 'V041 · Resolution distribution up to 72 hours',
    category: 'charts',
    prompt:
      'For resolved cases with resolution duration from 0 through 72 hours inclusive, create a frequency histogram using twelve equal 6-hour bins. Exclude nulls and disclose that durations above 72 hours are outside the requested scope.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'histogram',
    requirements: ['histogram_binning', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V042',
    title: 'V042 · First-response distribution',
    category: 'charts',
    prompt:
      'Histogram valid first-response durations from 0 through 120 minutes using twelve 10-minute bins. Count observations, and do not convert missing responses to zero.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'histogram',
    requirements: ['histogram_binning', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V043',
    title: 'V043 · Handling-effort distribution',
    category: 'charts',
    prompt:
      'Show a histogram of handling effort from 0 through 240 minutes inclusive in twelve 20-minute bins. State the upper-bound restriction.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'histogram',
    requirements: ['histogram_binning', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V044',
    title: 'V044 · Billed-amount distribution',
    category: 'charts',
    prompt:
      'Show a frequency histogram of billed USD between 0 and 500 inclusive with ten 50-dollar bins. Retain zero-billed cases.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'histogram',
    requirements: ['histogram_binning', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V045',
    title: 'V045 · Current open-case aging',
    category: 'charts',
    prompt:
      "For currently open cases aged no more than 1000 hours at the fixed snapshot, show an age histogram using ten 100-hour bins. Do not use resolution duration or the computer's current date.",
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'histogram',
    requirements: ['histogram_binning', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V046',
    title: 'V046 · Handling versus labor, bounded sample',
    category: 'charts',
    prompt:
      'For resolved North America cases, scatter handling minutes on X against labor cost USD on Y. Plot the first 400 valid cases in ascending case-reference order, one point per case, and label this a deterministic subset, not a representative sample.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'scatter',
    requirements: ['bounded_raw_points', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V047',
    title: 'V047 · Impact versus resolution, bounded sample',
    category: 'charts',
    prompt:
      'For resolved P1 cases, scatter affected user incidences on X against resolution hours on Y. Use the first 500 valid cases by ascending case reference. Do not aggregate points by region or imply a causal relationship.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'scatter',
    requirements: ['bounded_raw_points', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V048',
    title: 'V048 · Team response versus satisfaction',
    category: 'charts',
    prompt:
      'Make one scatter point per support team: average first-response minutes on X and mean survey score on Y. Use resolved cases, average each measure over its own non-null values, and require at least 50 survey responses per team.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'scatter',
    requirements: [
      'group_aggregate',
      'having',
      'mixed_aggregates',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V049',
    title: 'V049 · Service resolution and contribution bubbles',
    category: 'charts',
    prompt:
      'Use one bubble per service among resolved cases: mean resolution hours on X, total contribution USD on Y, and resolved case count for bubble size. Preserve negative contribution.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'bubble',
    requirements: [
      'group_aggregate',
      'mixed_aggregates',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V050',
    title: 'V050 · Client cost bubbles',
    category: 'charts',
    prompt:
      'Select the twelve clients with the largest total billed USD, ranking after aggregation. Show vendor cost USD on X, labor cost USD on Y and total billed USD as bubble size. Label clients only inside the authorized application.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'bubble',
    requirements: [
      'group_aggregate',
      'post_aggregate_ranking',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V051',
    title: 'V051 · SLA compliance by service',
    category: 'charts',
    prompt:
      'Compare resolution SLA met percentage by service as columns. Calculate 100 times total met cases divided by total eligible resolved cases. Exclude open and cancelled cases from the denominator.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: [
      'custom_aggregate_or_summary',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V052',
    title: 'V052 · Monthly SLA breach rate',
    category: 'charts',
    prompt:
      'Show monthly SLA breach percentage by opening month as a line: breached cases divided by eligible resolved cases times 100. Use null, not zero, when there is no eligible denominator.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'line',
    requirements: [
      'custom_aggregate_or_summary',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V053',
    title: 'V053 · Reopened-case rate by tier',
    category: 'charts',
    prompt:
      'Compare the percentage of resolved cases that were reopened at least once by support tier in columns. Divide reopened-case count by resolved-case count; do not divide reopen-event count by all cases.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: [
      'custom_aggregate_or_summary',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V054',
    title: 'V054 · Survey response rate by channel',
    category: 'charts',
    prompt:
      'Show survey response percentage by channel as horizontal bars. The denominator is resolved cases, and the numerator is cases with a survey response.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: [
      'custom_aggregate_or_summary',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V055',
    title: 'V055 · Satisfied respondent rate by team',
    category: 'charts',
    prompt:
      'Show the percentage of survey respondents scoring 4 or 5 for each support team in columns. Divide satisfied responses by survey responses, not by total cases.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: [
      'custom_aggregate_or_summary',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V056',
    title: 'V056 · Mean survey score by service',
    category: 'charts',
    prompt:
      'Compare average non-null survey score by service in horizontal bars. Use the original responded-case scores, not an unweighted average of monthly team averages.',
    outcome: 'apply',
    expectation:
      'Complexity 2/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V057',
    title: 'V057 · Contribution margin by business unit',
    category: 'charts',
    prompt:
      'Show contribution margin by business unit as columns: 100 times summed contribution divided by summed net revenue. Include zero-revenue cases and their costs in the numerator. Never average individual case margins.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: [
      'custom_aggregate_or_summary',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V058',
    title: 'V058 · Revenue per user-case incidence',
    category: 'charts',
    prompt:
      'Compare net revenue USD per affected user-case incidence by region using horizontal bars. Divide regional total net revenue by regional total affected-user incidences. Do not call this revenue per unique user.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: [
      'custom_aggregate_or_summary',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V059',
    title: 'V059 · Realized billing rate by tier',
    category: 'charts',
    prompt:
      'Compare billed USD per billable hour by support tier as columns. Divide summed billed USD by summed billable hours; do not average individual case rates.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: [
      'custom_aggregate_or_summary',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V060',
    title: 'V060 · Response duration in hours',
    category: 'charts',
    prompt:
      'Show mean first-response duration by contact channel in hours using columns. Average non-null minutes and divide by 60; label the axis hours.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: [
      'approved_unit_conversion',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V061',
    title: 'V061 · Highest billed clients',
    category: 'charts',
    prompt:
      'Show the seven clients with the largest total billed USD as horizontal bars, sorted descending after aggregation. Break ties by client name ascending. Do not select seven individual cases.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: [
      'group_aggregate',
      'post_aggregate_ranking',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V062',
    title: 'V062 · Largest SLA-breach volumes',
    category: 'charts',
    prompt:
      'Show the five services with the highest total SLA-breached case count as columns, ranked after summing the breach indicator. Break ties alphabetically.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: [
      'group_aggregate',
      'post_aggregate_ranking',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V063',
    title: 'V063 · Lowest satisfaction with adequate responses',
    category: 'charts',
    prompt:
      'Show the five support teams with the lowest satisfied-respondent percentage, but only teams with at least 100 responses. Apply the minimum sample-size condition after grouping, then rank ascending.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: [
      'custom_aggregate_or_summary',
      'group_aggregate',
      'having',
      'mixed_aggregates',
      'post_aggregate_ranking',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V064',
    title: 'V064 · Services above a total-cost threshold',
    category: 'charts',
    prompt:
      'Show services with total labor cost above 100000 USD as horizontal bars, ordered by total labor cost descending. This threshold applies to the service total, not individual case costs.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: ['group_aggregate', 'having', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V065',
    title: 'V065 · High-volume clients with weak SLA',
    category: 'charts',
    prompt:
      'Among clients with at least 150 cases and at least 100 SLA-eligible cases, show the ten lowest SLA met rates as horizontal bars. Apply both volume thresholds after grouping and use name ascending to break ties.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: [
      'custom_aggregate_or_summary',
      'group_aggregate',
      'having',
      'mixed_aggregates',
      'post_aggregate_ranking',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V066',
    title: 'V066 · Top channels plus Other',
    category: 'charts',
    prompt:
      'Show a pie of case counts for the three largest channels plus an Other slice containing every remaining channel. Rank channel totals first, and preserve the total case count.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'pie',
    requirements: [
      'group_aggregate',
      'other_bucket',
      'post_aggregate_ranking',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V067',
    title: 'V067 · Top services billed share plus Other',
    category: 'charts',
    prompt:
      'Show a donut of billed USD for the five largest services plus one Other slice for the remaining services. Rank summed billed USD, and ensure the slices reconcile to the full total.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'donut',
    requirements: [
      'group_aggregate',
      'other_bucket',
      'post_aggregate_ranking',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V068',
    title: 'V068 · Critical workload team ranking',
    category: 'charts',
    prompt:
      'Show the five teams with the most P1 cases as columns. Filter P1 first, aggregate by team, then rank descending with alphabetical tie-breaking.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: [
      'group_aggregate',
      'post_aggregate_ranking',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V069',
    title: 'V069 · Escalation contribution by service',
    category: 'charts',
    prompt:
      'For escalated cases, show total contribution by service as horizontal bars ordered from lowest to highest. Keep negative totals and use a zero baseline; do not use a pie.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V070',
    title: 'V070 · Top services inside each region',
    category: 'charts',
    prompt:
      'Show the two largest services by case count within each region, not the largest two services globally. Use horizontal bars labeled Region / Service, group the display by region, and break ties by service name.',
    outcome: 'apply',
    expectation:
      'Complexity 5/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: [
      'group_aggregate',
      'partitioned_ranking',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V071',
    title: 'V071 · Volume and response trend',
    category: 'charts',
    prompt:
      'By opening month, show case count as columns on the left axis and mean first-response minutes as a line on a separate right axis. Exclude null responses only from the average, not from case volume.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'customCombo',
    requirements: [
      'group_aggregate',
      'mixed_aggregates',
      'secondary_axis',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V072',
    title: 'V072 · Budget and actual labor trend',
    category: 'charts',
    prompt:
      'By opening month, show total allocated case labor budget as columns and actual labor cost as a line, sharing one USD axis. Do not claim the allocated case budget is a company-wide budget.',
    outcome: 'apply',
    expectation:
      'Complexity 2/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'columnLineCombo',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V073',
    title: 'V073 · Team cost and SLA combination',
    category: 'charts',
    prompt:
      'For each team, show summed labor and vendor USD as side-by-side columns on the left axis and SLA met rate as a line on a right percent axis. Compute the rate from summed eligible and met counts.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'customCombo',
    requirements: [
      'custom_aggregate_or_summary',
      'group_aggregate',
      'mixed_aggregates',
      'secondary_axis',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V074',
    title: 'V074 · Labor area and vendor columns',
    category: 'charts',
    prompt:
      'By opening month, show total labor cost as an area and total vendor cost as columns on the same USD axis. Do not cumulatively sum months.',
    outcome: 'apply',
    expectation:
      'Complexity 2/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'areaColumnCombo',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V075',
    title: 'V075 · Monthly cost components as lines',
    category: 'charts',
    prompt:
      'Show monthly labor cost, vendor cost and service credits as three separate unstacked lines sharing a USD axis. Sum each measure by opening month.',
    outcome: 'apply',
    expectation:
      'Complexity 2/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'line',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V076',
    title: 'V076 · SLA counts and eligible total',
    category: 'charts',
    prompt:
      'By opening month, show met and breached counts as stacked columns and eligible resolved-case count as a line on the same cases axis. The line must equal the combined column height.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'customCombo',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V077',
    title: 'V077 · Response and resolution on a common unit',
    category: 'charts',
    prompt:
      'For resolved cases, compare mean first-response time and mean resolution time by service as grouped columns. Convert mean first-response minutes to hours before plotting so both series share an hours axis.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: [
      'approved_unit_conversion',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V078',
    title: 'V078 · Minimum mean and maximum duration',
    category: 'charts',
    prompt:
      'For resolved cases, show minimum, mean and maximum resolution hours by priority as grouped horizontal bars in P1-to-P4 order. Compute each statistic independently from raw case durations.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: [
      'group_aggregate',
      'mixed_aggregates',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V079',
    title: 'V079 · Monthly and cumulative arrivals',
    category: 'charts',
    prompt:
      'Show monthly case counts as columns and a cumulative count from July 2025 as a line on a separately labeled right axis. Aggregate monthly counts before computing the running total.',
    outcome: 'apply',
    expectation:
      'Complexity 5/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'customCombo',
    requirements: [
      'group_aggregate',
      'secondary_axis',
      'server_authorization',
      'typed_filter_validation',
      'window_functions',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V080',
    title: 'V080 · Cumulative revenue and monthly vendor costs',
    category: 'charts',
    prompt:
      'Plot cumulative net revenue since July 2025 as an area and monthly vendor cost as columns on a shared USD axis. Clearly distinguish the cumulative measure from the monthly measure.',
    outcome: 'apply',
    expectation:
      'Complexity 5/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'areaColumnCombo',
    requirements: [
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
      'window_functions',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V081',
    title: 'V081 · Cumulative opened cases',
    category: 'charts',
    prompt:
      'Show a line of cumulative cases opened since July 1, 2025, with one point per month. Aggregate monthly counts, then compute a running sum in chronological order.',
    outcome: 'apply',
    expectation:
      'Complexity 5/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'line',
    requirements: [
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
      'window_functions',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V082',
    title: 'V082 · Three-month moving average',
    category: 'charts',
    prompt:
      'Show the trailing three-calendar-month moving average of monthly case-opening counts as a line. July and August must be null because a full three-month window is unavailable.',
    outcome: 'apply',
    expectation:
      'Complexity 5/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'line',
    requirements: [
      'calendar_or_category_domain',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
      'window_functions',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V083',
    title: 'V083 · Month-over-month arrival growth',
    category: 'charts',
    prompt:
      'Show month-over-month percentage change in case openings as a line. First aggregate monthly counts, compare each month with its immediate predecessor, and leave the first month null. A zero predecessor means null, not infinity.',
    outcome: 'apply',
    expectation:
      'Complexity 5/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'line',
    requirements: [
      'calendar_or_category_domain',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
      'window_functions',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V084',
    title: 'V084 · Cumulative contribution profit',
    category: 'charts',
    prompt:
      'Show cumulative contribution profit by opening month as a line from July 2025. Include negative case contributions; the series is allowed to fall.',
    outcome: 'apply',
    expectation:
      'Complexity 5/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'line',
    requirements: [
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
      'window_functions',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V085',
    title: 'V085 · Weighted rolling SLA performance',
    category: 'charts',
    prompt:
      'Plot the trailing three-month SLA met rate by opening month. Sum met counts and eligible counts across each complete window, then divide; do not average monthly percentages. Leave the first two months null.',
    outcome: 'apply',
    expectation:
      'Complexity 5/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'line',
    requirements: [
      'calendar_or_category_domain',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
      'window_functions',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V086',
    title: 'V086 · Median and tail resolution by service',
    category: 'charts',
    prompt:
      'For resolved cases, compare median and 90th-percentile resolution duration by service as grouped columns. Use linear-interpolated continuous percentiles over original non-null case durations, not percentiles of group averages.',
    outcome: 'apply',
    expectation:
      'Complexity 5/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: [
      'continuous_percentile',
      'group_aggregate',
      'mixed_aggregates',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V087',
    title: 'V087 · Monthly tail latency',
    category: 'charts',
    prompt:
      'Show the 90th-percentile resolution duration of resolved cases by opening month as a line. Use the continuous, linearly interpolated percentile of case durations in each cohort.',
    outcome: 'apply',
    expectation:
      'Complexity 5/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'line',
    requirements: [
      'continuous_percentile',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V088',
    title: 'V088 · Case-lifetime inventory at month end',
    category: 'charts',
    prompt:
      "Show the number of cases whose opening-to-final-exit interval spans each month-end snapshot as a line. Evaluate immediately before the next month starts: opening is before the cutoff and final exit is null or at/after it. Use opening/final-exit timestamps, not today's open indicator. Do not claim to reconstruct intermediate reopen states.",
    outcome: 'apply',
    expectation:
      'Complexity 5/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'line',
    requirements: ['server_authorization', 'snapshot_interval_query', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V089',
    title: 'V089 · Cancellation events by month',
    category: 'charts',
    prompt:
      'Show cancelled-case counts by final exit month as columns. Group by cancellation month, not opening month, and exclude all other outcomes.',
    outcome: 'apply',
    expectation:
      'Complexity 2/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V090',
    title: 'V090 · Resolved share of opening cohorts',
    category: 'charts',
    prompt:
      'By opening month, show the percentage of cases resolved at the fixed July 1 snapshot. Divide resolved cases by all cases in the cohort and label the chart as cohort resolution-to-date, not SLA success. Note that recent cohorts have less follow-up.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'line',
    requirements: [
      'custom_aggregate_or_summary',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V091',
    title: 'V091 · Missing cause rate',
    category: 'charts',
    prompt:
      'Among resolved cases, show the percentage with null or empty root cause by service as columns. A blank cause counts as missing, not as an invented category.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: [
      'custom_aggregate_or_summary',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V092',
    title: 'V092 · Normalized operational tags',
    category: 'charts',
    prompt:
      'Count cases by operational tag as horizontal bars after trimming whitespace and lowercasing. Merge null, empty and whitespace-only tags into Unknown. Use an approved read-only grouping expression; do not modify stored tags.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: [
      'approved_derived_dimension',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V093',
    title: 'V093 · Positive zero and negative revenue',
    category: 'charts',
    prompt:
      'Show 100% stacked columns by region for cases with positive, zero, or negative net revenue. Classify each case by its own net amount, count cases per band, and normalize within region.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'normalizedColumn',
    requirements: [
      'approved_derived_dimension',
      'group_aggregate',
      'pivot_or_conditional_series',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V094',
    title: 'V094 · Survey score distribution',
    category: 'charts',
    prompt:
      'Histogram non-null survey scores using one bin per integer score, with edges 0.5, 1.5, 2.5, 3.5, 4.5 and 5.5. Exclude nonresponses instead of adding a zero-score bucket.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'histogram',
    requirements: ['histogram_binning', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V095',
    title: 'V095 · Optional-score completeness',
    category: 'charts',
    prompt:
      'Show the missing optional-review-score percentage by channel as horizontal bars. Use all cases in the denominator; a null score is missing, not zero.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: [
      'custom_aggregate_or_summary',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V096',
    title: 'V096 · Distinct clients served by region',
    category: 'charts',
    prompt:
      'Show distinct client counts by region in columns within the authorized tenant. Count unique client identifiers, not case rows or unique display names. Do not send the client inventory to the LLM.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: [
      'distinct_aggregate',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V097',
    title: 'V097 · Native GBP billing by service',
    category: 'charts',
    prompt:
      'For GBP-denominated cases only, show total native billed amount by service as horizontal bars labeled GBP. Do not mix native USD, EUR or JPY into these totals.',
    outcome: 'apply',
    expectation:
      'Complexity 2/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V098',
    title: 'V098 · Converted billing by native currency',
    category: 'charts',
    prompt:
      'Show a stacked area chart of monthly billed USD with one series per original billing currency. All plotted amounts must be the preconverted USD values, not a sum of mixed local amounts.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'stackedArea',
    requirements: [
      'group_aggregate',
      'pivot_or_conditional_series',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V099',
    title: 'V099 · Resolution relative to the target',
    category: 'charts',
    prompt:
      'Among resolved cases, count cases in four exclusive duration-to-target bands as columns: at most 50%, over 50% through 100%, over 100% through 200%, and over 200%. Compare each case with its own target and keep that band order.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: [
      'approved_derived_dimension',
      'calendar_or_category_domain',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V100',
    title: 'V100 · Signed service contribution',
    category: 'charts',
    prompt:
      'Show total contribution profit by service as horizontal bars. Retain both positive and negative values around a zero baseline and sort services alphabetically. Do not take absolute values or use a pie chart.',
    outcome: 'apply',
    expectation:
      'Complexity 2/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V101',
    title: 'V101 · Status pie: Europe only',
    category: 'charts',
    prompt:
      'Keep the existing status pie and change only the region filter to Europe. Update this widget rather than creating another one.',
    outcome: 'sequence',
    expectation:
      'Complexity 3/5. Run V001 first. Preserve the existing widget and untouched filters. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'pie',
    requirements: [
      'Run V001 first; apply this as a follow-up to that chart.',
      'group_aggregate',
      'server_authorization',
      'state_patch_preservation',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: 'V001',
  },
  {
    id: 'V102',
    title: 'V102 · Status pie: replace Europe with APAC',
    category: 'charts',
    prompt:
      'On the same status pie, replace Europe with APAC. Do not add APAC alongside Europe. Preserve the measure, chart type, tenant scope and widget identity.',
    outcome: 'sequence',
    expectation:
      'Complexity 3/5. Run V101 first. Preserve the existing widget and untouched filters. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'pie',
    requirements: [
      'Run V101 first; apply this as a follow-up to that chart.',
      'group_aggregate',
      'server_authorization',
      'state_patch_preservation',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: 'V101',
  },
  {
    id: 'V103',
    title: 'V103 · Resolution comparison: Q1',
    category: 'charts',
    prompt:
      'Keep the existing average-resolution-by-service column chart and add an opening-date range of January 1 through March 31, 2026. Preserve the Resolved restriction and hours units.',
    outcome: 'sequence',
    expectation:
      'Complexity 3/5. Run V009 first. Preserve the existing widget and untouched filters. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: [
      'Run V009 first; apply this as a follow-up to that chart.',
      'group_aggregate',
      'server_authorization',
      'state_patch_preservation',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: 'V009',
  },
  {
    id: 'V104',
    title: 'V104 · Resolution comparison: Q2 replacement',
    category: 'charts',
    prompt:
      "Change that chart's opening-date range to April 1 through June 30, 2026. Replace the old date range; preserve the Resolved filter, service grouping and average-duration metric.",
    outcome: 'sequence',
    expectation:
      'Complexity 3/5. Run V103 first. Preserve the existing widget and untouched filters. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: [
      'Run V103 first; apply this as a follow-up to that chart.',
      'group_aggregate',
      'server_authorization',
      'state_patch_preservation',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: 'V103',
  },
  {
    id: 'V105',
    title: 'V105 · Outcomes: horizontal orientation',
    category: 'charts',
    prompt:
      'Keep the same regional outcome counts and filters, but change the stacked columns into stacked horizontal bars. Do not change counts into percentages.',
    outcome: 'sequence',
    expectation:
      'Complexity 3/5. Run V031 first. Preserve the existing widget and untouched filters. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'stackedBar',
    requirements: [
      'Run V031 first; apply this as a follow-up to that chart.',
      'group_aggregate',
      'server_authorization',
      'state_patch_preservation',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: 'V031',
  },
  {
    id: 'V106',
    title: 'V106 · Outcomes: percentage mode',
    category: 'charts',
    prompt:
      'Keep the same regional outcome chart and change it into 100% stacked horizontal bars. Normalize within each region; preserve raw counts for tooltips and do not rewrite the source data.',
    outcome: 'sequence',
    expectation:
      'Complexity 3/5. Run V105 first. Preserve the existing widget and untouched filters. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'normalizedBar',
    requirements: [
      'Run V105 first; apply this as a follow-up to that chart.',
      'group_aggregate',
      'server_authorization',
      'state_patch_preservation',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: 'V105',
  },
  {
    id: 'V107',
    title: 'V107 · Top clients: Premium scope',
    category: 'charts',
    prompt:
      'Keep the top-seven-clients billed-USD chart, but filter to Premium support. Recompute client totals and the top seven inside that scope. Do not reuse the old seven clients.',
    outcome: 'sequence',
    expectation:
      'Complexity 4/5. Run V061 first. Preserve the existing widget and untouched filters. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: [
      'Run V061 first; apply this as a follow-up to that chart.',
      'group_aggregate',
      'post_aggregate_ranking',
      'server_authorization',
      'state_patch_preservation',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: 'V061',
  },
  {
    id: 'V108',
    title: 'V108 · Top clients: Basic replacement',
    category: 'charts',
    prompt:
      'Replace the Premium filter with Basic on the same client ranking chart. Keep seven clients, billed USD, descending aggregate ranking and alphabetical tie-breaking.',
    outcome: 'sequence',
    expectation:
      'Complexity 4/5. Run V107 first. Preserve the existing widget and untouched filters. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: [
      'Run V107 first; apply this as a follow-up to that chart.',
      'group_aggregate',
      'post_aggregate_ranking',
      'server_authorization',
      'state_patch_preservation',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: 'V107',
  },
  {
    id: 'V109',
    title: 'V109 · Volume and response: Email scope',
    category: 'charts',
    prompt:
      'Keep the dual-axis monthly volume-and-response chart and filter the contact channel to Email. Apply the filter to both measures, retain null-safe response averaging and preserve both axis units.',
    outcome: 'sequence',
    expectation:
      'Complexity 4/5. Run V071 first. Preserve the existing widget and untouched filters. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'customCombo',
    requirements: [
      'Run V071 first; apply this as a follow-up to that chart.',
      'group_aggregate',
      'mixed_aggregates',
      'secondary_axis',
      'server_authorization',
      'state_patch_preservation',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: 'V071',
  },
  {
    id: 'V110',
    title: 'V110 · Volume and response: Portal replacement',
    category: 'charts',
    prompt:
      'Replace Email with Portal on the same dual-axis chart. Preserve monthly grouping, case-count columns, mean-response line, axis assignments and widget identity.',
    outcome: 'sequence',
    expectation:
      'Complexity 4/5. Run V109 first. Preserve the existing widget and untouched filters. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'customCombo',
    requirements: [
      'Run V109 first; apply this as a follow-up to that chart.',
      'group_aggregate',
      'mixed_aggregates',
      'secondary_axis',
      'server_authorization',
      'state_patch_preservation',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: 'V109',
  },
  {
    id: 'V111',
    title: 'V111 · Weekday and weekend hourly profiles',
    category: 'charts',
    prompt:
      'Compare hourly case-opening counts with separate unstacked lines for weekdays and weekends. Use UTC hour 0 through 23 and define weekends as Saturday and Sunday. These are total counts, not normalized average-day rates.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'line',
    requirements: [
      'approved_derived_dimension',
      'group_aggregate',
      'pivot_or_conditional_series',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V112',
    title: 'V112 · Budget variance combination',
    category: 'charts',
    prompt:
      'By opening month, show allocated case labor budget and actual labor cost as grouped USD columns, plus labor budget variance percentage as a line on a right axis. Variance is 100 times (actual total minus budget total) divided by budget total.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'customCombo',
    requirements: [
      'approved_unit_conversion',
      'custom_aggregate_or_summary',
      'group_aggregate',
      'mixed_aggregates',
      'secondary_axis',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V113',
    title: 'V113 · Priority SLA composition',
    category: 'charts',
    prompt:
      'For SLA-eligible resolved cases, show 100% stacked columns by priority with met and breached counts as the two series. Do not include open or cancelled cases in either stack denominator.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'normalizedColumn',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V114',
    title: 'V114 · Resolved cohort volumes by contract tier',
    category: 'charts',
    prompt:
      'Show stacked columns of resolved case counts by calendar opening quarter, with Premium, Standard and Basic series. Keep chronological quarter order and label the view as opening cohorts.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'stackedColumn',
    requirements: [
      'group_aggregate',
      'pivot_or_conditional_series',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V115',
    title: 'V115 · Region and business-unit contribution',
    category: 'charts',
    prompt:
      'For North America or Europe, show total contribution USD for each Region / Business Unit combination as horizontal bars. Group labels by region, retain negative totals, and never combine the two regions into one category.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V116',
    title: 'V116 · Teams requiring a satisfaction review',
    category: 'charts',
    prompt:
      'Show average survey score by support team as horizontal bars only for teams with at least 100 responses and an average score below 4.15. Apply both conditions after aggregation and order from lowest average score to highest.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: [
      'group_aggregate',
      'having',
      'mixed_aggregates',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
  {
    id: 'V117',
    title: 'V117 · Scoped client effort trend',
    category: 'charts',
    prompt:
      'Show monthly total handling minutes for the selected client Cedar & Vale as a line. Resolve the selected client privately, preserve the tenant restriction, and do not disclose the literal name to the LLM.',
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'line',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V118',
    title: 'V118 · Literal punctuation in client scope',
    category: 'charts',
    prompt:
      "For the selected client Orion's 100% Services, show a donut of case counts by issue type. Resolve the client privately and match the full name literally; the apostrophe and percent sign are not SQL syntax or wildcards.",
    outcome: 'apply',
    expectation:
      'Complexity 3/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'donut',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V119',
    title: 'V119 · Critical dependency exceptions',
    category: 'charts',
    prompt:
      'For cases opened June 1 through June 7, 2026 inclusive, show breached resolved-case counts by service as columns where priority is P1 OR P2 AND root cause is Dependency OR Capacity. Both alternatives are separate OR groups under the same AND, along with the date and breached-case restrictions.',
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedColumn',
    requirements: ['group_aggregate', 'server_authorization', 'typed_filter_validation'],
    benchmarkBaseCase: null,
  },
  {
    id: 'V120',
    title: 'V120 · Contribution per billable hour',
    category: 'charts',
    prompt:
      "For resolved cases, compare total contribution USD per billable hour by service as horizontal bars. Include zero-billable-hour cases and their losses in the group numerator; divide by the group's total billable hours and return null for a zero denominator.",
    outcome: 'apply',
    expectation:
      'Complexity 4/5. Benchmark prompt only. No reference graph or answer plan is loaded into the assistant. Verify the result against the offline benchmark.',
    fields: [],
    chartType: 'groupedBar',
    requirements: [
      'custom_aggregate_or_summary',
      'group_aggregate',
      'server_authorization',
      'typed_filter_validation',
    ],
    benchmarkBaseCase: null,
  },
];
