/** Deterministic, entirely synthetic examples; no customer or patient records. */
const round = (value, places = 2) => Number(value.toFixed(places));
const column = (id, label, kind, groupByTag, description, extra = {}) => ({
  id,
  label,
  kind,
  aliases: [label.toLowerCase()],
  nullable: false,
  sql: id,
  description,
  chartRole: kind === 'number' ? 'measure' : kind === 'date' ? 'temporal' : 'dimension',
  groupByTag,
  ...extra,
});
const number = (id, label, group, description, unit = null) =>
  column(id, label, 'number', group, description, { unit, scale: 2 });
const text = (id, label, group, description, values) =>
  column(id, label, 'text', group, description, values ? { values } : {});
function random(seed) {
  let state = seed >>> 0;
  return () => (state = (Math.imul(state, 1664525) + 1013904223) >>> 0) / 4294967296;
}
function metadata(key, label, description, category, columns, visible) {
  return {
    id: `local_demo_${key}`,
    label,
    description,
    rowLabel: key === 'finance' ? 'position' : 'operating day',
    version: `sample-${key}-v1`,
    category,
    tags: ['Featured', category],
    featured: true,
    columns,
    defaultVisibleColumnIds: visible,
    sqlDataset: { table: [`sample_${key}`], tenantColumn: 'tenant', rowIdColumn: 'id', columns },
  };
}

export function createFinanceSample() {
  const rng = random(260901);
  const portfolios = [
    'Growth',
    'Income',
    'Balanced',
    'Preservation',
    'Global opportunities',
    'Sustainable',
  ];
  const regions = ['North America', 'Europe', 'Asia Pacific', 'Latin America', 'Middle East'];
  const assetClasses = [
    'Equity',
    'Government bond',
    'Corporate bond',
    'Real estate',
    'Infrastructure',
  ];
  const risks = ['Low', 'Moderate', 'Elevated'];
  const columns = [
    text('id', 'Position ID', 'Position', 'Unique synthetic position identifier.'),
    column(
      'asOfDate',
      'Valuation date',
      'date',
      'Position',
      'All positions share one valuation date; valuations are comparable.',
    ),
    text('portfolio', 'Portfolio', 'Position', 'Synthetic investment mandate.', portfolios),
    text('region', 'Region', 'Position', 'Broad region of the instrument.', regions),
    text('assetClass', 'Asset class', 'Position', 'Instrument asset class.', assetClasses),
    text('instrument', 'Instrument', 'Position', 'Fictional instrument code; not a real security.'),
    text(
      'riskBand',
      'Risk band',
      'Risk',
      'Illustrative risk grouping, not an investment assessment.',
      risks,
    ),
    number('units', 'Units held', 'Valuation', 'Number of synthetic units held.', 'units'),
    number('unitPrice', 'Unit price (USD)', 'Valuation', 'Price per unit in synthetic USD.', 'USD'),
    number(
      'marketValue',
      'Market value (USD)',
      'Valuation',
      'Units multiplied by unit price.',
      'USD',
    ),
    number('costBasis', 'Cost basis (USD)', 'Valuation', 'Synthetic acquisition cost.', 'USD'),
    number(
      'unrealizedPnl',
      'Unrealized P&L (USD)',
      'Performance',
      'Market value minus cost basis.',
      'USD',
    ),
    number(
      'returnPct',
      'Unrealized return (%)',
      'Performance',
      'Unrealized P&L divided by cost basis, expressed in percent.',
      '%',
    ),
    number(
      'annualIncome',
      'Annual income (USD)',
      'Performance',
      'Illustrative annual income estimate.',
      'USD',
    ),
    number(
      'liquidityDays',
      'Liquidity horizon (days)',
      'Risk',
      'Illustrative expected liquidation horizon.',
      'days',
    ),
    number(
      'esgScore',
      'Sustainability score',
      'Risk',
      'Synthetic score from 20 to 100; not an external rating.',
    ),
    text('manager', 'Portfolio manager', 'Position', 'Fictional management team label.'),
    column('openedDate', 'Opened date', 'date', 'Position', 'Synthetic acquisition date.'),
  ];
  columns[0].chartRole = 'identifier';
  const rows = Array.from({ length: 2000 }, (_, i) => {
    const asset = i % assetClasses.length;
    const units = 25 + Math.floor(rng() * 5000);
    const unitPrice = round(18 + rng() * 230);
    const marketValue = round(units * unitPrice);
    const costBasis = round(marketValue / (0.84 + rng() * 0.49));
    const unrealizedPnl = round(marketValue - costBasis);
    return {
      id: `POS-${String(i + 1).padStart(5, '0')}`,
      asOfDate: '2026-09-30',
      portfolio: portfolios[Math.floor(rng() * portfolios.length)],
      region: regions[Math.floor(rng() * regions.length)],
      assetClass: assetClasses[asset],
      instrument: `DEMO-${['EQ', 'GB', 'CB', 'RE', 'IN'][asset]}-${String((i % 37) + 1).padStart(2, '0')}`,
      riskBand: risks[asset === 1 ? 0 : asset >= 3 ? 2 : Math.floor(rng() * risks.length)],
      units,
      unitPrice,
      marketValue,
      costBasis,
      unrealizedPnl,
      returnPct: round((unrealizedPnl / costBasis) * 100),
      annualIncome: round(marketValue * (0.012 + rng() * 0.055)),
      liquidityDays: [2, 3, 7, 45, 90][asset],
      esgScore: Math.floor(20 + rng() * 81),
      manager: `Team ${['Atlas', 'Cedar', 'Harbor', 'Summit'][i % 4]}`,
      openedDate: new Date(Date.UTC(2023, 0, 1) + Math.floor(rng() * 1200) * 86400000)
        .toISOString()
        .slice(0, 10),
    };
  });
  return {
    key: 'finance-demo',
    metadata: metadata(
      'finance',
      'Portfolio operations',
      '2,000 synthetic portfolio positions with valuation, return, risk and income measures. One shared valuation date; all amounts are illustrative USD.',
      'Finance',
      columns,
      ['portfolio', 'assetClass', 'region', 'marketValue', 'unrealizedPnl', 'riskBand'],
    ),
    rows,
  };
}

export function createHealthcareSample() {
  const rng = random(260902);
  const facilities = [
    'North clinic',
    'South clinic',
    'East medical center',
    'West clinic',
    'Central medical center',
  ];
  const departments = [
    'Primary care',
    'Cardiology',
    'Orthopedics',
    'Imaging',
    'Rehabilitation',
    'Pediatrics',
    'Dermatology',
    'Outpatient surgery',
  ];
  const columns = [
    text('id', 'Operating record ID', 'Service', 'Synthetic facility-department-day identifier.'),
    column(
      'serviceDate',
      'Service date',
      'date',
      'Service',
      'Date of the aggregated operating record.',
    ),
    text(
      'facility',
      'Facility',
      'Service',
      'Fictional facility; no real provider identity.',
      facilities,
    ),
    text('region', 'Service region', 'Service', 'Fictional service-area grouping.', [
      'North',
      'South',
      'East',
      'West',
      'Central',
    ]),
    text('department', 'Department', 'Service', 'Operational service department.', departments),
    text('careSetting', 'Care setting', 'Service', 'Outpatient service delivery setting.', [
      'Clinic',
      'Medical center',
    ]),
    number(
      'scheduledVisits',
      'Scheduled visits',
      'Activity',
      'Total scheduled visits; completed, cancelled and no-show counts reconcile.',
      'visits',
    ),
    number(
      'completedVisits',
      'Completed visits',
      'Activity',
      'Number of completed visits.',
      'visits',
    ),
    number(
      'cancelledVisits',
      'Cancelled visits',
      'Activity',
      'Number of cancelled visits.',
      'visits',
    ),
    number(
      'noShowVisits',
      'No-show visits',
      'Activity',
      'Number of appointments not attended.',
      'visits',
    ),
    number(
      'waitMinutes',
      'Average wait (minutes)',
      'Experience',
      'Mean wait for this operating day. Averaging these values gives an unweighted mean of daily averages.',
      'minutes',
    ),
    number(
      'patientSatisfaction',
      'Experience score',
      'Experience',
      'Synthetic daily experience score from 1 to 5; no individual responses.',
      'score',
    ),
    number(
      'staffedHours',
      'Staffed hours',
      'Capacity',
      'Total staff hours available to the department that day.',
      'hours',
    ),
    number(
      'capacityVisits',
      'Visit capacity',
      'Capacity',
      'Illustrative staffed visit capacity.',
      'visits',
    ),
    number(
      'utilizationPct',
      'Capacity used (%)',
      'Capacity',
      'Completed visits divided by staffed visit capacity, expressed in percent.',
      '%',
    ),
    number(
      'operatingCost',
      'Operating cost (USD)',
      'Finance',
      'Illustrative daily service cost.',
      'USD',
    ),
    number(
      'revenue',
      'Service revenue (USD)',
      'Finance',
      'Illustrative completed-service revenue.',
      'USD',
    ),
    number(
      'margin',
      'Operating margin (USD)',
      'Finance',
      'Service revenue minus operating cost.',
      'USD',
    ),
  ];
  columns[0].chartRole = 'identifier';
  const rows = Array.from({ length: 2000 }, (_, i) => {
    const facility = i % facilities.length,
      department = Math.floor(i / facilities.length) % departments.length;
    const date = new Date(Date.UTC(2026, 7, 12) + Math.floor(i / 40) * 86400000);
    const scheduledVisits = Math.floor(30 + rng() * 105 + (department === 0 ? 35 : 0));
    const cancelledVisits = Math.floor(scheduledVisits * (0.02 + rng() * 0.08));
    const noShowVisits = Math.floor(scheduledVisits * (0.01 + rng() * 0.07));
    const completedVisits = scheduledVisits - cancelledVisits - noShowVisits;
    const capacityVisits = Math.ceil(scheduledVisits * (1.03 + rng() * 0.22));
    const staffedHours = round(capacityVisits * (department === 7 ? 1.1 : 0.48), 1);
    const operatingCost = round(staffedHours * (49 + rng() * 24) + scheduledVisits * 16);
    const revenue = round(
      completedVisits * (department === 7 ? 325 : 75 + department * 16 + rng() * 30),
    );
    return {
      id: `OPS-${String(i + 1).padStart(5, '0')}`,
      serviceDate: date.toISOString().slice(0, 10),
      facility: facilities[facility],
      region: ['North', 'South', 'East', 'West', 'Central'][facility],
      department: departments[department],
      careSetting: facilities[facility].includes('center') ? 'Medical center' : 'Clinic',
      scheduledVisits,
      completedVisits,
      cancelledVisits,
      noShowVisits,
      waitMinutes: round(5 + department * 1.7 + rng() * 24, 1),
      patientSatisfaction: round(3.2 + rng() * 1.7, 1),
      staffedHours,
      capacityVisits,
      utilizationPct: round((completedVisits / capacityVisits) * 100),
      operatingCost,
      revenue,
      margin: round(revenue - operatingCost),
    };
  });
  return {
    key: 'healthcare-demo',
    metadata: metadata(
      'healthcare',
      'Care operations',
      '2,000 synthetic facility-department-day summaries across five facilities and eight services. Capacity, access, experience and costs; no patient-level data.',
      'Healthcare',
      columns,
      ['serviceDate', 'facility', 'department', 'completedVisits', 'waitMinutes', 'utilizationPct'],
    ),
    rows,
  };
}

export const createFeaturedSamples = () => [createFinanceSample(), createHealthcareSample()];

/** The same categories and measures as the saved chart; bounded aggregate rows only. */
export function aggregatePreview(sample, template) {
  const groups = new Map();
  for (const row of sample.rows) {
    const key = row[template.category];
    if (!groups.has(key)) groups.set(key, { count: 0, sums: template.measures.map(() => 0) });
    const group = groups.get(key);
    group.count++;
    template.measures.forEach((id, i) => {
      group.sums[i] += row[id];
    });
  }
  const fields = [template.category, ...template.measures];
  return {
    schemaVersion: 1,
    type: 'chart',
    title: template.name,
    chartType: template.type ?? 'column',
    totalRows: groups.size,
    columns: fields.map((id, i) => ({
      id,
      label: sample.metadata.columns.find((c) => c.id === id).label,
      dataType: i ? 'series' : 'category',
    })),
    rows: [...groups.entries()]
      .sort(([a], [b]) => String(a).localeCompare(String(b)))
      .slice(0, 48)
      .map(([category, group]) =>
        Object.fromEntries([
          [template.category, category],
          ...template.measures.map((id, i) => [
            id,
            round(group.sums[i] / (template.aggregation === 'avg' ? group.count : 1), 4),
          ]),
        ]),
      ),
  };
}
