import { COLUMNS, SCHEMA_VERSION, type ColumnSpec } from './schema.js';
import { CUSTODY_COLUMNS, TRANSACTION_COLUMNS } from './finance-schema.js';
import { DEMO_SQL_DATASET, type SqlDataset } from './sql-dataset.js';

export type DataSourceId = 'accounts' | 'transactions' | 'custody';
export const DEFAULT_DATA_SOURCE_ID: DataSourceId = 'accounts';
export interface DemoSourceMetadata {
  id: DataSourceId;
  label: string;
  description: string;
  rowLabel: string;
  version: string;
  columns: ColumnSpec[];
  sqlDataset: SqlDataset;
  defaultVisibleColumnIds: string[];
}
export const DATA_SOURCES: readonly DemoSourceMetadata[] = [
  {
    id: 'accounts',
    label: 'Accounts',
    description:
      '2,400 account records with quarterly finance measures and historical market observations.',
    rowLabel: 'account',
    version: SCHEMA_VERSION,
    columns: COLUMNS,
    sqlDataset: DEMO_SQL_DATASET,
    defaultVisibleColumnIds: COLUMNS.slice(0, 8).map((column) => column.id),
  },
  {
    id: 'transactions',
    label: 'Transactions',
    description:
      '25,000 synthetic trades across 450 fields: execution, settlement, fees and monthly lifecycle snapshots.',
    rowLabel: 'transaction',
    version: 'transactions-450-v1',
    columns: TRANSACTION_COLUMNS,
    sqlDataset: {
      columns: TRANSACTION_COLUMNS,
      table: ['TRANSACTIONS'],
      tenantColumn: 'TENANT_ID',
      rowIdColumn: 'id',
    },
    defaultVisibleColumnIds: [
      'id',
      'tradeDate',
      'accountName',
      'assetClass',
      'side',
      'status',
      'grossAmount',
      'feeAmount',
      'netAmount',
      'settlementDelayDays',
    ],
  },
  {
    id: 'custody',
    label: 'Custody holdings',
    description:
      '20,000 synthetic holdings across 450 fields: value, collateral, income, risk and monthly position snapshots.',
    rowLabel: 'holding',
    version: 'custody-450-v1',
    columns: CUSTODY_COLUMNS,
    sqlDataset: {
      columns: CUSTODY_COLUMNS,
      table: ['CUSTODY_HOLDINGS'],
      tenantColumn: 'TENANT_ID',
      rowIdColumn: 'id',
    },
    defaultVisibleColumnIds: [
      'id',
      'accountName',
      'custodian',
      'assetClass',
      'marketValue',
      'costValue',
      'unrealizedGain',
      'pledgedQuantity',
      'settlementStatus',
      'riskRating',
    ],
  },
];
export function getSourceMetadata(id: DataSourceId): DemoSourceMetadata {
  const source = DATA_SOURCES.find((source) => source.id === id);
  if (!source) throw new Error('Unknown demo data source: ' + id);
  return source;
}
