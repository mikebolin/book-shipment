import type { PromptExample } from './prompt-examples.js';

/** Current holdings and September snapshots; maturity schedules are not return histories. */
export const CUSTODY_CHART_EXAMPLES: readonly PromptExample[] = [
  {
    id: 'cu-demo-grouped-column',
    category: 'charts',
    chartType: 'groupedColumn',
    title: 'Cost and current value by investment type',
    prompt:
      'For Active custody holdings, create a grouped column chart of total cost value and total market value by asset class.',
    outcome: 'apply',
    expectation:
      'Filter to Active first; compare acquisition cost with current value in USD using separate columns.',
    fields: ['holdingStatus', 'assetClass', 'costValue', 'marketValue'],
  },
  {
    id: 'cu-demo-stacked-column',
    category: 'charts',
    chartType: 'stackedColumn',
    title: 'Available and pledged assets by custodian',
    prompt:
      'For Active custody holdings, create a stacked column chart of total Available value Sep 2026 and Pledged value Sep 2026 by custodian.',
    outcome: 'apply',
    expectation:
      'The two non-overlapping USD components add up to September market value for each custodian.',
    fields: ['holdingStatus', 'custodian', 'availableValue_2026_09', 'pledgedValue_2026_09'],
  },
  {
    id: 'cu-demo-normalized-column',
    category: 'charts',
    chartType: 'normalizedColumn',
    title: 'Non-cash investment mix across client groups',
    prompt:
      'For Active custody holdings where asset class is not Cash, create a 100% stacked column chart by client type using total Equity value Sep 2026, Bond value Sep 2026 and Fund value Sep 2026.',
    outcome: 'apply',
    expectation:
      'Exclude Cash first. Each client group shows equity, bond and fund shares of its September non-cash value; API totals stay in USD.',
    fields: [
      'holdingStatus',
      'assetClass',
      'clientType',
      'equityValue_2026_09',
      'bondValue_2026_09',
      'fundValue_2026_09',
    ],
  },
  {
    id: 'cu-demo-grouped-bar',
    category: 'charts',
    chartType: 'groupedBar',
    title: 'European holdings: cost versus value',
    prompt:
      'For Active custody holdings in Europe, create a grouped bar chart of total cost value and total market value by custodian.',
    outcome: 'apply',
    expectation:
      'Compare the two USD totals across custodians after filtering to active European holdings.',
    fields: ['holdingStatus', 'region', 'custodian', 'costValue', 'marketValue'],
  },
  {
    id: 'cu-demo-stacked-bar',
    category: 'charts',
    chartType: 'stackedBar',
    title: 'Where September investment income came from',
    prompt:
      'For Active custody holdings where Income Sep 2026 is not blank, create a stacked bar chart of total Dividend income Sep 2026, Interest income Sep 2026 and Other income Sep 2026 by custodian.',
    outcome: 'apply',
    expectation:
      'Stack distinct income sources from the same month. Missing income records are excluded before grouping.',
    fields: [
      'holdingStatus',
      'custodian',
      'incomeAmount_2026_09',
      'dividendIncome_2026_09',
      'interestIncome_2026_09',
      'otherIncome_2026_09',
    ],
  },
  {
    id: 'cu-demo-normalized-bar',
    category: 'charts',
    chartType: 'normalizedBar',
    title: 'How much value is pledged in each region?',
    prompt:
      'For Active custody holdings with market value at least 50000 USD, create a 100% stacked bar chart of total Available value Sep 2026 and Pledged value Sep 2026 by region.',
    outcome: 'apply',
    expectation:
      'Apply the inclusive size threshold first, then show available and pledged shares for each region.',
    fields: [
      'holdingStatus',
      'marketValue',
      'region',
      'availableValue_2026_09',
      'pledgedValue_2026_09',
    ],
  },
  {
    id: 'cu-demo-line',
    category: 'charts',
    chartType: 'line',
    title: 'Settled bond exposure by maturity year',
    prompt:
      'For Bond custody holdings with settlement status Settled and market value greater than zero, create a line chart of total market value by maturity date in yearly buckets.',
    outcome: 'apply',
    expectation:
      'Show the current USD exposure scheduled to mature in each year, not historical returns or a forecast.',
    fields: ['assetClass', 'settlementStatus', 'marketValue', 'maturityDate'],
  },
  {
    id: 'cu-demo-stacked-line',
    category: 'charts',
    chartType: 'stackedLine',
    title: 'Available and pledged bonds by maturity',
    prompt:
      'For Active Bond custody holdings, create a stacked line chart of total Available value Sep 2026 and Pledged value Sep 2026 by maturity date in yearly buckets.',
    outcome: 'apply',
    expectation:
      'Stack the two current collateral components within each bond maturity year; never add different monthly snapshots.',
    fields: [
      'holdingStatus',
      'assetClass',
      'maturityDate',
      'availableValue_2026_09',
      'pledgedValue_2026_09',
    ],
  },
  {
    id: 'cu-demo-normalized-line',
    category: 'charts',
    chartType: 'normalizedLine',
    title: 'Pledged share of settled bonds by maturity',
    prompt:
      'For Bond custody holdings with settlement status Settled and market value greater than zero, create a 100% stacked line chart of total Available value Sep 2026 and Pledged value Sep 2026 by maturity date in yearly buckets.',
    outcome: 'apply',
    expectation:
      'Compare the available and pledged shares within each maturity year, keeping the underlying API values in USD.',
    fields: [
      'assetClass',
      'settlementStatus',
      'marketValue',
      'maturityDate',
      'availableValue_2026_09',
      'pledgedValue_2026_09',
    ],
  },
  {
    id: 'cu-demo-area',
    category: 'charts',
    chartType: 'area',
    title: 'Acquisition cost of bonds approaching maturity',
    prompt:
      'For Active Bond custody holdings, create an area chart of total cost value by maturity date in yearly buckets.',
    outcome: 'apply',
    expectation:
      "Show the acquisition cost of today's active bonds grouped by contractual maturity year, not a cash-flow forecast.",
    fields: ['holdingStatus', 'assetClass', 'costValue', 'maturityDate'],
  },
  {
    id: 'cu-demo-stacked-area',
    category: 'charts',
    chartType: 'stackedArea',
    title: 'Pension fund bond collateral by maturity',
    prompt:
      'For Active Bond custody holdings owned by Pension fund clients, create a stacked area chart of total Available value Sep 2026 and Pledged value Sep 2026 by maturity date in yearly buckets.',
    outcome: 'apply',
    expectation:
      'Filter to the pension-fund bond cohort; stack available and pledged exposure in each maturity year.',
    fields: [
      'holdingStatus',
      'assetClass',
      'clientType',
      'maturityDate',
      'availableValue_2026_09',
      'pledgedValue_2026_09',
    ],
  },
  {
    id: 'cu-demo-normalized-area',
    category: 'charts',
    chartType: 'normalizedArea',
    title: 'European bond collateral mix by maturity',
    prompt:
      'For Active Bond custody holdings in Europe, create a 100% stacked area chart of total Available value Sep 2026 and Pledged value Sep 2026 by maturity date in yearly buckets.',
    outcome: 'apply',
    expectation:
      'Compare two nonnegative collateral components as percentages of each maturity-year total for the same September snapshot.',
    fields: [
      'holdingStatus',
      'assetClass',
      'region',
      'maturityDate',
      'availableValue_2026_09',
      'pledgedValue_2026_09',
    ],
  },
  {
    id: 'cu-demo-pie',
    category: 'charts',
    chartType: 'pie',
    title: 'Value split across known risk ratings',
    prompt:
      'For Active custody holdings where risk rating is not blank, create a pie chart of total market value by risk rating.',
    outcome: 'apply',
    expectation:
      'Show Low, Medium and High shares of the explicitly rated cohort; missing ratings are excluded by the filter.',
    fields: ['holdingStatus', 'riskRating', 'marketValue'],
  },
  {
    id: 'cu-demo-donut',
    category: 'charts',
    chartType: 'donut',
    title: 'Pension fund investment allocation',
    prompt:
      'For Active custody holdings owned by Pension fund clients, create a donut chart of total market value by asset class.',
    outcome: 'apply',
    expectation: 'Show the four investment types as shares of active pension-fund value in USD.',
    fields: ['holdingStatus', 'clientType', 'assetClass', 'marketValue'],
  },
  {
    id: 'cu-demo-scatter',
    category: 'charts',
    chartType: 'scatter',
    title: 'European equity cost versus current value',
    prompt:
      'For Active Equity custody holdings in Europe with market value at most 1000000 USD, create a scatter chart with cost value on X and market value on Y.',
    outcome: 'apply',
    expectation:
      'Plot each matching holding as one point with both axes in USD, retaining actual gains and losses.',
    fields: ['holdingStatus', 'assetClass', 'region', 'marketValue', 'costValue'],
  },
  {
    id: 'cu-demo-bubble',
    category: 'charts',
    chartType: 'bubble',
    title: 'Bond position size and collateral use',
    prompt:
      'For Active Bond custody holdings in Europe with Pledged value Sep 2026 greater than zero and market value at most 1000000 USD, create a bubble chart with market value on X, Pledged percent Sep 2026 on Y and Pledged value Sep 2026 as bubble size.',
    outcome: 'apply',
    expectation:
      'Plot one holding per bubble: USD position size, collateral percentage and positive pledged USD value.',
    fields: [
      'holdingStatus',
      'assetClass',
      'region',
      'marketValue',
      'pledgedPercent_2026_09',
      'pledgedValue_2026_09',
    ],
  },
  {
    id: 'cu-demo-histogram',
    category: 'charts',
    chartType: 'histogram',
    title: 'Distribution of active equity position sizes',
    prompt:
      'For Active Equity custody holdings with market value greater than zero and at most 1000000 USD, create a histogram of market value.',
    outcome: 'apply',
    expectation:
      'Use every matching raw USD position value; zero balances and values above the explicit cap are filtered out.',
    fields: ['holdingStatus', 'assetClass', 'marketValue'],
  },
  {
    id: 'cu-demo-column-line',
    category: 'charts',
    chartType: 'columnLineCombo',
    title: 'Portfolio value and lending capacity',
    prompt:
      'For Active custody holdings, create a column plus line combination chart by custodian, with total market value as columns and total loan value as the line.',
    outcome: 'apply',
    expectation:
      'Compare current portfolio value with the synthetic collateral lending value; both totals are USD.',
    fields: ['holdingStatus', 'custodian', 'marketValue', 'loanValue'],
  },
  {
    id: 'cu-demo-area-column',
    category: 'charts',
    chartType: 'areaColumnCombo',
    title: 'Bond cost and value across maturity years',
    prompt:
      'For Active Bond custody holdings, create an area plus column combination chart by maturity date in yearly buckets, with total cost value as the area and total market value as columns.',
    outcome: 'apply',
    expectation:
      "Compare two USD valuation measures for today's bond holdings across maturity years; this is not a historical trend.",
    fields: ['holdingStatus', 'assetClass', 'maturityDate', 'costValue', 'marketValue'],
  },
  {
    id: 'cu-demo-custom-combo',
    category: 'charts',
    chartType: 'customCombo',
    title: 'Average position size and collateral percentage',
    prompt:
      'For Active custody holdings in Europe, create a custom combination chart by asset class: average market value and average cost value as grouped columns on the left USD axis, and average Pledged percent Sep 2026 as a line on its own right percentage axis.',
    outcome: 'apply',
    expectation:
      'Average all three measures within each investment type. The unweighted average pledged percentage gets a separate right axis.',
    fields: [
      'holdingStatus',
      'region',
      'assetClass',
      'marketValue',
      'costValue',
      'pledgedPercent_2026_09',
    ],
  },
];
