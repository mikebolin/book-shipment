import type { ChartingDataSource } from '../core/data-access/charting-data';
import type { LocalDataset } from './client-data-sources';
import { parseLocalJsonFile } from './local-json-dataset';

export const NORMAL_PEOPLE_CHARTS_ID = 'local_normal_people_charts' as const;
export const NORMAL_PEOPLE_CHARTS_OPTION = {
  id: NORMAL_PEOPLE_CHARTS_ID,
  label: 'Normal People Charts · Straightforward AG · 150 prompts',
};

export async function loadNormalPeopleCharts(
  loadAsset: ChartingDataSource['loadAsset'],
  signal?: AbortSignal,
): Promise<LocalDataset> {
  const response = await loadAsset('normal-people-charts/dataset.json', signal);
  if (!response.ok)
    throw new Error(
      'The Normal People Charts sample could not be loaded. Check that its asset was deployed.',
    );
  const dataset = await parseLocalJsonFile(
    new File([await response.blob()], 'dataset.json', { type: 'application/json' }),
    { skipRecipes: true, signal },
  );
  if (dataset.rows.length !== 288 || dataset.originalFields.length !== 14)
    throw new Error('The Normal People Charts sample is incomplete or does not match its schema.');
  dataset.metadata = {
    ...dataset.metadata,
    id: NORMAL_PEOPLE_CHARTS_ID,
    version: `${NORMAL_PEOPLE_CHARTS_ID}-${dataset.contentHash?.slice(0, 32) ?? 'bundled-v1'}`,
    label: NORMAL_PEOPLE_CHARTS_OPTION.label,
    rowLabel: 'monthly sales record',
    local: true,
  };
  dataset.preparedRecipes = [];
  return dataset;
}
