import type { PromptExample } from './prompt-examples.js';

/** Start with a reviewed cohort, then explicitly continue into a chart and refine it. */
export const TRANSACTION_WORKFLOW_EXAMPLES: readonly PromptExample[] = [
  {
    id: 'tx-workflow-settlement-review',
    category: 'workflows',
    title: 'Find settlement exceptions, then explain them',
    outcome: 'sequence',
    prompt: 'Show Failed or Pending transactions with gross amount at least 50000 USD.',
    expectation:
      'First review the matching trades. Continue with the chart before or after applying the filter.',
    fields: ['status', 'grossAmount', 'exceptionReason'],
    followUps: [
      {
        title: 'Chart the reasons',
        prompt:
          'For these same transactions, create a bar chart counting trades by exception reason.',
        expectation:
          'Keep both settlement statuses and the amount threshold. Count trades, not trade IDs or dollars.',
      },
      {
        title: 'Make the chart easier to present',
        prompt: 'Keep the same chart and data. Use the vivid theme and show data labels.',
        expectation: 'Only appearance changes; every reason and trade count stays the same.',
      },
    ],
  },
  {
    id: 'tx-workflow-monthly-equity',
    category: 'workflows',
    title: 'Select equity trades, then compare monthly activity',
    outcome: 'sequence',
    prompt: 'Show Settled Equity transactions traded from January through September 2026.',
    expectation:
      'Review the settled equity cohort and inclusive calendar period before choosing a visual.',
    fields: ['status', 'assetClass', 'tradeDate', 'grossAmount', 'feeAmount'],
    followUps: [
      {
        title: 'Chart monthly trading value',
        prompt: 'For these same trades, create a line chart of total gross amount by trade month.',
        expectation:
          'Aggregate only the selected trades into month buckets, preserving all filters.',
      },
      {
        title: 'Explore average fees instead',
        prompt:
          'Keep the same trades and monthly line chart, but show average fees instead of total gross amount.',
        expectation:
          'Change the measure and aggregation; missing fees are excluded from each monthly average.',
      },
    ],
  },
];

export const CUSTODY_WORKFLOW_EXAMPLES: readonly PromptExample[] = [
  {
    id: 'cu-workflow-collateral-review',
    category: 'workflows',
    title: 'Find pledged holdings, then compare lending value',
    outcome: 'sequence',
    prompt: 'Show Active, Settled custody holdings with pledged quantity greater than zero.',
    expectation:
      'Review the pledged holding cohort. Loan value is the holding lending value, not the value of pledged units alone.',
    fields: [
      'holdingStatus',
      'settlementStatus',
      'pledgedQuantity',
      'loanValue',
      'assetClass',
      'region',
    ],
    followUps: [
      {
        title: 'Compare lending value by investment type',
        prompt:
          'For these same holdings, create a column chart of total loan value by asset class.',
        expectation:
          'Sum USD lending value for the reviewed active, settled, pledged holding cohort.',
      },
      {
        title: 'Focus on Europe',
        prompt: 'Keep the same chart and existing filters, but narrow these holdings to Europe.',
        expectation:
          'Add Region = Europe; preserve all three original conditions and recalculate every bar.',
      },
    ],
  },
  {
    id: 'cu-workflow-bond-maturities',
    category: 'workflows',
    title: 'Find upcoming bond maturities, then chart the schedule',
    outcome: 'sequence',
    prompt: 'Show Bond custody holdings with maturity dates from 2027 through 2030.',
    expectation:
      'Review bonds maturing from January 1, 2027 inclusive to January 1, 2031 exclusive. Exclude instruments without maturity dates.',
    fields: ['assetClass', 'maturityDate', 'marketValue', 'loanValue'],
    followUps: [
      {
        title: 'Chart value by maturity month',
        prompt:
          'For these same bonds, create a column chart of total market value by maturity month.',
        expectation:
          'Group current holding values by contractual maturity month; this is a maturity schedule, not a historical price series.',
      },
      {
        title: 'Explore lending value instead',
        prompt:
          'Keep the same bonds and maturity months, but show total loan value instead of market value.',
        expectation:
          'Use the lending value measure on the unchanged bond cohort and monthly maturity buckets.',
      },
    ],
  },
];
