import type { PromptExample } from './prompt-examples.js';

/** One filtered, business-oriented example for every included chart variant. */
export const TRANSACTION_CHART_EXAMPLES: readonly PromptExample[] = [
  {
    id: 'tx-demo-grouped-column',
    category: 'charts',
    chartType: 'groupedColumn',
    title: 'Grouped columns: purchases versus sales',
    prompt:
      'For settled transactions, create grouped columns by asset class comparing total Buy amount Sep 2026 and Sell amount Sep 2026 in USD.',
    outcome: 'apply',
    expectation:
      'Filter to Settled first. Compare separate buy and sell components from the September snapshot; each trade contributes to one side only.',
    fields: ['status', 'assetClass', 'buyAmount_2026_09', 'sellAmount_2026_09'],
  },
  {
    id: 'tx-demo-stacked-column',
    category: 'charts',
    chartType: 'stackedColumn',
    title: 'Stacked columns: trading costs by desk',
    prompt:
      'Exclude cancelled transactions and blank fees, then create stacked columns of total fees and tax in USD by trading desk.',
    outcome: 'apply',
    expectation:
      'Stack two separate nonnegative cost components. Do not include gross or net trade value in the stack.',
    fields: ['status', 'feeAmount', 'taxAmount', 'desk'],
  },
  {
    id: 'tx-demo-normalized-column',
    category: 'charts',
    chartType: 'normalizedColumn',
    title: '100% columns: equity trading cost mix',
    prompt:
      'For settled Equity transactions with known fees, create a 100% stacked column chart by broker showing the split between total fees and total tax.',
    outcome: 'apply',
    expectation:
      'Filter first, sum USD costs per broker, then display each broker as 100%. Returned values remain the original dollar sums.',
    fields: ['status', 'assetClass', 'feeAmount', 'taxAmount', 'broker'],
  },
  {
    id: 'tx-demo-grouped-bar',
    category: 'charts',
    chartType: 'groupedBar',
    title: 'Grouped bars: purchases and sales needing attention',
    prompt:
      'For Failed or Pending transactions, create grouped horizontal bars by counterparty comparing total Buy amount Sep 2026 and Sell amount Sep 2026 in USD.',
    outcome: 'apply',
    expectation:
      'Keep the Failed OR Pending cohort. Compare September buy and sell components without summing them with gross amount.',
    fields: ['status', 'counterparty', 'buyAmount_2026_09', 'sellAmount_2026_09'],
  },
  {
    id: 'tx-demo-stacked-bar',
    category: 'charts',
    chartType: 'stackedBar',
    title: 'Stacked bars: equity costs by region',
    prompt:
      'For Equity transactions excluding Cancelled and blank fees, create stacked horizontal bars by region for total fees and total tax in USD.',
    outcome: 'apply',
    expectation:
      'The full filtered cohort contributes fee and tax components to each regional cost total.',
    fields: ['assetClass', 'status', 'feeAmount', 'taxAmount', 'region'],
  },
  {
    id: 'tx-demo-normalized-bar',
    category: 'charts',
    chartType: 'normalizedBar',
    title: '100% bars: cross-border equity cost mix',
    prompt:
      'For cross border Equity transactions excluding Cancelled and blank fees, create 100% stacked horizontal bars by trade channel for total fees and total tax.',
    outcome: 'apply',
    expectation:
      'Each trade channel shows the percentage split of two nonnegative USD cost components, with a real variation in fee rates.',
    fields: ['isCrossBorder', 'assetClass', 'status', 'feeAmount', 'taxAmount', 'channel'],
  },
  {
    id: 'tx-demo-line',
    category: 'charts',
    chartType: 'line',
    title: 'Line: average equity trade size by month',
    prompt:
      'For settled Equity transactions, create a line chart of average gross amount in USD by trade date, using monthly buckets.',
    outcome: 'apply',
    expectation:
      'Average individual settled equity trades within each actual trade month. Do not sum prices or invent missing months.',
    fields: ['status', 'assetClass', 'tradeDate', 'grossAmount'],
  },
  {
    id: 'tx-demo-stacked-line',
    category: 'charts',
    chartType: 'stackedLine',
    title: 'Stacked lines: monthly purchase and sale value',
    prompt:
      'Exclude Cancelled transactions. Create stacked lines for total Buy amount Sep 2026 and Sell amount Sep 2026 in USD, grouped by trade date in monthly buckets.',
    outcome: 'apply',
    expectation:
      'Use September per-trade snapshots as two disjoint components, grouped by the month each trade occurred. The top line represents their combined value.',
    fields: ['status', 'tradeDate', 'buyAmount_2026_09', 'sellAmount_2026_09'],
  },
  {
    id: 'tx-demo-normalized-line',
    category: 'charts',
    chartType: 'normalizedLine',
    title: '100% lines: Europe purchase and sale mix',
    prompt:
      'For Europe transactions excluding Cancelled, create 100% stacked lines for total Buy amount Sep 2026 and Sell amount Sep 2026, grouped by trade date in monthly buckets.',
    outcome: 'apply',
    expectation:
      'Each trade month shows the percentage split between buy and sell value, measured using the September snapshot. The two components sum to 100%.',
    fields: ['region', 'status', 'tradeDate', 'buyAmount_2026_09', 'sellAmount_2026_09'],
  },
  {
    id: 'tx-demo-area',
    category: 'charts',
    chartType: 'area',
    title: 'Area: settled bond trading by month',
    prompt:
      'For settled Bond transactions, create an area chart of total gross amount in USD by trade date, using monthly buckets.',
    outcome: 'apply',
    expectation:
      'Sum the filtered bond trades by execution month. Each trade contributes once, regardless of how many monthly snapshot columns exist.',
    fields: ['status', 'assetClass', 'tradeDate', 'grossAmount'],
  },
  {
    id: 'tx-demo-stacked-area',
    category: 'charts',
    chartType: 'stackedArea',
    title: 'Stacked areas: monthly equity trading costs',
    prompt:
      'For Equity transactions excluding Cancelled and blank fees, create a stacked area chart of total fees and total tax in USD by trade date in monthly buckets.',
    outcome: 'apply',
    expectation:
      'Show monthly fee and tax costs as separate nonnegative parts of the combined trading cost.',
    fields: ['assetClass', 'status', 'feeAmount', 'taxAmount', 'tradeDate'],
  },
  {
    id: 'tx-demo-normalized-area',
    category: 'charts',
    chartType: 'normalizedArea',
    title: '100% areas: monthly cross-border cost mix',
    prompt:
      'For cross border Equity transactions excluding Cancelled and blank fees, create a 100% stacked area chart of total fees and total tax by trade date in monthly buckets.',
    outcome: 'apply',
    expectation:
      'Normalize the two USD cost components within each actual trade month; keep the underlying aggregate dollars available for review.',
    fields: ['isCrossBorder', 'assetClass', 'status', 'feeAmount', 'taxAmount', 'tradeDate'],
  },
  {
    id: 'tx-demo-pie',
    category: 'charts',
    chartType: 'pie',
    title: 'Pie: where settled trade value comes from',
    prompt: 'For settled transactions, create a pie chart of total gross amount in USD by region.',
    outcome: 'apply',
    expectation:
      'Three regions partition the nonnegative settled trading value, with no identifiers or signed cash amounts used as slices.',
    fields: ['status', 'region', 'grossAmount'],
  },
  {
    id: 'tx-demo-donut',
    category: 'charts',
    chartType: 'donut',
    title: 'Donut: why trades need attention',
    prompt:
      'For Failed or Pending transactions, create a donut chart counting transactions by exception reason.',
    outcome: 'apply',
    expectation:
      'Count every matching transaction once per exception reason. Count rows rather than numeric identifiers or dollar amounts.',
    fields: ['status', 'exceptionReason'],
  },
  {
    id: 'tx-demo-scatter',
    category: 'charts',
    chartType: 'scatter',
    title: 'Scatter: equity trade size and fees',
    prompt:
      'For Europe Equity transactions excluding Cancelled, with known fees and gross amount from 10000 through 200000 USD, create a scatter chart with gross amount on X and fees on Y.',
    outcome: 'apply',
    expectation:
      'Apply both inclusive amount boundaries first. Plot one raw amount/fee pair per matching trade, preserving variation in fee rates.',
    fields: ['region', 'assetClass', 'status', 'grossAmount', 'feeAmount'],
  },
  {
    id: 'tx-demo-bubble',
    category: 'charts',
    chartType: 'bubble',
    title: 'Bubble: settlement exceptions at a glance',
    prompt:
      'For Equity transactions with status Failed or Pending and gross amount greater than zero, create a bubble chart with risk score on X, settlement delay days on Y, and gross amount in USD as bubble size.',
    outcome: 'apply',
    expectation:
      'Preserve the grouped status condition. Each exception is one point with a positive size; separate axis units are score and days.',
    fields: ['assetClass', 'status', 'grossAmount', 'riskScore', 'settlementDelayDays'],
  },
  {
    id: 'tx-demo-histogram',
    category: 'charts',
    chartType: 'histogram',
    title: 'Histogram: sizes of settled equity trades',
    prompt:
      'For settled Equity transactions with gross amount greater than zero and at most 100000 USD, create a histogram of gross amount.',
    outcome: 'apply',
    expectation:
      'Use all matching raw trade amounts for frequency bins; do not pre-aggregate them or drop observations beyond the first grid page.',
    fields: ['status', 'assetClass', 'grossAmount'],
  },
  {
    id: 'tx-demo-column-line',
    category: 'charts',
    chartType: 'columnLineCombo',
    title: 'Column + line: monthly equity fees and tax',
    prompt:
      'For settled Equity transactions with known fees, create a column plus line combination chart by trade date in monthly buckets: total fees as columns and total tax as a line, both in USD.',
    outcome: 'apply',
    expectation:
      'Filter first and sum two comparable cost components per trade month. Keep fees first for columns and tax second for the line.',
    fields: ['status', 'assetClass', 'feeAmount', 'taxAmount', 'tradeDate'],
  },
  {
    id: 'tx-demo-area-column',
    category: 'charts',
    chartType: 'areaColumnCombo',
    title: 'Area + column: electronic equity costs',
    prompt:
      'For Electronic Equity transactions excluding Cancelled and blank fees, create an area plus column combination chart by trade date in monthly buckets: total fees as an area and total tax as columns, both in USD.',
    outcome: 'apply',
    expectation:
      'Compare monthly cost components on the same USD scale. Keep fees first for the area and tax second for columns.',
    fields: ['channel', 'assetClass', 'status', 'feeAmount', 'taxAmount', 'tradeDate'],
  },
  {
    id: 'tx-demo-custom-combo',
    category: 'charts',
    chartType: 'customCombo',
    title: 'Custom combination: costs beside trading value',
    prompt:
      'For settled Equity transactions with known fees, create a custom combination chart by trade date in monthly buckets: total fees and total tax as stacked columns on the left axis, and total gross amount as a line on a separate right axis. Both axes are in USD.',
    outcome: 'apply',
    expectation:
      'Stack only the two cost components. Draw gross trade value separately with its own scale, so large trade values do not hide fees and tax.',
    fields: ['status', 'assetClass', 'feeAmount', 'taxAmount', 'grossAmount', 'tradeDate'],
  },
];
