/** Self-contained mock report entries; no third-party report service is contacted. */
export const POWER_BI_REPORTS = [
  {
    id: 'adventureworks-sales',
    name: 'AdventureWorks sales',
    author: 'Local sample',
    description:
      'A public demonstration using the AdventureWorks sample dataset, with sales, products and customer drill-throughs.',
    category: 'Sales',
    source: 'assets/mock-report.html',
    embedUrl: 'assets/mock-report.html',
  },
  {
    id: 'sales-profit',
    name: 'Sales & profit',
    author: 'Local sample',
    description:
      'A public demonstration of sales performance, profit drivers and customer segments with interactive report navigation.',
    category: 'Sales & finance',
    source: 'assets/mock-report.html',
    embedUrl: 'assets/mock-report.html?report=profit',
  },
] as const;
