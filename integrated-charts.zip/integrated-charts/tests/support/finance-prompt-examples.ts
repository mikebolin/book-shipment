import type { PromptExample } from './prompt-examples.js';

/** Curated business questions against deterministic synthetic finance records. */
export const TRANSACTION_PROMPT_EXAMPLES: readonly PromptExample[] = [
  {
    id: 'tx-large-failed',
    category: 'logic',
    title: 'Large failed trades',
    prompt: 'Show failed transactions with gross amount at least 100000 USD.',
    outcome: 'apply',
    expectation: 'Failed trades with Gross amount >= 100000, including the exact boundary.',
    fields: ['status', 'grossAmount'],
  },
  {
    id: 'tx-amount-range',
    category: 'logic',
    title: 'Trades between two amounts',
    prompt:
      'Show transactions with gross amount from 5000 through 50000 USD, including both amounts.',
    outcome: 'apply',
    expectation: 'Gross amount >= 5000 AND <= 50000.',
    fields: ['grossAmount'],
  },
  {
    id: 'tx-nested-exceptions',
    category: 'logic',
    title: 'Settlement exceptions worth reviewing',
    prompt:
      'Show transactions where (status is Failed or Pending) and (gross amount is at least 50000 USD or settlement delay days is at least 3).',
    outcome: 'apply',
    expectation: 'Keep both OR groups joined by AND.',
    fields: ['status', 'grossAmount', 'settlementDelayDays'],
  },
  {
    id: 'tx-september-buys',
    category: 'dates',
    title: 'September equity purchases',
    prompt: 'Show Equity Buy transactions traded in September 2026.',
    outcome: 'apply',
    expectation: 'Equity, Buy, and trade dates from September 1 inclusive to October 1 exclusive.',
    fields: ['assetClass', 'side', 'tradeDate'],
  },
  {
    id: 'tx-missing-fees',
    category: 'sets',
    title: 'Trades waiting for fee information',
    prompt: 'Show transactions where fees are blank.',
    outcome: 'apply',
    expectation: 'Only genuinely missing fees, not zero fees.',
    fields: ['feeAmount'],
  },
  {
    id: 'tx-cross-border',
    category: 'sets',
    title: 'Cross-border trades in review',
    prompt: 'Show cross border transactions in Europe with status Failed or Pending.',
    outcome: 'apply',
    expectation: 'Cross border Yes AND Europe AND (Failed OR Pending).',
    fields: ['isCrossBorder', 'region', 'status'],
  },
  {
    id: 'tx-client-search',
    category: 'logic',
    title: 'Find an institutional client',
    prompt:
      'Show transactions where account name starts with Atlas and gross amount is greater than 10000 USD.',
    outcome: 'apply',
    expectation: 'Case-insensitive account prefix and a strict amount threshold.',
    fields: ['accountName', 'grossAmount'],
  },
  {
    id: 'tx-monthly-cash',
    category: 'logic',
    title: 'September settlement cash paid out',
    prompt: 'Show transactions where Cash impact Sep 2026 is less than zero and status is Settled.',
    outcome: 'apply',
    expectation:
      'Negative September cash impact identifies settled purchases; future snapshots stay blank.',
    fields: ['cashImpact_2026_09', 'status'],
  },
  {
    id: 'tx-chart-asset-value',
    category: 'charts',
    title: 'Trade value by investment type',
    prompt: 'Create a column chart of total gross amount by asset class for settled transactions.',
    outcome: 'apply',
    expectation: 'Filter to Settled first, then sum USD gross amount by asset class.',
    fields: ['status', 'assetClass', 'grossAmount'],
  },
  {
    id: 'tx-chart-status-count',
    category: 'charts',
    title: 'How many trades need attention?',
    prompt: 'Create a bar chart counting transactions by status.',
    outcome: 'apply',
    expectation: 'Count rows per status, never sum transaction identifiers.',
    fields: ['status'],
  },
  {
    id: 'tx-chart-broker-fees',
    category: 'charts',
    title: 'Average fees by broker',
    prompt:
      'Create a bar chart of average fees by broker for transactions with gross amount at least 50000 USD.',
    outcome: 'apply',
    expectation: 'Filter the cohort before averaging. Missing fees are excluded from each average.',
    fields: ['broker', 'grossAmount', 'feeAmount'],
  },
  {
    id: 'tx-chart-monthly-trades',
    category: 'charts',
    title: 'Monthly trading activity',
    prompt:
      'Create a line chart of total gross amount by trade date in monthly buckets for settled transactions.',
    outcome: 'apply',
    expectation: 'Sum the filtered trades into January through September trade-month buckets.',
    fields: ['tradeDate', 'status', 'grossAmount'],
  },
  {
    id: 'tx-chart-distribution',
    category: 'charts',
    title: 'Typical transaction sizes',
    prompt:
      'Create a histogram of gross amount for Equity transactions with gross amount at most 100000 USD.',
    outcome: 'apply',
    expectation: 'Use every matching raw gross amount, with an inclusive upper bound.',
    fields: ['assetClass', 'grossAmount'],
  },
  {
    id: 'tx-chart-fee-relationship',
    category: 'charts',
    title: 'How fees change with trade size',
    prompt:
      'Create a scatter chart with gross amount on X and fees on Y for Equity transactions in Europe where gross amount is at least 10000 USD and fees are not blank.',
    outcome: 'apply',
    expectation:
      'Plot one point per matching transaction; preserve the real amount-to-fee relationship.',
    fields: ['assetClass', 'region', 'grossAmount', 'feeAmount'],
  },
  {
    id: 'tx-chart-buy-sell-cash',
    category: 'charts',
    title: 'Purchases and sales move cash',
    prompt: 'Create a column chart of total cash impact by side for settled transactions.',
    outcome: 'apply',
    expectation:
      'Purchases produce negative bars and sales positive bars, using the filtered settlement cohort.',
    fields: ['status', 'side', 'cashImpact'],
  },
  {
    id: 'tx-chart-preview-refine',
    category: 'charts',
    title: 'Review and style an exception chart',
    prompt:
      'For failed or pending transactions, create a donut chart of total gross amount by asset class.',
    outcome: 'sequence',
    expectation: 'Preview the exception cohort, then refine appearance before Apply.',
    fields: ['status', 'assetClass', 'grossAmount'],
    followUps: [
      {
        title: 'Change the preview style',
        prompt:
          'Keep the same data and use the vivid dark theme, show labels, and move the legend to the right.',
        expectation: 'Preserve the exact cohort and values; update only appearance.',
      },
    ],
  },
];

export const CUSTODY_PROMPT_EXAMPLES: readonly PromptExample[] = [
  {
    id: 'cu-losses',
    category: 'logic',
    title: 'Holdings with unrealized losses',
    prompt:
      'Show custody holdings with unrealized gain less than zero and market value at least 100000 USD.',
    outcome: 'apply',
    expectation: 'Retain losses above the inclusive market-value threshold.',
    fields: ['unrealizedGain', 'marketValue'],
  },
  {
    id: 'cu-value-range',
    category: 'logic',
    title: 'Mid-sized holdings',
    prompt:
      'Show custody holdings with market value from 50000 through 1000000 USD, including both amounts.',
    outcome: 'apply',
    expectation: 'Market value >= 50000 AND <= 1000000.',
    fields: ['marketValue'],
  },
  {
    id: 'cu-nested-risk',
    category: 'logic',
    title: 'Risk and settlement review',
    prompt:
      'Show custody holdings where (risk rating is High or settlement status is Failed) and (region is Europe or market value is at least 1000000 USD).',
    outcome: 'apply',
    expectation: 'Keep both OR groups and their AND relationship.',
    fields: ['riskRating', 'settlementStatus', 'region', 'marketValue'],
  },
  {
    id: 'cu-bond-maturities',
    category: 'dates',
    title: 'Bonds maturing next year',
    prompt: 'Show Bond custody holdings with maturity dates in 2027.',
    outcome: 'apply',
    expectation: 'Bond holdings with maturity date >= 2027-01-01 and < 2028-01-01.',
    fields: ['assetClass', 'maturityDate'],
  },
  {
    id: 'cu-missing-risk',
    category: 'sets',
    title: 'Missing risk ratings',
    prompt: 'Show custody holdings where risk rating is blank.',
    outcome: 'apply',
    expectation: 'Only actual missing ratings.',
    fields: ['riskRating'],
  },
  {
    id: 'cu-pledged',
    category: 'logic',
    title: 'Restricted collateral positions',
    prompt: 'Show Restricted custody holdings with pledged quantity greater than zero.',
    outcome: 'apply',
    expectation: 'Restricted holdings that have units pledged as collateral.',
    fields: ['holdingStatus', 'pledgedQuantity'],
  },
  {
    id: 'cu-client-search',
    category: 'logic',
    title: 'Pension holdings in Europe',
    prompt:
      'Show custody holdings for Pension fund clients in Europe with market value greater than 100000 USD.',
    outcome: 'apply',
    expectation: 'Apply the client, region and amount conditions together.',
    fields: ['clientType', 'region', 'marketValue'],
  },
  {
    id: 'cu-monthly-losses',
    category: 'logic',
    title: 'September position losses',
    prompt:
      'Show custody holdings where Unrealized gain Sep 2026 is less than zero and Market value Sep 2026 is at least 50000 USD.',
    outcome: 'apply',
    expectation: 'Use the explicitly named September observations, including the value boundary.',
    fields: ['unrealizedGain_2026_09', 'marketValue_2026_09'],
  },
  {
    id: 'cu-chart-allocation',
    category: 'charts',
    title: 'Portfolio allocation',
    prompt:
      'Create a donut chart of total market value by asset class for Active custody holdings.',
    outcome: 'apply',
    expectation: 'Filter Active holdings and sum positive USD values by investment type.',
    fields: ['holdingStatus', 'assetClass', 'marketValue'],
  },
  {
    id: 'cu-chart-client-count',
    category: 'charts',
    title: 'Holdings by client segment',
    prompt: 'Create a bar chart counting custody holdings by client type.',
    outcome: 'apply',
    expectation: 'Count holding rows, never sum account or security identifiers.',
    fields: ['clientType'],
  },
  {
    id: 'cu-chart-losses',
    category: 'charts',
    title: 'Where unrealized losses sit',
    prompt:
      'For custody holdings with unrealized gain less than zero, create a bar chart of total unrealized gain by asset class.',
    outcome: 'apply',
    expectation: 'Negative bars preserve losses after applying the loss filter.',
    fields: ['unrealizedGain', 'assetClass'],
  },
  {
    id: 'cu-chart-value-cost',
    category: 'charts',
    title: 'Compare market value with cost',
    prompt:
      'Create a grouped column chart of total market value and total cost value by custodian.',
    outcome: 'apply',
    expectation: 'Compare two related USD measures on the same axis.',
    fields: ['marketValue', 'costValue', 'custodian'],
  },
  {
    id: 'cu-chart-relationship',
    category: 'charts',
    title: 'Cost and value relationship',
    prompt:
      'Create a scatter chart with cost value on X and market value on Y for Bond custody holdings in Europe.',
    outcome: 'apply',
    expectation: 'One point per matching holding, preserving gain and loss relationships.',
    fields: ['costValue', 'marketValue', 'assetClass', 'region'],
  },
  {
    id: 'cu-chart-income',
    category: 'charts',
    title: 'Average income by investment type',
    prompt:
      'Create a column chart of average income by asset class for custody holdings with market value at least 100000 USD.',
    outcome: 'apply',
    expectation:
      'Filter first; average only available income observations in each investment type.',
    fields: ['incomeAmount', 'assetClass', 'marketValue'],
  },
  {
    id: 'cu-chart-distribution',
    category: 'charts',
    title: 'Size of equity holdings',
    prompt:
      'Create a histogram of market value for Equity custody holdings with market value at most 1000000 USD.',
    outcome: 'apply',
    expectation:
      'Show the complete filtered distribution, including zero and exact upper boundaries.',
    fields: ['assetClass', 'marketValue'],
  },
  {
    id: 'cu-chart-preview-refine',
    category: 'charts',
    title: 'Review and style a custody chart',
    prompt:
      'For custody holdings in Europe, create a column chart of total market value by custodian.',
    outcome: 'sequence',
    expectation: 'Preview the filtered values, then refine appearance before Apply.',
    fields: ['region', 'marketValue', 'custodian'],
    followUps: [
      {
        title: 'Add clear chart labels',
        prompt:
          'Keep the same data, show labels, hide the legend, and use Market value in USD as the Y axis title.',
        expectation: 'The cohort and values stay unchanged while chart presentation updates.',
      },
    ],
  },
];
