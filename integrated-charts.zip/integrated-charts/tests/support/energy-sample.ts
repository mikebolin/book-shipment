import type { ChartingDataSource } from '../core/data-access/charting-data';
import type { LocalDataset } from './client-data-sources';
import { parseLocalJsonFile } from './local-json-dataset';

export const ENERGY_SAMPLE_ID = 'local_terravolt_energy_portfolio' as const;
export const ENERGY_SAMPLE_OPTION = {
  id: ENERGY_SAMPLE_ID,
  label: 'TerraVolt energy portfolio · 70,080 asset-hours',
};

/** Load the complete synthetic fixture with its column descriptions from this app origin. */
export async function loadEnergySample(
  loadAsset: ChartingDataSource['loadAsset'],
  signal?: AbortSignal,
): Promise<LocalDataset> {
  const response = await loadAsset('energy-sample/UPLOAD_WITH_METADATA.json', signal);
  if (!response.ok)
    throw new Error('The TerraVolt sample could not be loaded. Check that its asset was deployed.');
  const blob = await response.blob();
  const dataset = await parseLocalJsonFile(
    new File([blob], 'UPLOAD_WITH_METADATA.json', { type: 'application/json' }),
    { skipRecipes: true, signal },
  );
  if (dataset.rows.length !== 70_080 || dataset.originalFields.length !== 62)
    throw new Error('The TerraVolt sample is incomplete or does not match its schema.');
  dataset.metadata = {
    ...dataset.metadata,
    id: ENERGY_SAMPLE_ID,
    version: `${ENERGY_SAMPLE_ID}-${dataset.contentHash?.slice(0, 32) ?? 'bundled-v1'}`,
    label: ENERGY_SAMPLE_OPTION.label,
    rowLabel: 'asset-hour',
    local: true,
  };
  dataset.preparedRecipes = [];
  return dataset;
}
