import { Component, inject, provideZonelessChangeDetection } from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';
import { Router, RouterOutlet, provideRouter } from '@angular/router';
import {
  CHARTING_DATA,
  CHARTING_ROUTES,
  STUDIO_QUERY_EXECUTOR,
  WorkspaceStore,
  type AnalyticsRowsRequest,
  type ChartingDataSource,
  type ColumnSpec,
  type ModelResource,
  type StudioExecutionContext,
  type StudioQuery,
  type StudioQueryExecutor,
  type WidgetResource,
  type WidgetConfiguration,
} from '@prism/charting';
// This is deliberately a test-only transport. Hosts implement the public executor interface.
import { MockStudioQueryExecutor } from '../../../libs/charting/src/lib/explorer/mock-studio-query-executor';

interface ProbeRequest {
  request: AnalyticsRowsRequest;
  sql: string;
  binds: unknown[];
  sourceId?: string;
  tenant?: string;
  returnedRows?: number;
  matchedRows?: number;
  totalRows?: number;
  aborted?: boolean;
}
interface ServerGridProbe {
  snapshotCalls: number;
  assetCalls: number;
  queries: ProbeRequest[];
  summaryCalls: number;
  pivotCalls: number;
}
declare global {
  interface Window {
    __serverGridProbe: ServerGridProbe;
    __serverGridHost: {
      view(slug: string): WidgetResource;
      navigate(url: string): Promise<boolean>;
    };
  }
}
window.__serverGridProbe = {
  snapshotCalls: 0,
  assetCalls: 0,
  queries: [],
  summaryCalls: 0,
  pivotCalls: 0,
};

const columns: ColumnSpec[] = [
  { id: 'id', label: 'Activity ID', kind: 'text', sql: 'ACTIVITY_ID', chartRole: 'identifier' },
  {
    id: 'type',
    label: 'Activity type',
    kind: 'text',
    sql: 'ACTIVITY_TYPE',
    chartRole: 'dimension',
  },
  {
    id: 'status',
    label: 'Execution status',
    kind: 'text',
    sql: 'EXECUTION_STATUS',
    chartRole: 'dimension',
  },
  {
    id: 'businessDate',
    label: 'Business date',
    kind: 'date',
    sql: 'BUSINESS_DATE',
    chartRole: 'temporal',
  },
  {
    id: 'started',
    label: 'Started at (UTC)',
    kind: 'datetime',
    sql: 'STARTED_AT',
    chartRole: 'temporal',
  },
  { id: 'events', label: 'Events', kind: 'number', sql: 'EVENT_COUNT', chartRole: 'measure' },
].map((column) => ({
  ...column,
  aliases: [],
  nullable: false,
  description: column.label,
})) as ColumnSpec[];

// Rows live exclusively behind the supplied executor: neither the seed nor snapshot provider
// exposes them to the grid. The fixture executor returns only the requested route and block.
const rows = Array.from({ length: 1_000 }, (_, index) => {
  const date = index % 3 === 0 ? '2026-10-02' : '2026-10-03';
  return {
    id: `event-${String(index).padStart(5, '0')}`,
    type: index % 2 === 0 ? 'Ingestion' : 'Workflow',
    status: index % 4 < 2 ? 'Failed' : 'Breached',
    businessDate: date,
    started: `${date} ${index % 4 < 2 ? '11' : '12'}:${String(index % 60).padStart(2, '0')}:00`,
    events: 1,
  };
});
const now = '2026-10-03T12:00:00.000Z';
const model: ModelResource = {
  id: 'metadata-model',
  kind: 'MODEL',
  slug: 'remote-activity',
  name: 'Remote activity',
  description: 'Metadata-only host integration probe',
  modelId: null,
  version: 1,
  publishedVersion: 1,
  createdAt: now,
  updatedAt: now,
  body: {
    id: 'remote_activity',
    sourceKey: 'remote_activity',
    clientSourceId: 'remote_activity',
    label: 'Remote activity',
    description: 'Metadata-only host integration probe',
    rowLabel: 'events',
    version: '1',
    schemaVersion: '1',
    dataVersion: '1',
    rowCount: rows.length,
    columns,
    defaultVisibleColumnIds: columns.map((column) => column.id),
    sqlDataset: {
      columns,
      table: ['INTEGRATION', 'PUBLIC', 'ACTIVITY_EVENTS'],
      tenantColumn: 'TENANT_ID',
      rowIdColumn: 'id',
    },
  },
};
const widget: WidgetResource = {
  id: 'metadata-widget',
  kind: 'WIDGET',
  slug: 'remote-grid',
  name: 'Remote grouped activity',
  description: 'Published grouped grid backed only by the supplied query executor',
  modelId: model.id,
  version: 1,
  publishedVersion: 1,
  createdAt: now,
  updatedAt: now,
  body: {
    schemaVersion: 1,
    modelSchemaVersion: '1',
    mode: 'advanced',
    displayMode: 'grid',
    allowDownload: true,
    filterControls: { visible: true, parameterizable: true, editMode: 'expression' },
    calculatedColumns: [],
    chart: null,
    gridState: {
      rowGroup: { groupColIds: ['businessDate', 'type'] },
      aggregation: { aggregationModel: [{ colId: 'events', aggFunc: 'sum' }] },
      filter: {
        advancedFilterModel: {
          filterType: 'join',
          type: 'AND',
          conditions: [
            {
              filterType: 'dateString',
              colId: 'businessDate',
              type: 'greaterThanOrEqual',
              filter: '2026-10-03',
            },
            {
              filterType: 'dateTimeString',
              colId: 'started',
              type: 'greaterThanOrEqual',
              filter: '2026-10-03 11:00:00',
            },
          ],
        },
      },
    },
  },
};
const draftChart: NonNullable<WidgetConfiguration['chart']> = {
  id: 'remote-draft-chart',
  plan: {
    type: 'bar',
    categoryColumnId: 'type',
    measureColumnIds: ['events'],
    aggregation: 'sum',
    timeBucket: null,
    title: 'Remote event counts',
  },
  presentation: null,
};
const savedDraft: WidgetResource = {
  ...structuredClone(widget),
  id: 'metadata-saved-draft',
  slug: 'remote-saved-draft',
  name: 'Remote saved activity',
  publishedVersion: null,
  body: {
    ...structuredClone(widget.body),
    displayMode: 'both',
    chart: draftChart,
    charts: [draftChart],
    gridState: {
      ...structuredClone(widget.body.gridState),
      columnVisibility: { hiddenColIds: ['status'] },
      columnOrder: { orderedColIds: ['id', 'started', 'businessDate', 'type', 'events', 'status'] },
      sort: { sortModel: [{ colId: 'events', sort: 'desc' }] },
    },
  },
};

const data: ChartingDataSource = {
  createSeed: () => ({
    resources: { models: [model], widgets: [widget, savedDraft], dashboards: [] },
    revisions: {
      [model.id]: { 1: model },
      [widget.id]: { 1: widget },
      [savedDraft.id]: { 1: savedDraft },
    },
    datasets: {},
    sources: [{ ...model.body, key: model.body.sourceKey, name: model.name }],
  }),
  async loadSnapshot(_model, signal) {
    signal.throwIfAborted();
    window.__serverGridProbe.snapshotCalls++;
    throw new Error('Authorized snapshots are unavailable in this metadata-only host.');
  },
  async loadAsset() {
    window.__serverGridProbe.assetCalls++;
    throw new Error('This metadata-only host has no fixture assets.');
  },
};
const fixture = new MockStudioQueryExecutor(() => ({ rows, columns, rowIdColumn: 'id' }));
const executor: StudioQueryExecutor = {
  async execute(query: StudioQuery, signal: AbortSignal, context?: StudioExecutionContext) {
    const request: ProbeRequest = {
      request: structuredClone(query.request),
      sql: query.rows.sql,
      binds: structuredClone(query.rows.binds),
      sourceId: context?.sourceId,
      tenant: context?.tenant,
    };
    window.__serverGridProbe.queries.push(request);
    try {
      const result = await fixture.execute(query, signal);
      request.returnedRows = result.rowData.length;
      request.matchedRows = result.matchedRowCount;
      request.totalRows = result.totalRowCount;
      return result;
    } catch (error) {
      request.aborted = signal.aborted;
      throw error;
    }
  },
  async discoverPivots(statement, request, signal) {
    window.__serverGridProbe.pivotCalls++;
    return fixture.discoverPivots(statement, request, signal);
  },
  async summarize(statement, signal) {
    window.__serverGridProbe.summaryCalls++;
    return fixture.summarize(statement, signal);
  },
};

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  template: '<router-outlet />',
  styles: ':host { display: block; height: 100dvh; min-height: 0; }',
})
class MetadataOnlyHost {
  private readonly store = inject(WorkspaceStore);
  private readonly router = inject(Router);
  constructor() {
    window.__serverGridHost = {
      view: (slug) => structuredClone(this.store.get<WidgetConfiguration>('widgets', slug)),
      navigate: (url) => this.router.navigateByUrl(url),
    };
  }
}

bootstrapApplication(MetadataOnlyHost, {
  providers: [
    provideZonelessChangeDetection(),
    provideRouter([{ path: '', loadChildren: () => Promise.resolve(CHARTING_ROUTES) }]),
    { provide: CHARTING_DATA, useValue: data },
    { provide: STUDIO_QUERY_EXECUTOR, useValue: executor },
  ],
}).catch(console.error);
