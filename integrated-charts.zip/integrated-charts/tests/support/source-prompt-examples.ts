import type { DataSourceId } from '../core/domain/demo-sources';
import { ADVANCED_EXAMPLES } from './advanced-examples.js';
import { PROMPT_EXAMPLES, type PromptExample } from './prompt-examples.js';
import { CUSTODY_PROMPT_EXAMPLES, TRANSACTION_PROMPT_EXAMPLES } from './finance-prompt-examples.js';
import { TRANSACTION_CHART_EXAMPLES } from './transaction-chart-examples.js';
import { CUSTODY_CHART_EXAMPLES } from './custody-chart-examples.js';
import { withChartDemoType } from './chart-demo-types.js';
import { TRANSACTION_GRID_EXAMPLES, CUSTODY_GRID_EXAMPLES } from './finance-grid-examples.js';
import {
  TRANSACTION_WORKFLOW_EXAMPLES,
  CUSTODY_WORKFLOW_EXAMPLES,
} from './finance-workflow-examples.js';

export const ACCOUNT_ADVANCED_PROMPT_EXAMPLES: readonly PromptExample[] = ADVANCED_EXAMPLES.map(
  (example, index) => ({
    id: `account-advanced-${index + 1}`,
    title: example.label,
    category: index === 6 ? 'boundaries' : index === 4 ? 'calculated' : 'dashboards',
    prompt: example.value,
    outcome: index === 6 ? 'clarify' : index === 4 ? 'calculated' : 'apply',
    expectation: example.description,
    fields: [
      ['status', 'balance', 'delivered'],
      ['status', 'createdDate', 'balance'],
      ['status', 'revenue_2026_Q3', 'netIncome_2026_Q3', 'operatingCashFlow_2026_Q3'],
      ['symbol', 'marketDate', 'closePrice', 'volume'],
      ['revenue_2026_Q2', 'revenue_2026_Q3', 'status'],
      ['status', 'balance', 'delivered'],
      [],
    ][index],
  }),
);
const accountExamples = [...PROMPT_EXAMPLES, ...ACCOUNT_ADVANCED_PROMPT_EXAMPLES].map(
  withChartDemoType,
);
const transactionExamples = [
  ...TRANSACTION_PROMPT_EXAMPLES,
  ...TRANSACTION_CHART_EXAMPLES,
  ...TRANSACTION_WORKFLOW_EXAMPLES,
  ...TRANSACTION_GRID_EXAMPLES,
].map(withChartDemoType);
const custodyExamples = [
  ...CUSTODY_PROMPT_EXAMPLES,
  ...CUSTODY_CHART_EXAMPLES,
  ...CUSTODY_WORKFLOW_EXAMPLES,
  ...CUSTODY_GRID_EXAMPLES,
].map(withChartDemoType);
export function sourcePromptExamples(id: DataSourceId): readonly PromptExample[] {
  return id === 'transactions'
    ? transactionExamples
    : id === 'custody'
      ? custodyExamples
      : accountExamples;
}
