import type { ChartPlan } from '../../libs/charting/src/lib/core/domain/integrated-chart';

export type PromptOutcome = 'apply' | 'calculated' | 'clarify' | 'unsupported' | 'sequence';
export interface PromptExample {
  id: string;
  category: string;
  title: string;
  prompt: string;
  outcome: PromptOutcome;
  expectation: string;
  fields: readonly string[];
  /** Reviewed chart variant, used to browse demos without model inference. */
  chartType?: ChartPlan['type'];
  requirements?: readonly string[];
  /** Prompt-only benchmark follow-up; never an executable answer plan. */
  benchmarkBaseCase?: string | null;
  followUps?: readonly { title: string; prompt: string; expectation: string }[];
}

export const PROMPT_CATEGORIES = [
  {
    id: 'workflows',
    label: 'Guided workflows',
    description: 'Choose data, build a chart, then refine the result',
  },
  {
    id: 'logic',
    label: 'Advanced filters',
    description: 'Nested conditions, text and numeric ranges',
  },
  {
    id: 'dates',
    label: 'Dates & periods',
    description: 'Calendar windows, timestamps and historical prices',
  },
  {
    id: 'sets',
    label: 'Sets & missing values',
    description: 'Explicit selections, exclusions and blanks',
  },
  {
    id: 'analysis',
    label: 'Group, sort & pivot',
    description: 'Multiple dimensions and aggregate measures',
  },
  {
    id: 'calculated',
    label: 'Calculated columns',
    description: 'Review a formula together with its requested grid changes',
  },
  {
    id: 'charts',
    label: 'Charts',
    description: 'Comparisons, trends, relationships and distributions',
  },
  {
    id: 'dashboards',
    label: 'Dashboards & follow-ups',
    description: 'Filtered dashboards and several-turn workflows',
  },
  {
    id: 'boundaries',
    label: 'Clarification & limits',
    description: 'Requests that should ask a question or explain a limitation',
  },
] as const;

export const PROMPT_OUTCOMES: Record<PromptOutcome, string> = {
  apply: 'Ready to review',
  calculated: 'Calculation + changes',
  clarify: 'Asks a question',
  unsupported: 'Explains a limitation',
  sequence: 'Several turns',
};

/** Natural-language drafts and review criteria; selecting an example never runs it. */
export const PROMPT_EXAMPLES: readonly PromptExample[] = [
  {
    id: 'chart-custom-revenue-income',
    category: 'charts',
    title: 'Custom revenue columns and income line',
    outcome: 'apply',
    prompt:
      'For failed or pending accounts, create a custom combination chart by status of total Q3 2026 revenue as grouped columns on the left axis and total Q3 2026 net income as a line on a separate right axis.',
    expectation:
      'Filter first. Map revenue to groupedColumn on the primary axis and net income to line on a secondary axis. Both measures use USD, but the axes have independent scales; preserve losses.',
    fields: ['status', 'revenue_2026_Q3', 'netIncome_2026_Q3'],
    requirements: ['Charts available'],
  },
  {
    id: 'chart-custom-asset-components',
    category: 'charts',
    title: 'Stacked asset columns and total-assets area',
    outcome: 'apply',
    prompt:
      'Create a custom combination chart by status of total Q3 2026 cash and receivables as stacked columns on the left axis, and total Q3 2026 total assets as an area on a separate right axis.',
    expectation:
      'Map cash and receivables to stackedColumn on the primary axis and total assets to area on a secondary axis. Retain the independent axis scales; do not stack total assets with its components.',
    fields: ['status', 'cash_2026_Q3', 'receivables_2026_Q3', 'totalAssets_2026_Q3'],
    requirements: ['Charts available'],
  },
  {
    id: 'chart-custom-cohort-components',
    category: 'charts',
    title: 'Stacked cohort areas with an inventory line',
    outcome: 'apply',
    prompt:
      'For accounts created in September 2026, create a custom combination chart by Created date in daily buckets of total Q3 2026 cash and receivables as stacked areas, and total Q3 2026 inventory as a line, all on the shared left USD axis.',
    expectation:
      'Filter first and sum three measures per creation-day cohort. Use stackedArea for cash and receivables and line for inventory, without a secondary axis. These are synthetic cohort comparisons, not daily historical financial observations.',
    fields: ['createdDate', 'cash_2026_Q3', 'receivables_2026_Q3', 'inventory_2026_Q3'],
    requirements: ['Charts available'],
  },
  {
    id: 'explore-new-request',
    category: 'dashboards',
    title: 'Start a new request with a different cohort',
    outcome: 'sequence',
    prompt: 'Show failed accounts with balances greater than 1000.',
    expectation:
      'Apply the initial failed-account cohort. For the next prompt, choose New request so the new exploration starts without prior filters, grouping, sorting or chart context.',
    fields: ['status', 'balance', 'delivered'],
    requirements: ['Choose New request before the second prompt', 'Charts available'],
    followUps: [
      {
        title: 'New request: pending cohort',
        prompt:
          'Show pending accounts with balances greater than 5000 and create a bar chart of total balance by delivery status.',
        expectation:
          'Replace the failed-account view. Only pending accounts with Balance > 5000 belong to the new cohort; do not AND pending with the old failed filter.',
      },
      {
        title: 'Continue this new exploration',
        prompt:
          'Keep only those accounts where delivery is marked no and chart total balance by status.',
        expectation:
          'Choose Continue request and retain pending plus Balance > 5000 while adding Delivered = no. Use the newly filtered cohort for the chart.',
      },
    ],
  },
  {
    id: 'explore-continue-request',
    category: 'dashboards',
    title: 'Continue a request and preserve filters',
    outcome: 'sequence',
    prompt: 'Show failed or pending accounts with balances greater than 1000.',
    expectation:
      'Apply the initial cohort. Continue the same request for both follow-ups so the status and amount predicates remain active.',
    fields: ['status', 'balance', 'delivered'],
    requirements: ['Choose Continue request for follow-ups', 'Charts available'],
    followUps: [
      {
        title: 'Refine this cohort',
        prompt: 'Within these results, keep only delivery marked no.',
        expectation: 'Add Delivered = no without dropping failed/pending or Balance > 1000.',
      },
      {
        title: 'Chart the retained cohort',
        prompt: 'Create a column chart counting these matching accounts by status.',
        expectation:
          'Make only a chart change. Count rows using exactly the already approved filtered cohort.',
      },
    ],
  },
  {
    id: 'chart-losses-grouped',
    category: 'charts',
    title: 'Filter losses before comparing financials',
    outcome: 'apply',
    prompt:
      'For accounts with Q3 2026 revenue greater than 100000 and Q3 2026 net income below zero, create a grouped column chart of total Q3 2026 revenue and net income by status.',
    expectation:
      'Apply both numeric filters first, then sum each measure by status. Show negative income totals below zero alongside positive revenue totals.',
    fields: ['status', 'revenue_2026_Q3', 'netIncome_2026_Q3'],
    requirements: ['Charts available'],
  },
  {
    id: 'chart-themed-exceptions',
    category: 'charts',
    title: 'Style a filtered balance chart',
    outcome: 'apply',
    prompt:
      'Show failed or pending accounts and create a column chart of total balance by status. Use the AG Material Dark theme, show the legend at the bottom, show value labels, and set the x-axis title to Status and the y-axis title to Total balance (USD).',
    expectation:
      'Apply the filter and aggregate balances. Apply the requested supported theme, legend, labels, and axis titles without changing the source values.',
    fields: ['status', 'balance'],
    requirements: ['Charts available'],
  },
  {
    id: 'chart-themed-share',
    category: 'charts',
    title: 'Style account-share slices',
    outcome: 'apply',
    prompt:
      'Create a pie chart counting accounts by status, including missing statuses. Use the AG Vivid theme, show the legend on the right and show slice labels.',
    expectation:
      'Use nonnegative row counts. Change only chart presentation; the API category counts remain the same as the unstyled pie example.',
    fields: ['status'],
    requirements: ['Charts available'],
  },
  {
    id: 'grouped-cross-column-overlap',
    category: 'logic',
    title: 'Overlapping cross-column OR groups',
    outcome: 'apply',
    prompt:
      'Apply exactly (Status = failed OR Delivered = no) AND (Delivered = no OR Balance > 50000). Preserve the parentheses.',
    expectation:
      'Keep both OR groups under AND, including the repeated delivery predicate. A failed account with confirmed delivery and a low balance does not match.',
    fields: ['status', 'delivered', 'balance'],
    requirements: ['Advanced mode'],
  },
  {
    id: 'grouped-outer-alternative',
    category: 'logic',
    title: 'Two OR groups plus an outer alternative',
    outcome: 'apply',
    prompt:
      'Apply exactly ((Status = failed OR Status = pending) AND (Delivered = no OR Delivered = unknown)) OR (Balance < 0 OR Balance > 90000).',
    expectation:
      'The outer OR admits negative and over-90000 balances independently of status or delivery. Keep the two inner OR groups joined with AND.',
    fields: ['status', 'delivered', 'balance'],
    requirements: ['Advanced mode'],
  },
  {
    id: 'grouped-triple-intersection',
    category: 'logic',
    title: 'Three intersecting OR groups',
    outcome: 'apply',
    prompt:
      'Apply (Status = failed OR Status = pending) AND (Delivered = no OR Balance > 50000) AND (Account name starts with Atlas OR Q3 2026 cash > 25000).',
    expectation:
      'Every parenthesized group must match. Do not flatten six predicates into a global OR or require both alternatives in any group.',
    fields: ['status', 'delivered', 'balance', 'accountName', 'cash_2026_Q3'],
    requirements: ['Advanced mode'],
  },
  {
    id: 'grouped-date-branches',
    category: 'logic',
    title: 'Date alternatives with a loss exception',
    outcome: 'apply',
    prompt:
      'Find ((Created date is in September 2026 OR Account date is in July 2026) AND (Status = completed OR Delivered = yes)) OR (Balance < 0 AND Status = failed).',
    expectation:
      'Each month is its own inclusive-start/exclusive-end range. Join the date alternatives to the status/delivery alternatives; negative failed balances form a separate OR branch.',
    fields: ['createdDate', 'accountDate', 'status', 'delivered', 'balance'],
    requirements: ['Advanced mode'],
  },
  {
    id: 'grouped-financial-alternatives',
    category: 'logic',
    title: 'Scale and financial risk groups',
    outcome: 'apply',
    prompt:
      'Find (Q3 2026 revenue > 100000 OR Balance > 50000) AND ((Q3 2026 net income < 0 OR Q3 2026 operating cash flow < 0) OR (Q3 2026 cash = 0 OR Q3 2026 cash is missing)).',
    expectation:
      'Require one size threshold and one financial risk alternative. Preserve the nested OR groups and distinguish missing cash from a recorded zero.',
    fields: [
      'revenue_2026_Q3',
      'balance',
      'netIncome_2026_Q3',
      'operatingCashFlow_2026_Q3',
      'cash_2026_Q3',
    ],
    requirements: ['Advanced mode'],
  },
  ...(
    [
      [
        'chart-grouped-bar',
        'Grouped bars of synthetic financials',
        'Create a grouped bar chart of total Q3 2026 revenue and net income by status.',
        ['status', 'revenue_2026_Q3', 'netIncome_2026_Q3'],
        'Show separate revenue and net-income bars, preserving loss values.',
      ],
      [
        'chart-stacked-bar',
        'Stacked bars of asset components',
        'Create a stacked bar chart of total Q3 2026 cash, receivables, and inventory by status.',
        ['status', 'cash_2026_Q3', 'receivables_2026_Q3', 'inventory_2026_Q3'],
        'Stack three distinct nonnegative USD components. Missing observations are excluded independently; this is synthetic data.',
      ],
      [
        'chart-normalized-bar',
        'Asset composition in normalized bars',
        'Create a 100% normalized bar chart of total Q3 2026 cash, receivables, and inventory by status.',
        ['status', 'cash_2026_Q3', 'receivables_2026_Q3', 'inventory_2026_Q3'],
        'Return original aggregated USD values; AG Grid normalizes each category to percentages for display.',
      ],
      [
        'chart-grouped-column',
        'Grouped columns for revenue and cost',
        'Create a grouped column chart of total Q3 2026 revenue and cost of revenue by delivery status.',
        ['delivered', 'revenue_2026_Q3', 'costOfRevenue_2026_Q3'],
        'Compare two USD series side by side, retaining the blank delivery category.',
      ],
      [
        'chart-stacked-column',
        'Stacked columns of asset components',
        'Create a stacked column chart of total Q3 2026 cash and receivables by status.',
        ['status', 'cash_2026_Q3', 'receivables_2026_Q3'],
        'Stack separate nonnegative components with an explicit sum aggregation.',
      ],
      [
        'chart-normalized-column',
        'Percentage columns of asset composition',
        'Create a 100% normalized column chart of total Q3 2026 cash and receivables by status.',
        ['status', 'cash_2026_Q3', 'receivables_2026_Q3'],
        'Keep API totals in USD and normalize the two series in the chart. Do not silently normalize negative financial measures.',
      ],
      [
        'chart-stacked-line',
        'Stacked daily component lines',
        'For accounts created in September 2026, create a stacked line chart of total Q3 2026 cash and receivables by Created date, bucketed by day.',
        ['createdDate', 'cash_2026_Q3', 'receivables_2026_Q3'],
        'Filter first, then sum two nonnegative measures for each chronological daily cohort. These are cohort totals, not historical daily financial balances.',
      ],
      [
        'chart-normalized-line',
        'Normalized daily component lines',
        'For accounts created in September 2026, create a 100% normalized line chart of total Q3 2026 cash and receivables by Created date, bucketed by day.',
        ['createdDate', 'cash_2026_Q3', 'receivables_2026_Q3'],
        'Compare composition across creation-date cohorts using original API totals and chart-side normalization.',
      ],
      [
        'chart-area',
        'Filtered account creation area chart',
        'For failed or pending accounts created in September 2026, create an area chart counting accounts by Created date in daily buckets.',
        ['status', 'createdDate'],
        'Apply both filters before counting rows. Include accounts with blank balances; do not fill missing dates with invented zeroes.',
      ],
      [
        'chart-stacked-area',
        'Stacked daily component areas',
        'For accounts created in September 2026, create a stacked area chart of total Q3 2026 cash and receivables by Created date, bucketed by day.',
        ['createdDate', 'cash_2026_Q3', 'receivables_2026_Q3'],
        'Stack the daily creation-cohort totals in date order. The dates describe account creation, not dates when financial amounts were observed.',
      ],
      [
        'chart-normalized-area',
        'Normalized daily component areas',
        'For accounts created in September 2026, create a 100% normalized area chart of total Q3 2026 cash and receivables by Created date, bucketed by day.',
        ['createdDate', 'cash_2026_Q3', 'receivables_2026_Q3'],
        'Use nonnegative sums; normalize in AG Grid and retain source values in the API response.',
      ],
      [
        'chart-pie',
        'Account-count share by status',
        'Create a pie chart counting accounts by status, including missing statuses.',
        ['status'],
        'Use count of rows for the slices, including the blank category. Never use identifiers as numeric measures.',
      ],
      [
        'chart-donut',
        'Filtered delivery share',
        'For failed or pending accounts with balance greater than 1000, create a donut chart counting accounts by delivery status, including missing delivery values.',
        ['status', 'balance', 'delivered'],
        'Filter the authorized cohort first, then count all matching accounts in each delivery category.',
      ],
      [
        'chart-bubble',
        'Revenue, profit and asset size',
        'For accounts with Q3 2026 revenue greater than 100000, create a bubble chart with Q3 2026 revenue on x, Q3 2026 net income on y, and Q3 2026 total assets as bubble size.',
        ['revenue_2026_Q3', 'netIncome_2026_Q3', 'totalAssets_2026_Q3'],
        'Use three unaggregated numeric measures. Preserve negative income; omit incomplete triples; bubble sizes must be nonnegative.',
      ],
      [
        'chart-column-line-combo',
        'Revenue columns with an income line',
        'For failed or pending accounts, create a column-line combination chart of total Q3 2026 revenue and total Q3 2026 net income by status, in that series order.',
        ['status', 'revenue_2026_Q3', 'netIncome_2026_Q3'],
        'Filter first. Use revenue as columns and net income as a line on the same USD axis; preserve losses.',
      ],
      [
        'chart-area-column-combo',
        'Cash area and receivables columns',
        'For accounts created in September 2026, create an area-column combination chart of total Q3 2026 cash and total Q3 2026 receivables by Created date in daily buckets, in that series order.',
        ['createdDate', 'cash_2026_Q3', 'receivables_2026_Q3'],
        'Filter first, then chart the two USD totals in date order, with cash as an area and receivables as columns.',
      ],
    ] as const
  ).map(
    ([id, title, prompt, fields, expectation]): PromptExample => ({
      id,
      category: 'charts',
      title,
      prompt,
      fields,
      expectation,
      outcome: 'apply',
      requirements: ['Charts available'],
    }),
  ),
  {
    id: 'chart-nested-exceptions',
    category: 'charts',
    title: 'Nested filter, then compare balances',
    outcome: 'apply',
    prompt:
      'Filter to ((Status = failed OR Status = pending) AND (Delivered = no OR Delivered = unknown)) OR (Balance < 0 OR Balance > 90000), then create a bar chart of total balance by status.',
    expectation:
      'Preserve the outer OR and both inner OR groups. Chart every matching authorized row, including negative balances and the outer-branch statuses.',
    fields: ['status', 'delivered', 'balance'],
    requirements: ['Advanced mode', 'Charts available'],
  },
  ...(
    [
      [
        'filter-then-chart-exceptions',
        'Filter exceptions, then chart and refine',
        'Show failed or pending accounts with balances greater than 1000.',
        ['status', 'balance', 'delivered'],
        'Create a donut chart counting the matching accounts by delivery status, including missing delivery values.',
        'Retain the status and balance filter; chart counts of the filtered cohort.',
        'Keep only delivery marked no and show a bar chart of total balance by status.',
        'Add Delivered = no to the existing filter before summing balances.',
      ],
      [
        'filter-then-chart-dates',
        'Filter a period, then chart daily cohorts',
        'Show failed or pending accounts created in September 2026.',
        ['status', 'createdDate', 'balance'],
        'Create an area chart counting these matching accounts by Created date in daily buckets.',
        'Keep the status and September range; count all matching rows by day.',
        'Keep only accounts with balances greater than 5000 and make a line chart counting matching accounts by Created date in daily buckets.',
        'Add the balance threshold before daily row counts; do not use the visible page as the source.',
      ],
      [
        'filter-then-chart-financials',
        'Filter synthetic financials, then compare',
        'Show accounts with Q3 2026 revenue greater than 100000.',
        ['revenue_2026_Q3', 'netIncome_2026_Q3', 'totalAssets_2026_Q3', 'status'],
        'Create a bubble chart with Q3 2026 revenue on x, Q3 2026 net income on y, and Q3 2026 total assets as bubble size for these accounts.',
        'Preserve the revenue filter and omit only rows missing any selected measure.',
        'Keep only accounts with negative Q3 2026 net income, then create a grouped column chart of total Q3 2026 revenue and net income by status.',
        'Refine to losses first, then aggregate the same filtered cohort. Keep negative income totals.',
      ],
    ] as const
  ).map(
    ([
      id,
      title,
      prompt,
      fields,
      chartPrompt,
      chartExpectation,
      refinePrompt,
      refineExpectation,
    ]): PromptExample => ({
      id,
      category: 'dashboards',
      title,
      prompt,
      fields,
      outcome: 'sequence',
      expectation:
        'Review and apply the filter first. Each follow-up charts or refines the currently approved matching cohort.',
      requirements: ['Charts available'],
      followUps: [
        { title: 'Chart the matching rows', prompt: chartPrompt, expectation: chartExpectation },
        {
          title: 'Refine the filter and chart',
          prompt: refinePrompt,
          expectation: refineExpectation,
        },
      ],
    }),
  ),
  {
    id: 'chart-balance-by-status',
    category: 'charts',
    title: 'Bar chart of exception balances',
    outcome: 'apply',
    prompt: 'Show failed or pending accounts and create a bar chart of total balance by status.',
    expectation:
      'Filter to failed and pending, then sum Balance by Status across all matching accounts. Review the filter and chart together.',
    fields: ['status', 'balance'],
    requirements: ['Charts available'],
  },
  {
    id: 'chart-account-counts',
    category: 'charts',
    title: 'Column chart of account counts',
    outcome: 'apply',
    prompt:
      'Create a column chart counting accounts by delivery status, including missing delivery values.',
    expectation:
      'Count rows by Delivered, including the blank category and accounts with missing balances. Do not count only nonblank balances.',
    fields: ['delivered'],
    requirements: ['Charts available'],
  },
  {
    id: 'chart-financial-comparison',
    category: 'charts',
    title: 'Compare three financial measures',
    outcome: 'apply',
    prompt:
      'Create a column chart by status showing total Q3 2026 revenue, net income, and operating cash flow as separate series.',
    expectation:
      'Sum the three specified USD measures by Status on the same chart. Retain negative values and exclude missing observations from each sum.',
    fields: ['status', 'revenue_2026_Q3', 'netIncome_2026_Q3', 'operatingCashFlow_2026_Q3'],
    requirements: ['Charts available'],
  },
  {
    id: 'chart-daily-creations',
    category: 'charts',
    title: 'Daily account creation trend',
    outcome: 'apply',
    prompt:
      'For accounts created this month, make a line chart of the number of accounts created each day using Created date.',
    expectation:
      'Filter Created date to this calendar month and count rows in daily Created date buckets, ordered chronologically.',
    fields: ['createdDate'],
    requirements: ['Charts available'],
  },
  {
    id: 'chart-monthly-market-prices',
    category: 'charts',
    title: 'Monthly historical price comparison',
    outcome: 'apply',
    prompt:
      'For AAPL trading days in 2016, make a line chart of average open price and average close price by month using Market date.',
    expectation:
      'Filter Symbol and Market date to AAPL in 2016. Average both prices in chronological monthly buckets. This chart uses matching account rows with repeated historical observations; use the market dashboard for a deduplicated market series.',
    fields: ['symbol', 'marketDate', 'openPrice', 'closePrice'],
    requirements: ['Charts available'],
  },
  {
    id: 'chart-revenue-income-relationship',
    category: 'charts',
    title: 'Revenue versus net income',
    outcome: 'apply',
    prompt:
      'Create a scatter plot with Q3 2026 revenue on the x-axis and Q3 2026 net income on the y-axis.',
    expectation:
      'Plot two unaggregated numeric measures for each matching account. Omit pairs with a missing value, preserve losses and outliers, and do not imply causation.',
    fields: ['revenue_2026_Q3', 'netIncome_2026_Q3'],
    requirements: ['Charts available'],
  },
  {
    id: 'chart-price-volume-relationship',
    category: 'charts',
    title: 'Historical price versus volume',
    outcome: 'apply',
    prompt:
      'For AAPL trading days in 2016, create a scatter plot with close price on the x-axis and volume on the y-axis.',
    expectation:
      'Apply the historical cohort filter and plot Close price against Volume without aggregation. The axes have separate USD and share units; repeated observations come from synthetic accounts.',
    fields: ['symbol', 'marketDate', 'closePrice', 'volume'],
    requirements: ['Charts available'],
  },
  {
    id: 'chart-balance-distribution',
    category: 'charts',
    title: 'Balance distribution',
    outcome: 'apply',
    prompt: 'Create a histogram of account balances, including zero and negative balances.',
    expectation:
      'Use unaggregated Balance observations, omit missing balances, and retain zero, negative values and outliers when building the distribution.',
    fields: ['balance'],
    requirements: ['Charts available'],
  },
  {
    id: 'chart-largest-balance',
    category: 'charts',
    title: 'Largest balance in each status',
    outcome: 'apply',
    prompt: 'Create a bar chart of the maximum account balance in each status.',
    expectation:
      'Use max(Balance) by Status across the full matching cohort, excluding missing balances from the maximum.',
    fields: ['status', 'balance'],
    requirements: ['Charts available'],
  },
  {
    id: 'chart-smallest-balance',
    category: 'charts',
    title: 'Smallest balance by delivery',
    outcome: 'apply',
    prompt: 'Create a column chart of the minimum account balance for each delivery status.',
    expectation:
      'Use min(Balance) by Delivered. Keep negative and zero balances and include the blank delivery category.',
    fields: ['delivered', 'balance'],
    requirements: ['Charts available'],
  },
  {
    id: 'largest-accounts-within-groups',
    category: 'analysis',
    title: 'Largest accounts within each status',
    outcome: 'apply',
    prompt:
      'Show pending and failed accounts created this month. Group them by status with the biggest balances first inside each group.',
    expectation:
      'Apply the status and Created date filters. Keep parent groups in Status order and sort individual accounts by Balance descending when a group is expanded. No SUM or other aggregation is required.',
    fields: ['status', 'createdDate', 'balance'],
  },
  {
    id: 'nested-delivery',
    category: 'logic',
    title: 'Failed or pending delivery exceptions',
    outcome: 'apply',
    prompt: 'Find failed or pending accounts over $1,000 where delivery is marked no or unknown.',
    expectation:
      'Preserve both parenthesized OR groups inside one AND. Require Balance > 1000 and exclude blanks.',
    fields: ['status', 'delivered', 'balance'],
    requirements: ['Advanced mode'],
  },
  {
    id: 'nested-names',
    category: 'logic',
    title: 'Named accounts with two balance bands',
    outcome: 'apply',
    prompt:
      'Find names starting with Atlas or containing Northstar, with balances from $1,000 up to but not including $5,000, or at least $50,000. Biggest balances first.',
    expectation:
      'Keep the two alternative balance bands grouped under the name condition. Sort only the matching rows by Balance descending.',
    fields: ['accountName', 'balance'],
    requirements: ['Advanced mode', 'Start from an ungrouped view'],
  },
  {
    id: 'financial-alternatives',
    category: 'logic',
    title: 'Revenue with profit or cash-flow alternatives',
    outcome: 'apply',
    prompt:
      'Show accounts with over $100,000 revenue in Q3 2026 and either positive net income or positive operating cash flow that quarter. Leave out failed accounts and accounts with no status.',
    expectation:
      'Require revenue and a nonfailed nonblank Status, while allowing either positive net income or positive operating cash flow.',
    fields: ['revenue_2026_Q3', 'netIncome_2026_Q3', 'operatingCashFlow_2026_Q3', 'status'],
    requirements: ['Advanced mode'],
  },
  {
    id: 'bounded-range',
    category: 'logic',
    title: 'Exact range boundaries and priority sorting',
    outcome: 'apply',
    prompt:
      'Find balances of at least $1,000 but under $5,000. Show the newest accounts first, and the largest balances first when the creation dates are the same.',
    expectation:
      'Use a lower-inclusive, upper-exclusive numeric range: 1000 <= Balance < 5000. Preserve the requested two-column sort priority.',
    fields: ['balance', 'createdDate'],
    requirements: ['Start from an ungrouped view'],
  },
  {
    id: 'three-way-logic',
    category: 'logic',
    title: 'Three explicit business alternatives',
    outcome: 'apply',
    prompt:
      'I need failed accounts over $5,000, pending accounts that were not delivered, and completed accounts with Meridian in their name.',
    expectation:
      'Build one OR with three two-condition AND branches; keep all six predicates and their grouping.',
    fields: ['status', 'balance', 'delivered', 'accountName'],
    requirements: ['Advanced mode'],
  },
  {
    id: 'hidden-quarterly-fields',
    category: 'logic',
    title: 'Screen hidden quarterly fields',
    outcome: 'apply',
    prompt:
      'For Q3 2026, find accounts with current assets over $100,000 and current liabilities below $500,000, plus either cash over $25,000 or receivables over $75,000. Largest current assets first.',
    expectation:
      'Use the actual quarterly fields even when their columns are hidden. Keep the cash/receivables alternatives inside the surrounding AND.',
    fields: [
      'currentAssets_2026_Q3',
      'currentLiabilities_2026_Q3',
      'cash_2026_Q3',
      'receivables_2026_Q3',
    ],
    requirements: ['Advanced mode', 'Start from an ungrouped view'],
  },
  {
    id: 'reported-failed-request',
    category: 'dates',
    title: 'Failed records created this month',
    outcome: 'apply',
    prompt:
      'find the failed records created this month that did not get delivered. Ensure the balance was more than 1,000',
    expectation:
      'Use Status = failed, Created date within this calendar month, Delivered = no, and Balance > 1000. Literal unknown and blank delivery values are excluded. Show the resolved month boundaries in the review.',
    fields: ['status', 'createdDate', 'delivered', 'balance'],
  },
  {
    id: 'updated-last-week',
    category: 'dates',
    title: 'Last complete week in the user timezone',
    outcome: 'apply',
    prompt:
      'Find completed accounts updated last week with more than $2,500 in balance. Most recently updated first.',
    expectation:
      'Filter Updated at with UTC bounds representing the previous complete local calendar week, lower-inclusive and upper-exclusive. Retain Status = completed and Balance > 2500.',
    fields: ['status', 'updatedAt', 'balance'],
    requirements: ['Start from an ungrouped view'],
  },
  {
    id: 'two-explicit-date-fields',
    category: 'dates',
    title: 'Creation and business dates both yesterday',
    outcome: 'apply',
    prompt:
      'Show failed or pending accounts that were created yesterday and also have yesterday as their business date.',
    expectation:
      'Use both explicitly named calendar-date fields with yesterday resolved from the server clock and user timezone. Do not substitute Updated at.',
    fields: ['createdDate', 'accountDate', 'status'],
    requirements: ['Advanced mode'],
  },
  {
    id: 'historical-market-window',
    category: 'dates',
    title: 'Historical AAPL price and volume screen',
    outcome: 'apply',
    prompt:
      'Find AAPL trading days in 2016 with a closing price under $100 and at least 100 million shares traded. Oldest trading day first.',
    expectation:
      'Filter the historical market fields for the explicitly supplied 2016 interval. These are historical observations, not current prices.',
    fields: ['symbol', 'marketDate', 'closePrice', 'volume'],
    requirements: ['Start from an ungrouped view'],
  },
  {
    id: 'rolling-calendar-window',
    category: 'dates',
    title: 'Seven calendar days including today',
    outcome: 'apply',
    prompt:
      'Show accounts created in the last seven calendar days, including today, that were not delivered and have at least $1,000. Newest first.',
    expectation:
      'Resolve an explicit seven-calendar-day Created date interval ending after today. Keep Delivered = no and the inclusive Balance threshold; disclose exact dates.',
    fields: ['createdDate', 'delivered', 'balance'],
    requirements: ['Start from an ungrouped view'],
  },
  {
    id: 'status-set-includes-blank',
    category: 'sets',
    title: 'Include selected statuses and blanks',
    outcome: 'apply',
    prompt:
      'Show failed and pending accounts, plus accounts with no status, where the balance is over $1,000.',
    expectation:
      'The selected Status set includes null alongside failed and pending. Blank balances still fail the ordinary numeric comparison.',
    fields: ['status', 'balance'],
    requirements: ['Set Filters on'],
  },
  {
    id: 'delivery-set-exclusion',
    category: 'sets',
    title: 'Exclude no, unknown and blank delivery',
    outcome: 'apply',
    prompt:
      'Find balances of at least $5,000 where delivery is confirmed. Leave out no, unknown, and missing delivery values.',
    expectation:
      'Explicitly exclude null and the two named delivery values. In the current schema, only Delivered = yes remains.',
    fields: ['delivered', 'balance'],
    requirements: ['Set Filters on'],
  },
  {
    id: 'unknown-versus-blank',
    category: 'sets',
    title: 'Unknown delivery and missing delivery together',
    outcome: 'apply',
    prompt:
      'Find failed or pending accounts where delivery is marked unknown or has been left empty.',
    expectation:
      'Select both unknown and null for Delivered, and failed/pending for Status. Combine the two columns with AND.',
    fields: ['delivered', 'status'],
    requirements: ['Set Filters on'],
  },
  {
    id: 'two-native-sets',
    category: 'sets',
    title: 'Two native sets plus a numeric interval',
    outcome: 'apply',
    prompt:
      'Find failed or pending accounts with delivery marked no or unknown and balances from $1,000 up to but not including $10,000.',
    expectation:
      'Use bounded Status/Delivered selections and a two-predicate Balance range. This combination is representable in Advanced or column-filter mode.',
    fields: ['status', 'delivered', 'balance'],
    requirements: ['Set Filters on'],
  },
  {
    id: 'set-exclusion-keeps-blank',
    category: 'sets',
    title: 'Exclusion that deliberately keeps blanks',
    outcome: 'apply',
    prompt:
      'Leave out completed and delivered statuses, but keep accounts with no status. Largest balances first.',
    expectation:
      'Exclude only the two specified statuses. Retain failed, pending and null; do not silently turn the exclusion into comparisons that remove blanks.',
    fields: ['status', 'balance'],
    requirements: ['Set Filters on', 'Start from an ungrouped view'],
  },
  {
    id: 'three-aggregate-functions',
    category: 'analysis',
    title: 'Group with sum, average and maximum',
    outcome: 'apply',
    prompt:
      'Break down accounts by status with total balance, average Q3 2026 revenue, and the highest Q3 2026 net income. Put the statuses with the most total balance first.',
    expectation:
      'Use sum(Balance), avg(Revenue 2026 Q3), and max(Net income 2026 Q3) on three distinct columns. Order status groups by summed Balance descending.',
    fields: ['status', 'balance', 'revenue_2026_Q3', 'netIncome_2026_Q3'],
    requirements: ['Start with no conflicting sort'],
  },
  {
    id: 'three-level-groups',
    category: 'analysis',
    title: 'Three-level grouping with two measures',
    outcome: 'apply',
    prompt:
      'Break the accounts down by status, then delivery, then business date. For each group show total balance and average Q3 2026 revenue, with statuses and delivery values in alphabetical order.',
    expectation:
      'Use all three supported grouping levels in order and two numeric measures. Group expansion should load children through SSRM.',
    fields: ['status', 'delivered', 'accountDate', 'balance', 'revenue_2026_Q3'],
    requirements: ['Start with no conflicting sort'],
  },
  {
    id: 'delivery-pivot-two-measures',
    category: 'analysis',
    title: 'Pivot delivery with two measures',
    outcome: 'apply',
    prompt:
      'For failed or pending accounts over $1,000, put statuses down the rows and delivery values across the columns. Show total balance and average Q3 2026 revenue.',
    expectation:
      'Apply the filter and build delivery pivot columns with two independently aggregated values over the full filtered cohort.',
    fields: ['status', 'delivered', 'balance', 'revenue_2026_Q3'],
    requirements: ['Advanced mode', 'Start with no conflicting sort'],
  },
  {
    id: 'two-dimension-pivot',
    category: 'analysis',
    title: 'Two pivot dimensions and two measures',
    outcome: 'apply',
    prompt:
      'Put status down the rows, and delivery then ticker across the columns. Show total Q3 2026 revenue and the highest balance, with statuses in alphabetical order.',
    expectation:
      'Use two nonnumeric pivot dimensions and distinct sum/max measures. The sample contains AAPL, so the Symbol dimension has one observed ticker.',
    fields: ['status', 'delivered', 'symbol', 'revenue_2026_Q3', 'balance'],
    requirements: ['Start with no conflicting sort'],
  },
  {
    id: 'three-column-sort',
    category: 'analysis',
    title: 'Three-column sorting priority',
    outcome: 'apply',
    prompt:
      'Show individual accounts again. Sort by status alphabetically, then newest creation date, then largest balance.',
    expectation:
      'Interpret “individual accounts again” as leaving grouping and pivoting. Keep the current filters and apply Status ascending, Created date descending, and Balance descending in that order.',
    fields: ['status', 'createdDate', 'balance'],
  },
  {
    id: 'eight-measure-rollup',
    category: 'analysis',
    title: 'Eight-measure status rollup',
    outcome: 'apply',
    prompt:
      'Give me totals by status for balance and these Q3 2026 figures: revenue, net income, operating cash flow, cash, current assets, total assets, and equity. List statuses alphabetically.',
    expectation:
      'Use the supported eight-value limit, with one aggregation per distinct column. Do not infer financial relationships between these synthetic metrics.',
    fields: [
      'status',
      'balance',
      'revenue_2026_Q3',
      'netIncome_2026_Q3',
      'operatingCashFlow_2026_Q3',
      'cash_2026_Q3',
      'currentAssets_2026_Q3',
      'totalAssets_2026_Q3',
      'equity_2026_Q3',
    ],
    requirements: ['Start with no conflicting sort'],
  },
  {
    id: 'revenue-growth-positive',
    category: 'calculated',
    title: 'Revenue grew from Q2 to Q3',
    outcome: 'calculated',
    prompt: 'I want to find accounts where revenue grew in 2026 Q3 compared with 2026 Q2.',
    expectation:
      'Infer that comparing two quarterly columns needs a row calculation: Revenue 2026 Q3 minus Revenue 2026 Q2. Review the derived column and > 0 filter together; one approval completes the request.',
    fields: ['revenue_2026_Q3', 'revenue_2026_Q2'],
    requirements: ['Calculated columns available', 'Fewer than eight active calculated columns'],
  },
  {
    id: 'revenue-growth-percent',
    category: 'calculated',
    title: 'More than ten percent quarterly growth',
    outcome: 'calculated',
    prompt:
      'Which accounts grew revenue by more than 10% from Q2 to Q3 2026? Only include accounts with positive Q2 revenue, and put the fastest percentage growth first.',
    expectation:
      'Infer percentage growth as 100 * (Q3 revenue - Q2 revenue) / Q2 revenue, with Q2 revenue > 0, growth > 10, and descending growth order. Review and apply the compound plan with one approval.',
    fields: ['revenue_2026_Q3', 'revenue_2026_Q2'],
    requirements: ['Calculated columns available', 'Start from an ungrouped view'],
  },
  {
    id: 'explicit-row-margin',
    category: 'calculated',
    title: 'Net income as a share of revenue',
    outcome: 'calculated',
    prompt:
      'Find accounts whose Q3 2026 net income was more than 15% of revenue, with positive revenue that quarter.',
    expectation:
      'Derive each account’s Net income / Revenue for Q3 2026, require positive revenue and a ratio > 0.15 (equivalently, percentage > 15). Review the calculation and filter together.',
    fields: ['netIncome_2026_Q3', 'revenue_2026_Q3'],
    requirements: ['Calculated columns available'],
  },
  {
    id: 'daily-price-change',
    category: 'calculated',
    title: 'Positive historical intraday price change',
    outcome: 'calculated',
    prompt:
      'Find trading days when the closing price was above the opening price, with the biggest dollar increase first.',
    expectation:
      'Create a row-level historical price difference, apply > 0 and sort it after one compound approval. Do not claim it is an investment return or current quote.',
    fields: ['closePrice', 'openPrice'],
    requirements: ['Calculated columns available', 'Start from an ungrouped view'],
  },
  {
    id: 'adjusted-balance-rollup',
    category: 'calculated',
    title: 'Adjusted balance grouped totals',
    outcome: 'calculated',
    prompt:
      'What would the total balance by status look like if each account balance were 10% higher?',
    expectation:
      'Review the scalar formula and grouped sum together. Compute row values before aggregation and preserve untouched filters.',
    fields: ['balance', 'status'],
    requirements: ['Calculated columns available', 'Start with no conflicting sort'],
  },
  {
    id: 'cash-coverage-screen',
    category: 'calculated',
    title: 'Cash coverage below one',
    outcome: 'calculated',
    prompt:
      'For Q3 2026, divide cash by current liabilities for each account. Find ratios below 1 where liabilities are positive, then show the average ratio by status.',
    expectation:
      'Review the ratio, denominator guard, filter, grouping and average as one compound request. Average the qualifying row ratios rather than dividing aggregate totals.',
    fields: ['cash_2026_Q3', 'currentLiabilities_2026_Q3', 'status'],
    requirements: ['Calculated columns available', 'Start with no conflicting sort'],
  },
  {
    id: 'filtered-portfolio-dashboard',
    category: 'dashboards',
    title: 'Portfolio dashboard for delivery failures',
    outcome: 'apply',
    prompt:
      'Show a balance dashboard for failed accounts that were not delivered and have more than $5,000.',
    expectation:
      'Review all three filters and the portfolio dashboard together. Dashboard totals use all matching source rows, not only the visible grid page.',
    fields: ['status', 'delivered', 'balance'],
    requirements: ['Dashboards available'],
  },
  {
    id: 'filtered-financial-dashboard',
    category: 'dashboards',
    title: 'Quarterly performance for a filtered cohort',
    outcome: 'apply',
    prompt:
      'Give me a Q3 2026 financial dashboard for accounts with revenue over $100,000 and positive net income that quarter.',
    expectation:
      'Select the explicit quarter and filter the source cohort before computing the fixed financial metrics and recent-quarter comparison.',
    fields: ['revenue_2026_Q3', 'netIncome_2026_Q3'],
    requirements: ['Dashboards available'],
  },
  {
    id: 'historical-market-dashboard',
    category: 'dashboards',
    title: 'Historical market dashboard for 2016',
    outcome: 'apply',
    prompt: 'Show a dashboard of AAPL prices during 2016.',
    expectation:
      'Filter the explicit historical period, then deduplicate symbol/date observations for prices and traded volume. Do not multiply volume by repeated account rows.',
    fields: ['symbol', 'marketDate'],
    requirements: ['Dashboards available'],
  },
  {
    id: 'refine-delivery-workflow',
    category: 'dashboards',
    title: 'Refine an approved account selection',
    outcome: 'sequence',
    prompt: 'Show failed or pending accounts with more than $1,000.',
    expectation:
      'First review and apply this base selection. Then use the follow-up with Current filters set to Refine with AND.',
    fields: ['status', 'balance', 'delivered', 'updatedAt'],
    requirements: ['Advanced mode'],
    followUps: [
      {
        title: 'Then narrow the selection',
        prompt: 'Of those, only the ones that were not delivered and were updated last week.',
        expectation:
          'With Refine with AND selected, keep the original Status/Balance selection and add Delivered = no plus the previous complete week on Updated at.',
      },
      {
        title: 'Then summarize it',
        prompt: 'Now total their balances by status.',
        expectation: 'Retain the selected cohort and add Status grouping with summed Balance.',
      },
    ],
  },
  {
    id: 'calculated-cohort-dashboard',
    category: 'dashboards',
    title: 'Use a calculated field to choose a dashboard cohort',
    outcome: 'sequence',
    prompt: 'If every balance increased by 10%, which accounts would be over $10,000?',
    expectation:
      'Approve the compound calculation and filter first. Then request a dashboard over the resulting cohort.',
    fields: ['balance'],
    requirements: ['Calculated columns and dashboards available'],
    followUps: [
      {
        title: 'Then build the dashboard',
        prompt: 'Show a balance dashboard for those accounts.',
        expectation:
          'Retain the calculated filter as the cohort definition. The portfolio dashboard still reports recorded Balance rather than substituting the hypothetical increased balance.',
      },
    ],
  },
  {
    id: 'ambiguous-date-column',
    category: 'boundaries',
    title: 'Missing date-field choice',
    outcome: 'clarify',
    prompt: 'Group the completed records from last week by status and total their balances.',
    expectation:
      'Offer the relevant Created date, Updated at, and Account date choices for “last week”. Carry forward completed Status, grouping, and summed Balance when the user answers.',
    fields: ['status', 'createdDate', 'updatedAt', 'balance'],
    followUps: [
      {
        title: 'Choose creation dates',
        prompt: 'The date they were created.',
        expectation:
          'Resolve the original complete request on Created date without asking the user to restate its Status, grouping, or sum.',
      },
    ],
  },
  {
    id: 'ambiguous-boolean-grouping',
    category: 'boundaries',
    title: 'Unclear AND / OR grouping',
    outcome: 'clarify',
    prompt: 'Show failed accounts or accounts with unknown delivery and a balance over $1,000.',
    expectation:
      'Clarify whether the $1,000 threshold applies to both failed accounts and unknown-delivery accounts, or only to the unknown-delivery branch. Present those two interpretations as choices and retain the request for the reply.',
    fields: ['status', 'delivered', 'balance'],
    requirements: ['Advanced mode'],
    followUps: [
      {
        title: 'Choose both branches',
        prompt: 'Both types should be over $1,000.',
        expectation:
          'Apply the Balance threshold to the entire failed-or-unknown-delivery selection.',
      },
    ],
  },
  {
    id: 'pivot-missing-measure',
    category: 'boundaries',
    title: 'Pivot without a value or aggregation',
    outcome: 'clarify',
    prompt: 'Put status down the rows and delivery across the columns.',
    expectation:
      'Without an existing measure to reuse, ask what should populate the pivot, for example total Balance or average Balance. Offer concrete choices and make no partial change while waiting.',
    fields: ['delivered', 'status'],
    requirements: ['Start without an existing aggregation'],
  },
  {
    id: 'unresolved-delivery',
    category: 'boundaries',
    title: 'An undefined delivery business term',
    outcome: 'clarify',
    prompt: 'Show failed accounts with unresolved delivery.',
    expectation:
      'Ask which delivery values “unresolved” includes: no, the literal unknown, blank, or a specified combination. Do not invent this business definition.',
    fields: ['status', 'delivered'],
  },
  {
    id: 'unsupported-forecast',
    category: 'boundaries',
    title: 'Live quotes and forecasting',
    outcome: 'unsupported',
    prompt:
      'Use today’s AAPL price to predict next month’s closing price and show the profitable trades.',
    expectation:
      'Explain that the fixture contains historical observations and account records, with no live quotes, forecast model or trade-profit data. Apply no partial filter.',
    fields: [],
  },
  {
    id: 'unsupported-window-calculation',
    category: 'boundaries',
    title: 'Running totals and ranking',
    outcome: 'unsupported',
    prompt:
      'Show a running balance by creation date within each status, and rank the accounts by that running balance.',
    expectation:
      'Explain that row-level arithmetic does not support window calculations or ranks. The supported sort must not be applied by itself.',
    fields: ['createdDate', 'balance', 'status'],
  },
  {
    id: 'unsupported-write',
    category: 'boundaries',
    title: 'A request to modify source records',
    outcome: 'unsupported',
    prompt: 'Delete all failed accounts and show me the remaining records.',
    expectation:
      'Explain that this assistant explores data and cannot delete source records. No deletion or partial “remaining records” filter is performed.',
    fields: ['status'],
  },
  {
    id: 'name-prefix-suffix',
    category: 'logic',
    title: 'Names with either ending and one prefix',
    outcome: 'apply',
    prompt:
      'Find account names starting with North and ending in either Holdings or Capital, with balances over $2,500.',
    expectation:
      'Combine startsWith(North) AND (endsWith(Holdings) OR endsWith(Capital)) AND Balance > 2500. Keep the suffix alternatives together.',
    fields: ['accountName', 'balance'],
    requirements: ['Advanced mode'],
  },
  {
    id: 'text-exclusion-alternatives',
    category: 'logic',
    title: 'Name exclusions with status alternatives',
    outcome: 'apply',
    prompt:
      'Find failed or pending accounts with Northstar in the name, but leave out names containing Test or Demo.',
    expectation:
      'Require the Status alternatives and contains(Northstar), then exclude both contains(Test) and contains(Demo). The two exclusions combine with AND.',
    fields: ['accountName', 'status'],
    requirements: ['Advanced mode'],
  },
  {
    id: 'exact-money-boundaries',
    category: 'logic',
    title: 'Cent-accurate boundaries',
    outcome: 'apply',
    prompt:
      'Show balances from $1,000.01 through $4,999.99, including both amounts, that were not delivered.',
    expectation:
      'Preserve both two-decimal bounds exactly, use >= and <=, and require Delivered = no.',
    fields: ['balance', 'delivered'],
  },
  {
    id: 'status-specific-thresholds',
    category: 'logic',
    title: 'A different threshold for each status',
    outcome: 'apply',
    prompt:
      'Show failed accounts over $10,000 or pending accounts over $50,000. For either kind, delivery must be no or unknown.',
    expectation:
      'Build ((failed AND Balance > 10000) OR (pending AND Balance > 50000)) AND Delivered in [no, unknown]. Do not apply one branch’s threshold to the other.',
    fields: ['status', 'balance', 'delivered'],
    requirements: ['Advanced mode'],
  },
  {
    id: 'paired-market-screens',
    category: 'logic',
    title: 'Two historical price and volume combinations',
    outcome: 'apply',
    prompt:
      'For AAPL in 2016, find days that closed below $95 on more than 80 million shares, or above $110 on fewer than 30 million shares.',
    expectation:
      'Require Symbol and the 2016 Market date window around two separate price/volume AND branches joined with OR. Convert “million” into exact integer share counts.',
    fields: ['symbol', 'marketDate', 'closePrice', 'volume'],
    requirements: ['Advanced mode'],
  },
  {
    id: 'explicit-creation-period',
    category: 'dates',
    title: 'An inclusive creation-date range',
    outcome: 'apply',
    prompt:
      'Show pending accounts created September 5 through September 12, 2026, with at least $2,500. Newest first.',
    expectation:
      'Include both September 5 and 12 on Created date, retain the pending Status and inclusive Balance threshold, and sort Created date descending.',
    fields: ['status', 'createdDate', 'balance'],
    requirements: ['Start from an ungrouped view'],
  },
  {
    id: 'offset-timestamp-window',
    category: 'dates',
    title: 'A timestamp window with a time zone',
    outcome: 'apply',
    prompt:
      'Find accounts updated on September 15, 2026, from 9 am up to but not including 5 pm in New York, with delivery marked no.',
    expectation:
      'Resolve Updated at to [2026-09-15T13:00:00Z, 2026-09-15T21:00:00Z), using the named time zone and daylight saving rules. Combine with Delivered = no.',
    fields: ['updatedAt', 'delivered'],
  },
  {
    id: 'created-earlier-updated-later',
    category: 'dates',
    title: 'Old creation dates and recent updates',
    outcome: 'apply',
    prompt:
      'Show accounts created before September 10, 2026, that were updated September 20 through September 25, 2026. Only failed or pending ones.',
    expectation:
      'Use Created date < 2026-09-10 and a whole-day Updated at interval covering September 20–25 in the user time zone, plus the Status alternatives. Do not collapse the two date fields.',
    fields: ['createdDate', 'updatedAt', 'status'],
    requirements: ['Advanced mode'],
  },
  {
    id: 'two-creation-windows',
    category: 'dates',
    title: 'Two disjoint date windows',
    outcome: 'apply',
    prompt:
      'Find accounts created September 1 through 5 or September 20 through 25, 2026. In both periods, only show balances over $5,000 that were not delivered.',
    expectation:
      'Join the two inclusive Created date windows with OR, then AND the result with Balance > 5000 and Delivered = no.',
    fields: ['createdDate', 'balance', 'delivered'],
    requirements: ['Advanced mode'],
  },
  {
    id: 'business-date-quarter',
    category: 'dates',
    title: 'A quarter on the business date',
    outcome: 'apply',
    prompt:
      'Show accounts with business dates in Q3 2026, but leave out September 15. Only include completed accounts with a balance above zero.',
    expectation:
      'Use Account date in [2026-07-01, 2026-10-01), exclude 2026-09-15, and add completed Status with Balance > 0.',
    fields: ['accountDate', 'status', 'balance'],
    requirements: ['Advanced mode'],
  },
  {
    id: 'missing-or-zero-balance',
    category: 'sets',
    title: 'Missing balance versus a recorded zero',
    outcome: 'apply',
    prompt: 'Find failed accounts with either no balance recorded or a balance of zero.',
    expectation:
      'Require failed Status AND (Balance is blank OR Balance = 0). Preserve the distinction between a missing numeric value and zero.',
    fields: ['status', 'balance'],
    requirements: ['Advanced mode'],
  },
  {
    id: 'recorded-unknown-only',
    category: 'sets',
    title: 'Unknown is a value, not a blank',
    outcome: 'apply',
    prompt:
      'Show delivery marked unknown, but leave out empty delivery cells. Only balances over $2,000.',
    expectation:
      'Select the literal Delivered value unknown without null, then require Balance > 2000.',
    fields: ['delivered', 'balance'],
    requirements: ['Set Filters on'],
  },
  {
    id: 'known-status-missing-delivery',
    category: 'sets',
    title: 'Known status with no delivery value',
    outcome: 'apply',
    prompt:
      'Find accounts that have a status recorded but no delivery value, with a balance of at least $1,000.',
    expectation:
      'Require nonblank Status, blank Delivered, and Balance >= 1000. Do not substitute the literal unknown for missing delivery.',
    fields: ['status', 'delivered', 'balance'],
  },
  {
    id: 'two-level-groups-leaf-sort',
    category: 'analysis',
    title: 'Two levels with the largest accounts inside',
    outcome: 'apply',
    prompt:
      'For accounts created September 1 through 20, 2026, group by status and then delivery. Put the biggest balances first inside each delivery group.',
    expectation:
      'Filter Created date inclusively, create Status then Delivered group levels, and sort leaf accounts by Balance descending without inventing an aggregation.',
    fields: ['createdDate', 'status', 'delivered', 'balance'],
    requirements: ['Start without pivoting'],
  },
  {
    id: 'count-by-two-dimensions',
    category: 'analysis',
    title: 'Count accounts across two group levels',
    outcome: 'apply',
    prompt: 'How many accounts were created this month in each status and delivery combination?',
    expectation:
      'Group Status then Delivered and count account rows after applying this month to Created date. Count includes accounts whose Balance is missing.',
    fields: ['createdDate', 'status', 'delivered', 'balance'],
  },
  {
    id: 'minimum-and-maximum-rollup',
    category: 'analysis',
    title: 'Minimum and maximum on distinct measures',
    outcome: 'apply',
    prompt:
      'For completed accounts created in September 2026, group by delivery. Show the smallest balance and the highest Q3 2026 revenue in each group.',
    expectation:
      'Use completed Status and the September Created date window, group by Delivered, and aggregate min(Balance) plus max(Revenue 2026 Q3).',
    fields: ['status', 'createdDate', 'delivered', 'balance', 'revenue_2026_Q3'],
  },
  {
    id: 'three-groups-filtered-exceptions',
    category: 'analysis',
    title: 'Nested exceptions with three group levels',
    outcome: 'apply',
    prompt:
      'Find failed accounts over $5,000 or pending accounts over $10,000, created September 1 through 20, 2026. Break them down by status, delivery, and business date, with total balances for each group.',
    expectation:
      'Filter ((failed AND Balance > 5000) OR (pending AND Balance > 10000)) AND the inclusive creation window. Apply Status, Delivered, Account date grouping in order and sum(Balance).',
    fields: ['status', 'balance', 'createdDate', 'delivered', 'accountDate'],
    requirements: ['Advanced mode'],
  },
  {
    id: 'working-capital-shortfall',
    category: 'calculated',
    title: 'Compare two financial columns directly',
    outcome: 'calculated',
    prompt:
      'Which accounts had more current liabilities than current assets in Q3 2026? Show the biggest dollar shortfall first.',
    expectation:
      'Infer a row-level shortfall of Current liabilities minus Current assets for Q3 2026, filter > 0, and sort the calculated amount descending. Present the complete calculation and changes for one approval.',
    fields: ['currentLiabilities_2026_Q3', 'currentAssets_2026_Q3'],
    requirements: ['Calculated columns available', 'Start from an ungrouped view'],
  },
  {
    id: 'cash-flow-decline',
    category: 'calculated',
    title: 'Quarterly cash-flow decline by status',
    outcome: 'calculated',
    prompt:
      'Find accounts whose operating cash flow fell from Q2 to Q3 2026. Group them by status and total the dollar change.',
    expectation:
      'Infer Q3 minus Q2 Operating cash flow, filter the difference < 0, group by Status, and sum the difference. Do not turn a dollar-change request into percent growth.',
    fields: ['operatingCashFlow_2026_Q3', 'operatingCashFlow_2026_Q2', 'status'],
    requirements: ['Calculated columns available'],
  },
  {
    id: 'high-balance-threshold',
    category: 'boundaries',
    title: 'A vague size threshold',
    outcome: 'clarify',
    prompt: 'Show high-balance accounts that were not delivered.',
    expectation:
      'Retain Delivered = no and ask what balance threshold “high” means. Do not invent a threshold or silently apply only the delivery condition.',
    fields: ['balance', 'delivered'],
    followUps: [
      {
        title: 'Supply the threshold',
        prompt: 'More than $25,000.',
        expectation: 'Complete the original request with Delivered = no AND Balance > 25000.',
      },
    ],
  },
  {
    id: 'undefined-profitability',
    category: 'boundaries',
    title: 'An undefined financial metric',
    outcome: 'clarify',
    prompt: 'Build a dashboard for profitable accounts with a strong margin.',
    expectation:
      'Ask for the reporting quarter and intended profit/margin definition and threshold. Offer relevant definitions as choices without claiming one is already selected. Continue the pending dashboard request when the missing context arrives.',
    fields: ['netIncome_2026_Q3', 'revenue_2026_Q3'],
    requirements: ['Dashboards available'],
  },
  {
    id: 'missing-quarter',
    category: 'boundaries',
    title: 'A metric available in several quarters',
    outcome: 'clarify',
    prompt: 'Find accounts with revenue above $100,000 and positive net income.',
    expectation:
      'Ask which reporting quarter applies to both metrics and present available quarter choices. Do not silently select the latest quarter.',
    fields: ['revenue_2026_Q3', 'netIncome_2026_Q3'],
    followUps: [
      {
        title: 'Supply the quarter',
        prompt: 'Q3 2026 for both.',
        expectation: 'Complete the original two-predicate filter using only 2026 Q3 metrics.',
      },
    ],
  },
  {
    id: 'plain-business-spelling',
    category: 'logic',
    title: 'Everyday wording and a harmless typo',
    outcome: 'apply',
    prompt:
      'Can you show the pending acounts that havent been delivered and have more than 2500 dollars?',
    expectation:
      'Resolve harmless spelling and punctuation errors to Status = pending, Delivered = no, and Balance > 2500. Do not invent a new status or treat unknown delivery as no.',
    fields: ['status', 'delivered', 'balance'],
  },
  {
    id: 'excluded-middle-balance-band',
    category: 'logic',
    title: 'Exclude a middle range',
    outcome: 'apply',
    prompt:
      'Find completed accounts with balances below $1,000 or above $50,000. Leave out missing balances.',
    expectation:
      'Use completed Status AND (Balance < 1000 OR Balance > 50000); both boundaries and null balances are excluded.',
    fields: ['status', 'balance'],
    requirements: ['Advanced mode'],
  },
];
