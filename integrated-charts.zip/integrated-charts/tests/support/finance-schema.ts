import { validateSchema, type ColumnSpec, type Kind } from './schema.js';

const sqlName = (id: string) => id.replace(/[A-Z]/g, (letter) => '_' + letter).toUpperCase();
const column = (
  id: string,
  label: string,
  kind: Kind,
  description: string,
  options: Partial<ColumnSpec> = {},
): ColumnSpec => ({
  id,
  label,
  kind,
  description,
  aliases: [label.toLowerCase()],
  nullable: false,
  sql: sqlName(id),
  chartRole:
    kind === 'number'
      ? 'measure'
      : kind === 'date' || kind === 'datetime'
        ? 'temporal'
        : 'dimension',
  ...(kind === 'number' ? { scale: 2 } : {}),
  ...options,
});
const text = (
  id: string,
  label: string,
  description: string,
  values?: string[],
  nullable = false,
) => column(id, label, 'text', description, { ...(values ? { values } : {}), nullable });
const amount = (id: string, label: string, description: string, nullable = false) =>
  column(id, label, 'number', description, { unit: 'USD', nullable });
const number = (id: string, label: string, description: string, unit: string, scale = 2) =>
  column(id, label, 'number', description, { unit, scale });
const identifier = (id: string, label: string) =>
  column(id, label, 'text', 'Synthetic identifier. Never sum or average identifiers.', {
    chartRole: 'identifier',
  });

/** Keep presentation categories beside the source fields, independent of data/query semantics. */
function taggedColumns(
  columns: ColumnSpec[],
  groups: Readonly<Record<string, readonly string[]>>,
): ColumnSpec[] {
  const tags = new Map(
    Object.entries(groups).flatMap(([tag, ids]) => ids.map((id) => [id, tag] as const)),
  );
  return columns.map((column) => ({ ...column, groupByTag: tags.get(column.id) }));
}

export const TRANSACTION_CORE_COLUMNS: ColumnSpec[] = taggedColumns(
  [
    identifier('id', 'Transaction ID'),
    column(
      'tradeDate',
      'Trade date',
      'date',
      'Trade execution calendar date in 2026. Synthetic, not real trades.',
    ),
    column(
      'settlementDate',
      'Settlement date',
      'date',
      'Actual settlement date; blank for trades that have not settled.',
      { nullable: true },
    ),
    text('status', 'Status', 'Trade settlement state.', [
      'Settled',
      'Pending',
      'Failed',
      'Cancelled',
    ]),
    text(
      'side',
      'Side',
      'Buy or Sell. Monetary values are expressed in USD unless described otherwise.',
      ['Buy', 'Sell'],
    ),
    text('assetClass', 'Asset class', 'Investment type.', ['Equity', 'Bond', 'Fund', 'Cash']),
    text('region', 'Region', 'Account servicing region.', [
      'North America',
      'Europe',
      'Asia Pacific',
    ]),
    text(
      'currency',
      'Trade currency',
      'Original trade currency. USD measures are already converted using FX rate.',
      ['USD', 'EUR', 'GBP', 'JPY'],
    ),
    text('accountName', 'Account name', 'Synthetic institutional client account name.'),
    text(
      'securityName',
      'Security name',
      'Fictional investment name. Not a current security recommendation.',
    ),
    text('symbol', 'Symbol', 'Synthetic investment symbol.'),
    text('desk', 'Trading desk', 'Team that executed the trade.', [
      'Institutional',
      'Wealth',
      'Treasury',
      'Pension',
    ]),
    text('counterparty', 'Counterparty', 'Fictional executing counterparty.', [
      'North Bank',
      'Harbor Securities',
      'Summit Markets',
      'Cedar Trading',
    ]),
    text('channel', 'Trade channel', 'Order entry channel.', [
      'Electronic',
      'Voice',
      'Client portal',
    ]),
    number('quantity', 'Quantity', 'Non-negative traded units.', 'units', 0),
    number(
      'unitPrice',
      'Unit price',
      'Price per unit in the original trade currency.',
      'trade currency/unit',
      4,
    ),
    number('fxRate', 'FX rate', 'USD per one unit of trade currency.', 'USD/trade currency', 6),
    amount(
      'grossAmount',
      'Gross amount (USD)',
      'Quantity times unit price times FX rate, rounded to cents.',
    ),
    amount(
      'feeAmount',
      'Fees (USD)',
      'Total execution fees. Blank when fee information is unavailable.',
      true,
    ),
    amount('taxAmount', 'Tax (USD)', 'Transaction taxes, rounded to cents.'),
    amount(
      'netAmount',
      'Net amount (USD)',
      'Buy: gross amount plus fees and tax. Sell: gross amount minus fees and tax. Blank if fees are unavailable.',
      true,
    ),
    number(
      'settlementDelayDays',
      'Settlement delay days',
      'Calendar days after the expected settlement date; zero means on time.',
      'days',
      0,
    ),
    number(
      'riskScore',
      'Risk score',
      'Synthetic operational risk indicator between zero and 100; higher means more exceptions.',
      'score',
      0,
    ),
    text('isCrossBorder', 'Cross border', 'Whether trade and servicing countries differ.', [
      'Yes',
      'No',
    ]),
    text(
      'exceptionReason',
      'Exception reason',
      'Reason for a settlement exception. Blank means no recorded exception.',
      ['Missing instruction', 'Cash shortage', 'Security shortage', 'Counterparty review'],
      true,
    ),
    column(
      'updatedAt',
      'Updated at (UTC)',
      'datetime',
      'UTC timestamp of the latest synthetic trade update.',
    ),
    identifier('accountId', 'Account ID'),
    identifier('securityId', 'Security ID'),
    text('broker', 'Broker', 'Fictional broker.', [
      'Atlas Brokerage',
      'Beacon Brokerage',
      'Juniper Brokerage',
    ]),
    amount(
      'cashImpact',
      'Cash impact (USD)',
      'Signed settlement cash: negative for buys, positive for sells, zero for cancelled trades. Blank if net amount is unknown.',
      true,
    ),
  ],
  {
    'Trade details': ['id', 'tradeDate', 'status', 'side', 'channel', 'updatedAt'],
    'Accounts and execution': [
      'accountName',
      'accountId',
      'region',
      'desk',
      'counterparty',
      'broker',
      'isCrossBorder',
    ],
    'Security details': ['securityName', 'symbol', 'securityId', 'assetClass', 'currency'],
    'Trade amounts': [
      'quantity',
      'unitPrice',
      'fxRate',
      'grossAmount',
      'feeAmount',
      'taxAmount',
      'netAmount',
      'cashImpact',
    ],
    'Settlement and risk': [
      'settlementDate',
      'settlementDelayDays',
      'riskScore',
      'exceptionReason',
    ],
  },
);

export const CUSTODY_CORE_COLUMNS: ColumnSpec[] = taggedColumns(
  [
    identifier('id', 'Holding ID'),
    column(
      'asOfDate',
      'As of date',
      'date',
      'Position snapshot date: 30 September 2026. One row per account and security holding.',
    ),
    text('accountName', 'Account name', 'Synthetic institutional client account name.'),
    text('clientType', 'Client type', 'Institutional client segment.', [
      'Pension fund',
      'Insurance',
      'Asset manager',
      'Family office',
    ]),
    text('custodian', 'Custodian', 'Fictional custody provider.', [
      'North Custody',
      'Harbor Trust',
      'Summit Custody',
      'Cedar Trust',
    ]),
    text('region', 'Region', 'Account servicing region.', [
      'North America',
      'Europe',
      'Asia Pacific',
    ]),
    text(
      'currency',
      'Security currency',
      'Currency in which the security is priced. USD measures are converted.',
      ['USD', 'EUR', 'GBP', 'JPY'],
    ),
    text('assetClass', 'Asset class', 'Investment type.', ['Equity', 'Bond', 'Fund', 'Cash']),
    text('securityName', 'Security name', 'Fictional investment name.'),
    text('symbol', 'Symbol', 'Synthetic investment symbol.'),
    number(
      'quantity',
      'Quantity',
      'Total non-negative held units. Available plus pledged quantity equals quantity.',
      'units',
      0,
    ),
    number(
      'marketPrice',
      'Market price',
      'Price per unit in the original security currency.',
      'security currency/unit',
      4,
    ),
    number(
      'fxRate',
      'FX rate',
      'USD per one unit of security currency.',
      'USD/security currency',
      6,
    ),
    amount(
      'marketValue',
      'Market value (USD)',
      'Quantity times market price times FX rate, rounded to cents.',
    ),
    amount('costValue', 'Cost value (USD)', 'Original acquisition cost in USD.'),
    amount(
      'unrealizedGain',
      'Unrealized gain (USD)',
      'Market value minus cost value. May be negative, zero or positive.',
    ),
    amount(
      'incomeAmount',
      'Income (USD)',
      'Synthetic September income. Blank when income information is unavailable.',
      true,
    ),
    amount('feeAmount', 'Custody fees (USD)', 'Synthetic September custody fees.'),
    number(
      'availableQuantity',
      'Available quantity',
      'Units available to trade; total quantity less pledged quantity.',
      'units',
      0,
    ),
    number('pledgedQuantity', 'Pledged quantity', 'Units pledged as collateral.', 'units', 0),
    text('settlementStatus', 'Settlement status', 'Position settlement state.', [
      'Settled',
      'Pending',
      'Failed',
    ]),
    text(
      'riskRating',
      'Risk rating',
      'Synthetic investment risk category.',
      ['Low', 'Medium', 'High'],
      true,
    ),
    column(
      'maturityDate',
      'Maturity date',
      'date',
      'Bond maturity date; blank for instruments without a contractual maturity.',
      { nullable: true },
    ),
    text('country', 'Country', 'Issuer country.', [
      'United States',
      'Germany',
      'United Kingdom',
      'Japan',
      'Canada',
    ]),
    identifier('accountId', 'Account ID'),
    identifier('securityId', 'Security ID'),
    column('updatedAt', 'Updated at (UTC)', 'datetime', 'UTC timestamp of the position snapshot.'),
    text('holdingStatus', 'Holding status', 'Operational holding state.', [
      'Active',
      'Restricted',
      'Closed',
    ]),
    number(
      'ownershipPercent',
      'Ownership percent',
      'Synthetic percentage ownership of the issue, between zero and 100.',
      'percent',
      4,
    ),
    amount(
      'loanValue',
      'Loan value (USD)',
      'Collateral lending value; market value times an asset-class haircut.',
    ),
  ],
  {
    'Holding details': ['id', 'asOfDate', 'settlementStatus', 'holdingStatus', 'updatedAt'],
    'Account details': ['accountName', 'accountId', 'clientType', 'custodian', 'region'],
    'Security details': [
      'assetClass',
      'securityName',
      'securityId',
      'symbol',
      'currency',
      'maturityDate',
      'country',
    ],
    Valuation: [
      'quantity',
      'marketPrice',
      'fxRate',
      'marketValue',
      'costValue',
      'unrealizedGain',
      'incomeAmount',
      'feeAmount',
    ],
    'Collateral and risk': [
      'availableQuantity',
      'pledgedQuantity',
      'riskRating',
      'ownershipPercent',
      'loanValue',
    ],
  },
);

export const TRANSACTION_MONTHLY_METRICS = [
  ['grossAmount', 'Gross amount', 'USD'],
  ['feeAmount', 'Fees', 'USD'],
  ['taxAmount', 'Tax', 'USD'],
  ['netAmount', 'Net amount', 'USD'],
  ['cashImpact', 'Cash impact', 'USD'],
  ['settledAmount', 'Settled amount', 'USD'],
  ['pendingAmount', 'Pending amount', 'USD'],
  ['cancelledAmount', 'Cancelled amount', 'USD'],
  ['buyAmount', 'Buy amount', 'USD'],
  ['sellAmount', 'Sell amount', 'USD'],
  ['brokerFee', 'Broker fee', 'USD'],
  ['exchangeFee', 'Exchange fee', 'USD'],
  ['clearingFee', 'Clearing fee', 'USD'],
  ['settlementFee', 'Settlement fee', 'USD'],
  ['stampDuty', 'Stamp duty', 'USD'],
  ['withholdingTax', 'Withholding tax', 'USD'],
  ['financingCost', 'Financing cost', 'USD'],
  ['rebateAmount', 'Rebate', 'USD'],
  ['slippageCost', 'Slippage cost', 'USD'],
  ['commission', 'Commission', 'USD'],
  ['taxableAmount', 'Taxable amount', 'USD'],
  ['realizedGain', 'Realized gain', 'USD'],
  ['expectedCash', 'Expected cash', 'USD'],
  ['postedCash', 'Posted cash', 'USD'],
  ['unpostedCash', 'Unposted cash', 'USD'],
  ['quantity', 'Quantity', 'units'],
  ['settledQuantity', 'Settled quantity', 'units'],
  ['pendingQuantity', 'Pending quantity', 'units'],
  ['unitPrice', 'Unit price', 'trade currency/unit'],
  ['fxRate', 'FX rate', 'USD/trade currency'],
  ['ageDays', 'Age days', 'days'],
  ['feeRate', 'Fee rate', 'percent'],
  ['riskScore', 'Risk score', 'score'],
  ['exceptionCount', 'Exception count', 'count'],
  ['settlementDelayDays', 'Settlement delay days', 'days'],
] as const;

export const CUSTODY_MONTHLY_METRICS = [
  ['marketValue', 'Market value', 'USD'],
  ['costValue', 'Cost value', 'USD'],
  ['unrealizedGain', 'Unrealized gain', 'USD'],
  ['incomeAmount', 'Income', 'USD'],
  ['feeAmount', 'Custody fees', 'USD'],
  ['loanValue', 'Loan value', 'USD'],
  ['availableValue', 'Available value', 'USD'],
  ['pledgedValue', 'Pledged value', 'USD'],
  ['equityValue', 'Equity value', 'USD'],
  ['bondValue', 'Bond value', 'USD'],
  ['fundValue', 'Fund value', 'USD'],
  ['cashValue', 'Cash value', 'USD'],
  ['dividendIncome', 'Dividend income', 'USD'],
  ['interestIncome', 'Interest income', 'USD'],
  ['otherIncome', 'Other income', 'USD'],
  ['withholdingTax', 'Withholding tax', 'USD'],
  ['netIncome', 'Net income', 'USD'],
  ['administrationFee', 'Administration fee', 'USD'],
  ['safekeepingFee', 'Safekeeping fee', 'USD'],
  ['transactionFee', 'Transaction fee', 'USD'],
  ['openingValue', 'Opening value', 'USD'],
  ['closingValue', 'Closing value', 'USD'],
  ['valueChange', 'Value change', 'USD'],
  ['netReturn', 'Net return', 'USD'],
  ['quantity', 'Quantity', 'units'],
  ['availableQuantity', 'Available quantity', 'units'],
  ['pledgedQuantity', 'Pledged quantity', 'units'],
  ['marketPrice', 'Market price', 'security currency/unit'],
  ['fxRate', 'FX rate', 'USD/security currency'],
  ['ownershipPercent', 'Ownership percent', 'percent'],
  ['loanToValuePercent', 'Loan to value percent', 'percent'],
  ['pledgedPercent', 'Pledged percent', 'percent'],
  ['incomeYieldPercent', 'Income yield percent', 'percent'],
  ['feeRatePercent', 'Fee rate percent', 'percent'],
  ['priceChangePercent', 'Price change percent', 'percent'],
] as const;

function monthlyColumns(
  metrics: readonly (readonly [string, string, string])[],
  scope: 'transaction' | 'holding',
): ColumnSpec[] {
  return Array.from({ length: 12 }, (_, month) =>
    metrics.map(([id, label, unit]) => {
      const stamp = `2026_${String(month + 1).padStart(2, '0')}`;
      const monthLabel = new Intl.DateTimeFormat('en', { month: 'short', timeZone: 'UTC' }).format(
        new Date(Date.UTC(2026, month, 1)),
      );
      return column(
        `${id}_${stamp}`,
        `${label} ${monthLabel} 2026`,
        'number',
        `Synthetic ${scope} month-end ${label.toLowerCase()} for ${monthLabel} 2026, in ${unit}. ${scope === 'transaction' ? 'Lifecycle snapshot of this trade, not account totals; blank before the trade or after the September fixture cutoff.' : 'One holding at month end; blank after the September fixture cutoff. Monthly values are observations, not forecasts.'} Do not add snapshots from different months.`,
        {
          nullable: true,
          groupByTag: `2026 ${monthLabel}`,
          unit,
          scale:
            unit.includes('/') || unit === 'percent'
              ? 6
              : ['units', 'days', 'score', 'count'].includes(unit)
                ? 0
                : 2,
        },
      );
    }),
  ).flat();
}
export const TRANSACTION_COLUMNS = [
  ...TRANSACTION_CORE_COLUMNS,
  ...monthlyColumns(TRANSACTION_MONTHLY_METRICS, 'transaction'),
];
export const CUSTODY_COLUMNS = [
  ...CUSTODY_CORE_COLUMNS,
  ...monthlyColumns(CUSTODY_MONTHLY_METRICS, 'holding'),
];
validateSchema(TRANSACTION_COLUMNS);
validateSchema(CUSTODY_COLUMNS);
