import type { ChartingDataSource } from '../core/data-access/charting-data';
import { DATA_SOURCES } from '../core/domain/demo-sources';
import { ENERGY_SAMPLE_OPTION } from './energy-sample';
import { NORMAL_PEOPLE_CHARTS_OPTION } from './normal-people-charts';
import type { LocalDataset } from './client-data-sources';
import { parseLocalJsonFile } from './local-json-dataset';

export const ENTERPRISE_BENCHMARK_ID = 'local_enterprise_service_benchmark' as const;
export const ENTERPRISE_BENCHMARK_OPTION = {
  id: ENTERPRISE_BENCHMARK_ID,
  label: 'Enterprise service operations · 120 chart tests',
};

/** Load the authorized fixture from this application origin, never from a model service. */
export async function loadEnterpriseBenchmark(
  loadAsset: ChartingDataSource['loadAsset'],
  signal?: AbortSignal,
): Promise<LocalDataset> {
  const [dataResponse, metadataResponse] = await Promise.all([
    loadAsset('enterprise-benchmark/service_cases_authorized.json', signal),
    loadAsset('enterprise-benchmark/schema.metadata.json', signal),
  ]);
  if (!dataResponse.ok || !metadataResponse.ok)
    throw new Error(
      'The bundled enterprise benchmark could not be loaded. Check that its assets were deployed.',
    );
  const [blob, metadata] = await Promise.all([dataResponse.blob(), metadataResponse.json()]);
  const dataset = await parseLocalJsonFile(
    new File([blob], 'service_cases_authorized.json', { type: 'application/json' }),
    { metadata, skipRecipes: true, signal },
  );
  if (dataset.rows.length !== 28888 || dataset.originalFields.length !== 59)
    throw new Error('The enterprise benchmark asset is incomplete or does not match its schema.');
  dataset.metadata = {
    ...dataset.metadata,
    id: ENTERPRISE_BENCHMARK_ID,
    version: `${ENTERPRISE_BENCHMARK_ID}-${dataset.contentHash?.slice(0, 32) ?? 'bundled-v1'}`,
    label: ENTERPRISE_BENCHMARK_OPTION.label,
    rowLabel: 'service case',
    local: true,
  };
  dataset.preparedRecipes = [];
  return dataset;
}
