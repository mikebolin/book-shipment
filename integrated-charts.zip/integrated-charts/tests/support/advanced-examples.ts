export const ADVANCED_EXAMPLES = [
  {
    label: 'Operational exposure dashboard',
    category: 'Portfolio',
    description: 'Nested exceptions, membership lists, grouping and a delivery pivot.',
    value:
      'Show a balance dashboard for failed or pending accounts with at least $50,000 where delivery is marked unknown or left empty. Break down total balances by status, with delivery across the columns, and put the largest totals first.',
  },
  {
    label: 'Completed last week',
    category: 'Dates',
    description: 'Resolve a calendar week and keep the status and balance analysis together.',
    value:
      'Show a balance dashboard for completed accounts created last week, with total balance by status.',
  },
  {
    label: 'Quarterly performance review',
    category: 'Financial',
    description: 'A profitable account cohort, three measures and a quarterly comparison.',
    value:
      'Give me a Q3 2026 financial dashboard for accounts with revenue over $100,000 and positive net income that quarter. Total their revenue, net income, and operating cash flow by status, with the biggest revenue totals first.',
  },
  {
    label: 'Historical market stress days',
    category: 'Market',
    description: 'A dated price-and-volume screen with deduplicated market observations.',
    value:
      'Show a dashboard of AAPL trading days in 2016 when the closing price was below $100 and more than 50 million shares traded. Put the oldest trading days first.',
  },
  {
    label: 'Revenue change by account',
    category: 'Calculated column',
    description: 'Approve a derived measure and its filters and grouping together.',
    value:
      'Find accounts where revenue grew from Q2 to Q3 2026. Total the dollar increase by status and show the statuses with the most growth first.',
  },
  {
    label: 'Exclude statuses, retain missing values',
    category: 'Set Filters',
    description: 'An exclusion list with explicit blank and unknown semantics.',
    value:
      'Show a balance dashboard excluding failed and pending accounts, but keep accounts with no status. Balances should be at least $1,000 and under $50,000, with delivery marked unknown or empty. Total the balances by delivery.',
  },
  {
    label: 'Clarify a business metric',
    category: 'Clarification',
    description: 'Demonstrates asking for a definition instead of inventing a finance formula.',
    value: 'Build a dashboard of profitable accounts with a strong profit margin.',
  },
];
