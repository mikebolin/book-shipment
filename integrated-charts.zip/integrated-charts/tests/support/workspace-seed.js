import { createFeaturedSamples, aggregatePreview } from './sample-datasets.js';
import { createFocusedDashboards } from './sample-dashboards.js';
import catalog from './source-catalog.json' with { type: 'json' };

/** Original gallery seed runs synchronously in the browser, before the first route renders. */
export function createWorkspaceSeed() {
  let sequence = 0;
  const randomUUID = () => `seed-placement-${++sequence}`;
  const resources = { models: [], widgets: [], dashboards: [] };
  const revisions = {};
  const datasets = {};
  const sources = [];
  const timestamp = '2026-10-01T00:00:00.000Z';
  const generated = new Map(createFeaturedSamples().map((sample) => [sample.key, sample]));
  for (const source of catalog) {
    const sample = generated.get(source.key);
    const metadata = sample?.metadata ?? source.metadata;
    const id = `model-${source.key}`;
    const definition = {
      ...metadata,
      sourceKey: source.key,
      clientSourceId: metadata.id,
      schemaVersion: metadata.version,
      dataVersion: metadata.version,
      rowCount: sample?.rows.length ?? source.metadata.rowCount ?? 0,
    };
    sources.push({ key: source.key, name: metadata.label, ...definition });
    resources.models.push({
      id,
      kind: 'MODEL',
      slug: source.key,
      name: metadata.label,
      description: metadata.description,
      modelId: null,
      version: 1,
      publishedVersion: null,
      body: definition,
      createdAt: timestamp,
      updatedAt: timestamp,
    });
    if (sample) datasets[source.key] = sample.rows;
  }
  function seed(path, method = 'GET', input) {
    const [route, search] = path.split('?');
    const [collection, slug, action] = route.split('/');
    const items = resources[collection];
    if (method === 'GET') {
      if (!slug) return structuredClone(items);
      const item = items.find((item) => item.slug === slug || item.id === slug);
      return structuredClone(
        search === 'view=published' ? revisions[item.id][item.publishedVersion] : item,
      );
    }
    if (action === 'publish') {
      const item = items.find((item) => item.slug === slug);
      item.publishedVersion = item.version;
      (revisions[item.id] ??= {})[item.version] = structuredClone(item);
      return structuredClone(item);
    }
    const id = `seed-${collection}-${++sequence}`;
    const item = {
      id,
      kind: collection === 'widgets' ? 'WIDGET' : 'DASHBOARD',
      slug:
        input.name
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/-$/, '') +
        '-' +
        sequence,
      name: input.name,
      description: input.description ?? '',
      modelId: input.modelId ?? null,
      version: 1,
      publishedVersion: null,
      body: structuredClone(input.body),
      createdAt: timestamp,
      updatedAt: timestamp,
    };
    items.push(item);
    return structuredClone(item);
  }
  const legacyTemplates = [
    {
      name: 'Portfolio balance by status',
      source: 'accounts',
      category: 'status',
      measure: 'balance',
      type: 'column',
      description: 'Total account balances grouped by account status.',
    },
    {
      name: 'Transaction value by asset class',
      source: 'transactions',
      category: 'assetClass',
      measure: 'netAmount',
      type: 'bar',
      description: 'Net transaction amounts across asset classes.',
    },
    {
      name: 'Custody value by region',
      source: 'custody',
      category: 'region',
      measure: 'marketValue',
      type: 'donut',
      description: 'Regional distribution of the synthetic custody portfolio.',
    },
    {
      name: 'Service workload by priority',
      source: 'service-cases',
      category: 'priority',
      measure: 'case_count',
      type: 'column',
      description: 'Service case volumes grouped by priority.',
    },
    {
      name: 'Energy generation by site',
      source: 'energy',
      category: 'site',
      measure: 'generationMwh',
      type: 'bar',
      description: 'Recorded generation in MWh by asset; missing observations remain missing.',
    },
    {
      name: 'Account distribution by status',
      source: 'accounts',
      category: 'status',
      measure: null,
      type: 'donut',
      description: 'Account counts across statuses, sharing the portfolio snapshot.',
    },
  ];
  const featuredTemplates = [
    {
      name: 'Asset allocation',
      source: 'finance-demo',
      category: 'assetClass',
      measures: ['marketValue'],
      aggregation: 'sum',
      type: 'donut',
      group: 'Finance',
      description:
        'Market value of 2,000 synthetic positions by asset class, valued on 30 September 2026.',
    },
    {
      name: 'Portfolio performance',
      source: 'finance-demo',
      category: 'portfolio',
      measures: ['unrealizedPnl'],
      aggregation: 'sum',
      type: 'bar',
      group: 'Finance',
      description: 'Unrealized gains and losses in illustrative USD across six portfolio mandates.',
    },
    {
      name: 'Income by risk band',
      source: 'finance-demo',
      category: 'riskBand',
      measures: ['annualIncome'],
      aggregation: 'sum',
      type: 'column',
      group: 'Finance',
      description: 'Illustrative annual income across synthetic risk bands.',
    },
    {
      name: 'Care delivered by service',
      source: 'healthcare-demo',
      category: 'department',
      measures: ['completedVisits'],
      aggregation: 'sum',
      type: 'bar',
      group: 'Healthcare',
      description:
        'Completed visits across eight services from 2,000 synthetic operating-day summaries.',
    },
    {
      name: 'Access and waiting time',
      source: 'healthcare-demo',
      category: 'facility',
      measures: ['waitMinutes'],
      aggregation: 'avg',
      type: 'column',
      group: 'Healthcare',
      description:
        'Unweighted mean of daily department waiting-time averages at five fictional facilities, in minutes.',
    },
    {
      name: 'Visits and available capacity',
      source: 'healthcare-demo',
      category: 'department',
      measures: ['completedVisits', 'capacityVisits'],
      aggregation: 'sum',
      type: 'column',
      group: 'Healthcare',
      description: 'Completed visits compared with staffed capacity across eight services.',
    },
  ];
  /**
   * Server-grid demonstrations over the bundled 60,000-record Activity monitor fixture
   * (scripts/generate-activity-monitor.mjs). The rows load lazily, so these views carry no
   * generated preview; their grouping, aggregation, sort and filter state is the demonstration.
   */
  const activityVisible = (model, visible) => ({
    columnOrder: {
      orderedColIds: [
        ...visible,
        ...model.body.columns.map((column) => column.id).filter((id) => !visible.includes(id)),
      ],
    },
    columnVisibility: {
      hiddenColIds: model.body.columns
        .map((column) => column.id)
        .filter((id) => !visible.includes(id)),
    },
    columnSizing: {
      columnSizingModel: visible.map((colId) => ({
        colId,
        width:
          colId === 'name'
            ? 240
            : colId === 'fileName'
              ? 250
              : colId.endsWith('DateTime')
                ? 185
                : 150,
      })),
    },
  });
  /**
   * The failed-events default: the hour before the 12:00 UTC snapshot, failed or breached. The view
   * saves it as its table filter (charts follow it), and the dashboards override those same columns
   * with their own windows through the dashboard filter.
   */
  const failedEventsFilterModel = (start) => ({
    filterType: 'join',
    type: 'AND',
    conditions: [
      {
        filterType: 'dateTimeString',
        colId: 'startedDateTime',
        type: 'greaterThanOrEqual',
        filter: start,
      },
      {
        filterType: 'dateTimeString',
        colId: 'startedDateTime',
        type: 'lessThan',
        filter: '2026-10-03T12:00:00',
      },
      {
        filterType: 'join',
        type: 'OR',
        conditions: [
          { filterType: 'text', colId: 'executionStatus', type: 'equals', filter: 'Failed' },
          { filterType: 'text', colId: 'executionStatus', type: 'equals', filter: 'Breached' },
        ],
      },
    ],
  });
  /** Charts of the failed-events view; they follow the view's table filter. */
  const failuresOverTime = (minutes) => ({
    id: `activity-failures-${minutes}min`,
    plan: {
      type: 'column',
      categoryColumnId: 'startedDateTime',
      measureColumnIds: [],
      aggregation: 'count',
      timeBucket: 'minute',
      bucketSize: minutes,
      timeRange: { fill: 'zero' },
      title: `Failures over time · ${minutes} min`,
      appearance: {
        theme: null,
        legendPosition: null,
        showLegend: false,
        showLabels: null,
        xAxisTitle: 'Time (UTC)',
        yAxisTitle: 'Failed events',
      },
    },
    presentation: null,
    description: `Failed or breached activities per ${minutes}-minute bucket inside the current window; buckets without events count zero.`,
  });
  const failuresByType = {
    id: 'activity-failures-by-type',
    plan: {
      type: 'bar',
      categoryColumnId: 'type',
      measureColumnIds: ['metric_events'],
      aggregation: null,
      timeBucket: null,
      title: 'Failures by type',
      appearance: {
        theme: null,
        legendPosition: null,
        showLegend: false,
        showLabels: true,
        xAxisTitle: null,
        yAxisTitle: null,
      },
      analytics: {
        metrics: [
          {
            id: 'metric_events',
            label: 'Failed events',
            operation: 'count',
            columnId: null,
            numeratorColumnId: null,
            denominatorColumnId: null,
            scale: null,
            percentile: null,
          },
        ],
        groupFilter: [],
        orderBy: [{ field: 'metric_events', direction: 'desc' }],
        limit: null,
        seriesByColumnId: null,
      },
    },
    presentation: null,
    description: 'Activity types ranked by failed or breached events inside the current window.',
  };
  const activityCharts = (template) => {
    const charts = template.charts ?? [
      {
        id: `demo-activity-monitor-${template.chart.categoryColumnId}-${template.chart.type}`,
        plan: {
          type: template.chart.type,
          categoryColumnId: template.chart.categoryColumnId,
          measureColumnIds: [],
          aggregation: 'count',
          timeBucket: null,
          title: template.chart.title,
          appearance: null,
        },
        presentation: null,
      },
    ];
    return { chart: charts[0], charts };
  };
  const activityTemplates = [
    {
      name: 'Activity monitor · failed events',
      description:
        'Failed and breached activities for the triage dashboards: a server-side table grouped by activity type with event totals, failures over time at one- and five-minute buckets, and failures ranked by type. The dashboards supply the time window and statuses through their shared filter.',
      visible: ['executionStatus', 'startedDateTime', 'name', 'id', 'eventCount'],
      gridState: {
        filter: { advancedFilterModel: failedEventsFilterModel('2026-10-03T11:00:00') },
        rowGroup: { groupColIds: ['type'] },
        aggregation: { aggregationModel: [{ colId: 'eventCount', aggFunc: 'sum' }] },
        sort: {
          sortModel: [
            { colId: 'eventCount', sort: 'desc' },
            { colId: 'startedDateTime', sort: 'desc' },
          ],
        },
      },
      charts: [failuresOverTime(5), failuresOverTime(1), failuresByType],
    },
    {
      name: 'Breached activities by source and type',
      description:
        'Breached activities grouped by source system, then activity type. Groups sort by the longest SLA breach; expanding a group requests only its records.',
      visible: [
        'name',
        'executionStatus',
        'breachMinutes',
        'processedRowCount',
        'durationSeconds',
        'startedDateTime',
        'tenantCode',
        'owner',
        'fileName',
      ],
      gridState: {
        filter: {
          advancedFilterModel: {
            filterType: 'text',
            colId: 'executionStatus',
            type: 'equals',
            filter: 'Breached',
          },
        },
        rowGroup: { groupColIds: ['source', 'type'] },
        aggregation: {
          aggregationModel: [
            { colId: 'breachMinutes', aggFunc: 'max' },
            { colId: 'processedRowCount', aggFunc: 'sum' },
            { colId: 'durationSeconds', aggFunc: 'avg' },
          ],
        },
        sort: { sortModel: [{ colId: 'breachMinutes', sort: 'desc' }] },
      },
      chart: { type: 'bar', categoryColumnId: 'type', title: 'Breached activities by type' },
    },
    {
      name: 'Activity volume by status and type',
      description:
        'Every activity grouped by execution status, then activity type, with processed rows, average duration and retries summarized for each group.',
      visible: [
        'name',
        'source',
        'processedRowCount',
        'durationSeconds',
        'retryCount',
        'startedDateTime',
        'priority',
        'owner',
      ],
      gridState: {
        rowGroup: { groupColIds: ['executionStatus', 'type'] },
        aggregation: {
          aggregationModel: [
            { colId: 'processedRowCount', aggFunc: 'sum' },
            { colId: 'durationSeconds', aggFunc: 'avg' },
            { colId: 'retryCount', aggFunc: 'sum' },
          ],
        },
        sort: { sortModel: [{ colId: 'processedRowCount', sort: 'desc' }] },
      },
      chart: {
        type: 'donut',
        categoryColumnId: 'executionStatus',
        title: 'Activities by execution status',
      },
    },
  ];
  const samples = new Map(createFeaturedSamples().map((sample) => [sample.key, sample]));
  const includeLegacy = false;
  const templates = includeLegacy ? [...featuredTemplates, ...legacyTemplates] : featuredTemplates;
  const slugPrefix = (name) => `${name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-`;

  {
    const models = seed('models');
    const existing = seed('widgets');
    const widgets = [];
    let created = 0;
    for (const template of templates) {
      let widget = existing.find((item) => item.slug.startsWith(slugPrefix(template.name)));
      if (!widget) {
        const model = models.find((item) => item.body.sourceKey === template.source);
        if (!model)
          throw new Error(
            `Missing ${template.source} model. Start the API with demo model seeding enabled.`,
          );
        const measures = template.measures ?? (template.measure ? [template.measure] : []);
        const plan = {
          type: template.type,
          categoryColumnId: template.category,
          measureColumnIds: measures,
          aggregation: template.aggregation ?? (measures.length ? 'sum' : 'count'),
          timeBucket: null,
          title: template.name,
          appearance: null,
        };
        widget = seed('widgets', 'POST', {
          name: template.name,
          description: template.description,
          modelId: model.id,
          body: {
            schemaVersion: 1,
            modelSchemaVersion: model.body.schemaVersion,
            mode: 'advanced',
            displayMode: 'chart',
            allowDownload: true,
            filterControls: { visible: true, parameterizable: true },
            gridState: {},
            calculatedColumns: [],
            chart: {
              id: `demo-${template.source}-${template.category}-${measures.join('-') || 'count'}`,
              plan,
              presentation: null,
            },
            ...(samples.has(template.source)
              ? {
                  group: template.group,
                  tags: ['Featured', template.group],
                  preview: aggregatePreview(samples.get(template.source), template),
                }
              : { group: 'Additional examples', tags: ['Legacy'] }),
          },
        });
        widget = seed(`widgets/${widget.slug}/publish`, 'POST', {}, widget.version);
        created++;
      }
      // Build new examples from immutable publications, never from someone's edited draft.
      if (widget.publishedVersion !== null) {
        widget = seed(`widgets/${widget.slug}?view=published`);
      }
      widgets.push({ widget, templateName: template.name, featured: samples.has(template.source) });
    }
    for (const template of activityTemplates) {
      let widget = existing.find((item) => item.slug.startsWith(slugPrefix(template.name)));
      if (!widget) {
        const model = models.find((item) => item.body.sourceKey === 'activity-monitor');
        if (!model)
          throw new Error(
            'Missing activity-monitor model. Run node scripts/generate-activity-monitor.mjs.',
          );
        widget = seed('widgets', 'POST', {
          name: template.name,
          description: template.description,
          modelId: model.id,
          body: {
            schemaVersion: 1,
            modelSchemaVersion: model.body.schemaVersion,
            mode: 'advanced',
            displayMode: 'both',
            allowDownload: true,
            filterControls: { visible: true, parameterizable: true },
            viewLayout: { tablePosition: 'top', showRecordCounts: true },
            gridState: { ...activityVisible(model, template.visible), ...template.gridState },
            calculatedColumns: [],
            ...activityCharts(template),
            group: 'Operations',
            tags: ['Featured', 'Operations', 'Server grid'],
          },
        });
        widget = seed(`widgets/${widget.slug}/publish`, 'POST', {}, widget.version);
        created++;
      }
      if (widget.publishedVersion !== null) widget = seed(`widgets/${widget.slug}?view=published`);
      widgets.push({ widget, templateName: template.name, featured: false });
    }
    const dashboards = seed('dashboards');
    function ensureDashboard(name, description, featured) {
      let dashboard = dashboards.find((item) => item.slug.startsWith(slugPrefix(name)));
      if (dashboard) return dashboard;
      const published = widgets
        .filter((item) => item.featured === featured)
        .map((item) => item.widget)
        .filter((widget) => widget.publishedVersion !== null);
      if (!published.length)
        throw new Error(
          'Publish a sample view before creating the overview. Existing drafts were preserved.',
        );
      dashboard = seed('dashboards', 'POST', {
        name,
        description,
        body: {
          schemaVersion: 1,
          group: featured ? 'Featured' : 'Additional examples',
          tags: featured ? ['Featured', 'Finance', 'Healthcare'] : ['Legacy'],
          preview: {
            schemaVersion: 1,
            type: 'summary',
            label: 'Published views',
            value: published.length,
          },
          items: published.map((widget, index) => ({
            id: randomUUID(),
            widgetId: widget.id,
            widgetRevision: widget.publishedVersion,
            displayMode: 'chart',
            x: (index % 2) * 6,
            y: Math.floor(index / 2) * 6,
            w: 6,
            h: 6,
          })),
        },
      });
      dashboard = seed(`dashboards/${dashboard.slug}/publish`, 'POST', {}, dashboard.version);
      return dashboard;
    }
    const dashboard = ensureDashboard(
      'Finance & care overview',
      'Six financial and healthcare operations views. Each featured sample contains 2,000 synthetic records; no customer or patient data.',
      true,
    );
    let briefing = dashboards.find((item) =>
      item.slug.startsWith(slugPrefix('Leadership briefing')),
    );
    if (!briefing) {
      const finance = models.find((item) => item.body.sourceKey === 'finance-demo');
      const care = models.find((item) => item.body.sourceKey === 'healthcare-demo');
      const financial = widgets
        .filter((item) => item.widget.modelId === finance.id)
        .map((item) => item.widget);
      const clinical = widgets
        .filter((item) => item.widget.modelId === care.id)
        .map((item) => item.widget);
      let detail = existing.find((item) => item.slug.startsWith(slugPrefix('Portfolio details')));
      if (!detail) {
        const body = structuredClone(financial[0].body);
        body.displayMode = 'both';
        body.allowDownload = true;
        body.filterControls = { visible: true, parameterizable: true };
        body.gridState = {
          columnOrder: {
            orderedColIds: [
              'portfolio',
              'assetClass',
              'marketValue',
              ...finance.body.columns
                .map((column) => column.id)
                .filter((id) => !['portfolio', 'assetClass', 'marketValue'].includes(id)),
            ],
          },
          columnSizing: {
            columnSizingModel: finance.body.columns.map((column) => ({
              colId: column.id,
              width: column.id === 'portfolio' ? 220 : 160,
            })),
          },
          sort: { sortModel: [{ colId: 'marketValue', sort: 'desc' }] },
          filter: {
            advancedFilterModel: {
              filterType: 'number',
              colId: 'marketValue',
              type: 'greaterThanOrEqual',
              filter: 0,
            },
          },
        };
        body.chart.plan.title = 'Portfolio details';
        if (body.preview) body.preview.title = 'Portfolio details';
        detail = seed('widgets', 'POST', {
          name: 'Portfolio details',
          description: 'A related chart and table with an adjustable minimum market value.',
          modelId: finance.id,
          body,
        });
        detail = seed(`widgets/${detail.slug}/publish`, 'POST', {}, detail.version);
        created++;
      }
      const first = randomUUID(),
        second = randomUUID(),
        third = randomUUID();
      const view = (widget, x, y, w, h, sectionId, displayMode = 'chart') => ({
        id: randomUUID(),
        kind: 'view',
        widgetId: widget.id,
        widgetRevision: widget.publishedVersion,
        x,
        y,
        w,
        h,
        sectionId,
        displayMode,
      });
      briefing = seed('dashboards', 'POST', {
        name: 'Leadership briefing',
        description:
          'Portfolio performance and care operations, with related records and context. Synthetic sample data.',
        body: {
          schemaVersion: 1,
          group: 'Featured',
          tags: ['Finance', 'Healthcare', 'Guided'],
          items: [
            {
              id: first,
              kind: 'section',
              title: 'Portfolio overview',
              description:
                'Understand allocation and performance before exploring the underlying records.',
              x: 0,
              y: 0,
              w: 12,
              h: 1,
            },
            view(financial[0], 0, 1, 4, 6, first),
            view(financial[1], 4, 1, 8, 6, first),
            {
              id: second,
              kind: 'section',
              title: 'The evidence behind the chart',
              description:
                'Adjust the minimum market value, then apply it to the related chart and table.',
              x: 0,
              y: 7,
              w: 12,
              h: 1,
            },
            view(detail, 0, 8, 12, 9, second, 'both'),
            {
              id: third,
              kind: 'section',
              title: 'Care and context',
              description: 'Connect operating activity to a clear course of action.',
              x: 0,
              y: 17,
              w: 12,
              h: 1,
            },
            view(clinical[0], 0, 18, 6, 5, third),
            {
              id: randomUUID(),
              kind: 'image',
              title: 'From evidence to action',
              imageUrl: '/assets/dashboard-context.svg',
              alt: 'Discover, understand and act on your data',
              sectionId: third,
              x: 6,
              y: 18,
              w: 6,
              h: 5,
            },
          ],
        },
      });
      briefing = seed(`dashboards/${briefing.slug}/publish`, 'POST', {}, briefing.version);
    }
    if (includeLegacy)
      ensureDashboard(
        'Workspace overview',
        'Additional financial, service and energy examples from the original larger datasets.',
        false,
      );
    let explorer = dashboards.find((item) =>
      item.slug.startsWith(slugPrefix('Portfolio explorer')),
    );
    if (!explorer) {
      const finance = models.find((item) => item.body.sourceKey === 'finance-demo');
      const source = widgets.find((item) => item.widget.modelId === finance.id).widget;
      const columns = finance.body.columns.map((column) => column.id);
      const region = (value) => ({
        filterType: 'text',
        colId: 'region',
        type: 'equals',
        filter: value,
      });
      const placement = (title, x, y, w, h, filter, displayMode, editable) => ({
        id: randomUUID(),
        kind: 'view',
        widgetId: source.id,
        widgetRevision: source.publishedVersion,
        title,
        x,
        y,
        w,
        h,
        displayMode,
        interactions: { switchView: true },
        viewOverrides: {
          allowDownload: true,
          mode: 'advanced',
          filterControls: { visible: true, parameterizable: editable },
          gridState: {
            ...structuredClone(source.body.gridState),
            filter: { advancedFilterModel: filter },
            columnOrder: {
              orderedColIds: [
                'portfolio',
                'region',
                'assetClass',
                'marketValue',
                ...columns.filter(
                  (id) => !['portfolio', 'region', 'assetClass', 'marketValue'].includes(id),
                ),
              ],
            },
            columnVisibility: {
              hiddenColIds: columns.filter(
                (id) =>
                  !['portfolio', 'region', 'assetClass', 'marketValue', 'riskBand'].includes(id),
              ),
            },
            sort: { sortModel: [{ colId: 'marketValue', sort: 'desc' }] },
          },
          chart: {
            ...structuredClone(source.body.chart),
            plan: { ...source.body.chart.plan, type: 'bar' },
          },
        },
      });
      explorer = seed('dashboards', 'POST', {
        name: 'Portfolio explorer',
        description:
          'One published view, three independent dashboard configurations. Adjust a region or minimum market value, then apply to explore the matching chart and records.',
        body: {
          schemaVersion: 1,
          group: 'Featured',
          tags: ['Finance', 'Interactive'],
          items: [
            placement('North America exposure', 0, 0, 6, 6, region('North America'), 'chart', true),
            placement('Europe reference', 6, 0, 6, 6, region('Europe'), 'chart', false),
            placement(
              'Explore high-value positions',
              0,
              6,
              12,
              9,
              {
                filterType: 'number',
                colId: 'marketValue',
                type: 'greaterThanOrEqual',
                filter: 500000,
              },
              'both',
              true,
            ),
          ],
        },
      });
      explorer = seed(`dashboards/${explorer.slug}/publish`, 'POST', {}, explorer.version);
    }
    /**
     * Two triage dashboards over one published view and one shared, value-editable filter.
     * Nothing here is bespoke: chart and view elements, a dashboard filter whose comparison
     * values are inputs, and click-to-filter interactions declared on the chart elements.
     */
    const failed = widgets.find(
      (item) => item.templateName === 'Activity monitor · failed events',
    ).widget;
    /** The toolbar every triage dashboard starts with; readers change it, authors save defaults. */
    const filterTile = (start, bucketSeconds) => ({
      id: randomUUID(),
      kind: 'filter',
      widgetId: failed.id,
      widgetRevision: failed.publishedVersion,
      title: 'Filter controls',
      filter: { mode: 'advanced', filterModel: failedEventsFilterModel(start) },
      controls: [
        {
          type: 'window',
          columnId: 'startedDateTime',
          label: 'Recent window',
          options: [15, 30, 60, 180, 360, 720],
          endsAt: '2026-10-03T12:00:00',
        },
        {
          type: 'bucket',
          label: 'Time buckets',
          seconds: bucketSeconds,
          options: [6, 15, 30, 60, 300, 900],
        },
        { type: 'values', columnId: 'type', label: 'Event type', allowAll: true },
        {
          type: 'values',
          columnId: 'executionStatus',
          label: 'Status',
          multiple: true,
          options: ['Failed', 'Breached', 'Completed with exceptions', 'Awaiting User Action'],
        },
        {
          type: 'groupBy',
          label: 'Group grid by',
          options: [
            { columnId: 'type', label: 'Type' },
            { columnId: 'source', label: 'Source system' },
            { columnId: 'tenantCode', label: 'Client tenant' },
            { columnId: 'name', label: 'Activity name' },
          ],
          allowNone: true,
        },
      ],
      x: 0,
      y: 0,
      w: 12,
      h: 3,
    });
    const chartTile = (chartId, title, x, y, w, h) => ({
      id: randomUUID(),
      kind: 'chart',
      widgetId: failed.id,
      widgetRevision: failed.publishedVersion,
      chartId,
      title,
      x,
      y,
      w,
      h,
      interactions: { selectFilter: true },
    });
    const gridTile = (title, x, y, w, h) => ({
      id: randomUUID(),
      kind: 'view',
      widgetId: failed.id,
      widgetRevision: failed.publishedVersion,
      title,
      x,
      y,
      w,
      h,
      displayMode: 'grid',
      interactions: { switchView: false },
      viewOverrides: {
        allowDownload: true,
        filterControls: { visible: true, parameterizable: false },
      },
    });
    const triageDashboards = [
      {
        name: 'Explore failure activity',
        description:
          'Grid first: failed and breached events of the last 30 minutes grouped by activity type, then the timeline and the ranked types. The filter controls set the window, buckets, type, statuses and grouping for every element; click a bar to narrow further.',
        items: [
          filterTile('2026-10-03T11:30:00', 300),
          gridTile('Matching failed events', 0, 3, 12, 8),
          chartTile('activity-failures-5min', 'Failures over time', 0, 11, 6, 7),
          chartTile('activity-failures-by-type', 'Failures by type', 6, 11, 6, 7),
        ],
      },
      {
        name: 'Failure triage',
        description:
          'Timeline first: failed and breached events per minute over the last hour. Click a spike to retain that minute, then review the ranked types and the matching events beside it. Reset the filter controls to return to the saved hour.',
        items: [
          filterTile('2026-10-03T11:00:00', 60),
          chartTile('activity-failures-1min', 'Failures over time', 0, 3, 12, 7),
          chartTile('activity-failures-by-type', 'Failures by type', 0, 10, 5, 8),
          gridTile('Matching failed events', 5, 10, 7, 8),
        ],
      },
    ];
    for (const definition of triageDashboards) {
      let saved = dashboards.find((item) => item.slug.startsWith(slugPrefix(definition.name)));
      if (!saved) {
        saved = seed('dashboards', 'POST', {
          name: definition.name,
          description: definition.description,
          body: {
            schemaVersion: 2,
            group: 'Operations',
            tags: ['Featured', 'Operations', 'Triage'],
            items: definition.items,
          },
        });
        saved = seed(`dashboards/${saved.slug}/publish`, 'POST', {}, saved.version);
      }
    }
    const focused = [];
    for (const sample of createFocusedDashboards(models, widgets)) {
      let saved = dashboards.find((item) => item.slug.startsWith(slugPrefix(sample.name)));
      if (!saved) {
        saved = seed('dashboards', 'POST', sample);
        saved = seed(`dashboards/${saved.slug}/publish`, 'POST', {}, saved.version);
      }
      focused.push(saved);
    }
  }
  return { resources, revisions, datasets, sources };
}
