import type { Operator } from './contracts.js';
import { isColumnGroupTag } from './column-grouping.js';
export type Kind = 'text' | 'number' | 'date' | 'datetime';
export interface ColumnSpec {
  id: string;
  label: string;
  kind: Kind;
  aliases: string[];
  nullable: boolean;
  values?: string[];
  scale?: number;
  sql: string;
  description: string;
  /** Trusted application metadata; never accepted from chart requests. */
  chartRole?: 'identifier' | 'dimension' | 'measure' | 'temporal';
  unit?: string | null;
  /** Optional trusted column-panel category; one trimmed label, never row grouping or AI input. */
  groupByTag?: string;
}
export const SCHEMA_VERSION = 'finance-400-v2';
const CORE_COLUMNS: ColumnSpec[] = [
  {
    id: 'id',
    label: 'Account ID',
    kind: 'text',
    aliases: ['account id'],
    nullable: false,
    sql: 'ACCOUNT_ID',
    description: 'Unique account identifier.',
  },
  {
    id: 'accountName',
    label: 'Account name',
    kind: 'text',
    aliases: ['account name', 'name'],
    nullable: false,
    sql: 'ACCOUNT_NAME',
    description: 'Account display name. Text matching is case insensitive; quote multiword values.',
  },
  {
    id: 'accountDate',
    label: 'Account date',
    kind: 'date',
    aliases: ['account date', 'business date'],
    nullable: false,
    sql: 'ACCOUNT_DATE',
    description: 'Business account date, a calendar DATE without a time zone.',
  },
  {
    id: 'createdDate',
    label: 'Created date',
    kind: 'date',
    aliases: ['created date', 'creation date'],
    nullable: false,
    sql: 'CREATED_DATE',
    description: 'Account creation DATE. Distinct from the business account date.',
  },
  {
    id: 'updatedAt',
    label: 'Updated at (UTC)',
    kind: 'datetime',
    aliases: ['updated at', 'update time', 'updated'],
    nullable: false,
    sql: 'UPDATED_AT',
    description:
      'UTC timestamp. A whole-day request uses the selected time zone; exact timestamps require Z or an offset.',
  },
  {
    id: 'status',
    label: 'Status',
    kind: 'text',
    aliases: ['status', 'account status'],
    nullable: true,
    values: ['failed', 'pending', 'completed', 'delivered'],
    sql: 'STATUS',
    description: 'Exact business status. Missing means database NULL, not the text unknown.',
  },
  {
    id: 'delivered',
    label: 'Delivered',
    kind: 'text',
    aliases: ['delivered', 'delivery status', 'delivered status'],
    nullable: true,
    values: ['yes', 'no', 'unknown'],
    sql: 'DELIVERED',
    description:
      'Delivery indicator: yes means received, no means did not receive, unknown is recorded uncertainty. NULL means missing information, not a negative delivery outcome.',
  },
  {
    id: 'balance',
    label: 'Balance (USD)',
    kind: 'number',
    aliases: ['balance', 'amount'],
    nullable: true,
    scale: 2,
    sql: 'BALANCE',
    description:
      'Finite numeric balance in USD, up to two decimal places. No rounding, currency conversion or inferred scaling.',
  },
];

// 16 core columns plus 32 quarterly metrics over 12 quarters = exactly 400.
const MARKET_COLUMNS: ColumnSpec[] = [
  {
    id: 'symbol',
    label: 'Symbol',
    kind: 'text',
    aliases: ['symbol', 'ticker'],
    nullable: false,
    sql: 'SYMBOL',
    description: 'Historical market fixture ticker; AAPL in this sample.',
  },
  {
    id: 'marketDate',
    label: 'Market date',
    kind: 'date',
    aliases: ['market date', 'trading date'],
    nullable: false,
    sql: 'MARKET_DATE',
    description:
      'Historical trading DATE from the static Apple fixture, distinct from synthetic account dates.',
  },
  ...(['open', 'high', 'low', 'close', 'adjustedClose'] as const).map(
    (name): ColumnSpec => ({
      id: name === 'adjustedClose' ? name : name + 'Price',
      label:
        name === 'adjustedClose'
          ? 'Adjusted close'
          : name[0].toUpperCase() + name.slice(1) + ' price',
      kind: 'number',
      aliases: [name === 'adjustedClose' ? 'adjusted close' : name + ' price'],
      nullable: false,
      scale: 6,
      sql: name === 'adjustedClose' ? 'ADJUSTED_CLOSE' : name.toUpperCase() + '_PRICE',
      description:
        'Historical Apple price in USD, six decimal places, copied from the static fixture. Not a current quote.',
    }),
  ),
  {
    id: 'volume',
    label: 'Volume',
    kind: 'number',
    aliases: ['volume', 'trading volume'],
    nullable: false,
    scale: 0,
    sql: 'VOLUME',
    description: 'Historical traded shares, an integer. No k/m suffixes.',
  },
];
const METRICS = [
  'revenue',
  'cost of revenue',
  'gross profit',
  'operating expenses',
  'operating income',
  'interest expense',
  'income tax',
  'net income',
  'cash',
  'receivables',
  'inventory',
  'current assets',
  'total assets',
  'payables',
  'current liabilities',
  'long term debt',
  'total liabilities',
  'equity',
  'operating cash flow',
  'capital expenditure',
  'free cash flow',
  'dividends',
  'depreciation',
  'research expense',
  'sales expense',
  'deferred revenue',
  'goodwill',
  'intangible assets',
  'retained earnings',
  'working capital',
  'ebitda',
  'investments',
];
export const QUARTERLY_COLUMNS: ColumnSpec[] = Array.from({ length: 12 }, (_, q) => {
  const period = `${2024 + Math.floor(q / 4)} Q${(q % 4) + 1}`;
  return METRICS.map(
    (metric): ColumnSpec => ({
      id:
        metric.replace(/ ([a-z])/g, (_, ch: string) => ch.toUpperCase()) +
        '_' +
        period.replace(' ', '_'),
      label: metric[0].toUpperCase() + metric.slice(1) + ' ' + period,
      kind: 'number',
      aliases: [metric + ' ' + period.toLowerCase()],
      nullable: true,
      scale: 2,
      sql: metric.toUpperCase().replaceAll(' ', '_') + '_' + period.replace(' ', '_'),
      description: `Synthetic ${metric}, ${period}, USD, two decimal places. Demonstration values only; not reported Apple financials.`,
      groupByTag: period,
    }),
  );
}).flat();
export const COLUMNS: ColumnSpec[] = [
  ...CORE_COLUMNS.map((column) => ({ ...column, groupByTag: 'Account details' })),
  ...MARKET_COLUMNS.map((column) => ({ ...column, groupByTag: 'Market data' })),
  ...QUARTERLY_COLUMNS,
];

/** The schema is application configuration, never a user-provided request body. */
export function validateSchema(columns: readonly ColumnSpec[]): void {
  const ids = new Set<string>(),
    sql = new Set<string>(),
    labels = new Set<string>();
  const aliases = new Map<string, string>();
  for (const c of columns) {
    if (
      !/^[A-Za-z][A-Za-z0-9_]*$/.test(c.id) ||
      ['constructor', 'prototype', '__proto__', 'tenant'].includes(c.id) ||
      !c.sql ||
      c.sql.length > 255 ||
      /[\u0000-\u001f\u007f]/.test(c.sql) ||
      ids.has(c.id) ||
      sql.has(c.sql) ||
      labels.has(c.label.toLowerCase()) ||
      !['text', 'number', 'date', 'datetime'].includes(c.kind) ||
      !c.description ||
      (c.groupByTag !== undefined && !isColumnGroupTag(c.groupByTag)) ||
      (c.chartRole !== undefined &&
        (!['identifier', 'dimension', 'measure', 'temporal'].includes(c.chartRole) ||
          (c.chartRole === 'measure' && c.kind !== 'number') ||
          (c.chartRole === 'temporal' && c.kind !== 'date' && c.kind !== 'datetime'))) ||
      (c.unit !== undefined &&
        c.unit !== null &&
        (typeof c.unit !== 'string' || !c.unit.trim() || c.unit.length > 64)) ||
      (c.values !== undefined &&
        (c.kind !== 'text' ||
          !c.values.length ||
          c.values.some((value) => typeof value !== 'string' || value.length > 256) ||
          new Set(c.values.map((value) => value.toLowerCase())).size !== c.values.length)) ||
      (c.scale !== undefined &&
        (c.kind !== 'number' || !Number.isInteger(c.scale) || c.scale < 0 || c.scale > 6))
    ) {
      throw new Error('Invalid or duplicate schema column: ' + c.id);
    }
    ids.add(c.id);
    sql.add(c.sql);
    labels.add(c.label.toLowerCase());
    for (const alias of [c.id, ...c.aliases]) {
      const normalized = alias.trim().toLowerCase();
      if (!normalized || (aliases.has(normalized) && aliases.get(normalized) !== c.id))
        throw new Error('Ambiguous schema alias: ' + alias);
      aliases.set(normalized, c.id);
    }
  }
}
validateSchema(COLUMNS);

export const COLUMN_MAP = new Map(COLUMNS.map((c) => [c.id, c]));
export const LIMITS = {
  text: 2000,
  leaves: 24,
  depth: 5,
  conditionsPerColumn: 2,
  ttlMs: 300_000,
  maxPending: 1000,
  maxRows: 500,
} as const;
export function operators(c: ColumnSpec): Operator[] {
  const basic: Operator[] = ['equals', 'notEqual'];
  const extra: Operator[] =
    c.kind === 'text'
      ? ['contains', 'notContains', 'startsWith', 'endsWith']
      : ['greaterThan', 'greaterThanOrEqual', 'lessThan', 'lessThanOrEqual'];
  return [...basic, ...extra, 'blank', 'notBlank'];
}
