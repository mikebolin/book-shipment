const randomUUID = () => crypto.randomUUID();

/** Small, focused dashboards with independently configurable published view placements. */
export function createFocusedDashboards(models, views) {
  const modelFor = (source) => {
    const model = models.find((item) => item.body.sourceKey === source);
    if (!model) throw new Error(`Missing ${source} model for the sample dashboards.`);
    return model;
  };
  const published = (name) => {
    const view = views.find((item) => item.templateName === name)?.widget;
    if (!view?.publishedVersion) {
      throw new Error(
        `Publish "${name}" before creating sample dashboards. Its existing draft was preserved.`,
      );
    }
    return view;
  };
  const section = (title, description, y) => ({
    id: randomUUID(),
    kind: 'section',
    title,
    description,
    x: 0,
    y,
    w: 12,
    h: 1,
  });
  const view = (source, title, sectionId, x, y, w, h, displayMode = 'chart', overrides = {}) => ({
    id: randomUUID(),
    kind: 'view',
    widgetId: source.id,
    widgetRevision: source.publishedVersion,
    title,
    sectionId,
    x,
    y,
    w,
    h,
    displayMode,
    interactions: { switchView: true },
    viewOverrides: {
      allowDownload: true,
      filterControls: { visible: true, parameterizable: true },
      ...overrides,
    },
  });
  const table = (model, visible, sortColumn) => ({
    columnOrder: {
      orderedColIds: [
        ...visible,
        ...model.body.columns.map((column) => column.id).filter((id) => !visible.includes(id)),
      ],
    },
    columnVisibility: {
      hiddenColIds: model.body.columns
        .map((column) => column.id)
        .filter((id) => !visible.includes(id)),
    },
    columnSizing: {
      columnSizingModel: visible.map((colId) => ({
        colId,
        width: ['portfolio', 'facility', 'department'].includes(colId) ? 190 : 150,
      })),
    },
    sort: { sortModel: [{ colId: sortColumn, sort: 'desc' }] },
  });
  const note = (title, content, sectionId, x, y, w, h) => ({
    id: randomUUID(),
    kind: 'text',
    title,
    content,
    tone: 'info',
    sectionId,
    x,
    y,
    w,
    h,
  });
  const finance = modelFor('finance-demo');
  const healthcare = modelFor('healthcare-demo');
  const allocation = published('Asset allocation');
  const performance = published('Portfolio performance');
  const income = published('Income by risk band');
  const activity = published('Care delivered by service');
  const access = published('Access and waiting time');
  const capacity = published('Visits and available capacity');
  const portfolioSummary = section(
    'Portfolio at a glance',
    'Allocation, performance and income from one shared valuation date.',
    0,
  );
  const portfolioRecords = section(
    'Explore the positions',
    'Adjust the minimum market value, review matching records and download the current result.',
    7,
  );
  const careSummary = section(
    'Service performance',
    'Compare completed activity with capacity, then review access by facility.',
    0,
  );
  const careRecords = section(
    'Where to look next',
    'Start with daily average waits of at least 25 minutes; change or clear this sample filter to explore.',
    7,
  );
  // Dashboard model v2: a view is a catalog of elements. Charts and tables from different views
  // and different models sit side by side, inside sections whose children use relative rows.
  const richText = (lines) => ({
    type: 'doc',
    content: lines.map((line) =>
      line.startsWith('# ')
        ? { type: 'heading', attrs: { level: 2 }, content: [{ type: 'text', text: line.slice(2) }] }
        : line
          ? { type: 'paragraph', content: [{ type: 'text', text: line }] }
          : { type: 'paragraph' },
    ),
  });
  const chartElement = (source, sectionId, x, y, w, h, overrides = {}) => ({
    id: randomUUID(),
    kind: 'chart',
    widgetId: source.id,
    widgetRevision: source.publishedVersion,
    chartId: source.body.chart.id,
    sectionId,
    x,
    y,
    w,
    h,
    ...(Object.keys(overrides).length ? { overrides } : {}),
  });
  const tableElement = (source, sectionId, x, y, w, h, overrides = {}) => ({
    id: randomUUID(),
    kind: 'table',
    widgetId: source.id,
    widgetRevision: source.publishedVersion,
    sectionId,
    x,
    y,
    w,
    h,
    ...(Object.keys(overrides).length ? { overrides } : {}),
  });
  const container = (title, description, y, h) => ({
    id: randomUUID(),
    kind: 'section',
    layout: 'grid',
    title,
    description,
    x: 0,
    y,
    w: 12,
    h,
  });
  const financeSection = container(
    'Portfolio picture',
    'Two charts from two views of the finance model.',
    3,
    9,
  );
  const careSection = container(
    'Care operations',
    'A table and a chart from the healthcare model, beside the finance picture.',
    12,
    9,
  );
  const financialState = table(
    finance,
    ['portfolio', 'region', 'assetClass', 'marketValue', 'unrealizedPnl', 'riskBand'],
    'marketValue',
  );
  financialState.filter = {
    advancedFilterModel: {
      filterType: 'number',
      colId: 'marketValue',
      type: 'greaterThanOrEqual',
      filter: 500000,
    },
  };
  const clinicalState = table(
    healthcare,
    ['serviceDate', 'facility', 'department', 'completedVisits', 'capacityVisits', 'waitMinutes'],
    'waitMinutes',
  );
  clinicalState.filter = {
    advancedFilterModel: {
      filterType: 'number',
      colId: 'waitMinutes',
      type: 'greaterThanOrEqual',
      filter: 25,
    },
  };
  return [
    {
      name: 'Cross-model briefing',
      description:
        'Charts and a table placed as individual elements from four published views across two models. Dashboard model v2 with sections as containers.',
      body: {
        schemaVersion: 2,
        group: 'Featured',
        tags: ['Featured', 'Finance', 'Healthcare', 'Composition'],
        items: [
          {
            id: randomUUID(),
            kind: 'richtext',
            tone: 'info',
            document: richText([
              '# One page, two models',
              'Each element below is one chart or one table from a published view. Views are catalogs; dashboards compose their parts.',
              '',
              'Entirely synthetic data, valued 30 September 2026.',
            ]),
            x: 0,
            y: 0,
            w: 12,
            h: 3,
          },
          financeSection,
          chartElement(allocation, financeSection.id, 0, 0, 5, 8, {
            title: 'Allocation by asset class',
          }),
          chartElement(performance, financeSection.id, 5, 0, 7, 8, { chartType: 'column' }),
          careSection,
          tableElement(activity, careSection.id, 0, 0, 7, 8, {
            showRowNumbers: false,
            gridState: clinicalState,
            mode: 'advanced',
          }),
          chartElement(access, careSection.id, 7, 0, 5, 8),
        ],
      },
    },
    {
      name: 'Portfolio command center',
      description:
        'A focused portfolio review with allocation, performance, income and an interactive positions table. Entirely synthetic data, valued 30 September 2026.',
      body: {
        schemaVersion: 1,
        group: 'Finance',
        tags: ['Featured', 'Finance', 'Interactive'],
        items: [
          portfolioSummary,
          view(allocation, 'Asset allocation', portfolioSummary.id, 0, 1, 4, 6),
          view(performance, 'Portfolio performance', portfolioSummary.id, 4, 1, 4, 6),
          view(income, 'Income by risk band', portfolioSummary.id, 8, 1, 4, 6),
          portfolioRecords,
          view(allocation, 'High-value positions', portfolioRecords.id, 0, 8, 8, 8, 'grid', {
            mode: 'advanced',
            gridState: financialState,
            showRowNumbers: false,
          }),
          note(
            'Make it your own',
            'This example contains 2,000 fictional positions. All amounts are illustrative USD as of 30 September 2026.\n\nUse Edit filters to adjust the minimum market value. Download exports the currently displayed data.\n\nIn Edit dashboard, configure a tile to change its chart, visible columns, reader filters or download controls. Changes stay specific to this dashboard.',
            portfolioRecords.id,
            8,
            8,
            4,
            8,
          ),
        ],
      },
    },
    {
      name: 'Care capacity review',
      description:
        'Service capacity, completed activity and waiting-time patterns with a focused operating-record table. Synthetic facility-level summaries; no patient data.',
      body: {
        schemaVersion: 1,
        group: 'Healthcare',
        tags: ['Featured', 'Healthcare', 'Interactive'],
        items: [
          careSummary,
          view(capacity, 'Completed visits and capacity', careSummary.id, 0, 1, 8, 6),
          view(access, 'Average wait by facility', careSummary.id, 8, 1, 4, 6),
          careRecords,
          view(activity, 'Operating records to review', careRecords.id, 0, 8, 8, 8, 'grid', {
            mode: 'advanced',
            gridState: clinicalState,
            showRowNumbers: false,
          }),
          note(
            'Read the measures clearly',
            'This example contains 2,000 fictional facility, department and day summaries from 12 August through 30 September 2026.\n\nAverage wait is an unweighted mean of daily department averages. The 25-minute filter is an exploration example, not a clinical threshold.\n\nEdit filters to explore another facility, service or waiting time. Downloads reflect the current filtered result.',
            careRecords.id,
            8,
            8,
            4,
            8,
          ),
        ],
      },
    },
  ];
}
