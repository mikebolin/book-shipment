import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {
  compileStudioQuery,
  compileStudioPivotDiscovery,
  type StudioQueryResult,
} from '../libs/charting/src/lib/core/domain/studio-query';
import { MockStudioQueryExecutor } from '../libs/charting/src/lib/explorer/mock-studio-query-executor';
import {
  createStudioDatasource,
  studioRowsRequest,
} from '../libs/charting/src/lib/explorer/studio-server-datasource';
import { persistedGridState } from '../libs/charting/src/lib/rendering/grid-state-normalization';
import { filteredExportRows } from '../libs/charting/src/lib/rendering/filtered-export-rows';
import type { AnalyticsRowsRequest } from '../libs/charting/src/lib/core/domain/analytics-query';
import type { SqlDataset } from '../libs/charting/src/lib/core/domain/sql-dataset';
import type { ColumnSpec } from '../libs/charting/src/lib/core/domain/schema';
import { seed } from './fixtures';
import { createInitialState } from '../libs/charting/src/lib/core/state/workspace-state';

const column = (id: string, kind: ColumnSpec['kind'], nullable = true): ColumnSpec => ({
  id,
  kind,
  nullable,
  sql: id.toUpperCase(),
  label: id,
  aliases: [],
  description: id,
});
const columns = [
  column('eventId', 'text', false),
  column('type', 'text'),
  column('status', 'text'),
  column('amount', 'number'),
  column('time', 'datetime'),
  column('day', 'date'),
];
const dataset: SqlDataset = {
  columns,
  table: ['ANALYTICS', 'PUBLIC', 'ACTIVITY_MONITOR'],
  tenantColumn: 'TENANT_ID',
  rowIdColumn: 'eventId',
};
const rows = [
  {
    eventId: 'e1',
    type: 'Ingestion',
    status: 'Failed',
    amount: null,
    time: '2026-10-01 01:00:00',
    day: '2026-10-01',
  },
  {
    eventId: 'e2',
    type: 'Ingestion',
    status: 'Completed',
    amount: 20,
    time: '2026-10-01 02:00:00',
    day: '2026-10-01',
  },
  {
    eventId: 'e3',
    type: 'Export',
    status: 'Failed',
    amount: 50,
    time: '2026-10-02 01:00:00',
    day: '2026-10-02',
  },
  {
    eventId: 'e4',
    type: 'Export',
    status: 'Failed',
    amount: 10,
    time: '2026-10-02 02:00:00',
    day: '2026-10-02',
  },
  {
    eventId: 'e5',
    type: null,
    status: 'Failed',
    amount: 7,
    time: '2026-10-02 03:00:00',
    day: '2026-10-02',
  },
  {
    eventId: 'e6',
    type: '(Blanks)',
    status: 'Failed',
    amount: 8,
    time: '2026-10-02 04:00:00',
    day: '2026-10-02',
  },
  {
    eventId: 'e7',
    type: '\\literal',
    status: 'Failed',
    amount: 9,
    time: '2026-10-02 05:00:00',
    day: '2026-10-02',
  },
];
const executor = new MockStudioQueryExecutor(() => ({ rows, columns, rowIdColumn: 'eventId' }));
const signal = () => new AbortController().signal;
const request = (
  overrides: Partial<AnalyticsRowsRequest['request']> = {},
): AnalyticsRowsRequest => ({
  mode: 'advanced',
  calculatedColumnIds: [],
  request: {
    startRow: 0,
    endRow: 250,
    filterModel: null,
    sortModel: [],
    rowGroupCols: [],
    valueCols: [],
    pivotCols: [],
    pivotMode: false,
    groupKeys: [],
    ...overrides,
  },
});
const statements: { name: string; sql: string; binds: unknown[] }[] = [];
function compile(input: AnalyticsRowsRequest) {
  const query = compileStudioQuery(input, 'demo', dataset);
  for (const [name, statement] of Object.entries(query))
    if (statement && typeof statement === 'object' && 'sql' in statement)
      statements.push({ name, ...statement } as any);
  return query;
}

test('SSRM raw blocks preserve newest sort with a stable non-id key and real offsets', async () => {
  const first = compile(
    request({ startRow: 0, endRow: 2, sortModel: [{ colId: 'time', sort: 'desc' }] }),
  );
  const second = compile(
    request({ startRow: 2, endRow: 4, sortModel: [{ colId: 'time', sort: 'desc' }] }),
  );
  assert.match(
    first.rows.sql,
    /ORDER BY "time" DESC NULLS LAST, "eventId" ASC NULLS LAST LIMIT \? OFFSET \?$/,
  );
  assert.deepEqual(second.rows.binds.slice(-2), [2, 2]);
  const a = await executor.execute(first, signal()),
    b = await executor.execute(second, signal());
  assert.deepEqual(
    a.rowData.map((r) => r.eventId),
    ['e7', 'e6'],
  );
  assert.deepEqual(
    b.rowData.map((r) => r.eventId),
    ['e5', 'e4'],
  );
  assert.equal(a.rowCount, 7);
  assert.equal(a.matchedRowCount, 7);
});
test('group counts cover the full cohort before paging; detail sort waits for leaf route', async () => {
  const input = request({
    endRow: 1,
    rowGroupCols: [{ id: 'type' }],
    valueCols: [{ id: 'amount', aggFunc: 'sum' }],
    sortModel: [{ colId: 'time', sort: 'desc' }],
  });
  const query = compile(input),
    result = await executor.execute(query, signal());
  assert.match(
    query.rows.sql,
    /SELECT "type", COUNT\(\*\) AS "__groupCount", SUM\("amount"\) AS "amount" FROM "ROUTE_ROWS" GROUP BY "type"/,
  );
  assert.doesNotMatch(query.rows.sql, /ORDER BY "time"/);
  assert.equal(result.rowCount, 5);
  assert.equal(result.rowData.length, 1);
  const all = await executor.execute(
    compile({ ...input, request: { ...input.request, endRow: 250 } }),
    signal(),
  );
  assert.equal(all.rowData.find((r) => r.type === 'Export')?.amount, 60);
  assert.equal(all.rowData.find((r) => r.type === 'Export')?.__groupCount, 2);
  const leaf = compile({
    ...input,
    request: { ...input.request, groupKeys: ['Export'], endRow: 250 },
  });
  assert.match(leaf.rows.sql, /WHERE "type" = \?/);
  assert.match(leaf.rows.sql, /ORDER BY "time" DESC/);
  assert.deepEqual(
    (await executor.execute(leaf, signal())).rowData.map((r) => r.eventId),
    ['e4', 'e3'],
  );
});
test('multi-level grouping keeps nested OR scoped beneath tenant and group route', async () => {
  const input = request({
    rowGroupCols: [{ id: 'type' }, { id: 'status' }],
    groupKeys: ['Export'],
    filterModel: {
      filterType: 'join',
      type: 'OR',
      conditions: [
        { filterType: 'text', colId: 'status', type: 'equals', filter: 'Failed' },
        { filterType: 'number', colId: 'amount', type: 'greaterThan', filter: 15 },
      ],
    },
  });
  const query = compile(input),
    result = await executor.execute(query, signal());
  assert.match(query.rows.sql, /"TENANT_ID" = \? AND/);
  assert.match(query.rows.sql, / OR /);
  assert.match(query.rows.sql, /GROUP BY "status"/);
  assert.ok(query.rows.binds.includes('Export'));
  assert.deepEqual(result.rowData, [{ status: 'Failed', __groupCount: 2 }]);
  assert.equal(result.matchedRowCount, 7);
});
test('null groups, literal sentinel and backslash keys stay distinct', async () => {
  for (const [key, id] of [
    ['(Blanks)', 'e5'],
    ['\\(Blanks)', 'e6'],
    ['\\\\literal', 'e7'],
  ]) {
    const query = compile(request({ rowGroupCols: [{ id: 'type' }], groupKeys: [key] }));
    const result = await executor.execute(query, signal());
    assert.deepEqual(
      result.rowData.map((r) => r.eventId),
      [id],
    );
    if (id === 'e5') assert.match(query.rows.sql, /"type" IS NULL/);
  }
});
test('aggregate sorting, counts including nulls, and first/last use declared source key', async () => {
  for (const func of ['sum', 'avg', 'min', 'max', 'count', 'first', 'last']) {
    const query = compile(
      request({
        rowGroupCols: [{ id: 'type' }],
        valueCols: [{ id: 'amount', aggFunc: func }],
        sortModel: [{ colId: 'amount', sort: 'desc' }],
      }),
    );
    assert.match(query.rows.sql, /ORDER BY "amount" DESC NULLS LAST, "type" ASC/);
    const result = await executor.execute(query, signal());
    const ingestion = result.rowData.find((r) => r.type === 'Ingestion')!;
    if (func === 'count') assert.equal(ingestion.amount, 2);
    if (func === 'first') assert.equal(ingestion.amount, null);
    if (func === 'last') assert.equal(ingestion.amount, 20);
    assert.ok(result.grandTotalData);
  }
});
test('calculated fields are projected before filtering, grouping and pagination', () => {
  const definition = {
    id: 'calc_double',
    label: 'Double',
    expression: {
      kind: 'binary',
      operator: 'multiply',
      left: { kind: 'field', field: 'amount' },
      right: { kind: 'number', value: 2 },
    },
  } as any;
  const query = compileStudioQuery(
    {
      ...request({
        rowGroupCols: [{ id: 'type' }],
        valueCols: [{ id: 'calc_double', aggFunc: 'sum' }],
        filterModel: {
          filterType: 'number',
          colId: 'calc_double',
          type: 'greaterThan',
          filter: 10,
        },
      }),
      calculatedColumnIds: ['calc_double'],
    },
    'demo',
    dataset,
    [definition],
  );
  assert.match(query.rows.sql, /"DERIVED_ROWS"/);
  assert.match(query.rows.sql, /SUM\("calc_double"\)/);
  statements.push({ name: 'calculated', ...query.rows });
});
test('pivot discovery and generated conditional aggregates preserve pivot result fields', async () => {
  const input = request({
    rowGroupCols: [{ id: 'type' }],
    valueCols: [{ id: 'amount', aggFunc: 'sum' }],
    pivotMode: true,
    pivotCols: [{ id: 'status' }],
  });
  const discovery = compileStudioPivotDiscovery(input, 'demo', dataset);
  const pivots = await executor.discoverPivots(discovery, input, signal());
  const query = compileStudioQuery(input, 'demo', dataset, [], pivots);
  const result = await executor.execute(query, signal());
  assert.deepEqual(query.pivotResultFields, result.pivotResultFields);
  assert.match(query.rows.sql, /SUM\(IFF\("status" = \?, "amount", NULL\)\)/);
  assert.equal(result.rowData.find((r) => r.type === 'Export')?.['Failed|amount'], 60);
  statements.push({ name: 'pivot-discovery', ...discovery }, { name: 'pivot', ...query.rows });
});
test('empty matches produce zero groups, correct row counts, and no phantom summary', async () => {
  for (const shape of [
    { rowGroupCols: [{ id: 'type' }] },
    { pivotMode: true, valueCols: [{ id: 'amount', aggFunc: 'sum' }] },
  ]) {
    const q = compile(
      request({
        ...shape,
        filterModel: { filterType: 'number', colId: 'amount', type: 'greaterThan', filter: 1000 },
      }),
    );
    const result = await executor.execute(q, signal());
    assert.equal(result.rowCount, 0);
    assert.deepEqual(result.rowData, []);
  }
});
test('identifiers and values cannot escape mappings; invalid requests fail before execution', () => {
  const hostile = "x' OR 1=1 --";
  const query = compile(request({ rowGroupCols: [{ id: 'type' }], groupKeys: [hostile] }));
  assert.ok(query.rows.binds.includes(hostile));
  assert.ok(!query.rows.sql.includes(hostile));
  for (const input of [
    request({ startRow: 2, endRow: 1 }),
    request({ endRow: 100001 }),
    request({ rowGroupCols: [{ id: 'missing' }] }),
    request({ valueCols: [{ id: 'type', aggFunc: 'sum' }] }),
    request({ sortModel: [{ colId: 'DROP TABLE', sort: 'asc' }] }),
  ])
    assert.throws(() => compile(input));
});
test('column presentation order and group sort survive saving; exports use all filtered rows', () => {
  const state = persistedGridState({
    columnOrder: { orderedColIds: ['amount', 'type', 'eventId', 'ag-Grid-AutoColumn'] },
    sort: {
      sortModel: [
        { colId: 'ag-Grid-AutoColumn', sort: 'desc' },
        { colId: 'amount', sort: 'desc' },
      ],
    },
    rowGroup: { groupColIds: ['type'] },
  });
  assert.deepEqual(state.columnOrder?.orderedColIds, ['amount', 'type', 'eventId']);
  assert.equal(state.sort?.sortModel[0].colId, 'ag-Grid-AutoColumn');
  const exported = filteredExportRows(
    rows,
    columns,
    {
      filter: {
        advancedFilterModel: {
          filterType: 'text',
          colId: 'type',
          type: 'equals',
          filter: 'Export',
        },
      },
      sort: { sortModel: [{ colId: 'time', sort: 'desc' }] },
    },
    'advanced',
    'eventId',
  );
  assert.deepEqual(
    exported.map((r) => r.eventId),
    ['e4', 'e3'],
  );
});
test('all bundled model mappings compile as Snowflake sources', () => {
  const state = createInitialState(seed());
  for (const model of state.resources.models) {
    const query = compileStudioQuery(request(), 'local', model.body.sqlDataset);
    assert.match(query.rows.sql, /LIMIT \? OFFSET \?$/);
  }
});
test('datasource normalizes AG Grid sort metadata before strict SQL validation', async () => {
  const input = studioRowsRequest(
    {
      ...request({ rowGroupCols: [{ id: 'type' }] }).request,
      sortModel: [{ colId: 'ag-Grid-AutoColumn', sort: 'desc', type: 'rowGroup' }],
    } as any,
    'advanced',
    [],
  );
  assert.deepEqual(input.request.sortModel, [{ colId: 'ag-Grid-AutoColumn', sort: 'desc' }]);
  const query = compile(input);
  assert.match(query.rows.sql, /ORDER BY "type" DESC NULLS LAST/);
  const result = await executor.execute(query, signal());
  assert.equal(result.rowData.at(-1)?.type, null);
});
test('datasource discards stale filter responses and aborts on destroy', async () => {
  const pending: { resolve: (r: StudioQueryResult) => void; signal: AbortSignal }[] = [];
  let successes = 0;
  const ds = createStudioDatasource({
    context: () => ({ mode: 'advanced', tenant: 'demo', dataset, definitions: [] }),
    executor: {
      discoverPivots: async () => [],
      summarize: async () => [],
      execute: (_q, signal) => new Promise((resolve) => pending.push({ resolve, signal })),
    },
  });
  const params = (filterModel: any) =>
    ({
      request: request({ filterModel }).request,
      api: { isDestroyed: () => false },
      success: () => successes++,
      fail: () => {
        throw Error('Unexpected failure');
      },
    }) as any;
  ds.getRows(params(null));
  ds.getRows(params({ filterType: 'text', colId: 'type', type: 'equals', filter: 'Export' }));
  assert.equal(pending[0].signal.aborted, true);
  const result = { rowData: [], rowCount: 0, matchedRowCount: 0, totalRowCount: 7 };
  pending[0].resolve(result);
  pending[1].resolve(result);
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(successes, 1);
  ds.getRows(params(null));
  ds.destroy?.();
  assert.equal(pending[2].signal.aborted, true);
});
test('SSRM blocks keep every field of compact snapshot rows and calculated rows', async () => {
  // Bundled models decode into compact rows: only `id` is an own property; every other
  // field is an enumerable getter on a shared prototype. A block must still carry all fields.
  const { readSnapshot } = await import('../libs/charting/src/lib/core/domain/shared-snapshot');
  const compactColumns = [
    column('id', 'text', false),
    column('type', 'text'),
    column('status', 'text'),
    column('amount', 'number'),
    column('time', 'datetime'),
  ];
  const compactDataset: SqlDataset = {
    columns: compactColumns,
    table: ['ACTIVITY_MONITOR'],
    tenantColumn: 'TENANT_ID',
    rowIdColumn: 'id',
  };
  const encoded = [
    {
      type: 'start',
      schemaVersion: 'v1',
      totalRows: 3,
      encoding: 'column-rows-v1',
      columns: compactColumns.map((c) => c.id),
    },
    {
      type: 'batch',
      rows: [
        ['a1', 'Ingestion', 'Failed', null, '2026-10-01T01:00:00+00:00'],
        ['a2', 'Ingestion', 'Completed', 20, '2026-10-01 02:00:00'],
        ['a3', 'Export', 'Failed', 50, '2026-10-02T01:00:00Z'],
      ],
    },
    { type: 'complete', totalRows: 3 },
  ]
    .map((line) => JSON.stringify(line))
    .join('\n');
  const snapshot = await readSnapshot(
    new Response(encoded),
    { key: 'activity', schemaVersion: 'v1', datetimeColumns: ['time'] },
    new AbortController().signal,
  );
  assert.deepEqual(Object.keys(snapshot.rows[0]), ['id']);
  assert.equal(snapshot.rows[0].type, 'Ingestion');
  // Calculated columns are materialized onto rows that inherit the compact source row.
  const materialized = snapshot.rows.map((row) =>
    Object.defineProperty(Object.create(row), 'calc_double', {
      value: typeof row.amount === 'number' ? row.amount * 2 : null,
      enumerable: true,
    }),
  );
  const calculated = { ...column('calc_double', 'number'), sql: '' };
  const compactExecutor = new MockStudioQueryExecutor(() => ({
    rows: materialized,
    columns: [...compactColumns, calculated],
    rowIdColumn: 'id',
  }));
  const leaf = await compactExecutor.execute(
    compileStudioQuery(
      request({ sortModel: [{ colId: 'time', sort: 'desc' }] }),
      'demo',
      compactDataset,
    ),
    signal(),
  );
  assert.deepEqual(leaf.rowData[0], {
    id: 'a3',
    type: 'Export',
    status: 'Failed',
    amount: 50,
    time: '2026-10-02 01:00:00',
    calc_double: 100,
  });
  assert.deepEqual(
    leaf.rowData.map((r) => r.id),
    ['a3', 'a2', 'a1'],
  );
  assert.equal(leaf.rowData[2].time, '2026-10-01 01:00:00');
  const grouped = await compactExecutor.execute(
    compileStudioQuery(
      request({
        rowGroupCols: [{ id: 'type' }],
        valueCols: [{ id: 'amount', aggFunc: 'sum' }],
        sortModel: [{ colId: 'amount', sort: 'desc' }],
      }),
      'demo',
      compactDataset,
    ),
    signal(),
  );
  assert.deepEqual(grouped.rowData, [
    { type: 'Export', amount: 50, __groupCount: 1 },
    { type: 'Ingestion', amount: 20, __groupCount: 2 },
  ]);
  assert.equal(grouped.matchedRowCount, 3);
  const drill = await compactExecutor.execute(
    compileStudioQuery(
      request({ rowGroupCols: [{ id: 'type' }], groupKeys: ['Ingestion'] }),
      'demo',
      compactDataset,
    ),
    signal(),
  );
  assert.deepEqual(
    drill.rowData.map((r) => [r.id, r.status, r.amount]),
    [
      ['a1', 'Failed', null],
      ['a2', 'Completed', 20],
    ],
  );
});
test('chart summaries bucket the filtered source relation; chart measures sum counts', async () => {
  const { compileStudioSummary } = await import(
    '../libs/charting/src/lib/core/domain/studio-query'
  );
  const input = {
    mode: 'advanced' as const,
    filterModel: { filterType: 'text', colId: 'status', type: 'equals', filter: 'Failed' },
    bucket: { field: 'time', seconds: 3600 as const },
    dimensions: ['type', 'status'],
  };
  const statement = compileStudioSummary(input, 'demo', dataset);
  assert.match(
    statement.sql,
    /SELECT DATE_TRUNC\('HOUR', "time"\) AS "__bucket", "type", "status", COUNT\(\*\) AS "__count" FROM "SOURCE_ROWS" WHERE "time" IS NOT NULL GROUP BY 1, 2, 3 ORDER BY 1 ASC NULLS LAST, 2 ASC NULLS LAST, 3 ASC NULLS LAST$/,
  );
  assert.deepEqual(statement.binds, ['demo', 'failed']);
  statements.push({ name: 'summary', sql: statement.sql, binds: statement.binds });
  const minute = compileStudioSummary(
    { ...input, bucket: { field: 'time', seconds: 60 } },
    'demo',
    dataset,
  );
  assert.match(minute.sql, /DATE_TRUNC\('MINUTE', "time"\) AS "__bucket"/);
  // Sub-minute widths slice by seconds; minute multiples slice by minutes. Widths are inlined
  // from the validated list, never from the request text.
  const fine = compileStudioSummary(
    { ...input, bucket: { field: 'time', seconds: 6 } },
    'demo',
    dataset,
  );
  assert.match(fine.sql, /TIME_SLICE\("time", 6, 'SECOND'\) AS "__bucket"/);
  statements.push({ name: 'summary-6s', sql: fine.sql, binds: fine.binds });
  const five = compileStudioSummary(
    { ...input, bucket: { field: 'time', seconds: 300 } },
    'demo',
    dataset,
  );
  assert.match(five.sql, /TIME_SLICE\("time", 5, 'MINUTE'\) AS "__bucket"/);
  assert.throws(() =>
    compileStudioSummary({ ...input, bucket: { field: 'day', seconds: 300 } }, 'demo', dataset),
  );
  assert.throws(() =>
    compileStudioSummary(
      { ...input, bucket: { field: 'time', seconds: 7 as unknown as 6 } },
      'demo',
      dataset,
    ),
  );
  assert.throws(() => compileStudioSummary({ ...input, dimensions: ['amount'] }, 'demo', dataset));
  assert.deepEqual(await executor.summarize(statement, signal()), [
    { __bucket: '2026-10-01 01:00:00', type: 'Ingestion', status: 'Failed', __count: 1 },
    { __bucket: '2026-10-02 01:00:00', type: 'Export', status: 'Failed', __count: 1 },
    { __bucket: '2026-10-02 02:00:00', type: 'Export', status: 'Failed', __count: 1 },
    { __bucket: '2026-10-02 03:00:00', type: null, status: 'Failed', __count: 1 },
    { __bucket: '2026-10-02 04:00:00', type: '(Blanks)', status: 'Failed', __count: 1 },
    { __bucket: '2026-10-02 05:00:00', type: '\\literal', status: 'Failed', __count: 1 },
  ]);
  // Events in one minute share a bucket; the returned row represents several events.
  const burst = new MockStudioQueryExecutor(() => ({
    rows: [
      {
        eventId: 'b1',
        type: 'Ingestion',
        status: 'Failed',
        amount: 1,
        time: '2026-10-03 11:35:10',
        day: '2026-10-03',
      },
      {
        eventId: 'b2',
        type: 'Ingestion',
        status: 'Failed',
        amount: 1,
        time: '2026-10-03 11:35:50',
        day: '2026-10-03',
      },
      {
        eventId: 'b3',
        type: 'Ingestion',
        status: 'Completed',
        amount: 1,
        time: '2026-10-03 11:35:55',
        day: '2026-10-03',
      },
      {
        eventId: 'b4',
        type: 'Export',
        status: 'Failed',
        amount: 1,
        time: '2026-10-03 11:36:05',
        day: '2026-10-03',
      },
    ],
    columns,
    rowIdColumn: 'eventId',
  }));
  assert.deepEqual(
    await burst.summarize(
      compileStudioSummary(
        { ...input, filterModel: null, bucket: { field: 'time', seconds: 60 } },
        'demo',
        dataset,
      ),
      signal(),
    ),
    [
      { __bucket: '2026-10-03 11:35:00', type: 'Ingestion', status: 'Completed', __count: 1 },
      { __bucket: '2026-10-03 11:35:00', type: 'Ingestion', status: 'Failed', __count: 2 },
      { __bucket: '2026-10-03 11:36:00', type: 'Export', status: 'Failed', __count: 1 },
    ],
  );
  // Six-second slices separate the same burst; starts align to multiples of six seconds.
  assert.deepEqual(
    await burst.summarize(
      compileStudioSummary(
        { ...input, filterModel: null, bucket: { field: 'time', seconds: 6 } },
        'demo',
        dataset,
      ),
      signal(),
    ),
    [
      { __bucket: '2026-10-03 11:35:06', type: 'Ingestion', status: 'Failed', __count: 1 },
      { __bucket: '2026-10-03 11:35:48', type: 'Ingestion', status: 'Failed', __count: 1 },
      { __bucket: '2026-10-03 11:35:54', type: 'Ingestion', status: 'Completed', __count: 1 },
      { __bucket: '2026-10-03 11:36:00', type: 'Export', status: 'Failed', __count: 1 },
    ],
  );
});
test('a dashboard scope is ANDed into every grid block request', async () => {
  const { combineFilterModels } = await import(
    '../libs/charting/src/lib/explorer/studio-server-datasource'
  );
  const scope = { filterType: 'text', colId: 'status', type: 'equals', filter: 'Failed' };
  const own = { filterType: 'text', colId: 'type', type: 'equals', filter: 'Export' };
  assert.deepEqual(combineFilterModels('advanced', scope, null), scope);
  assert.deepEqual(combineFilterModels('advanced', scope, {}), scope);
  assert.deepEqual(combineFilterModels('advanced', null, {}), null);
  assert.deepEqual(combineFilterModels('advanced', scope, own), {
    filterType: 'join',
    type: 'AND',
    conditions: [scope, own],
  });
  // The dashboard supplies the values for the columns it constrains; the element's own
  // conditions on those columns are defaults it replaces, so a dashboard can widen a window.
  const defaults = {
    filterType: 'join',
    type: 'AND',
    conditions: [
      {
        filterType: 'datetime',
        colId: 'time',
        type: 'greaterThanOrEqual',
        filter: '2026-10-02 00:00:00',
      },
      { filterType: 'datetime', colId: 'time', type: 'lessThan', filter: '2026-10-02 06:00:00' },
      {
        filterType: 'join',
        type: 'OR',
        conditions: [
          { filterType: 'text', colId: 'status', type: 'equals', filter: 'Failed' },
          { filterType: 'text', colId: 'status', type: 'equals', filter: 'Completed' },
        ],
      },
      own,
    ],
  };
  const window = {
    filterType: 'join',
    type: 'AND',
    conditions: [
      {
        filterType: 'datetime',
        colId: 'time',
        type: 'greaterThanOrEqual',
        filter: '2026-10-01 00:00:00',
      },
      { filterType: 'datetime', colId: 'time', type: 'lessThan', filter: '2026-10-03 00:00:00' },
      { filterType: 'text', colId: 'status', type: 'equals', filter: 'Failed' },
    ],
  };
  assert.deepEqual(combineFilterModels('advanced', window, defaults), {
    filterType: 'join',
    type: 'AND',
    conditions: [window, own],
  });
  assert.deepEqual(
    combineFilterModels('advanced', scope, { ...scope, filter: 'Completed' }),
    scope,
  );
  assert.throws(() => combineFilterModels('columns', scope, null));
  const compiled: { rows: { sql: string; binds: unknown[] } }[] = [];
  const ds = createStudioDatasource({
    context: () => ({ mode: 'advanced', tenant: 'demo', dataset, definitions: [] }),
    scope: () => scope,
    executor,
    compiled: (query) => compiled.push(query),
  });
  const ids = await new Promise<unknown[]>((resolve, reject) =>
    ds.getRows({
      request: request({ filterModel: own }).request,
      api: { isDestroyed: () => false },
      success: (result: { rowData: Record<string, unknown>[] }) =>
        resolve(result.rowData.map((row) => row['eventId'])),
      fail: () => reject(new Error('The scoped block request failed.')),
    } as any),
  );
  assert.deepEqual(ids, ['e3', 'e4']);
  assert.match(compiled[0].rows.sql, /LOWER\("STATUS"\) = \? AND LOWER\("TYPE"\) = \?/);
  assert.deepEqual(compiled[0].rows.binds.slice(0, 3), ['demo', 'failed', 'export']);
});
test('typed routes bind numeric, date and timestamp keys without session-dependent parsing', async () => {
  for (const [id, key, predicate] of [
    ['amount', '50', /"amount" = \?/],
    ['day', '2026-10-02', /"day" = TO_DATE\(\?, 'YYYY-MM-DD'\)/],
    ['time', '2026-10-02 01:00:00', /"time" = TO_TIMESTAMP_NTZ\(\?, 'YYYY-MM-DD HH24:MI:SS'\)/],
  ] as const) {
    const query = compile(request({ rowGroupCols: [{ id }], groupKeys: [key] }));
    assert.match(query.rows.sql, predicate);
    assert.equal(query.rows.binds[1], id === 'amount' ? 50 : key);
    const result = await executor.execute(query, signal());
    assert.ok(result.rowData.some((row) => row.eventId === 'e3'));
  }
  assert.throws(() => compile(request({ rowGroupCols: [{ id: 'amount' }], groupKeys: ['bogus'] })));
});

test('time summaries exclude undated records while grid matching counts retain them', async () => {
  const { compileStudioSummary } = await import(
    '../libs/charting/src/lib/core/domain/studio-query'
  );
  const sourceRows = [rows[0], { ...rows[0], eventId: 'undated', time: null }];
  const local = new MockStudioQueryExecutor(() => ({
    rows: sourceRows,
    columns,
    rowIdColumn: 'eventId',
  }));
  const statement = compileStudioSummary(
    {
      mode: 'advanced',
      filterModel: null,
      bucket: { field: 'time', seconds: 60 },
      dimensions: ['type'],
    },
    'demo',
    dataset,
  );
  assert.match(statement.sql, /WHERE "time" IS NOT NULL GROUP BY/);
  const result = await local.summarize(statement, signal());
  assert.equal(result.length, 1);
  assert.equal(result[0].__count, 1);
  assert.equal((await local.execute(compile(request()), signal())).matchedRowCount, 2);
});

test('datasource reports unsupported dashboard scopes through fail instead of throwing into AG Grid', () => {
  let failures = 0;
  let message = '';
  const ds = createStudioDatasource({
    context: () => ({ mode: 'columns', tenant: 'demo', dataset, definitions: [] }),
    scope: () => ({ filterType: 'text', colId: 'status', type: 'equals', filter: 'Failed' }),
    executor,
    error: (error) => {
      message = error.message;
    },
  });
  assert.doesNotThrow(() =>
    ds.getRows({
      request: request().request,
      api: { isDestroyed: () => false },
      success: () => assert.fail('Unsupported scopes must not succeed.'),
      fail: () => {
        failures++;
      },
    } as any),
  );
  assert.equal(failures, 1);
  assert.match(message, /advanced filter mode/);
  ds.destroy?.();
});

test('a host executor receives the source context for both pivot discovery and row blocks', async () => {
  const context = {
    mode: 'advanced' as const,
    sourceId: 'activity-monitor',
    tenant: 'demo',
    dataset,
    definitions: [],
  };
  const contexts: unknown[] = [];
  const ds = createStudioDatasource({
    context: () => context,
    executor: {
      summarize: async () => [],
      discoverPivots: async (statement, input, signal, sourceContext) => {
        contexts.push(sourceContext);
        return executor.discoverPivots(statement, input, signal);
      },
      execute: async (query, signal, sourceContext) => {
        contexts.push(sourceContext);
        return executor.execute(query, signal);
      },
    },
  });
  await new Promise<void>((resolve, reject) =>
    ds.getRows({
      request: request({
        rowGroupCols: [{ id: 'type' }],
        pivotMode: true,
        pivotCols: [{ id: 'status' }],
        valueCols: [{ id: 'amount', aggFunc: 'sum' }],
      }).request,
      api: { isDestroyed: () => false },
      success: () => resolve(),
      fail: () => reject(new Error('The host query failed.')),
    } as any),
  );
  assert.equal(contexts.length, 2);
  assert.ok(contexts.every((received) => received === context));
  ds.destroy?.();
});

test('compiler fixtures have one ordered bind per placeholder', () => {
  for (const statement of statements)
    assert.equal((statement.sql.match(/\?/g) ?? []).length, statement.binds.length, statement.name);
  fs.mkdirSync('evidence', { recursive: true });
  fs.writeFileSync('evidence/studio-sql-statements.json', JSON.stringify(statements, null, 2));
});
