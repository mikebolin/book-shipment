import '@angular/compiler';
import test from 'node:test';
import assert from 'node:assert/strict';
import { createEnvironmentInjector, runInInjectionContext, SimpleChange } from '@angular/core';
import { WorkspaceStore } from '../libs/charting/src/lib/core/state/index';
import { WorkspaceRepository } from '../libs/charting/src/lib/core/data-access/workspace-repository.service';
import { WidgetViewComponent } from '../libs/charting/src/lib/rendering/widget-view.component';
import { ViewExportService } from '../libs/charting/src/lib/rendering/view-export.service';
import { AppThemeService } from '../libs/charting/src/lib/explorer/app-theme.service';
import { STUDIO_QUERY_EXECUTOR } from '../libs/charting/src/lib/explorer/studio-query-executor.token';
import type { WidgetConfiguration } from '../libs/charting/src/lib/core/domain/workspace.types';
import { dataProvider, seed } from './fixtures';

function reader(sourceKey: string, lease: () => unknown) {
  const resources = seed().resources!;
  const model = structuredClone(resources.models![0]);
  model.body.sourceKey = sourceKey;
  const configuration: WidgetConfiguration = {
    schemaVersion: 1,
    modelSchemaVersion: model.body.schemaVersion,
    displayMode: 'grid',
    charts: [],
    chart: null,
    mode: 'advanced',
    gridState: {},
    calculatedColumns: [],
    recordCount: 0,
  };
  const root = createEnvironmentInjector(
    [
      WorkspaceStore,
      dataProvider,
      { provide: WorkspaceRepository, useValue: { lease } },
      { provide: AppThemeService, useValue: {} },
      { provide: ViewExportService, useValue: {} },
      {
        provide: STUDIO_QUERY_EXECUTOR,
        useValue: {
          execute: () => {
            throw new Error('Grid blocks are tested separately');
          },
        },
      },
    ],
    null as any,
  );
  const previousWindow = globalThis.window;
  (globalThis as any).window ??= {};
  const component = runInInjectionContext(root, () => new WidgetViewComponent());
  if (previousWindow === undefined) delete (globalThis as any).window;
  component.model = model;
  component.configuration = configuration;
  return { root, component };
}

test('host grid metadata loads without a snapshot; downloads request an authorized snapshot and can retry failures', async () => {
  let leases = 0;
  const { root, component } = reader('host_holdings', () => {
    leases++;
    return { result: Promise.reject(new Error('Host snapshots are unavailable')), release() {} };
  });
  try {
    await component.reload();
    assert.equal(component.loading(), false);
    assert.equal(component.error(), '');
    assert.equal(leases, 0);
    assert.equal(component.rows().length, 0);
    assert.equal(component.columns.length, component.specs.length);
    assert.ok(component.columns.length > 1);
    assert.throws(() => component.exportCsv(), /not been loaded for export/);
    await assert.rejects(component.exportSection(), /Host snapshots are unavailable/);
    assert.equal(leases, 1);
    await assert.rejects(component.exportSection(), /Host snapshots are unavailable/);
    assert.equal(leases, 2);
    assert.equal(component.error(), '');
  } finally {
    component.ngOnDestroy();
    root.destroy();
  }
});

test('session imports keep their local rows when a host SQL executor is installed', async () => {
  let leases = 0;
  const { root, component } = reader('local_import', () => {
    leases++;
    return { result: Promise.resolve({ rows: [], decodedBytes: 0, receivedAt: 0 }), release() {} };
  });
  try {
    await component.reload();
    assert.equal(component.error(), '');
    assert.equal(leases, 1);
    assert.equal((await component.exportSection())!.charts.length, 0);
    assert.equal(leases, 1);
  } finally {
    component.ngOnDestroy();
    root.destroy();
  }
});

test('server grid policy remounts preserve reader filters and grouping state', async () => {
  let leases = 0;
  const { root, component } = reader('host_policy', () => {
    leases++;
    throw new Error('Unexpected snapshot');
  });
  try {
    component.configuration.displayMode = 'both';
    await component.reload();
    assert.equal(component.effectiveMode, 'grid');
    const previous = component.configuration;
    const state = {
      rowGroup: { groupColIds: ['region'] },
      sort: { sortModel: [{ colId: 'region', sort: 'desc' as const }] },
    };
    (component as any).gridApi = { isDestroyed: () => false, getState: () => state };
    component.tableChanged.set(true);
    component.groupingChanged.set(true);
    const key = component.gridRenderKeys()[0];
    const policy = {
      cacheBlockSize: 50,
      maxBlocksInCache: 5,
      maxConcurrentRequests: 1,
      blockLoadDebounceMillis: 120,
    };
    component.configuration = { ...previous, serverGrid: policy };
    component.ngOnChanges({
      configuration: new SimpleChange(previous, component.configuration, false),
    });
    assert.deepEqual(component.serverGridSettings, policy);
    assert.deepEqual(component.initialState, state);
    assert.equal(component.gridRenderKeys()[0], key + 1);
    assert.equal(component.tableChanged(), true);
    assert.equal(component.groupingChanged(), true);
    assert.equal(leases, 0);
  } finally {
    component.ngOnDestroy();
    root.destroy();
  }
});
