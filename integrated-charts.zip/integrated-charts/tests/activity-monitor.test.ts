import test from 'node:test';
import assert from 'node:assert/strict';
import { createWorkspaceSeed } from '../src/data/workspace-seed.js';
import { createInitialState, cards, getResource } from '../libs/charting/src/lib/core/state/workspace-state';
import type { ChartingSeed } from '../libs/charting/src/lib/core/data-access/charting-data';
import { viewCharts } from '../libs/charting/src/lib/rendering/view-charts';
import { catalogElements, defaultControls } from '../libs/dashboards/src/lib/dashboard-catalog';
import { COLUMNS } from '../libs/charting/src/lib/core/domain/schema';
import manifest from '../src/data/bundled-assets.json';

const productionState = () => createInitialState(createWorkspaceSeed() as unknown as ChartingSeed);

test('production host retains only portable activity monitor models, views and dashboards', () => {
  const state = productionState();
  assert.deepEqual(state.resources.models.map((model) => model.slug), ['activity-monitor']);
  assert.equal(state.resources.widgets.length, 3);
  assert.deepEqual(state.resources.dashboards.map((dashboard) => dashboard.name), ['Operations monitor', 'Explore failure activity', 'Failure triage']);
  assert.deepEqual(Object.keys(manifest), ['mock-data/activity-monitor.ndjson']);
  assert.deepEqual(COLUMNS, [], 'Hosts must supply schema; no implicit Accounts schema');
  for (const dashboard of state.resources.dashboards)
    for (const placement of dashboard.body.items)
      assert.ok(getResource(state, 'widgets', placement.widgetId, true, placement.widgetRevision));
});

test('dashboard thumbnail chooses a chart actually placed in the pinned dashboard', () => {
  const state = productionState();
  const triage = cards(state, 'dashboards', true).find((card) => card.name === 'Failure triage')!;
  assert.equal(triage.preview?.type, 'chart');
  assert.equal(triage.preview?.chartType, 'column');
  assert.match(triage.preview?.title ?? '', /1 min/);
  const revision = state.revisions[triage.id][1];
  revision.body.items = revision.body.items.filter((placement) => placement.chartId === 'activity-failures-by-type');
  revision.body.items[0].overrides = { chartType: 'donut', title: 'Selected types' };
  const updated = cards(state, 'dashboards', true).find((card) => card.id === triage.id)!;
  assert.equal(updated.preview?.chartType, 'donut');
  assert.equal(updated.preview?.title, 'Selected types');
});

test('chart arrays remain usable without a legacy primary chart and every advanced view offers filter controls', () => {
  const state = productionState();
  const widget = state.resources.widgets[0];
  widget.body.chart = null;
  widget.body.gridState.filter = undefined;
  assert.equal(viewCharts(widget.body).length, 3);
  assert.ok(catalogElements([widget]).some((element) => element.kind === 'filter'));
  widget.body.gridState.filter = { advancedFilterModel: { filterType: 'number', colId: 'eventCount', type: 'greaterThan', filter: 2 } };
  assert.ok(!defaultControls(widget).some((control) => control.type === 'window'), 'numeric bounds must never produce a time-window control');
});
