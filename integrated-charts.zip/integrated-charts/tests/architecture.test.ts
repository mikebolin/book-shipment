import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
/** Paths use forward slashes on every platform so prefix checks match on Windows too. */
function files(root: string): string[] {
  return fs
    .readdirSync(root, { withFileTypes: true })
    .flatMap((entry) =>
      entry.isDirectory()
        ? files(path.posix.join(root, entry.name))
        : [path.posix.join(root, entry.name)],
    );
}
test('host is only bootstrap and router composition; all implementation belongs to source libraries', () => {
  assert.deepEqual(
    files('src')
      .filter((p) => !p.startsWith('src/data/'))
      .map((p) => path.basename(p))
      .sort(),
    ['app.ts', 'index.html', 'main.ts'],
  );
  assert.match(fs.readFileSync('src/app.ts', 'utf8'), /export class AppComponent\s*\{\s*\}/);
  const config = JSON.parse(fs.readFileSync('angular.json', 'utf8'));
  assert.deepEqual(fs.readdirSync('libs').sort(), ['charting', 'dashboards', 'userPref']);
  for (const lib of ['charting', 'dashboards', 'userPref'])
    assert.equal(config.projects[lib].projectType, 'library');
  assert.ok(fs.existsSync('src/data/data.module.ts'));
});
test('no remote data transport or backend dependencies can reappear', () => {
  for (const f of files('libs').filter((f) => /\.(ts|js)$/.test(f))) {
    const text = fs.readFileSync(f, 'utf8');
    assert.ok(
      !/(?:['"`])\/api\/|HttpClient|new (?:WebSocket|EventSource)|from ['"](?:pg|express|jose|node:)/.test(
        text,
      ),
      f,
    );
  }
  const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
  for (const name of ['pg', 'express', 'express-rate-limit', 'helmet', 'jose'])
    assert.equal(pkg.dependencies[name], undefined);
  assert.equal(pkg.dependencies['@ngrx/signals'], '22.0.1');
  assert.ok(!/proxy/.test(pkg.scripts.start));
});
test('StackBlitz imports text-only runtime assets and invokes the direct Angular dev server', () => {
  const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
  assert.equal(pkg.stackblitz.startCommand, 'npm start');
  assert.equal(JSON.parse(fs.readFileSync('.stackblitzrc', 'utf8')).startCommand, 'npm start');
  for (const file of [...files('libs/charting/assets'), ...files('src/data/assets')])
    assert.ok(!/\.(?:gz|woff2|png|zip)$/.test(file), file);
  assert.ok(pkg.scripts.start.includes('--host 0.0.0.0'));
});

test('Charting has no host/sibling imports, deep library imports, or authentication', () => {
  for (const f of files('libs').filter((f) => /\.(ts|html)$/.test(f))) {
    const text = fs.readFileSync(f, 'utf8');
    assert.ok(!/@prism\/[^'"/]+\//.test(text), f + ': deep import');
    assert.ok(
      !/WorkspaceUser|WorkspaceAuth|requireUser|requireEditor|canEdit\(\)|store\.login|store\.logout|Sign out|Enter workspace/.test(
        text,
      ),
      f + ': authentication',
    );
    if (f.startsWith('libs/charting/'))
      assert.ok(
        !/from ['"][^'"]*(?:@prism|src\/data|libs\/dashboards|libs\/userPref)|import\(['"][^'"]*(?:@prism|src\/data)/.test(
          text,
        ),
        f + ': nonportable import',
      );
  }
});
