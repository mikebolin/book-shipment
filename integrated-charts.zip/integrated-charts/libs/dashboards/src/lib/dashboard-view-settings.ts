import type { GridState } from 'ag-grid-community';
import type { ColumnSpec } from '@prism/charting';
import { operators } from '@prism/charting';
import { fromModel, toModel } from '@prism/charting';
import type { Placement, ViewFilterControls, WidgetConfiguration } from '@prism/charting';
import { viewCharts } from '@prism/charting';

export type ViewOverrides = NonNullable<Placement['viewOverrides']>;
export type FilterExperience = 'inherit' | 'hidden' | 'readonly' | 'interactive' | 'values';
export interface DashboardFilterRule {
  id: string;
  columnId: string;
  operator: string;
  value: string | number;
}
export interface DashboardFilterDraft {
  mode: 'advanced' | 'columns';
  model: unknown;
  rules: DashboardFilterRule[];
}
export interface TableColumnSetting {
  id: string;
  label: string;
  kind: string;
  visible: boolean;
  sort: '' | 'asc' | 'desc';
}
const record = (value: unknown): value is Record<string, unknown> =>
  !!value && typeof value === 'object' && !Array.isArray(value);
const same = (a: unknown, b: unknown) => JSON.stringify(a) === JSON.stringify(b);

function ownFilterControls(configuration: WidgetConfiguration, targetId: string) {
  return targetId === 'grid'
    ? configuration.grid?.filterControls
    : viewCharts(configuration).find((chart) => chart.id === targetId)?.filterControls;
}

function resolvedFilterControls(configuration: WidgetConfiguration, targetId: string) {
  return (
    ownFilterControls(configuration, targetId) ??
    configuration.filterControls ?? { visible: true, parameterizable: false }
  );
}

/** Inheritance is relative to the published component, including its own reader permissions. */
export function dashboardFilterExperience(
  source: WidgetConfiguration,
  effective: WidgetConfiguration,
  targetId: string,
): FilterExperience {
  const experience = (controls: ViewFilterControls): FilterExperience =>
    !controls.visible
      ? 'hidden'
      : !controls.parameterizable
        ? 'readonly'
        : controls.editMode === 'values'
          ? 'values'
          : 'interactive';
  const current = experience(resolvedFilterControls(effective, targetId));
  return current === experience(resolvedFilterControls(source, targetId)) ? 'inherit' : current;
}

export function dashboardFilterControls(
  source: WidgetConfiguration,
  effective: WidgetConfiguration,
  targetId: string,
  experience: FilterExperience,
): ViewFilterControls | undefined {
  if (experience === 'inherit') {
    const original = ownFilterControls(source, targetId);
    return structuredClone(
      original ??
        (same(source.filterControls, effective.filterControls)
          ? undefined
          : resolvedFilterControls(source, targetId)),
    );
  }
  return {
    visible: experience !== 'hidden',
    parameterizable: experience === 'interactive' || experience === 'values',
    ...(experience === 'values' ? { editMode: 'values' } : {}),
  };
}

export function savedViewFilter(configuration: WidgetConfiguration): unknown {
  return configuration.mode === 'advanced'
    ? (configuration.gridState.filter?.advancedFilterModel ?? null)
    : (configuration.gridState.filter?.filterModel ?? {});
}

function structure(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(structure);
  if (!record(value)) return value;
  return Object.fromEntries(
    Object.entries(value).map(([key, entry]) => [
      key,
      ['filter', 'filterTo', 'dateFrom', 'dateTo', 'values'].includes(key)
        ? '<value>'
        : structure(entry),
    ]),
  );
}

function ruleFromModel(
  value: unknown,
  columns: readonly ColumnSpec[],
  index: number,
): DashboardFilterRule | null {
  if (
    !record(value) ||
    typeof value['colId'] !== 'string' ||
    typeof value['type'] !== 'string' ||
    value['conditions'] ||
    value['values']
  )
    return null;
  const column = columns.find((column) => column.id === value['colId']);
  if (!column || !operators(column).includes(value['type'] as never)) return null;
  if (value['filter'] != null && !['string', 'number'].includes(typeof value['filter']))
    return null;
  return {
    id: `saved-rule-${index}`,
    columnId: column.id,
    operator: value['type'],
    value: (value['filter'] ?? '') as string | number,
  };
}

/** Recognize only the wrapper produced here. Arbitrary nested saved logic remains an untouched expression. */
export function dashboardFilterDraft(
  source: WidgetConfiguration,
  effective: WidgetConfiguration,
  columns: readonly ColumnSpec[],
): DashboardFilterDraft {
  const model = structuredClone(savedViewFilter(effective));
  if (effective.mode !== 'advanced' || same(model, savedViewFilter(source)))
    return { mode: effective.mode, model, rules: [] };
  let sourceAdvanced: unknown;
  try {
    sourceAdvanced =
      source.mode === 'advanced'
        ? savedViewFilter(source)
        : toModel(fromModel(savedViewFilter(source), source.mode, columns), 'advanced', columns);
  } catch {
    return { mode: effective.mode, model, rules: [] };
  }
  const conditions =
    record(model) &&
    model['filterType'] === 'join' &&
    model['type'] === 'AND' &&
    Array.isArray(model['conditions'])
      ? model['conditions']
      : [model];
  const hasSource = sourceAdvanced != null;
  const tail = hasSource ? conditions.slice(1) : conditions;
  const rules = tail.map((entry, index) => ruleFromModel(entry, columns, index));
  if (
    tail.length &&
    rules.every(Boolean) &&
    (!hasSource || same(structure(conditions[0]), structure(sourceAdvanced)))
  ) {
    return {
      mode: 'advanced',
      model: hasSource ? structuredClone(conditions[0]) : null,
      rules: rules as DashboardFilterRule[],
    };
  }
  return { mode: effective.mode, model, rules: [] };
}

/** Existing expressions are preserved byte-for-byte unless additional conditions explicitly require Advanced mode. */
export function composeDashboardFilters(
  draft: DashboardFilterDraft,
  columns: readonly ColumnSpec[],
): { mode: 'advanced' | 'columns'; model: unknown } {
  fromModel(draft.model, draft.mode, columns);
  if (!draft.rules.length) return { mode: draft.mode, model: structuredClone(draft.model) };
  const base =
    draft.mode === 'advanced'
      ? structuredClone(draft.model)
      : toModel(fromModel(draft.model, draft.mode, columns), 'advanced', columns);
  const added = draft.rules.map((rule) => {
    const column = columns.find((column) => column.id === rule.columnId);
    if (!column) throw new Error('Choose a field for each added condition.');
    if (!operators(column).includes(rule.operator as never))
      throw new Error(`Choose an operator supported by ${column.label}.`);
    const blank = rule.operator === 'blank' || rule.operator === 'notBlank';
    let value: string | number = rule.value;
    if (!blank && column.kind === 'number') {
      if (value === '' || !Number.isFinite(Number(value)))
        throw new Error(`${column.label} requires a number.`);
      value = Number(value);
    }
    return {
      filterType:
        column.kind === 'date'
          ? 'dateString'
          : column.kind === 'datetime'
            ? 'dateTimeString'
            : column.kind,
      colId: column.id,
      type: rule.operator,
      ...(!blank ? { filter: value } : {}),
    };
  });
  const conditions = [...(base == null ? [] : [base]), ...added];
  const model =
    conditions.length === 1 ? conditions[0] : { filterType: 'join', type: 'AND', conditions };
  fromModel(model, 'advanced', columns);
  return { mode: 'advanced', model };
}

export function tableColumnSettings(
  configuration: WidgetConfiguration,
  columns: readonly ColumnSpec[],
): TableColumnSetting[] {
  const hidden = new Set(configuration.gridState.columnVisibility?.hiddenColIds ?? []);
  const order = configuration.gridState.columnOrder?.orderedColIds ?? [];
  const sort = configuration.gridState.sort?.sortModel ?? [];
  return columns
    .map((column, index) => ({
      column,
      index,
      rank: order.includes(column.id) ? order.indexOf(column.id) : order.length + index,
    }))
    .sort((a, b) => a.rank - b.rank)
    .map(({ column }) => ({
      id: column.id,
      label: column.label,
      kind: column.kind,
      visible: !hidden.has(column.id),
      sort: sort.find((entry) => entry.colId === column.id)?.sort ?? '',
    }));
}

/** Only the edited table blocks change. Widths, order, grouping, aggregation and pivot state survive. */
export function tableGridState(
  original: GridState,
  columns: readonly TableColumnSetting[],
  sortOrder: readonly string[],
): GridState {
  if (!columns.some((column) => column.visible))
    throw new Error('Keep at least one table column visible.');
  const state = structuredClone(original);
  const ids = new Set(columns.map((column) => column.id));
  const hidden = [
    ...(original.columnVisibility?.hiddenColIds ?? []).filter((id) => !ids.has(id)),
    ...columns.filter((column) => !column.visible).map((column) => column.id),
  ];
  const originalHidden = original.columnVisibility?.hiddenColIds ?? [];
  if (!same([...hidden].sort(), [...originalHidden].sort()))
    state.columnVisibility = { ...state.columnVisibility, hiddenColIds: hidden };
  const selected = columns.filter((column) => column.sort);
  const sorted = selected
    .map((column, index) => ({
      column,
      rank: sortOrder.includes(column.id) ? sortOrder.indexOf(column.id) : sortOrder.length + index,
    }))
    .sort((a, b) => a.rank - b.rank)
    .map(({ column }) => ({ colId: column.id, sort: column.sort as 'asc' | 'desc' }));
  const unknown = (original.sort?.sortModel ?? []).filter((entry) => !ids.has(entry.colId));
  const nextSort = [...sorted, ...unknown];
  if (!same(nextSort, original.sort?.sortModel ?? []))
    state.sort = { ...state.sort, sortModel: nextSort };
  return state;
}

export function filterState(
  state: GridState,
  mode: 'advanced' | 'columns',
  model: unknown,
): GridState {
  const next = structuredClone(state);
  next.filter =
    mode === 'advanced'
      ? {
          advancedFilterModel: structuredClone(model) as NonNullable<
            GridState['filter']
          >['advancedFilterModel'],
        }
      : { filterModel: structuredClone(model) as NonNullable<GridState['filter']>['filterModel'] };
  return next;
}

export function minimalViewOverrides(
  source: WidgetConfiguration,
  effective: WidgetConfiguration,
  experience: FilterExperience,
): ViewOverrides {
  const result: ViewOverrides = {};
  for (const key of [
    'mode',
    'grid',
    'gridState',
    'chart',
    'charts',
    'showRowNumbers',
    'filterControls',
    'serverGrid',
  ] as const) {
    if (!same(effective[key], source[key]))
      Object.assign(result, { [key]: structuredClone(effective[key]) });
  }
  if ((effective.allowDownload !== false) !== (source.allowDownload !== false))
    result.allowDownload = effective.allowDownload !== false;
  if (JSON.stringify(effective.viewLayout ?? {}) !== JSON.stringify(source.viewLayout ?? {}))
    result.viewLayout = structuredClone(effective.viewLayout ?? {});
  if ((effective.bothChartCount ?? 2) !== (source.bothChartCount ?? 2))
    result.bothChartCount = effective.bothChartCount ?? 2;
  if (experience !== 'inherit')
    result.filterControls = {
      visible: experience !== 'hidden',
      parameterizable: experience === 'interactive' || experience === 'values',
      ...(experience === 'values' ? { editMode: 'values' as const } : {}),
    };
  return result;
}
