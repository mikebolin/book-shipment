import { injectUiState } from '@prism/charting';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatTabsModule } from '@angular/material/tabs';
import { calculatedColumnSpec } from '@prism/charting';
import type { ChartPlan } from '@prism/charting';
import { placementConfiguration } from './dashboard-composer';
import { InlineViewFiltersComponent } from '@prism/charting';
import { filterParameters, parameterText } from '@prism/charting';
import { WidgetViewComponent } from '@prism/charting';
import { captureViewCharts, independentChartConfiguration, viewCharts } from '@prism/charting';
import type { DashboardDataScope } from '@prism/charting';
import type {
  ModelResource,
  Placement,
  WidgetConfiguration,
  WidgetResource,
  ViewChart,
  ViewChartDataScope,
} from '@prism/charting';
import type { GridModel } from '@prism/charting';
import {
  composeDashboardFilters,
  dashboardFilterControls,
  dashboardFilterExperience,
  filterState,
  minimalViewOverrides,
  savedViewFilter,
  type DashboardFilterDraft,
  type FilterExperience,
} from './dashboard-view-settings';

export interface DashboardViewSettingsData {
  item: Placement;
  widget: WidgetResource;
  model: ModelResource;
  sections: Placement[];
  dataScope?: DashboardDataScope;
}

@Component({
  standalone: true,
  imports: [
    FormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatCheckboxModule,
    MatTabsModule,
    WidgetViewComponent,
    InlineViewFiltersComponent,
  ],
  template: `
    <header class="settings-heading">
      <div>
        <h2 mat-dialog-title>Configure dashboard view</h2>
        <p>
          Only this dashboard <span aria-hidden="true">·</span> {{ data.widget.name }}
          <span class="revision"
            >revision {{ data.item.widgetRevision ?? data.widget.version }}</span
          >
        </p>
      </div>
      <button
        mat-icon-button
        mat-dialog-close
        aria-label="Cancel view settings"
        matTooltip="Cancel"
      >
        <mat-icon>close</mat-icon>
      </button>
    </header>
    <mat-dialog-content class="settings-content" [class.with-preview]="previewConfiguration()">
      <div class="settings-form">
        <mat-tab-group animationDuration="0ms" [preserveContent]="true">
          <mat-tab label="View"
            ><div class="tab-content">
              <div class="fields-two">
                <mat-form-field appearance="outline" subscriptSizing="dynamic"
                  ><mat-label>View title</mat-label
                  ><input matInput [(ngModel)]="title" maxlength="120"
                /></mat-form-field>
                <mat-form-field appearance="outline" subscriptSizing="dynamic"
                  ><mat-label>Presentation</mat-label
                  ><mat-select [(ngModel)]="displayMode">
                    <mat-option value="chart" [disabled]="!charts.length">Charts</mat-option
                    ><mat-option value="grid">Table</mat-option
                    ><mat-option value="both" [disabled]="!charts.length"
                      >Chart and table</mat-option
                    >
                  </mat-select></mat-form-field
                >
              </div>
              @if (displayMode === 'both') {
                <mat-form-field appearance="outline" subscriptSizing="dynamic">
                  <mat-label>Charts above table</mat-label>
                  <mat-select [(ngModel)]="effective.bothChartCount">
                    <mat-option [value]="1">One chart</mat-option>
                    <mat-option [value]="2">Two charts</mat-option>
                    <mat-option [value]="3">Three charts</mat-option>
                  </mat-select>
                </mat-form-field>
              }
              <mat-form-field appearance="outline" subscriptSizing="dynamic"
                ><mat-label>View description</mat-label
                ><textarea matInput [(ngModel)]="description" maxlength="2000" rows="2"></textarea>
              </mat-form-field>
              @if (data.sections.length) {
                <mat-form-field appearance="outline" subscriptSizing="dynamic"
                  ><mat-label>Dashboard section</mat-label
                  ><mat-select [(ngModel)]="sectionId"
                    ><mat-option value="">No section</mat-option>
                    @for (section of data.sections; track section.id) {
                      <mat-option [value]="section.id">{{ section.title }}</mat-option>
                    }
                  </mat-select></mat-form-field
                >
              }
              <mat-checkbox [(ngModel)]="effective.allowDownload"
                >Include in dashboard downloads</mat-checkbox
              >
              <p class="hint">
                The dashboard's Download all includes this view's filtered records and charts.
              </p>
              @if (charts.length) {
                <mat-checkbox [(ngModel)]="switchView"
                  >Allow viewers to switch chart and table</mat-checkbox
                >
                <p class="hint">
                  Readers can change presentation without changing the saved dashboard.
                </p>
                <mat-form-field appearance="outline" subscriptSizing="dynamic">
                  <mat-label>Configure chart</mat-label>
                  <mat-select [(ngModel)]="selectedChartId">
                    @for (chart of charts; track chart.id) {
                      <mat-option [value]="chart.id">{{ chart.plan.title }}</mat-option>
                    }
                  </mat-select>
                </mat-form-field>
                @if (selectedChart; as chart) {
                  <mat-form-field appearance="outline" subscriptSizing="dynamic">
                    <mat-label>Chart title</mat-label>
                    <input
                      matInput
                      [ngModel]="chart.plan.title"
                      (ngModelChange)="setChartTitle($event)"
                      maxlength="120"
                    />
                  </mat-form-field>
                  <mat-form-field appearance="outline" subscriptSizing="dynamic">
                    <mat-label>Chart size</mat-label>
                    <mat-select
                      [ngModel]="chart.size ?? 'standard'"
                      (ngModelChange)="setChartSize($event)"
                    >
                      <mat-option value="standard">Standard</mat-option>
                      <mat-option value="wide">Wide</mat-option>
                    </mat-select>
                  </mat-form-field>
                }
                @if (chartTypes.length > 1) {
                  <mat-form-field appearance="outline" subscriptSizing="dynamic"
                    ><mat-label>Chart type</mat-label
                    ><mat-select
                      [ngModel]="selectedChart?.plan?.type"
                      (ngModelChange)="setChartType($event)"
                    >
                      @for (type of chartTypes; track type.value) {
                        <mat-option [value]="type.value">{{ type.label }}</mat-option>
                      }
                    </mat-select></mat-form-field
                  >
                }
              } @else {
                <p class="hint">
                  This published revision contains a table. Publish a chart in Data studio to make
                  chart presentations available.
                </p>
              }
            </div></mat-tab
          >
          <mat-tab label="Filters"
            ><div class="tab-content">
              <mat-form-field appearance="outline" subscriptSizing="dynamic"
                ><mat-label>Filter experience</mat-label
                ><mat-select [(ngModel)]="filterExperience">
                  <mat-option value="inherit">Inherit published settings</mat-option
                  ><mat-option value="hidden">Hide filters</mat-option
                  ><mat-option value="readonly">Show filters (read-only)</mat-option
                  ><mat-option value="interactive">Let viewers edit expressions</mat-option>
                  <mat-option value="values">Let viewers edit values only</mat-option>
                </mat-select></mat-form-field
              >
              <p class="hint">{{ filterHint }}</p>
              <mat-form-field appearance="outline" subscriptSizing="dynamic">
                <mat-label>Filter configuration</mat-label>
                <mat-select [(ngModel)]="filterTargetId">
                  <mat-option value="grid">Table</mat-option>
                  @for (chart of charts; track chart.id) {
                    <mat-option [value]="chart.id">{{ chart.plan.title }}</mat-option>
                  }
                </mat-select>
              </mat-form-field>
              <section class="expression-card" aria-label="Existing filter expression">
                <div class="section-heading">
                  <div>
                    <strong>{{
                      filterTargetId === 'grid' ? 'Table filters' : 'Chart filters'
                    }}</strong
                    ><span>{{
                      existingParameters.length
                        ? 'Existing conditions keep their original grouping.'
                        : 'All records are included until you add a condition.'
                    }}</span>
                  </div>
                  <button
                    mat-icon-button
                    (click)="clearFilters()"
                    [disabled]="!existingParameters.length && !activeFilterDraft.rules.length"
                    aria-label="Clear dashboard filters"
                    matTooltip="Clear filters for this dashboard view"
                  >
                    <mat-icon>filter_alt_off</mat-icon>
                  </button>
                </div>
                <workspace-inline-view-filters
                  [scope]="activeFilterScope"
                  [columns]="columns"
                  access="expression"
                  [label]="filterTargetId === 'grid' ? 'Table filters' : 'Chart filters'"
                  (scopeChange)="setFilters($event)"
                />
              </section></div
          ></mat-tab>
        </mat-tab-group>
      </div>
      @if (previewConfiguration(); as configuration) {
        <aside class="view-preview" aria-label="Dashboard view preview">
          <div class="section-heading">
            <div><strong>Preview</strong><span>Refresh to see your latest changes.</span></div>
            <button
              mat-icon-button
              (click)="preview()"
              aria-label="Refresh view preview"
              matTooltip="Refresh preview"
            >
              <mat-icon>refresh</mat-icon></button
            ><button
              mat-icon-button
              (click)="closePreview()"
              aria-label="Close view preview"
              matTooltip="Close preview"
            >
              <mat-icon>close</mat-icon>
            </button>
          </div>
          <div class="preview-canvas">
            <workspace-widget-view
              [model]="data.model"
              [configuration]="configuration"
              [displayMode]="previewMode"
              [dataScope]="data.dataScope"
            />
          </div>
        </aside>
      }
    </mat-dialog-content>
    @if (error()) {
      <p class="settings-error" role="alert">{{ error() }}</p>
    }
    <mat-dialog-actions class="settings-actions"
      ><button
        mat-icon-button
        (click)="reset()"
        aria-label="Reset to published settings"
        matTooltip="Reset this view to its published settings"
      >
        <mat-icon>restart_alt</mat-icon></button
      ><span>Changes apply only to this dashboard.</span
      ><button mat-button (click)="preview()" aria-label="Preview view" matTooltip="Preview view">
        <mat-icon>visibility</mat-icon>Preview</button
      ><button
        mat-button
        class="apply-action"
        (click)="apply()"
        aria-label="Apply view settings"
        matTooltip="Apply view settings"
      >
        Apply settings
      </button></mat-dialog-actions
    >
  `,
  styles: [
    `
      :host {
        display: flex;
        flex-direction: column;
        min-width: 0;
        max-height: 90dvh;
        color: var(--ws-ink);
        --mat-form-field-container-height: 42px;
        --mat-form-field-container-vertical-padding: 9px;
        --mdc-icon-button-state-layer-size: 34px;
        --mdc-icon-button-icon-size: 19px;
      }
      .settings-heading {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 18px 22px 8px;
      }
      .settings-heading > div {
        min-width: 0;
        flex: 1;
      }
      .settings-heading h2 {
        font-size: 19px;
        line-height: 26px;
        padding: 0;
        margin: 0;
      }
      .settings-heading h2::before {
        display: none;
      }
      .settings-heading p {
        margin: 4px 0 0;
        color: var(--ws-muted);
        font-size: 11px;
        overflow-wrap: anywhere;
      }
      .revision {
        white-space: nowrap;
        margin-left: 5px;
      }
      button[mat-icon-button] {
        width: 34px;
        height: 34px;
        padding: 7px;
        flex-shrink: 0;
      }
      button[mat-icon-button] mat-icon {
        font-size: 19px;
        height: 19px;
        width: 19px;
        flex-shrink: 0;
      }
      .settings-content {
        padding: 0 22px !important;
        max-height: calc(90dvh - 140px);
        min-height: 320px;
        display: grid;
        grid-template-columns: minmax(0, 1fr);
        gap: 18px;
      }
      .settings-form {
        min-width: 0;
      }
      .tab-content {
        display: flex;
        flex-direction: column;
        gap: 14px;
        padding: 18px 0 8px;
      }
      mat-form-field {
        width: 100%;
        min-width: 0;
        font-size: 13px;
      }
      .fields-two {
        display: grid;
        grid-template-columns: minmax(0, 1.3fr) minmax(0, 1fr);
        gap: 12px;
      }
      textarea {
        resize: vertical;
      }
      .hint {
        font-size: 12px;
        line-height: 1.5;
        color: var(--ws-muted);
        margin: -5px 0 0;
      }
      .section-heading {
        display: flex;
        gap: 5px;
        align-items: center;
        min-width: 0;
      }
      .section-heading > div {
        flex: 1;
        min-width: 0;
      }
      .section-heading strong {
        display: block;
        font-size: 12px;
        font-weight: 600;
      }
      .section-heading span {
        display: block;
        font-size: 11px;
        line-height: 1.4;
        color: var(--ws-muted);
        margin-top: 3px;
      }
      .expression-card {
        padding: 10px 12px;
        border: 1px solid var(--ws-border);
        border-radius: 10px;
        background: var(--mat-sys-surface-container-low);
      }
      .predicate-list {
        display: flex;
        gap: 6px;
        flex-wrap: wrap;
        margin-top: 10px;
      }
      .predicate-list > span {
        font-size: 11px;
        line-height: 1.5;
        color: var(--ws-muted);
        padding: 4px 7px;
        border: 1px solid var(--ws-border);
        border-radius: 5px;
        overflow-wrap: anywhere;
      }
      .predicate-list b {
        font-weight: 500;
        color: var(--ws-ink);
      }
      .dashboard-filter-rule {
        display: grid;
        grid-template-columns: minmax(0, 1.2fr) minmax(0, 1fr) minmax(0, 1fr) 34px;
        gap: 8px;
        align-items: center;
      }
      .no-value {
        font-size: 11px;
        color: var(--ws-muted);
      }
      .table-controls {
        display: flex;
        gap: 14px;
        align-items: center;
      }
      .table-controls mat-form-field {
        flex: 1;
      }
      .table-controls mat-checkbox {
        white-space: nowrap;
        font-size: 12px;
      }
      .column-list {
        border: 1px solid var(--ws-border);
        border-radius: 9px;
        overflow: hidden;
      }
      .column-setting {
        display: flex;
        align-items: center;
        gap: 7px;
        min-height: 52px;
        padding: 5px 10px;
        border-bottom: 1px solid var(--ws-border);
      }
      .column-setting:last-child {
        border: 0;
      }
      .column-setting mat-checkbox {
        flex: 1;
        min-width: 0;
        font-size: 12px;
      }
      .column-setting mat-checkbox span {
        overflow-wrap: anywhere;
      }
      .column-kind {
        color: var(--ws-muted);
        font-size: 10px;
      }
      .column-setting mat-form-field {
        width: 146px;
        flex-shrink: 0;
        font-size: 11px;
      }
      .sort-rank {
        height: 19px;
        width: 19px;
        border-radius: 50%;
        display: grid;
        place-items: center;
        background: var(--mat-sys-secondary-container);
        color: var(--mat-sys-on-secondary-container);
        font-size: 10px;
      }
      .more-columns {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 6px;
        font-size: 11px;
        color: var(--ws-muted);
      }
      .view-preview {
        min-width: 0;
        margin-top: 16px;
        border: 1px solid var(--ws-border);
        border-radius: 10px;
        overflow: hidden;
        align-self: start;
      }
      .view-preview > .section-heading {
        padding: 9px 10px;
        border-bottom: 1px solid var(--ws-border);
      }
      .preview-canvas {
        height: 420px;
        min-width: 0;
        padding: 6px;
      }
      .preview-canvas workspace-widget-view {
        height: 100%;
        display: block;
      }
      .settings-actions {
        display: flex;
        gap: 7px;
        padding: 10px 18px !important;
        border-top: 1px solid var(--ws-border);
        min-height: 56px;
      }
      .settings-actions > span {
        flex: 1;
        font-size: 11px;
        color: var(--ws-muted);
      }
      .settings-error {
        font-size: 12px;
        color: var(--mat-sys-error);
        margin: 6px 22px 10px;
        line-height: 1.5;
      }
      @media (min-width: 1000px) {
        .settings-content.with-preview {
          grid-template-columns: minmax(0, 1.1fr) minmax(0, 1fr);
        }
      }
      @media (max-width: 600px) {
        .settings-heading {
          padding: 14px 14px 6px;
        }
        .settings-heading h2 {
          font-size: 17px;
        }
        .settings-content {
          padding: 0 14px !important;
          max-height: calc(90dvh - 140px);
        }
        .fields-two {
          grid-template-columns: 1fr;
          gap: 14px;
        }
        .dashboard-filter-rule {
          grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) 34px;
          padding-bottom: 12px;
          border-bottom: 1px solid var(--ws-border);
        }
        .dashboard-filter-rule mat-form-field:first-child {
          grid-column: 1/4;
        }
        .table-controls {
          align-items: stretch;
          flex-direction: column;
          gap: 4px;
        }
        .column-kind {
          display: none;
        }
        .column-setting {
          padding: 5px;
        }
        .column-setting mat-form-field {
          width: 118px;
        }
        .settings-actions {
          padding: 8px 10px !important;
        }
        .settings-actions > span {
          max-width: 170px;
          font-size: 10px;
        }
        button[mat-icon-button] {
          width: 40px;
          height: 40px;
          padding: 10px;
        }
        .dashboard-filter-rule > button {
          width: 34px;
          padding: 7px;
        }
        .preview-canvas {
          height: 380px;
        }
      }
    `,
  ],
})
export class DashboardViewSettingsComponent {
  private readonly reactiveState = injectUiState('DashboardViewSettingsComponent');

  readonly data = inject<DashboardViewSettingsData>(MAT_DIALOG_DATA);
  private readonly ref = inject(MatDialogRef<DashboardViewSettingsComponent, Placement>);
  readonly source = structuredClone(this.data.widget.body);
  readonly columns = [
    ...this.data.model.body.columns,
    ...this.source.calculatedColumns.map((column) =>
      calculatedColumnSpec(column, this.data.model.body.columns),
    ),
  ];
  effective = placementConfiguration(this.source, undefined, this.data.item.viewOverrides);
  filterDraft!: DashboardFilterDraft;
  chartFilterDrafts: Record<string, DashboardFilterDraft> = {};
  private readonly filterTargetIdState = this.reactiveState.signal('grid');
  get filterTargetId() {
    return this.filterTargetIdState();
  }
  set filterTargetId(value) {
    this.filterTargetIdState.set(value);
  }
  private readonly selectedChartIdState = this.reactiveState.signal('');
  get selectedChartId() {
    return this.selectedChartIdState();
  }
  set selectedChartId(value) {
    this.selectedChartIdState.set(value);
  }
  private readonly titleState = this.reactiveState.signal(
    this.data.item.title ?? this.data.widget.name,
  );
  get title() {
    return this.titleState();
  }
  set title(value) {
    this.titleState.set(value);
  }
  private readonly descriptionState = this.reactiveState.signal(this.data.item.description ?? '');
  get description() {
    return this.descriptionState();
  }
  set description(value) {
    this.descriptionState.set(value);
  }
  private readonly sectionIdState = this.reactiveState.signal(this.data.item.sectionId ?? '');
  get sectionId() {
    return this.sectionIdState();
  }
  set sectionId(value) {
    this.sectionIdState.set(value);
  }
  private readonly displayModeState = this.reactiveState.signal<'grid' | 'chart' | 'both'>(
    this.data.item.displayMode ??
      this.effective.displayMode ??
      (this.effective.chart ? 'chart' : 'grid'),
  );
  get displayMode() {
    return this.displayModeState();
  }
  set displayMode(value) {
    this.displayModeState.set(value);
  }
  private readonly switchViewState = this.reactiveState.signal(
    this.data.item.interactions?.switchView ?? true,
  );
  get switchView() {
    return this.switchViewState();
  }
  set switchView(value) {
    this.switchViewState.set(value);
  }
  readonly error = this.reactiveState.signal('');
  readonly previewConfiguration = this.reactiveState.signal<WidgetConfiguration | null>(null);
  private readonly previewModeState = this.reactiveState.signal<'grid' | 'chart' | 'both'>(
    this.displayMode,
  );
  get previewMode() {
    return this.previewModeState();
  }
  set previewMode(value) {
    this.previewModeState.set(value);
  }
  readonly describeParameter = parameterText;
  constructor() {
    this.loadConfiguration(this.effective);
  }
  private loadConfiguration(configuration: WidgetConfiguration) {
    this.effective = independentChartConfiguration(configuration);
    this.effective.allowDownload ??= true;
    this.effective.bothChartCount ??= 2;
    this.filterDraft = {
      mode: this.effective.mode,
      model: structuredClone(savedViewFilter(this.effective)),
      rules: [],
    };
    this.chartFilterDrafts = Object.fromEntries(
      this.charts.map((chart) => [
        chart.id,
        {
          mode: chart.dataScope!.mode,
          model: structuredClone(chart.dataScope!.filterModel),
          rules: [],
        },
      ]),
    );
    this.selectedChartId = this.effective.chart?.id ?? '';
    this.filterTargetId = 'grid';
  }
  get charts() {
    return viewCharts(this.effective);
  }
  get selectedChart() {
    return this.charts.find((chart) => chart.id === this.selectedChartId);
  }
  private updateChart(id: string, update: (chart: ViewChart) => ViewChart) {
    const charts = captureViewCharts(
      this.charts.map((chart) => (chart.id === id ? update(chart) : chart)),
    );
    this.effective = {
      ...this.effective,
      charts,
      chart: charts.find((chart) => chart.id === this.effective.chart?.id) ?? charts[0] ?? null,
    };
  }
  setChartTitle(title: string) {
    this.updateChart(this.selectedChartId, (chart) => ({
      ...chart,
      plan: { ...chart.plan, title },
      presentation: null,
    }));
  }
  setChartType(type: ChartPlan['type']) {
    this.updateChart(this.selectedChartId, (chart) => ({
      ...chart,
      plan: { ...chart.plan, type },
      presentation: null,
    }));
  }
  setChartSize(size: ViewChart['size']) {
    this.updateChart(this.selectedChartId, (chart) => ({ ...chart, size }));
  }
  get activeFilterDraft(): DashboardFilterDraft {
    return this.chartFilterDrafts[this.filterTargetId] ?? this.filterDraft;
  }
  get activeFilterScope(): ViewChartDataScope {
    const draft = this.activeFilterDraft;
    return { mode: draft.mode, filterModel: draft.model as GridModel };
  }
  get filterExperience(): FilterExperience {
    return dashboardFilterExperience(this.source, this.effective, this.filterTargetId);
  }
  set filterExperience(value: FilterExperience) {
    const controls = dashboardFilterControls(
      this.source,
      this.effective,
      this.filterTargetId,
      value,
    );
    if (this.filterTargetId === 'grid') {
      this.effective.grid = {
        id: this.effective.grid?.id ?? crypto.randomUUID(),
        ...(controls ? { filterControls: controls } : {}),
      };
    } else
      this.updateChart(this.filterTargetId, (chart) => {
        const next = { ...chart };
        if (controls) next.filterControls = controls;
        else delete next.filterControls;
        return next;
      });
  }
  setFilters(scope: ViewChartDataScope) {
    const draft: DashboardFilterDraft = {
      mode: scope.mode,
      model: structuredClone(scope.filterModel),
      rules: [],
    };
    if (this.filterTargetId === 'grid') this.filterDraft = draft;
    else this.chartFilterDrafts = { ...this.chartFilterDrafts, [this.filterTargetId]: draft };
    this.error.set('');
  }
  get existingParameters() {
    return filterParameters(
      this.activeFilterDraft.model,
      this.activeFilterDraft.mode,
      this.columns,
    );
  }
  get filterHint() {
    const mode = this.filterExperience;
    return mode === 'hidden'
      ? 'Saved conditions still apply; filter controls are hidden from readers.'
      : mode === 'readonly'
        ? 'Readers can inspect the saved conditions without changing their values.'
        : mode === 'interactive'
          ? 'Readers can edit this component’s expression inline. Other chart and table filters stay unchanged.'
          : mode === 'values'
            ? 'Readers can change comparison values. Fields, operators and expression grouping stay fixed.'
            : 'Uses the view’s saved filter visibility and interaction settings.';
  }
  get chartTypes(): { value: ChartPlan['type']; label: string }[] {
    const type = this.selectedChart?.plan.type;
    if (!type) return [];
    const simple: ChartPlan['type'][] = [
      'bar',
      'groupedBar',
      'stackedBar',
      'normalizedBar',
      'column',
      'groupedColumn',
      'stackedColumn',
      'normalizedColumn',
      'line',
      'stackedLine',
      'normalizedLine',
      'area',
      'stackedArea',
      'normalizedArea',
    ];
    const choices: ChartPlan['type'][] =
      simple.includes(type) && this.selectedChart?.plan.categoryColumnId
        ? [type, 'bar', 'column', 'line', 'area']
        : type === 'pie' || type === 'donut'
          ? [type, 'pie', 'donut']
          : [type];
    return [...new Set(choices)].map((value) => ({
      value,
      label:
        value[0].toUpperCase() +
        value
          .slice(1)
          .replace(/([a-z])([A-Z])/g, '$1 $2')
          .toLowerCase(),
    }));
  }
  clearFilters() {
    this.setFilters({
      mode: this.activeFilterDraft.mode,
      filterModel: this.activeFilterDraft.mode === 'advanced' ? null : {},
    });
  }
  private configuration(): WidgetConfiguration {
    const filters = composeDashboardFilters(this.filterDraft, this.columns);
    let gridState = structuredClone(this.effective.gridState);
    if (
      filters.mode !== this.effective.mode ||
      JSON.stringify(filters.model) !== JSON.stringify(savedViewFilter(this.effective))
    )
      gridState = filterState(gridState, filters.mode, filters.model);
    const configuration: WidgetConfiguration = {
      ...structuredClone(this.effective),
      mode: filters.mode,
      gridState,
    };
    configuration.charts = captureViewCharts(
      this.charts.map((chart) => {
        const filters = composeDashboardFilters(this.chartFilterDrafts[chart.id], this.columns);
        if (!chart.plan.title.trim() || chart.plan.title.length > 120)
          throw new Error('Give each chart a title of 1 to 120 characters.');
        return {
          ...chart,
          dataScope: { mode: filters.mode, filterModel: filters.model as GridModel },
        };
      }),
    );
    configuration.chart =
      configuration.charts.find((chart) => chart.id === this.effective.chart?.id) ??
      configuration.charts[0] ??
      null;
    if (this.displayMode !== 'grid' && !configuration.chart)
      throw new Error('This published revision has no chart. Choose the table presentation.');
    if (this.title.trim().length > 120 || this.description.trim().length > 2000)
      throw new Error('Shorten the title or description before applying.');
    return configuration;
  }
  preview() {
    try {
      const configuration = this.configuration();
      this.previewMode = this.displayMode;
      this.previewConfiguration.set(placementConfiguration(configuration, this.title));
      this.ref.updateSize('1040px');
      this.error.set('');
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : 'Check the view settings.');
    }
  }
  closePreview() {
    this.previewConfiguration.set(null);
    this.ref.updateSize('680px');
  }
  reset() {
    this.loadConfiguration(this.source);
    this.title = this.data.widget.name;
    this.description = '';
    this.displayMode = this.source.displayMode ?? (this.source.chart ? 'chart' : 'grid');
    this.switchView = true;
    this.closePreview();
    this.error.set('');
  }
  apply() {
    try {
      const configuration = this.configuration();
      const overrides = minimalViewOverrides(this.source, configuration, 'inherit');
      const item = structuredClone(this.data.item);
      const title = this.title.trim(),
        description = this.description.trim();
      if (title && title !== this.data.widget.name) item.title = title;
      else delete item.title;
      if (description) item.description = description;
      else delete item.description;
      if (this.sectionId) item.sectionId = this.sectionId;
      else delete item.sectionId;
      item.displayMode = this.displayMode;
      if (Object.keys(overrides).length) item.viewOverrides = overrides;
      else delete item.viewOverrides;
      if (!this.switchView) item.interactions = { switchView: false };
      else delete item.interactions;
      this.ref.close(item);
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : 'Check the view settings.');
    }
  }
}
