import type { RichTextDocument, RichTextMark, RichTextNode, Tone } from '@prism/charting';

/**
 * Structured rich text for dashboards: a ProseMirror-style JSON document restricted to an explicit
 * node, mark and attribute allow-list. The server validates the same schema (RichTextValidation.java),
 * so documents are rendered from JSON and never from author-supplied markup.
 */
export const RICH_TEXT_MAX_BYTES = 200 * 1024;
export const RICH_TEXT_MAX_DEPTH = 12;
export const TONES: readonly Tone[] = ['neutral', 'info', 'success', 'warning'];
export const RICH_TEXT_NODE_TYPES = [
  'doc',
  'paragraph',
  'heading',
  'bulletList',
  'orderedList',
  'listItem',
  'taskList',
  'taskItem',
  'blockquote',
  'codeBlock',
  'horizontalRule',
  'hardBreak',
  'table',
  'tableRow',
  'tableHeader',
  'tableCell',
  'image',
  'callout',
  'text',
] as const;
export const RICH_TEXT_MARK_TYPES = [
  'bold',
  'italic',
  'underline',
  'strike',
  'code',
  'link',
  'highlight',
] as const;

type Content = 'block' | 'inline' | 'listItem' | 'taskItem' | 'tableRow' | 'cell' | 'text' | 'none';
type AttrCheck = (value: unknown) => boolean;
interface NodeSpec {
  content: Content;
  /** Attribute names with their value checks; a missing optional attribute is fine, an unknown one is not. */
  attrs?: Record<string, AttrCheck>;
  required?: string[];
  /** Nodes that can only appear in inline positions. */
  inline?: boolean;
}
const isInt = (value: unknown, min: number, max: number) =>
  typeof value === 'number' && Number.isInteger(value) && value >= min && value <= max;
const isText = (value: unknown, max: number) =>
  typeof value === 'string' &&
  value.length <= max &&
  !/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(value);
const nullable =
  (check: AttrCheck): AttrCheck =>
  (value) =>
    value === null || value === undefined || check(value);
export function safeRichTextUrl(value: unknown, kind: 'link' | 'image'): boolean {
  if (typeof value !== 'string' || value.length > 2048 || /[\s\\]/.test(value)) return false;
  if (kind === 'image' && /^\/assets\/(?!\/)/.test(value))
    return !/%(?:2f|5c|0[ad])/i.test(value) && !value.includes('..');
  if (kind === 'link' && /^mailto:[^\s/?#@]+@[^\s/?#]+$/i.test(value)) return true;
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && !!url.hostname && !url.username && !url.password;
  } catch {
    return false;
  }
}
const NODES: Record<string, NodeSpec> = {
  doc: { content: 'block' },
  paragraph: { content: 'inline' },
  heading: { content: 'inline', attrs: { level: (v) => isInt(v, 1, 4) }, required: ['level'] },
  bulletList: { content: 'listItem' },
  orderedList: {
    content: 'listItem',
    attrs: {
      start: nullable((v) => isInt(v, 1, 1_000_000)),
      type: nullable((v) => typeof v === 'string' && /^[1aAiI]$/.test(v)),
    },
  },
  listItem: { content: 'block' },
  taskList: { content: 'taskItem' },
  taskItem: { content: 'block', attrs: { checked: nullable((v) => typeof v === 'boolean') } },
  blockquote: { content: 'block' },
  codeBlock: {
    content: 'text',
    attrs: { language: nullable((v) => isText(v, 40) && /^[a-z0-9+#.-]*$/i.test(v as string)) },
  },
  horizontalRule: { content: 'none' },
  hardBreak: { content: 'none', inline: true },
  table: { content: 'tableRow' },
  tableRow: { content: 'cell' },
  tableHeader: {
    content: 'block',
    attrs: {
      colspan: nullable((v) => isInt(v, 1, 20)),
      rowspan: nullable((v) => isInt(v, 1, 20)),
      colwidth: nullable(
        (v) => Array.isArray(v) && v.length <= 20 && v.every((n) => isInt(n, 1, 4000)),
      ),
    },
  },
  tableCell: {
    content: 'block',
    attrs: {
      colspan: nullable((v) => isInt(v, 1, 20)),
      rowspan: nullable((v) => isInt(v, 1, 20)),
      colwidth: nullable(
        (v) => Array.isArray(v) && v.length <= 20 && v.every((n) => isInt(n, 1, 4000)),
      ),
    },
  },
  image: {
    content: 'none',
    attrs: {
      src: (v) => safeRichTextUrl(v, 'image'),
      alt: nullable((v) => isText(v, 500)),
      title: nullable((v) => isText(v, 200)),
    },
    required: ['src'],
  },
  callout: {
    content: 'block',
    attrs: { tone: (v) => TONES.includes(v as Tone) },
    required: ['tone'],
  },
  text: { content: 'none', inline: true },
};
const MARKS: Record<string, { attrs?: Record<string, AttrCheck>; required?: string[] }> = {
  bold: {},
  italic: {},
  underline: {},
  strike: {},
  code: {},
  highlight: {
    attrs: { color: nullable((v) => typeof v === 'string' && /^#[0-9a-f]{6}$/i.test(v)) },
  },
  link: {
    attrs: {
      href: (v) => safeRichTextUrl(v, 'link'),
      target: nullable((v) => v === '_blank'),
      rel: nullable((v) => isText(v, 100) && /^[a-z -]*$/i.test(v as string)),
      class: nullable(() => false),
    },
    required: ['href'],
  },
};
const CONTENT_RULES: Record<Content, (type: string) => boolean> = {
  block: (type) =>
    !NODES[type]?.inline &&
    type !== 'doc' &&
    !['listItem', 'taskItem', 'tableRow', 'tableHeader', 'tableCell'].includes(type),
  inline: (type) => type === 'text' || type === 'hardBreak' || type === 'image',
  listItem: (type) => type === 'listItem',
  taskItem: (type) => type === 'taskItem',
  tableRow: (type) => type === 'tableRow',
  cell: (type) => type === 'tableHeader' || type === 'tableCell',
  text: (type) => type === 'text',
  none: () => false,
};
const record = (value: unknown): value is Record<string, unknown> =>
  !!value && typeof value === 'object' && !Array.isArray(value);

/** Returns a human-readable problem, or null when the document matches the schema. */
export function richTextProblem(document: unknown): string | null {
  if (!record(document) || document['type'] !== 'doc') return 'Rich text must be a document.';
  const bytes = new TextEncoder().encode(JSON.stringify(document)).length;
  if (bytes > RICH_TEXT_MAX_BYTES) return 'Rich text exceeds 200 KiB.';
  return nodeProblem(document, 0, 'block');
}
function nodeProblem(value: unknown, depth: number, position: Content): string | null {
  if (depth > RICH_TEXT_MAX_DEPTH) return 'Rich text is nested too deeply.';
  if (!record(value) || typeof value['type'] !== 'string') return 'Rich text nodes require a type.';
  const type = value['type'];
  const spec = NODES[type];
  if (!spec) return `Unsupported rich text node: ${type}.`;
  if (depth > 0 && !CONTENT_RULES[position](type)) return `A ${type} node cannot appear here.`;
  for (const key of Object.keys(value))
    if (!['type', 'attrs', 'content', 'marks', 'text'].includes(key))
      return `Unsupported rich text field: ${key}.`;
  const attrs = value['attrs'];
  if (attrs !== undefined) {
    if (!record(attrs)) return `${type} attributes must be an object.`;
    for (const [key, attr] of Object.entries(attrs)) {
      const check = spec.attrs?.[key];
      if (!check) return `Unsupported ${type} attribute: ${key}.`;
      if (!check(attr)) return `Invalid ${type} attribute: ${key}.`;
    }
  }
  for (const key of spec.required ?? [])
    if (!record(attrs) || attrs[key] === undefined || attrs[key] === null)
      return `${type} requires ${key}.`;
  if (type === 'text') {
    if (typeof value['text'] !== 'string' || !value['text'].length)
      return 'Text nodes require text.';
    if (!isText(value['text'], 100_000)) return 'Text contains unsupported control characters.';
    if (value['content'] !== undefined) return 'Text nodes cannot contain nodes.';
    const marks = value['marks'];
    if (marks !== undefined) {
      if (!Array.isArray(marks)) return 'Marks must be an array.';
      const seen = new Set<string>();
      for (const mark of marks) {
        const problem = markProblem(mark);
        if (problem) return problem;
        if (seen.has((mark as RichTextMark).type)) return 'Marks must be unique per text node.';
        seen.add((mark as RichTextMark).type);
      }
      if (position === 'text' && marks.length) return 'Code blocks cannot contain marks.';
    }
    return null;
  }
  if (value['text'] !== undefined) return `${type} nodes cannot carry text.`;
  if (value['marks'] !== undefined) return `${type} nodes cannot carry marks.`;
  const content = value['content'];
  if (content === undefined) return null;
  if (!Array.isArray(content)) return `${type} content must be an array.`;
  if (spec.content === 'none' && content.length) return `${type} nodes cannot contain nodes.`;
  if (content.length > 5000) return 'Rich text contains too many nodes.';
  for (const child of content) {
    const problem = nodeProblem(child, depth + 1, spec.content);
    if (problem) return problem;
  }
  return null;
}
function markProblem(value: unknown): string | null {
  if (!record(value) || typeof value['type'] !== 'string') return 'Marks require a type.';
  const spec = MARKS[value['type']];
  if (!spec) return `Unsupported rich text mark: ${value['type']}.`;
  for (const key of Object.keys(value))
    if (key !== 'type' && key !== 'attrs') return `Unsupported mark field: ${key}.`;
  const attrs = value['attrs'];
  if (attrs !== undefined) {
    if (!record(attrs)) return `${value['type']} attributes must be an object.`;
    for (const [key, attr] of Object.entries(attrs)) {
      const check = spec.attrs?.[key];
      if (!check) return `Unsupported ${value['type']} attribute: ${key}.`;
      if (!check(attr)) return `Invalid ${value['type']} attribute: ${key}.`;
    }
  }
  for (const key of spec.required ?? [])
    if (!record(attrs) || attrs[key] === undefined || attrs[key] === null)
      return `${value['type']} requires ${key}.`;
  return null;
}

export function emptyRichText(): RichTextDocument {
  return { type: 'doc', content: [{ type: 'paragraph' }] };
}
/** One paragraph per line; blank lines become empty paragraphs so spacing survives. */
export function richTextFromPlainText(text: string): RichTextDocument {
  const lines = text.replace(/\r\n?/g, '\n').split('\n');
  const content: RichTextNode[] = lines.map((line) =>
    line.length
      ? { type: 'paragraph', content: [{ type: 'text', text: line }] }
      : { type: 'paragraph' },
  );
  return { type: 'doc', content: content.length ? content : [{ type: 'paragraph' }] };
}
export function richTextToPlainText(document: RichTextNode | null | undefined): string {
  if (!document) return '';
  const blocks: string[] = [];
  const walk = (node: RichTextNode, into: string[]) => {
    if (node.type === 'text') into.push(node.text ?? '');
    else if (node.type === 'hardBreak') into.push('\n');
    else if (node.type === 'image') into.push(String(node.attrs?.['alt'] ?? ''));
    else {
      const parts: string[] = [];
      for (const child of node.content ?? []) walk(child, parts);
      const inline =
        node.type === 'paragraph' || node.type === 'heading' || node.type === 'codeBlock';
      if (inline) blocks.push(parts.join(''));
      else if (parts.length) into.push(...parts);
    }
  };
  walk(document, []);
  return blocks.join('\n').trim();
}
export function richTextIsEmpty(document: RichTextNode | null | undefined): boolean {
  return (
    !richTextToPlainText(document) &&
    !findNode(document, (node) => node.type === 'image' || node.type === 'table')
  );
}
function findNode(
  node: RichTextNode | null | undefined,
  predicate: (node: RichTextNode) => boolean,
): boolean {
  if (!node) return false;
  if (predicate(node)) return true;
  return (node.content ?? []).some((child) => findNode(child, predicate));
}

const escape = (value: string) =>
  value.replace(
    /[&<>"']/g,
    (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!,
  );
const MARK_TAGS: Record<RichTextMark['type'], string> = {
  bold: 'strong',
  italic: 'em',
  underline: 'u',
  strike: 's',
  code: 'code',
  highlight: 'mark',
  link: 'a',
};
/**
 * Renders a validated document as HTML built only from this allow-list; the result is still passed
 * through Angular's sanitizer when bound. Invalid documents render as plain text.
 */
export function richTextToHtml(document: RichTextNode | null | undefined): string {
  if (!document) return '';
  if (richTextProblem(document)) return `<p>${escape(richTextToPlainText(document))}</p>`;
  return (document.content ?? []).map(renderNode).join('');
}
function renderNode(node: RichTextNode): string {
  const children = () => (node.content ?? []).map(renderNode).join('');
  const attrs = node.attrs ?? {};
  switch (node.type) {
    case 'text':
      return renderMarks(escape(node.text ?? ''), node.marks ?? []);
    case 'paragraph':
      return `<p>${children() || '<br>'}</p>`;
    case 'heading': {
      const level = Math.min(4, Math.max(1, Number(attrs['level']) || 1));
      return `<h${level}>${children()}</h${level}>`;
    }
    case 'bulletList':
      return `<ul>${children()}</ul>`;
    case 'orderedList': {
      const start = Number(attrs['start']);
      return `<ol${Number.isInteger(start) && start > 1 ? ` start="${start}"` : ''}>${children()}</ol>`;
    }
    case 'listItem':
      return `<li>${children()}</li>`;
    case 'taskList':
      return `<ul class="rt-task-list">${children()}</ul>`;
    case 'taskItem':
      return `<li class="rt-task-item" data-checked="${attrs['checked'] === true}"><span class="rt-task-box" aria-hidden="true">${
        attrs['checked'] === true ? '&#10003;' : ''
      }</span><div>${children()}</div></li>`;
    case 'blockquote':
      return `<blockquote>${children()}</blockquote>`;
    case 'codeBlock':
      return `<pre><code>${(node.content ?? []).map((child) => escape(child.text ?? '')).join('')}</code></pre>`;
    case 'horizontalRule':
      return '<hr>';
    case 'hardBreak':
      return '<br>';
    case 'table':
      return `<div class="rt-table"><table>${children()}</table></div>`;
    case 'tableRow':
      return `<tr>${children()}</tr>`;
    case 'tableHeader':
    case 'tableCell': {
      const tag = node.type === 'tableHeader' ? 'th' : 'td';
      const span = (key: string) => {
        const value = Number(attrs[key]);
        return Number.isInteger(value) && value > 1 ? ` ${key}="${value}"` : '';
      };
      return `<${tag}${span('colspan')}${span('rowspan')}>${children()}</${tag}>`;
    }
    case 'image': {
      const src = attrs['src'];
      if (!safeRichTextUrl(src, 'image')) return '';
      const title = typeof attrs['title'] === 'string' ? ` title="${escape(attrs['title'])}"` : '';
      return `<img src="${escape(String(src))}" alt="${escape(String(attrs['alt'] ?? ''))}"${title} loading="lazy" decoding="async" referrerpolicy="no-referrer">`;
    }
    case 'callout':
      return `<div class="rt-callout tone-${TONES.includes(attrs['tone'] as Tone) ? attrs['tone'] : 'neutral'}">${children()}</div>`;
    default:
      return '';
  }
}
function renderMarks(text: string, marks: RichTextMark[]): string {
  let html = text;
  for (const mark of [...marks].reverse()) {
    const tag = MARK_TAGS[mark.type];
    if (!tag) continue;
    if (mark.type === 'link') {
      const href = mark.attrs?.['href'];
      if (!safeRichTextUrl(href, 'link')) continue;
      html = `<a href="${escape(String(href))}" target="_blank" rel="noopener noreferrer nofollow">${html}</a>`;
    } else html = `<${tag}>${html}</${tag}>`;
  }
  return html;
}
