import { injectUiState } from '@prism/charting';
import { ChangeDetectionStrategy, Component, Input, computed } from '@angular/core';
import type { RichTextDocument, Tone } from '@prism/charting';
import { richTextToHtml } from './rich-text';

/**
 * Renders a schema-validated rich text document. The HTML comes from `richTextToHtml` (an
 * allow-listed JSON renderer) and still passes through Angular's sanitizer on binding, so no
 * author-supplied markup ever reaches the DOM.
 */
@Component({
  selector: 'workspace-rich-text',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { '[class]': "'dashboard-prose rich-text tone-' + (tone || 'neutral')" },
  template: `<div class="rich-text-body" [innerHTML]="html()"></div>`,
  styles: `
    :host {
      display: block;
      min-height: 0;
      overflow: auto;
      font-size: 13px;
      line-height: 1.6;
      color: var(--ws-ink);
    }
    .rich-text-body > :first-child {
      margin-top: 0;
    }
    .rich-text-body > :last-child {
      margin-bottom: 0;
    }
    .rich-text-body ::ng-deep h1,
    .rich-text-body ::ng-deep h2,
    .rich-text-body ::ng-deep h3,
    .rich-text-body ::ng-deep h4 {
      margin: 14px 0 6px;
      line-height: 1.3;
      letter-spacing: -0.2px;
      font-weight: 600;
    }
    .rich-text-body ::ng-deep h1 {
      font-size: 20px;
    }
    .rich-text-body ::ng-deep h2 {
      font-size: 17px;
    }
    .rich-text-body ::ng-deep h3 {
      font-size: 15px;
    }
    .rich-text-body ::ng-deep h4 {
      font-size: 13px;
      text-transform: uppercase;
      letter-spacing: 0.4px;
      color: var(--ws-muted);
    }
    .rich-text-body ::ng-deep p {
      margin: 0 0 8px;
    }
    .rich-text-body ::ng-deep ul,
    .rich-text-body ::ng-deep ol {
      margin: 0 0 8px;
      padding-left: 22px;
    }
    .rich-text-body ::ng-deep li > p {
      margin-bottom: 2px;
    }
    .rich-text-body ::ng-deep blockquote {
      margin: 8px 0;
      padding: 4px 12px;
      border-left: 3px solid var(--mat-sys-primary);
      color: var(--ws-muted);
    }
    .rich-text-body ::ng-deep pre {
      margin: 8px 0;
      padding: 10px 12px;
      border-radius: 8px;
      background: var(--mat-sys-surface-container);
      font-size: 12px;
      overflow: auto;
    }
    .rich-text-body ::ng-deep code {
      font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      font-size: 0.92em;
    }
    .rich-text-body ::ng-deep p code {
      padding: 1px 5px;
      border-radius: 4px;
      background: var(--mat-sys-surface-container);
    }
    .rich-text-body ::ng-deep hr {
      border: 0;
      border-top: 1px solid var(--ws-border);
      margin: 12px 0;
    }
    .rich-text-body ::ng-deep a {
      color: var(--mat-sys-primary);
    }
    .rich-text-body ::ng-deep mark {
      background: var(--mat-sys-tertiary-container);
      color: var(--mat-sys-on-tertiary-container);
      border-radius: 3px;
      padding: 0 2px;
    }
    .rich-text-body ::ng-deep img {
      max-width: 100%;
      height: auto;
      border-radius: 8px;
      display: block;
      margin: 8px 0;
    }
    .rich-text-body ::ng-deep .rt-table {
      overflow: auto;
      margin: 8px 0;
    }
    .rich-text-body ::ng-deep table {
      border-collapse: collapse;
      width: 100%;
      font-size: 12px;
    }
    .rich-text-body ::ng-deep th,
    .rich-text-body ::ng-deep td {
      border: 1px solid var(--ws-border);
      padding: 5px 8px;
      text-align: left;
      vertical-align: top;
    }
    .rich-text-body ::ng-deep th {
      background: var(--mat-sys-surface-container-low);
      font-weight: 600;
    }
    .rich-text-body ::ng-deep td > p,
    .rich-text-body ::ng-deep th > p {
      margin: 0;
    }
    .rich-text-body ::ng-deep .rt-task-list {
      list-style: none;
      padding-left: 2px;
    }
    .rich-text-body ::ng-deep .rt-task-item {
      display: flex;
      align-items: flex-start;
      gap: 8px;
      margin: 2px 0;
    }
    .rich-text-body ::ng-deep .rt-task-box {
      flex-shrink: 0;
      width: 15px;
      height: 15px;
      margin-top: 3px;
      border: 1.5px solid var(--ws-muted);
      border-radius: 4px;
      font-size: 11px;
      line-height: 13px;
      text-align: center;
      color: var(--mat-sys-on-primary);
    }
    .rich-text-body ::ng-deep .rt-task-item[data-checked='true'] .rt-task-box {
      background: var(--mat-sys-primary);
      border-color: var(--mat-sys-primary);
    }
    .rich-text-body ::ng-deep .rt-task-item[data-checked='true'] > div {
      color: var(--ws-muted);
      text-decoration: line-through;
    }
    .rich-text-body ::ng-deep .rt-callout {
      margin: 8px 0;
      padding: 10px 12px;
      border-radius: 10px;
      border: 1px solid var(--ws-border);
      background: var(--mat-sys-surface-container-low);
    }
    .rich-text-body ::ng-deep .rt-callout.tone-info {
      background: var(--mat-sys-primary-container);
      color: var(--mat-sys-on-primary-container);
      border-color: transparent;
    }
    .rich-text-body ::ng-deep .rt-callout.tone-success {
      background: var(--mat-sys-tertiary-container);
      color: var(--mat-sys-on-tertiary-container);
      border-color: transparent;
    }
    .rich-text-body ::ng-deep .rt-callout.tone-warning {
      background: var(--mat-sys-error-container);
      color: var(--mat-sys-on-error-container);
      border-color: transparent;
    }
    .rich-text-body ::ng-deep .rt-callout > p:last-child {
      margin-bottom: 0;
    }
  `,
})
export class RichTextViewComponent {
  private readonly reactiveState = injectUiState('RichTextViewComponent');

  private readonly source = this.reactiveState.signal<RichTextDocument | null>(null);
  @Input({ required: true }) set document(value: RichTextDocument | null | undefined) {
    this.source.set(value ?? null);
  }
  @Input() tone: Tone | undefined;
  readonly html = computed(() => richTextToHtml(this.source()));
}
