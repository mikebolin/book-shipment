import { ViewExportService, type ViewExportSection } from '@prism/charting';
import { injectUiState } from '@prism/charting';
import {
  Component,
  computed,
  inject,
  ViewChild,
  ViewChildren,
  QueryList,
  ElementRef,
  afterEveryRender,
  OnDestroy,
  HostListener,
} from '@angular/core';
import { FilterValuesFormComponent } from '@prism/charting';
import type { DashboardScopeState } from '@prism/charting';
import { boundLabel, bucketFromSeconds, selectChartCategory } from './dashboard-filter';
import { DashboardControlsComponent } from './dashboard-controls.component';
import { dashboardDefaultScope } from './dashboard-control-settings';
import { NgTemplateOutlet } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink, ActivatedRoute, Router } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDialog } from '@angular/material/dialog';
import { combineLatest, firstValueFrom, Subscription } from 'rxjs';
import { GridStack, type GridStackNode } from 'gridstack';
import { WorkspaceRepository, type DashboardDataScope } from '@prism/charting';
import { ResourceDialogComponent } from '@prism/charting';
import { WidgetViewComponent } from '@prism/charting';
import { minimalViewOverrides } from './dashboard-view-settings';
import { DashboardElementComponent } from './dashboard-element.component';
import { RichTextViewComponent } from './rich-text-view.component';
import { ChartTileComponent } from './chart-tile.component';
import { TableTileComponent } from './table-tile.component';
import { DashboardDataService } from '@prism/charting';
import { flattenDashboard, nestDashboard } from './dashboard-migration';
import { catalogElements, catalogPlacement } from './dashboard-catalog';
import { independentChartConfiguration } from '@prism/charting';
import { viewCharts, calculatedColumnSpec } from '@prism/charting';
import {
  effectiveElementConfiguration,
  elementIcon,
  elementTitle,
  isDataElement,
  isViewElement,
  minimalChartOverrides,
  minimalTableOverrides,
  pinnedChart,
} from './dashboard-elements';
import {
  DashboardElementDialogComponent,
  DashboardTemplateDialogComponent,
} from './dashboard-composer-dialogs.component';
import {
  arrangeDashboard,
  placementBody,
  placementConfiguration,
  placementDisplayMode,
  templatePlacements,
  openPlacement,
  resizePlacement,
} from './dashboard-composer';
import type { PublishedViewChoice } from './dashboard-view-picker.component';
import type {
  DashboardResource,
  DashboardConfiguration,
  ModelResource,
  WidgetResource,
  WidgetConfiguration,
  Placement,
  ViewChartDataScope,
  ChartPresentation,
} from '@prism/charting';
interface RenderedPlacement extends Placement {
  widget?: WidgetResource;
  model?: ModelResource;
  configuration?: WidgetConfiguration;
  dataScope?: DashboardDataScope;
}
@Component({
  standalone: true,
  imports: [
    FormsModule,
    NgTemplateOutlet,
    RouterLink,
    MatIconModule,
    MatButtonModule,
    MatMenuModule,
    MatTooltipModule,
    WidgetViewComponent,
    DashboardElementComponent,
    RichTextViewComponent,
    ChartTileComponent,
    TableTileComponent,
    FilterValuesFormComponent,
    DashboardControlsComponent,
  ],
  providers: [DashboardDataService],
  template: `<div class="page-wrap dashboard-workspace">
    <header class="page-heading">
      <div class="dashboard-title-group">
        <a
          mat-icon-button
          routerLink="/dashboards"
          aria-label="Back to dashboards"
          matTooltip="Back to dashboards"
          ><mat-icon>arrow_back</mat-icon></a
        >
        @if (editable()) {
          <input
            class="dashboard-title"
            [(ngModel)]="name"
            [disabled]="loading() || busy()"
            maxlength="120"
            placeholder="Untitled dashboard"
            aria-label="Dashboard name"
          />
        } @else {
          <h1>{{ name || 'Untitled dashboard' }}</h1>
        }
      </div>
      <div class="header-actions">
        @if (hasDownloadableElements()) {
          <button
            mat-button
            (click)="downloadAll()"
            [disabled]="loading() || busy() || downloading()"
            aria-label="Download all"
            matTooltip="Download all charts and tables on this page in one ZIP"
          >
            <mat-icon>download</mat-icon>{{ downloading() ? 'Preparing…' : 'Download all' }}
          </button>
        }
        <span class="dashboard-mode" role="status"
          ><mat-icon>{{
            previewing() ? 'visibility' : editing() ? 'edit_note' : 'lock_outline'
          }}</mat-icon
          >{{ previewing() ? 'Preview' : editing() ? 'Draft' : 'Published' }}
          @if (resource(); as saved) {
            · v{{ saved.version }}
          }
          @if (editing() && isDirty()) {
            · Unsaved changes
          }
          @if (!editing()) {
            · Read only
          }
        </span>

        @if (editing()) {
          <button
            mat-icon-button
            [disabled]="loading() || busy()"
            (click)="togglePreview()"
            [attr.aria-pressed]="previewing()"
            [attr.aria-label]="previewing() ? 'Return to dashboard editor' : 'Preview dashboard'"
            [matTooltip]="previewing() ? 'Return to editor' : 'Preview dashboard'"
          >
            <mat-icon>{{ previewing() ? 'edit' : 'preview' }}</mat-icon>
          </button>
        }
        @if (editable()) {
          <button
            mat-icon-button
            aria-label="Dashboard details"
            matTooltip="Dashboard details"
            [attr.aria-expanded]="detailsOpen()"
            (click)="detailsOpen.set(!detailsOpen())"
          >
            <mat-icon>tune</mat-icon>
          </button>
          <button
            mat-icon-button
            [matMenuTriggerFor]="dashboardActions"
            [disabled]="busy() || loading()"
            aria-label="More dashboard actions"
          >
            <mat-icon>more_horiz</mat-icon>
          </button>
          <mat-menu #dashboardActions="matMenu">
            <button mat-menu-item (click)="save(true)" aria-label="Save as new">
              <mat-icon>copy_all</mat-icon>Save as new
            </button>
            @if (isDirty()) {
              <button mat-menu-item (click)="revert()" aria-label="Revert changes">
                <mat-icon>undo</mat-icon>Revert changes
              </button>
            }
            @if (resource()?.publishedVersion) {
              <a
                mat-menu-item
                [routerLink]="['/dashboards', resource()?.slug]"
                aria-label="View published dashboard"
                ><mat-icon>visibility</mat-icon>View published dashboard</a
              >
            }
          </mat-menu>
          @if (isDirty()) {
            <button
              mat-button
              [disabled]="busy() || loading()"
              (click)="save(false)"
              aria-label="Save layout"
              matTooltip="Save layout"
            >
              <mat-icon>save</mat-icon>Save draft
            </button>
          }
          @if (hasPendingPublication()) {
            <button
              mat-button
              [disabled]="busy() || loading()"
              (click)="publish()"
              aria-label="Publish"
              matTooltip="Publish changes"
            >
              <mat-icon>publish</mat-icon>Publish
            </button>
          }
        } @else if (!editing()) {
          <a
            mat-button
            [routerLink]="['/dashboards', resource()?.slug]"
            [queryParams]="{ edit: 1 }"
            aria-label="Edit dashboard"
            matTooltip="Edit dashboard"
            ><mat-icon>edit</mat-icon>Edit draft</a
          >
        }
      </div>
    </header>
    <div class="dashboard-context">
      <span>{{ items().length }} elements · {{ sections().length }} sections</span>
      @if (group) {
        <span>{{ group }}</span>
      }
      <button
        mat-icon-button
        (click)="tour()"
        aria-label="Dashboard help"
        matTooltip="Dashboard help"
      >
        <mat-icon>help_outline</mat-icon>
      </button>
    </div>
    @if (error()) {
      <div class="workspace-alert" role="alert">{{ error() }}</div>
    }
    @if (message()) {
      <div class="workspace-notice" role="status">{{ message() }}</div>
    }
    @if (!editable() && description) {
      <p class="dashboard-summary">{{ description }}</p>
    }
    @if (previewing()) {
      <div class="preview-note" role="status">
        <mat-icon>visibility</mat-icon>Preview · unsaved changes are visible only to you
      </div>
    }
    @if (editable()) {
      @if (detailsOpen()) {
        <div class="dashboard-properties">
          <label
            >Description<input
              [(ngModel)]="description"
              [disabled]="loading() || busy()"
              maxlength="2000"
              placeholder="Add a description"
              aria-label="Description"
          /></label>
          <label
            >Group<input
              [(ngModel)]="group"
              [disabled]="loading() || busy()"
              maxlength="80"
              aria-label="Group"
          /></label>
          <label
            >Tags<input
              [(ngModel)]="tagText"
              [disabled]="loading() || busy()"
              maxlength="263"
              placeholder="Separate with commas"
              aria-label="Tags"
          /></label>
        </div>
      }
      <div class="dashboard-toolbar">
        <div class="tool-cluster" role="group" aria-label="Add dashboard content">
          <button
            mat-button
            class="primary-tool"
            [disabled]="loading() || busy() || items().length >= 48"
            (click)="add()"
            aria-label="Add element"
            matTooltip="Browse charts, tables and views"
          >
            <mat-icon>add</mat-icon>Add element
          </button>
          <button
            mat-icon-button
            [disabled]="loading() || busy() || items().length >= 48"
            (click)="addElement('section')"
            aria-label="Add section"
            matTooltip="Add section"
          >
            <mat-icon>segment</mat-icon>
          </button>

          <button
            mat-icon-button
            [disabled]="loading() || busy() || items().length >= 48"
            (click)="addElement('text')"
            matTooltip="Add text"
            aria-label="Add text"
          >
            <mat-icon>notes</mat-icon>
          </button>
          <button
            mat-icon-button
            [matMenuTriggerFor]="contentMenu"
            [disabled]="loading() || busy() || items().length >= 48"
            aria-label="More content"
            matTooltip="More content"
          >
            <mat-icon>add</mat-icon>
          </button>
          <mat-menu #contentMenu="matMenu">
            <button mat-menu-item (click)="addElement('html')" aria-label="Add HTML">
              <mat-icon>code</mat-icon>HTML / document
            </button>
            <button mat-menu-item (click)="addElement('image')" aria-label="Add image">
              <mat-icon>image</mat-icon>Image
            </button>
            <button mat-menu-item (click)="addElement('powerbi')" aria-label="Add Power BI report">
              <mat-icon>analytics</mat-icon>Power BI report
            </button>
          </mat-menu>
        </div>
        <div class="tool-cluster" role="group" aria-label="Arrange dashboard layout">
          <button
            mat-icon-button
            [disabled]="loading()"
            (click)="chooseTemplate()"
            aria-label="Choose dashboard template"
            matTooltip="Choose a template"
          >
            <mat-icon>dashboard_customize</mat-icon>
          </button>
          <button
            mat-icon-button
            [disabled]="loading() || !items().length"
            (click)="arrange()"
            aria-label="Arrange dashboard sections"
            matTooltip="Arrange sections and their elements"
          >
            <mat-icon>auto_awesome_mosaic</mat-icon>
          </button>
        </div>
        <span class="builder-hint">Drag to arrange · Resize from a card's corner</span>
      </div>
      @if (mobile()) {
        <div class="mobile-layout-note">
          <mat-icon>smartphone</mat-icon>Desktop layout preserved
        </div>
      }
    }
    @if (loading()) {
      <div class="empty-state" role="status">Loading dashboard configurations…</div>
    }
    <div
      #canvas
      class="grid-stack"
      aria-label="Dashboard layout"
      [class.viewer-grid]="!editable()"
      [attr.aria-busy]="loading()"
      [attr.inert]="loading() ? '' : null"
    >
      @for (item of items(); track item.id) {
        <div
          class="grid-stack-item"
          [attr.gs-id]="item.id"
          [attr.gs-x]="item.x"
          [attr.gs-y]="item.y"
          [attr.gs-w]="item.w"
          [attr.gs-h]="item.h"
        >
          <article
            class="grid-stack-item-content dashboard-tile"
            [class.section-tile]="item.kind === 'section'"
            [class.grouped-tile]="!!item.sectionId"
            [class.data-tile]="isVisualData(item)"
            [attr.data-tone]="item.tone || 'neutral'"
            [attr.data-placement-id]="item.id"
          >
            <ng-template #placementActions>
              @if (item.widget && isVisualData(item)) {
                <button
                  mat-icon-button
                  [matMenuTriggerFor]="sourceMenu"
                  aria-label="View source"
                  [matTooltip]="item.widget.name + ' - published revision ' + item.widgetRevision"
                >
                  <mat-icon>link</mat-icon>
                </button>
                <mat-menu #sourceMenu="matMenu">
                  <div class="source-details">
                    <strong>{{ item.widget.name }}</strong
                    ><span
                      >{{ item.model?.name }} - published revision {{ item.widgetRevision }}</span
                    >
                  </div>
                  <a
                    mat-menu-item
                    [routerLink]="['/views', item.widget.slug]"
                    aria-label="Open source view"
                    ><mat-icon>open_in_new</mat-icon>Open source view</a
                  >
                </mat-menu>
                @if (editable()) {
                  <span
                    class="tile-drag-handle data-drag-handle"
                    [attr.aria-label]="'Drag ' + title(item)"
                    matTooltip="Drag to move this view"
                    ><mat-icon>drag_indicator</mat-icon></span
                  >
                }
              }
              @if (
                isView(item) &&
                item.configuration &&
                (item.configuration.chart || item.configuration.charts?.length) &&
                (editable() || item.interactions?.switchView !== false)
              ) {
                <div class="view-toggle">
                  <button
                    aria-label="Show chart"
                    [disabled]="!item.configuration.chart"
                    [class.selected]="viewMode(item) === 'chart'"
                    [attr.aria-pressed]="viewMode(item) === 'chart'"
                    (click)="display(item, 'chart')"
                    matTooltip="Show chart"
                  >
                    <mat-icon>bar_chart</mat-icon></button
                  ><button
                    aria-label="Show grid"
                    [class.selected]="viewMode(item) === 'grid'"
                    [attr.aria-pressed]="viewMode(item) === 'grid'"
                    (click)="display(item, 'grid')"
                    matTooltip="Show grid"
                  >
                    <mat-icon>table_chart</mat-icon>
                  </button>
                  <button
                    aria-label="Show chart and table"
                    [disabled]="!item.configuration.chart"
                    [class.selected]="viewMode(item) === 'both'"
                    [attr.aria-pressed]="viewMode(item) === 'both'"
                    (click)="display(item, 'both')"
                    matTooltip="Chart and table"
                  >
                    <mat-icon>view_agenda</mat-icon>
                  </button>
                </div>
              }
              @if (item.kind === 'filter' && filterChanged(item) && !item.controls?.length) {
                <button
                  mat-icon-button
                  type="button"
                  (click)="resetFilter(item)"
                  aria-label="Reset dashboard filter"
                  matTooltip="Reset to the saved filter values"
                  data-testid="dashboard-filter-reset"
                >
                  <mat-icon>restart_alt</mat-icon>
                </button>
              }
              @if (editable()) {
                @if (item.kind === 'filter') {
                  <button
                    mat-icon-button
                    aria-label="Configure filter controls"
                    matTooltip="Configure filter controls"
                    (click)="configureFilter(item)"
                  >
                    <mat-icon>tune</mat-icon>
                  </button>
                }
                @if (item.widget && isView(item)) {
                  <button
                    mat-icon-button
                    aria-label="Configure view"
                    [class.configured]="!!item.viewOverrides"
                    matTooltip="Configure this view for this dashboard"
                    (click)="configureView(item)"
                  >
                    <mat-icon>tune</mat-icon>
                  </button>
                }
                <button
                  mat-icon-button
                  aria-label="Element actions"
                  matTooltip="Element actions"
                  [matMenuTriggerFor]="elementMenu"
                >
                  <mat-icon>more_horiz</mat-icon>
                </button>
                <mat-menu #elementMenu="matMenu">
                  <button
                    mat-menu-item
                    (click)="editElement(item)"
                    aria-label="Edit element settings"
                  >
                    <mat-icon>tune</mat-icon
                    >{{
                      item.kind === 'filter'
                        ? 'Position and section'
                        : item.kind === 'chart'
                          ? 'Chart settings'
                          : item.widget || item.kind === 'richtext'
                            ? 'Position and section'
                            : 'Element settings'
                    }}
                  </button>
                  @if (item.widget) {
                    @if (latestRevision(item); as revision) {
                      <button
                        mat-menu-item
                        (click)="updateSourceRevision(item)"
                        aria-label="Update to latest published view"
                      >
                        <mat-icon>update</mat-icon>Update to published revision {{ revision }}
                      </button>
                    }
                    @if (isView(item)) {
                      @if (singleChart(item)) {
                        <button
                          mat-menu-item
                          (click)="breakOutChart(item)"
                          aria-label="Break out chart"
                        >
                          <mat-icon>open_in_full</mat-icon>Break out chart
                        </button>
                      }
                      <button
                        mat-menu-item
                        (click)="separateView(item)"
                        [disabled]="items().length + (item.configuration?.charts?.length || 1) > 48"
                      >
                        <mat-icon>dashboard_customize</mat-icon>Separate charts and table
                      </button>
                    }
                    <button
                      mat-menu-item
                      (click)="duplicateView(item)"
                      [disabled]="items().length >= 48"
                      aria-label="Duplicate view"
                    >
                      <mat-icon>content_copy</mat-icon>Duplicate view
                    </button>
                  }
                  @if (item.kind !== 'section') {
                    <button mat-menu-item [matMenuTriggerFor]="sizeMenu">
                      <mat-icon>aspect_ratio</mat-icon>Resize
                    </button>
                  }
                  <button mat-menu-item (click)="remove(item)" aria-label="Remove placement">
                    <mat-icon>delete_outline</mat-icon>Remove from dashboard
                  </button>
                </mat-menu>
                <mat-menu #sizeMenu="matMenu">
                  <button mat-menu-item (click)="width(item, 4)" aria-label="Third width">
                    <mat-icon>view_column</mat-icon>Third width
                  </button>
                  <button mat-menu-item (click)="width(item, 6)" aria-label="Half width">
                    <mat-icon>view_week</mat-icon>Half width
                  </button>
                  <button mat-menu-item (click)="width(item, 12)" aria-label="Full width">
                    <mat-icon>view_day</mat-icon>Full width
                  </button>
                  <button mat-menu-item (click)="height(item, -1)" aria-label="Reduce height">
                    <mat-icon>remove</mat-icon>Reduce height
                  </button>
                  <button mat-menu-item (click)="height(item, 1)" aria-label="Increase height">
                    <mat-icon>add</mat-icon>Increase height
                  </button>
                </mat-menu>
              }
            </ng-template>
            @if (!isVisualData(item)) {
              <header class="tile-heading">
                <div
                  class="tile-drag-handle"
                  [attr.aria-label]="editable() ? 'Drag ' + title(item) : null"
                >
                  <mat-icon>{{ editable() ? 'drag_indicator' : icon(item) }}</mat-icon>
                  <div>
                    <strong>{{ title(item) }}</strong>
                    @if (item.kind === 'section' && item.description) {
                      <span class="section-caption" [matTooltip]="item.description">{{
                        item.description
                      }}</span>
                    }
                    @if (item.sectionId) {
                      <span class="tile-section-label">{{ sectionTitle(item.sectionId) }}</span>
                    }
                  </div>
                </div>
                @if (item.kind === 'section' && editable()) {
                  <button
                    mat-icon-button
                    (click)="add(item.id)"
                    aria-label="Add element to section"
                    matTooltip="Add element to this section"
                  >
                    <mat-icon>add</mat-icon>
                  </button>
                  <span
                    class="section-count"
                    [matTooltip]="sectionSize(item.id) + ' elements in this section'"
                    >{{ sectionSize(item.id) }}</span
                  >
                }
                <ng-container [ngTemplateOutlet]="placementActions" />
              </header>
            }

            @if (item.kind !== 'section') {
              <div class="tile-body">
                @if (item.kind === 'filter' && item.model && item.filter) {
                  @if (item.controls?.length) {
                    <workspace-dashboard-controls
                      [controls]="item.controls!"
                      [columns]="filterColumnsFor(item)"
                      [scope]="scopeFor(item)"
                      [label]="title(item)"
                      [changed]="filterChanged(item)"
                      [disabled]="loading() || busy()"
                      (scopeChange)="applyScope(item, $event)"
                      (reset)="resetFilter(item)"
                    />
                  } @else {
                    <workspace-filter-values-form
                      class="dashboard-filter-controls"
                      [compact]="true"
                      [columns]="filterColumnsFor(item)"
                      [scope]="{ mode: 'advanced', filterModel: scopeFor(item).filterModel }"
                      [label]="title(item)"
                      applyLabel="Apply to dashboard"
                      [disabled]="loading() || busy()"
                      (scopeChange)="applyFilterValues(item, $event)"
                    />
                  }
                } @else if (
                  item.model &&
                  item.configuration &&
                  item.kind === 'chart' &&
                  item.configuration.chart
                ) {
                  <workspace-chart-tile
                    [headerActions]="placementActions"
                    [title]="title(item)"
                    [exportLabel]="item.title || item.model!.name"
                    [model]="item.model"
                    [configuration]="item.widget!.body"
                    [chart]="item.configuration.chart"
                    [dataScope]="item.dataScope"
                    [scopeFilter]="scopeFilterFor(item)"
                    [scopeBucketSeconds]="scopeBucketSecondsFor(item)"
                    [editable]="editable()"
                    [allowDownload]="item.configuration.allowDownload !== false"
                    (scopeChange)="updateChartScope(item, $event)"
                    (presentationChange)="updateChartPresentation(item, $event)"
                    (categoryClick)="selectCategory(item, $event)"
                  />
                } @else if (item.model && item.configuration && item.kind === 'table') {
                  <workspace-table-tile
                    [headerActions]="placementActions"
                    [title]="title(item)"
                    [exportLabel]="item.title || item.model!.name"
                    [model]="item.model"
                    [configuration]="item.configuration"
                    [dataScope]="item.dataScope"
                    [scopeFilter]="scopeFilterFor(item)"
                    [scopeGroupBy]="scopeGroupByFor(item)"
                    [editable]="editable()"
                    (configurationChange)="updateElementConfiguration(item, $event)"
                  />
                } @else if (item.model && item.configuration) {
                  @if (item.description) {
                    <p class="tile-description">{{ item.description }}</p>
                  }
                  <workspace-widget-view
                    [integratedHeaders]="true"
                    [headerActions]="placementActions"
                    [tableTitle]="title(item)"
                    [exportLabel]="item.title || item.model!.name"
                    [model]="item.model"
                    [configuration]="item.configuration"
                    [displayMode]="viewMode(item)"
                    [dataScope]="item.dataScope"
                    [scopeFilter]="scopeFilterFor(item)"
                    [scopeGroupBy]="scopeGroupByFor(item)"
                    [scopeBucketSeconds]="scopeBucketSecondsFor(item)"
                    [showDownloadActions]="false"
                    [editable]="editable() && isView(item)"
                    (configurationChange)="updateViewConfiguration(item, $event)"
                  />
                } @else if (item.kind === 'richtext') {
                  <workspace-rich-text [document]="item.document" [tone]="item.tone" />
                } @else {
                  <workspace-dashboard-element [item]="item" [editing]="editable()" />
                }
              </div>
            }
          </article>
        </div>
      }
    </div>
    @if (!loading() && !items().length) {
      <div class="empty-state">
        <div class="empty-icon"><mat-icon>dashboard_customize</mat-icon></div>
        <h2>
          {{ editable() ? 'Build from your element library' : 'No elements in this dashboard' }}
        </h2>
        <p>
          {{
            editable()
              ? 'Choose a chart or table, set its defaults and decide what readers can change. Each copy has its own settings.'
              : 'This dashboard does not have published elements yet.'
          }}
        </p>
        @if (editable()) {
          <div class="empty-actions">
            <button mat-button (click)="add()" aria-label="Add your first element">
              <mat-icon>add</mat-icon>Browse elements
            </button>
            <button mat-button (click)="chooseTemplate()" aria-label="Start from a template">
              <mat-icon>dashboard_customize</mat-icon>Start from a template
            </button>
          </div>
        }
      </div>
    }
  </div>`,
  styles: [
    `
      :host {
        display: block;
      }
      .grid-stack {
        min-height: 1px;
      }
      .dashboard-workspace {
        padding: 8px 12px 18px;
      }
      .dashboard-title-group {
        display: flex;
        align-items: center;
        gap: 4px;
        min-width: 0;
        flex: 1;
      }
      .dashboard-title-group h1 {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        font-size: clamp(20px, 2vw, 26px);
      }
      .dashboard-title {
        min-width: 60px;
        max-width: 550px;
        width: 100%;
        padding: 5px 6px;
        background: transparent;
        color: var(--ws-ink);
        border: 1px solid transparent;
        border-radius: 5px;
        font:
          600 24px Roboto,
          Arial,
          sans-serif;
      }
      .dashboard-title:hover,
      .dashboard-title:focus {
        border-color: var(--ws-border);
        background: var(--mat-sys-surface);
      }
      .dashboard-properties {
        display: grid;
        grid-template-columns: 2fr 1fr 1fr;
        gap: 16px;
        padding: 16px;
        border: 1px solid var(--ws-border);
        border-radius: 12px;
        background: var(--mat-sys-surface);
        margin: 4px 0 16px;
      }
      .dashboard-properties label {
        display: flex;
        align-items: stretch;
        flex-direction: column;
        gap: 8px;
        width: 100%;
        font-size: 11px;
        color: var(--ws-muted);
      }
      .dashboard-properties input {
        flex: 1;
        min-width: 0;
        border: 1px solid var(--ws-border);
        border-radius: 5px;
        padding: 7px;
        font:
          12px Roboto,
          Arial,
          sans-serif;
        background: var(--mat-sys-surface);
        color: var(--ws-ink);
      }
      .dashboard-toolbar {
        display: flex;
        align-items: center;
        gap: 10px;
        margin: 0 0 14px;
        flex-wrap: wrap;
      }
      .dashboard-toolbar > span {
        margin-left: auto;
        font-size: 10px;
        color: var(--ws-muted);
      }
      .dashboard-toolbar .builder-hint {
        margin-left: 8px;
        margin-right: auto;
        font-size: 11px;
      }
      .tool-cluster {
        display: flex;
        align-items: center;
        border: 1px solid var(--ws-border);
        background: var(--mat-sys-surface);
        border-radius: 8px;
        padding: 2px;
        gap: 1px;
      }
      .primary-tool {
        color: var(--mat-sys-primary);
        background: var(--mat-sys-primary-container);
        border-radius: 6px;
      }
      .configured {
        color: var(--mat-sys-primary);
        background: var(--mat-sys-secondary-container);
      }
      @media (max-width: 700px) {
        .dashboard-toolbar .builder-hint {
          display: none;
        }
      }
      .widget-picker {
        display: flex;
        align-items: center;
        background: var(--mat-sys-surface);
        border: 1px solid var(--ws-border);
        border-radius: 5px;
        padding: 0 8px;
        max-width: 450px;
        flex: 1;
        min-width: 150px;
        color: var(--ws-muted);
      }
      .widget-picker mat-icon {
        font-size: 17px;
        width: 17px;
        height: 17px;
      }
      .widget-picker select {
        width: 100%;
        min-width: 0;
        max-width: none;
        border: 0;
        background: transparent;
        padding: 8px;
        font:
          12px Roboto,
          Arial,
          sans-serif;
        color: var(--ws-ink);
      }
      .dashboard-tile {
        background: var(--mat-sys-surface);
        border: 1px solid var(--ws-border);
        border-radius: 12px;
        box-shadow: 0 2px 8px rgb(15 23 42 / 3%);
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }
      .data-tile {
        border-radius: 4px;
      }
      .tile-drag-handle.data-drag-handle {
        flex: 0 0 auto;
        width: 24px;
        justify-content: center;
        cursor: grab;
      }
      .source-details {
        display: flex;
        flex-direction: column;
        gap: 4px;
        max-width: 320px;
        padding: 10px 16px;
        font-size: 13px;
      }
      .source-details span {
        font-size: 11px;
        color: var(--ws-muted);
      }
      .tile-heading {
        display: flex;
        align-items: center;
        gap: 4px;
        min-height: 44px;
        padding: 4px 10px;
        border-bottom: 1px solid var(--ws-border);
      }
      .tile-drag-handle {
        display: flex;
        align-items: center;
        gap: 5px;
        min-width: 0;
        flex: 1;
        cursor: grab;
      }
      .viewer-grid .tile-drag-handle {
        cursor: default;
      }
      .tile-drag-handle > mat-icon {
        color: var(--ws-muted);
        font-size: 17px;
        width: 17px;
        height: 17px;
        flex-shrink: 0;
      }
      .tile-drag-handle div {
        min-width: 0;
      }
      .tile-drag-handle strong {
        display: block;
        font-size: 13px;
        font-weight: 600;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .tile-drag-handle span {
        display: none;
      }
      .tile-drag-handle .tile-section-label {
        display: block;
        font-size: 9px;
        color: var(--ws-muted);
        margin-top: 2px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .dashboard-summary {
        margin: 0 4px 12px;
        font-size: 12px;
        line-height: 1.6;
        color: var(--ws-muted);
        white-space: pre-line;
      }
      .dashboard-mode {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 6px 9px;
        border: 1px solid var(--ws-border);
        border-radius: 6px;
        font-size: 11px;
        color: var(--ws-muted);
      }
      .dashboard-mode mat-icon {
        font-size: 15px;
        height: 15px;
        width: 15px;
      }
      .dashboard-context {
        display: flex;
        align-items: center;
        gap: 14px;
        margin: -4px 4px 12px;
        font-size: 12px;
        color: var(--ws-muted);
      }
      .dashboard-context button {
        margin-left: auto;
        font-size: 12px;
      }
      .tile-body > workspace-dashboard-controls,
      .tile-body > .dashboard-filter-controls {
        display: block;
        width: 100%;
      }
      .empty-actions {
        display: flex;
        gap: 10px;
        justify-content: center;
        flex-wrap: wrap;
        margin-top: 20px;
      }
      .page-heading {
        flex-wrap: wrap;
        padding: 8px 0 12px;
        gap: 16px;
      }
      .header-actions {
        flex-wrap: wrap;
        gap: 6px;
      }
      .dashboard-title-group {
        flex: 1 1 320px;
      }
      .dashboard-title-group h1,
      .dashboard-title {
        font-size: 24px;
        letter-spacing: -0.02em;
      }
      .preview-note {
        display: flex;
        align-items: center;
        gap: 6px;
        font-size: 11px;
        color: var(--ws-muted);
        padding: 6px 4px 10px;
      }
      .preview-note mat-icon {
        font-size: 16px;
        width: 16px;
        height: 16px;
      }
      .section-tile {
        background: linear-gradient(
          110deg,
          var(--mat-sys-surface-container),
          var(--mat-sys-surface)
        );
        border: 1px solid var(--ws-border);
        border-radius: 10px;
      }
      .section-tile .tile-heading {
        border: 0;
        padding: 8px 16px;
        min-height: 0;
        height: 100%;
      }
      .section-tile .tile-drag-handle strong {
        font-size: 16px;
        font-weight: 600;
        line-height: 18px;
      }
      .tile-drag-handle .section-caption {
        display: block;
        font-size: 12px;
        line-height: 18px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        color: var(--ws-muted);
      }
      .section-count {
        flex-shrink: 0;
        min-width: 18px;
        padding: 2px 4px;
        text-align: center;
        border-radius: 4px;
        background: var(--mat-sys-surface-container-high);
        color: var(--ws-muted);
        font-size: 10px;
      }
      .grouped-tile {
        border-top: 1px solid var(--ws-border);
      }
      .section-tile[data-tone='info'] {
        border-left: 3px solid var(--mat-sys-primary);
      }
      .section-tile[data-tone='success'] {
        border-left: 3px solid #47866b;
      }
      .section-tile[data-tone='warning'] {
        border-left: 3px solid #b88035;
      }
      .tile-description {
        margin: 0;
        padding: 6px 10px;
        font-size: 11px;
        line-height: 1.5;
        color: var(--ws-muted);
        max-height: 65px;
        overflow: auto;
        flex-shrink: 0;
      }
      .tile-body {
        flex: 1;
        min-height: 0;
        overflow: hidden;
        display: flex;
        flex-direction: column;
      }
      .tile-body workspace-widget-view {
        min-height: 0;
        flex: 1;
        height: 0;
      }
      .tile-layout-actions {
        display: flex;
        gap: 0;
        justify-content: flex-end;
        position: absolute;
        z-index: 2;
        right: 8px;
        bottom: 6px;
        border: 1px solid var(--ws-border);
        border-radius: 5px;
        background: var(--mat-sys-surface);
        opacity: 0;
        transition: opacity 0.15s;
      }
      .dashboard-tile:hover .tile-layout-actions,
      .dashboard-tile:focus-within .tile-layout-actions {
        opacity: 1;
      }
      .mobile-layout-note {
        display: flex;
        align-items: center;
        gap: 5px;
        font-size: 10px;
        color: var(--ws-muted);
        margin: 0 0 5px;
      }
      .mobile-layout-note mat-icon {
        font-size: 14px;
        width: 14px;
        height: 14px;
      }
      @media (max-width: 700px) {
        .dashboard-workspace {
          padding: 5px;
        }
        .dashboard-title {
          font-size: 16px;
          padding: 4px 0;
        }
        .dashboard-title-group h1 {
          font-size: 17px;
        }
        .header-actions {
          gap: 0;
          flex-wrap: wrap;
          justify-content: flex-end;
        }
        .page-heading {
          gap: 2px;
        }
        .dashboard-toolbar {
          gap: 2px;
        }
        .dashboard-toolbar > span {
          display: none;
        }
        .widget-picker select {
          font-size: 13px;
        }
        .tile-heading {
          padding: 3px 5px;
        }
        .tile-heading .view-toggle button {
          width: 36px;
          height: 40px;
        }
        .tile-layout-actions {
          opacity: 1;
          position: static;
          justify-content: flex-end;
          border: 0;
          border-bottom: 1px solid var(--ws-border);
          border-radius: 0;
        }
        .tile-layout-actions .mat-mdc-icon-button {
          height: 36px !important;
        }
        .dashboard-properties label {
          font-size: 10px;
        }
        .dashboard-properties {
          grid-template-columns: 1fr;
          gap: 12px;
        }
      }
    `,
  ],
})
export class DashboardDetailComponent implements OnDestroy {
  private readonly reactiveState = injectUiState('DashboardDetailComponent');

  @ViewChildren(WidgetViewComponent) private viewTiles!: QueryList<WidgetViewComponent>;
  @ViewChildren(ChartTileComponent) private chartTiles!: QueryList<ChartTileComponent>;
  @ViewChildren(TableTileComponent) private tableTiles!: QueryList<TableTileComponent>;
  private readonly exports = inject(ViewExportService);
  readonly downloading = this.reactiveState.signal(false);
  hasDownloadableElements() {
    return this.items().some(
      (item) => item.configuration && item.configuration.allowDownload !== false,
    );
  }
  async downloadAll() {
    if (this.loading() || this.busy() || this.downloading()) return;
    this.downloading.set(true);
    this.error.set('');
    try {
      const components = [...this.viewTiles, ...this.chartTiles, ...this.tableTiles];
      // Preserve placement order, even when a dashboard mixes views, charts and tables.
      components.sort(
        (a, b) =>
          this.items().findIndex((item) => item.id === a.dataScope?.placementId) -
          this.items().findIndex((item) => item.id === b.dataScope?.placementId),
      );
      const sections = (
        await Promise.all(components.map((component) => component.exportSection()))
      ).filter((section): section is ViewExportSection => section !== null);
      await this.exports.downloadPage(sections, this.name || 'Dashboard');
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : 'Unable to prepare this download.');
    } finally {
      this.downloading.set(false);
    }
  }
  readonly readerModes = this.reactiveState.signal<Record<string, 'grid' | 'chart' | 'both'>>({});
  readonly workspace = inject(WorkspaceRepository);
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private dialog = inject(MatDialog);
  private sub = new Subscription();
  @ViewChild('canvas') canvas?: ElementRef<HTMLElement>;
  private grid?: GridStack;
  private observer?: ResizeObserver;
  private needsSync = true;
  private syncing = false;
  private generation = 0;
  private routeState = '';
  readonly resource = this.reactiveState.signal<DashboardResource | null>(null);
  readonly models = this.reactiveState.signal<ModelResource[]>([]);
  readonly widgets = this.reactiveState.signal<WidgetResource[]>([]);
  readonly items = this.reactiveState.signal<RenderedPlacement[]>([]);
  readonly editing = this.reactiveState.signal(false);
  readonly loading = this.reactiveState.signal(true);
  readonly busy = this.reactiveState.signal(false);
  readonly error = this.reactiveState.signal('');
  readonly message = this.reactiveState.signal('');
  readonly mobile = this.reactiveState.signal(false);
  readonly detailsOpen = this.reactiveState.signal(false);
  readonly previewing = this.reactiveState.signal(false);
  /** Session scope of each filter-controls element; saved defaults live on the element itself. */
  readonly appliedScopes = this.reactiveState.signal<Record<string, DashboardScopeState>>({});
  private readonly scopeCache = new Map<string, { source: unknown; scope: DashboardScopeState }>();
  private filterItems(modelId?: string) {
    return this.items().filter(
      (item) => item.kind === 'filter' && item.filter && (!modelId || item.model?.id === modelId),
    );
  }
  /** The scope a filter-controls element currently applies; defaults come from its saved filter. */
  scopeFor(item: RenderedPlacement): DashboardScopeState {
    const applied = this.appliedScopes()[item.id];
    const source =
      applied ?? JSON.stringify([item.filter, item.controls, item.widget?.body.calculatedColumns]);
    const cached = this.scopeCache.get(item.id);
    if (cached && cached.source === source) return cached.scope;
    const scope: DashboardScopeState =
      applied ??
      dashboardDefaultScope(
        item.filter?.filterModel ?? null,
        item.controls ?? [],
        this.filterColumnsFor(item),
      );
    this.scopeCache.set(item.id, { source, scope });
    return scope;
  }
  /** Controls are bound to their source model; unrelated sources never receive foreign field IDs. */
  private readonly scopesByModel = computed(() => {
    this.appliedScopes();
    const scopes = new Map<string, DashboardScopeState>();
    for (const modelId of new Set(
      this.filterItems()
        .map((item) => item.model?.id)
        .filter((id): id is string => !!id),
    )) {
      const states = this.filterItems(modelId).map((item) => this.scopeFor(item));
      const conditions = states
        .map((state) => state.filterModel)
        .filter((model) => model != null && Object.keys(model).length);
      scopes.set(modelId, {
        filterModel:
          conditions.length > 1
            ? { filterType: 'join', type: 'AND', conditions }
            : (conditions[0] ?? null),
        bucketSeconds: states.find((state) => state.bucketSeconds !== undefined)?.bucketSeconds,
        groupBy: states.find((state) => state.groupBy !== undefined)?.groupBy,
      });
    }
    return scopes;
  });
  scopeFilterFor(item: RenderedPlacement) {
    return this.scopesByModel().get(item.model?.id ?? '')?.filterModel ?? null;
  }
  scopeBucketSecondsFor(item: RenderedPlacement) {
    return this.scopesByModel().get(item.model?.id ?? '')?.bucketSeconds;
  }
  scopeGroupByFor(item: RenderedPlacement) {
    return this.scopesByModel().get(item.model?.id ?? '')?.groupBy;
  }
  filterChanged(item: RenderedPlacement) {
    return item.id in this.appliedScopes();
  }
  /** Readers change the session scope; an author editing the dashboard changes the saved defaults. */
  applyScope(item: RenderedPlacement, scope: DashboardScopeState) {
    const next: DashboardScopeState = structuredClone(scope);
    if (this.editable()) {
      this.items.update((items) =>
        items.map((current) =>
          current.id === item.id
            ? {
                ...current,
                filter: { mode: 'advanced' as const, filterModel: next.filterModel },
                controls: current.controls?.map((control) =>
                  control.type === 'bucket' && next.bucketSeconds !== undefined
                    ? { ...control, seconds: next.bucketSeconds }
                    : control.type === 'groupBy' && next.groupBy !== undefined
                      ? { ...control, columnId: next.groupBy }
                      : control.type === 'window'
                        ? { ...control, minutes: undefined }
                        : control,
                ),
              }
            : current,
        ),
      );
      this.needsSync = true;
    }
    this.appliedScopes.update((all) => ({ ...all, [item.id]: next }));
  }
  applyFilterValues(item: RenderedPlacement, scope: ViewChartDataScope) {
    this.applyScope(item, { ...this.scopeFor(item), filterModel: scope.filterModel });
  }
  resetFilter(item: RenderedPlacement) {
    this.appliedScopes.update((all) => {
      const next = { ...all };
      delete next[item.id];
      return next;
    });
  }
  private resetFilters() {
    this.scopeCache.clear();
    this.appliedScopes.set({});
  }
  /** Click-to-filter: a time bucket narrows the window; a category toggles its equality. */
  selectCategory(item: RenderedPlacement, value: string | number) {
    const chart = item.configuration?.chart;
    const columnId = chart?.plan.categoryColumnId;
    if (!item.interactions?.selectFilter || !chart || !columnId) return;
    const target = this.filterItems().find((candidate) => candidate.model?.id === item.model?.id);
    const column = target?.model?.body.columns.find((candidate) => candidate.id === columnId);
    if (!target || !column) {
      this.message.set(
        'Add Filter controls to this dashboard so chart clicks can narrow the data.',
      );
      return;
    }
    const current = this.scopeFor(target);
    // The clicked bar spans the bucket width currently plotted, which the bucket control may
    // have changed from the chart's saved width.
    const plan =
      current.bucketSeconds && ['second', 'minute', 'hour'].includes(chart.plan.timeBucket ?? '')
        ? { ...chart.plan, ...bucketFromSeconds(current.bucketSeconds) }
        : chart.plan;
    const next = selectChartCategory(current.filterModel, plan, column, value);
    if (next === undefined) return;
    this.appliedScopes.update((all) => ({
      ...all,
      [target.id]: { ...current, filterModel: next },
    }));
    this.message.set(
      chart.plan.timeBucket
        ? `Window narrowed to the ${boundLabel(String(value))} bucket. Reset the filter controls to restore the saved window.`
        : `${column.label} ${JSON.stringify(String(value))} toggled in the filter controls.`,
    );
  }
  private readonly nameState = this.reactiveState.signal('');
  get name() {
    return this.nameState();
  }
  set name(value) {
    this.nameState.set(value);
  }
  private readonly descriptionState = this.reactiveState.signal('');
  get description() {
    return this.descriptionState();
  }
  set description(value) {
    this.descriptionState.set(value);
  }
  private readonly groupState = this.reactiveState.signal('');
  get group() {
    return this.groupState();
  }
  set group(value) {
    this.groupState.set(value);
  }
  private readonly tagTextState = this.reactiveState.signal('');
  get tagText() {
    return this.tagTextState();
  }
  set tagText(value) {
    this.tagTextState.set(value);
  }
  private baseline = '';
  private pendingLeave?: Promise<boolean>;
  private savedState?: {
    name: string;
    description: string;
    group: string;
    tagText: string;
    items: RenderedPlacement[];
    schemaVersion: 1 | 2;
  };
  constructor() {
    this.sub.add(
      combineLatest([this.route.paramMap, this.route.queryParamMap]).subscribe(([p, q]) => {
        const slug = p.get('slug') ?? 'new',
          state = `${slug}:${q.has('edit')}`;
        if (state === this.routeState) return;
        this.routeState = state;
        void this.load(slug, q.has('edit')).then(async () => {
          if (
            state === this.routeState &&
            (q.get('template') === 'choose' || q.get('add') === 'view') &&
            this.editable() &&
            !this.error()
          ) {
            await this.router.navigate([], {
              relativeTo: this.route,
              queryParams: { template: null, add: null },
              queryParamsHandling: 'merge',
              replaceUrl: true,
            });
            if (q.get('add') === 'view') await this.add();
            else await this.chooseTemplate();
          }
        });
      }),
    );
    afterEveryRender(() => {
      if (this.canvas && !this.grid) {
        this.grid =
          GridStack.init(
            {
              column: 12,
              cellHeight: 64,
              margin: 8,
              animate: false,
              handle: '.tile-drag-handle',
              mode: 'float',
              minRow: 0,
              staticGrid: this.busy() || !this.editable(),
              resizable: { handles: 'se' },
              auto: false,
            },
            this.canvas.nativeElement,
          ) ?? undefined;
        if (!this.grid) return;
        this.grid.on('change', (_event: Event, nodes: GridStackNode[]) => {
          if (this.syncing || !this.editable() || this.grid?.getColumn() !== 12) return;
          const changed = new Map(nodes.map((n) => [String(n.id), n]));
          this.items.update((items) =>
            items.map((i) => {
              const n = changed.get(i.id);
              return n ? { ...i, x: n.x ?? i.x, y: n.y ?? i.y, w: n.w ?? i.w, h: n.h ?? i.h } : i;
            }),
          );
        });
        this.grid.on('dragstop', (_event: Event, element: HTMLElement) => {
          const item = this.items().find((item) => item.id === element.getAttribute('gs-id'));
          if (item?.kind === 'section') queueMicrotask(() => this.arrange());
        });
        this.observer = new ResizeObserver(() => this.resize());
        this.observer.observe(this.canvas.nativeElement);
        this.needsSync = true;
      }
      if (this.grid && this.needsSync) this.sync();
    });
  }
  private resize() {
    if (!this.grid || !this.canvas) return;
    const small = this.canvas.nativeElement.clientWidth < 720;
    this.mobile.set(small);
    const columns = small ? 1 : 12;
    if (this.grid.getColumn() !== columns) {
      this.syncing = true;
      this.grid.column(columns);
      this.grid.setStatic(this.busy() || !this.editable() || small);
      if (!small)
        this.grid.load(
          this.items().map((i) => ({
            id: i.id,
            x: i.x,
            y: i.y,
            w: i.w,
            h: i.h,
            minH: i.kind === 'section' ? 1 : 2,
            maxH: 24,
          })),
          false,
        );
      this.syncing = false;
    }
  }
  private sync() {
    if (!this.grid || !this.canvas) return;
    this.needsSync = false;
    this.syncing = true;
    this.grid.batchUpdate();
    for (const el of Array.from(
      this.canvas.nativeElement.querySelectorAll<HTMLElement>(':scope > .grid-stack-item'),
    )) {
      if (!(el as any).gridstackNode) {
        const i = this.items().find((x) => x.id === el.getAttribute('gs-id'));
        if (i)
          this.grid.makeWidget(el, {
            id: i.id,
            x: i.x,
            y: i.y,
            w: i.w,
            h: i.h,
            minH: i.kind === 'section' ? 1 : 2,
            maxH: 24,
          });
      }
    }
    if (this.grid.getColumn() === 12)
      this.grid.load(
        this.items().map((i) => ({
          id: i.id,
          x: i.x,
          y: i.y,
          w: i.w,
          h: i.h,
          minH: i.kind === 'section' ? 1 : 2,
          maxH: 24,
        })),
        false,
      );
    this.grid.batchUpdate(false);
    this.grid.setStatic(this.busy() || !this.editable() || this.mobile());
    this.syncing = false;
    this.resize();
  }
  private async load(slug: string, edit: boolean) {
    const gen = ++this.generation;
    this.loading.set(true);
    this.error.set('');
    this.message.set('');
    this.previewing.set(false);
    this.readerModes.set({});
    this.editing.set(false);
    this.grid?.removeAll(false);
    this.items.set([]);
    this.models.set([]);
    this.widgets.set([]);
    this.resource.set(null);
    this.name = '';
    this.description = '';
    this.group = '';
    this.tagText = '';
    this.schemaVersion = 1;
    if (slug === 'new') {
      this.resource.set(null);
      this.name = '';
      this.description = '';
      this.group = '';
      this.tagText = '';
    }
    try {
      let placements: Placement[] = [];
      if (slug !== 'new') {
        this.editing.set(edit);
        const d = await this.workspace.get<DashboardConfiguration>(
          'dashboards',
          slug,
          !this.editing(),
        );
        if (gen !== this.generation) return;
        this.resource.set(d);
        this.name = d.name;
        this.description = d.description;
        this.group = d.body.group ?? '';
        this.tagText = (d.body.tags ?? []).join(', ');
        this.schemaVersion = d.body.schemaVersion === 2 ? 2 : 1;
        placements = flattenDashboard(d.body);
      } else {
        this.editing.set(true);
      }
      if (this.editing()) {
        const [models, widgets] = await Promise.all([
          this.workspace.list<ModelResource['body']>('models'),
          this.workspace.list<WidgetResource['body']>('widgets', true),
        ]);
        if (gen !== this.generation) return;
        this.models.set(models as unknown as ModelResource[]);
        this.widgets.set(widgets as unknown as WidgetResource[]);
      } else {
        this.models.set([]);
        this.widgets.set([]);
      }
      const dashboard = this.resource();
      const rendered = await Promise.all(
        placements.map(async (i) => {
          if (!isDataElement(i)) return i;
          if (!dashboard) throw new Error('Dashboard content is unavailable.');
          const view = this.editing() ? 'draft' : 'published';
          const query = new URLSearchParams({ view });
          if (view === 'published') query.set('revision', String(dashboard.version));
          const { widget, model } = await this.workspace.placement(
            slug,
            i.id,
            view,
            view === 'published' ? dashboard.version : undefined,
          );
          return {
            ...i,
            widget,
            model,
            configuration: effectiveElementConfiguration(i, widget.body),
            dataScope: {
              dashboardSlug: slug,
              placementId: i.id,
              view,
              ...(view === 'published' ? { revision: dashboard.version } : {}),
            } as DashboardDataScope,
          };
        }),
      );
      if (gen !== this.generation) return;
      this.grid?.removeAll(false);
      this.items.set(rendered);
      this.resetFilters();
      this.remember();
      this.needsSync = true;
    } catch (e) {
      if (gen === this.generation) this.error.set(e instanceof Error ? e.message : String(e));
    } finally {
      if (gen === this.generation) this.loading.set(false);
    }
  }
  modelName(id: string | null) {
    return this.models().find((m) => m.id === id)?.name ?? 'Model';
  }
  modelCount() {
    return new Set(this.items().flatMap((i) => (i.model ? [i.model.id] : []))).size;
  }
  editable() {
    return this.editing() && !this.previewing();
  }
  private setBusy(value: boolean) {
    this.busy.set(value);
    this.grid?.setStatic(value || !this.editable() || this.mobile());
  }
  togglePreview() {
    this.readerModes.set({});
    this.previewing.set(!this.previewing());
    this.grid?.setStatic(!this.editable() || this.mobile());
    this.needsSync = true;
    // Switching toolbars changes the available viewport; resize grids and charts afterward.
    requestAnimationFrame(() => window.dispatchEvent(new Event('resize')));
  }
  async tour() {
    const { DashboardTourComponent } = await import('./dashboard-tour.component');
    this.dialog.open(DashboardTourComponent, {
      data: { existing: true },
      width: '680px',
      maxWidth: '94vw',
    });
  }
  pickerGroups() {
    return this.models()
      .map((model) => ({
        id: model.id,
        name: model.name,
        widgets: this.widgets().filter((widget) => widget.modelId === model.id),
      }))
      .filter((model) => model.widgets.length);
  }
  sections() {
    return this.items().filter((item) => item.kind === 'section');
  }
  readonly isView = isViewElement;
  title(item: RenderedPlacement) {
    return elementTitle(item, item.widget);
  }
  icon(item: RenderedPlacement) {
    return elementIcon(item);
  }
  sectionTitle(id: string) {
    return this.items().find((item) => item.id === id)?.title || 'Section';
  }
  sectionSize(id: string) {
    return this.items().filter((item) => item.sectionId === id).length;
  }
  arrange() {
    if (!this.editable() || this.busy()) return;
    this.items.set(arrangeDashboard(this.items()));
    this.needsSync = true;
  }
  async editElement(item: RenderedPlacement) {
    if (!this.editable() || this.busy()) return;
    const value = await firstValueFrom(
      this.dialog
        .open(DashboardElementDialogComponent, {
          data: {
            item: placementBody({ ...item, title: this.title(item) }),
            sections: this.sections(),
            items: this.items(),
            hasChart: !!item.configuration?.chart,
            hasFilterCategory: !!item.configuration?.chart?.plan.categoryColumnId,
          },
          width: '540px',
          maxWidth: 'calc(100vw - 24px)',
          enterAnimationDuration: 100,
          exitAnimationDuration: 70,
        })
        .afterClosed(),
    );
    if (!value) return;
    this.items.update((items) =>
      items.map((current) =>
        current.id === item.id
          ? {
              ...current,
              ...value,
              interactions: value.interactions,
              ...(current.widget
                ? {
                    configuration: effectiveElementConfiguration(
                      { ...current, ...value },
                      current.widget.body,
                    ),
                  }
                : {}),
            }
          : current,
      ),
    );
    if (value.displayMode === 'both')
      this.items.set(placementDisplayMode(this.items(), item.id, 'both', true));
    if (value.sectionId !== item.sectionId) this.arrange();
    this.needsSync = true;
  }
  isVisualData(item: RenderedPlacement) {
    return (
      !!item.model &&
      !!item.configuration &&
      (this.isView(item) || item.kind === 'chart' || item.kind === 'table')
    );
  }
  filterColumnsFor(item: RenderedPlacement) {
    return [
      ...(item.model?.body.columns ?? []),
      ...(item.widget?.body.calculatedColumns ?? []).map((definition) =>
        calculatedColumnSpec(definition, item.model?.body.columns),
      ),
    ];
  }
  async configureFilter(item: RenderedPlacement, adding = false) {
    if (!this.editable() || this.busy() || !item.widget || !item.model || item.kind !== 'filter')
      return;
    const generation = this.generation;
    const { DashboardFilterSettingsComponent } = await import(
      './dashboard-filter-settings.component'
    );
    const value = (await firstValueFrom(
      this.dialog
        .open(DashboardFilterSettingsComponent, {
          data: { item: placementBody(item), widget: item.widget, model: item.model },
          width: '700px',
          maxWidth: 'calc(100vw - 24px)',
          enterAnimationDuration: 100,
          exitAnimationDuration: 70,
        })
        .afterClosed(),
    )) as Placement | undefined;
    if (!value || generation !== this.generation || !this.editable()) return;
    const updated = {
      ...item,
      ...value,
      configuration: effectiveElementConfiguration(value, item.widget.body),
    };
    this.items.update((items) =>
      adding
        ? [...items, updated]
        : items.map((current) => (current.id === item.id ? updated : current)),
    );
    this.resetFilter(updated);
    this.scopeCache.delete(updated.id);
    this.schemaVersion = 2;
    if (adding && updated.sectionId) this.arrange();
    this.needsSync = true;
    this.message.set(
      'Filter controls saved in this draft. Publish the dashboard to make them available to readers.',
    );
  }
  latestRevision(item: RenderedPlacement): number | undefined {
    const latest = this.widgets().find((widget) => widget.id === item.widgetId)?.publishedVersion;
    return latest && latest > (item.widgetRevision ?? 0) ? latest : undefined;
  }
  async updateSourceRevision(item: RenderedPlacement) {
    if (!this.editable() || this.busy() || !item.widgetId || !this.latestRevision(item)) return;
    const generation = this.generation;
    try {
      const widget = (await this.workspace.get<WidgetConfiguration>(
        'widgets',
        item.widgetId,
        true,
      )) as WidgetResource;
      const model = (await this.workspace.get<ModelResource['body']>(
        'models',
        widget.modelId!,
      )) as ModelResource;
      if (generation !== this.generation || !this.editable()) return;
      if (item.kind === 'chart' && !pinnedChart(widget.body, item.chartId!))
        throw new Error(
          'This chart is absent from the latest published view. Choose a replacement chart from the element library.',
        );
      const next: RenderedPlacement = {
        ...item,
        widgetRevision: widget.publishedVersion!,
        widget,
        model,
      };
      next.configuration = effectiveElementConfiguration(next, widget.body);
      this.items.update((items) =>
        items.map((current) => (current.id === item.id ? next : current)),
      );
      this.resetFilter(next);
      this.scopeCache.delete(item.id);
      this.message.set(
        `Updated to ${widget.name} revision ${widget.publishedVersion}. Dashboard settings and placement are preserved.`,
      );
    } catch (error) {
      this.error.set(
        error instanceof Error ? error.message : 'Unable to update the view revision.',
      );
    }
  }
  async addElement(kind: 'section' | 'image' | 'powerbi' | 'text' | 'html') {
    if (!this.editable() || this.busy() || this.items().length >= 48) return;
    const w = kind === 'section' ? 12 : 6;
    const h = kind === 'section' ? 2 : kind === 'text' || kind === 'html' ? 3 : 6;
    const item: Placement = {
      id: crypto.randomUUID(),
      kind,
      ...openPlacement(this.items(), w, h),
      w,
      h,
      title: '',
      description: '',
      tone: 'neutral',
    };
    const value = await firstValueFrom(
      this.dialog
        .open(DashboardElementDialogComponent, {
          data: { item, sections: this.sections(), items: this.items(), new: true },
          width: '540px',
          maxWidth: 'calc(100vw - 24px)',
          enterAnimationDuration: 100,
          exitAnimationDuration: 70,
        })
        .afterClosed(),
    );
    if (value) {
      this.items.update((items) => [...items, value]);
      if (value.sectionId) this.arrange();
      this.needsSync = true;
    }
  }
  async chooseTemplate() {
    if (!this.editable() || this.busy() || this.loading()) return;
    const result = await firstValueFrom(
      this.dialog
        .open(DashboardTemplateDialogComponent, {
          data: { models: this.models(), replacing: !!this.items().length },
          width: '660px',
          maxWidth: 'calc(100vw - 24px)',
          enterAnimationDuration: 100,
          exitAnimationDuration: 70,
        })
        .afterClosed(),
    );
    if (!result) return;
    const placements = templatePlacements(
      result.template,
      this.widgets().filter((widget) => !result.modelId || widget.modelId === result.modelId),
    );
    const items: RenderedPlacement[] = placements.map((item) => {
      if (item.kind !== 'view') return item;
      const widget = this.widgets().find((widget) => widget.id === item.widgetId)!;
      const model = this.models().find((model) => model.id === widget.modelId)!;
      return {
        ...item,
        widget,
        model,
        configuration: placementConfiguration(widget.body, item.title, item.viewOverrides),
      };
    });
    this.grid?.removeAll(false);
    this.items.set(items);
    this.needsSync = true;
    if (!this.name.trim())
      this.name =
        result.template === 'overview'
          ? 'Performance overview'
          : result.template === 'comparison'
            ? 'Comparison dashboard'
            : 'Data story';
    this.message.set(
      'Template applied to your draft. Edit the headings and views, then save when ready.',
    );
  }
  async add(sectionId?: string) {
    if (this.loading() || this.busy() || !this.editable()) return;
    const generation = this.generation;
    const { DashboardViewPickerComponent } = await import('./dashboard-view-picker.component');
    const choice = (await firstValueFrom(
      this.dialog
        .open(DashboardViewPickerComponent, {
          data: {
            widgets: this.widgets(),
            models: this.models(),
            sections: this.sections(),
            sectionId,
          },
          width: '960px',
          maxWidth: 'calc(100vw - 24px)',
          enterAnimationDuration: 100,
          exitAnimationDuration: 70,
        })
        .afterClosed(),
    )) as PublishedViewChoice | undefined;
    if (generation !== this.generation || !this.editable()) return;
    if (choice && 'powerBi' in choice) {
      if (this.items().length >= 48) return;
      const report = choice.powerBi;
      this.items.update((items) => [
        ...items,
        {
          id: crypto.randomUUID(),
          kind: 'powerbi',
          title: report.name,
          description: report.description,
          embedUrl: report.embedUrl,
          ...(choice.sectionId ? { sectionId: choice.sectionId } : {}),
          ...openPlacement(items, 12, 8),
        },
      ]);
      if (choice.sectionId) this.arrange();
      this.needsSync = true;
      return;
    }
    if (!choice || !('element' in choice)) return;
    const widget = choice.element.widget;
    const model = this.models().find((m) => m.id === widget.modelId);
    if (!widget || !model || !widget.publishedVersion || this.items().length >= 48) return;
    const item: RenderedPlacement = {
      ...catalogPlacement(choice.element, this.items(), choice.sectionId),
      widget,
      model,
      configuration: structuredClone(widget.body),
    };
    item.configuration = effectiveElementConfiguration(item, widget.body);
    if (item.kind === 'view') {
      await this.configureView(item, true);
    } else if (item.kind === 'filter') {
      await this.configureFilter(item, true);
    } else {
      this.schemaVersion = 2;
      this.items.update((items) => [...items, item]);
      if (this.sections().length) this.arrange();
      this.needsSync = true;
      this.message.set(
        `${this.title(item)} added. Drag to position it or use Element actions to choose a section.`,
      );
    }
  }
  updateChartScope(item: RenderedPlacement, scope: ViewChartDataScope) {
    if (!item.configuration?.chart) return;
    const chart = { ...item.configuration.chart, dataScope: scope };
    this.updateElementConfiguration(item, { ...item.configuration, chart, charts: [chart] });
  }
  updateChartPresentation(item: RenderedPlacement, presentation: ChartPresentation | null) {
    if (!item.configuration?.chart) return;
    const chart = { ...item.configuration.chart, presentation };
    this.updateElementConfiguration(item, { ...item.configuration, chart, charts: [chart] });
  }
  singleChart(item: RenderedPlacement) {
    return item.configuration && viewCharts(item.configuration).length === 1;
  }
  /** A chart-only tile keeps the exact source revision and query scope without a nested view card. */
  breakOutChart(item: RenderedPlacement) {
    if (
      !this.editable() ||
      this.busy() ||
      !item.widget ||
      !item.configuration ||
      !this.singleChart(item)
    )
      return;
    const chart = viewCharts(independentChartConfiguration(item.configuration))[0];
    const source = pinnedChart(item.widget.body, chart.id);
    if (!source) return;
    const next: RenderedPlacement = {
      ...item,
      kind: 'chart',
      chartId: chart.id,
      displayMode: undefined,
      viewOverrides: undefined,
      overrides: minimalChartOverrides(source, chart, {
        source: item.widget.body.allowDownload !== false,
        effective: item.configuration.allowDownload !== false,
      }),
      interactions: item.interactions?.selectFilter ? { selectFilter: true } : undefined,
    };
    next.configuration = effectiveElementConfiguration(next, item.widget.body);
    this.schemaVersion = 2;
    this.items.update((items) => items.map((current) => (current.id === item.id ? next : current)));
    this.needsSync = true;
    this.message.set('Chart broken out. Its filters and shared data source are preserved.');
  }
  separateView(item: RenderedPlacement) {
    if (!this.editable() || this.busy() || !item.widget || !item.configuration) return;
    const configuration = independentChartConfiguration(item.configuration);
    const elements = catalogElements([{ ...item.widget, body: configuration }]).filter(
      (element) => element.kind !== 'view' && element.kind !== 'filter',
    );
    if (this.items().length - 1 + elements.length > 48) return;
    const remaining = this.items().filter((current) => current.id !== item.id);
    for (const element of elements) {
      const next: RenderedPlacement = {
        ...catalogPlacement(element, remaining, item.sectionId),
        widgetRevision: item.widgetRevision,
        widget: item.widget,
        model: item.model,
      };
      // A separated chart and table retain the parent's authorized dashboard cohort and cache.
      if (item.dataScope) next.dataScope = { ...item.dataScope, placementId: next.id };
      if (next.kind === 'chart' && item.interactions?.selectFilter)
        next.interactions = { selectFilter: true };
      if (next.kind === 'chart' && next.chartId) {
        const source = pinnedChart(item.widget.body, next.chartId);
        const effective = pinnedChart(configuration, next.chartId);
        if (source && effective)
          next.overrides = minimalChartOverrides(source, effective, {
            source: item.widget.body.allowDownload !== false,
            effective: item.configuration.allowDownload !== false,
          });
      } else next.overrides = minimalTableOverrides(item.widget.body, item.configuration);
      next.configuration = effectiveElementConfiguration(next, item.widget.body);
      remaining.push(next);
    }
    const el = this.canvas?.nativeElement.querySelector<HTMLElement>(`[gs-id="${item.id}"]`);
    if (el) this.grid?.removeWidget(el, false, false);
    this.schemaVersion = 2;
    this.items.set(remaining);
    if (this.sections().length) this.arrange();
    this.needsSync = true;
    this.message.set(
      'Charts and table separated. Each element can be moved, resized and filtered independently.',
    );
  }
  updateElementConfiguration(item: RenderedPlacement, configuration: WidgetConfiguration) {
    if (!this.editable() || this.busy() || !item.widget) return;
    const source = item.chartId ? pinnedChart(item.widget.body, item.chartId) : undefined;
    const overrides =
      item.kind === 'chart' && source && configuration.chart
        ? minimalChartOverrides(source, configuration.chart, {
            source: item.widget.body.allowDownload !== false,
            effective: configuration.allowDownload !== false,
          })
        : minimalTableOverrides(item.widget.body, configuration);
    this.items.update((items) =>
      items.map((current) =>
        current.id === item.id
          ? { ...current, overrides, configuration: structuredClone(configuration) }
          : current,
      ),
    );
  }
  async configureView(item: RenderedPlacement, adding = false) {
    if (!this.editable() || this.busy() || !item.widget || !item.model) return;
    const generation = this.generation;
    const { DashboardViewSettingsComponent } = await import('./dashboard-view-settings.component');
    const value = (await firstValueFrom(
      this.dialog
        .open(DashboardViewSettingsComponent, {
          data: {
            item: placementBody(item),
            widget: item.widget,
            model: item.model,
            sections: this.sections(),
            dataScope: item.dataScope,
          },
          width: '680px',
          maxWidth: 'calc(100vw - 24px)',
          enterAnimationDuration: 100,
          exitAnimationDuration: 70,
        })
        .afterClosed(),
    )) as Placement | undefined;
    if (!value || generation !== this.generation || !this.editable()) return;
    const updated: RenderedPlacement = {
      ...item,
      ...value,
      configuration: placementConfiguration(item.widget.body, value.title, value.viewOverrides),
    };
    // Reset actions may remove optional keys, which must not survive object spreading.
    updated.viewOverrides = value.viewOverrides;
    updated.interactions = value.interactions;
    updated.title = value.title;
    updated.description = value.description;
    updated.sectionId = value.sectionId;
    this.items.update((items) =>
      adding
        ? [...items, updated]
        : items.map((current) => (current.id === item.id ? updated : current)),
    );
    if (value.displayMode === 'both')
      this.items.set(placementDisplayMode(this.items(), item.id, 'both', true));
    if (value.sectionId !== item.sectionId || (adding && value.sectionId)) this.arrange();
    this.needsSync = true;
  }
  updateViewConfiguration(item: RenderedPlacement, configuration: WidgetConfiguration) {
    if (!this.editable() || this.busy() || !item.widget) return;
    const viewOverrides = minimalViewOverrides(item.widget.body, configuration, 'inherit');
    this.items.update((items) =>
      items.map((current) =>
        current.id === item.id
          ? {
              ...current,
              configuration: structuredClone(configuration),
              viewOverrides: Object.keys(viewOverrides).length ? viewOverrides : undefined,
            }
          : current,
      ),
    );
  }
  duplicateView(item: RenderedPlacement) {
    if (!this.editable() || this.busy() || !item.widget || this.items().length >= 48) return;
    const copy: RenderedPlacement = {
      ...structuredClone(item),
      id: crypto.randomUUID(),
      ...openPlacement(this.items(), item.w, item.h),
      title: this.title(item).slice(0, 115) + ' copy',
      dataScope: undefined,
    };
    copy.configuration = effectiveElementConfiguration(copy, copy.widget!.body);
    this.items.update((items) => [...items, copy]);
    this.needsSync = true;
  }
  async remove(item: RenderedPlacement) {
    if (!this.editable() || this.busy()) return;
    if (item.kind === 'section' && this.sectionSize(item.id)) {
      const confirmed = await firstValueFrom(
        this.dialog
          .open(ResourceDialogComponent, {
            data: {
              title: 'Remove section?',
              confirm:
                'The elements in this section will remain in the dashboard without a section.',
            },
          })
          .afterClosed(),
      );
      if (!confirmed) return;
    }
    const el = this.canvas?.nativeElement.querySelector<HTMLElement>(`[gs-id="${item.id}"]`);
    this.syncing = true;
    if (el) this.grid?.removeWidget(el, false, false);
    this.items.update((items) =>
      items
        .filter((i) => i.id !== item.id)
        .map((i) => (i.sectionId === item.id ? { ...i, sectionId: undefined } : i)),
    );
    this.syncing = false;
    this.needsSync = true;
  }
  viewMode(item: RenderedPlacement) {
    if (item.kind === 'chart') return 'chart';
    if (item.kind === 'table') return 'grid';
    return (
      (!this.editable() ? this.readerModes()[item.id] : undefined) ??
      item.displayMode ??
      item.configuration?.displayMode ??
      (item.configuration?.chart ? 'chart' : 'grid')
    );
  }
  display(item: RenderedPlacement, mode: 'grid' | 'chart' | 'both') {
    if (this.busy()) return;
    if (!this.editable() && item.interactions?.switchView === false) return;
    if ((mode === 'chart' || mode === 'both') && !item.configuration?.chart) return;
    if (!this.editable()) {
      this.readerModes.update((modes) => ({ ...modes, [item.id]: mode }));
      return;
    }
    this.items.update((items) => placementDisplayMode(items, item.id, mode, this.editable()));
    if (this.editable()) this.needsSync = true;
  }
  width(item: RenderedPlacement, w: number) {
    if (!this.editable() || this.busy()) return;
    this.items.update((items) => resizePlacement(items, item.id, w, item.h));
    this.needsSync = true;
  }
  height(item: RenderedPlacement, delta: number) {
    if (!this.editable() || this.busy()) return;
    const h = Math.max(item.kind === 'section' ? 1 : 2, Math.min(24, item.h + delta));
    this.items.update((items) => resizePlacement(items, item.id, item.w, h));
    this.needsSync = true;
  }
  /** Independent elements upgrade a draft to v2; canvas coordinates are nested again on save. */
  private schemaVersion: 1 | 2 = 1;
  private body(): DashboardConfiguration {
    const items = this.schemaVersion === 2 ? nestDashboard(this.items()) : this.items();
    return {
      schemaVersion: this.schemaVersion,
      group: this.group.trim(),
      tags: [
        ...new Set(
          this.tagText
            .split(',')
            .map((tag) => tag.trim())
            .filter(Boolean),
        ),
      ],
      items: items.map(placementBody),
    };
  }
  private fingerprint() {
    return JSON.stringify({
      name: this.name.trim(),
      description: this.description.trim(),
      body: this.body(),
    });
  }
  isDirty() {
    return !this.loading() && this.fingerprint() !== this.baseline;
  }
  canLeave(): boolean | Promise<boolean> {
    if (!this.editing() || !this.isDirty()) return true;
    if (this.busy()) return false;
    return (this.pendingLeave ??= this.confirmLeave().finally(() => {
      this.pendingLeave = undefined;
    }));
  }
  private async confirmLeave(): Promise<boolean> {
    const { UnsavedChangesDialogComponent } = await import('@prism/charting');
    const action = await firstValueFrom(
      this.dialog
        .open(UnsavedChangesDialogComponent, {
          data: { name: this.name },
          width: '520px',
          maxWidth: 'calc(100vw - 24px)',
        })
        .afterClosed(),
    );
    if (action === 'discard') return true;
    if (action === 'save') return !!(await this.save(false, false));
    return false;
  }
  @HostListener('window:beforeunload', ['$event'])
  protectUnsavedChanges(event: BeforeUnloadEvent) {
    if (this.editing() && this.isDirty()) {
      event.preventDefault();
      event.returnValue = '';
    }
  }
  hasPendingPublication() {
    const resource = this.resource();
    return (
      !this.loading() &&
      (this.isDirty() || (!!resource && resource.version !== resource.publishedVersion))
    );
  }
  private remember() {
    this.baseline = this.fingerprint();
    this.savedState = {
      name: this.name,
      description: this.description,
      group: this.group,
      tagText: this.tagText,
      items: structuredClone(this.items()),
      schemaVersion: this.schemaVersion,
    };
  }
  revert() {
    if (!this.savedState || this.busy() || this.loading()) return;
    const saved = this.savedState;
    this.name = saved.name;
    this.description = saved.description;
    this.group = saved.group;
    this.tagText = saved.tagText;
    this.schemaVersion = saved.schemaVersion;
    this.grid?.removeAll(false);
    this.items.set(structuredClone(saved.items));
    this.needsSync = true;
    this.error.set('');
    this.message.set('Changes reverted.');
  }
  async save(copy: boolean, navigate = true): Promise<DashboardResource | undefined> {
    if (!this.editing() || this.loading() || this.busy()) return;
    if (!copy && !this.isDirty() && this.resource()) return this.resource()!;
    this.setBusy(true);
    this.error.set('');
    try {
      let name = this.name.trim(),
        description = this.description;
      if (copy) {
        const data = await firstValueFrom(
          this.dialog
            .open(ResourceDialogComponent, {
              data: { title: 'Save dashboard as new', name: name + ' copy', description },
            })
            .afterClosed(),
        );
        if (!data) return;
        name = data.name;
        description = data.description;
      }
      if (!name) throw new Error('Enter a dashboard name.');
      const payload = { name, description, body: this.body() };
      const old = this.resource();
      const saved =
        old && !copy
          ? await this.workspace.update('dashboards', old, payload)
          : await this.workspace.create<DashboardConfiguration>('dashboards', payload);
      this.resource.set(saved);
      this.name = saved.name;
      this.description = saved.description;
      this.group = saved.body.group ?? '';
      this.tagText = (saved.body.tags ?? []).join(', ');
      this.remember();
      this.message.set(`Saved layout version ${saved.version}.`);
      if (navigate && (!old || copy))
        await this.router.navigate(['/dashboards', saved.slug], {
          queryParams: { edit: 1 },
          replaceUrl: true,
        });
      return saved;
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : String(e));
      return;
    } finally {
      this.setBusy(false);
    }
  }
  async publish() {
    const saved = await this.save(false);
    if (!saved) return;
    this.setBusy(true);
    try {
      const published = await this.workspace.publish('dashboards', saved);
      this.resource.set(published);
      this.message.set(
        `Published dashboard revision ${published.publishedVersion}. Widget configurations are pinned.`,
      );
    } catch (e) {
      this.error.set(String(e));
    } finally {
      this.setBusy(false);
    }
  }
  async precache() {
    const d = this.resource();
    if (!d) return;
    this.setBusy(true);
    try {
      await this.workspace.precache(d.slug);
      this.message.set(
        'Cache preparation requested once per model. Subsequent views reuse the completed snapshots.',
      );
    } catch (e) {
      this.error.set(String(e));
    } finally {
      this.setBusy(false);
    }
  }
  ngOnDestroy() {
    this.generation++;
    this.sub.unsubscribe();
    this.observer?.disconnect();
    this.grid?.destroy(false);
    this.grid = undefined;
  }
}
