import { CHARTING_DATA } from '@prism/charting';
import { injectUiState } from '@prism/charting';
import { Component, Input, computed, inject } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import type { Placement } from '@prism/charting';
import { validImageUrl, validPowerBiUrl } from './dashboard-composer';

@Component({
  selector: 'workspace-dashboard-element',
  standalone: true,
  imports: [MatIconModule, MatButtonModule, MatTooltipModule],
  template: `
    @if (item.kind === 'text') {
      <div [class]="'dashboard-prose text-block tone-' + (item.tone || 'neutral')">
        {{ item.content }}
      </div>
    } @else if (item.kind === 'html') {
      <div
        [class]="'dashboard-prose html-block tone-' + (item.tone || 'neutral')"
        [innerHTML]="item.content || ''"
      ></div>
    } @else if (item.kind === 'image' && imageUrl()) {
      @if (imageFailed()) {
        <div class="element-placeholder" role="status">
          <mat-icon>broken_image</mat-icon><span>Image unavailable</span>
        </div>
      } @else {
        <img
          [src]="imageUrl()"
          [alt]="item.alt || ''"
          loading="lazy"
          decoding="async"
          referrerpolicy="no-referrer"
          (error)="imageFailed.set(true)"
        />
      }
    } @else if (item.kind === 'powerbi' && reportUrl()) {
      @if (!editing || activated()) {
        <iframe
          [src]="reportUrl()"
          [title]="item.title || 'Power BI report'"
          loading="lazy"
          referrerpolicy="no-referrer"
          allowfullscreen
          sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-downloads"
        ></iframe>
        @if (demoReport(); as report) {
          <a class="report-credit" [href]="report.source" target="_blank" rel="noopener noreferrer"
            >{{ report.author }} · View source</a
          >
        }
      } @else {
        <div class="element-placeholder">
          <mat-icon>analytics</mat-icon><strong>Power BI report</strong
          ><span>Open the configured report.</span
          ><button
            mat-icon-button
            (click)="activated.set(true)"
            aria-label="Preview Power BI report"
            matTooltip="Preview Power BI report"
          >
            <mat-icon>play_arrow</mat-icon>
          </button>
        </div>
      }
    } @else {
      <div class="element-placeholder" role="alert">
        <mat-icon>link_off</mat-icon><span>This element needs a valid source.</span>
      </div>
    }
  `,
  styles: [
    `
      :host {
        display: flex;
        flex-direction: column;
        width: 100%;
        height: 100%;
        min-height: 0;
      }
      .text-block {
        white-space: pre-wrap;
      }
      img {
        display: block;
        width: 100%;
        height: 100%;
        object-fit: contain;
      }
      iframe {
        width: 100%;
        height: 100%;
        border: 0;
        display: block;
        flex: 1;
        min-height: 0;
      }
      .report-credit {
        padding: 7px 12px;
        font-size: 11px;
        color: var(--ws-muted);
        border-top: 1px solid var(--ws-border);
      }
      .element-placeholder {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 8px;
        height: 100%;
        padding: 16px;
        text-align: center;
        color: var(--mat-sys-on-surface-variant);
        font-size: 12px;
      }
      .element-placeholder > mat-icon {
        font-size: 30px;
        width: 30px;
        height: 30px;
        color: var(--mat-sys-primary);
      }
      .element-placeholder strong {
        font-weight: 500;
        color: var(--mat-sys-on-surface);
      }
      .element-placeholder span {
        font-size: 11px;
      }
    `,
  ],
})
export class DashboardElementComponent {
  readonly hostData = inject(CHARTING_DATA);
  private readonly reactiveState = injectUiState('DashboardElementComponent');

  private readonly sanitizer = inject(DomSanitizer);
  private readonly placement = this.reactiveState.signal<Placement>({
    id: '',
    x: 0,
    y: 0,
    w: 6,
    h: 6,
  });
  @Input({ required: true }) set item(value: Placement) {
    if (value.imageUrl !== this.placement().imageUrl) this.imageFailed.set(false);
    if (value.embedUrl !== this.placement().embedUrl) this.activated.set(false);
    this.placement.set(value);
  }
  get item() {
    return this.placement();
  }
  @Input() editing = false;
  readonly activated = this.reactiveState.signal(false);
  readonly imageFailed = this.reactiveState.signal(false);
  readonly demoReport = computed(() =>
    (this.hostData.reports ?? []).find((report) => report.embedUrl === this.placement().embedUrl),
  );
  readonly imageUrl = computed(() =>
    validImageUrl(this.placement().imageUrl || '') ? this.placement().imageUrl! : '',
  );
  readonly reportUrl = computed(() =>
    validPowerBiUrl(this.placement().embedUrl || '')
      ? this.sanitizer.bypassSecurityTrustResourceUrl(this.placement().embedUrl!)
      : null,
  );
}
