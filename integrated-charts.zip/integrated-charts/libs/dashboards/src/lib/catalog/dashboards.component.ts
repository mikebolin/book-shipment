import { injectUiState } from '@prism/charting';
import { Component, computed, inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDialog } from '@angular/material/dialog';
import { Clipboard } from '@angular/cdk/clipboard';
import { firstValueFrom } from 'rxjs';
import { WorkspaceRepository } from '@prism/charting';
import { ResourceDialogComponent } from '@prism/charting';
import type { WorkspaceCard } from '@prism/charting';
import type { DashboardConfiguration } from '@prism/charting';
import { ResourceGalleryComponent } from '@prism/charting';
import { ResourceCardComponent, type CardAction } from '@prism/charting';
import { ConfirmDialogComponent } from '@prism/charting';
import { UserPreferencesService } from '@prism/charting';
import {
  GALLERY_DEFAULTS,
  cardStatus,
  galleryStateFromParams,
  matchesCard,
  sortCards,
  writeGalleryState,
  type GalleryState,
} from '@prism/charting';

/** The Dashboards gallery: the same cards and toolbar as Views, with local draft and published views. */
@Component({
  standalone: true,
  imports: [
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    ResourceGalleryComponent,
    ResourceCardComponent,
  ],
  template: `
    <workspace-resource-gallery
      title="Dashboards"
      description="Bring charts, tables and context together in one place for your readers."
      noun="dashboard"
      [count]="dashboards().length"
      searchPlaceholder="Search dashboards"
      searchLabel="Search dashboards"
      [publicationTabs]="true"
      publicationLabel="Dashboard publication"
      [groups]="groups()"
      [tags]="tags()"
      [summary]="summary()"
      [loading]="loading()"
      [error]="error()"
      [state]="state()"
      (stateChange)="update($event)"
    >
      <ng-container gallery-primary>
        <button
          mat-icon-button
          type="button"
          (click)="tour()"
          aria-label="Dashboard tour"
          matTooltip="Dashboard tour"
        >
          <mat-icon>help_outline</mat-icon>
        </button>

        <button
          mat-icon-button
          type="button"
          class="create-action"
          (click)="create()"
          aria-label="Create dashboard"
          matTooltip="Create dashboard"
        >
          <mat-icon>add</mat-icon>
        </button>
      </ng-container>
      <div class="resource-grid" [class.resource-list]="state().density === 'list'">
        @for (dashboard of filtered(); track dashboard.id) {
          <workspace-resource-card
            kind="dashboard"
            [name]="dashboard.name"
            [description]="dashboard.description"
            fallbackDescription="A workspace for related insights."
            [preview]="dashboard.preview"
            [kicker]="kicker(dashboard)"
            [tags]="dashboard.tags ?? []"
            [selectedTag]="state().tag"
            [status]="status(dashboard)"
            [updatedAt]="dashboard.updatedAt"
            [visibility]="dashboard.visibility ?? ''"
            [density]="state().density"
            [openLink]="['/dashboards', dashboard.slug]"
            [openQuery]="openQuery(dashboard)"
            [editLink]="dashboard.canEdit ? ['/dashboards', dashboard.slug] : null"
            [editQuery]="{ edit: '1' }"
            editLabel="Edit dashboard"
            [actions]="actions(dashboard)"
            (action)="run(dashboard, $event)"
            (tagSelect)="update({ tag: state().tag === $event ? '' : $event })"
          />
        }
      </div>
      @if (!loading() && !filtered().length) {
        <div class="empty-state">
          <div class="empty-icon"><mat-icon>dashboard_customize</mat-icon></div>
          <h2>{{ dashboards().length ? 'No matching dashboards' : 'No dashboards yet' }}</h2>
          <p>
            {{
              dashboards().length
                ? 'Try another search, group, or tag.'
                : true
                  ? 'Create a private dashboard, then place charts, tables and notes on it.'
                  : 'Dashboards shared with you will appear here once published.'
            }}
          </p>
          @if (dashboards().length) {
            <button mat-button type="button" (click)="update({ q: '', group: '', tag: '' })">
              Clear filters
            </button>
          } @else if (true) {
            <button
              mat-button
              type="button"
              (click)="create()"
              aria-label="Create your first dashboard"
            >
              <mat-icon>add</mat-icon>Create dashboard
            </button>
          }
        </div>
      }
    </workspace-resource-gallery>
  `,
  styles: `
    .resource-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(min(100%, 280px), min(100%, 344px)));
      gap: 20px;
      align-items: stretch;
    }
    @container (min-width: 480px) and (max-width: 720px) {
      .resource-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
      }
    }
    .resource-grid.resource-list {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .create-action {
      color: var(--mat-sys-on-primary);
      background: var(--mat-sys-primary);
    }
    .empty-state button mat-icon {
      margin-right: 6px;
    }
  `,
})
export class DashboardsComponent {
  private readonly reactiveState = injectUiState('DashboardsComponent');

  readonly workspace = inject(WorkspaceRepository);
  private readonly dialog = inject(MatDialog);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly clipboard = inject(Clipboard);
  private readonly preferences = inject(UserPreferencesService);
  readonly dashboards = computed(() =>
    this.workspace.store.cards('dashboards', this.state().pub === 'published'),
  );
  readonly error = this.reactiveState.signal('');
  readonly loading = this.reactiveState.signal(true);
  readonly state = this.reactiveState.signal<GalleryState>({ ...GALLERY_DEFAULTS });
  private generation = 0;

  constructor() {
    const settings = this.preferences.settings();
    this.state.set(
      galleryStateFromParams(this.route.snapshot.queryParams, {
        ...GALLERY_DEFAULTS,
        density: settings.galleryDensity,
      }),
    );
    void this.load();
  }

  update(patch: Partial<GalleryState>) {
    const previous = this.state();
    const next = { ...previous, ...patch };
    this.state.set(next);
    writeGalleryState(this.router, this.route, next, GALLERY_DEFAULTS);
    if (patch.density)
      void this.preferences
        .updateSettings({ galleryDensity: patch.density })
        .catch(() => undefined);
    if (patch.pub && patch.pub !== previous.pub) void this.load();
  }

  async load() {
    const generation = ++this.generation;
    this.loading.set(true);
    this.error.set('');
    try {
      const cards = await this.workspace.cards('dashboards', this.state().pub);
      // Cards derive from canonical resources and publications.
    } catch (e) {
      if (generation === this.generation) {
        this.error.set(e instanceof Error ? e.message : String(e));
      }
    } finally {
      if (generation === this.generation) this.loading.set(false);
    }
  }

  readonly groups = computed(() =>
    [
      ...new Set(
        this.dashboards()
          .map((d) => d.group ?? '')
          .filter(Boolean),
      ),
    ].sort(),
  );
  readonly tags = computed(() =>
    [...new Set(this.dashboards().flatMap((d) => d.tags ?? []))].sort(),
  );
  readonly filtered = computed(() => {
    const state = this.state();
    return sortCards(
      this.dashboards().filter((d) => matchesCard(d, state)),
      state.sort === 'model' ? 'name' : state.sort,
    );
  });
  readonly summary = computed(() => {
    const count = this.filtered().length;
    return `${count} ${count === 1 ? 'dashboard' : 'dashboards'}${this.state().pub === 'draft' ? ' · editable versions' : ''}`;
  });

  kicker(dashboard: WorkspaceCard) {
    const items = dashboard.itemCount ?? 0;
    const charts = dashboard.chartCount ?? 0;
    return `${items} ${items === 1 ? 'element' : 'elements'}${charts ? ` · ${charts} ${charts === 1 ? 'chart' : 'charts'}` : ''}`;
  }
  status(dashboard: WorkspaceCard) {
    return cardStatus(dashboard, this.state().pub);
  }
  openQuery(dashboard: WorkspaceCard) {
    return this.state().pub === 'draft' || !dashboard.publishedVersion ? { edit: '1' } : null;
  }
  actions(dashboard: WorkspaceCard): CardAction[] {
    return [
      ...(dashboard.publishedVersion
        ? [{ id: 'open', label: 'Open published', icon: 'public' }]
        : []),
      ...(dashboard.canEdit ? [{ id: 'edit', label: 'Edit', icon: 'edit' }] : []),
      ...(dashboard.canEdit ? [{ id: 'duplicate', label: 'Duplicate', icon: 'content_copy' }] : []),
      ...(dashboard.publishedVersion ? [{ id: 'copyLink', label: 'Copy link', icon: 'link' }] : []),
      ...(dashboard.canDelete
        ? [
            {
              id: 'delete',
              label: 'Delete',
              icon: 'delete_outline',
              destructive: true,
              divider: true,
            },
          ]
        : []),
    ];
  }
  async run(dashboard: WorkspaceCard, id: string) {
    try {
      switch (id) {
        case 'open':
          return void this.router.navigate(['/dashboards', dashboard.slug]);
        case 'edit':
          return void this.router.navigate(['/dashboards', dashboard.slug], {
            queryParams: { edit: 1 },
          });
        case 'duplicate':
          return this.duplicate(dashboard);
        case 'copyLink':
          this.clipboard.copy(new URL(`/dashboards/${dashboard.slug}`, location.origin).toString());
          return;
        case 'delete':
          return this.remove(dashboard);
      }
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : String(error));
    }
  }
  async tour() {
    const { DashboardTourComponent } = await import('../dashboard-tour.component');
    const result = await firstValueFrom(
      this.dialog
        .open(DashboardTourComponent, {
          data: { existing: false },
          width: '680px',
          maxWidth: '94vw',
        })
        .afterClosed(),
    );
    if (result === 'create' && true) await this.create();
  }
  async create() {
    const value = await firstValueFrom(
      this.dialog
        .open(ResourceDialogComponent, {
          width: '520px',
          maxWidth: 'calc(100vw - 32px)',
          data: {
            title: 'Create dashboard',
            subtitle: 'Give your dashboard a name and help readers find it.',
            actionLabel: 'Create dashboard',
            metadata: true,
          },
        })
        .afterClosed(),
    );
    if (!value) return;
    try {
      const resource = await this.workspace.create<DashboardConfiguration>('dashboards', {
        name: value.name,
        description: value.description,
        body: { schemaVersion: 2, items: [], group: value.group, tags: value.tags },
      });
      await this.router.navigate(['/dashboards', resource.slug], { queryParams: { edit: 1 } });
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : String(e));
    }
  }
  private async duplicate(dashboard: WorkspaceCard) {
    const draft = await this.workspace.get<DashboardConfiguration>('dashboards', dashboard.slug);
    const copy = await this.workspace.create<DashboardConfiguration>('dashboards', {
      name: `${draft.name} copy`,
      description: draft.description,
      body: structuredClone(draft.body),
    });
    await this.router.navigate(['/dashboards', copy.slug], { queryParams: { edit: 1 } });
  }
  private async remove(dashboard: WorkspaceCard) {
    const confirmed = await firstValueFrom(
      this.dialog
        .open(ConfirmDialogComponent, {
          data: {
            title: `Delete ${dashboard.name}?`,
            message:
              'The dashboard and all of its revisions are removed. The views it uses are kept.',
            confirmLabel: 'Delete dashboard',
            destructive: true,
          },
          width: '480px',
          maxWidth: 'calc(100vw - 24px)',
        })
        .afterClosed(),
    );
    if (!confirmed) return;
    try {
      const draft = await this.workspace.get<DashboardConfiguration>('dashboards', dashboard.slug);
      await this.workspace.remove('dashboards', draft);
      await this.load();
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : String(e));
    }
  }
}
