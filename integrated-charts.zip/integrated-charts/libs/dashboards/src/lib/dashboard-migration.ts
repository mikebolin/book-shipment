import type { DashboardConfiguration, Placement } from '@prism/charting';
import { richTextFromPlainText } from './rich-text';

/**
 * Dashboard schema migration (v1 → v2). The Java twin (DashboardMigration.java) applies the same
 * rules when a v1 revision is read through the placements API; published v1 revisions are never
 * rewritten in the database, and saving a draft writes v2.
 *
 * v2 rules: elements are a flat list with 12-column geometry; a section is a container whose children
 * keep `sectionId` and store x/y relative to the section's content grid (12 columns, rows from 0).
 * A section's stored `h` is its full rendered height (header plus children) and is derived again
 * whenever the composer renders it.
 */
export const SECTION_HEADER_ROWS = 1;
export const MAX_TOP_LEVEL_ELEMENTS = 48;
export const MAX_ELEMENTS = 120;

export function elementKind(item: Pick<Placement, 'kind'>): NonNullable<Placement['kind']> {
  return item.kind ?? 'view';
}
export function isSection(item: Pick<Placement, 'kind'>): boolean {
  return item.kind === 'section';
}
export function topLevelItems<T extends Placement>(items: readonly T[]): T[] {
  const sections = new Set(items.filter(isSection).map((item) => item.id));
  return items.filter((item) => !item.sectionId || !sections.has(item.sectionId));
}
export function childrenOf<T extends Placement>(items: readonly T[], sectionId: string): T[] {
  return items.filter((item) => item.sectionId === sectionId && !isSection(item));
}
export function overlaps(
  a: Pick<Placement, 'x' | 'y' | 'w' | 'h'>,
  b: Pick<Placement, 'x' | 'y' | 'w' | 'h'>,
): boolean {
  return a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
}

/**
 * Pushes elements down, in reading order, until none overlap within the chosen containers:
 * the top level, every section's children, or both. Elements keep their original order.
 */
export function resolveOverlaps<T extends Placement>(
  items: readonly T[],
  scope: 'top' | 'children' | 'all' = 'all',
): T[] {
  const sections = new Set(items.filter(isSection).map((item) => item.id));
  const containerOf = (item: T) =>
    item.sectionId && sections.has(item.sectionId) && !isSection(item) ? item.sectionId : '';
  const containers = new Set(items.map(containerOf));
  const updates = new Map<string, T>();
  for (const container of containers) {
    if ((container === '' && scope === 'children') || (container !== '' && scope === 'top'))
      continue;
    const members = items
      .map((item, index) => ({ item, index }))
      .filter(({ item }) => containerOf(item) === container)
      .sort((a, b) => a.item.y - b.item.y || a.item.x - b.item.x || a.index - b.index);
    const placed: T[] = [];
    for (const { item } of members) {
      let next = item;
      let blockers: T[];
      while ((blockers = placed.filter((other) => overlaps(next, other))).length)
        next = { ...next, y: Math.max(...blockers.map((other) => other.y + other.h)) };
      placed.push(next);
      updates.set(next.id, next);
    }
  }
  return items.map((item) => updates.get(item.id) ?? item);
}

/** Returns the ids of elements that overlap within the same container (top level or one section). */
export function containerOverlaps(items: readonly Placement[]): [string, string][] {
  const result: [string, string][] = [];
  const groups = [
    topLevelItems(items),
    ...items.filter(isSection).map((section) => childrenOf(items, section.id)),
  ];
  for (const group of groups)
    for (let a = 0; a < group.length; a++)
      for (let b = a + 1; b < group.length; b++)
        if (overlaps(group[a], group[b])) result.push([group[a].id, group[b].id]);
  return result;
}

/** Pure, deterministic and idempotent: migrating a v2 body only normalizes it. */
export function migrateDashboard(body: DashboardConfiguration): DashboardConfiguration {
  const source = structuredClone(body);
  const sections = new Map(source.items.filter(isSection).map((item) => [item.id, item]));
  const items: Placement[] = source.items.map((item) => {
    const copy: Placement = { ...item, kind: elementKind(item) };
    if (copy.sectionId && (!sections.has(copy.sectionId) || copy.kind === 'section'))
      delete copy.sectionId;
    if (copy.kind === 'section') copy.layout = 'grid';
    return copy;
  });
  const result: DashboardConfiguration = {
    ...source,
    schemaVersion: 2,
    items,
  };
  if (source.schemaVersion === 2) return result;
  result.items = items.map((item) => {
    let next = item;
    if (next.kind === 'text') {
      const { content, ...rest } = next;
      next = { ...rest, kind: 'richtext', document: richTextFromPlainText(content ?? '') };
    }
    if (next.sectionId) {
      const section = sections.get(next.sectionId)!;
      next = { ...next, y: Math.max(0, next.y - (section.y + section.h)) };
    }
    return next;
  });
  result.items = resolveOverlaps(result.items, 'children');
  result.items = result.items.map((item) =>
    item.kind === 'section'
      ? {
          ...item,
          h: item.h + Math.max(0, ...childrenOf(result.items, item.id).map((c) => c.y + c.h)),
        }
      : item,
  );
  result.items = resolveOverlaps(result.items, 'top');
  return result;
}

/**
 * Absolute coordinates for a single-level canvas: sections become header tiles and their children
 * are positioned below them. v1 bodies are already flat and pass through unchanged.
 */
export function flattenDashboard(body: DashboardConfiguration): Placement[] {
  if (body.schemaVersion !== 2) return structuredClone(body.items);
  const sections = new Map(body.items.filter(isSection).map((item) => [item.id, item]));
  return body.items.map((item) => {
    const section = item.sectionId ? sections.get(item.sectionId) : undefined;
    if (isSection(item)) return { ...item, h: Math.min(item.h, SECTION_HEADER_ROWS) };
    if (!section) return { ...item };
    const scale = section.w === 12 ? 1 : section.w / 12;
    return {
      ...item,
      x: Math.min(11, section.x + Math.floor(item.x * scale)),
      w: Math.max(1, Math.round(item.w * scale)),
      y: section.y + SECTION_HEADER_ROWS + item.y,
    };
  });
}

/** Inverse of flattenDashboard for saving a v2 body from the single-level canvas. */
export function nestDashboard(items: readonly Placement[]): Placement[] {
  const sections = new Map(items.filter(isSection).map((item) => [item.id, item]));
  const nested: Placement[] = items.map((item) => {
    const section = item.sectionId ? sections.get(item.sectionId) : undefined;
    if (isSection(item)) return { ...item, layout: 'grid' as const };
    if (!section) return { ...item };
    const scale = section.w === 12 ? 1 : 12 / section.w;
    return {
      ...item,
      x: Math.max(0, Math.min(11, Math.round((item.x - section.x) * scale))),
      w: Math.max(1, Math.min(12, Math.round(item.w * scale))),
      y: Math.max(0, item.y - section.y - SECTION_HEADER_ROWS),
    };
  });
  return nested.map((item) =>
    isSection(item)
      ? {
          ...item,
          h:
            SECTION_HEADER_ROWS +
            Math.max(0, ...childrenOf(nested, item.id).map((child) => child.y + child.h)),
        }
      : item,
  );
}
