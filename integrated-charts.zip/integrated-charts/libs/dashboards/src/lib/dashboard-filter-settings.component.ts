import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import {
  AdvancedFilterBuilderComponent,
  calculatedColumnSpec,
  fromModel,
  injectUiState,
} from '@prism/charting';
import type {
  ColumnSpec,
  DashboardControl,
  FilterDraftChange,
  GridModel,
  ModelResource,
  Placement,
  WidgetResource,
} from '@prism/charting';
import type { AdvancedFilterModel } from 'ag-grid-community';
import {
  composeDashboardControls,
  dashboardControlDraft,
  type DashboardControlDraft,
} from './dashboard-control-settings';

/** Authors configure portable reader controls here; the dashboard keeps its published source pin. */
@Component({
  standalone: true,
  imports: [
    FormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    AdvancedFilterBuilderComponent,
  ],
  template: `
    <header class="heading">
      <div>
        <h2 mat-dialog-title>Filter controls</h2>
        <p>{{ data.widget.name }} · revision {{ data.item.widgetRevision }}</p>
      </div>
      <button mat-icon-button mat-dialog-close aria-label="Cancel filter control settings">
        <mat-icon>close</mat-icon>
      </button>
    </header>
    <mat-dialog-content>
      <p class="hint">
        These controls apply to charts and tables using {{ data.model.name }}. Readers can change
        their values; the defaults are saved with this dashboard.
      </p>
      <label class="field"
        >Title<input [(ngModel)]="title" maxlength="120" aria-label="Filter controls title"
      /></label>
      <div class="control-list">
        @for (control of drafts; track control.id; let index = $index) {
          <details class="control-card" [open]="openedId === control.id">
            <summary>
              <span class="control-heading"
                ><strong>{{ control.label || typeLabel(control.type) }}</strong
                ><span>{{ bindingLabel(control) }}</span></span
              >
              <span class="control-actions">
                <button
                  mat-icon-button
                  type="button"
                  [disabled]="index === 0"
                  (click)="move(index, -1, $event)"
                  aria-label="Move control up"
                  matTooltip="Move up"
                >
                  <mat-icon>arrow_upward</mat-icon>
                </button>
                <button
                  mat-icon-button
                  type="button"
                  [disabled]="index === drafts.length - 1"
                  (click)="move(index, 1, $event)"
                  aria-label="Move control down"
                  matTooltip="Move down"
                >
                  <mat-icon>arrow_downward</mat-icon>
                </button>
                <button
                  mat-icon-button
                  type="button"
                  (click)="remove(index, $event)"
                  aria-label="Remove control"
                  matTooltip="Remove control"
                >
                  <mat-icon>delete_outline</mat-icon>
                </button>
              </span>
            </summary>
            <div class="control-fields">
              <label class="field"
                >Label<input [(ngModel)]="control.label" maxlength="120" aria-label="Control label"
              /></label>
              @if (control.type === 'window' || control.type === 'values') {
                <label class="field"
                  >Field<select
                    [ngModel]="control.columnId"
                    (ngModelChange)="setColumn(control, $event)"
                    aria-label="Control field"
                  >
                    <option value="">Choose a field</option>
                    @for (column of eligibleColumns(control.type); track column.id) {
                      <option [value]="column.id">{{ column.label }}</option>
                    }
                  </select></label
                >
              }
              @if (control.type === 'window') {
                <label class="field"
                  >Window presets (minutes)<input
                    [(ngModel)]="control.optionsText"
                    placeholder="15, 30, 60, 180"
                    aria-label="Window presets"
                /></label>
                <label class="field"
                  >Default window<select
                    [(ngModel)]="control.defaultMinutes"
                    aria-label="Default window"
                  >
                    <option [ngValue]="null">Keep the saved filter</option>
                    @for (minutes of numericOptions(control); track minutes) {
                      <option [ngValue]="minutes">{{ minutes }} minutes</option>
                    }
                  </select></label
                >
                <label class="field"
                  >Window ends at<select [(ngModel)]="control.anchor" aria-label="Window anchor">
                    <option value="saved">Saved filter end</option>
                    <option value="now">Current time when opened</option>
                    <option value="fixed">Fixed time (UTC)</option>
                  </select></label
                >
                @if (control.anchor === 'fixed') {
                  <label class="field"
                    >Window end (UTC)<input
                      [(ngModel)]="control.endsAt"
                      placeholder="2026-10-03T12:00:00"
                      aria-label="Window end UTC"
                  /></label>
                }
              }
              @if (control.type === 'bucket') {
                <label class="field"
                  >Bucket presets (seconds)<input
                    [(ngModel)]="control.optionsText"
                    placeholder="6, 30, 60, 300, 900"
                    aria-label="Bucket presets"
                /></label>
                <label class="field"
                  >Default bucket<select
                    [(ngModel)]="control.defaultSeconds"
                    aria-label="Default bucket"
                  >
                    @for (seconds of numericOptions(control); track seconds) {
                      <option [ngValue]="seconds">{{ seconds }} seconds</option>
                    }
                  </select></label
                >
                <p class="hint wide">
                  Changes the interval of charts grouped by seconds, minutes or hours.
                </p>
              }
              @if (control.type === 'values') {
                <label class="field"
                  >Options (one per line)<textarea
                    [(ngModel)]="control.optionsText"
                    rows="3"
                    aria-label="Selector options"
                    placeholder="Leave empty to use the source field's values"
                  ></textarea>
                </label>
                <label class="field"
                  >Default selections (one per line)<textarea
                    [(ngModel)]="control.defaultValuesText"
                    rows="3"
                    aria-label="Default selections"
                  ></textarea>
                </label>
                <label class="check"
                  ><input type="checkbox" [(ngModel)]="control.multiple" />Allow multiple
                  selections</label
                >
                @if (!control.multiple) {
                  <label class="check"
                    ><input type="checkbox" [(ngModel)]="control.allowAll" />Allow all values</label
                  >
                }
              }
              @if (control.type === 'groupBy') {
                <fieldset class="group-fields wide">
                  <legend>Grouping fields</legend>
                  @for (column of columns; track column.id) {
                    <label class="check"
                      ><input
                        type="checkbox"
                        [ngModel]="control.groupColumnIds.includes(column.id)"
                        (ngModelChange)="toggleGroup(control, column.id, $event)"
                      />{{ column.label }}</label
                    >
                  }
                </fieldset>
                <label class="field"
                  >Default grouping<select
                    [(ngModel)]="control.defaultGroupBy"
                    aria-label="Default grouping"
                  >
                    @if (control.allowNone) {
                      <option value="">No grouping</option>
                    }
                    @for (id of control.groupColumnIds; track id) {
                      <option [value]="id">{{ columnLabel(id) }}</option>
                    }
                  </select></label
                >
                <label class="check"
                  ><input type="checkbox" [(ngModel)]="control.allowNone" />Allow no grouping</label
                >
              }
            </div>
          </details>
        } @empty {
          <p class="hint">
            Add a control to give readers a window, value selector or grouping choice.
          </p>
        }
      </div>
      <div class="add-control">
        <label class="field"
          >New control<select [(ngModel)]="newType" aria-label="New control type">
            <option value="window">Recent window</option>
            <option value="bucket">Time buckets</option>
            <option value="values">Value selector</option>
            <option value="groupBy">Grouping</option>
          </select></label
        >
        <button
          mat-button
          (click)="add()"
          [disabled]="drafts.length >= 24"
          aria-label="Add control"
        >
          <mat-icon>add</mat-icon>Add control
        </button>
      </div>
      <details class="conditions">
        <summary>Saved conditions</summary>
        <p class="hint">
          Control defaults replace conditions on their own fields. Other conditions always apply.
        </p>
        <app-advanced-filter-builder
          [embedded]="true"
          [inline]="true"
          [columns]="columns"
          [model]="initialModel"
          title="Saved conditions"
          (draftChange)="setConditions($event)"
        />
      </details>
      @if (error()) {
        <p class="error" role="alert">{{ error() }}</p>
      }
    </mat-dialog-content>
    <mat-dialog-actions align="end"
      ><button mat-button mat-dialog-close>Cancel</button
      ><button
        mat-button
        (click)="apply()"
        [disabled]="!conditionsValid"
        aria-label="Apply filter control settings"
      >
        Apply settings
      </button></mat-dialog-actions
    >
  `,
  styles: `
    .heading {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 12px 20px 0;
    }
    h2 {
      padding: 0 !important;
      font-size: 20px !important;
    }
    .heading p {
      margin: 0 0 12px;
      color: var(--ws-muted);
      font-size: 12px;
    }
    mat-dialog-content {
      display: flex;
      flex-direction: column;
      gap: 16px;
      padding: 12px 24px 24px !important;
    }
    .hint {
      margin: 0;
      color: var(--ws-muted);
      font-size: 12px;
      line-height: 1.5;
    }
    .field {
      display: flex;
      flex-direction: column;
      gap: 5px;
      font-size: 12px;
      color: var(--ws-muted);
      min-width: 0;
    }
    input:not([type='checkbox']),
    select,
    textarea {
      box-sizing: border-box;
      width: 100%;
      min-height: 36px;
      border: 1px solid var(--mat-sys-outline);
      border-radius: 6px;
      padding: 7px 9px;
      background: var(--mat-sys-surface-container-lowest);
      color: var(--mat-sys-on-surface);
      font: inherit;
      font-size: 13px;
    }
    input:focus-visible,
    select:focus-visible,
    textarea:focus-visible,
    summary:focus-visible {
      outline: 2px solid var(--mat-sys-primary);
      outline-offset: 2px;
    }
    textarea {
      resize: vertical;
    }
    .control-list {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
    .control-card {
      border: 1px solid var(--ws-border);
      border-radius: 8px;
    }
    summary {
      cursor: pointer;
      padding: 10px 12px;
      font-size: 13px;
    }
    .control-card > summary {
      display: flex;
      align-items: center;
      gap: 8px;
      list-style: none;
    }
    .control-card > summary::before {
      content: '›';
      font-size: 20px;
    }
    .control-card[open] > summary::before {
      transform: rotate(90deg);
    }
    summary::-webkit-details-marker {
      display: none;
    }
    .control-heading {
      display: flex;
      flex-direction: column;
      flex: 1;
      gap: 3px;
      min-width: 0;
    }
    .control-heading span {
      color: var(--ws-muted);
      font-size: 11px;
    }
    .control-actions {
      display: flex;
    }
    .control-actions button {
      --mat-icon-button-state-layer-size: 32px;
      --mat-icon-button-touch-target-display: none;
      width: 32px;
      height: 32px;
      padding: 6px;
    }
    .control-actions mat-icon {
      font-size: 18px;
      width: 18px;
      height: 18px;
    }
    .control-fields {
      border-top: 1px solid var(--ws-border);
      padding: 12px;
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
    }
    .wide {
      grid-column: 1 / -1;
    }
    .check {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 12px;
    }
    .group-fields {
      border: 0;
      padding: 0;
      margin: 0;
      display: flex;
      flex-wrap: wrap;
      gap: 8px 16px;
      max-height: 180px;
      overflow: auto;
    }
    .group-fields legend {
      padding: 0 0 8px;
      font-size: 12px;
      color: var(--ws-muted);
    }
    .add-control {
      display: flex;
      align-items: flex-end;
      gap: 12px;
    }
    .add-control .field {
      flex: 1;
    }
    .conditions {
      border-top: 1px solid var(--ws-border);
    }
    .conditions > summary {
      padding-left: 0;
      font-weight: 500;
    }
    .conditions .hint {
      margin-bottom: 10px;
    }
    .error {
      color: var(--mat-sys-error);
      margin: 0;
      font-size: 13px;
    }
    mat-dialog-actions {
      border-top: 1px solid var(--ws-border);
    }
    @media (max-width: 600px) {
      .control-fields {
        grid-template-columns: 1fr;
      }
    }
  `,
})
export class DashboardFilterSettingsComponent {
  private readonly state = injectUiState('DashboardFilterSettings');
  readonly data = inject<{ item: Placement; widget: WidgetResource; model: ModelResource }>(
    MAT_DIALOG_DATA,
  );
  private readonly dialog = inject(MatDialogRef<DashboardFilterSettingsComponent>);
  readonly columns: ColumnSpec[] = [
    ...this.data.model.body.columns,
    ...(this.data.widget.body.calculatedColumns ?? []).map((definition) =>
      calculatedColumnSpec(definition, this.data.model.body.columns),
    ),
  ];
  title = this.data.item.title ?? 'Filter controls';
  initialModel = structuredClone(
    this.data.item.filter?.filterModel ?? null,
  ) as AdvancedFilterModel | null;
  filterModel: GridModel = this.initialModel as GridModel;
  conditionsValid = true;
  drafts = (this.data.item.controls ?? []).map((control, index) =>
    dashboardControlDraft(control, this.filterModel, `control-${index}`),
  );
  newType: DashboardControl['type'] = 'values';
  openedId = '';
  private nextId = this.drafts.length;
  readonly error = this.state.signal('');

  typeLabel(type: DashboardControl['type']): string {
    return {
      window: 'Recent window',
      bucket: 'Time buckets',
      values: 'Value selector',
      groupBy: 'Grouping',
    }[type];
  }
  columnLabel(id: string) {
    return this.columns.find((column) => column.id === id)?.label ?? id;
  }
  bindingLabel(control: DashboardControlDraft) {
    return control.type === 'window' || control.type === 'values'
      ? `${this.typeLabel(control.type)} · ${this.columnLabel(control.columnId) || 'Choose a field'}`
      : this.typeLabel(control.type);
  }
  eligibleColumns(type: DashboardControl['type']) {
    return this.columns.filter(
      (column) => type !== 'window' || ['date', 'datetime'].includes(column.kind),
    );
  }
  numericOptions(control: DashboardControlDraft) {
    return [
      ...new Set(
        control.optionsText
          .split(/[\s,]+/)
          .filter(Boolean)
          .map(Number)
          .filter((value) => Number.isSafeInteger(value) && value > 0),
      ),
    ];
  }
  setColumn(control: DashboardControlDraft, id: string) {
    control.columnId = id;
    const source: DashboardControl =
      control.type === 'window'
        ? { type: 'window', columnId: id, options: this.numericOptions(control) }
        : { type: 'values', columnId: id };
    const defaults = dashboardControlDraft(source, this.filterModel, control.id);
    control.defaultValuesText = defaults.defaultValuesText;
    control.defaultMinutes = defaults.defaultMinutes;
  }
  add() {
    const columnId = this.eligibleColumns(this.newType)[0]?.id ?? '';
    const dateOnly = this.columns.find((column) => column.id === columnId)?.kind === 'date';
    const source: DashboardControl =
      this.newType === 'window'
        ? {
            type: 'window',
            columnId,
            label: 'Recent window',
            options: dateOnly ? [1440, 10080, 43200] : [15, 30, 60, 180],
            minutes: dateOnly ? 1440 : 60,
          }
        : this.newType === 'bucket'
          ? { type: 'bucket', label: 'Time buckets', options: [6, 30, 60, 300, 900], seconds: 60 }
          : this.newType === 'groupBy'
            ? {
                type: 'groupBy',
                label: 'Group grid by',
                options: columnId ? [{ columnId }] : [],
                allowNone: true,
                columnId: null,
              }
            : { type: 'values', columnId, allowAll: true };
    const draft = dashboardControlDraft(source, this.filterModel, `control-${this.nextId++}`);
    this.drafts = [...this.drafts, draft];
    this.openedId = draft.id;
    this.error.set('');
  }
  move(index: number, delta: number, event: Event) {
    event.preventDefault();
    event.stopPropagation();
    const next = [...this.drafts];
    [next[index], next[index + delta]] = [next[index + delta], next[index]];
    this.drafts = next;
  }
  remove(index: number, event: Event) {
    event.preventDefault();
    event.stopPropagation();
    this.drafts = this.drafts.filter((_, position) => position !== index);
  }
  toggleGroup(control: DashboardControlDraft, id: string, selected: boolean) {
    control.groupColumnIds = selected
      ? [...control.groupColumnIds, id]
      : control.groupColumnIds.filter((value) => value !== id);
  }
  setConditions(change: FilterDraftChange) {
    this.conditionsValid = change.valid;
    this.filterModel = change.model as GridModel;
    this.error.set(change.message);
  }
  apply() {
    if (!this.conditionsValid) return;
    try {
      const { controls, filterModel } = composeDashboardControls(
        this.drafts,
        this.filterModel,
        this.columns,
      );
      fromModel(filterModel, 'advanced', this.columns);
      this.dialog.close({
        ...structuredClone(this.data.item),
        title: this.title.trim() || 'Filter controls',
        controls,
        filter: { mode: 'advanced', filterModel },
      });
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : 'Check the filter controls.');
    }
  }
}
