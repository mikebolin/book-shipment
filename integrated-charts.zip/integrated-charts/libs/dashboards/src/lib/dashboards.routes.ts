import type { Routes } from '@angular/router';
export const DASHBOARD_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./catalog/dashboards.component').then((m) => m.DashboardsComponent),
  },
  {
    path: ':slug',
    runGuardsAndResolvers: 'paramsOrQueryParamsChange',
    canDeactivate: [
      (component: import('./dashboard-detail.component').DashboardDetailComponent) =>
        component.canLeave(),
    ],
    loadComponent: () =>
      import('./dashboard-detail.component').then((m) => m.DashboardDetailComponent),
  },
];
