import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { describeFilterScope } from '@prism/charting';
import type { ColumnSpec, DashboardControl, DashboardScopeState } from '@prism/charting';
import {
  bucketSecondsLabel,
  equalityValues,
  windowMinutes,
  withEqualityValues,
  withRecentWindow,
} from './dashboard-filter';

/**
 * The toolbar of a filter-controls element: one flat row of presets and selections generated
 * from the element's `controls` configuration, applied immediately, followed by one sentence
 * describing the scope every other element on the dashboard now follows.
 */
@Component({
  selector: 'workspace-dashboard-controls',
  standalone: true,
  imports: [FormsModule, MatButtonModule, MatIconModule, MatTooltipModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="controls-bar" role="group" [attr.aria-label]="label">
      @for (control of controls; track $index) {
        @switch (control.type) {
          @case ('window') {
            <label class="control">
              <span>{{ control.label ?? 'Recent window' }}</span>
              <select
                [attr.aria-label]="control.label ?? 'Recent window'"
                [ngModel]="windowValue(control)"
                (ngModelChange)="setWindow(control, $event)"
                [disabled]="disabled"
              >
                @for (minutes of control.options; track minutes) {
                  <option [ngValue]="minutes">{{ minutesLabel(minutes) }}</option>
                }
                @if (windowValue(control) === null) {
                  <option [ngValue]="null">Custom</option>
                }
              </select>
            </label>
          }
          @case ('bucket') {
            <label class="control">
              <span>{{ control.label ?? 'Time buckets' }}</span>
              <select
                [attr.aria-label]="control.label ?? 'Time buckets'"
                [ngModel]="bucketValue(control)"
                (ngModelChange)="setBucket($event)"
                [disabled]="disabled"
              >
                @for (seconds of control.options; track seconds) {
                  <option [ngValue]="seconds">{{ bucketLabel(seconds) }}</option>
                }
              </select>
            </label>
          }
          @case ('values') {
            @if (control.multiple) {
              <div class="control">
                <span>{{ control.label ?? columnLabel(control.columnId) }}</span>
                <div
                  class="chip-set"
                  role="group"
                  [attr.aria-label]="control.label ?? columnLabel(control.columnId)"
                >
                  @for (option of valueOptions(control); track option) {
                    <button
                      type="button"
                      mat-button
                      class="chip"
                      [class.on]="selectedValues(control).includes(option)"
                      [attr.aria-pressed]="selectedValues(control).includes(option)"
                      [disabled]="disabled"
                      (click)="toggleValue(control, option)"
                    >
                      <mat-icon aria-hidden="true">{{
                        selectedValues(control).includes(option)
                          ? 'check_box'
                          : 'check_box_outline_blank'
                      }}</mat-icon>
                      {{ option }}
                    </button>
                  }
                </div>
              </div>
            } @else {
              <label class="control">
                <span>{{ control.label ?? columnLabel(control.columnId) }}</span>
                <select
                  [attr.aria-label]="control.label ?? columnLabel(control.columnId)"
                  [ngModel]="selectedValues(control)[0] ?? ''"
                  (ngModelChange)="setValue(control, $event)"
                  [disabled]="disabled"
                >
                  @if (control.allowAll !== false) {
                    <option value="">
                      All {{ (control.label ?? columnLabel(control.columnId)).toLowerCase() }}s
                    </option>
                  }
                  @for (option of valueOptions(control); track option) {
                    <option [value]="option">{{ option }}</option>
                  }
                </select>
              </label>
            }
          }
          @case ('groupBy') {
            <label class="control">
              <span>{{ control.label ?? 'Group grid by' }}</span>
              <select
                [attr.aria-label]="control.label ?? 'Group grid by'"
                [ngModel]="groupValue(control)"
                (ngModelChange)="setGroupBy($event)"
                [disabled]="disabled"
              >
                @for (option of control.options; track option.columnId) {
                  <option [value]="option.columnId">
                    {{ option.label ?? columnLabel(option.columnId) }}
                  </option>
                }
                @if (control.allowNone !== false) {
                  <option value="">No grouping</option>
                }
              </select>
            </label>
          }
        }
      }
      @if (changed) {
        <button
          mat-button
          type="button"
          class="reset"
          (click)="reset.emit()"
          [disabled]="disabled"
          aria-label="Reset dashboard filter"
          data-testid="dashboard-filter-reset"
        >
          <mat-icon>restart_alt</mat-icon>Reset
        </button>
      }
    </div>
    <p class="controls-summary" data-testid="filter-values-summary" aria-live="polite">
      {{ summary() }}
    </p>
  `,
  styles: `
    :host {
      display: block;
      min-width: 0;
      padding: 6px 12px 8px;
    }
    .controls-bar {
      display: flex;
      flex-wrap: wrap;
      align-items: flex-end;
      gap: 8px 16px;
    }
    .control {
      display: flex;
      flex-direction: column;
      gap: 3px;
      min-width: 0;
    }
    .control > span {
      font-size: 11px;
      color: var(--ws-muted);
    }
    select {
      min-height: 34px;
      min-width: 150px;
      border: 1px solid var(--mat-sys-outline);
      border-radius: 7px;
      padding: 5px 8px;
      background: var(--mat-sys-surface-container-lowest);
      color: var(--mat-sys-on-surface);
      font: inherit;
      font-size: 12px;
    }
    select:focus-visible,
    .chip:focus-visible {
      outline: 2px solid var(--mat-sys-primary);
      outline-offset: 1px;
    }
    .chip-set {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      min-height: 34px;
      align-items: center;
    }
    .chip {
      border: 0;
      border-radius: 4px;
      padding: 0 8px;
      background: transparent;
      color: var(--mat-sys-on-surface);
      font: inherit;
      font-size: 12px;
      cursor: pointer;
    }
    .chip.on {
      background: transparent;
      color: var(--mat-sys-primary);
    }
    .chip:disabled {
      opacity: 0.6;
      cursor: default;
    }
    .reset {
      margin-left: auto;
      font-size: 12px;
    }
    .controls-summary {
      margin: 6px 0 0;
      font-size: 12px;
      line-height: 1.45;
      color: var(--ws-muted);
      overflow-wrap: anywhere;
    }
  `,
})
export class DashboardControlsComponent {
  @Input({ required: true }) controls: DashboardControl[] = [];
  @Input({ required: true }) columns: readonly ColumnSpec[] = [];
  @Input({ required: true }) scope!: DashboardScopeState;
  @Input() label = 'Filter controls';
  @Input() disabled = false;
  @Input() changed = false;
  @Output() readonly scopeChange = new EventEmitter<DashboardScopeState>();
  @Output() readonly reset = new EventEmitter<void>();

  column(id: string): ColumnSpec | undefined {
    return this.columns.find((column) => column.id === id);
  }
  columnLabel(id: string): string {
    return this.column(id)?.label ?? id;
  }
  minutesLabel(minutes: number): string {
    return minutes % 60 === 0 && minutes >= 120
      ? `${minutes / 60} hours`
      : minutes === 60
        ? '1 hour'
        : `${minutes} minutes`;
  }
  bucketLabel(seconds: number): string {
    return bucketSecondsLabel(seconds);
  }
  summary(): string {
    const parts = [
      describeFilterScope({ mode: 'advanced', filterModel: this.scope.filterModel }, this.columns),
    ];
    const bucket = this.controls.find((control) => control.type === 'bucket');
    if (bucket && bucket.type === 'bucket')
      parts.push(`${this.bucketLabel(this.bucketValue(bucket))} buckets`);
    const groupBy = this.controls.find((control) => control.type === 'groupBy');
    if (groupBy && groupBy.type === 'groupBy') {
      const value = this.groupValue(groupBy);
      parts.push(value ? `grouped by ${this.columnLabel(value).toLowerCase()}` : 'no grouping');
    }
    return parts.join(' · ');
  }

  windowValue(control: Extract<DashboardControl, { type: 'window' }>): number | null {
    const minutes = windowMinutes(this.scope.filterModel, control.columnId);
    return minutes !== null && control.options.includes(minutes) ? minutes : null;
  }
  setWindow(control: Extract<DashboardControl, { type: 'window' }>, minutes: number | null) {
    const column = this.column(control.columnId);
    if (minutes === null || !column) return;
    this.scopeChange.emit({
      ...this.scope,
      filterModel: withRecentWindow(
        this.scope.filterModel,
        column,
        minutes,
        control.anchor === 'now' ? new Date().toISOString() : control.endsAt,
      ),
    });
  }
  bucketValue(control: Extract<DashboardControl, { type: 'bucket' }>): number {
    return this.scope.bucketSeconds ?? control.seconds ?? control.options[0] ?? 60;
  }
  setBucket(seconds: number) {
    this.scopeChange.emit({ ...this.scope, bucketSeconds: seconds });
  }
  valueOptions(control: Extract<DashboardControl, { type: 'values' }>): string[] {
    const selected = equalityValues(this.scope.filterModel, control.columnId);
    return [
      ...new Set([
        ...(control.options ?? this.column(control.columnId)?.values ?? []),
        ...selected,
      ]),
    ];
  }
  selectedValues(control: Extract<DashboardControl, { type: 'values' }>): string[] {
    return equalityValues(this.scope.filterModel, control.columnId);
  }
  toggleValue(control: Extract<DashboardControl, { type: 'values' }>, option: string) {
    const selected = this.selectedValues(control);
    const next = selected.includes(option)
      ? selected.filter((value) => value !== option)
      : [...selected, option];
    if (!next.length && control.allowAll === false) return;
    this.emitValues(control, next);
  }
  setValue(control: Extract<DashboardControl, { type: 'values' }>, option: string) {
    this.emitValues(control, option ? [option] : []);
  }
  private emitValues(control: Extract<DashboardControl, { type: 'values' }>, values: string[]) {
    const column = this.column(control.columnId);
    if (!column) return;
    this.scopeChange.emit({
      ...this.scope,
      filterModel: withEqualityValues(this.scope.filterModel, column, values),
    });
  }
  groupValue(control: Extract<DashboardControl, { type: 'groupBy' }>): string {
    return this.scope.groupBy === undefined
      ? control.columnId === undefined
        ? (control.options[0]?.columnId ?? '')
        : (control.columnId ?? '')
      : (this.scope.groupBy ?? '');
  }
  setGroupBy(columnId: string) {
    this.scopeChange.emit({ ...this.scope, groupBy: columnId || null });
  }
}
