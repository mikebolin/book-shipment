import { CHARTING_DATA } from '@prism/charting';
import { injectUiState } from '@prism/charting';
import { Component, computed, inject, ChangeDetectionStrategy } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { ResourcePreviewComponent } from '@prism/charting';
import type { ModelResource, Placement, WidgetResource } from '@prism/charting';
import { type PowerBiReport } from '@prism/charting';
import { catalogElements, type CatalogElement } from './dashboard-catalog';
export type PublishedViewChoice =
  | { element: CatalogElement; sectionId?: string }
  | { powerBi: PowerBiReport; sectionId?: string };

/** The catalog uses saved metadata only; browsing it never acquires source data. */
@Component({
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    FormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    ResourcePreviewComponent,
  ],
  template: `
    <header class="picker-heading">
      <div>
        <h2 mat-dialog-title>Element library</h2>
        <p>
          Add a chart or table independently, or choose Complete views to keep the outer container
          and saved layout.
        </p>
      </div>
      <button
        mat-icon-button
        mat-dialog-close
        aria-label="Close element library"
        matTooltip="Close"
      >
        <mat-icon>close</mat-icon>
      </button>
    </header>
    <mat-dialog-content>
      <div class="catalog-toolbar">
        <mat-form-field class="search" appearance="outline" subscriptSizing="dynamic">
          <mat-icon matPrefix>search</mat-icon>
          <input
            matInput
            type="search"
            placeholder="Search elements"
            aria-label="Search published views"
            [ngModel]="query()"
            (ngModelChange)="query.set($event)"
            autocomplete="off"
            cdkFocusInitial
          />
          @if (query()) {
            <button
              mat-icon-button
              matSuffix
              (click)="query.set('')"
              aria-label="Clear view search"
            >
              <mat-icon>close</mat-icon>
            </button>
          }
        </mat-form-field>
        @if (data.sections?.length) {
          <mat-form-field class="destination" appearance="outline" subscriptSizing="dynamic">
            <mat-label>Place in</mat-label>
            <mat-select [(ngModel)]="sectionId" aria-label="Place in container">
              <mat-option value="">Dashboard canvas</mat-option>
              @for (section of data.sections; track section.id) {
                <mat-option [value]="section.id">{{ section.title }}</mat-option>
              }
            </mat-select>
          </mat-form-field>
        }
      </div>
      <div class="catalog-types" role="group" aria-label="Element type">
        @for (type of types; track type.id) {
          <button
            type="button"
            [class.selected]="kind() === type.id"
            [attr.aria-pressed]="kind() === type.id"
            (click)="kind.set(type.id)"
          >
            {{ type.label }}
          </button>
        }
      </div>
      @for (group of groups(); track group.id) {
        <section class="model-group" [attr.aria-label]="group.name">
          <h3>
            <mat-icon>storage</mat-icon>{{ group.name
            }}<small>{{ group.elements.length }} elements</small>
          </h3>
          <div class="view-cards">
            @for (element of group.elements; track element.id) {
              <article
                class="view-card"
                [attr.data-widget-id]="element.widget.id"
                [attr.data-element-kind]="element.kind"
                [attr.aria-label]="element.name + ' ' + element.kind"
              >
                <div class="card-title">
                  <span class="kind-label"
                    ><mat-icon>{{ icon(element.kind) }}</mat-icon
                    >{{ label(element.kind) }}</span
                  >
                  <button
                    mat-icon-button
                    (click)="choose(element)"
                    [attr.aria-label]="'Add ' + element.name"
                    [matTooltip]="'Add ' + element.name"
                  >
                    <mat-icon>add</mat-icon>
                  </button>
                </div>
                @if (
                  element.widget.body.preview &&
                  (element.kind === 'view' || element.chartId === element.widget.body.chart?.id)
                ) {
                  <workspace-resource-preview
                    [preview]="element.widget.body.preview"
                    [icon]="icon(element.kind)"
                  />
                } @else {
                  <div class="element-preview" aria-hidden="true">
                    <mat-icon>{{ icon(element.kind) }}</mat-icon>
                    <span>{{
                      element.kind === 'table'
                        ? 'Saved columns, sorting and filters'
                        : element.kind === 'view'
                          ? 'Saved view configuration'
                          : element.kind === 'filter'
                            ? 'Saved filter values as inputs that scope every element'
                            : 'Independent chart'
                    }}</span>
                  </div>
                }
                <div class="card-copy">
                  <h4 [matTooltip]="element.name">{{ element.name }}</h4>
                  <p>{{ element.widget.name }}</p>
                  <div class="card-meta">
                    <span>{{ label(element.kind) }}</span
                    ><span>Revision {{ element.widget.publishedVersion }}</span>
                  </div>
                </div>
              </article>
            }
          </div>
        </section>
      }
      @if (reports().length) {
        <section class="model-group" aria-label="Power BI published views">
          <h3><mat-icon>analytics</mat-icon>Power BI<small>Public demos</small></h3>
          <div class="view-cards">
            @for (report of reports(); track report.id) {
              <article class="view-card">
                <div class="card-title">
                  <span class="kind-label"><mat-icon>analytics</mat-icon>Report</span>
                  <button
                    mat-icon-button
                    (click)="chooseReport(report)"
                    [attr.aria-label]="'Add ' + report.name"
                  >
                    <mat-icon>add</mat-icon>
                  </button>
                </div>
                <div class="card-copy">
                  <h4>{{ report.name }}</h4>
                  <p>{{ report.description }}</p>
                  <div class="card-meta">{{ report.category }}</div>
                </div>
              </article>
            }
          </div>
        </section>
      }
      @if (!groups().length && !reports().length) {
        <div class="empty">
          <mat-icon>search_off</mat-icon><strong>No matching elements</strong>
          <p>
            Search by chart, view, model or tag. Publish a view in Studio to add its elements here.
          </p>
        </div>
      }
    </mat-dialog-content>
  `,
  styles: `
    :host {
      display: block;
      min-width: 0;
      color: var(--ws-ink);
    }
    .picker-heading {
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 12px;
      padding: 18px 20px 16px;
    }
    .picker-heading h2 {
      font-size: 20px;
      padding: 0;
      margin: 0 0 6px;
    }
    .picker-heading h2::before {
      display: none;
    }
    .picker-heading p {
      margin: 0;
      color: var(--ws-muted);
      font-size: 12px;
      line-height: 1.5;
    }
    mat-dialog-content {
      padding: 0 20px 20px !important;
      max-height: 72dvh;
    }
    .catalog-toolbar {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 12px;
      padding-top: 8px;
    }
    .search {
      width: 300px;
      max-width: 100%;
    }
    .destination {
      width: 220px;
      max-width: 100%;
      margin-left: auto;
    }
    mat-form-field {
      --mat-form-field-outlined-container-shape: 8px;
      --mat-form-field-container-height: 40px;
      --mat-form-field-container-vertical-padding: 8px;
    }
    .search mat-icon[matPrefix] {
      color: var(--ws-muted);
      padding-left: 12px;
    }
    .search input {
      appearance: none;
      border: 0;
      padding: 0;
      border-radius: 0;
      background: transparent;
      box-shadow: none;
      outline: none;
    }
    .search input::-webkit-search-cancel-button {
      display: none;
    }
    .catalog-types {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      padding: 14px 0;
    }
    .catalog-types button {
      padding: 7px 12px;
      border: 1px solid var(--ws-border);
      border-radius: 20px;
      font: inherit;
      font-size: 12px;
      background: transparent;
      color: var(--ws-muted);
      cursor: pointer;
    }
    .catalog-types button.selected {
      background: var(--ws-accent-soft);
      color: var(--ws-ink);
      border-color: var(--ws-accent);
    }
    .model-group {
      margin: 8px 0 22px;
    }
    .model-group h3 {
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 0 0 10px;
      font-size: 12px;
      font-weight: 500;
    }
    h3 mat-icon,
    .kind-label mat-icon {
      font-size: 16px;
      width: 16px;
      height: 16px;
      color: var(--ws-muted);
    }
    h3 small {
      margin-left: auto;
      font-size: 11px;
      color: var(--ws-muted);
      font-weight: 400;
    }
    .view-cards {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(min(100%, 230px), 1fr));
      gap: 12px;
    }
    .view-card {
      border: 1px solid var(--ws-border);
      border-radius: 10px;
      overflow: hidden;
      background: var(--mat-sys-surface);
      min-width: 0;
    }
    .view-card:focus-within,
    .view-card:hover {
      border-color: var(--ws-accent);
    }
    workspace-resource-preview,
    .element-preview {
      height: 104px;
      padding: 8px 12px;
      background: var(--mat-sys-surface-container-low);
    }
    .element-preview {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      gap: 10px;
      color: var(--ws-muted);
      font-size: 11px;
    }
    .element-preview mat-icon {
      width: 28px;
      height: 28px;
      font-size: 28px;
      color: var(--ws-accent);
    }
    .card-title {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      padding: 5px 8px 5px 12px;
    }
    .kind-label {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      color: var(--ws-muted);
      font-size: 11px;
    }
    .card-title button {
      flex-shrink: 0;
      width: 32px;
      height: 32px;
      padding: 7px;
      --mat-icon-button-state-layer-size: 32px;
      color: var(--ws-accent);
    }
    .card-title button mat-icon {
      font-size: 18px;
      width: 18px;
      height: 18px;
    }
    .card-copy {
      padding: 12px;
    }
    .card-copy h4 {
      margin: 0 0 5px;
      font-size: 13px;
      line-height: 1.4;
      font-weight: 600;
      overflow-wrap: anywhere;
    }
    .card-copy p {
      font-size: 11px;
      line-height: 1.5;
      color: var(--ws-muted);
      margin: 0 0 12px;
      overflow-wrap: anywhere;
    }
    .card-meta {
      display: flex;
      justify-content: space-between;
      gap: 8px;
      font-size: 10px;
      color: var(--ws-muted);
    }
    .empty {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 12px;
      padding: 32px;
      text-align: center;
    }
    .empty p {
      font-size: 12px;
      color: var(--ws-muted);
      max-width: 340px;
      line-height: 1.5;
    }
    @media (max-width: 600px) {
      .destination {
        margin-left: 0;
      }
      .search,
      .destination {
        width: 100%;
      }
    }
  `,
})
export class DashboardViewPickerComponent {
  readonly hostData = inject(CHARTING_DATA);
  private readonly reactiveState = injectUiState('DashboardViewPickerComponent');

  readonly data = inject<{
    widgets: WidgetResource[];
    models: ModelResource[];
    sections?: Placement[];
    sectionId?: string;
  }>(MAT_DIALOG_DATA);
  private readonly ref = inject(MatDialogRef<DashboardViewPickerComponent, PublishedViewChoice>);
  readonly query = this.reactiveState.signal('');
  readonly kind = this.reactiveState.signal('all');
  private readonly sectionIdState = this.reactiveState.signal(this.data.sectionId ?? '');
  get sectionId() {
    return this.sectionIdState();
  }
  set sectionId(value) {
    this.sectionIdState.set(value);
  }
  readonly types = [
    { id: 'all', label: 'All elements' },
    { id: 'chart', label: 'Charts' },
    { id: 'table', label: 'Tables' },
    { id: 'filter', label: 'Filter controls' },
    { id: 'view', label: 'Complete views' },
    { id: 'report', label: 'Reports' },
  ];
  readonly elements = catalogElements(this.data.widgets);
  readonly groups = computed(() => {
    const query = this.query().trim().toLocaleLowerCase();
    const models = new Map(this.data.models.map((model) => [model.id, model.name]));
    const groups = new Map<string, { id: string; name: string; elements: CatalogElement[] }>();
    for (const element of this.elements) {
      if (this.kind() !== 'all' && this.kind() !== element.kind) continue;
      const widget = element.widget;
      const id = widget.modelId ?? 'unassigned';
      const name = models.get(id) ?? 'Other models';
      if (
        query &&
        ![element.name, widget.name, widget.description, name, ...(widget.body.tags ?? [])]
          .join(' ')
          .toLocaleLowerCase()
          .includes(query)
      )
        continue;
      if (!groups.has(id)) groups.set(id, { id, name, elements: [] });
      groups.get(id)!.elements.push(element);
    }
    return [...groups.values()].sort((a, b) => a.name.localeCompare(b.name));
  });
  readonly reports = computed(() =>
    ['all', 'report'].includes(this.kind())
      ? (this.hostData.reports ?? []).filter((report) =>
          `${report.name} ${report.description} Power BI`
            .toLowerCase()
            .includes(this.query().trim().toLowerCase()),
        )
      : [],
  );
  icon(kind: string) {
    return kind === 'chart'
      ? 'insert_chart_outlined'
      : kind === 'table'
        ? 'table_chart'
        : kind === 'filter'
          ? 'tune'
          : 'view_module';
  }
  label(kind: string) {
    return kind === 'chart'
      ? 'Chart'
      : kind === 'table'
        ? 'Table'
        : kind === 'filter'
          ? 'Filter controls'
          : 'Complete view';
  }
  choose(element: CatalogElement) {
    this.ref.close({ element, sectionId: this.sectionId || undefined });
  }
  chooseReport(powerBi: PowerBiReport) {
    this.ref.close({ powerBi, sectionId: this.sectionId || undefined });
  }
}
