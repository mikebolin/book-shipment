import type {
  DashboardControl,
  GridModel,
  Placement,
  ViewChartDataScope,
  WidgetResource,
} from '@prism/charting';
import { viewCharts } from '@prism/charting';
import { openPlacement } from './dashboard-composer';

export interface CatalogElement {
  id: string;
  kind: 'chart' | 'table' | 'view' | 'filter';
  name: string;
  widget: WidgetResource;
  chartId?: string;
}

/** A view's saved advanced filter, when it has one: the source of a filter-controls element. */
export function savedViewFilter(widget: WidgetResource): ViewChartDataScope | null {
  const model = widget.body.gridState?.filter?.advancedFilterModel;
  return widget.body.mode === 'advanced'
    ? { mode: 'advanced', filterModel: (model ? structuredClone(model) : null) as unknown as GridModel }
    : null;
}

/** Every saved chart, table and filter can be placed independently of its source view. */
export function catalogElements(widgets: readonly WidgetResource[]): CatalogElement[] {
  return widgets
    .filter((widget) => widget.publishedVersion)
    .flatMap((widget) => [
      ...viewCharts(widget.body).map((chart) => ({
        id: `${widget.id}:chart:${chart.id}`,
        kind: 'chart' as const,
        name: chart.plan.title || widget.name,
        widget,
        chartId: chart.id,
      })),
      { id: `${widget.id}:table`, kind: 'table' as const, name: `${widget.name} · table`, widget },
      ...(savedViewFilter(widget)
        ? [
            {
              id: `${widget.id}:filter`,
              kind: 'filter' as const,
              name: `${widget.name} · filter controls`,
              widget,
            },
          ]
        : []),
      { id: `${widget.id}:view`, kind: 'view' as const, name: widget.name, widget },
    ]);
}

export function catalogPlacement(
  element: CatalogElement,
  items: Placement[],
  sectionId?: string,
): Placement {
  const section = items.find((item) => item.id === sectionId && item.kind === 'section');
  const chart =
    element.kind === 'chart'
      ? viewCharts(element.widget.body).find((chart) => chart.id === element.chartId)
      : undefined;
  const controls = chart?.filterControls ?? element.widget.body.filterControls;
  const hasValueForm =
    element.kind === 'chart' &&
    controls?.visible !== false &&
    controls?.parameterizable &&
    controls.editMode === 'values';
  const h = hasValueForm
    ? 12
    : element.kind === 'filter'
      ? 3
      : element.kind === 'view' && element.widget.body.displayMode === 'both'
        ? 8
        : 6;
  const geometry = openPlacement(items, element.kind === 'filter' ? 12 : 6, h);
  if (section) {
    geometry.x = section.x;
    geometry.w = Math.min(6, section.w);
    geometry.y = Math.max(
      section.y + section.h,
      ...items.filter((item) => item.sectionId === section.id).map((item) => item.y + item.h),
    );
  }
  return {
    id: crypto.randomUUID(),
    kind: element.kind,
    widgetId: element.widget.id,
    widgetRevision: element.widget.publishedVersion!,
    ...geometry,
    ...(section ? { sectionId: section.id } : {}),
    ...(element.kind === 'chart' ? { chartId: element.chartId } : {}),
    ...(element.kind === 'filter'
      ? {
          title: 'Filter controls',
          filter: savedViewFilter(element.widget)!,
          controls: defaultControls(element.widget),
        }
      : {}),
    ...(element.kind === 'view'
      ? {
          displayMode:
            element.widget.body.displayMode ??
            (viewCharts(element.widget.body).length ? 'chart' : 'grid'),
        }
      : {}),
  };
}

/**
 * A usable toolbar for a view's saved filter: a recent-window preset for its time bounds, one
 * selector per column with equality rules, a bucket size when the view charts minutes, and the
 * view's grouping as the first grouping choice. Authors refine the list in the saved dashboard.
 */
export function defaultControls(widget: WidgetResource): DashboardControl[] {
  const model = (savedViewFilter(widget)?.filterModel ?? null) as Record<string, unknown> | null;
  const controls: DashboardControl[] = [];
  const conditions: Record<string, unknown>[] =
    model && model['filterType'] === 'join' && Array.isArray(model['conditions'])
      ? (model['conditions'] as Record<string, unknown>[])
      : model
        ? [model]
        : [];
  const bounded = new Set<string>();
  const equalities = new Map<string, number>();
  for (const rule of conditions) {
    const colId = typeof rule['colId'] === 'string' ? rule['colId'] : undefined;
    if (
      colId &&
      /^date/.test(String(rule['filterType'])) &&
      ['greaterThanOrEqual', 'greaterThan', 'lessThan', 'lessThanOrEqual'].includes(
        String(rule['type']),
      )
    )
      bounded.add(colId);
    else if (colId && rule['type'] === 'equals') equalities.set(colId, 1);
    else if (
      rule['filterType'] === 'join' &&
      rule['type'] === 'OR' &&
      Array.isArray(rule['conditions'])
    ) {
      const children = rule['conditions'] as Record<string, unknown>[];
      const column = children[0]?.['colId'];
      if (
        typeof column === 'string' &&
        children.every((child) => child['colId'] === column && child['type'] === 'equals')
      )
        equalities.set(column, children.length);
    }
  }
  const columns = widget.body.gridState?.columnOrder?.orderedColIds ?? [];
  for (const columnId of bounded) {
    const end = conditions.find(
      (rule) =>
        rule['colId'] === columnId &&
        ['lessThan', 'lessThanOrEqual'].includes(String(rule['type'])),
    );
    controls.push({
      type: 'window',
      columnId,
      label: 'Recent window',
      options: [15, 30, 60, 180, 360, 720],
      ...(typeof end?.['filter'] === 'string' ? { endsAt: end['filter'] } : {}),
    });
  }
  const bucketed = viewCharts(widget.body).find((chart) =>
    ['second', 'minute', 'hour'].includes(chart.plan.timeBucket ?? ''),
  );
  if (bucketed) {
    const unit =
      bucketed.plan.timeBucket === 'second' ? 1 : bucketed.plan.timeBucket === 'minute' ? 60 : 3600;
    controls.push({
      type: 'bucket',
      label: 'Time buckets',
      seconds: (bucketed.plan.bucketSize ?? 1) * unit,
      options: [6, 15, 30, 60, 300, 900],
    });
  }
  for (const [columnId, count] of equalities)
    controls.push({
      type: 'values',
      columnId,
      ...(count > 1 ? { multiple: true } : { allowAll: true }),
    });
  const grouped = widget.body.gridState?.rowGroup?.groupColIds ?? [];
  if (grouped.length)
    controls.push({
      type: 'groupBy',
      columnId: grouped[0],
      label: 'Group grid by',
      options: [...new Set([...grouped, ...columns.slice(0, 6)])].map((columnId) => ({ columnId })),
      allowNone: true,
    });
  return controls;
}
