import type { ColumnSpec, DashboardControl, DashboardScopeState, GridModel } from '@prism/charting';
import {
  equalityValues,
  parseStamp,
  windowMinutes,
  withEqualityValues,
  withRecentWindow,
} from './dashboard-filter';

/** Editing form only; persisted controls remain a small, declarative configuration. */
export interface DashboardControlDraft {
  id: string;
  type: DashboardControl['type'];
  label: string;
  columnId: string;
  optionsText: string;
  defaultMinutes: number | null;
  defaultSeconds: number | null;
  anchor: 'saved' | 'fixed' | 'now';
  endsAt: string;
  multiple: boolean;
  allowAll: boolean;
  defaultValuesText: string;
  groupColumnIds: string[];
  groupLabels: Record<string, string>;
  defaultGroupBy: string;
  allowNone: boolean;
}

const lines = (text: string) => [
  ...new Set(
    text
      .split(/\r?\n/)
      .map((value) => value.trim())
      .filter(Boolean),
  ),
];
const positiveOptions = (text: string, label: string) => {
  const values = [
    ...new Set(
      text
        .split(/[\s,]+/)
        .filter(Boolean)
        .map(Number),
    ),
  ];
  if (!values.length || values.some((value) => !Number.isSafeInteger(value) || value < 1))
    throw new Error(`${label}: enter positive whole numbers separated by commas.`);
  if (values.length > 24) throw new Error(`${label}: keep at most 24 presets.`);
  return values;
};

export function dashboardControlDraft(
  control: DashboardControl,
  model: GridModel,
  id: string,
): DashboardControlDraft {
  const minutes =
    control.type === 'window' ? (control.minutes ?? windowMinutes(model, control.columnId)) : null;
  return {
    id,
    type: control.type,
    label: control.label ?? '',
    columnId: 'columnId' in control ? (control.columnId ?? '') : '',
    optionsText:
      control.type === 'values'
        ? (control.options ?? []).join('\n')
        : control.type === 'window' || control.type === 'bucket'
          ? control.options.join(', ')
          : '',
    defaultMinutes:
      control.type === 'window' && minutes !== null && control.options.includes(minutes)
        ? minutes
        : null,
    defaultSeconds:
      control.type === 'bucket' ? (control.seconds ?? control.options[0] ?? null) : null,
    anchor:
      control.type === 'window'
        ? control.anchor === 'now'
          ? 'now'
          : control.endsAt
            ? 'fixed'
            : 'saved'
        : 'saved',
    endsAt: control.type === 'window' ? (control.endsAt ?? '') : '',
    multiple: control.type === 'values' && !!control.multiple,
    allowAll: control.type !== 'values' || control.allowAll !== false,
    defaultValuesText:
      control.type === 'values' ? equalityValues(model, control.columnId).join('\n') : '',
    groupColumnIds:
      control.type === 'groupBy' ? control.options.map((option) => option.columnId) : [],
    groupLabels:
      control.type === 'groupBy'
        ? Object.fromEntries(
            control.options
              .filter((option) => option.label)
              .map((option) => [option.columnId, option.label!]),
          )
        : {},
    defaultGroupBy:
      control.type === 'groupBy'
        ? control.columnId === undefined
          ? (control.options[0]?.columnId ?? '')
          : (control.columnId ?? '')
        : '',
    allowNone: control.type === 'groupBy' && control.allowNone !== false,
  };
}

/** Saved defaults must produce exactly the same state displayed by the reader controls. */
export function dashboardDefaultScope(
  model: GridModel,
  controls: readonly DashboardControl[],
  columns: readonly ColumnSpec[],
  now = new Date(),
): DashboardScopeState {
  let filterModel = model;
  for (const control of controls) {
    if (control.type !== 'window' || control.anchor !== 'now') continue;
    const column = columns.find((column) => column.id === control.columnId);
    if (!column) continue;
    const minutes = control.minutes ?? windowMinutes(model, column.id) ?? control.options[0];
    if (minutes) filterModel = withRecentWindow(filterModel, column, minutes, now.toISOString());
  }
  const bucket = controls.find((control) => control.type === 'bucket');
  const grouping = controls.find((control) => control.type === 'groupBy');
  return {
    filterModel,
    ...(bucket?.type === 'bucket' ? { bucketSeconds: bucket.seconds ?? bucket.options[0] } : {}),
    ...(grouping?.type === 'groupBy'
      ? {
          groupBy:
            grouping.columnId === undefined
              ? (grouping.options[0]?.columnId ?? null)
              : grouping.columnId,
        }
      : {}),
  };
}

/** Validate bindings/options and apply only the defaults explicitly configured by each control. */
export function composeDashboardControls(
  drafts: readonly DashboardControlDraft[],
  originalModel: GridModel,
  columns: readonly ColumnSpec[],
): { controls: DashboardControl[]; filterModel: GridModel } {
  let filterModel = structuredClone(originalModel);
  const bound = new Set<string>();
  const controls = drafts.map((draft): DashboardControl => {
    const label = draft.label.trim();
    if (label.length > 120) throw new Error('Keep control labels under 120 characters.');
    const common = label ? { label } : {};
    const column = columns.find((column) => column.id === draft.columnId);
    const binding =
      draft.type === 'values' || draft.type === 'window' ? `column:${draft.columnId}` : draft.type;
    if (bound.has(binding))
      throw new Error('Use one control per field, one bucket control and one grouping control.');
    bound.add(binding);
    if (draft.type === 'window') {
      if (!column || !['date', 'datetime'].includes(column.kind))
        throw new Error('Choose a date or timestamp field for each recent window.');
      const options = positiveOptions(draft.optionsText, 'Window presets');
      if (column.kind === 'date' && options.some((minutes) => minutes % 1440 !== 0))
        throw new Error(
          'Date fields need whole-day windows (multiples of 1,440 minutes). Use a timestamp field for shorter windows.',
        );
      if (draft.defaultMinutes !== null && !options.includes(Number(draft.defaultMinutes)))
        throw new Error('Choose a default window from its presets, or keep the saved filter.');
      if (draft.anchor === 'now' && draft.defaultMinutes === null)
        throw new Error('Choose a default window for the current-time anchor.');
      if (draft.anchor === 'fixed' && parseStamp(draft.endsAt) === null)
        throw new Error('Enter a valid window end in UTC.');
      if (draft.defaultMinutes !== null)
        filterModel = withRecentWindow(
          filterModel,
          column,
          Number(draft.defaultMinutes),
          draft.anchor === 'now'
            ? new Date().toISOString()
            : draft.anchor === 'fixed'
              ? draft.endsAt
              : undefined,
        );
      return {
        ...common,
        type: 'window',
        columnId: column.id,
        options,
        ...(draft.defaultMinutes !== null ? { minutes: Number(draft.defaultMinutes) } : {}),
        ...(draft.anchor === 'now'
          ? { anchor: 'now' }
          : draft.anchor === 'fixed'
            ? { endsAt: draft.endsAt.trim() }
            : {}),
      };
    }
    if (draft.type === 'bucket') {
      const options = positiveOptions(draft.optionsText, 'Bucket presets');
      if (draft.defaultSeconds === null || !options.includes(Number(draft.defaultSeconds)))
        throw new Error('Choose a default bucket size from its presets.');
      return { ...common, type: 'bucket', options, seconds: Number(draft.defaultSeconds) };
    }
    if (draft.type === 'values') {
      if (!column) throw new Error('Choose a field for each value selector.');
      const options = lines(draft.optionsText),
        values = lines(draft.defaultValuesText);
      if (options.length > 100 || values.length > 100)
        throw new Error('Keep selectors and defaults under 100 values.');
      if (!draft.multiple && values.length > 1)
        throw new Error('A single-value selector needs at most one default value.');
      if (!draft.multiple && !draft.allowAll && !values.length)
        throw new Error('Choose a default value, or allow all values.');
      if (
        column.kind === 'number' &&
        [...options, ...values].some((value) => !Number.isFinite(Number(value)))
      )
        throw new Error(`${column.label} requires numeric selector values.`);
      const available = options.length ? options : (column.values ?? []);
      if (!available.length)
        throw new Error(
          `Add selector options for ${column.label}; the source field has no defined values.`,
        );
      if (available.length && values.some((value) => !available.includes(value)))
        throw new Error(`Include every default value in the ${label || column.label} options.`);
      filterModel = withEqualityValues(filterModel, column, values);
      return {
        ...common,
        type: 'values',
        columnId: column.id,
        ...(options.length ? { options } : {}),
        ...(draft.multiple ? { multiple: true } : { allowAll: draft.allowAll }),
      };
    }
    const ids = [...new Set(draft.groupColumnIds)];
    if (!ids.length || ids.some((id) => !columns.some((column) => column.id === id)))
      throw new Error('Choose at least one available grouping field.');
    if (draft.defaultGroupBy ? !ids.includes(draft.defaultGroupBy) : !draft.allowNone)
      throw new Error('Choose a default grouping field, or allow no grouping.');
    return {
      ...common,
      type: 'groupBy',
      allowNone: draft.allowNone,
      columnId: draft.defaultGroupBy || null,
      options: ids.map((columnId) => ({
        columnId,
        ...(draft.groupLabels[columnId] ? { label: draft.groupLabels[columnId] } : {}),
      })),
    };
  });
  return { controls, filterModel };
}
