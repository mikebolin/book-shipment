import type { ChartPlan } from '@prism/charting';
import type {
  ChartOverrides,
  ChartPlacement,
  DashboardElement,
  FilterPlacement,
  Placement,
  PlacementKind,
  SectionPlacement,
  TableOverrides,
  TablePlacement,
  ViewChart,
  ViewPlacement,
  WidgetConfiguration,
  WidgetResource,
} from '@prism/charting';
import { viewCharts } from '@prism/charting';
import { placementConfiguration } from './dashboard-composer';
import { richTextToPlainText } from './rich-text';

/**
 * Helpers for schemaVersion 2 dashboard elements: kind guards, the effective configuration a
 * chart or table element renders with, and the minimal override diffs the inspector stores.
 * The Java twin of `effectiveElementConfiguration` is WorkspaceValidation.effectiveConfiguration.
 */
export const elementKindOf = (item: Pick<Placement, 'kind'>): PlacementKind => item.kind ?? 'view';
/** The guards keep the caller's record type (rendered placements carry extra fields). */
export const isViewElement = <T extends Placement>(item: T): item is T & ViewPlacement =>
  elementKindOf(item) === 'view';
export const isChartElement = <T extends Placement>(item: T): item is T & ChartPlacement =>
  item.kind === 'chart';
export const isTableElement = <T extends Placement>(item: T): item is T & TablePlacement =>
  item.kind === 'table';
export const isFilterElement = <T extends Placement>(item: T): item is T & FilterPlacement =>
  item.kind === 'filter';
export const isSectionElement = <T extends Placement>(item: T): item is T & SectionPlacement =>
  item.kind === 'section';
/** Elements that pin a published view revision and need its model (filter controls need columns). */
export const isDataElement = (item: Placement): boolean =>
  isViewElement(item) || isChartElement(item) || isTableElement(item) || isFilterElement(item);

const same = (a: unknown, b: unknown) => JSON.stringify(a) === JSON.stringify(b);

/** The pinned chart a chart element points at; legacy single-chart bodies match `chart.id`. */
export function pinnedChart(
  configuration: WidgetConfiguration,
  chartId: string,
): ViewChart | undefined {
  return viewCharts(configuration).find((chart) => chart.id === chartId);
}

const SIMPLE_FAMILY: ChartPlan['type'][] = [
  'bar',
  'groupedBar',
  'stackedBar',
  'normalizedBar',
  'column',
  'groupedColumn',
  'stackedColumn',
  'normalizedColumn',
  'line',
  'stackedLine',
  'normalizedLine',
  'area',
  'stackedArea',
  'normalizedArea',
];
/** Chart types a dashboard may switch a pinned chart to without changing its data plan. */
export function chartTypeChoices(chart: ViewChart | undefined): ChartPlan['type'][] {
  const type = chart?.plan.type;
  if (!type) return [];
  const choices: ChartPlan['type'][] =
    SIMPLE_FAMILY.includes(type) && chart?.plan.categoryColumnId
      ? [type, 'bar', 'column', 'line', 'area']
      : type === 'pie' || type === 'donut'
        ? [type, 'pie', 'donut']
        : [type];
  return [...new Set(choices)];
}
export function chartTypeLabel(value: string): string {
  return (
    value[0].toUpperCase() +
    value
      .slice(1)
      .replace(/([a-z])([A-Z])/g, '$1 $2')
      .toLowerCase()
  );
}

/** Apply a chart element's overrides to its pinned chart. */
export function effectiveChart(
  source: ViewChart,
  overrides: ChartOverrides | undefined,
): ViewChart {
  const chart = structuredClone(source);
  if (!overrides) return chart;
  if (overrides.title?.trim()) chart.plan = { ...chart.plan, title: overrides.title.trim() };
  if (overrides.chartType && chartTypeChoices(source).includes(overrides.chartType))
    chart.plan = { ...chart.plan, type: overrides.chartType };
  if ('presentation' in overrides)
    chart.presentation = structuredClone(overrides.presentation ?? null);
  if (overrides.dataScope) chart.dataScope = structuredClone(overrides.dataScope);
  if (overrides.filterControls) chart.filterControls = structuredClone(overrides.filterControls);
  return chart;
}

/**
 * The configuration a data-bound element renders with: a `view` applies its viewOverrides; a
 * `chart` reduces the pinned revision to one chart; a `table` drops every chart.
 */
export function effectiveElementConfiguration(
  item: Placement,
  pinned: WidgetConfiguration,
): WidgetConfiguration {
  if (isChartElement(item)) {
    const source = pinnedChart(pinned, item.chartId);
    const chart = source ? effectiveChart(source, item.overrides) : null;
    const base = structuredClone(pinned);
    return {
      ...base,
      displayMode: 'chart',
      chart,
      charts: chart ? [chart] : [],
      ...(item.overrides?.allowDownload !== undefined
        ? { allowDownload: item.overrides.allowDownload }
        : {}),
    };
  }
  if (isFilterElement(item)) {
    // Filter controls render inputs, not data; nothing here is downloadable.
    return {
      ...structuredClone(pinned),
      displayMode: 'grid',
      chart: null,
      charts: [],
      allowDownload: false,
    };
  }
  if (isTableElement(item)) {
    const base = structuredClone(pinned);
    const overrides = item.overrides;
    const result: WidgetConfiguration = { ...base, displayMode: 'grid', chart: null, charts: [] };
    if (overrides?.mode) result.mode = overrides.mode;
    if (overrides?.gridState) result.gridState = structuredClone(overrides.gridState);
    if (overrides?.filterControls) {
      result.filterControls = structuredClone(overrides.filterControls);
      if (result.grid)
        result.grid = { ...result.grid, filterControls: structuredClone(overrides.filterControls) };
    }
    if (overrides?.showRowNumbers !== undefined) result.showRowNumbers = overrides.showRowNumbers;
    if (overrides?.serverGrid) result.serverGrid = structuredClone(overrides.serverGrid);
    if (overrides?.allowDownload !== undefined) result.allowDownload = overrides.allowDownload;
    return result;
  }
  return placementConfiguration(pinned, item.title, item.viewOverrides);
}

/** Only keys that differ from the pinned chart survive; an empty result means "inherit". */
export function minimalChartOverrides(
  source: ViewChart,
  effective: ViewChart,
  allowDownload?: { source: boolean; effective: boolean },
): ChartOverrides | undefined {
  const result: ChartOverrides = {};
  if (effective.plan.title !== source.plan.title) result.title = effective.plan.title;
  if (effective.plan.type !== source.plan.type) result.chartType = effective.plan.type;
  if (!same(effective.presentation ?? null, source.presentation ?? null))
    result.presentation = structuredClone(effective.presentation ?? null);
  if (!same(effective.dataScope, source.dataScope) && effective.dataScope)
    result.dataScope = structuredClone(effective.dataScope);
  if (!same(effective.filterControls, source.filterControls) && effective.filterControls)
    result.filterControls = structuredClone(effective.filterControls);
  if (allowDownload && allowDownload.effective !== allowDownload.source)
    result.allowDownload = allowDownload.effective;
  return Object.keys(result).length ? result : undefined;
}
export function minimalTableOverrides(
  source: WidgetConfiguration,
  effective: WidgetConfiguration,
): TableOverrides | undefined {
  const result: TableOverrides = {};
  if (effective.mode !== source.mode) result.mode = effective.mode;
  if (!same(effective.gridState, source.gridState))
    result.gridState = structuredClone(effective.gridState);
  const sourceControls = source.grid?.filterControls ?? source.filterControls;
  const effectiveControls = effective.grid?.filterControls ?? effective.filterControls;
  if (!same(effectiveControls, sourceControls) && effectiveControls)
    result.filterControls = structuredClone(effectiveControls);
  if ((effective.showRowNumbers ?? true) !== (source.showRowNumbers ?? true))
    result.showRowNumbers = effective.showRowNumbers ?? true;
  if (!same(effective.serverGrid, source.serverGrid) && effective.serverGrid)
    result.serverGrid = structuredClone(effective.serverGrid);
  if ((effective.allowDownload !== false) !== (source.allowDownload !== false))
    result.allowDownload = effective.allowDownload !== false;
  return Object.keys(result).length ? result : undefined;
}

/** Display title for any element; data elements fall back to their source names. */
export function elementTitle(
  item: Placement,
  widget?: Pick<WidgetResource, 'name' | 'body'>,
): string {
  if (item.title?.trim()) return item.title.trim();
  switch (elementKindOf(item)) {
    case 'chart': {
      const chart = widget && item.chartId ? pinnedChart(widget.body, item.chartId) : undefined;
      return (
        (item.overrides as ChartOverrides | undefined)?.title?.trim() ||
        chart?.plan.title ||
        widget?.name ||
        'Chart'
      );
    }
    case 'table':
      return widget ? `${widget.name} · table` : 'Table';
    case 'filter':
      return 'Filter controls';
    case 'view':
      return widget?.name ?? 'View';
    case 'section':
      return 'Untitled section';
    case 'richtext':
      return richTextToPlainText(item.document).split('\n')[0]?.slice(0, 80) || 'Text';
    case 'text':
      return 'Text';
    case 'html':
      return 'HTML';
    case 'powerbi':
      return 'Power BI report';
    default:
      return 'Image';
  }
}
export function elementIcon(item: Placement): string {
  switch (elementKindOf(item)) {
    case 'chart':
      return 'insert_chart_outlined';
    case 'table':
      return 'table_chart';
    case 'filter':
      return 'tune';
    case 'section':
      return 'segment';
    case 'richtext':
    case 'text':
      return 'notes';
    case 'html':
      return 'code';
    case 'image':
      return 'image';
    case 'powerbi':
      return 'analytics';
    default:
      return item.displayMode === 'grid' ? 'table_chart' : 'insert_chart_outlined';
  }
}
/** A strict element view of a permissive placement record (for the composer store). */
export function asElement(item: Placement): DashboardElement {
  return { ...item, kind: elementKindOf(item) } as DashboardElement;
}
