import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  TemplateRef,
  Output,
  ViewChild,
} from '@angular/core';
import {
  WidgetViewComponent,
  type DashboardDataScope,
  type GridModel,
  type ModelResource,
  type ViewExportSection,
  type WidgetConfiguration,
} from '@prism/charting';

/** Independent tables use the same server grid, saved presentation and export path as views. */
@Component({
  selector: 'workspace-table-tile',
  standalone: true,
  imports: [WidgetViewComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { class: 'dashboard-tile-content' },
  template: `
    <workspace-widget-view
      [integratedHeaders]="true"
      [model]="model"
      [configuration]="configuration"
      displayMode="grid"
      [dataScope]="dataScope"
      [scopeFilter]="scopeFilter"
      [scopeGroupBy]="scopeGroupBy"
      [editable]="editable"
      [showDownloadAll]="false"
      [exportLabel]="exportLabel"
      [tableTitle]="title || 'Data table'"
      [headerActions]="headerActions"
      (configurationChange)="configurationChange.emit($event)"
    />
  `,
  styles: `
    :host,
    workspace-widget-view {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-width: 0;
      min-height: 0;
    }
    workspace-widget-view {
      flex: 1;
    }
  `,
})
export class TableTileComponent {
  @Input({ required: true }) model!: ModelResource;
  @Input({ required: true }) configuration!: WidgetConfiguration;
  @Input() dataScope?: DashboardDataScope;
  @Input() scopeFilter?: GridModel;
  @Input() scopeGroupBy?: string | null;
  @Input() editable = false;
  @Input() exportLabel = '';
  @Input() title = '';
  @Input() headerActions?: TemplateRef<unknown>;
  @Output() readonly configurationChange = new EventEmitter<WidgetConfiguration>();
  @ViewChild(WidgetViewComponent) private reader?: WidgetViewComponent;

  exportSection(): Promise<ViewExportSection | null> {
    if (!this.reader) throw new Error('The table is still loading. Please try again.');
    return this.reader.exportSection();
  }
  exportCsv(): string {
    return this.reader?.exportCsv() ?? '';
  }
}
