import { injectUiState } from '@prism/charting';
import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
@Component({
  standalone: true,
  imports: [MatDialogModule, MatButtonModule, MatIconModule],
  template: `<h2 mat-dialog-title>Create your first dashboard</h2>
    <mat-dialog-content>
      <p class="tour-kicker">INTERACTIVE DEMO · {{ step() + 1 }} OF {{ steps.length }}</p>
      <div class="tour-progress" aria-label="Tour progress">
        @for (item of steps; track $index) {
          <span [class.done]="$index <= step()"></span>
        }
      </div>
      <h3>{{ steps[step()].title }}</h3>
      <p class="tour-copy">{{ steps[step()].copy }}</p>
      <div class="tour-canvas" aria-label="Example dashboard">
        <div class="demo-heading">
          <mat-icon>dashboard</mat-icon><strong>Quarterly performance</strong
          ><span>{{ step() === 4 ? 'Published v1' : step() === 3 ? 'Preview' : 'Draft' }}</span>
        </div>
        @if (step() === 0) {
          <div class="demo-empty">
            <mat-icon>edit_note</mat-icon>
            <p>Give your dashboard a name and a short description.</p>
          </div>
        }
        @if (step() >= 1) {
          <div class="demo-section">Business performance</div>
          <div class="demo-chart">
            <div class="demo-bars" aria-label="Illustrative bar chart">
              @for (height of [42, 67, 55, 88, 74, 95]; track $index) {
                <span [style.height.%]="height"></span>
              }
            </div>
            <div class="demo-metric">
              <small>Example revenue</small><strong>$1.2M</strong><span>Illustrative data</span>
            </div>
          </div>
        }
        @if (step() >= 2) {
          <div class="demo-note">
            <mat-icon>notes</mat-icon
            ><span
              >Add the story behind the numbers. Use text, HTML, images or Power BI reports.</span
            >
          </div>
        }
      </div>
      <p class="tour-note">
        This tour uses sample content. Your dashboards stay unchanged.
      </p> </mat-dialog-content
    ><mat-dialog-actions
      ><button mat-button mat-dialog-close>Close tour</button><span></span
      ><button mat-button (click)="step.set(step() - 1)" [disabled]="step() === 0">Back</button>
      @if (step() < steps.length - 1) {
        <button mat-button (click)="step.set(step() + 1)">Next</button>
      } @else {
        <button mat-button (click)="ref.close('create')">
          {{ data?.existing ? 'Finish tour' : 'Start a dashboard' }}
        </button>
      }
    </mat-dialog-actions>`,
  styles: `
    .tour-kicker {
      font-size: 10px;
      letter-spacing: 0.1em;
      color: var(--ws-muted);
    }
    .tour-progress {
      display: flex;
      gap: 6px;
    }
    .tour-progress span {
      height: 3px;
      flex: 1;
      background: var(--ws-border);
      border-radius: 2px;
    }
    .tour-progress .done {
      background: var(--ws-accent);
    }
    h3 {
      font-size: 21px;
      margin: 22px 0 8px;
    }
    .tour-copy {
      font-size: 14px;
      line-height: 1.7;
      color: var(--ws-muted);
      min-height: 72px;
    }
    .tour-canvas {
      padding: 18px;
      border: 1px solid var(--ws-border);
      border-radius: 12px;
      min-height: 280px;
      background: var(--mat-sys-surface-container-low);
    }
    .demo-heading {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
    }
    .demo-heading > span {
      margin-left: auto;
      font-size: 10px;
      color: var(--ws-accent);
    }
    .demo-empty {
      display: grid;
      place-items: center;
      padding: 50px 16px;
      color: var(--ws-muted);
      font-size: 13px;
      text-align: center;
    }
    .demo-section {
      font-size: 12px;
      margin: 22px 0 12px;
    }
    .demo-chart {
      display: grid;
      grid-template-columns: 2fr 1fr;
      gap: 24px;
      height: 120px;
    }
    .demo-bars {
      display: flex;
      gap: 10px;
      align-items: flex-end;
      padding: 10px;
      border-bottom: 1px solid var(--ws-border);
    }
    .demo-bars span {
      flex: 1;
      background: var(--ws-accent);
      opacity: 0.7;
      border-radius: 4px 4px 0 0;
    }
    .demo-metric {
      display: flex;
      flex-direction: column;
      justify-content: center;
      gap: 8px;
    }
    .demo-metric strong {
      font-size: 28px;
    }
    .demo-metric small,
    .demo-metric span {
      font-size: 10px;
      color: var(--ws-muted);
    }
    .demo-note {
      display: flex;
      gap: 10px;
      font-size: 12px;
      line-height: 1.6;
      margin-top: 18px;
      padding-top: 12px;
      border-top: 1px solid var(--ws-border);
    }
    .tour-note {
      font-size: 11px;
      color: var(--ws-muted);
      margin: 14px 0 0;
    }
    mat-dialog-actions {
      gap: 6px;
    }
    mat-dialog-actions > span {
      flex: 1;
    }
  `,
})
export class DashboardTourComponent {
  private readonly reactiveState = injectUiState('DashboardTourComponent');

  readonly ref = inject(MatDialogRef<DashboardTourComponent>);
  readonly data = inject<{ existing?: boolean } | null>(MAT_DIALOG_DATA, { optional: true });
  readonly step = this.reactiveState.signal(0);
  readonly steps = [
    {
      title: 'Start with a clear purpose',
      copy: 'Choose Create dashboard. Name it for the audience or question it answers, and add a description in dashboard details.',
    },
    {
      title: 'Bring in a published view',
      copy: 'Choose Add view. Browse data models or the Power BI library, then add a chart or table. Saved view settings come with it.',
    },
    {
      title: 'Organize the story',
      copy: 'Add section headings and supporting text or HTML. Drag elements into position, resize them, or use a layout template.',
    },
    {
      title: 'Try the reader experience',
      copy: 'Choose Preview to test charts, tables and enabled filters. Return to the editor to refine the layout. Your draft is preserved.',
    },
    {
      title: 'Save, publish and share',
      copy: 'Save the draft, then Publish to make that version available. Use Share to choose your audience. Later edits stay in a draft until you publish again.',
    },
  ];
}
