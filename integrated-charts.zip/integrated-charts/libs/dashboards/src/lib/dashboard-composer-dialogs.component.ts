import { injectUiState } from '@prism/charting';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import {
  DASHBOARD_TEMPLATES,
  validImageUrl,
  validPowerBiUrl,
  type DashboardTemplate,
} from './dashboard-composer';
import type { ModelResource, Placement } from '@prism/charting';

@Component({
  standalone: true,
  imports: [
    FormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
  ],
  template: `<h2 mat-dialog-title>{{ data.new ? 'Add ' + kindLabel() : 'Element settings' }}</h2>
    <form #form="ngForm" (ngSubmit)="form.valid && save()">
      <mat-dialog-content>
        <mat-form-field appearance="outline" subscriptSizing="dynamic"
          ><mat-label>{{ item.kind === 'section' ? 'Section heading' : 'Title' }}</mat-label
          ><input
            matInput
            name="title"
            [(ngModel)]="item.title"
            maxlength="120"
            [required]="item.kind === 'section'"
            cdkFocusInitial
        /></mat-form-field>
        <mat-form-field appearance="outline" subscriptSizing="dynamic"
          ><mat-label>Description</mat-label
          ><textarea
            matInput
            name="description"
            [(ngModel)]="item.description"
            maxlength="2000"
            rows="2"
          ></textarea>
        </mat-form-field>
        @if (item.kind !== 'section' && data.sections.length) {
          <mat-form-field appearance="outline" subscriptSizing="dynamic"
            ><mat-label>Section</mat-label
            ><mat-select name="section" [(ngModel)]="item.sectionId"
              ><mat-option value="">No section</mat-option>
              @for (section of data.sections; track section.id) {
                <mat-option [value]="section.id">{{ section.title }}</mat-option>
              }
            </mat-select></mat-form-field
          >
        }
        @if (!item.kind || item.kind === 'view') {
          <mat-form-field appearance="outline" subscriptSizing="dynamic"
            ><mat-label>Presentation</mat-label
            ><mat-select name="displayMode" [(ngModel)]="item.displayMode"
              ><mat-option value="chart" [disabled]="!data.hasChart">Chart</mat-option
              ><mat-option value="grid">Table</mat-option
              ><mat-option value="both" [disabled]="!data.hasChart"
                >Chart and table</mat-option
              ></mat-select
            ></mat-form-field
          >
        }
        @if (item.kind === 'chart') {
          <label class="interaction-field">
            <input
              type="checkbox"
              name="selectFilter"
              [ngModel]="item.interactions?.selectFilter ?? false"
              (ngModelChange)="setChartFiltering($event)"
              [disabled]="!data.hasFilterCategory"
            />
            Click chart to filter dashboard
          </label>
          <p class="field-hint">
            Add Filter controls for the same data model. A category selects a value; a time bucket
            narrows the window.
          </p>
        }
        @if (item.kind === 'image') {
          <mat-form-field appearance="outline" subscriptSizing="dynamic"
            ><mat-label>Image URL</mat-label
            ><input
              matInput
              name="imageUrl"
              [(ngModel)]="item.imageUrl"
              required
              maxlength="2048"
              placeholder="https://example.com/image.png"
          /></mat-form-field>
          <mat-form-field appearance="outline" subscriptSizing="dynamic"
            ><mat-label>Alternative text</mat-label
            ><input matInput name="alt" [(ngModel)]="item.alt" required maxlength="200"
          /></mat-form-field>
          <p class="field-hint">
            Use an HTTPS image or an asset in this workspace. Describe the image for readers using
            assistive technology.
          </p>
        }
        @if (item.kind === 'text' || item.kind === 'html') {
          <mat-form-field appearance="outline" subscriptSizing="dynamic"
            ><mat-label>{{ item.kind === 'html' ? 'HTML content' : 'Text content' }}</mat-label
            ><textarea
              matInput
              name="content"
              [(ngModel)]="item.content"
              required
              maxlength="20000"
              rows="7"
            ></textarea>
          </mat-form-field>
          @if (item.kind === 'html') {
            <p class="field-hint">
              Use headings, paragraphs, lists, tables and links. Scripts and embedded content are
              removed.
            </p>
            <div class="html-preview">
              <strong>Preview</strong>
              <div class="dashboard-prose" [innerHTML]="item.content || ''"></div>
            </div>
          }
        }
        @if (item.kind === 'text' || item.kind === 'html' || item.kind === 'section') {
          <mat-form-field appearance="outline" subscriptSizing="dynamic"
            ><mat-label>Accent</mat-label
            ><mat-select name="tone" [(ngModel)]="item.tone"
              ><mat-option value="neutral">Neutral</mat-option
              ><mat-option value="info">Information</mat-option
              ><mat-option value="success">Positive</mat-option
              ><mat-option value="warning">Attention</mat-option></mat-select
            ></mat-form-field
          >
        }
        @if (item.kind === 'powerbi') {
          <mat-form-field appearance="outline" subscriptSizing="dynamic"
            ><mat-label>Power BI embed URL</mat-label
            ><input
              matInput
              name="embedUrl"
              [(ngModel)]="item.embedUrl"
              required
              maxlength="2048"
              placeholder="https://app.powerbi.com/reportEmbed?reportId=..."
          /></mat-form-field>
          <p class="field-hint">
            Use a Power BI reportEmbed or public view URL. Secure reports require the reader to have
            access to the report.
          </p>
        }
        <fieldset class="position-fields">
          <legend>Desktop placement</legend>
          <mat-form-field appearance="outline" subscriptSizing="dynamic"
            ><mat-label>Column</mat-label
            ><input matInput type="number" name="x" [(ngModel)]="item.x" min="0" max="11" required
          /></mat-form-field>
          <mat-form-field appearance="outline" subscriptSizing="dynamic"
            ><mat-label>Row</mat-label
            ><input
              matInput
              type="number"
              name="y"
              [(ngModel)]="item.y"
              min="0"
              max="1000"
              required
          /></mat-form-field>
          <mat-form-field appearance="outline" subscriptSizing="dynamic"
            ><mat-label>Width</mat-label
            ><input matInput type="number" name="w" [(ngModel)]="item.w" min="2" max="12" required
          /></mat-form-field>
          <mat-form-field appearance="outline" subscriptSizing="dynamic"
            ><mat-label>Height</mat-label
            ><input
              matInput
              type="number"
              name="h"
              [(ngModel)]="item.h"
              [min]="item.kind === 'section' ? 1 : 2"
              max="24"
              required
          /></mat-form-field>
        </fieldset>
        @if (error) {
          <p class="dialog-error" role="alert">{{ error }}</p>
        }</mat-dialog-content
      ><mat-dialog-actions align="end"
        ><button
          mat-button
          type="button"
          mat-dialog-close
          aria-label="Cancel element changes"
          matTooltip="Cancel"
        >
          Cancel</button
        ><button
          mat-button
          type="submit"
          [disabled]="form.invalid"
          aria-label="Apply element settings"
          matTooltip="Apply settings"
        >
          {{ data.new ? 'Add element' : 'Apply settings' }}
        </button></mat-dialog-actions
      >
    </form>`,
  styles: [
    `
      h2 {
        font-size: 18px !important;
      }
      mat-dialog-content {
        display: flex;
        flex-direction: column;
        gap: 12px;
        padding-top: 8px !important;
      }
      mat-form-field {
        width: 100%;
        --mat-form-field-container-height: 44px;
        --mat-form-field-container-vertical-padding: 10px;
        --mat-form-field-container-text-size: 13px;
      }
      .position-fields {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 8px;
        border: 0;
        padding: 0;
        margin: 0;
      }
      .position-fields legend {
        font-size: 11px;
        color: var(--mat-sys-on-surface-variant);
        padding: 0 0 10px;
      }
      .field-hint {
        margin: 0;
        font-size: 11px;
        line-height: 1.6;
        color: var(--mat-sys-on-surface-variant);
      }
      .interaction-field {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 13px;
      }
      .html-preview {
        border: 1px solid var(--ws-border);
        border-radius: 10px;
        padding: 12px;
        max-height: 240px;
        overflow: auto;
        font-size: 12px;
      }
      .dialog-error {
        font-size: 12px;
        color: var(--mat-sys-error);
        margin: 0;
      }
      mat-dialog-actions {
        border-top: 1px solid var(--mat-sys-outline-variant);
      }
      @media (max-width: 480px) {
        .position-fields {
          grid-template-columns: repeat(2, minmax(0, 1fr));
        }
      }
    `,
  ],
})
export class DashboardElementDialogComponent {
  private readonly reactiveState = injectUiState('DashboardElementDialogComponent');

  readonly data = inject<{
    item: Placement;
    sections: Placement[];
    items?: Placement[];
    hasChart?: boolean;
    hasFilterCategory?: boolean;
    new?: boolean;
  }>(MAT_DIALOG_DATA);
  private readonly dialog = inject(MatDialogRef<DashboardElementDialogComponent>);
  item = structuredClone(this.data.item);
  private readonly errorState = this.reactiveState.signal('');
  get error() {
    return this.errorState();
  }
  set error(value) {
    this.errorState.set(value);
  }
  kindLabel() {
    return this.item.kind === 'powerbi' ? 'Power BI report' : this.item.kind || 'view';
  }
  setChartFiltering(enabled: boolean) {
    const interactions = { ...this.item.interactions };
    if (enabled) interactions.selectFilter = true;
    else delete interactions.selectFilter;
    this.item.interactions = Object.keys(interactions).length ? interactions : undefined;
  }
  save() {
    this.error = '';
    this.item.imageUrl = this.item.imageUrl?.trim();
    this.item.embedUrl = this.item.embedUrl?.trim();
    if (this.item.kind === 'section' && !this.item.title?.trim())
      this.error = 'Enter a section heading.';
    else if ((this.item.kind === 'text' || this.item.kind === 'html') && !this.item.content?.trim())
      this.error = 'Enter content for this element.';
    else if (
      this.item.kind === 'image' &&
      (!validImageUrl(this.item.imageUrl || '') || !this.item.alt?.trim())
    )
      this.error = 'Enter a valid HTTPS image URL and alternative text.';
    else if (this.item.kind === 'powerbi' && !validPowerBiUrl(this.item.embedUrl || ''))
      this.error = 'Use an https://app.powerbi.com/reportEmbed or /view URL.';
    else if (
      ![this.item.x, this.item.y, this.item.w, this.item.h].every(Number.isInteger) ||
      this.item.x < 0 ||
      this.item.y < 0 ||
      this.item.y > 1000 ||
      this.item.w < 2 ||
      this.item.x + this.item.w > 12 ||
      this.item.h < (this.item.kind === 'section' ? 1 : 2) ||
      this.item.h > 24
    )
      this.error = 'Choose a placement within the 12-column layout.';
    else if (
      this.item.sectionId === this.data.item.sectionId &&
      this.data.items?.some(
        (other) =>
          other.id !== this.item.id &&
          this.item.x < other.x + other.w &&
          this.item.x + this.item.w > other.x &&
          this.item.y < other.y + other.h &&
          this.item.y + this.item.h > other.y,
      )
    )
      this.error =
        'This position overlaps another element. Choose an open position or cancel and use Arrange sections.';
    if (!this.error) this.dialog.close(this.item);
  }
}

@Component({
  standalone: true,
  imports: [
    FormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    MatFormFieldModule,
    MatSelectModule,
  ],
  template: `<h2 mat-dialog-title>Start with a layout</h2>
    <mat-dialog-content>
      <p class="template-hint">
        {{
          data.replacing
            ? 'Replace the current draft layout. Revert will restore your last saved version.'
            : 'Choose a structure and make it your own. Published views fill the layout automatically.'
        }}
      </p>
      <mat-form-field appearance="outline" subscriptSizing="dynamic"
        ><mat-label>Use views from</mat-label
        ><mat-select [(ngModel)]="modelId"
          ><mat-option value="">All data models</mat-option>
          @for (model of data.models; track model.id) {
            <mat-option [value]="model.id">{{ model.name }}</mat-option>
          }
        </mat-select></mat-form-field
      >
      <div class="template-options">
        @for (template of templates; track template.id) {
          <button
            type="button"
            class="template-option"
            [class.selected]="selected === template.id"
            [attr.aria-pressed]="selected === template.id"
            (click)="selected = template.id"
          >
            <span class="template-preview" [class]="'template-preview ' + template.id"
              ><i></i><i></i><i></i><i></i></span
            ><strong>{{ template.name }}</strong
            ><span>{{ template.description }}</span>
          </button>
        }
      </div> </mat-dialog-content
    ><mat-dialog-actions align="end"
      ><button mat-button mat-dialog-close aria-label="Cancel template">Cancel</button
      ><button
        mat-button
        (click)="apply()"
        aria-label="Apply dashboard template"
        matTooltip="Apply template"
      >
        {{ data.replacing ? 'Replace layout' : 'Use template' }}
      </button></mat-dialog-actions
    >`,
  styles: [
    `
      h2 {
        font-size: 18px !important;
      }
      mat-dialog-content {
        padding-top: 4px !important;
      }
      .template-hint {
        font-size: 12px;
        line-height: 1.6;
        color: var(--mat-sys-on-surface-variant);
        margin: 0 0 14px;
      }
      mat-form-field {
        width: 100%;
        --mat-form-field-container-height: 44px;
        --mat-form-field-container-vertical-padding: 10px;
        --mat-form-field-container-text-size: 13px;
      }
      .template-options {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 10px;
        margin-top: 14px;
      }
      .template-option {
        background: var(--mat-sys-surface);
        color: var(--mat-sys-on-surface);
        border: 1px solid var(--mat-sys-outline-variant);
        border-radius: 8px;
        padding: 12px;
        text-align: left;
        display: flex;
        flex-direction: column;
        gap: 8px;
        cursor: pointer;
      }
      .template-option.selected {
        border-color: var(--mat-sys-primary);
        background: var(--mat-sys-primary-container);
        color: var(--mat-sys-on-primary-container);
      }
      .template-option strong {
        font-size: 13px;
        font-weight: 600;
      }
      .template-option > span:last-child {
        font-size: 11px;
        line-height: 1.5;
      }
      .template-preview {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 4px;
        width: 100%;
        height: 66px;
        padding: 5px;
        background: var(--mat-sys-surface-container-low);
        border-radius: 4px;
      }
      .template-preview i {
        background: var(--mat-sys-primary);
        opacity: 0.3;
        border-radius: 2px;
      }
      .template-preview i:first-child {
        grid-column: 1/-1;
        height: 9px;
        opacity: 0.6;
      }
      .template-preview.comparison {
        grid-template-columns: repeat(2, 1fr);
      }
      .template-preview.comparison i:last-child {
        grid-column: 1/-1;
      }
      .template-preview.story {
        grid-template-columns: 1fr;
      }
      .template-preview.story i:last-child {
        display: none;
      }
      mat-dialog-actions {
        border-top: 1px solid var(--mat-sys-outline-variant);
      }
      @media (max-width: 600px) {
        .template-options {
          grid-template-columns: 1fr;
        }
        .template-option {
          display: grid;
          grid-template-columns: 75px 1fr;
          gap: 4px 12px;
        }
        .template-preview {
          grid-row: 1/3;
        }
        .template-option strong {
          align-self: end;
        }
      }
    `,
  ],
})
export class DashboardTemplateDialogComponent {
  private readonly reactiveState = injectUiState('DashboardTemplateDialogComponent');

  readonly data = inject<{ models: ModelResource[]; replacing: boolean }>(MAT_DIALOG_DATA);
  private readonly dialog = inject(MatDialogRef<DashboardTemplateDialogComponent>);
  readonly templates = DASHBOARD_TEMPLATES;
  private readonly selectedState = this.reactiveState.signal<DashboardTemplate>('overview');
  get selected() {
    return this.selectedState();
  }
  set selected(value) {
    this.selectedState.set(value);
  }
  private readonly modelIdState = this.reactiveState.signal('');
  get modelId() {
    return this.modelIdState();
  }
  set modelId(value) {
    this.modelIdState.set(value);
  }
  apply() {
    this.dialog.close({ template: this.selected, modelId: this.modelId });
  }
}
