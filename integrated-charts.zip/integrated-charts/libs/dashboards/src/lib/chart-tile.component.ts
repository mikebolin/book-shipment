import { FilterValuesFormComponent } from '@prism/charting';
import { injectUiState } from '@prism/charting';
import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  Output,
  SimpleChanges,
  TemplateRef,
  ViewChild,
  computed,
  inject,
} from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { IntegratedChartComponent, type ChartPresentation } from '@prism/charting';
import { fromModel, combineFilterModels } from '@prism/charting';
import { bucketFromSeconds, bucketSecondsLabel } from './dashboard-filter';
import type { ChartResponse } from '@prism/charting';
import type { GridModel } from '@prism/charting';
import type { DashboardDataScope } from '@prism/charting';
import {
  DashboardDataService,
  type DashboardData,
  type DashboardDataHandle,
} from '@prism/charting';
import { FilterScopeChipComponent } from '@prism/charting';
import { ChartFocusComponent } from '@prism/charting';
import { chartDataScope } from '@prism/charting';
import type {
  ModelResource,
  ViewChart,
  ViewChartDataScope,
  ViewFilterControls,
  WidgetConfiguration,
} from '@prism/charting';

/**
 * One chart of a pinned view revision on a dashboard. Data comes from the composer's shared
 * `DashboardDataService`, so many tiles from one model share a single row cache. Readers may
 * adjust the chart filter in memory (when the view allows it); authors edit the element's
 * overrides, which the host persists.
 */
@Component({
  selector: 'workspace-chart-tile',
  standalone: true,
  imports: [
    MatButtonModule,
    NgTemplateOutlet,
    MatIconModule,
    MatTooltipModule,
    IntegratedChartComponent,
    FilterScopeChipComponent,
    FilterValuesFormComponent,
    ChartFocusComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { class: 'dashboard-tile-content', '[attr.data-chart-id]': 'chart.id' },
  template: `
    <header class="tile-scope-header">
      <div class="scope-heading">
        <mat-icon class="chart-title-icon">bar_chart</mat-icon
        ><strong class="chart-title">{{ title || chart.plan.title }}</strong>
        <span class="record-count"
          >{{
            result()?.data ? result()!.data!.matchedRowCount.toLocaleString() : '—'
          }}
          records</span
        >
        @if (data() && showFilters()) {
          <workspace-filter-scope-chip
            [scope]="scope()"
            [preview]="{ rows: data()!.rows, chart: chart }"
            [columns]="data()!.specs"
            [componentLabel]="chart.plan.title"
            component="chart"
            [scopeId]="chart.id"
            [access]="filterAccess()"
            [adjusted]="!editable && changed()"
            [overridden]="editable && changed()"
            [editable]="editable"
            [disabled]="loading()"
            [dense]="true"
            (scopeChange)="applyScope($event)"
            (reset)="resetScope()"
          />
        }
        <span class="toolbar-spacer"></span>
        @if (changed()) {
          <button
            mat-icon-button
            type="button"
            (click)="resetScope()"
            [attr.aria-label]="editable ? 'Reset to the view’s filter' : 'Reset chart filters'"
            [matTooltip]="editable ? 'Reset to the view’s filter' : 'Reset chart filters'"
          >
            <mat-icon>restart_alt</mat-icon>
          </button>
        }
        <button
          mat-icon-button
          type="button"
          aria-label="Expand chart"
          matTooltip="Expand chart"
          [disabled]="!result()?.data"
          (click)="focused.set(true)"
        >
          <mat-icon>open_in_full</mat-icon>
        </button>
        <ng-container [ngTemplateOutlet]="headerActions ?? null" />
      </div>
    </header>
    @if (data() && showValueForm()) {
      <workspace-filter-values-form
        [columns]="data()!.specs"
        [scope]="scope()"
        [label]="chart.plan.title"
        [disabled]="loading()"
        (scopeChange)="applyScope($event)"
      />
    }
    @if (error()) {
      <div class="tile-status" role="alert">
        <strong>Unable to display this chart</strong><span>{{ error() }}</span>
        <button
          mat-icon-button
          type="button"
          aria-label="Retry"
          matTooltip="Retry"
          (click)="reload()"
        >
          <mat-icon>refresh</mat-icon>
        </button>
      </div>
    } @else if (loading()) {
      <div class="tile-status" role="status">
        <span class="loading-line"></span><strong>Loading data</strong>
      </div>
    } @else if (result()?.error) {
      <div class="tile-status" role="alert">
        <strong>Unable to display this chart</strong><span>{{ result()!.error }}</span>
      </div>
    } @else {
      <app-integrated-chart
        [dataset]="result()!.data"
        [captureInitialPresentation]="false"
        [presentation]="chart.presentation"
        [disabled]="!editable"
        [readonlyView]="!editable"
        [allowDownload]="allowDownload"
        [showDownloadControl]="false"
        [compact]="true"
        (presentationChange)="presentationChange.emit($event)"
        (categoryClick)="onCategoryClick($event)"
      />
    }
    @if (focused() && result()?.data) {
      <workspace-chart-focus [title]="chart.plan.title" (closed)="focused.set(false)">
        <app-integrated-chart
          [dataset]="result()!.data"
          [captureInitialPresentation]="false"
          [presentation]="chart.presentation"
          [disabled]="true"
          [readonlyView]="true"
          [allowDownload]="allowDownload"
          [showDownloadControl]="false"
          [compact]="false"
        />
      </workspace-chart-focus>
    }
  `,
  styles: `
    :host {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-width: 0;
      min-height: 0;
      overflow: auto;
    }
    workspace-filter-values-form {
      flex: 0 0 auto;
    }
    .tile-scope-header {
      flex-shrink: 0;
      padding: 4px 8px;
      border-bottom: 1px solid color-mix(in srgb, var(--ws-border) 75%, transparent);
    }
    .scope-heading {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      min-width: 0;
      gap: 6px;
    }
    .record-count {
      font-size: 11px;
      color: var(--ws-muted);
      white-space: nowrap;
    }
    .chart-title {
      min-width: 0;
      max-width: 40%;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      font-size: 13px;
      font-weight: 600;
    }
    .chart-title-icon {
      font-size: 16px;
      width: 16px;
      height: 16px;
      color: var(--ws-muted);
    }
    .toolbar-spacer {
      flex: 1;
    }
    app-integrated-chart {
      display: block;
      flex: 1 1 200px;
      min-height: 160px;
      min-width: 0;
    }
    .tile-status {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 6px;
      padding: 16px;
      text-align: center;
      font-size: 12px;
      color: var(--ws-muted);
    }
    .tile-status strong {
      color: var(--ws-ink);
    }
    .loading-line {
      width: 120px;
      height: 3px;
      border-radius: 2px;
      background: linear-gradient(
        90deg,
        var(--ws-border),
        var(--mat-sys-primary),
        var(--ws-border)
      );
      background-size: 200% 100%;
      animation: slide 1.2s linear infinite;
    }
    @keyframes slide {
      to {
        background-position: -200% 0;
      }
    }
    @media (prefers-reduced-motion: reduce) {
      .loading-line {
        animation: none;
      }
    }
  `,
})
export class ChartTileComponent implements OnChanges, OnDestroy {
  private readonly reactiveState = injectUiState('ChartTileComponent');

  @ViewChild(IntegratedChartComponent) private rendered?: IntegratedChartComponent;
  @Input({ required: true }) model!: ModelResource;
  /** The pinned revision: calculated columns, schema version and default reader controls. */
  @Input({ required: true }) configuration!: WidgetConfiguration;
  /** The chart with the element's overrides already applied. */
  @Input({ required: true }) chart!: ViewChart;
  @Input() dataScope?: DashboardDataScope;
  /** The dashboard-level filter, ANDed with this chart's own scope. */
  @Input() scopeFilter?: GridModel;
  /** Dashboard bucket control: a width in seconds that overrides a fixed-width time axis. */
  @Input() scopeBucketSeconds?: number;
  @Input() editable = false;
  @Input() allowDownload = true;
  @Input() exportLabel = '';
  @Input() title = '';
  @Input() headerActions?: TemplateRef<unknown>;

  @Output() readonly scopeChange = new EventEmitter<ViewChartDataScope>();
  @Output() readonly presentationChange = new EventEmitter<ChartPresentation>();
  /** The clicked category's data value (a time bucket key or a dimension value). */
  @Output() readonly categoryClick = new EventEmitter<string | number>();
  private readonly datasets = inject(DashboardDataService);
  readonly loading = this.reactiveState.signal(true);
  readonly error = this.reactiveState.signal('');
  readonly data = this.reactiveState.signal<DashboardData | null>(null);
  readonly scope = this.reactiveState.signal<ViewChartDataScope>({
    mode: 'advanced',
    filterModel: null,
  });
  readonly result = this.reactiveState.signal<{ data: ChartResponse | null; error: string } | null>(
    null,
  );
  readonly focused = this.reactiveState.signal(false);
  private original: ViewChartDataScope = { mode: 'advanced', filterModel: null };
  readonly changed = computed(() => JSON.stringify(this.scope()) !== JSON.stringify(this.original));
  private handle?: DashboardDataHandle;
  private generation = 0;
  private signature = '';

  ngOnChanges(changes: SimpleChanges) {
    const signature = JSON.stringify([
      this.model.id,
      this.model.body.schemaVersion,
      this.configuration.calculatedColumns ?? [],
      this.dataScope ?? null,
    ]);
    if (signature !== this.signature || !this.handle) {
      this.signature = signature;
      void this.reload();
    } else if (changes['chart']) this.applyChartInput();
    else if (changes['scopeFilter'] || changes['scopeBucketSeconds']) this.query();
  }
  /** The pinned plan with the dashboard's bucket width applied to a fixed-width time axis. */
  private effectivePlan() {
    const plan = this.chart.plan;
    const seconds = this.scopeBucketSeconds;
    if (!seconds || !['second', 'minute', 'hour'].includes(plan.timeBucket ?? '')) return plan;
    const { timeBucket, bucketSize } = bucketFromSeconds(seconds);
    return {
      ...plan,
      timeBucket,
      bucketSize,
      title: plan.title.replace(/\d+\s*(?:s|min|h)\b/, bucketSecondsLabel(seconds)),
    };
  }
  /** Integrated charts report the axis label; map it back to the plotted category value. */
  onCategoryClick(label: string | number) {
    const displayLabels = this.result()?.data?.categoryDisplayLabels;
    const key = displayLabels
      ? Object.keys(displayLabels).find((candidate) => displayLabels[candidate] === String(label))
      : undefined;
    this.categoryClick.emit(key ?? label);
  }
  private controls(): ViewFilterControls | undefined {
    return this.chart.filterControls ?? this.configuration.filterControls;
  }
  showValueForm() {
    const controls = this.controls();
    return (
      controls?.visible !== false && controls?.parameterizable && controls.editMode === 'values'
    );
  }
  showFilters() {
    return this.controls()?.visible !== false;
  }
  filterAccess(): 'none' | 'values' | 'expression' {
    if (this.editable) return 'expression';
    const controls = this.controls();
    return controls?.visible !== false && controls?.parameterizable
      ? (controls.editMode ?? 'expression')
      : 'none';
  }
  private tableScope(): ViewChartDataScope {
    return {
      mode: this.configuration.mode,
      filterModel: (this.configuration.mode === 'advanced'
        ? (this.configuration.gridState.filter?.advancedFilterModel ?? null)
        : (this.configuration.gridState.filter?.filterModel ?? {})) as GridModel,
    };
  }
  /** A new effective chart (override edits) re-queries without touching the shared data. */
  private applyChartInput() {
    this.original = structuredClone(chartDataScope(this.chart, this.tableScope()));
    this.scope.set(structuredClone(this.original));
    this.query();
  }
  private query() {
    const data = this.data();
    if (!data) return;
    try {
      const scope = this.scope();
      const result = data.cache.query(data.source, 'analytics/chart', {
        mode: scope.mode,
        filterModel:
          this.scopeFilter == null
            ? scope.filterModel
            : combineFilterModels(scope.mode, this.scopeFilter, scope.filterModel),
        calculatedColumnIds: (this.configuration.calculatedColumns ?? []).map(
          (column) => column.id,
        ),
        plan: this.effectivePlan(),
      }) as ChartResponse;
      this.result.set({ data: result, error: '' });
    } catch (error) {
      this.result.set({
        data: null,
        error: error instanceof Error ? error.message : 'Unable to prepare this chart.',
      });
    }
  }
  applyScope(scope: ViewChartDataScope) {
    const data = this.data();
    if (this.filterAccess() === 'none' || !data) return;
    try {
      fromModel(scope.filterModel, scope.mode, data.specs);
      this.scope.set(structuredClone(scope));
      this.query();
      if (this.editable) this.scopeChange.emit(structuredClone(scope));
    } catch (error) {
      this.result.set({
        data: null,
        error: error instanceof Error ? error.message : 'Unable to apply these chart filters.',
      });
    }
  }
  resetScope() {
    this.applyScope(structuredClone(this.original));
  }
  exportSection(): import('@prism/charting').ViewExportSection | null {
    if (!this.allowDownload) return null;
    if (this.loading()) throw new Error('Data is still loading. Try again when the page is ready.');
    const result = this.result();
    if (this.error() || !result?.data)
      throw new Error(this.error() || result?.error || 'Chart is not ready.');
    return {
      name: this.exportLabel || this.chart.plan.title,
      charts: [{ data: result.data, presentation: this.chart.presentation }],
    };
  }
  download() {
    if (!this.allowDownload) return;
    this.rendered?.download();
  }
  async reload() {
    const generation = ++this.generation;
    this.handle?.release();
    this.handle = undefined;
    this.data.set(null);
    this.result.set(null);
    this.error.set('');
    this.loading.set(true);
    try {
      if (this.configuration.modelSchemaVersion !== this.model.body.schemaVersion)
        throw new Error(
          'The model schema changed. Republish this view after reviewing its columns.',
        );
      const handle = this.datasets.acquire(
        this.model,
        this.dataScope,
        this.configuration.calculatedColumns ?? [],
      );
      this.handle = handle;
      const data = await handle.ready;
      if (generation !== this.generation) return;
      this.data.set(data);
      this.applyChartInput();
    } catch (error) {
      if (generation === this.generation)
        this.error.set(error instanceof Error ? error.message : 'Unable to load this chart.');
    } finally {
      if (generation === this.generation) this.loading.set(false);
    }
  }
  ngOnDestroy() {
    this.generation++;
    this.handle?.release();
  }
}
