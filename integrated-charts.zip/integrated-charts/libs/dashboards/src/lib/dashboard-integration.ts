import { inject, makeEnvironmentProviders } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { firstValueFrom } from 'rxjs';
import { CHARTING_ACTIONS, type ChartingActions } from '@prism/charting/platform';

/** An optional adapter; Charting has no reference to this library. */
export function provideDashboardIntegration() {
  return makeEnvironmentProviders([
    {
      provide: CHARTING_ACTIONS,
      useFactory: (): ChartingActions => {
        const dialog = inject(MatDialog),
          router = inject(Router);
        return {
          async addToDashboard(widget) {
            const { AddToDashboardDialogComponent } = await import(
              './add-to-dashboard-dialog.component'
            );
            const result = await firstValueFrom(
              dialog
                .open(AddToDashboardDialogComponent, {
                  data: { widget },
                  width: '640px',
                  maxWidth: 'calc(100vw - 24px)',
                })
                .afterClosed(),
            );
            if (result)
              await router.navigate(['/dashboards', result.slug], {
                queryParams: { edit: 1, select: result.placementIds.join(',') },
              });
          },
        };
      },
    },
  ]);
}
