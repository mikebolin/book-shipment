import type { ChartPlan, ColumnSpec, GridModel } from '@prism/charting';

/**
 * Pure helpers for the dashboard-level advanced filter. Readers never edit predicates here: a
 * chart click only rewrites comparison values (a time bucket's bounds) or toggles one equality,
 * so the saved filter keeps its shape and every element still shares the same context.
 */
type Rule = Record<string, unknown>;
const BOUNDS = ['greaterThanOrEqual', 'greaterThan', 'lessThan', 'lessThanOrEqual'];
const pad = (value: number) => String(value).padStart(2, '0');
const isJoin = (rule: Rule) => rule['filterType'] === 'join';

/** Top-level AND conditions of an advanced model; a single rule counts as one condition. */
export function andConditions(model: GridModel): Rule[] {
  if (!model) return [];
  const node = model as Rule;
  if (isJoin(node) && node['type'] === 'AND' && Array.isArray(node['conditions']))
    return (node['conditions'] as Rule[]).map((condition) => ({ ...condition }));
  return [{ ...node }];
}
export function fromConditions(conditions: Rule[]): GridModel {
  if (!conditions.length) return null;
  if (conditions.length === 1) return conditions[0];
  return { filterType: 'join', type: 'AND', conditions };
}

/** AG Grid's canonical Advanced Filter timestamp: UTC wall time with `T` and no zone. */
export function canonicalTimestamp(at: Date): string {
  return at.toISOString().slice(0, 19);
}
export const advancedFilterType = (kind: ColumnSpec['kind']) =>
  kind === 'date' ? 'dateString' : kind === 'datetime' ? 'dateTimeString' : kind;

/** Replace or add the lower and upper bounds on one column; every other condition is retained. */
export function withTimeBounds(
  model: GridModel,
  column: ColumnSpec,
  start: Date,
  endExclusive: Date,
): GridModel {
  const filterType = advancedFilterType(column.kind);
  const format = (at: Date) =>
    column.kind === 'date' ? at.toISOString().slice(0, 10) : canonicalTimestamp(at);
  const rest = andConditions(model).filter(
    (rule) => !(rule['colId'] === column.id && BOUNDS.includes(String(rule['type']))),
  );
  return fromConditions([
    ...rest,
    { filterType, colId: column.id, type: 'greaterThanOrEqual', filter: format(start) },
    { filterType, colId: column.id, type: 'lessThan', filter: format(endExclusive) },
  ]);
}

/** Click-to-filter on a category: select it, replace a different selection, or clear it again. */
export function toggleEquals(
  model: GridModel,
  column: ColumnSpec,
  value: string | number,
): GridModel {
  const conditions = andConditions(model);
  const index = conditions.findIndex(
    (rule) => !isJoin(rule) && rule['colId'] === column.id && rule['type'] === 'equals',
  );
  if (index >= 0 && String(conditions[index]['filter']) === String(value))
    return fromConditions(conditions.filter((_, position) => position !== index));
  const rule: Rule = {
    filterType: advancedFilterType(column.kind),
    colId: column.id,
    type: 'equals',
    filter: column.kind === 'number' ? Number(value) : String(value),
  };
  if (index >= 0) conditions[index] = rule;
  else conditions.push(rule);
  return fromConditions(conditions);
}

/** The half-open span of a chart bucket key, such as `2026-10-03 11:35`, `2026-10` or `2026 Q4`. */
export function bucketSpan(
  key: string | number,
  timeBucket: NonNullable<ChartPlan['timeBucket']>,
  bucketSize = 1,
): { start: Date; end: Date } | null {
  const text = String(key);
  const size = Math.max(1, Math.floor(bucketSize));
  if (timeBucket === 'second' || timeBucket === 'minute' || timeBucket === 'hour') {
    const match = /^(\d{4}-\d{2}-\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?/.exec(text);
    if (!match) return null;
    const start = new Date(`${match[1]}T${match[2]}:${match[3]}:${match[4] ?? '00'}Z`);
    if (!Number.isFinite(start.getTime())) return null;
    const width =
      size * (timeBucket === 'second' ? 1_000 : timeBucket === 'minute' ? 60_000 : 3_600_000);
    return { start, end: new Date(start.getTime() + width) };
  }
  if (timeBucket === 'day') {
    const start = new Date(`${text.slice(0, 10)}T00:00:00Z`);
    if (!Number.isFinite(start.getTime())) return null;
    const end = new Date(start);
    end.setUTCDate(end.getUTCDate() + 1);
    return { start, end };
  }
  if (timeBucket === 'month') {
    const match = /^(\d{4})-(\d{2})/.exec(text);
    if (!match) return null;
    const start = new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, 1));
    const end = new Date(Date.UTC(Number(match[1]), Number(match[2]), 1));
    return { start, end };
  }
  if (timeBucket === 'quarter') {
    const match = /^(\d{4}) Q([1-4])$/.exec(text);
    if (!match) return null;
    const month = (Number(match[2]) - 1) * 3;
    return {
      start: new Date(Date.UTC(Number(match[1]), month, 1)),
      end: new Date(Date.UTC(Number(match[1]), month + 3, 1)),
    };
  }
  const year = Number(text.slice(0, 4));
  if (!Number.isFinite(year)) return null;
  return { start: new Date(Date.UTC(year, 0, 1)), end: new Date(Date.UTC(year + 1, 0, 1)) };
}

/**
 * Apply a chart click to the dashboard filter: a time-bucketed category narrows the window to
 * that bucket; any other category toggles an equality on its column. `undefined` means no change.
 */
export function selectChartCategory(
  model: GridModel,
  plan: ChartPlan,
  column: ColumnSpec,
  value: string | number,
): GridModel | undefined {
  if (plan.timeBucket) {
    const span = bucketSpan(value, plan.timeBucket, plan.bucketSize);
    return span ? withTimeBounds(model, column, span.start, span.end) : undefined;
  }
  return toggleEquals(model, column, value);
}

/** Short label for a bound in chips and summaries (`11:35`, `11:35:06` or `2026-10-03`). */
export function boundLabel(value: unknown): string {
  const text = String(value ?? '');
  const match = /^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})(?::(\d{2}))?/.exec(text);
  if (!match) return text.slice(0, 10);
  return match[3] && match[3] !== '00' ? `${match[2]}:${match[3]}` : match[2];
}
export { pad as padTwo };

/** Equality values on a column: a top-level equals rule or an OR group made only of such rules. */
function equalityGroup(rule: Rule, columnId: string): boolean {
  return (
    isJoin(rule) &&
    rule['type'] === 'OR' &&
    Array.isArray(rule['conditions']) &&
    rule['conditions'].length > 0 &&
    (rule['conditions'] as Rule[]).every(
      (child) => !isJoin(child) && child['colId'] === columnId && child['type'] === 'equals',
    )
  );
}
export function equalityValues(model: GridModel, columnId: string): string[] {
  const values: string[] = [];
  for (const rule of andConditions(model)) {
    if (!isJoin(rule) && rule['colId'] === columnId && rule['type'] === 'equals')
      values.push(String(rule['filter']));
    else if (equalityGroup(rule, columnId))
      values.push(...(rule['conditions'] as Rule[]).map((child) => String(child['filter'])));
  }
  return values;
}
/** Replace the equality selection on one column; an empty selection removes the condition. */
export function withEqualityValues(
  model: GridModel,
  column: ColumnSpec,
  values: readonly string[],
): GridModel {
  const filterType = advancedFilterType(column.kind);
  const rest = andConditions(model).filter(
    (rule) =>
      !(
        (!isJoin(rule) && rule['colId'] === column.id && rule['type'] === 'equals') ||
        equalityGroup(rule, column.id)
      ),
  );
  const rules: Rule[] = [...new Set(values)].map((value) => ({
    filterType,
    colId: column.id,
    type: 'equals',
    filter: column.kind === 'number' ? Number(value) : value,
  }));
  return fromConditions([
    ...rest,
    ...(rules.length > 1 ? [{ filterType: 'join', type: 'OR', conditions: rules }] : rules),
  ]);
}
/** The current lower/upper bound values on a time column, when present at the top level. */
export function timeBounds(model: GridModel, columnId: string): { start?: string; end?: string } {
  const result: { start?: string; end?: string } = {};
  for (const rule of andConditions(model)) {
    if (isJoin(rule) || rule['colId'] !== columnId) continue;
    const value = String(rule['filter'] ?? '');
    if (rule['type'] === 'greaterThanOrEqual' || rule['type'] === 'greaterThan')
      result.start = value;
    if (rule['type'] === 'lessThan' || rule['type'] === 'lessThanOrEqual') result.end = value;
  }
  return result;
}
/** Epoch milliseconds of a date, UTC timestamp or zoned ISO text; null when unreadable. */
export function parseStamp(text: string | undefined | null): number | null {
  if (!text) return null;
  const normalized = text.trim().replace(' ', 'T');
  const at = Date.parse(/(?:Z|[+-]\d{2}:\d{2})$/.test(normalized) ? normalized : normalized + 'Z');
  return Number.isFinite(at) ? at : null;
}
/** Whole minutes between the bounds on a time column, or null without two readable bounds. */
export function windowMinutes(model: GridModel, columnId: string): number | null {
  const { start, end } = timeBounds(model, columnId);
  const from = parseStamp(start),
    to = parseStamp(end);
  return from !== null && to !== null && to > from ? Math.round((to - from) / 60_000) : null;
}
/** A preset recent window: `[anchor − minutes, anchor)` where the anchor is fixed or the current end. */
export function withRecentWindow(
  model: GridModel,
  column: ColumnSpec,
  minutes: number,
  endsAt?: string,
): GridModel {
  const anchor =
    parseStamp(endsAt) ??
    parseStamp(timeBounds(model, column.id).end) ??
    Math.floor(Date.now() / 60_000) * 60_000;
  return withTimeBounds(model, column, new Date(anchor - minutes * 60_000), new Date(anchor));
}

/** `6 s`, `1 min`, `5 min`, `1 h`: the label of a bucket width given in seconds. */
export function bucketSecondsLabel(seconds: number): string {
  if (seconds % 60 !== 0) return `${seconds} s`;
  if (seconds % 3600 === 0) return `${seconds / 3600} h`;
  return `${seconds / 60} min`;
}
/** The chart bucket unit and size for a width in seconds (hours, minutes, else seconds). */
export function bucketFromSeconds(seconds: number): {
  timeBucket: 'second' | 'minute' | 'hour';
  bucketSize: number;
} {
  if (seconds % 3600 === 0) return { timeBucket: 'hour', bucketSize: seconds / 3600 };
  if (seconds % 60 === 0) return { timeBucket: 'minute', bucketSize: seconds / 60 };
  return { timeBucket: 'second', bucketSize: seconds };
}
