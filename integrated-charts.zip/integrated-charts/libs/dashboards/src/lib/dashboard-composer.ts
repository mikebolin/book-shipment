import type { Placement, WidgetConfiguration, WidgetResource } from '@prism/charting';
import { viewCharts } from '@prism/charting';

export type DashboardTemplate = 'overview' | 'comparison' | 'story';
export const DASHBOARD_TEMPLATES: {
  id: DashboardTemplate;
  name: string;
  description: string;
  icon: string;
}[] = [
  {
    id: 'overview',
    name: 'Overview',
    description: 'A concise summary followed by supporting detail.',
    icon: 'dashboard',
  },
  {
    id: 'comparison',
    name: 'Comparison',
    description: 'Two views side by side, with a shared detail section.',
    icon: 'view_week',
  },
  {
    id: 'story',
    name: 'Data story',
    description: 'Introduce the context, then guide readers through the evidence.',
    icon: 'view_agenda',
  },
];

export function validImageUrl(value: string): boolean {
  if (/^\/assets\/(?!\/)/.test(value) && !/[\\\s]/.test(value) && !/%(?:2f|5c|0[ad])/i.test(value))
    return new URL(value, 'https://workspace.invalid').pathname.startsWith('/assets/');
  try {
    const url = new URL(value);
    return (
      url.protocol === 'https:' &&
      !!url.hostname &&
      !url.username &&
      !url.password &&
      !/[\r\n]/.test(value)
    );
  } catch {
    return false;
  }
}
export function validPowerBiUrl(value: string): boolean {
  try {
    const url = new URL(value);
    return (
      url.origin === 'https://app.powerbi.com' &&
      ['/reportEmbed', '/view'].includes(url.pathname) &&
      !url.username &&
      !url.password &&
      !url.hash
    );
  } catch {
    return false;
  }
}

/** Sections and their members stay contiguous; rows never overlap in the 12-column layout. */
export function arrangeDashboard<T extends Placement>(items: T[]): T[] {
  const ordered = [...items].sort((a, b) => a.y - b.y || a.x - b.x);
  const headers = ordered.filter((item) => item.kind === 'section');
  const sectionIds = new Set(headers.map((item) => item.id));
  const groups = [
    ordered.filter(
      (item) => item.kind !== 'section' && (!item.sectionId || !sectionIds.has(item.sectionId)),
    ),
    ...headers.map((header) => [
      header,
      ...ordered.filter((item) => item.sectionId === header.id && item.kind !== 'section'),
    ]),
  ];
  let y = 0;
  const result: T[] = [];
  for (const group of groups) {
    let x = 0,
      rowHeight = 0;
    for (const item of group) {
      const w = item.kind === 'section' ? 12 : Math.max(2, Math.min(12, item.w));
      if (x + w > 12) {
        y += rowHeight;
        x = 0;
        rowHeight = 0;
      }
      result.push({ ...item, x, y, w });
      x += w;
      rowHeight = Math.max(rowHeight, item.h);
      if (x === 12) {
        y += rowHeight;
        x = 0;
        rowHeight = 0;
      }
    }
    y += rowHeight;
  }
  return result;
}

export function templatePlacements(
  template: DashboardTemplate,
  views: WidgetResource[],
  uuid = () => crypto.randomUUID(),
): Placement[] {
  const available = views.filter((view) => view.publishedVersion);
  const section = (title: string, description: string): Placement => ({
    id: uuid(),
    kind: 'section',
    title,
    description,
    x: 0,
    y: 0,
    w: 12,
    h: 2,
  });
  const view = (
    widget: WidgetResource,
    sectionId: string,
    w: number,
    mode?: 'grid' | 'chart' | 'both',
  ): Placement => ({
    id: uuid(),
    kind: 'view',
    widgetId: widget.id,
    widgetRevision: widget.publishedVersion!,
    sectionId,
    displayMode: mode ?? (viewCharts(widget.body).length ? 'chart' : 'grid'),
    x: 0,
    y: 0,
    w,
    h: mode === 'both' ? 9 : 6,
  });
  const intro = section(
    template === 'comparison'
      ? 'Compare perspectives'
      : template === 'story'
        ? 'The story at a glance'
        : 'Performance overview',
    'Add context to help readers understand what matters.',
  );
  const detail = section(
    template === 'story' ? 'Explore the evidence' : 'Supporting detail',
    'Use the underlying detail to explain the headline findings.',
  );
  const count = template === 'overview' ? 3 : template === 'comparison' ? 2 : 1;
  const featured = available
    .slice(0, count)
    .map((widget) =>
      view(widget, intro.id, template === 'overview' ? 4 : template === 'comparison' ? 6 : 12),
    );
  const supporting = available[0]
    ? [
        view(
          available[0],
          detail.id,
          12,
          template === 'story' && viewCharts(available[0].body).length ? 'both' : 'grid',
        ),
      ]
    : [];
  return arrangeDashboard([intro, ...featured, detail, ...supporting]);
}

export function placementBody(item: Placement): Placement {
  const common = {
    id: item.id,
    x: item.x,
    y: item.y,
    w: item.w,
    h: item.h,
    ...(item.title?.trim() ? { title: item.title.trim() } : {}),
    ...(item.description?.trim() ? { description: item.description.trim() } : {}),
    ...(item.sectionId ? { sectionId: item.sectionId } : {}),
    ...(item.tone ? { tone: item.tone } : {}),
  };
  switch (item.kind) {
    case 'text':
    case 'html':
      return { ...common, kind: item.kind, content: item.content?.trim() };
    case 'richtext':
      return { ...common, kind: 'richtext', document: structuredClone(item.document) };
    case 'section':
      return {
        ...common,
        kind: 'section',
        title: item.title?.trim() || 'Untitled section',
        ...(item.layout ? { layout: item.layout } : {}),
        ...(item.collapsed ? { collapsed: true } : {}),
      };
    case 'image':
      return { ...common, kind: 'image', imageUrl: item.imageUrl, alt: item.alt?.trim() };
    case 'powerbi':
      return { ...common, kind: 'powerbi', embedUrl: item.embedUrl };
    case 'chart':
      return {
        ...common,
        kind: 'chart',
        widgetId: item.widgetId,
        widgetRevision: item.widgetRevision,
        chartId: item.chartId,
        ...(item.interactions ? { interactions: { ...item.interactions } } : {}),
        ...(item.overrides && Object.keys(item.overrides).length
          ? { overrides: structuredClone(item.overrides) }
          : {}),
      };
    case 'table':
      return {
        ...common,
        kind: 'table',
        widgetId: item.widgetId,
        widgetRevision: item.widgetRevision,
        ...(item.overrides && Object.keys(item.overrides).length
          ? { overrides: structuredClone(item.overrides) }
          : {}),
      };
    case 'filter':
      return {
        ...common,
        kind: 'filter',
        widgetId: item.widgetId,
        widgetRevision: item.widgetRevision,
        filter: structuredClone(item.filter ?? { mode: 'advanced', filterModel: null }),
        ...(item.controls?.length ? { controls: structuredClone(item.controls) } : {}),
      };
    default:
      return {
        ...common,
        ...(item.kind ? { kind: 'view' as const } : {}),
        widgetId: item.widgetId,
        widgetRevision: item.widgetRevision,
        displayMode: item.displayMode ?? 'grid',
        ...(item.viewOverrides ? { viewOverrides: structuredClone(item.viewOverrides) } : {}),
        ...(item.interactions ? { interactions: { ...item.interactions } } : {}),
      };
  }
}

/** A dashboard title override does not mutate the pinned, reusable published view. */
export function placementConfiguration(
  configuration: WidgetConfiguration,
  title?: string,
  overrides?: Placement['viewOverrides'],
): WidgetConfiguration {
  let effective = overrides ? { ...configuration, ...structuredClone(overrides) } : configuration;
  if (overrides && 'chart' in overrides && overrides.chart === null && !('charts' in overrides))
    effective = { ...effective, charts: [] };
  if (overrides?.charts) {
    // A collection override is authoritative, including edits to the selected source chart.
    const primary =
      overrides.chart ??
      overrides.charts.find((chart) => chart.id === configuration.chart?.id) ??
      overrides.charts[0] ??
      null;
    effective = { ...effective, chart: primary };
  } else if (!effective.chart && effective.charts?.length) {
    effective = { ...effective, chart: effective.charts[0] };
  }
  const sourceChart = viewCharts(configuration).find((chart) => chart.id === effective.chart?.id);
  const hasChartTitleOverride =
    !!(overrides?.chart || overrides?.charts) &&
    effective.chart?.plan.title !== sourceChart?.plan.title;
  return title?.trim() &&
    effective.chart &&
    viewCharts(effective).length === 1 &&
    !hasChartTitleOverride
    ? {
        ...effective,
        chart: {
          ...effective.chart,
          plan: { ...effective.chart.plan, title: title.trim() },
        },
      }
    : effective;
}

/** Place new/duplicated views in the first free area without moving existing content. */
export function openPlacement(
  items: Placement[],
  w = 6,
  h = 6,
): Pick<Placement, 'x' | 'y' | 'w' | 'h'> {
  // The canvas stores section headers separately, but a new top-level element must
  // also clear their contents so saving the nested layout cannot create overlaps.
  items = items.map((item) =>
    item.kind === 'section'
      ? {
          ...item,
          h: Math.max(
            item.h,
            ...items
              .filter((child) => child.sectionId === item.id)
              .map((child) => child.y + child.h - item.y),
          ),
        }
      : item,
  );
  const rows = [...new Set([0, ...items.map((item) => item.y + item.h)])].sort((a, b) => a - b);
  for (const y of rows)
    for (let x = 0; x <= 12 - w; x++) {
      if (
        items.every(
          (item) =>
            x >= item.x + item.w || x + w <= item.x || y >= item.y + item.h || y + h <= item.y,
        )
      )
        return { x, y, w, h };
    }
  return { x: 0, y: Math.max(0, ...items.map((item) => item.y + item.h)), w, h };
}

/** Keep the resized card anchored and move only colliding cards down, preserving their order. */
export function resizePlacement<T extends Placement>(
  items: T[],
  id: string,
  width: number,
  height: number,
): T[] {
  const target = items.find((item) => item.id === id);
  if (!target) return items;
  const w = Math.max(2, Math.min(12, width));
  const h = Math.max(target.kind === 'section' ? 1 : 2, Math.min(24, height));
  const resized = { ...target, w, h, x: Math.min(target.x, 12 - w) };
  const positioned: T[] = [resized];
  const updates = new Map<string, T>([[id, resized]]);
  for (const item of [...items]
    .filter((item) => item.id !== id)
    .sort((a, b) => a.y - b.y || a.x - b.x)) {
    let next = { ...item };
    let blockers: T[];
    while (
      (blockers = positioned.filter(
        (other) =>
          next.x < other.x + other.w &&
          next.x + next.w > other.x &&
          next.y < other.y + other.h &&
          next.y + next.h > other.y,
      )).length
    )
      next = { ...next, y: Math.max(...blockers.map((other) => other.y + other.h)) };
    positioned.push(next);
    updates.set(next.id, next);
  }
  return items.map((item) => updates.get(item.id)!);
}

/** Editing grows a combined tile safely; reader presentation switches leave saved geometry intact. */
export function placementDisplayMode<T extends Placement>(
  items: T[],
  id: string,
  displayMode: 'grid' | 'chart' | 'both',
  editing: boolean,
): T[] {
  const target = items.find((item) => item.id === id);
  const grow = editing && displayMode === 'both' && !!target && target.h < 8;
  const changed = items.map((item) =>
    item.id === id ? { ...item, displayMode, h: grow ? 8 : item.h } : item,
  );
  return grow ? arrangeDashboard(changed) : changed;
}
