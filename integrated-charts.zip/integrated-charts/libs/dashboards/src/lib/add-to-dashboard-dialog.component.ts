import { injectUiState } from '@prism/charting';
import { Component, computed, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { catalogElements, catalogPlacement } from './dashboard-catalog';
import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';
import { WorkspaceRepository } from '@prism/charting';
import type { WorkspaceCard } from '@prism/charting';
import type { DashboardConfiguration, Placement, WidgetResource } from '@prism/charting';
import { openPlacement } from './dashboard-composer';
import { topLevelItems } from './dashboard-migration';
import { viewCharts } from '@prism/charting';

export interface AddToDashboardData {
  /** The published widget resource (its published revision is pinned). */
  widget: WidgetResource;
}

export interface AddToDashboardResult {
  slug: string;
  placementIds: string[];
}

/**
 * Put a published view on a dashboard the user can edit, or on a new one. The composer
 * opens afterwards with the new element selected so the author can refine it.
 */
@Component({
  standalone: true,
  imports: [
    FormsModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatRadioModule,
    MatSelectModule,
    MatCheckboxModule,
  ],
  template: `
    <h2 mat-dialog-title>Add to dashboard</h2>
    <mat-dialog-content>
      <p class="context">
        <strong>{{ data.widget.name }}</strong> · published v{{ data.widget.publishedVersion }} ·
        {{
          chartCount === 0 ? 'table only' : chartCount === 1 ? '1 chart' : chartCount + ' charts'
        }}
      </p>
      @if (error()) {
        <p class="workspace-alert" role="alert">{{ error() }}</p>
      }
      <h3>Dashboard</h3>
      @if (loading()) {
        <p class="hint">Loading your dashboards…</p>
      } @else {
        <mat-form-field appearance="outline" class="name-field">
          <mat-label>Destination dashboard</mat-label>
          <mat-select
            [ngModel]="target()"
            (ngModelChange)="target.set($event)"
            aria-label="Destination dashboard"
          >
            <mat-option value="__new__">New dashboard</mat-option>
            @for (card of dashboards(); track card.id) {
              <mat-option [value]="card.slug">{{ card.name }}</mat-option>
            }
          </mat-select>
        </mat-form-field>
        @if (!dashboards().length) {
          <p class="hint">You have no dashboards you can edit yet; a new one will be created.</p>
        }
      }
      @if (target() === '__new__') {
        <mat-form-field appearance="outline" class="name-field">
          <mat-label>Dashboard name</mat-label>
          <input matInput name="name" [(ngModel)]="newName" maxlength="120" required />
        </mat-form-field>
      }
      <h3>What would you like to add?</h3>
      <mat-radio-group
        class="choices"
        [ngModel]="importMode()"
        (ngModelChange)="importMode.set($event)"
        aria-label="Import format"
      >
        <mat-radio-button value="elements"
          >Individual charts and table<small
            >Choose the pieces you need. Each moves, resizes and filters independently.</small
          ></mat-radio-button
        >
        <mat-radio-button value="view"
          >Whole view with its container<small
            >Keep the Studio layout and all its pieces together.</small
          ></mat-radio-button
        >
      </mat-radio-group>
      @if (importMode() === 'elements') {
        <div class="element-checklist" role="group" aria-label="Elements to import">
          @for (element of elements; track element.id) {
            <mat-checkbox
              [checked]="selectedIds().includes(element.id)"
              (change)="selectElement(element.id, $event.checked)"
              >{{ element.name
              }}<small>{{
                element.kind === 'chart' ? 'Independent chart' : 'Independent table'
              }}</small></mat-checkbox
            >
          }
        </div>
        <p class="hint">
          {{ selectedIds().length }} selected · saved chart filters and formatting are preserved.
        </p>
      } @else {
        <h3>Include in the view</h3>
        <mat-radio-group
          class="choices"
          [ngModel]="display()"
          (ngModelChange)="display.set($event)"
          aria-label="Display"
        >
          @if (chartCount) {
            <mat-radio-button value="chart">Charts</mat-radio-button>
            <mat-radio-button value="both">Table and charts · saved order</mat-radio-button>
          }
          <mat-radio-button value="grid">Table</mat-radio-button>
        </mat-radio-group>
      }
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button type="button" mat-dialog-close [disabled]="busy()">Cancel</button>
      <button
        mat-button
        type="button"
        (click)="submit()"
        [disabled]="busy() || loading() || !valid()"
      >
        {{ busy() ? 'Adding…' : 'Add and open composer' }}
      </button>
    </mat-dialog-actions>
  `,
  styles: `
    .element-checklist {
      display: flex;
      flex-direction: column;
      gap: 6px;
      padding: 12px;
      border: 1px solid var(--ws-border);
      border-radius: 10px;
      margin: 10px 0;
      max-height: 220px;
      overflow: auto;
    }
    .context,
    .hint {
      color: var(--ws-muted);
      font-size: 12px;
      line-height: 1.6;
      margin: 0 0 12px;
    }
    .context strong {
      color: var(--ws-ink);
    }
    h3 {
      font-size: 12px;
      font-weight: 600;
      color: var(--ws-muted);
      margin: 14px 0 6px;
    }
    .choices {
      display: flex;
      flex-direction: column;
      gap: 2px;
      max-height: 240px;
      overflow: auto;
    }
    .choice-name {
      display: block;
      font-size: 13px;
    }
    small {
      display: block;
      color: var(--ws-muted);
      font-size: 11px;
    }
    mat-radio-button mat-icon {
      width: 16px;
      height: 16px;
      font-size: 16px;
      vertical-align: -3px;
      margin-right: 4px;
    }
    .name-field {
      display: block;
      width: 100%;
      margin-top: 8px;
    }
    mat-dialog-actions {
      gap: 8px;
      padding: 12px 24px 20px;
    }
  `,
})
export class AddToDashboardDialogComponent {
  private readonly reactiveState = injectUiState('AddToDashboardDialogComponent');

  readonly data = inject<AddToDashboardData>(MAT_DIALOG_DATA);
  private readonly ref = inject(MatDialogRef<AddToDashboardDialogComponent, AddToDashboardResult>);
  private readonly workspace = inject(WorkspaceRepository);
  readonly loading = this.reactiveState.signal(true);
  readonly busy = this.reactiveState.signal(false);
  readonly error = this.reactiveState.signal('');
  readonly dashboards = this.reactiveState.signal<WorkspaceCard[]>([]);
  readonly target = this.reactiveState.signal('__new__');
  readonly chartCount = viewCharts(this.data.widget.body).length;
  readonly elements = catalogElements([this.data.widget]).filter(
    (element) => element.kind !== 'view',
  );
  readonly importMode = this.reactiveState.signal<'elements' | 'view'>('elements');
  readonly selectedIds = this.reactiveState.signal(
    this.elements
      .filter((element) => (this.chartCount ? element.kind === 'chart' : element.kind === 'table'))
      .map((element) => element.id),
  );
  selectElement(id: string, checked: boolean) {
    this.selectedIds.update((ids) =>
      checked ? [...ids, id] : ids.filter((value) => value !== id),
    );
  }
  readonly display = this.reactiveState.signal<'grid' | 'chart' | 'both'>(
    this.chartCount ? (this.data.widget.body.displayMode ?? 'chart') : 'grid',
  );
  private readonly newNameState = this.reactiveState.signal(`${this.data.widget.name} dashboard`);
  get newName() {
    return this.newNameState();
  }
  set newName(value) {
    this.newNameState.set(value);
  }
  readonly valid = computed(
    () =>
      (this.target() !== '__new__' || !!this.newName.trim()) &&
      (this.importMode() === 'view' || this.selectedIds().length > 0),
  );

  constructor() {
    void this.load();
  }
  private async load() {
    try {
      const cards = await this.workspace.cards('dashboards', 'draft');
      this.dashboards.set(
        cards
          .filter((card) => card.canEdit !== false)
          .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)),
      );
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : String(error));
    } finally {
      this.loading.set(false);
    }
  }
  async submit() {
    if (this.busy() || !this.valid()) return;
    this.busy.set(true);
    this.error.set('');
    this.ref.disableClose = true;
    try {
      const placements: Placement[] = [];
      if (this.importMode() === 'view') {
        placements.push({
          id: crypto.randomUUID(),
          kind: 'view',
          widgetId: this.data.widget.id,
          widgetRevision: this.data.widget.publishedVersion!,
          displayMode: this.display(),
          x: 0,
          y: 0,
          w: this.display() === 'grid' ? 12 : 6,
          h: this.display() === 'both' ? 9 : 6,
        });
      } else {
        for (const element of this.elements.filter((element) =>
          this.selectedIds().includes(element.id),
        ))
          placements.push(catalogPlacement(element, placements));
      }
      if (placements.length > 48) throw new Error('Choose at most 48 elements for one dashboard.');
      let slug: string;
      if (this.target() === '__new__') {
        const created = await this.workspace.create<DashboardConfiguration>('dashboards', {
          name: this.newName.trim(),
          description: '',
          body: { schemaVersion: 2, items: placements },
        });
        slug = created.slug;
      } else {
        const current = await this.workspace.get<DashboardConfiguration>(
          'dashboards',
          this.target(),
        );
        const items = current.body.items ?? [];
        if (items.length + placements.length > 48)
          throw new Error(
            'A dashboard supports up to 48 elements. Choose fewer pieces or create a new dashboard.',
          );
        const occupied = current.body.schemaVersion === 2 ? [...topLevelItems(items)] : [...items];
        for (const placement of placements) {
          Object.assign(placement, openPlacement(occupied, placement.w, placement.h));
          occupied.push(placement);
        }
        const updated = await this.workspace.update<DashboardConfiguration>('dashboards', current, {
          name: current.name,
          description: current.description,
          body: { ...current.body, items: [...items, ...placements] },
        });
        slug = updated.slug;
      }
      this.ref.close({ slug, placementIds: placements.map((placement) => placement.id) });
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : String(error));
    } finally {
      this.busy.set(false);
      this.ref.disableClose = false;
    }
  }
}
