export { DASHBOARD_ROUTES } from './lib/dashboards.routes';
export { provideDashboardIntegration } from './lib/dashboard-integration';
