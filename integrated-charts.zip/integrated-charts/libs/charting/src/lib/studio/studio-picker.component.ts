import { injectUiState } from '../core/state/index';
import {
  Component,
  Input,
  Output,
  EventEmitter,
  OnChanges,
  type SimpleChanges,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import type { StudioSelection } from './studio-state';
import { filterParameters, parameterText } from '../rendering/filter-parameters';
import { viewCharts } from '../rendering/view-charts';
import { calculatedColumnSpec } from '../core/domain/calculated-columns';

@Component({
  selector: 'workspace-studio-picker',
  standalone: true,
  imports: [FormsModule, MatAutocompleteModule, MatInputModule, MatIconModule],
  template: `
    <div class="picker">
      <mat-icon aria-hidden="true">{{ mode === 'published' ? 'lock_outline' : 'search' }}</mat-icon>
      <input
        matInput
        #input
        [ngModel]="search"
        (input)="search = input.value"
        [disabled]="disabled"
        (focus)="search = ''; input.select()"
        [matAutocomplete]="choices"
        aria-label="Find a model or view"
        placeholder="Find a model or view"
      />
      <mat-icon class="chevron" aria-hidden="true">expand_more</mat-icon>
    </div>
    <mat-autocomplete
      #choices="matAutocomplete"
      [displayWith]="display"
      [requireSelection]="true"
      [panelWidth]="'min(520px, calc(100vw - 32px))'"
      class="studio-view-options"
      (optionSelected)="choose($event.option.value)"
      (closed)="search = label"
    >
      @for (group of groups(); track group.id) {
        <mat-optgroup [label]="group.name">
          @for (option of group.options; track option.key) {
            <mat-option [value]="option">
              <span class="option-heading"
                ><mat-icon>{{
                  option.mode === 'model'
                    ? 'storage'
                    : hasChart(option)
                      ? 'bar_chart'
                      : 'table_chart'
                }}</mat-icon
                ><span class="option-name">{{ option.label }}</span>
                <span class="option-status">{{
                  option.mode === 'model'
                    ? 'Model explorer'
                    : option.mode === 'published'
                      ? 'Published · v' + option.widget?.publishedVersion
                      : 'Draft · v' + option.widget?.version
                }}</span></span
              >
            </mat-option>
          }
        </mat-optgroup>
      } @empty {
        <mat-option disabled>No matching models or views</mat-option>
      }
    </mat-autocomplete>
  `,
  styles: `
    :host {
      display: block;
      min-width: 0;
      width: 100%;
    }
    .picker {
      display: flex;
      align-items: center;
      gap: 6px;
      min-width: 0;
      border: 1px solid transparent;
      border-radius: 6px;
      padding: 3px 5px;
      margin-left: -5px;
    }
    .picker:hover,
    .picker:focus-within {
      border-color: var(--ws-border);
      background: var(--mat-sys-surface-container-low);
    }
    .picker:focus-within {
      outline: 2px solid var(--ws-accent);
      outline-offset: 1px;
    }
    input {
      width: 100%;
      min-width: 0;
      border: 0;
      outline: 0;
      background: transparent;
      color: var(--ws-ink);
      font:
        500 16px Roboto,
        sans-serif;
      text-overflow: ellipsis;
    }
    mat-icon {
      flex: 0 0 17px;
      width: 17px;
      height: 17px;
      font-size: 17px;
      color: var(--ws-muted);
    }
    .option-name,
    .option-status {
      display: block;
      line-height: 20px;
    }
    .option-name {
      font-size: 13px;
      font-weight: 600;
      white-space: normal;
    }
    .option-heading {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .option-heading > .option-name {
      flex: 1;
    }
    .option-status {
      flex-shrink: 0;
      font-size: 11px;
    }
    .option-description {
      display: block;
      margin: 5px 0 7px 27px;
      font-size: 12px;
      line-height: 18px;
      color: var(--ws-muted);
    }
    .option-facts {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
      margin: 6px 0 0 27px;
      font-size: 11px;
      color: var(--ws-muted);
    }
    .option-facts > span {
      padding: 2px 7px;
      border-radius: 5px;
      background: var(--mat-sys-surface-container-high);
    }
    .option-filters {
      display: flex;
      gap: 8px;
      align-items: flex-start;
      color: var(--ws-muted);
      margin: 7px 0 0 27px;
      font-size: 11px;
      line-height: 17px;
      white-space: normal;
      overflow-wrap: anywhere;
    }
    .option-filters mat-icon {
      font-size: 14px;
    }
    @media (max-width: 600px) {
      .option-heading {
        flex-wrap: wrap;
      }
      .option-status {
        width: 100%;
        margin-left: 27px;
      }
    }
    .option-status {
      font-size: 11px;
      color: var(--ws-muted);
    }
  `,
})
export class StudioPickerComponent implements OnChanges {
  private readonly reactiveState = injectUiState('StudioPickerComponent');

  @Input() options: StudioSelection[] = [];
  @Input() label = '';
  @Input() mode: StudioSelection['mode'] = 'model';
  @Input() disabled = false;
  @Output() selected = new EventEmitter<StudioSelection>();
  private readonly searchState = this.reactiveState.signal<string | StudioSelection>('');
  get search() {
    return this.searchState();
  }
  set search(value) {
    this.searchState.set(value);
  }
  readonly display = (value: string | StudioSelection) =>
    typeof value === 'string' ? value : (value?.label ?? '');
  ngOnChanges(changes: SimpleChanges) {
    if (changes['label']) this.search = this.label;
  }
  groups() {
    const query = typeof this.search === 'string' ? this.search.trim().toLowerCase() : '';
    const matches = this.options.filter((option) =>
      `${option.model.name} ${option.label} ${option.mode} ${option.widget?.description ?? ''} ${option.widget?.body.group ?? ''} ${(option.widget?.body.tags ?? []).join(' ')}`
        .toLowerCase()
        .includes(query),
    );
    return [...new Set(matches.map((option) => option.model.id))].map((id) => ({
      id,
      name: matches.find((option) => option.model.id === id)!.model.name,
      options: matches.filter((option) => option.model.id === id),
    }));
  }
  hasChart(option: StudioSelection) {
    return !!option.widget && viewCharts(option.widget.body).length > 0;
  }
  chartSummary(option: StudioSelection) {
    const charts = option.widget ? viewCharts(option.widget.body) : [];
    return charts.length
      ? [
          ...new Set(charts.map((chart) => chart.plan.type.replace(/([a-z])([A-Z])/g, '$1 $2'))),
        ].join(', ') + (charts.length > 1 ? ` · ${charts.length} charts` : ' chart')
      : 'Grid';
  }
  recordSummary(option: StudioSelection) {
    const preview = option.widget?.body.preview;
    const savedCount =
      option.widget?.body.recordCount ??
      (preview?.type === 'summary' && typeof preview.value === 'number'
        ? preview.value
        : undefined);
    return (
      (savedCount ?? option.model.body.rowCount).toLocaleString() +
      (savedCount != null ? ' records at save' : ' model records')
    );
  }
  filters(option: StudioSelection) {
    const body = option.widget?.body;
    if (!body) return 'All records';
    try {
      const columns = [
        ...option.model.body.columns,
        ...(body.calculatedColumns ?? []).map((column) =>
          calculatedColumnSpec(column, option.model.body.columns),
        ),
      ];
      const parameters = filterParameters(
        body.mode === 'advanced'
          ? body.gridState.filter?.advancedFilterModel
          : body.gridState.filter?.filterModel,
        body.mode,
        columns,
      );
      return parameters.length
        ? parameters
            .slice(0, 3)
            .map((value) => `${value.label} ${value.operator} ${parameterText(value)}`)
            .join(' · ') + (parameters.length > 3 ? ` · +${parameters.length - 3} conditions` : '')
        : 'All records';
    } catch {
      return 'Saved filter expression';
    }
  }
  choose(option: StudioSelection) {
    this.search = this.label;
    this.selected.emit(option);
  }
}
