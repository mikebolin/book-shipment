import { CHARTING_ACTIONS } from '../core/data-access/charting-actions';
import { injectUiState } from '../core/state/index';
import {
  Component,
  computed,
  inject,
  Injector,
  OnDestroy,
  ViewChildren,
  QueryList,
  effect,
  untracked,
} from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router, RouterLink } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatDialog } from '@angular/material/dialog';
import { firstValueFrom, Subscription, filter, startWith } from 'rxjs';
import { WorkspaceRepository } from '../core/data-access/workspace-repository.service';
import type {
  ModelResource,
  WidgetResource,
  WidgetConfiguration,
  EditorBridge,
} from '../core/domain/workspace.types';
import {
  ViewSettingsDialogComponent,
  type PublicationSettings,
  type ViewSettings,
} from '../rendering/view-settings-dialog.component';
import { ExplorerTabComponent } from '../explorer/explorer-workspace.component';
import { EXPLORER_CONTEXT, type ExplorerContext } from '../explorer/explorer-context';
import { STUDIO_QUERY_EXECUTOR } from '../explorer/studio-query-executor.token';
import type { LocalDataset, ClientDataSourceId } from '../explorer/client-data-sources';
import type { StreamRow } from '../explorer/ndjson-row-stream';
import type { SnapshotLease } from '../core/domain/shared-snapshot';
import { StudioNavigatorComponent } from './studio-navigator.component';
import { WidgetViewComponent } from '../rendering/widget-view.component';
import { studioSelections, type StudioSelection } from './studio-state';
import {
  UnsavedChangesDialogComponent,
  type UnsavedChangesChoice,
  type UnsavedChangesDialogData,
} from '../ui/unsaved-changes-dialog.component';
import {
  LifecycleBarComponent,
  type LifecycleBreadcrumb,
} from '../rendering/lifecycle-bar.component';
import { studioLifecycle, type LifecyclePlan } from '../rendering/lifecycle';
import { UserPreferencesService } from '../core/data-access/user-preferences.service';
import { ConfirmDialogComponent, type ConfirmDialogData } from '../ui/confirm-dialog.component';
import { WorkspaceError } from '../core/data-access/workspace-repository.service';

interface Tab {
  id: string;
  model: ModelResource;
  injector?: Injector;
  lease?: SnapshotLease;
  bridge?: EditorBridge;
  widget?: WidgetResource;
  name: string;
  description: string;
  group: string;
  tags: string[];
  error: string;
  active: boolean;
  loading: boolean;
  revision: number;
  selectionKey?: string;
  configurationLoading?: boolean;
  publication?: PublicationSettings;
  metadataBaseline: string;
  mode: StudioSelection['mode'];
  readonlyConfiguration?: WidgetConfiguration;
  previewMode: 'grid' | 'chart' | 'both';
  operation?: 'naming' | 'saving' | 'publishing' | 'drafting' | 'deleting';
}

@Component({
  standalone: true,
  imports: [
    RouterLink,
    MatButtonModule,
    MatTooltipModule,
    MatIconModule,
    MatMenuModule,
    ExplorerTabComponent,
    StudioNavigatorComponent,
    WidgetViewComponent,
    LifecycleBarComponent,
  ],
  template: `
    <div class="studio-workbench">
      @if (navigatorOpen() && active(); as current) {
        <aside class="studio-navigation" id="studio-navigation" aria-label="Browse views">
          <header>
            <strong>Views</strong>
            <button
              mat-icon-button
              (click)="navigatorOpen.set(false)"
              aria-label="Close view navigator"
              matTooltip="Close view navigator"
            >
              <mat-icon>chevron_left</mat-icon>
            </button>
          </header>
          <workspace-studio-navigator
            [models]="models()"
            [options]="selections()"
            [modelId]="current.model.id"
            [selectedKey]="
              current.widget ? current.widget.id + ':' + current.mode : current.model.id
            "
            [disabled]="busy() || !!current.configurationLoading"
            [canCreate]="true"
            (selected)="select($event)"
            (create)="newConfiguration()"
          />
          <a class="navigator-library" routerLink="/library"
            ><mat-icon>view_module</mat-icon>View library<mat-icon>arrow_outward</mat-icon></a
          >
        </aside>
      }
      <div class="studio-canvas">
        @if (active(); as current) {
          <workspace-lifecycle-bar
            class="studio-command-bar"
            [plan]="lifecycle()"
            [title]="current.widget ? current.name : 'Explore data'"
            [breadcrumb]="breadcrumb(current)"
            [editableTitle]="!!current.widget && editable(current)"
            [busy]="busy() || !!current.configurationLoading"
            (titleChange)="rename(current, $event)"
            (action)="onAction(current, $event)"
          >
            <button
              lifecycle-navigation
              mat-icon-button
              class="navigator-toggle"
              (click)="navigatorOpen.set(!navigatorOpen())"
              [attr.aria-expanded]="navigatorOpen()"
              aria-controls="studio-navigation"
              aria-label="Browse views"
              matTooltip="Browse models and views"
            >
              <mat-icon>view_sidebar</mat-icon>
            </button>
          </workspace-lifecycle-bar>
        } @else if (!error()) {
          <div class="empty-state" role="status">Opening data studio…</div>
        }
        @if (error()) {
          <div class="workspace-alert" role="alert">{{ error() }}</div>
        }
        @if (message()) {
          <div class="workspace-notice" role="status">
            <mat-icon aria-hidden="true">info_outline</mat-icon>
            <span>{{ message() }}</span
            ><button
              mat-icon-button
              (click)="message.set('')"
              aria-label="Dismiss notification"
              matTooltip="Dismiss"
            >
              <mat-icon>close</mat-icon>
            </button>
          </div>
        }
        <div class="studio-editors">
          @for (tab of tabs(); track tab.id) {
            <section class="studio-editor" [hidden]="!tab.active">
              @if (tab.loading || tab.configurationLoading) {
                <div class="empty-state" role="status">
                  <h2>{{ tab.model.name }}</h2>
                  <p>Opening view…</p>
                </div>
              } @else if (tab.error) {
                <div class="workspace-alert" role="alert">{{ tab.error }}</div>
              } @else if (tab.mode === 'published' && tab.readonlyConfiguration) {
                <div class="studio-readonly">
                  <ng-template #publishedActions>
                    <span class="published-lock"
                      ><mat-icon>lock_outline</mat-icon>Configuration locked</span
                    >
                    <div class="studio-preview-actions" role="group" aria-label="View controls">
                      @if (
                        tab.readonlyConfiguration.chart || tab.readonlyConfiguration.charts?.length
                      ) {
                        <button
                          mat-icon-button
                          (click)="tab.previewMode = 'chart'"
                          aria-label="Show chart"
                          matTooltip="Show chart"
                          [attr.aria-pressed]="tab.previewMode === 'chart'"
                          [class.selected]="tab.previewMode === 'chart'"
                        >
                          <mat-icon>bar_chart</mat-icon>
                        </button>
                        <button
                          mat-icon-button
                          (click)="tab.previewMode = 'grid'"
                          aria-label="Show grid"
                          matTooltip="Preview table"
                          [class.selected]="tab.previewMode === 'grid'"
                          [attr.aria-pressed]="tab.previewMode === 'grid'"
                        >
                          <mat-icon>table_chart</mat-icon>
                        </button>
                        <button
                          mat-icon-button
                          (click)="tab.previewMode = 'both'"
                          aria-label="Show chart and grid"
                          matTooltip="Charts and table"
                          [class.selected]="tab.previewMode === 'both'"
                          [attr.aria-pressed]="tab.previewMode === 'both'"
                        >
                          <mat-icon>insert_chart</mat-icon>
                        </button>
                      }
                      @if (tab.readonlyConfiguration.allowDownload !== false) {
                        <span class="studio-preview-divider" aria-hidden="true"></span>
                        <button
                          mat-icon-button
                          type="button"
                          [disabled]="downloading() || tab.configurationLoading"
                          (click)="downloadAll(tab)"
                          aria-label="Download all charts and table"
                          matTooltip="Download every chart and the table"
                          data-action="download"
                        >
                          <mat-icon>download</mat-icon>
                        </button>
                      }
                    </div>
                  </ng-template>
                  <workspace-widget-view
                    [model]="tab.model"
                    [configuration]="tab.readonlyConfiguration"
                    [displayMode]="tab.previewMode"
                    [showDownloadAll]="false"
                    [showDownloadActions]="false"
                    [integratedHeaders]="true"
                    [headerActions]="publishedActions"
                  />
                </div>
              } @else if (tab.injector) {
                <app-explorer-tab [injector]="tab.injector" [active]="tab.active" />
              }
            </section>
          }
        </div>
      </div>
    </div>
  `,
  styles: `
    :host {
      display: flex;
      flex-direction: column;
      height: 100%;
      min-width: 0;
    }
    .studio-workbench {
      display: flex;
      flex: 1;
      min-height: 0;
      position: relative;
    }
    .studio-canvas {
      display: flex;
      flex-direction: column;
      min-width: 0;
      flex: 1;
    }
    .studio-navigation {
      display: flex;
      flex-direction: column;
      width: clamp(300px, 24vw, 360px);
      flex-shrink: 0;
      border-right: 1px solid var(--ws-border);
      background: var(--mat-sys-surface-container-low);
    }
    .studio-navigation > header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      min-height: 44px;
      padding: 4px 8px 0 20px;
      font-size: 13px;
    }
    .studio-navigation workspace-studio-navigator {
      flex: 1;
      min-height: 0;
    }
    .navigator-library {
      display: flex;
      align-items: center;
      gap: 10px;
      color: var(--ws-muted);
      text-decoration: none;
      padding: 16px 20px;
      border-top: 1px solid var(--ws-border);
      font-size: 12px;
    }
    .navigator-library mat-icon {
      width: 17px;
      height: 17px;
      font-size: 17px;
    }
    .navigator-library mat-icon:last-child {
      margin-left: auto;
    }
    .studio-editors {
      flex: 1;
      min-height: 380px;
      position: relative;
    }
    .studio-editor {
      height: 100%;
      min-height: 380px;
    }
    .studio-editor[hidden] {
      display: none !important;
    }
    .studio-readonly {
      display: flex;
      flex-direction: column;
      height: 100%;
      padding: 12px;
    }
    .studio-readonly workspace-widget-view {
      flex: 1;
      min-height: 0;
      border: 1px solid var(--ws-border);
      border-radius: 10px;
      overflow: hidden;
    }
    .published-lock {
      display: flex;
      align-items: center;
      gap: 6px;
      color: var(--ws-muted);
      font-size: 12px;
      white-space: nowrap;
    }
    .published-lock mat-icon {
      width: 16px;
      height: 16px;
      font-size: 16px;
    }
    .studio-preview-actions {
      display: flex;
      align-items: center;
      gap: 2px;
    }
    .studio-preview-divider {
      width: 1px;
      height: 20px;
      margin: 0 6px;
      background: var(--ws-border);
    }
    .studio-preview-actions .selected {
      color: var(--ws-accent);
      background: var(--mat-sys-primary-container);
    }
    .workspace-notice {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      min-height: 34px;
      padding: 2px 16px;
      margin: 0;
      border-radius: 0;
      border: 0;
      border-bottom: 1px solid var(--ws-border);
      background: var(--mat-sys-surface-container-low);
      color: var(--ws-muted);
      font-size: 12px;
    }
    .workspace-notice > mat-icon {
      flex-shrink: 0;
      width: 16px;
      height: 16px;
      font-size: 16px;
      color: var(--ws-accent);
    }
    .workspace-notice > span {
      flex: 1;
      min-width: 0;
    }
    .workspace-notice > button {
      --mat-icon-button-state-layer-size: 28px;
      --mat-icon-button-touch-target-display: none;
      flex-shrink: 0;
      width: 28px;
      height: 28px;
      padding: 5px;
    }
    .workspace-notice > button mat-icon {
      width: 18px;
      height: 18px;
      font-size: 18px;
    }
    @media (max-width: 700px) {
      .studio-navigation {
        position: absolute;
        inset: 0 auto 0 0;
        width: min(290px, 100%);
        z-index: 45;
        box-shadow: 12px 0 35px #0002;
      }
      .studio-readonly {
        padding: 6px;
      }
    }
  `,
})
export class StudioComponent implements OnDestroy {
  private readonly queryExecutor = inject(STUDIO_QUERY_EXECUTOR);
  readonly hostActions = inject(CHARTING_ACTIONS);
  private readonly reactiveState = injectUiState('StudioComponent');

  readonly workspace = inject(WorkspaceRepository);
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private parent = inject(Injector);
  private dialog = inject(MatDialog);
  private readonly preferences = inject(UserPreferencesService);
  @ViewChildren(WidgetViewComponent) private readers!: QueryList<WidgetViewComponent>;
  readonly downloading = this.reactiveState.signal(false);
  readonly savedWidgets = computed(() => this.workspace.store.list<WidgetConfiguration>('widgets'));
  readonly publishedWidgets = computed(() =>
    this.workspace.store.list<WidgetConfiguration>('widgets', true),
  );
  readonly models = this.workspace.store.modelList;
  readonly selections = computed(() =>
    studioSelections(this.models(), this.savedWidgets(), this.publishedWidgets()),
  );
  readonly tabs = this.reactiveState.signal<Tab[]>([]);
  readonly active = this.reactiveState.signal<Tab | null>(null);
  readonly error = this.reactiveState.signal('');
  readonly message = this.reactiveState.signal('');
  readonly busy = this.reactiveState.signal(false);
  readonly navigatorOpen = this.reactiveState.signal(
    window.matchMedia('(min-width: 1200px)').matches,
  );
  private subscription = new Subscription();
  private destroyed = false;
  private lastModelTab = new Map<string, string>();

  async downloadAll(tab: Tab): Promise<void> {
    if (this.downloading() || this.busy()) return;
    this.downloading.set(true);
    this.error.set('');
    try {
      if (tab.mode === 'published') {
        const reader = this.readers.find(
          (item) => item.configuration === tab.readonlyConfiguration,
        );
        if (!reader || reader.loading())
          throw new Error('The view is still loading. Please try again.');
        await reader.downloadAll();
      } else {
        if (!tab.bridge?.downloadAll)
          throw new Error('The view is still loading. Please try again.');
        await tab.bridge.downloadAll();
      }
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : 'Unable to download this view.');
    } finally {
      this.downloading.set(false);
    }
  }

  /** Leaving the studio: every dirty editor is saved, discarded or kept in one decision. */
  async canLeave(): Promise<boolean> {
    const pending = this.tabs().filter((tab) => this.dirty(tab));
    if (!pending.length) return true;
    const choice = await this.confirmUnsaved(pending, 'leave');
    if (choice === 'stay') return false;
    if (choice === 'discard') {
      for (const tab of pending) this.discardChanges(tab);
      return true;
    }
    for (const tab of pending) if (!(await this.saveTab(tab, false))) return false;
    return !this.tabs().some((tab) => this.dirty(tab));
  }
  private async confirmUnsaved(
    pending: Tab[],
    reason: 'leave' | 'close',
  ): Promise<UnsavedChangesChoice> {
    const explorations = pending.filter((tab) => !tab.widget);
    const data: UnsavedChangesDialogData = {
      name: pending[0].name,
      names: pending.map((tab) => (tab.widget ? tab.name : `your ${tab.model.name} exploration`)),
      title: explorations.length === pending.length ? 'Save as a view?' : 'Save your changes?',
      description:
        explorations.length === pending.length
          ? 'Exploration is not kept unless you save it as a view. Charts, filters and calculations would be lost.'
          : explorations.length
            ? 'Drafts are saved in place; an exploration is saved as a new view. Published content stays as it is.'
            : 'Save a draft to pick up where you left off. Published content stays as it is.',
      saveLabel:
        explorations.length === pending.length
          ? 'Save as view'
          : explorations.length
            ? 'Save all'
            : pending.length > 1
              ? 'Save drafts'
              : 'Save draft',
      keepLabel: explorations.length === pending.length ? 'Keep exploring' : 'Keep editing',
      discardLabel: reason === 'close' ? 'Close without saving' : 'Discard changes',
    };
    const choice = await firstValueFrom(
      this.dialog
        .open(UnsavedChangesDialogComponent, {
          data,
          width: '520px',
          maxWidth: 'calc(100vw - 24px)',
        })
        .afterClosed(),
    );
    return choice === 'save' || choice === 'discard' ? choice : 'stay';
  }
  /** Return an editor to its last saved state (or a blank explorer) without a dialog. */
  discardChanges(tab: Tab): void {
    if (!this.editable(tab)) return;
    if (tab.widget) {
      this.setWidget(tab, tab.widget);
      tab.bridge?.restore(structuredClone(tab.widget.body));
    } else tab.bridge?.reset();
    tab.bridge?.markSaved();
    this.changed();
  }
  private readonly anyDirty = computed(() => this.tabs().some((tab) => this.dirty(tab)));
  private readonly unloadGuard = (event: BeforeUnloadEvent) => {
    event.preventDefault();
    event.returnValue = '';
  };

  constructor() {
    // The browser prompt only exists while something is unsaved.
    effect(() => {
      const dirty = this.anyDirty();
      untracked(() => {
        window.removeEventListener('beforeunload', this.unloadGuard);
        if (dirty) window.addEventListener('beforeunload', this.unloadGuard);
      });
    });
    void this.init();
  }
  private async init() {
    try {
      const [models, drafts, published] = await Promise.all([
        this.workspace.list<ModelResource['body']>('models'),
        this.workspace.list<WidgetConfiguration>('widgets'),
        this.workspace.list<WidgetConfiguration>('widgets', true),
      ]);
      if (this.destroyed) return;

      if (!this.route.snapshot.paramMap.has('slug') && models[0]) {
        await this.router.navigate(['/studio', models[0].slug], { replaceUrl: true });
        return;
      }
      this.subscription.add(
        this.router.events
          .pipe(
            filter((event) => event instanceof NavigationEnd),
            startWith(null),
          )
          .subscribe(() => {
            // Read both parts of the completed route together. Separate emissions can
            // briefly pair the previous model with the next view and reset its editor.
            const { paramMap: params, queryParamMap: query } = this.route.snapshot;
            void this.open(
              params.get('slug') ?? this.models()[0]?.slug,
              query.get('widget'),
              query.get('view'),
            );
          }),
      );
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : String(error));
    }
  }
  tabQuery(id: string) {
    const tab = this.tabs().find((tab) => tab.id === this.lastModelTab.get(id));
    return tab ? this.queryFor(tab) : {};
  }
  modelTabs(id: string) {
    return this.tabs().filter((tab) => tab.model.id === id);
  }
  queryFor(tab: Tab) {
    return tab.widget ? { widget: tab.widget.slug, view: tab.mode } : {};
  }
  async closeTab(tab: Tab) {
    if (this.busy()) return;
    if (this.dirty(tab)) {
      const choice = await this.confirmUnsaved([tab], 'close');
      if (choice === 'stay') return;
      if (choice === 'save' && !(await this.saveTab(tab, false))) return;
    }
    ++tab.revision;
    tab.lease?.release();
    this.tabs.update((tabs) => tabs.filter((value) => value !== tab));
    if (this.lastModelTab.get(tab.model.id) === tab.id) this.lastModelTab.delete(tab.model.id);
    if (tab.active) {
      const next = this.modelTabs(tab.model.id).at(-1) ?? this.tabs().at(-1);
      this.active.set(null);
      if (next)
        await this.router.navigate(['/studio', next.model.slug], {
          queryParams: this.queryFor(next),
        });
      else {
        await this.router.navigate(['/studio', tab.model.slug]);
        if (!this.active()) await this.open(tab.model.slug, null, null);
      }
    }
  }
  editable(tab: Tab) {
    return true && tab.mode !== 'published';
  }
  /** Work that deserves a prompt: any change to a draft, meaningful work in an exploration. */
  dirty(tab: Tab) {
    if (!this.editable(tab)) return false;
    if (tab.widget)
      return !!tab.bridge?.hasChanges() || this.metadataKey(tab) !== tab.metadataBaseline;
    return !!tab.bridge?.hasChanges() && (tab.bridge.hasMeaningfulWork?.() ?? true);
  }
  /** Any edit at all, layout included: enough to offer Save, not enough to warn. */
  hasEdits(tab: Tab) {
    return (
      this.editable(tab) &&
      (!!tab.bridge?.hasChanges() ||
        (!!tab.widget && this.metadataKey(tab) !== tab.metadataBaseline))
    );
  }
  /** The header plan for the active tab; copy and action sets live in `studioLifecycle`. */
  readonly lifecycle = computed<LifecyclePlan>(() => {
    this.tabs();
    this.busy();
    const tab = this.active();
    if (!tab)
      return studioLifecycle({
        mode: 'model',
        modelName: '',
        dirty: false,
        hasEdits: false,
        canEdit: false,
        canDownload: false,
        editorReady: false,
      });
    return studioLifecycle(this.lifecycleInput(tab));
  });
  private lifecycleInput(tab: Tab) {
    const newerDraft =
      tab.mode === 'published' && tab.widget
        ? this.savedWidgets().find(
            (widget) =>
              widget.id === tab.widget!.id &&
              widget.publishedVersion != null &&
              widget.version > widget.publishedVersion,
          )
        : undefined;
    return {
      mode: tab.mode,
      modelName: tab.model.name,
      version: tab.widget?.version,
      publishedVersion: tab.widget?.publishedVersion ?? null,
      draftVersion: newerDraft?.version,
      dirty: this.dirty(tab),
      hasEdits: this.hasEdits(tab),
      canEdit: true,
      canAddToDashboard: !!this.hostActions.addToDashboard,
      canDownload:
        !this.downloading() &&
        !tab.loading &&
        !tab.configurationLoading &&
        (tab.mode !== 'published' || tab.readonlyConfiguration?.allowDownload !== false),
      editorReady:
        !tab.loading &&
        !tab.configurationLoading &&
        (tab.mode === 'published'
          ? !!tab.readonlyConfiguration
          : !!tab.bridge && (tab.bridge.canCapture?.() ?? true)),
      operation: tab.operation,
    };
  }
  breadcrumb(tab: Tab): LifecycleBreadcrumb[] {
    return [
      { label: 'Data studio', link: ['/studio'] },
      { label: tab.model.name, link: ['/studio', tab.model.slug] },
      ...(tab.widget ? [{ label: tab.name }] : []),
    ];
  }
  /** Inline rename from the header; the settings dialog keeps the same field. */
  rename(tab: Tab, name: string) {
    if (!tab.widget || !this.editable(tab) || !name.trim()) return;
    tab.name = name.trim();
    this.changed();
  }
  async onAction(tab: Tab, id: string) {
    switch (id) {
      case 'save':
        return void (await this.save(false));
      case 'saveAsNew':
        return void (await this.save(true));
      case 'publish':
        return this.publish();
      case 'editDraft':
        return this.editDraft();
      case 'settings':
        return this.editSettings();
      case 'download':
        return this.downloadAll(tab);
      case 'discard':
      case 'reset':
        return this.discardChanges(tab);
      case 'preview':
        return this.previewAsReader(tab);
      case 'openPublished':
        return void this.router.navigate(['/studio', tab.model.slug], {
          queryParams: { widget: tab.widget?.slug, view: 'published' },
        });
      case 'copyLink':
        return this.copyLink(tab);
      case 'addToDashboard':
        return this.addToDashboard(tab);
      case 'delete':
        return this.deleteView(tab);
      case 'import':
        return void this.router.navigate(['/studio/import']);
      case 'library':
        return void this.router.navigate(['/library']);
    }
  }
  async previewAsReader(tab: Tab) {
    if (this.busy() || tab.configurationLoading) return;
    try {
      const configuration =
        tab.mode === 'published' ? tab.readonlyConfiguration : tab.bridge?.capture();
      if (!configuration) throw new Error('The view is still loading. Please try again.');
      const { ReaderPreviewDialogComponent } = await import(
        '../rendering/reader-preview-dialog.component'
      );
      this.dialog.open(ReaderPreviewDialogComponent, {
        data: { name: tab.name, model: tab.model, configuration },
        width: '96vw',
        maxWidth: '1600px',
        height: '92vh',
        panelClass: 'reader-preview-dialog',
        autoFocus: 'dialog',
      });
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : String(error));
    }
  }
  async copyLink(tab: Tab) {
    if (!tab.widget) return;
    const url = new URL(`/views/${tab.widget.slug}`, window.location.origin).toString();
    try {
      await navigator.clipboard.writeText(url);
      this.message.set('Link copied: ' + url);
    } catch {
      this.message.set('Reader link: ' + url);
    }
  }
  async addToDashboard(tab: Tab) {
    if (tab.widget && tab.mode === 'published' && !this.busy())
      await this.hostActions.addToDashboard?.(tab.widget);
  }
  async deleteView(tab: Tab) {
    if (!tab.widget || this.busy()) return;
    const confirmed = await firstValueFrom(
      this.dialog
        .open(ConfirmDialogComponent, {
          data: {
            title: `Delete ${tab.name}?`,
            message: tab.widget.publishedVersion
              ? 'The draft and every published revision are removed. Readers lose access immediately.'
              : 'This draft has never been published; it is removed for everyone.',
            detail: 'Dashboards that use this view keep it: delete those elements first.',
            confirmLabel: 'Delete view',
            destructive: true,
          } satisfies ConfirmDialogData,
          width: '480px',
          maxWidth: 'calc(100vw - 24px)',
        })
        .afterClosed(),
    );
    if (!confirmed || this.destroyed) return;
    this.busy.set(true);
    this.error.set('');
    tab.operation = 'deleting';
    try {
      const current = await this.workspace.get<WidgetConfiguration>('widgets', tab.widget.slug);
      await this.workspace.remove('widgets', current);
      const id = current.id;

      for (const other of this.tabs().filter((value) => value.widget?.id === id)) {
        ++other.revision;
        other.lease?.release();
      }
      this.tabs.update((tabs) => tabs.filter((value) => value.widget?.id !== id));
      this.active.set(null);
      this.message.set(`Deleted ${current.name}.`);
      await this.router.navigate(['/studio', tab.model.slug]);
      if (!this.active()) await this.open(tab.model.slug, null, null);
    } catch (error) {
      tab.operation = undefined;
      this.error.set(
        error instanceof WorkspaceError && error.code === 'IN_USE'
          ? 'This view is placed on a dashboard. Remove it from the dashboard first.'
          : error instanceof Error
            ? error.message
            : String(error),
      );
    } finally {
      this.busy.set(false);
    }
  }
  private metadataKey(tab: Tab) {
    return JSON.stringify([tab.name, tab.description, tab.group, tab.tags, tab.publication]);
  }
  private changed() {
    this.tabs.update((tabs) => [...tabs]);
  }
  private setWidget(tab: Tab, widget?: WidgetResource) {
    tab.widget = widget;
    tab.name = widget?.name ?? tab.model.name + ' view';
    tab.description = widget?.description ?? '';
    tab.group = widget?.body.group ?? '';
    tab.tags = widget?.body.tags ?? [];
    tab.publication = widget
      ? {
          displayMode: widget.body.displayMode ?? (widget.body.chart ? 'both' : 'grid'),
          allowDownload: widget.body.allowDownload ?? true,
          serverGrid: widget.body.serverGrid,
          filterControls: widget.body.filterControls ?? { visible: true, parameterizable: false },
        }
      : undefined;
    tab.metadataBaseline = this.metadataKey(tab);
  }
  private async open(slug: string, widgetSlug: string | null, requestedMode: string | null) {
    if (this.destroyed) return;
    const model = this.models().find((model) => model.slug === slug);
    if (!model) {
      this.error.set('Data model not found.');
      return;
    }
    const saved = this.savedWidgets().find((widget) => widget.slug === widgetSlug);
    const mode: Tab['mode'] = !widgetSlug
      ? 'model'
      : requestedMode === 'draft' && saved && saved.version !== saved.publishedVersion
        ? 'draft'
        : requestedMode === 'published' || saved?.publishedVersion
          ? 'published'
          : 'draft';
    const key = `${widgetSlug ?? ''}:${mode}`;
    this.tabs().forEach((tab) => {
      tab.active = false;
    });
    let tab = this.tabs().find((tab) => tab.model.id === model.id && tab.selectionKey === key);
    if (!tab) {
      tab = {
        id: crypto.randomUUID(),
        selectionKey: key,
        model,
        name: model.name + ' view',
        description: '',
        group: '',
        tags: [],
        error: '',
        active: true,
        loading: true,
        revision: 0,
        metadataBaseline: '',
        mode,
        previewMode: 'grid',
      };
      this.setWidget(tab);
      this.tabs.update((tabs) => [...tabs, tab!]);
    }
    tab.active = true;
    this.active.set(tab);
    this.lastModelTab.set(model.id, tab.id);
    this.changed();
    this.error.set('');
    this.message.set('');
    if (
      tab.configurationLoading ||
      (tab.selectionKey === key && (tab.injector || tab.readonlyConfiguration))
    )
      return;
    const revision = ++tab.revision;
    tab.configurationLoading = true;
    tab.error = '';
    this.error.set('');
    this.message.set('');
    tab.injector = undefined;
    tab.bridge = undefined;
    tab.readonlyConfiguration = undefined;
    this.changed();
    try {
      const widget = widgetSlug
        ? await this.workspace.get<WidgetConfiguration>('widgets', widgetSlug, mode === 'published')
        : undefined;
      if (this.destroyed || revision !== tab.revision) return;
      if (widget && widget.modelId !== model.id)
        throw new Error('This view belongs to a different model.');
      if (widget && widget.body.modelSchemaVersion !== model.body.schemaVersion)
        throw new Error(
          'This view uses an older model schema. Open the default model to create a new view.',
        );
      this.setWidget(tab, widget);
      tab.mode = mode;
      if (mode === 'published' && widget) {
        tab.readonlyConfiguration = {
          ...widget.body,
        };
        tab.previewMode =
          widget.body.chart || widget.body.charts?.length
            ? (widget.body.displayMode ?? 'chart')
            : 'grid';
      } else {
        const source = model.body.clientSourceId as ClientDataSourceId;
        const serverSideOnly = !!this.queryExecutor && !source.startsWith('local_');
        if (!serverSideOnly) tab.lease ??= this.workspace.lease(model);
        const data = serverSideOnly ? undefined : await tab.lease!.result;
        if (this.destroyed || revision !== tab.revision) return;
        const dataset: LocalDataset | undefined =
          source.startsWith('local_') && data
            ? {
                metadata: { ...model.body, id: source as `local_${string}`, local: true },
                rows: data.rows as StreamRow[],
                originalFields: model.body.columns.map((column) => ({
                  originalName: column.id,
                  columnId: column.id,
                  inferredType: column.kind,
                  gridType: column.kind,
                  nullable: column.nullable,
                  identifier: column.chartRole === 'identifier',
                  unique: column.chartRole === 'identifier',
                })),
                warnings: [],
                provenance: {
                  kind: 'local-json',
                  fileName: model.slug,
                  bytes: data.decodedBytes,
                  importedAt: new Date().toISOString(),
                  rowCount: data.rows.length,
                },
              }
            : undefined;
        const context: ExplorerContext = {
          id: crypto.randomUUID(),
          initialSource: source,
          dataset,
          snapshotRows: data?.rows as StreamRow[] | undefined,
          serverSideOnly,
          ...(serverSideOnly
            ? {
                capabilities: {
                  liveAiAvailable: false,
                  liveAiProvider: null,
                  chartRecommendationsAvailable: false,
                },
                loadSnapshotRows: async () => {
                  tab!.lease ??= this.workspace.lease(model);
                  return (await tab!.lease.result).rows as readonly StreamRow[];
                },
              }
            : {}),
          modelDefinition: model.body,
          configuration: widget?.body,
          modelSources: this.models().map((model) => ({
            id: model.body.clientSourceId as ClientDataSourceId,
            label: model.name,
          })),
          isActive: () => tab!.active,
          attachEditor: (bridge) => {
            if (revision !== tab!.revision) return;
            tab!.bridge = bridge ?? undefined;
            this.changed();
          },
          openTab: (source) => {
            const target = this.models().find((model) => model.body.clientSourceId === source.id);
            if (target) void this.router.navigate(['/studio', target.slug]);
          },
        };
        tab.injector = Injector.create({
          parent: this.parent,
          providers: [{ provide: EXPLORER_CONTEXT, useValue: context }],
        });
      }
      tab.selectionKey = key;
    } catch (error) {
      if (this.destroyed || revision !== tab.revision) return;
      tab.error = error instanceof Error ? error.message : String(error);
      tab.lease?.release();
      tab.lease = undefined;
    } finally {
      if (revision === tab.revision) {
        tab.loading = false;
        tab.configurationLoading = false;
        this.changed();
      }
    }
    if (requestedMode === 'new' && this.active() === tab && true) {
      await this.router.navigate(['/studio', model.slug], { replaceUrl: true });
      await this.newConfiguration();
    }
  }
  select(option: StudioSelection) {
    if (window.matchMedia('(max-width: 700px)').matches) this.navigatorOpen.set(false);
    if (this.busy()) return;
    void this.router.navigate(['/studio', option.model.slug], {
      queryParams: option.widget ? { widget: option.widget.slug, view: option.mode } : {},
    });
  }
  private settings(tab: Tab, configuration: WidgetConfiguration): ViewSettings {
    return {
      name: tab.name,
      description: tab.description,
      group: tab.group,
      tags: tab.tags,
      displayMode:
        configuration.displayMode ??
        tab.publication?.displayMode ??
        (configuration.chart ? 'chart' : 'grid'),
      filterControls: tab.publication?.filterControls ?? { visible: true, parameterizable: true },
      allowDownload: tab.publication?.allowDownload ?? configuration.allowDownload ?? true,
      serverGrid: tab.publication?.serverGrid ?? configuration.serverGrid,
    };
  }
  /** Reader-facing settings layered over the captured configuration; chart titles are untouched. */
  private configuredBody(
    configuration: WidgetConfiguration,
    value: ViewSettings,
  ): WidgetConfiguration {
    const body = structuredClone(configuration);
    return {
      ...body,
      group: value.group,
      tags: value.tags,
      displayMode: body.chart || body.charts?.length ? value.displayMode : 'grid',
      filterControls: value.filterControls,
      allowDownload: value.allowDownload ?? true,
      serverGrid: value.serverGrid,
    };
  }
  async newConfiguration() {
    const tab = this.active();
    if (!tab || this.busy() || tab.configurationLoading) return;
    await this.createView(
      tab,
      {
        schemaVersion: 1,
        modelSchemaVersion: tab.model.body.schemaVersion,
        mode: 'advanced',
        gridState: {},
        calculatedColumns: [],
        chart: null,
      },
      'blank',
    );
  }
  /**
   * Create a view from this tab. A `capture` of an exploration turns the tab itself into
   * the draft (the work is saved, nothing is left behind to warn about); a `blank` view or
   * a `copy` opens in its own tab and leaves this one as it is.
   */
  private async createView(
    tab: Tab,
    configuration: WidgetConfiguration,
    origin: 'capture' | 'blank' | 'copy',
  ): Promise<WidgetResource | undefined> {
    const copy = origin === 'copy';
    this.busy.set(true);
    this.error.set('');
    this.message.set('');
    let created: WidgetResource | undefined;
    try {
      const initial = this.settings(tab, configuration);
      await firstValueFrom(
        this.dialog
          .open(ViewSettingsDialogComponent, {
            width: '600px',
            maxWidth: 'calc(100vw - 24px)',
            data: {
              title: copy ? 'Save a copy' : 'Create view',
              modelName: tab.model.name,
              create: true,
              hasChart: !!(configuration.chart || configuration.charts?.length),
              value: {
                ...initial,
                name: copy ? tab.name + ' copy' : '',
                ...(!copy && !configuration.chart
                  ? {
                      description: '',
                      group: '',
                      tags: [],
                      displayMode: 'grid',
                      filterControls: { visible: true, parameterizable: true },
                    }
                  : {}),
              },
              submit: async (value: ViewSettings) => {
                created = await this.workspace.create<WidgetConfiguration>('widgets', {
                  name: value.name,
                  description: value.description,
                  modelId: tab.model.id,
                  body: this.configuredBody(configuration, value),
                });
              },
            },
          })
          .afterClosed(),
      );
      if (created && !this.destroyed) {
        if (origin === 'capture' && !tab.widget && tab.bridge) {
          this.adoptCreatedView(tab, created, configuration);
          await this.router.navigate(['/studio', tab.model.slug], {
            queryParams: { widget: created.slug, view: 'draft' },
            replaceUrl: true,
          });
        } else {
          await this.router.navigate(['/studio', tab.model.slug], {
            queryParams: { widget: created.slug, view: 'draft' },
          });
        }
        this.message.set('Saved ' + created.name + '. Your draft is ready to edit.');
      }
      return created;
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : String(error));
      return;
    } finally {
      this.busy.set(false);
    }
  }
  /** The exploration tab becomes the draft it was just saved as; its editor is kept. */
  private adoptCreatedView(tab: Tab, created: WidgetResource, captured: WidgetConfiguration) {
    this.setWidget(tab, created);
    tab.mode = 'draft';
    tab.selectionKey = created.slug + ':draft';
    tab.previewMode = created.body.displayMode ?? 'grid';
    // Reader settings chosen in the dialog (display mode, filter controls) now apply to the editor.
    if (this.readerSettingsDiffer(captured, created.body))
      tab.bridge?.restore(structuredClone(created.body));
    tab.bridge?.markSaved();
    this.lastModelTab.set(tab.model.id, tab.id);
    this.changed();
  }
  private readerSettingsDiffer(captured: WidgetConfiguration, saved: WidgetConfiguration) {
    return (
      (captured.displayMode ?? 'grid') !== (saved.displayMode ?? 'grid') ||
      JSON.stringify(captured.serverGrid ?? null) !== JSON.stringify(saved.serverGrid ?? null) ||
      JSON.stringify(captured.filterControls ?? null) !==
        JSON.stringify(saved.filterControls ?? null) ||
      (captured.chart?.plan.title ?? '') !== (saved.chart?.plan.title ?? '')
    );
  }
  async editDraft() {
    const tab = this.active();
    if (!tab?.widget || tab.mode !== 'published' || this.busy()) return;
    this.busy.set(true);
    this.error.set('');
    this.message.set('');
    tab.operation = 'drafting';
    try {
      const current = await this.workspace.get<WidgetConfiguration>('widgets', tab.widget.slug);
      const draft =
        current.version === current.publishedVersion
          ? await this.workspace.update<WidgetConfiguration>('widgets', current, {
              name: current.name,
              description: current.description,
              modelId: current.modelId,
              body: current.body,
            })
          : current;
      await this.router.navigate(['/studio', tab.model.slug], {
        queryParams: { widget: draft.slug, view: 'draft' },
      });
      this.message.set(
        `Draft v${draft.version} is ready to edit. Published v${draft.publishedVersion} remains available to readers.`,
      );
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : String(error));
    } finally {
      tab.operation = undefined;
      this.busy.set(false);
    }
  }
  async editSettings() {
    const tab = this.active();
    if (!tab?.widget || this.busy() || tab.configurationLoading) return;
    this.busy.set(true);
    try {
      const configuration = tab.bridge?.capture() ?? tab.widget.body;
      const value: ViewSettings | undefined = await firstValueFrom(
        this.dialog
          .open(ViewSettingsDialogComponent, {
            width: '600px',
            maxWidth: 'calc(100vw - 24px)',
            data: {
              title: 'View settings',
              modelName: tab.model.name,
              value: this.settings(tab, configuration),
              hasChart: !!(configuration.chart || configuration.charts?.length),
              readOnly: !this.editable(tab),
            },
          })
          .afterClosed(),
      );
      if (!value || !this.editable(tab) || this.destroyed) return;
      tab.name = value.name;
      tab.description = value.description;
      tab.group = value.group;
      tab.tags = value.tags;
      tab.publication = {
        serverGrid: value.serverGrid,
        allowDownload: value.allowDownload ?? true,
        displayMode: value.displayMode,
        filterControls: value.filterControls,
      };
      if (
        configuration.displayMode !== value.displayMode ||
        JSON.stringify(configuration.serverGrid ?? null) !==
          JSON.stringify(value.serverGrid ?? null) ||
        JSON.stringify(configuration.filterControls ?? null) !==
          JSON.stringify(value.filterControls)
      )
        tab.bridge?.restore(this.configuredBody(configuration, value));
      this.changed();
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : String(error));
    } finally {
      this.busy.set(false);
    }
  }
  async save(asNew: boolean): Promise<WidgetResource | undefined> {
    const tab = this.active();
    return tab ? this.saveTab(tab, asNew) : undefined;
  }
  private async saveTab(tab: Tab, asNew: boolean): Promise<WidgetResource | undefined> {
    if (!tab.bridge || !this.editable(tab) || this.busy() || tab.configurationLoading) return;
    if (asNew || !tab.widget) {
      try {
        return await this.createView(tab, tab.bridge.capture(), asNew ? 'copy' : 'capture');
      } catch (error) {
        this.error.set(error instanceof Error ? error.message : String(error));
        return;
      }
    }
    this.busy.set(true);
    this.error.set('');
    this.message.set('');
    tab.operation = 'saving';
    try {
      const captured = tab.bridge.capture();
      const body = this.configuredBody(captured, this.settings(tab, captured));
      const widget = await this.workspace.update<WidgetConfiguration>('widgets', tab.widget, {
        name: tab.name,
        description: tab.description,
        modelId: tab.model.id,
        body,
      });
      this.setWidget(tab, widget);
      tab.bridge.markSaved();
      this.changed();
      this.message.set(
        'Saved ' + widget.name + '. Publish to make this version available to readers.',
      );
      return widget;
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : String(error));
      return;
    } finally {
      tab.operation = undefined;
      this.busy.set(false);
    }
  }
  async publish() {
    try {
      await this.publishReadyView();
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : String(error));
    }
  }
  private async publishReadyView() {
    const tab = this.active();
    if (!tab || !this.editable(tab) || this.busy() || !tab.widget) return;
    if (!this.preferences.settings().skipPublishConfirmation) {
      const configuration = tab.bridge?.capture() ?? tab.widget.body;
      const { PublishConfirmDialogComponent } = await import(
        '../ui/publish-confirm-dialog.component'
      );
      const result = await firstValueFrom(
        this.dialog
          .open(PublishConfirmDialogComponent, {
            data: {
              name: tab.name,
              draftVersion: tab.widget.version,
              publishedVersion: tab.widget.publishedVersion,
              configuration: this.configuredBody(configuration, this.settings(tab, configuration)),
              unsaved: this.hasEdits(tab),
            },
            width: '520px',
            maxWidth: 'calc(100vw - 24px)',
          })
          .afterClosed(),
      );
      if (!result?.publish || this.destroyed) return;
      if (result.skipNextTime)
        void this.preferences
          .updateSettings({ skipPublishConfirmation: true })
          .catch(() => undefined);
    }
    const widget = this.hasEdits(tab) ? await this.save(false) : tab.widget;
    if (!widget) return;
    this.busy.set(true);
    this.error.set('');
    this.message.set('');
    tab.operation = 'publishing';
    try {
      const published = await this.workspace.publish<WidgetConfiguration>('widgets', widget);

      const previous = this.tabs().find(
        (value) => value !== tab && value.widget?.id === published.id && value.mode === 'published',
      );
      if (previous) {
        ++previous.revision;
        previous.lease?.release();
        this.tabs.update((tabs) => tabs.filter((value) => value !== previous));
      }
      ++tab.revision;
      tab.bridge = undefined;
      tab.injector = undefined;
      tab.lease?.release();
      tab.lease = undefined;
      this.setWidget(tab, published);
      tab.mode = 'published';
      tab.selectionKey = published.slug + ':published';
      tab.readonlyConfiguration = {
        ...published.body,
      };
      tab.previewMode =
        published.body.chart || published.body.charts?.length
          ? (published.body.displayMode ?? 'chart')
          : 'grid';
      this.changed();
      await this.router.navigate(['/studio', tab.model.slug], {
        queryParams: { widget: published.slug, view: 'published' },
        replaceUrl: true,
      });
      this.message.set(
        `Published revision ${published.publishedVersion}. This view is now read only.`,
      );
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : String(error));
    } finally {
      tab.operation = undefined;
      this.busy.set(false);
    }
  }
  ngOnDestroy() {
    this.destroyed = true;
    window.removeEventListener('beforeunload', this.unloadGuard);
    this.subscription.unsubscribe();
    this.tabs().forEach((tab) => tab.lease?.release());
  }
}
