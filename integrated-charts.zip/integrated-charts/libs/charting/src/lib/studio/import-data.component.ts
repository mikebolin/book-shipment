import { injectUiState } from '../core/state/index';
import { Component, Injector, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { JsonImportComponent } from '../explorer/json-import.component';
import { ExplorerTabComponent } from '../explorer/explorer-workspace.component';
import { EXPLORER_CONTEXT, type ExplorerContext } from '../explorer/explorer-context';
import type { LocalDataset } from '../explorer/client-data-sources';
import type { WidgetConfiguration } from '../core/domain/workspace.types';

@Component({
  standalone: true,
  imports: [
    RouterLink,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    JsonImportComponent,
    ExplorerTabComponent,
  ],
  template: `
    <header class="import-page-heading">
      <div>
        <a routerLink="/studio">Data studio</a>
        <h1>{{ dataset()?.metadata?.label ?? 'Import data' }}</h1>
      </div>
      <a
        mat-icon-button
        routerLink="/studio"
        aria-label="Back to data studio"
        matTooltip="Back to data studio"
        ><mat-icon>close</mat-icon></a
      >
    </header>
    @if (explorer(); as context) {
      <div class="session-note">
        <mat-icon>info_outline</mat-icon
        ><span
          >This file is available while this import page is open. Download results before leaving or
          reloading.</span
        ><button mat-button type="button" (click)="startAgain()">Import another file</button>
      </div>
      <div class="import-explorer"><app-explorer-tab [injector]="context" [active]="true" /></div>
    } @else {
      <main class="import-page">
        <app-json-import [showBack]="false" (imported)="open($event)" />
      </main>
    }
  `,
  styles: `
    :host {
      display: flex;
      flex-direction: column;
      min-height: 0;
      height: 100%;
      background: var(--mat-sys-surface-container-lowest);
    }
    .import-page-heading {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 20px 28px 14px;
      border-bottom: 1px solid var(--mat-sys-outline-variant);
    }
    .import-page-heading a {
      font-size: 12px;
      color: var(--mat-sys-on-surface-variant);
      text-decoration: none;
    }
    .import-page-heading h1 {
      font-size: 23px;
      margin: 6px 0 0;
      font-weight: 600;
    }
    .import-page {
      padding: 28px;
      overflow: auto;
      flex: 1;
    }
    .session-note {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 8px 20px;
      border-bottom: 1px solid var(--mat-sys-outline-variant);
      font-size: 12px;
      color: var(--mat-sys-on-surface-variant);
    }
    .session-note span {
      flex: 1;
    }
    .session-note mat-icon {
      font-size: 18px;
      width: 18px;
      height: 18px;
      flex-shrink: 0;
    }
    .import-explorer {
      flex: 1;
      min-height: 500px;
      overflow: hidden;
    }
    @media (max-width: 600px) {
      .import-page-heading {
        padding: 16px;
      }
      .import-page {
        padding: 16px;
      }
      .session-note {
        flex-wrap: wrap;
        padding: 10px 16px;
      }
    }
  `,
})
export class ImportDataComponent {
  private readonly reactiveState = injectUiState('ImportDataComponent');

  private readonly parent = inject(Injector);
  readonly dataset = this.reactiveState.signal<LocalDataset | null>(null);
  readonly explorer = this.reactiveState.signal<Injector | null>(null);
  open(dataset: LocalDataset) {
    this.dataset.set(dataset);
    const recipe = dataset.initialAnalysisChart;
    const configuration: WidgetConfiguration | undefined = recipe?.chart
      ? {
          schemaVersion: 1,
          modelSchemaVersion: dataset.metadata.version,
          mode: 'advanced',
          gridState: recipe.gridState,
          calculatedColumns: [],
          chart: { id: crypto.randomUUID(), plan: recipe.chart, presentation: null },
        }
      : undefined;
    const context: ExplorerContext = {
      id: `import-${crypto.randomUUID()}`,
      initialSource: dataset.metadata.id,
      dataset,
      configuration,
      isActive: () => true,
    };
    this.explorer.set(
      Injector.create({
        parent: this.parent,
        providers: [{ provide: EXPLORER_CONTEXT, useValue: context }],
      }),
    );
  }
  startAgain() {
    this.explorer.set(null);
    this.dataset.set(null);
  }
}
