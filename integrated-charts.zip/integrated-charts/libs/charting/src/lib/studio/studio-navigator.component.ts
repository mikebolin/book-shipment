import { injectUiState } from '../core/state/index';
import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
  ViewChild,
  computed,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatAutocompleteModule, MatAutocompleteTrigger } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTooltipModule } from '@angular/material/tooltip';
import type { ModelResource, WidgetConfiguration } from '../core/domain/workspace.types';
import { matchesViewSearch, navigationViewName, type StudioSelection } from './studio-state';
import { viewCharts } from '../rendering/view-charts';

/** A saved table filter (advanced expression or column filters) narrows the view's records. */
export function hasTableFilter(configuration: WidgetConfiguration | undefined): boolean {
  const filter = configuration?.gridState?.filter;
  if (!filter) return false;
  if (filter.advancedFilterModel) return true;
  const model = filter.filterModel;
  return !!model && typeof model === 'object' && Object.keys(model).length > 0;
}

/**
 * The studio's left panel: one Material autocomplete that behaves as a single select for the
 * data source and doubles as the view finder, the "new view" action beside it, then the views
 * of the selected source with their metadata.
 */
@Component({
  selector: 'workspace-studio-navigator',
  standalone: true,
  imports: [
    FormsModule,
    MatAutocompleteModule,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatTooltipModule,
  ],
  template: `
    <div class="source-row">
      <mat-form-field class="source-field" appearance="outline" subscriptSizing="dynamic">
        <mat-label>Data source</mat-label>
        <mat-icon matPrefix aria-hidden="true">storage</mat-icon>
        <input
          #sourceInput
          matInput
          type="text"
          autocomplete="off"
          aria-label="Data source or view"
          placeholder="Choose a source or find a view"
          [disabled]="disabled"
          [ngModel]="text()"
          (ngModelChange)="text.set($event)"
          (focus)="sourceInput.select()"
          (blur)="restoreIfClosed()"
          [matAutocomplete]="picker"
        />
        <mat-autocomplete
          #picker="matAutocomplete"
          class="studio-source-panel"
          panelWidth="min(520px, calc(100vw - 32px))"
          [displayWith]="display"
          [autoActiveFirstOption]="false"
          (optionSelected)="choose($event.option.value)"
          (closed)="restore()"
        >
          @if (matchingModels().length) {
            <mat-optgroup label="Data sources">
              @for (option of matchingModels(); track option.key) {
                <mat-option [value]="option" [class.current]="option.key === selectedKey">
                  <span class="option-row">
                    <mat-icon aria-hidden="true">storage</mat-icon>
                    <span class="option-text">
                      <span class="option-name">{{ option.model.name }}</span>
                      <small>{{ viewTotal(option.model.id) }}</small>
                    </span>
                    @if (option.key === selectedKey) {
                      <mat-icon class="current-indicator" aria-hidden="true">check</mat-icon>
                    }
                  </span>
                </mat-option>
              }
            </mat-optgroup>
          }
          @if (matchingViews().length) {
            <mat-optgroup [label]="query() ? 'Views' : 'Views in ' + modelName()">
              @for (option of matchingViews(); track option.key) {
                <mat-option [value]="option" [class.current]="option.key === selectedKey">
                  <span class="option-row">
                    <mat-icon aria-hidden="true">{{
                      option.mode === 'published' ? 'check_circle_outline' : 'edit_note'
                    }}</mat-icon>
                    <span class="option-text">
                      <span class="option-name">{{ viewName(option) }}</span>
                      <small>{{ optionSummary(option, true) }}</small>
                    </span>
                    @if (option.key === selectedKey) {
                      <mat-icon class="current-indicator" aria-hidden="true">check</mat-icon>
                    }
                  </span>
                </mat-option>
              }
            </mat-optgroup>
          }
          @if (!matchingModels().length && !matchingViews().length) {
            <mat-option disabled>No matching sources or views.</mat-option>
          }
        </mat-autocomplete>
      </mat-form-field>
      @if (canCreate) {
        <button
          mat-icon-button
          type="button"
          class="create-view"
          [disabled]="disabled"
          (click)="create.emit()"
          aria-label="Create a new view"
          matTooltip="Start a blank view on this data source"
        >
          <mat-icon>add</mat-icon>
        </button>
      }
    </div>
    <nav aria-label="Model views">
      @for (group of groups(); track group.mode) {
        <h2>
          {{ group.label }} <span>{{ group.options.length }}</span>
        </h2>
        @for (option of group.options; track option.key) {
          <button
            type="button"
            class="view-choice"
            [class.current]="option.key === selectedKey"
            [attr.aria-current]="option.key === selectedKey ? 'page' : null"
            [disabled]="disabled"
            (click)="selected.emit(option)"
          >
            <mat-icon>{{
              option.mode === 'model'
                ? 'table_chart'
                : option.mode === 'published'
                  ? 'check_circle_outline'
                  : 'edit_note'
            }}</mat-icon>
            <span class="choice-text"
              ><strong>{{
                option.mode === 'model' ? 'Explore all records' : viewName(option)
              }}</strong>
              @if (option.mode !== 'model') {
                <small>{{ optionSummary(option) }}</small>
              } @else {
                <small>{{ viewTotal(option.model.id) }}</small>
              }
            </span>
          </button>
        }
      } @empty {
        <p class="empty">No views on this data source yet.</p>
      }
    </nav>
  `,
  styles: `
    :host {
      display: flex;
      flex-direction: column;
      height: 100%;
      min-height: 0;
      padding: 4px 12px 8px;
    }
    .source-row {
      display: flex;
      align-items: center;
      gap: 4px;
    }
    .source-field {
      flex: 1;
      min-width: 0;
      --mat-form-field-outlined-container-shape: 4px;
    }
    .source-field mat-icon[matPrefix] {
      width: 18px;
      height: 18px;
      font-size: 18px;
      padding-inline: 10px 4px;
      box-sizing: content-box;
      color: var(--ws-muted);
    }
    .source-field input {
      text-overflow: ellipsis;
    }
    .create-view {
      flex-shrink: 0;
      color: var(--mat-sys-primary);
      background: transparent;
    }
    .create-view:disabled {
      opacity: 0.5;
    }
    mat-icon {
      width: 18px;
      height: 18px;
      font-size: 18px;
      flex-shrink: 0;
      color: var(--ws-muted);
    }
    nav {
      overflow: auto;
      flex: 1;
      margin-top: 6px;
    }
    h2 {
      display: flex;
      justify-content: space-between;
      font-size: 11px;
      font-weight: 600;
      color: var(--ws-muted);
      margin: 14px 8px 6px;
    }
    h2 span {
      font-weight: 400;
    }
    .view-choice {
      display: flex;
      align-items: center;
      gap: 10px;
      width: 100%;
      padding: 8px 9px;
      border: 1px solid transparent;
      border-radius: 8px;
      background: transparent;
      color: var(--ws-ink);
      text-align: left;
      cursor: pointer;
    }
    .view-choice:hover {
      background: var(--mat-sys-surface-container);
    }
    .view-choice.current {
      background: var(--mat-sys-secondary-container);
      color: var(--mat-sys-on-secondary-container);
    }
    .view-choice.current mat-icon {
      color: inherit;
    }
    .choice-text {
      min-width: 0;
      flex: 1;
    }
    strong {
      display: block;
      font-size: 13px;
      font-weight: 500;
      line-height: 1.5;
      white-space: normal;
      overflow-wrap: anywhere;
      overflow: hidden;
    }
    small {
      display: block;
      color: var(--ws-muted);
      font-size: 12px;
      line-height: 1.5;
      margin-top: 3px;
    }
    .empty {
      font-size: 11px;
      line-height: 1.7;
      color: var(--ws-muted);
      margin: 18px 8px 0;
    }
    button:disabled {
      cursor: wait;
    }
  `,
})
export class StudioNavigatorComponent implements OnChanges {
  private readonly reactiveState = injectUiState('StudioNavigatorComponent');

  @Input() models: ModelResource[] = [];
  @Input() options: StudioSelection[] = [];
  @Input() modelId = '';
  @Input() selectedKey = '';
  @Input() disabled = false;
  @Input() canCreate = false;
  @Output() selected = new EventEmitter<StudioSelection>();
  @Output() create = new EventEmitter<void>();
  @ViewChild(MatAutocompleteTrigger) private trigger?: MatAutocompleteTrigger;
  readonly viewName = navigationViewName;
  /** The input's model: a string while typing, briefly the chosen option after a selection. */
  readonly text = this.reactiveState.signal<string | StudioSelection>('');
  private readonly inputs = this.reactiveState.signal({
    options: [] as StudioSelection[],
    modelId: '',
  });

  ngOnChanges(changes: SimpleChanges) {
    if (changes['options'] || changes['modelId'])
      this.inputs.set({ options: this.options, modelId: this.modelId });
    if (changes['modelId'] || changes['models']) this.text.set(this.modelName());
  }
  modelName(): string {
    return this.models.find((model) => model.id === this.modelId)?.name ?? '';
  }
  /** Typing filters; the current source name alone means "show everything". */
  readonly query = computed(() => {
    const text = this.text();
    const value = typeof text === 'string' ? text.trim() : '';
    return value && value !== this.modelName() ? value.toLocaleLowerCase() : '';
  });
  readonly matchingModels = computed(() => {
    const query = this.query();
    return this.inputs().options.filter(
      (option) =>
        option.mode === 'model' &&
        (!query || option.model.name.toLocaleLowerCase().includes(query)),
    );
  });
  readonly matchingViews = computed(() => {
    const query = this.query();
    const { options, modelId } = this.inputs();
    return options
      .filter((option) => option.mode !== 'model')
      .filter((option) => (query ? matchesViewSearch(option, query) : option.model.id === modelId))
      .sort((a, b) => a.model.name.localeCompare(b.model.name) || a.label.localeCompare(b.label))
      .slice(0, 40);
  });
  readonly display = (option: StudioSelection | string | null) =>
    !option || typeof option === 'string'
      ? (option ?? '')
      : option.mode === 'model'
        ? option.model.name
        : navigationViewName(option);
  choose(option: StudioSelection) {
    this.text.set(option.mode === 'model' ? option.model.name : this.modelName());
    this.selected.emit(option);
  }
  /** Closing without a choice puts the current source back, like a select. */
  restore() {
    this.text.set(this.modelName());
  }
  restoreIfClosed() {
    if (!this.trigger?.panelOpen) this.restore();
  }
  chartCount(option: StudioSelection) {
    return option.widget?.body ? viewCharts(option.widget.body).length : 0;
  }
  chartSummary(option: StudioSelection) {
    const count = this.chartCount(option);
    return count ? `${count} ${count === 1 ? 'chart' : 'charts'} · table` : 'Table';
  }
  filtered(option: StudioSelection) {
    return hasTableFilter(option.widget?.body);
  }
  /** One readable secondary line instead of revision pills and icon counters. */
  optionSummary(option: StudioSelection, includeMode = false): string {
    return [
      includeMode ? (option.mode === 'published' ? 'Published' : 'Draft') : '',
      this.chartSummary(option),
      this.filtered(option) ? 'Filtered' : '',
      includeMode && option.model.id !== this.modelId ? option.model.name : '',
    ]
      .filter(Boolean)
      .join(' · ');
  }
  viewTotal(modelId: string) {
    const views = this.options.filter(
      (option) => option.model.id === modelId && option.mode !== 'model',
    );
    const published = views.filter((option) => option.mode === 'published').length;
    const drafts = views.length - published;
    return (
      [
        published ? `${published} published ${published === 1 ? 'view' : 'views'}` : '',
        drafts ? `${drafts} ${drafts === 1 ? 'draft' : 'drafts'}` : '',
      ]
        .filter(Boolean)
        .join(' · ') || 'No views yet'
    );
  }
  groups() {
    return (
      [
        ['model', 'Dataset'],
        ['draft', 'Draft views'],
        ['published', 'Published views'],
      ] as const
    )
      .map(([mode, label]) => ({
        mode,
        label,
        options: this.options.filter(
          (option) => option.model.id === this.modelId && option.mode === mode,
        ),
      }))
      .filter((group) => group.options.length);
  }
}
