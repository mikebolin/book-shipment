import type {
  ModelResource,
  WidgetResource,
  WidgetConfiguration,
} from '../core/domain/workspace.types';
import { viewCharts } from '../rendering/view-charts';
import { comparableConfiguration } from '../rendering/grid-state-normalization';

export type StudioMode = 'model' | 'new' | 'published' | 'draft';

export interface StudioSelection {
  key: string;
  model: ModelResource;
  widget?: WidgetResource;
  mode: StudioMode;
  label: string;
}

/** Older suggested names appended the expression; keep navigation concise. */
export function navigationViewName(option: StudioSelection): string {
  return option.label.replace(/\s+Filters:\s*[\s\S]*$/i, '').trim() || option.label;
}

export function matchingViewCharts(option: StudioSelection, search: string) {
  const query = search.trim().toLocaleLowerCase();
  if (query.length < 3 || !option.widget?.body) return [];
  return viewCharts(option.widget.body).filter((chart) =>
    chart.plan.title.toLocaleLowerCase().includes(query),
  );
}

export function matchesViewSearch(option: StudioSelection, search: string): boolean {
  const query = search.trim().toLocaleLowerCase();
  return (
    !query ||
    navigationViewName(option).toLocaleLowerCase().includes(query) ||
    matchingViewCharts(option, query).length > 0
  );
}

export function studioSelections(
  models: ModelResource[],
  drafts: WidgetResource[],
  published: WidgetResource[],
): StudioSelection[] {
  return models.flatMap((model) => [
    { key: model.id, model, mode: 'model' as const, label: model.name },
    ...published
      .filter((widget) => widget.modelId === model.id)
      .map((widget) => ({
        key: `${widget.id}:published`,
        model,
        widget,
        mode: 'published' as const,
        label: widget.name,
      })),
    ...drafts
      .filter(
        (widget) =>
          widget.modelId === model.id &&
          (!widget.publishedVersion || widget.version > widget.publishedVersion),
      )
      .map((widget) => ({
        key: `${widget.id}:draft`,
        model,
        widget,
        mode: 'draft' as const,
        label: widget.name,
      })),
  ]);
}

/**
 * Ignore navigation, generated previews and the values AG Grid normalizes on its own
 * (synthetic columns, flex widths, chart render ids, empty blocks) when deciding
 * whether a view needs saving. Two equal keys describe the same view.
 */
export function configurationKey(configuration: Partial<WidgetConfiguration>): string {
  const { sideBar: _sideBar, ...gridState } = configuration.gridState ?? {};
  const stable = (value: unknown): unknown =>
    Array.isArray(value)
      ? value.map(stable)
      : value && typeof value === 'object'
        ? Object.fromEntries(
            Object.entries(value)
              .filter(([, child]) => child !== undefined)
              .sort(([a], [b]) => a.localeCompare(b))
              .map(([key, child]) => [key, stable(child)]),
          )
        : value;
  return JSON.stringify(stable(comparableConfiguration({ ...configuration, gridState })));
}
