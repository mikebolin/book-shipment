import { DOCUMENT } from '@angular/common';
import { DestroyRef, Directive, ElementRef, Injectable, inject } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

/** Keep AG popups inside their owning CDK overlay, including the browser's top layer.
 * A body-level z-index cannot rise above a native dialog/popover. Do not reparent
 * a popup after AG has positioned it: supply the right parent before it opens.
 */
@Injectable({ providedIn: 'root' })
export class GridPopupLayer {
  private readonly document = inject(DOCUMENT);
  parentFor(element: HTMLElement): HTMLElement {
    const owner = element.closest<HTMLElement>('.mat-mdc-dialog-container, .cdk-overlay-pane');
    if (!owner) return this.document.body;
    // AG constrains popups to their parent's rectangle. A small menu rectangle
    // would force suggestions over the input, even after fixing their stacking.
    // This full-viewport layer stays inside the owning focus/overlay tree.
    let layer = owner.querySelector<HTMLElement>(':scope > .prism-grid-popup-layer');
    if (!layer) {
      layer = this.document.createElement('div');
      layer.className = 'prism-grid-popup-layer prism-popup-owner';
      owner.appendChild(layer);
    }
    return layer;
  }
}

/** Shared by every Angular grid surface, including grids inside previews and dialogs. */
@Directive({ selector: 'ag-grid-angular[prismPopupLayer]', standalone: true })
export class GridPopupLayerDirective {
  constructor() {
    const grid = inject(AgGridAngular);
    const host = inject<ElementRef<HTMLElement>>(ElementRef);
    const layer = inject(GridPopupLayer);
    grid.gridReady.pipe(takeUntilDestroyed(inject(DestroyRef))).subscribe(({ api }) => {
      api.setGridOption('popupParent', layer.parentFor(host.nativeElement));
    });
  }
}
