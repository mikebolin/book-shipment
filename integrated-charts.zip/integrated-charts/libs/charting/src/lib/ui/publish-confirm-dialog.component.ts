import { injectUiState } from '../core/state/index';
import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatIconModule } from '@angular/material/icon';
import type { WidgetConfiguration } from '../core/domain/workspace.types';
import { viewCharts } from '../rendering/view-charts';

export interface PublishConfirmData {
  name: string;
  draftVersion: number;
  publishedVersion: number | null;
  configuration: WidgetConfiguration;
  unsaved: boolean;
}

export interface PublishConfirmResult {
  publish: boolean;
  skipNextTime: boolean;
}

/** What readers will get, summarized once before a revision becomes immutable. */
@Component({
  standalone: true,
  imports: [MatDialogModule, MatButtonModule, MatCheckboxModule, MatIconModule],
  template: `
    <h2 mat-dialog-title>Publish {{ data.name }}?</h2>
    <mat-dialog-content>
      <p class="versions">
        <span class="version">Draft v{{ data.draftVersion }}</span>
        <mat-icon aria-hidden="true">arrow_forward</mat-icon>
        <span class="version published"
          >Published v{{ data.draftVersion + 1 + (data.unsaved ? 1 : 0) }}</span
        >
      </p>
      @if (data.unsaved) {
        <p class="note">Your unsaved changes are saved first, then that version is published.</p>
      }
      <dl>
        <dt>Charts</dt>
        <dd>{{ summary.charts }}</dd>
        <dt>Default display</dt>
        <dd>{{ summary.display }}</dd>
        <dt>Filters</dt>
        <dd>{{ summary.filters }}</dd>
        <dt>Downloads</dt>
        <dd>{{ summary.downloads }}</dd>
      </dl>
      <p class="note">
        Published revisions are immutable. Dashboards keep the revision they pinned until an author
        updates them.
      </p>
      <mat-checkbox [checked]="skip()" (change)="skip.set($event.checked)"
        >Don’t ask again</mat-checkbox
      >
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button type="button" (click)="close(false)">Cancel</button>
      <button mat-button type="button" (click)="close(true)" cdkFocusInitial>
        <mat-icon aria-hidden="true">publish</mat-icon>Publish
      </button>
    </mat-dialog-actions>
  `,
  styles: `
    .versions {
      display: flex;
      align-items: center;
      gap: 10px;
      margin: 0 0 14px;
      font-size: 13px;
    }
    .version {
      padding: 4px 10px;
      border-radius: 4px;
      background: var(--mat-sys-surface-container);
      color: var(--ws-muted);
      font-weight: 500;
    }
    .version.published {
      background: var(--mat-sys-primary-container);
      color: var(--mat-sys-on-primary-container);
    }
    dl {
      display: grid;
      grid-template-columns: auto 1fr;
      gap: 6px 18px;
      margin: 0 0 14px;
      font-size: 13px;
    }
    dt {
      color: var(--ws-muted);
    }
    dd {
      margin: 0;
      color: var(--ws-ink);
    }
    .note {
      color: var(--ws-muted);
      font-size: 12px;
      line-height: 1.6;
      margin: 0 0 12px;
    }
    mat-dialog-actions {
      gap: 8px;
      padding: 12px 24px 20px;
    }
    mat-dialog-actions mat-icon {
      margin-right: 6px;
    }
  `,
})
export class PublishConfirmDialogComponent {
  private readonly reactiveState = injectUiState('PublishConfirmDialogComponent');

  readonly data = inject<PublishConfirmData>(MAT_DIALOG_DATA);
  private readonly ref = inject(MatDialogRef<PublishConfirmDialogComponent, PublishConfirmResult>);
  readonly skip = this.reactiveState.signal(false);
  readonly summary = summarize(this.data.configuration);
  close(publish: boolean) {
    this.ref.close({ publish, skipNextTime: this.skip() });
  }
}

export function summarize(configuration: WidgetConfiguration) {
  const charts = viewCharts(configuration).length;
  const controls = configuration.filterControls;
  const display =
    charts === 0
      ? 'Table'
      : configuration.displayMode === 'both'
        ? 'Charts above the table'
        : configuration.displayMode === 'grid'
          ? 'Table'
          : 'Charts';
  return {
    charts: charts === 0 ? 'None (table only)' : charts === 1 ? '1 chart' : `${charts} charts`,
    display,
    filters:
      controls?.visible === false
        ? 'Hidden from readers'
        : controls?.parameterizable
          ? controls.editMode === 'values'
            ? 'Readers can change values'
            : 'Readers can edit the expression'
          : 'Shown, not editable',
    downloads: configuration.allowDownload === false ? 'Off' : 'CSV and PNG available',
  };
}
