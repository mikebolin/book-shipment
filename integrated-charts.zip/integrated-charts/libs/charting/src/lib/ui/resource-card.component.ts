import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { DatePipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ResourcePreviewComponent } from './resource-preview.component';
import type { WorkspacePreview } from '../core/domain/workspace-cards';
import type { GalleryDensity } from '../views/gallery-state';

export interface CardAction {
  id: string;
  label: string;
  icon?: string;
  disabled?: boolean;
  tooltip?: string;
  destructive?: boolean;
  divider?: boolean;
}

export interface CardStatus {
  label: string;
  tone: 'neutral' | 'accent' | 'tertiary';
}

/**
 * One card for views, dashboards and models. The whole card opens the resource; `Edit`
 * and `More` appear on hover and focus. Grid and list densities share the same markup.
 */
@Component({
  selector: 'workspace-resource-card',
  standalone: true,
  imports: [
    DatePipe,
    RouterLink,
    MatButtonModule,
    MatDividerModule,
    MatIconModule,
    MatMenuModule,
    MatTooltipModule,
    ResourcePreviewComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: {
    '[class.list]': "density === 'list'",
    '[class.grid]': "density === 'grid'",
    '[attr.data-card-kind]': 'kind',
  },
  template: `
    <article class="card" [class.list-row]="density === 'list'">
      <a
        class="card-open"
        [routerLink]="openLink"
        [queryParams]="openQuery ?? null"
        [attr.aria-label]="'Open ' + name"
      >
        <span class="sr-only">Open {{ name }}</span>
      </a>
      <div class="card-preview" aria-hidden="true">
        @if (kind === 'model') {
          <div class="model-figure">
            <mat-icon>storage</mat-icon>
            <strong>{{ recordCount?.toLocaleString() }}</strong>
            <span>records · {{ fieldCount }} fields</span>
          </div>
        } @else {
          <workspace-resource-preview
            [preview]="preview"
            [icon]="kind === 'dashboard' ? 'dashboard_customize' : 'insert_chart_outlined'"
          />
        }
      </div>
      <div class="card-body">
        <p class="kicker">
          <span class="resource-kind">
            <mat-icon aria-hidden="true">{{ kindIcon }}</mat-icon
            >{{ kindLabel }}
          </span>
          @if (modelName) {
            <span class="model-chip"
              ><mat-icon aria-hidden="true">storage</mat-icon>{{ modelName }}</span
            >
          }
          @if (kicker) {
            <span class="kicker-text">{{ kicker }}</span>
          }
        </p>
        <h2 class="card-title">{{ name }}</h2>
        <p class="card-description">{{ description || fallbackDescription }}</p>
        @if (tags.length) {
          <div class="card-tags">
            @for (tag of tags.slice(0, 3); track tag) {
              <button
                type="button"
                class="tag"
                [class.selected]="tag === selectedTag"
                [attr.aria-pressed]="tag === selectedTag"
                (click)="tagSelect.emit(tag)"
              >
                {{ tag }}
              </button>
            }
            @if (tags.length > 3) {
              <span class="tag more" [matTooltip]="tags.slice(3).join(', ')"
                >+{{ tags.length - 3 }}</span
              >
            }
          </div>
        }
      </div>
      <footer class="card-footer">
        @if (status) {
          <span class="status-pill" [class]="'status-pill tone-' + status.tone">{{
            status.label
          }}</span>
        }
        @if (updatedAt) {
          <time
            class="updated"
            [attr.datetime]="updatedAt"
            [matTooltip]="'Updated ' + (updatedAt | date: 'medium')"
            >{{ updatedAt | date: 'mediumDate' }}</time
          >
        }
        @if (visibility) {
          <mat-icon
            class="visibility"
            [matTooltip]="
              visibility === 'shared' ? 'Shared with selected people or roles' : 'Private'
            "
            [attr.aria-label]="visibility === 'shared' ? 'Shared' : 'Private'"
            >{{ visibility === 'shared' ? 'group' : 'lock' }}</mat-icon
          >
        }
      </footer>
      <div class="card-actions">
        @if (editLink) {
          <a
            mat-icon-button
            class="card-action"
            [routerLink]="editLink"
            [queryParams]="editQuery ?? null"
            [attr.aria-label]="editLabel"
            [matTooltip]="editLabel"
            ><mat-icon>edit</mat-icon></a
          >
        }
        @if (actions.length) {
          <button
            mat-icon-button
            class="card-action"
            type="button"
            [matMenuTriggerFor]="menu"
            [attr.aria-label]="'More actions for ' + name"
            matTooltip="More"
          >
            <mat-icon>more_vert</mat-icon>
          </button>
          <mat-menu #menu="matMenu">
            @for (item of actions; track item.id) {
              @if (item.divider) {
                <mat-divider />
              }
              <button
                mat-menu-item
                [disabled]="item.disabled"
                [class.destructive]="item.destructive"
                [matTooltip]="item.tooltip ?? ''"
                (click)="action.emit(item.id)"
              >
                @if (item.icon) {
                  <mat-icon>{{ item.icon }}</mat-icon>
                }
                <span>{{ item.label }}</span>
              </button>
            }
          </mat-menu>
        }
      </div>
    </article>
  `,
  styles: `
    :host {
      display: block;
      min-width: 0;
      height: 100%;
    }
    .card {
      position: relative;
      display: flex;
      flex-direction: column;
      height: 100%;
      min-width: 0;
      box-sizing: border-box;
      border: 1px solid color-mix(in srgb, var(--ws-border) 72%, transparent);
      border-radius: 12px;
      background: var(--mat-sys-surface-container-lowest, var(--mat-sys-surface));
      box-shadow: 0 2px 6px rgb(15 23 42 / 4%);
      transition:
        border-color 160ms,
        box-shadow 160ms,
        transform 160ms;
    }
    .card:hover,
    .card:focus-within {
      border-color: color-mix(in srgb, var(--mat-sys-primary) 55%, var(--ws-border));
      box-shadow: 0 6px 20px rgb(15 23 42 / 9%);
      transform: translateY(-2px);
    }
    .card-open {
      position: absolute;
      inset: 0;
      z-index: 1;
      border-radius: inherit;
    }
    .card-open:focus-visible {
      outline: 2px solid var(--ws-accent);
      outline-offset: 2px;
    }
    .sr-only {
      position: absolute;
      width: 1px;
      height: 1px;
      overflow: hidden;
      clip-path: inset(50%);
    }
    .card-preview {
      position: relative;
      aspect-ratio: 320 / 152;
      flex-shrink: 0;
      margin: 10px 10px 0;
      overflow: hidden;
      border: 1px solid color-mix(in srgb, var(--ws-border) 35%, transparent);
      border-radius: 8px;
      background: color-mix(
        in srgb,
        var(--mat-sys-primary) 3%,
        var(--mat-sys-surface-container-lowest, var(--mat-sys-surface))
      );
    }
    .card-preview workspace-resource-preview {
      height: 100%;
    }
    .model-figure {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      height: 100%;
      gap: 2px;
      color: var(--mat-sys-on-surface-variant);
    }
    .model-figure mat-icon {
      font-size: 30px;
      width: 30px;
      height: 30px;
      color: var(--mat-sys-primary);
      opacity: 0.8;
      margin-bottom: 6px;
    }
    .model-figure strong {
      font-size: 22px;
      color: var(--mat-sys-on-surface);
      font-variant-numeric: tabular-nums;
    }
    .model-figure span {
      font-size: 11px;
    }
    .card-body {
      flex: 1;
      padding: 14px 18px 14px;
      min-width: 0;
    }
    .kicker {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 6px 10px;
      margin: 0 0 8px;
      font-size: 11px;
      color: var(--ws-muted);
      min-height: 18px;
    }
    .resource-kind {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      font-weight: 500;
      color: var(--mat-sys-primary);
      white-space: nowrap;
    }
    .resource-kind mat-icon {
      width: 14px;
      height: 14px;
      font-size: 14px;
    }
    .kicker-text {
      white-space: nowrap;
    }
    .model-chip {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      max-width: 100%;
      padding: 2px 8px 2px 6px;
      border-radius: 4px;
      background: var(--mat-sys-surface-container);
      color: var(--mat-sys-on-surface-variant);
      font-weight: 500;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .model-chip mat-icon {
      width: 13px;
      height: 13px;
      font-size: 13px;
      flex-shrink: 0;
    }
    .card-title {
      margin: 0 0 7px;
      font-size: 16px;
      font-weight: 600;
      line-height: 1.4;
      color: var(--ws-ink);
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
      overflow-wrap: anywhere;
    }
    .card-description {
      margin: 0;
      font-size: 13px;
      line-height: 1.55;
      color: var(--ws-muted);
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
      min-height: 40px;
      overflow-wrap: anywhere;
    }
    .card-tags {
      position: relative;
      z-index: 2;
      display: flex;
      flex-wrap: wrap;
      gap: 5px;
      margin-top: 12px;
    }
    .tag {
      padding: 3px 8px;
      max-width: 100%;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      border: 1px solid color-mix(in srgb, var(--ws-border) 50%, transparent);
      border-radius: 6px;
      background: var(--mat-sys-surface-container-low);
      color: var(--ws-muted);
      font: inherit;
      font-size: 11px;
      line-height: 16px;
      cursor: pointer;
    }
    .tag.more {
      cursor: default;
    }
    .tag:hover:not(.more),
    .tag.selected {
      background: var(--mat-sys-secondary-container);
      color: var(--mat-sys-on-secondary-container);
    }
    .tag:focus-visible {
      outline: 2px solid var(--ws-accent);
      outline-offset: 2px;
    }
    .card-footer {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 8px;
      min-height: 46px;
      padding: 10px 18px;
      box-sizing: border-box;
      border-top: 1px solid color-mix(in srgb, var(--ws-border) 45%, transparent);
      font-size: 11px;
      color: var(--ws-muted);
    }
    .status-pill {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 3px 8px;
      border-radius: 6px;
      background: var(--mat-sys-surface-container);
      color: var(--ws-muted);
      font-weight: 500;
      max-width: 100%;
      box-sizing: border-box;
      overflow-wrap: anywhere;
    }
    .status-pill.tone-accent {
      background: color-mix(
        in srgb,
        var(--mat-sys-primary) 9%,
        var(--mat-sys-surface-container-lowest, var(--mat-sys-surface))
      );
      color: var(--mat-sys-primary);
    }
    .status-pill.tone-accent::before {
      content: '';
      width: 5px;
      height: 5px;
      border-radius: 50%;
      background: currentColor;
    }
    .status-pill.tone-tertiary {
      background: var(--mat-sys-tertiary-container);
      color: var(--mat-sys-on-tertiary-container);
    }
    .updated {
      margin-left: auto;
      white-space: nowrap;
    }
    .visibility {
      width: 16px;
      height: 16px;
      font-size: 16px;
    }
    .card-actions {
      position: absolute;
      top: 16px;
      right: 16px;
      z-index: 2;
      display: flex;
      gap: 2px;
      padding: 2px;
      border: 1px solid color-mix(in srgb, var(--ws-border) 65%, transparent);
      border-radius: 8px;
      background: var(--mat-sys-surface-container-lowest, var(--mat-sys-surface));
      box-shadow: 0 2px 6px rgb(15 23 42 / 8%);
      opacity: 0;
      transition: opacity 120ms;
    }
    .card:hover .card-actions,
    .card:focus-within .card-actions,
    .card-actions:focus-within {
      opacity: 1;
    }
    .card-action {
      --mdc-icon-button-state-layer-size: 32px;
      width: 32px;
      height: 32px;
      padding: 4px;
    }
    .card-action mat-icon {
      width: 20px;
      height: 20px;
      font-size: 20px;
    }
    @media (hover: none) {
      .card-actions {
        opacity: 1;
      }
      .card-actions .card-action {
        --mdc-icon-button-state-layer-size: 40px;
        width: 40px;
        height: 40px;
        padding: 8px;
      }
      .tag {
        min-height: 32px;
      }
    }
    .destructive {
      color: var(--mat-sys-error);
    }
    /* List density: a row with a small preview. */
    .card.list-row {
      display: grid;
      grid-template-columns: 128px minmax(0, 1fr) auto;
      grid-template-areas: 'preview body footer';
      align-items: center;
      gap: 0 14px;
      border-radius: 10px;
    }
    .card.list-row:hover,
    .card.list-row:focus-within {
      transform: none;
    }
    .list-row .card-preview {
      grid-area: preview;
      aspect-ratio: 320 / 152;
      height: auto;
      margin: 10px 0 10px 10px;
      border-radius: 6px;
    }
    .list-row .card-preview workspace-resource-preview {
      padding: 6px;
    }
    .list-row .card-body {
      grid-area: body;
      padding: 14px 0;
    }
    .list-row .card-description {
      -webkit-line-clamp: 1;
      min-height: 0;
    }
    .list-row .card-title {
      -webkit-line-clamp: 1;
      font-size: 14px;
    }
    .list-row .kicker {
      margin-bottom: 4px;
    }
    .list-row .card-tags {
      margin-top: 6px;
    }
    .list-row .card-footer {
      grid-area: footer;
      padding: 12px 100px 12px 0;
      min-height: 0;
      border: 0;
      flex-wrap: wrap;
      justify-content: flex-end;
      max-width: 280px;
      gap: 6px 10px;
    }
    .list-row .card-actions {
      top: 50%;
      transform: translateY(-50%);
      opacity: 1;
      box-shadow: none;
      background: transparent;
      border: 0;
    }
    @container (max-width: 900px) {
      .card.list-row {
        grid-template-columns: 112px minmax(0, 1fr);
        grid-template-areas:
          'preview body'
          'preview footer';
        align-items: center;
      }
      .list-row .card-footer {
        padding: 0 14px 12px 0;
        max-width: none;
        justify-content: flex-start;
      }
      .list-row .card-body {
        padding: 12px 90px 8px 0;
      }
      .list-row .card-actions {
        top: 10px;
        right: 10px;
        transform: none;
      }
      .list-row .updated {
        margin-left: 0;
      }
    }
    @container (max-width: 480px) {
      .card.list-row {
        grid-template-columns: 80px minmax(0, 1fr);
        gap: 0 12px;
      }
      .list-row .card-body {
        padding-right: 12px;
      }
      .list-row .kicker,
      .list-row .card-tags {
        display: none;
      }
      .list-row .card-title {
        -webkit-line-clamp: 2;
      }
      .list-row .card-footer {
        min-height: 56px;
        padding-bottom: 46px;
      }
      .list-row .card-actions {
        top: auto;
        bottom: 8px;
        right: 8px;
      }
      .list-row .updated {
        font-size: 10px;
      }
    }
    @media (prefers-reduced-motion: reduce) {
      .card,
      .card-actions {
        transition: none;
      }
      .card:hover,
      .card:focus-within {
        transform: none;
      }
    }
  `,
})
export class ResourceCardComponent {
  get kindIcon() {
    return this.kind === 'dashboard'
      ? 'dashboard_customize'
      : this.kind === 'model'
        ? 'storage'
        : this.preview?.type === 'chart'
          ? 'insert_chart_outlined'
          : 'table_chart';
  }
  get kindLabel() {
    return this.kind === 'dashboard'
      ? 'Dashboard'
      : this.kind === 'model'
        ? 'Data model'
        : this.preview?.type === 'chart'
          ? 'Chart view'
          : 'Table view';
  }
  @Input({ required: true }) kind: 'view' | 'dashboard' | 'model' = 'view';
  @Input({ required: true }) name = '';
  @Input() description = '';
  @Input() fallbackDescription = 'No description yet.';
  @Input() preview: WorkspacePreview | null | undefined;
  @Input() modelName = '';
  @Input() kicker = '';
  @Input() tags: string[] = [];
  @Input() selectedTag = '';
  @Input() status: CardStatus | null = null;
  @Input() updatedAt = '';
  @Input() visibility: 'private' | 'shared' | '' = '';
  @Input() recordCount: number | null = null;
  @Input() fieldCount = 0;
  @Input() density: GalleryDensity = 'grid';
  @Input({ required: true }) openLink: unknown[] = [];
  @Input() openQuery: Record<string, string> | null = null;
  @Input() editLink: unknown[] | null = null;
  @Input() editQuery: Record<string, string> | null = null;
  @Input() editLabel = 'Edit';
  @Input() actions: CardAction[] = [];
  @Output() readonly action = new EventEmitter<string>();
  @Output() readonly tagSelect = new EventEmitter<string>();
}
