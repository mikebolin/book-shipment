import { injectUiState } from '../core/state/index';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import {
  MatChipsModule,
  type MatChipEditedEvent,
  type MatChipInputEvent,
} from '@angular/material/chips';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
@Component({
  standalone: true,
  imports: [
    FormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatChipsModule,
  ],
  template: ` <header class="dialog-heading">
      <mat-icon>{{ data.metadata ? 'dashboard_customize' : 'edit_note' }}</mat-icon>
      <div>
        <h2 mat-dialog-title>{{ data.title }}</h2>
        @if (data.subtitle) {
          <p>{{ data.subtitle }}</p>
        }
      </div>
    </header>
    <mat-dialog-content>
      @if (data.confirm) {
        <p>{{ data.confirm }}</p>
      } @else {
        <mat-form-field appearance="outline" subscriptSizing="dynamic"
          ><mat-label>Name</mat-label
          ><input
            matInput
            [(ngModel)]="name"
            [readonly]="data.readOnly"
            maxlength="120"
            required
            cdkFocusInitial
        /></mat-form-field>
        <mat-form-field appearance="outline" subscriptSizing="dynamic"
          ><mat-label>Description</mat-label
          ><textarea
            matInput
            [(ngModel)]="description"
            [readonly]="data.readOnly"
            maxlength="2000"
            rows="2"
          ></textarea>
        </mat-form-field>
        @if (data.metadata) {
          <mat-form-field appearance="outline" subscriptSizing="dynamic"
            ><mat-label>Group</mat-label>
            <input matInput [(ngModel)]="group" [readonly]="data.readOnly" maxlength="80" />
          </mat-form-field>
          <mat-form-field appearance="outline" subscriptSizing="dynamic"
            ><mat-label>Tags</mat-label>
            <mat-chip-grid #tagGrid aria-label="Dashboard tags" [disabled]="data.readOnly">
              @for (tag of tags; track tag) {
                <mat-chip-row
                  (removed)="removeTag(tag)"
                  [editable]="!data.readOnly"
                  (edited)="editTag(tag, $event)"
                  [aria-description]="'Press Enter to edit ' + tag"
                >
                  {{ tag }}
                  <button matChipRemove type="button" [attr.aria-label]="'Remove tag ' + tag">
                    <mat-icon>cancel</mat-icon>
                  </button>
                </mat-chip-row>
              }
              <input
                aria-label="Add dashboard tag"
                [matChipInputFor]="tagGrid"
                [matChipInputSeparatorKeyCodes]="tagSeparators"
                [matChipInputAddOnBlur]="true"
                (matChipInputTokenEnd)="addTag($event)"
                [disabled]="data.readOnly"
                maxlength="32"
                placeholder="Add a tag"
              />
            </mat-chip-grid>
            <mat-hint>{{ tagError() || 'Enter or comma to add. Up to 8 tags.' }}</mat-hint>
          </mat-form-field>
        }
        @if (data.sources) {
          <mat-form-field appearance="outline"
            ><mat-label>Approved data source</mat-label
            ><mat-select [(ngModel)]="sourceKey">
              @for (source of data.sources; track source.key) {
                <mat-option [value]="source.key">{{ source.name }}</mat-option>
              }
            </mat-select></mat-form-field
          >
        }
      }</mat-dialog-content
    ><mat-dialog-actions align="end"
      ><button mat-button mat-dialog-close aria-label="Cancel" matTooltip="Cancel">Cancel</button>
      @if (!data.readOnly) {
        <button
          mat-button
          [attr.aria-label]="data.confirm ? 'Delete' : data.actionLabel || 'Save'"
          [disabled]="!data.confirm && (!name.trim() || invalidTags() || !!tagError())"
          (click)="save()"
        >
          {{ data.confirm ? 'Delete' : data.actionLabel || 'Save' }}
        </button>
      }
    </mat-dialog-actions>`,
  styles: [
    `
      mat-dialog-content {
        display: grid;
        gap: 16px;
        padding-top: 6px !important;
      }
      mat-form-field {
        display: block;
        width: 100%;
        min-width: 0;
      }
      p {
        max-width: 460px;
        line-height: 1.6;
      }
      .dialog-heading {
        display: flex;
        align-items: flex-start;
        gap: 12px;
        padding: 24px 24px 16px;
      }
      .dialog-heading > mat-icon {
        color: var(--mat-sys-primary);
        margin-top: 5px;
      }
      .dialog-heading h2 {
        margin: 0;
        padding: 0;
        font-size: 20px;
      }
      .dialog-heading p {
        margin: 4px 0 0;
        color: var(--ws-muted);
        font-size: 13px;
        line-height: 1.4;
      }
      mat-dialog-actions {
        padding: 16px 24px 20px;
      }
    `,
  ],
})
export class ResourceDialogComponent {
  private readonly reactiveState = injectUiState('ResourceDialogComponent');

  readonly data = inject<any>(MAT_DIALOG_DATA);
  readonly ref = inject(MatDialogRef);
  private readonly nameState = this.reactiveState.signal(this.data.name ?? '');
  get name() {
    return this.nameState();
  }
  set name(value) {
    this.nameState.set(value);
  }
  private readonly descriptionState = this.reactiveState.signal(this.data.description ?? '');
  get description() {
    return this.descriptionState();
  }
  set description(value) {
    this.descriptionState.set(value);
  }
  private readonly sourceKeyState = this.reactiveState.signal(this.data.sources?.[0]?.key);
  get sourceKey() {
    return this.sourceKeyState();
  }
  set sourceKey(value) {
    this.sourceKeyState.set(value);
  }
  private readonly groupState = this.reactiveState.signal(this.data.group ?? '');
  get group() {
    return this.groupState();
  }
  set group(value) {
    this.groupState.set(value);
  }
  readonly tagSeparators = [ENTER, COMMA];
  readonly tagError = this.reactiveState.signal('');
  private readonly tagsState = this.reactiveState.signal<string[]>([
    ...new Set<string>(this.data.tags ?? []),
  ]);
  get tags() {
    return this.tagsState();
  }
  set tags(value) {
    this.tagsState.set(value);
  }
  invalidTags() {
    return this.data.metadata && (this.tags.length > 8 || this.tags.some((tag) => tag.length > 32));
  }
  addTag(event: MatChipInputEvent) {
    const additions = event.value
      .split(',')
      .map((tag) => tag.trim())
      .filter(Boolean);
    const next = [...this.tags];
    for (const tag of additions)
      if (!next.some((value) => value.toLowerCase() === tag.toLowerCase())) next.push(tag);
    if (!this.validateTags(next)) return;
    this.tags = next;
    event.chipInput.clear();
  }
  removeTag(tag: string) {
    this.tags = this.tags.filter((value) => value !== tag);
    this.tagError.set('');
  }
  editTag(tag: string, event: MatChipEditedEvent) {
    const value = event.value.trim();
    const next = this.tags.flatMap((current) =>
      current === tag ? (value ? [value] : []) : [current],
    );
    if (!this.validateTags(next)) return;
    this.tags = next.filter(
      (current, index) =>
        next.findIndex((other) => other.toLowerCase() === current.toLowerCase()) === index,
    );
  }
  private validateTags(tags: string[]) {
    this.tagError.set(
      tags.length > 8
        ? 'Use up to 8 tags.'
        : tags.some((tag) => tag.length > 32)
          ? 'Each tag can contain up to 32 characters.'
          : '',
    );
    return !this.tagError();
  }
  save() {
    this.ref.close(
      this.data.confirm
        ? true
        : {
            name: this.name.trim(),
            description: this.description.trim(),
            sourceKey: this.sourceKey,
            ...(this.data.metadata
              ? {
                  group: this.group.trim(),
                  tags: [...this.tags],
                }
              : {}),
          },
    );
  }
}
