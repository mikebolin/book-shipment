import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';

export interface ConfirmDialogData {
  title: string;
  message: string;
  /** Optional second paragraph, for consequences. */
  detail?: string;
  confirmLabel?: string;
  cancelLabel?: string;
  destructive?: boolean;
}

/** The one confirmation dialog for destructive actions; the browser confirm box is never used. */
@Component({
  standalone: true,
  imports: [MatDialogModule, MatButtonModule],
  template: `
    <h2 mat-dialog-title>{{ data.title }}</h2>
    <mat-dialog-content>
      <p>{{ data.message }}</p>
      @if (data.detail) {
        <p class="detail">{{ data.detail }}</p>
      }
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button type="button" [mat-dialog-close]="false" cdkFocusInitial>
        {{ data.cancelLabel ?? 'Cancel' }}
      </button>
      <button
        mat-button
        type="button"
        [mat-dialog-close]="true"
        [class.destructive]="data.destructive"
      >
        {{ data.confirmLabel ?? 'Confirm' }}
      </button>
    </mat-dialog-actions>
  `,
  styles: `
    p {
      color: var(--ws-ink);
      font-size: 13px;
      line-height: 1.7;
      margin: 0 0 10px;
    }
    .detail {
      color: var(--ws-muted);
    }
    .destructive {
      --mdc-filled-button-container-color: var(--mat-sys-error);
      --mdc-filled-button-label-text-color: var(--mat-sys-on-error);
    }
    mat-dialog-actions {
      gap: 8px;
      padding: 12px 24px 20px;
    }
  `,
})
export class ConfirmDialogComponent {
  readonly data = inject<ConfirmDialogData>(MAT_DIALOG_DATA);
}
