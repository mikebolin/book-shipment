import { Component, computed, input } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import type { WorkspacePreview } from '../core/domain/workspace-cards';

/** Renders only a saved thumbnail; it cannot acquire a dataset or create a chart engine. */
@Component({
  selector: 'workspace-resource-preview',
  standalone: true,
  host: {
    '[attr.data-preview-kind]': 'preview()?.type ?? "summary"',
    '[attr.data-chart-type]': 'preview()?.chartType ?? null',
  },
  imports: [MatIconModule],
  template: `
    @if (preview()?.type === 'dashboard') {
      <div class="layout" aria-hidden="true">
        @for (item of preview()?.items ?? []; track $index) {
          <span
            class="placement"
            [class.section]="item.kind === 'section'"
            [class.content]="
              item.kind === 'richtext' || item.kind === 'text' || item.kind === 'html'
            "
            [style.left.%]="(item.x / 12) * 100"
            [style.top.%]="(item.y / rows()) * 100"
            [style.width.%]="(item.w / 12) * 100"
            [style.height.%]="(item.h / rows()) * 100"
          >
            @if (item.h > 1 && item.kind !== 'section') {
              <mat-icon>{{ itemIcon(item) }}</mat-icon>
            }
          </span>
        }
        @if (!preview()?.items?.length) {
          <mat-icon class="empty-layout">dashboard_customize</mat-icon>
        }
      </div>
    } @else if (points().length && circular()) {
      <svg
        viewBox="0 0 320 152"
        preserveAspectRatio="xMidYMid meet"
        role="img"
        [attr.aria-label]="preview()?.title || 'Saved chart preview'"
      >
        @for (segment of segments(); track $index) {
          <circle
            cx="160"
            cy="76"
            r="50"
            fill="none"
            stroke-width="26"
            [attr.stroke]="segment.color"
            [attr.stroke-dasharray]="segment.dash"
            [attr.stroke-dashoffset]="segment.offset"
            transform="rotate(-90 160 76)"
          />
        }
      </svg>
    } @else if (bars().length && !horizontal() && !scatter() && !histogram() && !combination()) {
      <svg
        viewBox="0 0 320 152"
        preserveAspectRatio="xMidYMid meet"
        role="img"
        [attr.aria-label]="preview()?.title || 'Saved chart preview'"
      >
        <path class="grid-line" d="M20 25H306 M20 65H306 M20 105H306" />
        @if (linear()) {
          <path class="trend" [attr.d]="linePath()" />
        }
        @for (bar of bars(); track $index) {
          @if (!linear()) {
            <rect
              [attr.x]="bar.x"
              [attr.y]="bar.y"
              [attr.width]="bar.width"
              [attr.height]="bar.height"
              rx="3"
            />
          }
          <text [attr.x]="bar.x + bar.width / 2" y="143" text-anchor="middle">
            <title>{{ bar.fullLabel }}</title>
            {{ bar.label }}
          </text>
        }
        <path class="axis" [attr.d]="'M20 ' + zero() + 'H306'" />
      </svg>
    } @else if (preview()?.type === 'chart') {
      <svg
        viewBox="0 0 320 152"
        preserveAspectRatio="xMidYMid meet"
        role="img"
        [attr.aria-label]="(preview()?.title || 'Chart') + ' · ' + preview()?.chartType + ' layout'"
      >
        @if (circular()) {
          <circle
            class="schematic-ring"
            cx="160"
            cy="76"
            r="49"
            [attr.stroke-width]="/pie/i.test(preview()?.chartType ?? '') ? 49 : 25"
          />
          <path class="schematic-slice" d="M160 27 A49 49 0 0 1 209 76" />
        } @else if (scatter()) {
          <path class="axis" d="M20 20V130H306" />
          <circle class="point" cx="56" cy="105" [attr.r]="bubble() ? 9 : 5" />
          <circle class="point" cx="89" cy="83" [attr.r]="bubble() ? 13 : 5" />
          <circle class="point" cx="139" cy="101" [attr.r]="bubble() ? 7 : 5" />
          <circle class="point" cx="170" cy="58" [attr.r]="bubble() ? 17 : 5" />
          <circle class="point" cx="217" cy="76" [attr.r]="bubble() ? 11 : 5" />
          <circle class="point" cx="268" cy="32" [attr.r]="bubble() ? 14 : 5" />
        } @else if (histogram()) {
          <rect x="38" y="102" width="36" height="28" />
          <rect x="76" y="72" width="36" height="58" />
          <rect x="114" y="32" width="36" height="98" />
          <rect x="152" y="20" width="36" height="110" />
          <rect x="190" y="58" width="36" height="72" />
          <rect x="228" y="96" width="36" height="34" />
          <path class="axis" d="M20 130H306" />
        } @else if (combination()) {
          <path class="grid-line" d="M20 25H306 M20 65H306 M20 105H306" />
          <rect x="40" y="70" width="40" height="60" rx="2" />
          <rect x="108" y="42" width="40" height="88" rx="2" />
          <rect x="176" y="59" width="40" height="71" rx="2" />
          <rect x="244" y="25" width="40" height="105" rx="2" />
          <path class="trend" d="M60 91 L128 71 L196 39 L264 52" />
          <path class="axis" d="M20 130H306" />
        } @else if (linear()) {
          <path class="grid-line" d="M20 25H306 M20 65H306 M20 105H306" />
          @if (area()) {
            <path
              class="area-fill"
              d="M24 130V118 L65 95 L106 104 L147 65 L188 74 L229 38 L298 25V130Z"
            />
          }
          <path class="trend" d="M24 118 L65 95 L106 104 L147 65 L188 74 L229 38 L298 25" />
          <path class="axis" d="M20 130H306" />
        } @else if (horizontal()) {
          <rect x="24" y="22" width="245" height="21" rx="3" />
          <rect x="24" y="54" width="181" height="21" rx="3" />
          <rect x="24" y="86" width="126" height="21" rx="3" />
          <rect x="24" y="118" width="77" height="21" rx="3" />
        } @else {
          <path class="grid-line" d="M20 25H306 M20 65H306 M20 105H306" />
          <rect x="36" y="70" width="42" height="60" rx="3" />
          <rect x="103" y="30" width="42" height="100" rx="3" />
          <rect x="170" y="52" width="42" height="78" rx="3" />
          <rect x="237" y="90" width="42" height="40" rx="3" />
          <path class="axis" d="M20 130H306" />
        }
        <title>{{ preview()?.title }} · chart layout; open to see current data</title>
      </svg>
    } @else {
      <div class="summary" aria-hidden="true">
        <mat-icon>{{ icon() }}</mat-icon>
        @if (preview()?.value != null) {
          <strong>{{ preview()?.value }}</strong>
        }
        <span>{{ preview()?.label || 'Data table' }}</span>
      </div>
    }
  `,
  styles: [
    `
      :host {
        display: block;
        height: 160px;
        box-sizing: border-box;
        padding: 12px;
        background: transparent;
        color: var(--mat-sys-primary);
      }
      svg {
        display: block;
        width: 100%;
        height: 100%;
        overflow: visible;
      }
      rect {
        fill: var(--mat-sys-primary);
        opacity: 0.84;
      }
      rect:nth-of-type(3n) {
        fill: var(--mat-sys-tertiary);
      }
      .axis,
      .grid-line {
        fill: none;
        stroke: var(--mat-sys-outline-variant);
        stroke-width: 1;
      }
      .grid-line {
        opacity: 0.4;
      }
      .trend {
        fill: none;
        stroke: var(--mat-sys-primary);
        stroke-width: 3;
        stroke-linejoin: round;
        stroke-linecap: round;
      }
      .schematic-ring {
        fill: none;
        stroke: var(--mat-sys-primary);
        opacity: 0.5;
      }
      .schematic-slice {
        fill: none;
        stroke: var(--mat-sys-tertiary);
        stroke-width: 26;
      }
      .point {
        fill: var(--mat-sys-primary);
        opacity: 0.72;
      }
      .point:nth-of-type(even) {
        fill: var(--mat-sys-tertiary);
      }
      .area-fill {
        fill: var(--mat-sys-primary);
        opacity: 0.18;
      }
      text {
        fill: var(--mat-sys-on-surface-variant);
        font:
          9px Roboto,
          sans-serif;
      }
      .layout {
        position: relative;
        height: 100%;
      }
      .placement {
        position: absolute;
        border: 3px solid var(--mat-sys-surface-container-low);
        border-radius: 7px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: var(--mat-sys-secondary-container);
        color: var(--mat-sys-on-secondary-container);
        box-sizing: border-box;
      }
      .placement mat-icon {
        font-size: 23px;
        opacity: 0.66;
      }
      .placement.section {
        background: transparent;
        border: 1px dashed var(--mat-sys-outline-variant);
        z-index: 0;
      }
      .placement.content {
        background: var(--mat-sys-surface-container-high);
        color: var(--mat-sys-on-surface-variant);
      }
      .empty-layout {
        position: absolute;
        top: calc(50% - 12px);
        left: calc(50% - 12px);
      }
      .summary {
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        gap: 8px;
        color: var(--mat-sys-on-surface-variant);
      }
      .summary mat-icon {
        font-size: 30px;
        width: 30px;
        height: 30px;
        opacity: 0.6;
      }
      .summary strong {
        font-size: 24px;
        color: var(--mat-sys-on-surface);
      }
      .summary span {
        font-size: 11px;
      }
    `,
  ],
})
export class ResourcePreviewComponent {
  readonly preview = input<WorkspacePreview | null | undefined>();
  readonly icon = input('insert_chart_outlined');
  readonly rows = computed(() =>
    Math.max(1, ...(this.preview()?.items ?? []).map((i) => i.y + i.h)),
  );
  itemIcon(item: { displayMode?: string; kind?: string }) {
    switch (item.kind) {
      case 'table':
        return 'table_chart';
      case 'chart':
        return 'bar_chart';
      case 'richtext':
      case 'text':
      case 'html':
        return 'notes';
      case 'image':
        return 'image';
      case 'powerbi':
        return 'analytics';
      default:
        return item.displayMode === 'grid' ? 'table_chart' : 'bar_chart';
    }
  }
  readonly circular = computed(() => /pie|donut|doughnut/i.test(this.preview()?.chartType ?? ''));
  readonly linear = computed(() => /line|area/i.test(this.preview()?.chartType ?? ''));
  readonly horizontal = computed(() => /bar/i.test(this.preview()?.chartType ?? ''));
  readonly scatter = computed(() => /scatter|bubble/i.test(this.preview()?.chartType ?? ''));
  readonly bubble = computed(() => /bubble/i.test(this.preview()?.chartType ?? ''));
  readonly histogram = computed(() => /histogram/i.test(this.preview()?.chartType ?? ''));
  readonly combination = computed(() => /combo/i.test(this.preview()?.chartType ?? ''));
  readonly area = computed(() => /area/i.test(this.preview()?.chartType ?? ''));
  readonly points = computed(() => {
    const preview = this.preview();
    if (preview?.type !== 'chart' || !preview.rows?.length) return [];
    const columns = preview.columns ?? [];
    const hasNumbers = (c: { id: string }) =>
      preview.rows!.some((row) => typeof row[c.id] === 'number');
    const numeric = columns.slice(1).find(hasNumbers) ?? columns.find(hasNumbers);
    if (!numeric) return [];
    const category = columns.find((c) => c.id !== numeric.id);
    return preview.rows.slice(0, 8).map((row) => ({
      value: Number(row[numeric.id]) || 0,
      label: String(category ? (row[category.id] ?? '') : ''),
    }));
  });
  private readonly range = computed(() => ({
    min: Math.min(0, ...this.points().map((p) => p.value)),
    max: Math.max(1, ...this.points().map((p) => p.value)),
  }));
  readonly zero = computed(
    () => 22 + (this.range().max / (this.range().max - this.range().min)) * 108,
  );
  readonly bars = computed(() => {
    const values = this.points();
    const step = 280 / values.length;
    const labelLength = Math.max(3, Math.min(12, Math.floor((step - 8) / 5)));
    return values.map((v, i) => ({
      x: 24 + i * step,
      y:
        v.value >= 0
          ? this.zero() - (v.value / (this.range().max - this.range().min)) * 108
          : this.zero(),
      width: Math.max(8, step - 10),
      height: Math.max(2, (Math.abs(v.value) / (this.range().max - this.range().min)) * 108),
      endpoint: this.zero() - (v.value / (this.range().max - this.range().min)) * 108,
      label: v.label.length > labelLength ? v.label.slice(0, labelLength - 1) + '\u2026' : v.label,
      fullLabel: v.label,
    }));
  });
  readonly linePath = computed(() =>
    this.bars()
      .map((bar, i) => `${i ? 'L' : 'M'}${bar.x + bar.width / 2} ${bar.endpoint}`)
      .join(' '),
  );
  readonly segments = computed(() => {
    const values = this.points().map((p) => Math.max(0, p.value));
    const total = values.reduce((a, b) => a + b, 0) || 1;
    const colors = [
      'var(--mat-sys-primary)',
      'var(--mat-sys-tertiary)',
      'var(--mat-sys-secondary)',
      'var(--mat-sys-outline)',
    ];
    let offset = 0;
    return values.map((value, i) => {
      const length = (value / total) * 314.159;
      const segment = {
        dash: `${length} ${314.159 - length}`,
        offset: -offset,
        color: colors[i % colors.length],
      };
      offset += length;
      return segment;
    });
  });
}
