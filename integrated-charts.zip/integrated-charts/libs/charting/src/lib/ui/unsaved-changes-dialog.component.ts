import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';

export type UnsavedChangesChoice = 'save' | 'discard' | 'stay';

export interface UnsavedChangesDialogData {
  /** Resource name shown in the prompt; `names` lists several at once. */
  name: string;
  names?: string[];
  title?: string;
  /** One sentence under the list, defaults to the draft explanation. */
  description?: string;
  saveLabel?: string;
  discardLabel?: string;
  keepLabel?: string;
  /** Hide the save choice when nothing can be saved from here. */
  canSave?: boolean;
}

@Component({
  standalone: true,
  imports: [MatDialogModule, MatButtonModule],
  template: `
    <h2 mat-dialog-title>{{ data.title ?? 'Save your changes?' }}</h2>
    <mat-dialog-content>
      <p>
        Your changes to
        @for (name of names; track $index; let last = $last) {
          <strong>{{ name }}</strong
          >{{ last ? '' : $index === names.length - 2 ? ' and ' : ', ' }}
        }
        have not been saved.
      </p>
      <p>
        {{
          data.description ??
            'Save a draft to pick up where you left off. Published content stays as it is.'
        }}
      </p>
    </mat-dialog-content>
    <mat-dialog-actions>
      <button mat-button [mat-dialog-close]="'stay'" cdkFocusInitial>
        {{ data.keepLabel ?? 'Keep editing' }}
      </button>
      <span></span>
      <button mat-button [mat-dialog-close]="'discard'">
        {{ data.discardLabel ?? 'Discard changes' }}
      </button>
      @if (data.canSave !== false) {
        <button mat-button [mat-dialog-close]="'save'">
          {{ data.saveLabel ?? 'Save draft' }}
        </button>
      }
    </mat-dialog-actions>
  `,
  styles: [
    `
      p {
        color: var(--ws-muted);
        font-size: 13px;
        line-height: 1.7;
        margin: 0 0 12px;
      }
      strong {
        color: var(--ws-ink);
        font-weight: 600;
      }
      mat-dialog-actions {
        gap: 4px;
        border-top: 1px solid var(--ws-border);
        padding: 12px 20px;
      }
      mat-dialog-actions span {
        flex: 1;
      }
      @media (max-width: 480px) {
        mat-dialog-actions {
          justify-content: flex-end;
        }
        mat-dialog-actions span {
          display: none;
        }
      }
    `,
  ],
})
export class UnsavedChangesDialogComponent {
  readonly data = inject<UnsavedChangesDialogData>(MAT_DIALOG_DATA);
  readonly names = this.data.names?.length
    ? this.data.names
    : [this.data.name || 'Untitled dashboard'];
}
