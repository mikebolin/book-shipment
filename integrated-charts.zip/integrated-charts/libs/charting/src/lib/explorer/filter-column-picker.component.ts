import { injectUiState } from '../core/state/index';
import { DOCUMENT } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
  ViewChild,
  inject,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatAutocompleteModule, MatAutocompleteTrigger } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import type { ColumnSpec } from '../core/domain/schema';

export type FilterColumnOrder = 'az' | 'za' | 'grid';

@Component({
  selector: 'app-filter-column-picker',
  standalone: true,
  imports: [
    FormsModule,
    MatAutocompleteModule,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatMenuModule,
    MatTooltipModule,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <mat-form-field appearance="outline" floatLabel="always" subscriptSizing="dynamic">
      <mat-label>Column</mat-label>
      <mat-icon matPrefix aria-hidden="true">search</mat-icon>
      <input
        matInput
        type="text"
        autocomplete="off"
        aria-label="Choose filter column"
        placeholder="Search columns"
        [disabled]="disabled"
        [ngModel]="search"
        (ngModelChange)="search = $event"
        [matAutocomplete]="columnOptions"
        (focus)="selectInput($event)"
        (blur)="restoreIfClosed()"
      />
      <button
        mat-icon-button
        matSuffix
        type="button"
        [disabled]="disabled"
        [matMenuTriggerFor]="orderMenu"
        aria-label="Column order"
        matTooltip="Sort columns"
      >
        <mat-icon>sort</mat-icon>
      </button>
      <mat-autocomplete
        #columnOptions="matAutocomplete"
        [panelWidth]="panelWidth"
        [displayWith]="displayColumn"
        (optionSelected)="choose($event.option.value)"
        (closed)="restoreSelection()"
      >
        @for (column of matches; track column.id) {
          <mat-option [value]="column.id">
            <span class="column-option"
              ><span>{{ column.label }}</span
              ><small>{{ column.kind }}{{ column.unit ? ' / ' + column.unit : '' }}</small></span
            >
          </mat-option>
        } @empty {
          <mat-option disabled>No matching columns. Try another name.</mat-option>
        }
      </mat-autocomplete>
    </mat-form-field>
    <mat-menu #orderMenu="matMenu">
      <button mat-menu-item (click)="setOrder('az')">
        <mat-icon>{{ order === 'az' ? 'check' : 'sort_by_alpha' }}</mat-icon
        >A to Z
      </button>
      <button mat-menu-item (click)="setOrder('za')">
        <mat-icon>{{ order === 'za' ? 'check' : 'sort_by_alpha' }}</mat-icon
        >Z to A
      </button>
      <button mat-menu-item (click)="setOrder('grid')">
        <mat-icon>{{ order === 'grid' ? 'check' : 'view_column' }}</mat-icon
        >Grid order
      </button>
    </mat-menu>
  `,
  styles: `
    :host {
      display: block;
      min-width: 0;
    }
    mat-form-field {
      display: block;
      width: 100%;
      min-width: 0;
      --mat-form-field-container-height: 46px;
      --mat-form-field-container-vertical-padding: 11px;
      --mat-form-field-container-text-size: 13px;
    }
    input {
      min-width: 0;
      text-overflow: ellipsis;
    }
    mat-icon[matPrefix] {
      width: 18px;
      height: 18px;
      font-size: 18px;
      padding-inline: 10px 6px;
      box-sizing: content-box;
      color: var(--mat-sys-on-surface-variant);
    }
    button[matSuffix] {
      --mat-icon-button-state-layer-size: 40px;
      --mat-icon-button-touch-target-display: none;
      width: 40px;
      height: 40px;
      padding: 10px;
      margin-right: 3px;
    }
    button[matSuffix] mat-icon {
      width: 20px;
      height: 20px;
      font-size: 20px;
    }
    .column-option {
      display: grid;
      gap: 3px;
      padding-block: 5px;
      font-size: 13px;
      line-height: 1.4;
      overflow-wrap: anywhere;
      white-space: normal;
      min-width: 0;
    }
    .column-option small {
      color: var(--mat-sys-on-surface-variant);
      font-size: 11px;
      white-space: normal;
    }
    @media (pointer: coarse) {
      mat-form-field {
        --mat-form-field-container-text-size: 16px;
      }
    }
  `,
})
export class FilterColumnPickerComponent implements OnChanges {
  private readonly reactiveState = injectUiState('FilterColumnPickerComponent');
  private readonly document = inject(DOCUMENT);

  @Input() columns: readonly ColumnSpec[] = [];
  @Input() value = '';
  @Input() order: FilterColumnOrder = 'az';
  @Input() disabled = false;
  @Output() readonly valueChange = new EventEmitter<string>();
  @Output() readonly orderChange = new EventEmitter<FilterColumnOrder>();
  @ViewChild(MatAutocompleteTrigger) private trigger?: MatAutocompleteTrigger;
  private readonly searchState = this.reactiveState.signal('');
  get search() {
    return this.searchState();
  }
  set search(value) {
    this.searchState.set(value);
  }
  readonly displayColumn = (id: string): string =>
    this.columns.find((column) => column.id === id)?.label ?? id ?? '';

  /** Suggestions need room for names and metadata even when the trigger is a compact cell. */
  get panelWidth(): number {
    return Math.min(440, (this.document.defaultView?.innerWidth ?? 1024) - 32);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['value'] || changes['columns']) this.restoreSelection();
  }
  get label(): string {
    return this.columns.find((column) => column.id === this.value)?.label ?? this.value;
  }
  get matches(): ColumnSpec[] {
    const entered = this.search.trim().toLocaleLowerCase();
    const query = entered === this.label.toLocaleLowerCase() ? '' : entered;
    const result = this.columns.filter(
      (column) =>
        !query ||
        [column.label, column.id, ...column.aliases].some((value) =>
          value.toLocaleLowerCase().includes(query),
        ),
    );
    if (this.order !== 'grid')
      result.sort(
        (a, b) =>
          (this.order === 'az' ? 1 : -1) *
          a.label.localeCompare(b.label, undefined, { numeric: true, sensitivity: 'base' }),
      );
    return result;
  }
  choose(value: string): void {
    if (this.disabled || !this.columns.some((column) => column.id === value)) return;
    this.value = value;
    this.restoreSelection();
    this.valueChange.emit(value);
  }
  setOrder(order: FilterColumnOrder): void {
    this.order = order;
    this.orderChange.emit(order);
  }
  selectInput(event: FocusEvent): void {
    (event.target as HTMLInputElement).select();
  }
  restoreIfClosed(): void {
    if (!this.trigger?.panelOpen) this.restoreSelection();
  }
  restoreSelection(): void {
    this.search = this.label;
  }
}
