import type { ChartPlan } from '../core/domain/integrated-chart';

export type PromptOutcome = 'apply' | 'calculated' | 'clarify' | 'unsupported' | 'sequence';
export interface PromptExample {
  id: string;
  category: string;
  title: string;
  prompt: string;
  outcome: PromptOutcome;
  expectation: string;
  fields: readonly string[];
  /** Reviewed chart variant, used to browse demos without model inference. */
  chartType?: ChartPlan['type'];
  requirements?: readonly string[];
  /** Prompt-only benchmark follow-up; never an executable answer plan. */
  benchmarkBaseCase?: string | null;
  followUps?: readonly { title: string; prompt: string; expectation: string }[];
}

export const PROMPT_CATEGORIES = [
  {
    id: 'workflows',
    label: 'Guided workflows',
    description: 'Choose data, build a chart, then refine the result',
  },
  {
    id: 'logic',
    label: 'Advanced filters',
    description: 'Nested conditions, text and numeric ranges',
  },
  {
    id: 'dates',
    label: 'Dates & periods',
    description: 'Calendar windows, timestamps and historical prices',
  },
  {
    id: 'sets',
    label: 'Sets & missing values',
    description: 'Explicit selections, exclusions and blanks',
  },
  {
    id: 'analysis',
    label: 'Group, sort & pivot',
    description: 'Multiple dimensions and aggregate measures',
  },
  {
    id: 'calculated',
    label: 'Calculated columns',
    description: 'Review a formula together with its requested grid changes',
  },
  {
    id: 'charts',
    label: 'Charts',
    description: 'Comparisons, trends, relationships and distributions',
  },
  {
    id: 'dashboards',
    label: 'Dashboards & follow-ups',
    description: 'Filtered dashboards and several-turn workflows',
  },
  {
    id: 'boundaries',
    label: 'Clarification & limits',
    description: 'Requests that should ask a question or explain a limitation',
  },
] as const;

export const PROMPT_OUTCOMES: Record<PromptOutcome, string> = {
  apply: 'Ready to review',
  calculated: 'Calculation + changes',
  clarify: 'Asks a question',
  unsupported: 'Explains a limitation',
  sequence: 'Several turns',
};

