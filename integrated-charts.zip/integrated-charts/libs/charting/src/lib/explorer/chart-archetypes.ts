import type { ColumnSpec } from '../core/domain/schema';
import type { ChartDataset, ChartPlan } from '../core/domain/integrated-chart';
import { CHART_DEMO_VARIANTS } from './chart-demo-types';
import { buildChartDataset, type ChartSourceRow } from '../core/domain/chart-data';
import {
  chartObservationNote,
  comparableObservedMeasures,
  observedCategoryScore,
  observedMeasureScore,
  observedTimeBucket,
  preferredAggregation,
  type ChartDataProfile,
} from './chart-data-profile';
import {
  defaultGuidePlan,
  guideFields,
  guidePlanError,
  isComboChart,
  isRawChart,
  isTimeChart,
  defaultComboSeries,
} from './chart-guide';

export interface ChartArchetype {
  candidateId?: string;
  id: ChartPlan['type'];
  label: string;
  family: string;
  description: string;
  reason: string;
  score: number;
  supported: boolean;
  limitation: string;
  plan: ChartPlan;
  illustration: ChartDataset;
  fields: string[];
  dataNote?: string;
}

export interface GuideRole {
  kind: 'category' | 'measure' | 'interval' | 'aggregation';
  label: string;
  help: string;
  slot?: number;
}

const schemaFields = new WeakMap<readonly ColumnSpec[], ReturnType<typeof guideFields>>();
function chartFields(columns: readonly ColumnSpec[]) {
  let fields = schemaFields.get(columns);
  if (!fields) {
    fields = guideFields(columns);
    schemaFields.set(columns, fields);
  }
  return fields;
}

/** A variant must be usable with the user's fields, not just a different example in the schema. */
export function chartVariantSelection(
  current: ChartPlan,
  type: ChartPlan['type'],
  columns: readonly ColumnSpec[],
  profile?: ChartDataProfile | null,
): { plan: ChartPlan; limitation: string } {
  const plan = { ...structuredClone(current), type };
  const minimum = /stacked|normalized|Combo/i.test(type)
    ? 2
    : type === 'bubble'
      ? 3
      : type === 'scatter'
        ? 2
        : 1;
  while (
    plan.measureColumnIds.length < minimum &&
    !(plan.aggregation === 'count' && !plan.measureColumnIds.length)
  ) {
    const next = rankedChartFields(
      columns,
      { kind: 'measure', slot: plan.measureColumnIds.length, label: 'Measure', help: '' },
      plan,
      '',
      columns.length,
      profile,
    )[0];
    if (!next) {
      const field = columns.find((column) => column.id === plan.measureColumnIds[0]);
      return {
        plan,
        limitation: field
          ? `This style needs another field with the same unit as ${field.label}. Choose a different measure to use it.`
          : 'This style needs more numeric fields. Choose a different measure to use it.',
      };
    }
    plan.measureColumnIds.push(next.id);
  }
  plan.seriesChartTypes =
    type === 'customCombo' ? defaultComboSeries(plan.measureColumnIds, columns) : null;
  return { plan, limitation: guidePlanError(plan, columns) };
}

export function schemaChartInsights(columns: readonly ColumnSpec[]) {
  const fields = chartFields(columns);
  return {
    measures: fields.measures.length,
    dates: fields.dates.length,
    categories: fields.categories.filter((column) => !fields.dates.includes(column)).length,
    identifiers: columns.filter((column) => fields.metadata.get(column.id)?.role === 'identifier')
      .length,
    knownUnits: [
      ...new Set(
        fields.measures.map((column) => fields.metadata.get(column.id)?.unit).filter(Boolean),
      ),
    ] as string[],
  };
}

/** Deterministic ranking from schema metadata only. It makes no claim about observed row values. */
export function rankedChartFields(
  columns: readonly ColumnSpec[],
  role: GuideRole,
  plan: ChartPlan,
  query = '',
  limit = 8,
  profile?: ChartDataProfile | null,
): ColumnSpec[] {
  const fields = chartFields(columns);
  // Later roles are suggestions until reviewed; they must not hide valid choices
  // from an earlier step. Selection swaps a conflicting later suggestion.
  const chosen = new Set(plan.measureColumnIds.slice(0, role.slot ?? 0));
  const firstUnit = fields.metadata.get(plan.measureColumnIds[0])?.unit;
  const candidates =
    role.kind === 'category'
      ? isTimeChart(plan.type)
        ? fields.dates
        : fields.categories
      : fields.measures.filter((column) => {
          if (chosen.has(column.id)) return false;
          if (
            !role.slot &&
            plan.measureColumnIds.length > 1 &&
            !isRawChart(plan.type) &&
            plan.type !== 'customCombo' &&
            plan.aggregation !== 'count'
          ) {
            const unit = fields.metadata.get(column.id)?.unit;
            if (
              !unit ||
              fields.measures.filter((field) => fields.metadata.get(field.id)?.unit === unit)
                .length < plan.measureColumnIds.length
            )
              return false;
          }
          // Shared axes must compare like units. Raw plots and custom combinations
          // can place unrelated measures on independent axes.
          return (
            !role.slot ||
            isRawChart(plan.type) ||
            plan.type === 'customCombo' ||
            plan.aggregation === 'count' ||
            Boolean(firstUnit && fields.metadata.get(column.id)?.unit === firstUnit)
          );
        });
  const search = query.trim().toLocaleLowerCase();
  const score = (column: ColumnSpec) => {
    const metadata = fields.metadata.get(column.id)!;
    let value = column.description ? 2 : 0;
    if (role.kind === 'category') {
      if (profile) value += observedCategoryScore(column, plan, profile);
      if (column.values?.length && column.values.length <= 12) value += 20;
      else if (column.values?.length && column.values.length <= 30) value += 12;
      if (isTimeChart(plan.type) && metadata.role === 'temporal') value += 20;
      if (!isTimeChart(plan.type) && metadata.role === 'dimension') value += 6;
    } else {
      if (profile) {
        value += observedMeasureScore(column, profile);
        const first = columns.find((field) => field.id === plan.measureColumnIds[0]);
        if (role.slot && first && !isRawChart(plan.type))
          value += comparableObservedMeasures(first, column, profile) ? 50 : -50;
        if (role.label === 'Bubble size' && (profile.fields.get(column.id)?.minimum ?? 0) < 0)
          value -= 200;
      }
      if (metadata.unit) value += 8;
      if (firstUnit && metadata.unit === firstUnit && !isRawChart(plan.type)) value += 15;
      if (
        /amount|balance|total|value|revenue|cost|quantity|score|temperature|duration/i.test(
          `${column.label} ${column.description}`,
        )
      )
        value += 5;
      if (
        role.label === 'Bubble size' &&
        /amount|value|volume|quantity|count|size|population/i.test(
          `${column.label} ${column.description}`,
        )
      )
        value += 8;
    }
    // Prefer concise business fields over repeated generated period columns, without
    // relying on a particular demo's column IDs or array order.
    if (/\b20\d{2}\b/.test(column.label)) value -= 5;
    return value - Math.min(column.label.length, 100) / 100;
  };
  const scores = new Map(candidates.map((column) => [column.id, score(column)]));
  return candidates
    .filter(
      (column) =>
        !search ||
        `${column.label} ${column.id} ${column.unit ?? ''} ${column.description} ${column.aliases.join(' ')}`
          .toLocaleLowerCase()
          .includes(search),
    )
    .sort((a, b) => scores.get(b.id)! - scores.get(a.id)! || a.label.localeCompare(b.label))
    .slice(0, limit);
}

export function chartGuideRoles(plan: ChartPlan): GuideRole[] {
  const roles: GuideRole[] = [];
  if (!isRawChart(plan.type)) {
    roles.push({
      kind: 'category',
      label: isTimeChart(plan.type) ? 'Date field' : 'Category',
      help: isTimeChart(plan.type)
        ? 'Choose the date that defines the timeline.'
        : 'Choose how records should be grouped. A short list of categories is easiest to compare.',
    });
    if (plan.timeBucket)
      roles.push({
        kind: 'interval',
        label: 'Time interval',
        help: 'Choose how dates are grouped. Months are a useful starting point.',
      });
  }
  const minimumCount =
    plan.type === 'bubble'
      ? 3
      : plan.type === 'scatter' || isComboChart(plan.type) || /stacked|normalized/i.test(plan.type)
        ? 2
        : 1;
  const count = Math.max(minimumCount, Math.min(3, plan.measureColumnIds.length));
  if (isRawChart(plan.type) || plan.aggregation !== 'count' || plan.measureColumnIds.length) {
    for (let slot = 0; slot < count; slot++)
      roles.push({
        kind: 'measure',
        slot,
        label:
          plan.type === 'bubble' || plan.type === 'scatter'
            ? ['X measure', 'Y measure', 'Bubble size'][slot]!
            : slot
              ? slot === 1
                ? 'Second series'
                : 'Third series'
              : 'Measure',
        help:
          plan.type === 'bubble' && slot === 2
            ? 'A third, nonnegative measure controls each bubble’s size.'
            : slot
              ? 'Choose a different numeric field. Shared axes need compatible units.'
              : 'Choose the numeric value to summarize or compare. Identifier fields are excluded.',
      });
  }
  if (!isRawChart(plan.type))
    roles.push({
      kind: 'aggregation',
      label: 'Calculation',
      help: 'Choose what each plotted value represents. Use averages for prices, rates and ratios.',
    });
  return roles;
}

const descriptions: Record<string, string> = {
  Column: 'Compare values across categories with vertical bars.',
  Bar: 'Compare categories with horizontal bars, useful for longer names.',
  Line: 'Follow changes over a date-based timeline.',
  Area: 'Show how values and their composition change over time.',
  Pie: 'Show each category’s share of a nonnegative total.',
  Donut: 'Compare a few categories as parts of a whole.',
  Scatter: 'Explore the relationship between two numeric fields.',
  Bubble: 'Explore two numeric fields with a third shown by bubble size.',
  Histogram: 'See the distribution and spread of a numeric field.',
  Combination: 'Compare multiple measures using complementary series styles.',
};

/** Small illustrative datasets show the shape of a chart, never pretend to be a data preview. */
export function archetypeIllustration(type: ChartPlan['type']): ChartDataset {
  if (['scatter', 'bubble', 'histogram'].includes(type)) {
    const count = type === 'bubble' ? 3 : type === 'scatter' ? 2 : 1;
    return {
      type,
      title: '',
      columns: Array.from({ length: count }, (_, index) => ({
        id: `measure${index}`,
        label: ['X', 'Y', 'Size'][index]!,
        dataType: 'series' as const,
      })),
      rows: Array.from({ length: 18 }, (_, index) =>
        Object.fromEntries(
          Array.from({ length: count }, (_, measure) => [
            `measure${measure}`,
            measure === 0
              ? 12 + index * 3 + (index % 4) * 2
              : measure === 1
                ? 10 + index * 2 + (index % 5) * 5
                : 4 + (index % 6) * 3,
          ]),
        ),
      ),
      appearance: {
        theme: null,
        legendPosition: null,
        showLegend: false,
        showLabels: false,
        xAxisTitle: null,
        yAxisTitle: null,
      },
    };
  }
  const multiple = /stacked|normalized|Combo|grouped/i.test(type);
  const columns: ChartDataset['columns'] = [
    { id: 'category', label: 'Category', dataType: 'category' },
    { id: 'measure0', label: 'Series A', dataType: 'series' },
    ...(multiple ? [{ id: 'measure1', label: 'Series B', dataType: 'series' as const }] : []),
  ];
  return {
    type,
    title: '',
    columns,
    rows: ['Jan', 'Feb', 'Mar', 'Apr', 'May'].map((category, index) => ({
      category: isTimeChart(type)
        ? category
        : ['North', 'South', 'East', 'West', 'Central'][index]!,
      measure0: [24, 37, 28, 46, 54][index]!,
      ...(multiple ? { measure1: [17, 21, 14, 29, 25][index]! } : {}),
    })),
    ...(type === 'customCombo'
      ? {
          seriesChartTypes: [
            { colId: 'measure0', chartType: 'groupedColumn' as const, secondaryAxis: false },
            { colId: 'measure1', chartType: 'line' as const, secondaryAxis: false },
          ],
        }
      : {}),
    appearance: {
      theme: null,
      legendPosition: null,
      showLegend: false,
      showLabels: false,
      xAxisTitle: null,
      yAxisTitle: null,
    },
  };
}

/** A small, clearly labelled illustration of the current mapping, while local data computes. */
export function guideIllustration(plan: ChartPlan, columns: readonly ColumnSpec[]): ChartDataset {
  const base = archetypeIllustration(plan.type);
  const byId = new Map(columns.map((column) => [column.id, column]));
  const category = byId.get(plan.categoryColumnId ?? '');
  const ids = plan.measureColumnIds.length ? plan.measureColumnIds : ['__count'];
  const raw = isRawChart(plan.type);
  const fieldLabels = ids.map((id) => byId.get(id)?.label ?? 'Record count');
  const seriesIds = ids.map((_, index) => `measure${index}`);
  const categories = category?.values?.slice(0, 5);
  const numberOfRows = raw ? base.rows.length : 5;
  const seed = (id: string) => [...id].reduce((sum, character) => sum + character.charCodeAt(0), 0);
  return {
    ...base,
    title:
      plan.title ||
      (raw
        ? fieldLabels.join(' / ')
        : `${fieldLabels.join(' / ')} by ${category?.label ?? 'category'}`),
    appearance: { ...base.appearance!, ...plan.appearance },
    columns: [
      ...(!raw
        ? [{ id: 'category', label: category?.label ?? 'Category', dataType: 'category' as const }]
        : []),
      ...seriesIds.map((id, index) => ({
        id,
        label: fieldLabels[index]!,
        dataType: 'series' as const,
        sourceColumnId: ids[index],
        unit: byId.get(ids[index]!)?.unit ?? null,
        aggregation: plan.aggregation,
      })),
    ],
    rows: Array.from({ length: numberOfRows }, (_, index) => ({
      ...(!raw
        ? {
            category:
              categories?.[index] ??
              (isTimeChart(plan.type)
                ? ['Jan', 'Feb', 'Mar', 'Apr', 'May'][index]!
                : ['North', 'South', 'East', 'West', 'Central'][index]!),
          }
        : {}),
      ...Object.fromEntries(
        seriesIds.map((id, slot) => {
          const hash = seed(ids[slot]!);
          const factor = plan.aggregation === 'avg' ? 0.4 : plan.aggregation === 'count' ? 0.2 : 1;
          return [id, Math.round((12 + ((index * (slot + 3) * 7 + hash) % 70)) * factor)];
        }),
      ),
    })),
    seriesChartTypes:
      plan.type === 'customCombo'
        ? (plan.seriesChartTypes?.map((series) => ({
            ...series,
            colId: seriesIds[ids.indexOf(series.colId)]!,
          })) ?? null)
        : null,
  };
}

export function chartArchetypes(
  columns: readonly ColumnSpec[],
  profile?: ChartDataProfile | null,
): ChartArchetype[] {
  const fields = guideFields(columns);
  return CHART_DEMO_VARIANTS.map((variant) => {
    const plan = defaultGuidePlan(variant.id, columns);
    const count =
      plan.type === 'bubble'
        ? 3
        : plan.type === 'scatter' ||
            isComboChart(plan.type) ||
            /stacked|normalized/i.test(plan.type)
          ? 2
          : 1;
    plan.measureColumnIds = [];
    for (let slot = 0; slot < count; slot++) {
      const field = rankedChartFields(
        columns,
        { kind: 'measure', slot, label: slot === 2 ? 'Bubble size' : 'Measure', help: '' },
        plan,
        '',
        columns.length,
        profile,
      )[0];
      if (field) plan.measureColumnIds.push(field.id);
    }
    // Grouped examples should show the exact fields that will populate the form.
    // Add a second series only when real values share both units and a readable scale.
    if (
      profile &&
      ['groupedColumn', 'groupedBar'].includes(plan.type) &&
      plan.measureColumnIds.length === 1
    ) {
      const first = columns.find((column) => column.id === plan.measureColumnIds[0])!;
      const second = rankedChartFields(
        columns,
        { kind: 'measure', slot: 1, label: 'Second series', help: '' },
        plan,
        '',
        columns.length,
        profile,
      ).find((column) => comparableObservedMeasures(first, column, profile));
      if (second) plan.measureColumnIds.push(second.id);
    }
    const first = columns.find((column) => column.id === plan.measureColumnIds[0]);
    if (!isRawChart(plan.type)) plan.aggregation = !first ? 'count' : preferredAggregation(first);
    const category = rankedChartFields(
      columns,
      { kind: 'category', label: 'Category', help: '' },
      plan,
      '',
      columns.length,
      profile,
    )[0];
    if (!isRawChart(plan.type)) {
      plan.categoryColumnId = category?.id ?? null;
      plan.timeBucket = profile
        ? observedTimeBucket(category, profile)
        : category && ['date', 'datetime'].includes(category.kind)
          ? 'month'
          : null;
    }
    if (['pie', 'donut'].includes(plan.type)) {
      const additive = rankedChartFields(
        columns,
        { kind: 'measure', slot: 0, label: 'Measure', help: '' },
        plan,
        '',
        columns.length,
        profile,
      ).find(
        (column) =>
          preferredAggregation(column) === 'sum' &&
          (!profile || (profile.fields.get(column.id)?.minimum ?? -1) >= 0),
      );
      // Averages of prices/rates do not describe parts of a whole. If there is
      // no nonnegative additive value, record counts make an honest proportion.
      plan.measureColumnIds = additive ? [additive.id] : [];
      plan.aggregation = additive ? 'sum' : 'count';
    }
    if (plan.type === 'customCombo') {
      const unit = fields.metadata.get(plan.measureColumnIds[0])?.unit;
      plan.seriesChartTypes = plan.measureColumnIds.map((id, index) => ({
        colId: id,
        chartType: index ? 'line' : 'groupedColumn',
        secondaryAxis: index > 0 && (!unit || fields.metadata.get(id)?.unit !== unit),
      }));
    }
    let limitation =
      count > 1 && plan.measureColumnIds.length < count
        ? `This style needs ${count} distinct numeric measures.`
        : guidePlanError(plan, columns);
    const roles = [plan.categoryColumnId, ...plan.measureColumnIds].filter(Boolean) as string[];
    const names = roles.map((id) => columns.find((column) => column.id === id)!.label);
    let illustration = guideIllustration(plan, columns);
    let dataNote = profile ? chartObservationNote(plan, columns, profile) : '';
    if (profile && !limitation) {
      try {
        const result = buildChartDataset(
          { ...plan, title: illustration.title },
          columns,
          profile.rows as readonly ChartSourceRow[],
          Math.max(profile.rows.length, 1),
        );
        illustration = {
          ...result,
          appearance: {
            theme: null,
            legendPosition: 'bottom',
            showLegend: plan.measureColumnIds.length > 1,
            showLabels: false,
            xAxisTitle: null,
            yAxisTitle: null,
          },
        };
      } catch (error) {
        limitation = (error as Error).message;
        illustration = { ...illustration, rows: [] };
      }
    }
    const score =
      (limitation ? -100 : 0) +
      (['groupedColumn', 'groupedBar', 'line', 'donut', 'histogram', 'scatter'].includes(plan.type)
        ? 20
        : 5) +
      (isTimeChart(plan.type) && fields.dates.length ? 8 : 0) +
      (category?.values?.length &&
      category.values.length <= 12 &&
      ['groupedColumn', 'groupedBar', 'donut'].includes(plan.type)
        ? 10
        : 0);
    return {
      ...variant,
      description: descriptions[variant.family]!,
      reason:
        limitation ||
        `${plan.categoryColumnId ? `Group by ${category?.label}` : `Use ${names[0] ?? 'numeric values'}`}${plan.categoryColumnId && names.length > 1 ? ` and compare ${names.slice(1).join(' / ')}` : names.length > 1 ? ` against ${names.slice(1).join(' / ')}` : ''}.`,
      score,
      supported: !limitation,
      limitation,
      plan,
      illustration,
      dataNote,
      fields: names,
    };
  }).sort((a, b) => b.score - a.score || a.label.localeCompare(b.label));
}
