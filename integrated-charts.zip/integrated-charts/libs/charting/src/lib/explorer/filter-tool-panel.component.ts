import { injectUiState } from '../core/state/index';
import { ChangeDetectionStrategy, Component, OnDestroy, computed } from '@angular/core';
import type { IToolPanelAngularComp } from 'ag-grid-angular';
import type { AdvancedFilterModel, IToolPanelParams } from 'ag-grid-community';
import { AdvancedFilterBuilderComponent } from './advanced-filter-builder.component';
import type { ColumnSpec } from '../core/domain/schema';

export const EXPLORER_FILTER_PANEL = 'explorerFilters';

export interface FilterToolPanelParams extends IToolPanelParams {
  panelId: string;
  getColumns: () => readonly ColumnSpec[];
  getModel: () => AdvancedFilterModel | null;
  isLocked: () => boolean;
  applyModel: (model: AdvancedFilterModel | null) => string | null;
  clearModel: () => string | null;
  closePanel: () => void;
}

/** AG Grid owns visibility; the editor retains its private draft between openings. */
@Component({
  selector: 'app-filter-tool-panel',
  standalone: true,
  imports: [AdvancedFilterBuilderComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (params(); as settings) {
      <section
        class="filter-tool-panel"
        [id]="settings.panelId"
        aria-label="Filters"
        (keydown.escape)="onEscape($event)"
      >
        @if (error()) {
          <p class="filter-panel-error" role="alert">{{ error() }}</p>
        }
        <app-advanced-filter-builder
          [embedded]="true"
          [columns]="columns()"
          [model]="model()"
          [resetRevision]="resetRevision()"
          [disabled]="settings.isLocked() || modelUnavailable()"
          title="Filters"
          (applied)="apply($event)"
          (cleared)="clear()"
          (closed)="settings.closePanel()"
        />
      </section>
    }
  `,
  styles: `
    :host,
    .filter-tool-panel {
      display: flex;
      flex-direction: column;
      height: 100%;
      min-width: 0;
      min-height: 0;
      width: 100%;
      overflow: hidden;
      color: var(--mat-sys-on-surface);
      background: var(--mat-sys-surface-container-lowest);
      font-family: Roboto, 'Segoe UI', sans-serif;
    }
    app-advanced-filter-builder {
      flex: 1;
      min-height: 0;
      min-width: 0;
    }
    .filter-panel-error {
      flex: 0 0 auto;
      margin: 0;
      padding: 12px 16px;
      font-size: 12px;
      line-height: 1.5;
      background: var(--mat-sys-error-container);
      color: var(--mat-sys-on-error-container);
    }
  `,
})
export class FilterToolPanelComponent implements IToolPanelAngularComp, OnDestroy {
  private readonly reactiveState = injectUiState('FilterToolPanelComponent');

  readonly params = this.reactiveState.signal<FilterToolPanelParams | null>(null);
  readonly columns = computed(() => this.params()?.getColumns() ?? []);
  readonly model = this.reactiveState.signal<AdvancedFilterModel | null>(null);
  readonly resetRevision = this.reactiveState.signal(0);
  readonly error = this.reactiveState.signal('');
  readonly modelUnavailable = this.reactiveState.signal(false);
  private appliedKey = '';
  private readonly syncModel = (): void => {
    const params = this.params();
    if (!params || params.api.isDestroyed()) return;
    try {
      const model = params.getModel();
      const key = JSON.stringify(model);
      if (key !== this.appliedKey) {
        this.appliedKey = key;
        this.model.set(model ? structuredClone(model) : null);
        this.error.set('');
      }
      this.modelUnavailable.set(false);
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : 'This filter cannot be edited here.');
      this.modelUnavailable.set(true);
    }
  };

  agInit(params: FilterToolPanelParams): void {
    this.params.set(params);
    params.api.addEventListener('filterChanged', this.syncModel);
    this.syncModel();
  }

  refresh(params: FilterToolPanelParams): boolean {
    this.params.set(params);
    this.syncModel();
    return true;
  }

  apply(model: AdvancedFilterModel | null): void {
    const params = this.params();
    if (!params || params.isLocked() || this.modelUnavailable()) return;
    const error = params.applyModel(model);
    this.error.set(error ?? '');
    if (!error) {
      this.syncModel();
      if (!this.error()) params.closePanel();
    }
  }

  clear(): void {
    const params = this.params();
    if (!params || params.isLocked()) return;
    this.error.set(params.clearModel() ?? '');
  }

  /** An explicit clear also discards drafts when the applied model was already null. */
  resetDraft(): void {
    this.syncModel();
    if (this.modelUnavailable()) return;
    this.error.set('');
    this.resetRevision.update((revision) => revision + 1);
  }

  onEscape(event: Event): void {
    if (event.defaultPrevented) return;
    event.preventDefault();
    event.stopPropagation();
    this.params()?.closePanel();
  }

  ngOnDestroy(): void {
    const api = this.params()?.api;
    if (api && !api.isDestroyed()) api.removeEventListener('filterChanged', this.syncModel);
  }
}
