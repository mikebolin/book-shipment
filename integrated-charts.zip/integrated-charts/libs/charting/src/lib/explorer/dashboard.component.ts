import { ChangeDetectionStrategy, Component, Input, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import type { DashboardChart, DashboardMetric, DashboardResponse } from '../core/domain/dashboard';
import { IntegratedChartComponent } from './integrated-chart.component';

type Format = DashboardMetric['format'];
interface PlotPoint {
  x: number;
  y: number;
  value: number;
  category: string;
}
interface PlotBar extends PlotPoint {
  width: number;
  height: number;
}
interface ChartSeries {
  id: string;
  label: string;
  format: Format;
  color: string;
  path: string;
  points: PlotPoint[];
  bars: PlotBar[];
}
interface HorizontalRow {
  label: string;
  values: {
    label: string;
    value: number | null;
    format: Format;
    color: string;
    left: number;
    width: number;
  }[];
}
interface ChartView {
  chart: DashboardChart;
  series: ChartSeries[];
  horizontal: HorizontalRow[];
  zero: number;
  zeroPercent: number;
  yTicks: { value: number; top: number }[];
  xTicks: { label: string; left: number; first: boolean; last: boolean }[];
  hasValues: boolean;
  mixedUnits: boolean;
  format: Format;
  description: string;
}

const PLOT_WIDTH = 700;
const PLOT_HEIGHT = 220;
const COLORS = Array.from({ length: 6 }, (_, index) => `var(--app-chart-${index + 1})`);
const finite = (value: unknown): value is number =>
  typeof value === 'number' && Number.isFinite(value);

@Component({
  selector: 'app-analysis-dashboard',
  standalone: true,
  imports: [CommonModule, IntegratedChartComponent],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DashboardComponent implements OnChanges {
  @Input() data: DashboardResponse | null = null;
  @Input() busy = false;
  @Input() error = '';
  charts: ChartView[] = [];

  ngOnChanges(): void {
    this.charts = (this.data?.charts ?? []).map((chart) => this.chartView(chart));
  }

  formatValue(value: number | null | undefined, format: Format, compact = false): string {
    if (!finite(value)) return '—';
    const normalized = Object.is(value, -0) ? 0 : value;
    if (format === 'percent')
      return new Intl.NumberFormat('en-US', { style: 'percent', maximumFractionDigits: 1 }).format(
        normalized / 100,
      );
    const abbreviate = compact && Math.abs(normalized) >= 1_000_000;
    return new Intl.NumberFormat('en-US', {
      ...(format === 'currency' ? { style: 'currency', currency: 'USD' } : {}),
      notation:
        compact && Math.abs(normalized) >= 1e15
          ? 'scientific'
          : abbreviate
            ? 'compact'
            : 'standard',
      maximumFractionDigits: abbreviate ? 1 : 2,
    }).format(normalized);
  }

  axisValue(value: number, format: Format): string {
    if (!finite(value)) return '—';
    if (format === 'percent') return this.formatValue(value, format);
    return new Intl.NumberFormat('en-US', {
      ...(format === 'currency' ? { style: 'currency', currency: 'USD' } : {}),
      notation: Math.abs(value) >= 1e15 ? 'scientific' : 'compact',
      maximumFractionDigits: 1,
    }).format(value);
  }

  metricDescription(metric: DashboardMetric): string {
    return `${metric.label}: ${finite(metric.value) ? this.formatValue(metric.value, metric.format) : 'Not available'}`;
  }

  seriesValue(chart: DashboardChart, seriesIndex: number, categoryIndex: number): number | null {
    const value = chart.series[seriesIndex]?.values[categoryIndex];
    return finite(value) ? value : null;
  }

  private categoryLabel(category: string): string {
    if (/^\d{4}-\d{2}-\d{2}$/.test(category)) {
      const date = new Date(`${category}T00:00:00Z`);
      if (finite(date.getTime()))
        return new Intl.DateTimeFormat('en-US', {
          month: 'short',
          day: 'numeric',
          year: '2-digit',
          timeZone: 'UTC',
        }).format(date);
    }
    return category;
  }

  private chartView(chart: DashboardChart): ChartView {
    const values = chart.series.flatMap((series) => series.values.filter(finite));
    const format = chart.series[0]?.format ?? 'number';
    const min = values.length ? Math.min(...values) : 0;
    const max = values.length ? Math.max(...values) : 1;
    // Normalize before computing ranges, so large positive and negative values
    // cannot overflow the chart geometry even when their difference would.
    const magnitude = Math.max(Math.abs(min), Math.abs(max), 1);
    let scaledMin = min / magnitude;
    let scaledMax = max / magnitude;
    if (chart.kind === 'bar') {
      scaledMin = Math.min(0, scaledMin);
      scaledMax = Math.max(0, scaledMax);
      if (scaledMin === scaledMax) scaledMax = 1;
    } else {
      const padding =
        scaledMin === scaledMax
          ? Math.max(Math.abs(scaledMax) * 0.05, 1 / magnitude)
          : (scaledMax - scaledMin) * 0.08;
      scaledMin -= padding;
      scaledMax += padding;
    }
    const range = scaledMax - scaledMin || 1;
    const ratio = (value: number) => (value / magnitude - scaledMin) / range;
    const y = (value: number) => PLOT_HEIGHT * (1 - ratio(value));
    const zero = Math.min(PLOT_HEIGHT, Math.max(0, y(0)));
    const zeroPercent = Math.min(100, Math.max(0, ratio(0) * 100));
    const count = chart.categories.length;
    const slot = PLOT_WIDTH / Math.max(count, 1);
    const groupWidth = slot * 0.72;
    const barWidth = groupWidth / Math.max(chart.series.length, 1);
    const series = chart.series.map((series, index): ChartSeries => {
      let path = '';
      let connected = false;
      const points: PlotPoint[] = [];
      const bars: PlotBar[] = [];
      chart.categories.forEach((category, categoryIndex) => {
        const value = series.values[categoryIndex];
        if (!finite(value)) {
          connected = false;
          return;
        }
        const pointX = count > 1 ? (categoryIndex * PLOT_WIDTH) / (count - 1) : PLOT_WIDTH / 2;
        const pointY = y(value);
        path += `${connected ? 'L' : 'M'}${pointX.toFixed(3)},${pointY.toFixed(3)} `;
        connected = true;
        // Keep isolated observations visible without covering dense lines in markers.
        if (
          count <= 20 ||
          !finite(series.values[categoryIndex - 1]) ||
          !finite(series.values[categoryIndex + 1])
        )
          points.push({ x: pointX, y: pointY, value, category });
        bars.push({
          x: categoryIndex * slot + (slot - groupWidth) / 2 + index * barWidth,
          y: Math.min(zero, pointY),
          width: Math.max(0.5, barWidth - Math.min(2, barWidth * 0.15)),
          height: Math.max(value === 0 ? 1 : 0.5, Math.abs(zero - pointY)),
          value,
          category,
        });
      });
      return {
        id: series.id,
        label: series.label,
        format: series.format,
        color: COLORS[index % COLORS.length],
        path: path.trim(),
        points,
        bars,
      };
    });
    const tickCount = Math.min(count, 4);
    const xIndices = [
      ...new Set(
        Array.from({ length: tickCount }, (_, i) =>
          tickCount === 1 ? 0 : Math.round((i * (count - 1)) / (tickCount - 1)),
        ),
      ),
    ];
    return {
      chart,
      series,
      zero,
      zeroPercent,
      format,
      hasValues: values.length > 0,
      mixedUnits: new Set(chart.series.map((item) => item.format)).size > 1,
      yTicks: Array.from({ length: 5 }, (_, index) => ({
        value: Math.max(
          -Number.MAX_VALUE,
          Math.min(Number.MAX_VALUE, (scaledMax - (range * index) / 4) * magnitude),
        ),
        top: index * 25,
      })),
      xTicks: xIndices.map((index, position) => ({
        label: this.categoryLabel(chart.categories[index]),
        left:
          chart.kind === 'bar'
            ? ((index + 0.5) * 100) / count
            : count > 1
              ? (index * 100) / (count - 1)
              : 50,
        first: (chart.kind === 'line' || count > tickCount) && position === 0 && count > 1,
        last:
          (chart.kind === 'line' || count > tickCount) &&
          position === xIndices.length - 1 &&
          count > 1,
      })),
      horizontal: chart.categories.map((label, categoryIndex) => ({
        label,
        values: chart.series.map((series, index) => {
          const raw = series.values[categoryIndex];
          const value = finite(raw) ? raw : null;
          const position = value === null ? zeroPercent : ratio(value) * 100;
          return {
            label: series.label,
            value,
            format: series.format,
            color: COLORS[index % COLORS.length],
            left: Math.min(position, zeroPercent),
            width: value === null ? 0 : Math.abs(position - zeroPercent),
          };
        }),
      })),
      description: `${chart.title}. ${chart.categories.length} categories, ${chart.series.length} series. Exact values are available in the chart data table. Missing values are not plotted.`,
    };
  }
}
