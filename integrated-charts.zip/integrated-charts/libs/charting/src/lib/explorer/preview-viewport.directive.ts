import { injectUiState } from '../core/state/index';
import {
  AfterViewInit,
  Directive,
  ElementRef,
  HostListener,
  OnDestroy,
  inject,
} from '@angular/core';

/** Keep heavyweight charts/grids mounted only near the library's scroll viewport. */
@Directive({ selector: '[appPreviewViewport]', standalone: true, exportAs: 'previewViewport' })
export class PreviewViewportDirective implements AfterViewInit, OnDestroy {
  private readonly reactiveState = injectUiState('PreviewViewportDirective');

  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef);
  private observer?: IntersectionObserver;
  private intersecting = false;
  readonly visible = this.reactiveState.signal(false);

  ngAfterViewInit(): void {
    this.observer = new IntersectionObserver(
      (entries) => {
        // A drawer can cross the viewport more than once before delivery. Use
        // its latest entry so an earlier hidden state cannot strand the preview.
        const entry = entries.filter((entry) => entry.target === this.host.nativeElement).at(-1);
        if (!entry) return;
        this.intersecting = entry.isIntersecting;
        this.update();
      },
      { root: this.host.nativeElement.closest('.library-examples'), rootMargin: '160px 0px' },
    );
    this.observer.observe(this.host.nativeElement);
  }

  @HostListener('focusin')
  update(): void {
    // Do not destroy a chart's controls while keyboard focus is inside the card.
    const visible = this.intersecting || this.host.nativeElement.contains(document.activeElement);
    if (!visible && this.visible()) {
      const preview = this.host.nativeElement.querySelector<HTMLElement>('.saved-preview');
      if (preview) preview.style.minHeight = `${preview.getBoundingClientRect().height}px`;
    }
    this.visible.set(visible);
  }

  @HostListener('focusout')
  releaseFocus(): void {
    queueMicrotask(() => this.update());
  }

  ngOnDestroy(): void {
    this.observer?.disconnect();
  }
}
