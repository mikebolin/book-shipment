import type { GridChatTurn } from '../core/domain/grid-copilot';
import { isOperationalAssistantMessage } from './grid-chat-context';

export interface PendingGridIntent {
  request: string;
  answers: { question: string; answer: string }[];
  question: string;
}

/** Pin the entire unresolved request, independent of how much chat history is visible. */
export function clarificationContext(pending: PendingGridIntent): GridChatTurn[] {
  const turns: GridChatTurn[] = [{ role: 'user', text: pending.request }];
  if (pending.answers.length) {
    let history = '';
    for (const pair of pending.answers) {
      // The original request and every user answer carry the decisions. Earlier
      // model questions are generated prose and can contain words the private
      // boundary cannot safely send back to the provider.
      const exchange = `answer: ${pair.answer}`;
      if (history && history.length + 1 + exchange.length > 4000) {
        turns.push({ role: 'user', text: history });
        history = '';
      }
      history += `${history ? '\n' : ''}${exchange}`;
    }
    if (history) turns.push({ role: 'user', text: history });
  }
  if (!isOperationalAssistantMessage(pending.question))
    turns.push({ role: 'assistant', text: pending.question });
  if (
    turns.length > 12 ||
    turns.some((turn) => turn.text.length > 4000) ||
    turns.reduce((length, turn) => length + turn.text.length, 0) > 16_000
  )
    throw new Error(
      'This request has reached the conversation limit. Start a different request and include your chosen details in one message. Your grid has not changed.',
    );
  return turns;
}
