type PreviewTask = { current: () => boolean; resolve: (current: boolean) => void };
const pending: PreviewTask[] = [];
let scheduled = false;

/** Spread chart construction across browser tasks so input can run between cards. */
export function chartPreviewTurn(current: () => boolean): Promise<boolean> {
  return new Promise((resolve) => {
    pending.push({ current, resolve });
    schedule();
  });
}

function schedule(): void {
  if (scheduled || !pending.length) return;
  scheduled = true;
  // A fresh task also lets chart/grid work queued by the preceding card settle.
  setTimeout(() => {
    if (typeof requestIdleCallback === 'function') requestIdleCallback(run, { timeout: 150 });
    else run();
  }, 16);
}

function run(): void {
  scheduled = false;
  let task: PreviewTask | undefined;
  while ((task = pending.shift())) {
    if (!task.current()) {
      task.resolve(false);
      continue;
    }
    task.resolve(true);
    break;
  }
  schedule();
}
