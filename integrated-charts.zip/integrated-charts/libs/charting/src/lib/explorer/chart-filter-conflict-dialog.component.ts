import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnDestroy,
  Output,
  ViewChild,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';

@Component({
  selector: 'app-chart-filter-conflict-dialog',
  standalone: true,
  imports: [MatButtonModule, MatIconModule, MatTooltipModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <dialog
      #dialog
      aria-labelledby="chart-filter-conflict-title"
      aria-describedby="chart-filter-conflict-description"
      (cancel)="$event.preventDefault(); decided.emit(false)"
    >
      <h2 id="chart-filter-conflict-title">Replace existing charts?</h2>
      <p id="chart-filter-conflict-description">
        This chart uses different filters. Saving it will update the grid filters and delete
        {{ count === 1 ? 'your existing chart' : 'all ' + count + ' existing charts' }}.
      </p>
      <p>Charts can be kept together only when they use the same filters.</p>
      <dl>
        <dt>Current filters</dt>
        <dd>{{ currentFilter || 'All records' }}</dd>
        <dt>New filters</dt>
        <dd>{{ nextFilter || 'All records' }}</dd>
      </dl>
      <footer>
        <button
          mat-icon-button
          type="button"
          autofocus
          (click)="decided.emit(false)"
          aria-label="Cancel"
          matTooltip="Cancel"
        >
          <mat-icon>close</mat-icon>
        </button>
        <button
          mat-icon-button
          class="replace"
          type="button"
          (click)="decided.emit(true)"
          aria-label="Delete charts and save"
          matTooltip="Delete charts and save"
        >
          <mat-icon>delete_outline</mat-icon>
        </button>
      </footer>
    </dialog>
  `,
  styles: [
    `
      dialog {
        width: min(560px, calc(100vw - 40px));
        max-height: calc(100dvh - 48px);
        box-sizing: border-box;
        overflow: auto;
        padding: 24px;
        border: 1px solid var(--mat-sys-outline-variant);
        border-radius: 16px;
        background: var(--mat-sys-surface-container-high);
        color: var(--mat-sys-on-surface);
        box-shadow: 0 12px 36px #0006;
      }
      dialog::backdrop {
        background: #0008;
      }
      h2 {
        margin: 0 0 16px;
        font-size: 20px;
      }
      p {
        line-height: 1.5;
      }
      dl {
        margin: 20px 0;
        padding: 16px;
        border: 1px solid var(--mat-sys-outline-variant);
        border-radius: 8px;
      }
      dt {
        margin-bottom: 6px;
        font-weight: 600;
      }
      dd {
        margin: 0 0 16px;
        overflow-wrap: anywhere;
        line-height: 1.5;
      }
      dd:last-child {
        margin-bottom: 0;
      }
      footer {
        display: flex;
        flex-wrap: wrap;
        justify-content: flex-end;
        gap: 8px;
      }
      .replace {
        --mdc-filled-button-container-color: var(--mat-sys-error);
        --mdc-filled-button-label-text-color: var(--mat-sys-on-error);
        background: var(--mat-sys-error);
        color: var(--mat-sys-on-error);
      }
    `,
  ],
})
export class ChartFilterConflictDialogComponent implements AfterViewInit, OnDestroy {
  @Input({ required: true }) count = 0;
  @Input({ required: true }) currentFilter = '';
  @Input({ required: true }) nextFilter = '';
  @Output() readonly decided = new EventEmitter<boolean>();
  @ViewChild('dialog', { static: true }) private dialog!: ElementRef<HTMLDialogElement>;
  private returnFocus: HTMLElement | null = null;

  ngAfterViewInit(): void {
    this.returnFocus = this.dialog.nativeElement.ownerDocument.activeElement as HTMLElement;
    this.dialog.nativeElement.showModal();
  }

  ngOnDestroy(): void {
    this.dialog.nativeElement.close();
    if (this.returnFocus?.isConnected) this.returnFocus.focus();
  }
}
