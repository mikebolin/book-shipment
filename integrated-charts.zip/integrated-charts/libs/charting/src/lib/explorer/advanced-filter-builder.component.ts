import { injectUiState } from '../core/state/index';
import { CommonModule, DOCUMENT } from '@angular/common';
import { LiveAnnouncer } from '@angular/cdk/a11y';
import { CdkDrag, CdkDragEnd, DragDropModule } from '@angular/cdk/drag-drop';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { Overlay, OverlayModule, OverlayRef } from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';
import {
  AfterViewInit,
  DoCheck,
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  HostListener,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  Output,
  ViewChild,
  ViewContainerRef,
  TemplateRef,
  SimpleChanges,
  inject,
  effect,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { provideNativeDateAdapter } from '@angular/material/core';
import type {
  AdvancedFilterModel,
  ColumnAdvancedFilterModel,
  JoinAdvancedFilterModel,
} from 'ag-grid-community';
import { operators, type ColumnSpec } from '../core/domain/schema';
import { EXPLORER_CONTEXT } from './explorer-context';
import {
  FilterColumnPickerComponent,
  type FilterColumnOrder,
} from './filter-column-picker.component';

const OPERATOR_LABELS: Record<string, string> = {
  equals: 'Equals',
  notEqual: 'Does not equal',
  contains: 'Contains',
  notContains: 'Does not contain',
  startsWith: 'Starts with',
  endsWith: 'Ends with',
  greaterThan: 'Greater than',
  greaterThanOrEqual: 'Greater than or equal',
  lessThan: 'Less than',
  lessThanOrEqual: 'Less than or equal',
  blank: 'Is blank',
  notBlank: 'Is not blank',
  inRange: 'Between',
  isAnyOf: 'Is any of',
  isNoneOf: 'Is none of',
  true: 'Is true',
  false: 'Is false',
};
export interface FilterDraftChange {
  model: AdvancedFilterModel | null;
  valid: boolean;
  message: string;
}
let nextBuilderId = 0;

function filterModelKey(model: AdvancedFilterModel | null): string {
  return JSON.stringify(model, (_key, value) =>
    value && typeof value === 'object' && !Array.isArray(value)
      ? Object.fromEntries(Object.entries(value).sort(([a], [b]) => a.localeCompare(b)))
      : value,
  );
}

/** Edits only a private copy; the public AG Grid model is published on Apply. */
@Component({
  selector: 'app-advanced-filter-builder',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    FilterColumnPickerComponent,
    MatButtonModule,
    OverlayModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatSelectModule,
    MatMenuModule,
    MatTooltipModule,
    MatDatepickerModule,
    DragDropModule,
    ScrollingModule,
  ],
  providers: [provideNativeDateAdapter()],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './advanced-filter-builder.component.html',
  styleUrl: './advanced-filter-builder.component.scss',
  host: {
    '[class.embedded-builder]': 'embedded',
    '[class.inline-builder]': 'embedded && inline',
  },
})
export class AdvancedFilterBuilderComponent
  implements OnInit, OnChanges, AfterViewInit, OnDestroy, DoCheck
{
  private readonly reactiveState = injectUiState('AdvancedFilterBuilderComponent');

  @Input() columns: readonly ColumnSpec[] = [];
  @Input() model: AdvancedFilterModel | null = null;
  @Input() resetRevision = 0;
  @Input() title = 'Filter your data';
  @Input() applyLabel = 'Apply filters';
  @Input() resetLabel = 'Clear all';
  @Input() embedded = false;
  /** Header editors grow with their contents; AG Grid drawers fill a fixed-height panel. */
  @Input() inline = false;
  @Input() disabled = false;
  /** Saved filters remain inspectable without exposing editing controls. */
  @Input() readOnly = false;
  @Input() dialogMode = false;
  @Output() readonly draftChange = new EventEmitter<FilterDraftChange>();
  private lastDraftKey = '';
  ngDoCheck(): void {
    const key = JSON.stringify(this.root);
    if (key === this.lastDraftKey) return;
    this.lastDraftKey = key;
    const message = this.validationMessage;
    const change = { model: structuredClone(this.draftModel()), valid: !message, message };
    queueMicrotask(() => {
      if (!this.destroyed) this.draftChange.emit(change);
    });
  }
  @Output() readonly applied = new EventEmitter<AdvancedFilterModel | null>();
  @Output() readonly closed = new EventEmitter<void>();
  @Output() readonly cleared = new EventEmitter<void>();
  @ViewChild('dialog', { static: true }) private dialog!: TemplateRef<unknown>;
  private readonly overlays = inject(Overlay);
  private readonly viewContainer = inject(ViewContainerRef);
  private readonly explorerContext = inject(EXPLORER_CONTEXT);
  private readonly document = inject(DOCUMENT);
  private readonly announcer = inject(LiveAnnouncer);
  private overlayRef?: OverlayRef;
  private panelPortal?: TemplatePortal;
  private destroyed = false;
  private panelDrag?: CdkDrag;
  private previousFocus?: HTMLElement;
  private readonly minimizedState = this.reactiveState.signal(false);
  get minimized() {
    return this.minimizedState();
  }
  set minimized(value) {
    this.minimizedState.set(value);
  }
  root: JoinAdvancedFilterModel = { filterType: 'join', type: 'AND', conditions: [] };
  private readonly columnOrderState = this.reactiveState.signal<FilterColumnOrder>('az');
  get columnOrder() {
    return this.columnOrderState();
  }
  set columnOrder(value) {
    this.columnOrderState.set(value);
  }
  private preserveRoot = false;
  private appliedModelKey = 'null';
  private readonly builderId = ++nextBuilderId;
  private readonly nodeIds = new WeakMap<AdvancedFilterModel, number>();
  private collapsedNodes = new WeakSet<JoinAdvancedFilterModel>();
  private nextNodeId = 0;
  private readonly dateDrafts = new WeakMap<
    ColumnAdvancedFilterModel,
    { from: Date | null; to: Date | null }
  >();

  constructor() {
    effect(() => {
      const active = this.explorerContext.isActive?.() ?? true;
      if (!this.overlayRef || !this.panelPortal) return;
      if (active && !this.overlayRef.hasAttached()) {
        this.overlayRef.attach(this.panelPortal);
        this.resizePanel();
      } else if (!active && this.overlayRef.hasAttached()) {
        // Tabs preserve their filter drafts, but never leave a floating panel on another source.
        this.overlayRef.detach();
        this.panelDrag = undefined;
      }
    });
  }

  ngOnInit(): void {
    this.resetDraft();
  }
  ngOnChanges(changes: SimpleChanges): void {
    // Initial inputs are cloned once in ngOnInit. A later authoritative filter
    // replaces the draft; merely hiding the retained tool panel does not.
    if (
      (changes['model'] && !changes['model'].firstChange) ||
      (changes['resetRevision'] && !changes['resetRevision'].firstChange)
    )
      this.resetDraft();
  }
  private resetDraft(): void {
    this.collapsedNodes = new WeakSet();
    const model = this.model ? structuredClone(this.model) : null;
    this.appliedModelKey = filterModelKey(model);
    this.preserveRoot = model?.filterType === 'join';
    this.root =
      model?.filterType === 'join'
        ? model
        : { filterType: 'join', type: 'AND', conditions: model ? [model] : [] };
    this.collapsedNodes = new WeakSet(this.draftGroups());
  }
  ngAfterViewInit(): void {
    if (this.embedded) {
      if (this.inline) {
        this.document.defaultView?.requestAnimationFrame(() => {
          if (!this.destroyed) {
            // The editor can open below the visible part of a scrolled chart guide.
            // Reveal its controls without focusing an input or opening a phone keyboard.
            this.viewContainer.element.nativeElement
              .querySelector('.filter-dialog')
              ?.scrollIntoView({ block: 'nearest', inline: 'nearest' });
          }
        });
      }
      return;
    }
    this.previousFocus = this.document.activeElement as HTMLElement;
    // A modeless overlay keeps grid navigation, copying and scrolling available.
    // Material dialogs always install a focus trap, even without their backdrop.
    this.overlayRef = this.overlays.create({
      hasBackdrop: false,
      usePopover: false,
      scrollStrategy: this.overlays.scrollStrategies.noop(),
      panelClass: 'advanced-filter-panel',
      positionStrategy: this.overlays.position().global().right('16px').top('88px'),
      width: '820px',
      maxWidth: 'calc(100vw - 16px)',
      eventPredicate: (event) =>
        !!this.overlayRef?.overlayElement.contains(event.target as globalThis.Node),
    });
    this.panelPortal = new TemplatePortal(this.dialog, this.viewContainer);
    if (this.explorerContext.isActive?.() ?? true) {
      this.overlayRef.attach(this.panelPortal);
      this.resizePanel();
      this.overlayRef.overlayElement.querySelector<HTMLButtonElement>('.builder-close')?.focus();
    }
    this.overlayRef.keydownEvents().subscribe((event) => {
      if (event.key !== 'Escape' || event.defaultPrevented) return;
      event.preventDefault();
      this.closed.emit();
    });
  }
  ngOnDestroy(): void {
    this.destroyed = true;
    const restoreFocus = this.overlayRef?.overlayElement.contains(this.document.activeElement);
    this.overlayRef?.dispose();
    if (restoreFocus && this.previousFocus?.isConnected) this.previousFocus.focus();
  }
  @HostListener('window:resize')
  resizePanel(): void {
    if (!this.overlayRef) return;
    const narrow = (this.document.defaultView?.innerWidth ?? 1024) <= 600;
    this.panelDrag?.reset();
    this.overlayRef.updatePositionStrategy(
      this.overlays
        .position()
        .global()
        .right(narrow ? '8px' : '16px')
        .top(narrow ? '72px' : '88px'),
    );
  }
  rememberPanelPosition(event: CdkDragEnd): void {
    this.panelDrag = event.source;
  }
  movePanel(event: KeyboardEvent, drag: CdkDrag): void {
    if (this.embedded) return;
    const delta = event.shiftKey ? 48 : 16;
    const direction: Record<string, { x: number; y: number }> = {
      ArrowLeft: { x: -delta, y: 0 },
      ArrowRight: { x: delta, y: 0 },
      ArrowUp: { x: 0, y: -delta },
      ArrowDown: { x: 0, y: delta },
    };
    const move = direction[event.key];
    if (!move) return;
    event.preventDefault();
    const rect = drag.getRootElement().getBoundingClientRect();
    const viewport = this.document.documentElement;
    const current = drag.getFreeDragPosition();
    drag.setFreeDragPosition({
      x:
        current.x +
        Math.max(8 - rect.left, Math.min(move.x, viewport.clientWidth - rect.right - 8)),
      y:
        current.y +
        Math.max(8 - rect.top, Math.min(move.y, viewport.clientHeight - rect.bottom - 8)),
    });
    this.panelDrag = drag;
  }
  toggleMinimized(): void {
    if (this.embedded) return;
    this.minimized = !this.minimized;
    // Expanding after moving a collapsed panel must keep every control in view.
    if (!this.minimized) this.resizePanel();
  }
  get conditionCount(): number {
    const count = (node: AdvancedFilterModel): number =>
      node.filterType === 'join'
        ? node.conditions.reduce((sum, child) => sum + count(child), 0)
        : 1;
    return count(this.root);
  }
  isCollapsed(node: JoinAdvancedFilterModel): boolean {
    return this.collapsedNodes.has(node);
  }
  private draftGroups(): JoinAdvancedFilterModel[] {
    const nodes: JoinAdvancedFilterModel[] = [];
    const visit = (group: JoinAdvancedFilterModel): void => {
      for (const node of group.conditions) {
        if (node.filterType === 'join') {
          nodes.push(node);
          visit(node);
        }
      }
    };
    visit(this.root);
    return nodes;
  }
  get allCollapsed(): boolean {
    const nodes = this.draftGroups();
    return nodes.length > 0 && nodes.every((node) => this.isCollapsed(node));
  }
  get groupCount(): number {
    return this.draftGroups().length;
  }
  toggleCollapsed(node: JoinAdvancedFilterModel): void {
    if (this.disabled) return;
    this.isCollapsed(node) ? this.collapsedNodes.delete(node) : this.collapsedNodes.add(node);
  }
  toggleAllCollapsed(): void {
    if (this.disabled || !this.groupCount) return;
    const expand = this.allCollapsed;
    this.collapsedNodes = new WeakSet(expand ? [] : this.draftGroups());
    void this.announcer.announce(`All filter groups ${expand ? 'expanded' : 'collapsed'}.`);
  }
  conditionSummary(node: ColumnAdvancedFilterModel): string {
    if (!node.colId) return 'Choose a column';
    const operator = OPERATOR_LABELS[node.type] ?? node.type;
    const display = (value: unknown): string =>
      value === null
        ? '(Blank)'
        : value === undefined || value === ''
          ? 'Enter a value'
          : String(value);
    if (node.filterType === 'set') {
      const values = (node.values ?? []).map(display);
      return `${operator}: ${values.slice(0, 3).join(', ') || 'Choose values'}${values.length > 3 ? ` +${values.length - 3} more` : ''}`;
    }
    if (!this.takesValue(node)) return operator;
    return `${operator} ${display(node.filter)}${node.type === 'inRange' ? ` and ${display(node.filterTo)}` : ''}`;
  }
  groupSummary(group: JoinAdvancedFilterModel): string {
    const names: string[] = [];
    let count = 0;
    const visit = (node: AdvancedFilterModel): void => {
      if (node.filterType === 'join') node.conditions.forEach(visit);
      else {
        count++;
        const name = this.nodeLabel(node);
        if (!names.includes(name) && names.length < 2) names.push(name);
      }
    };
    visit(group);
    return `${count} ${count === 1 ? 'filter' : 'filters'}${names.length ? ' · ' + names.join(', ') : ''}`;
  }
  groupLogic(group: JoinAdvancedFilterModel): string {
    return group.type === 'AND' ? 'All filters (AND)' : 'Any filter (OR)';
  }
  private expandToGroup(target: JoinAdvancedFilterModel): void {
    const visit = (group: JoinAdvancedFilterModel): boolean => {
      if (
        group === target ||
        group.conditions.some((node) => node.filterType === 'join' && visit(node))
      ) {
        this.collapsedNodes.delete(group);
        return true;
      }
      return false;
    };
    visit(this.root);
  }
  isDate(node: ColumnAdvancedFilterModel): boolean {
    return node.filterType === 'date' || node.filterType === 'dateString';
  }
  dateDraft(node: ColumnAdvancedFilterModel): { from: Date | null; to: Date | null } {
    const existing = this.dateDrafts.get(node);
    if (existing) return existing;
    const parse = (value: unknown): Date | null => {
      const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(value ?? ''));
      if (!match) return null;
      const date = new Date(0);
      date.setFullYear(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
      date.setHours(0, 0, 0, 0);
      return date.getMonth() === Number(match[2]) - 1 && date.getDate() === Number(match[3])
        ? date
        : null;
    };
    const draft = {
      from: node.filterType === 'set' ? null : parse(node.filter),
      to: node.filterType === 'set' ? null : parse(node.filterTo),
    };
    this.dateDrafts.set(node, draft);
    return draft;
  }
  setDateValue(node: ColumnAdvancedFilterModel, date: Date | null, end = false): void {
    if (this.disabled || this.readOnly) return;
    if (node.filterType !== 'date' && node.filterType !== 'dateString') return;
    // Calendar dates stay in local YYYY-MM-DD form; UTC conversion would shift some timezones.
    const value =
      date && !Number.isNaN(date.getTime())
        ? [
            String(date.getFullYear()).padStart(4, '0'),
            String(date.getMonth() + 1).padStart(2, '0'),
            String(date.getDate()).padStart(2, '0'),
          ].join('-')
        : '';
    if (end) node.filterTo = value;
    else node.filter = value;
  }
  reset(): void {
    if (this.disabled || this.readOnly) return;
    this.root = { filterType: 'join', type: 'AND', conditions: [] };
    this.preserveRoot = false;
    this.collapsedNodes = new WeakSet();
    this.cleared.emit();
  }
  addCondition(group: JoinAdvancedFilterModel): void {
    if (this.disabled || this.readOnly) return;
    this.expandToGroup(group);
    group.conditions.push({ filterType: 'text', colId: '', type: 'equals', filter: '' });
  }
  addGroup(group: JoinAdvancedFilterModel): void {
    if (this.disabled || this.readOnly) return;
    this.expandToGroup(group);
    group.conditions.push({
      filterType: 'join',
      type: 'AND',
      conditions: [{ filterType: 'text', colId: '', type: 'equals', filter: '' }],
    });
  }
  nodeId(node: AdvancedFilterModel): string {
    if (!this.nodeIds.has(node)) this.nodeIds.set(node, ++this.nextNodeId);
    return `filter-${this.builderId}-node-${this.nodeIds.get(node)}`;
  }
  dropListId(group: JoinAdvancedFilterModel): string {
    return `${this.nodeId(group)}-list`;
  }
  private groups(): { group: JoinAdvancedFilterModel; label: string; depth: number }[] {
    const result: { group: JoinAdvancedFilterModel; label: string; depth: number }[] = [];
    const visit = (group: JoinAdvancedFilterModel, path: number[]): void => {
      result.push({
        group,
        label: path.length ? `Group ${path.join('.')}` : 'All filters',
        depth: path.length,
      });
      let groupIndex = 0;
      for (const node of group.conditions)
        if (node.filterType === 'join') visit(node, [...path, ++groupIndex]);
    };
    visit(this.root, []);
    return result;
  }
  groupLabel(group: JoinAdvancedFilterModel): string {
    return this.groups().find((entry) => entry.group === group)?.label ?? 'Group';
  }
  nodeLabel(node: AdvancedFilterModel): string {
    return node.filterType === 'join'
      ? this.groupLabel(node)
      : (this.columns.find((column) => column.id === node.colId)?.label ?? 'Condition');
  }
  moveTargets(node: AdvancedFilterModel | undefined, source: JoinAdvancedFilterModel) {
    if (!node) return [];
    return this.groups().filter(
      (entry) => entry.group !== source && !this.containsGroup(node, entry.group),
    );
  }
  private containsGroup(node: AdvancedFilterModel, target: JoinAdvancedFilterModel): boolean {
    return (
      node === target ||
      (node.filterType === 'join' &&
        node.conditions.some((child) => this.containsGroup(child, target)))
    );
  }
  moveToGroup(
    source: JoinAdvancedFilterModel,
    node: AdvancedFilterModel,
    target: JoinAdvancedFilterModel,
    index = target.conditions.length,
    restoreFocus = true,
  ): void {
    if (this.disabled || this.readOnly) return;
    const sourceIndex = source.conditions.indexOf(node);
    if (sourceIndex < 0 || source === target || this.containsGroup(node, target)) return;
    if (!this.groups().some((entry) => entry.group === target)) return;
    source.conditions.splice(sourceIndex, 1);
    target.conditions.splice(Math.max(0, Math.min(index, target.conditions.length)), 0, node);
    this.expandToGroup(target);
    this.announceMove(node, target);
    if (restoreFocus)
      this.document.defaultView?.requestAnimationFrame(() => {
        if (!this.destroyed)
          this.document
            .getElementById(this.nodeId(node))
            ?.querySelector<HTMLElement>('.condition-actions')
            ?.focus();
      });
  }
  private announceMove(node: AdvancedFilterModel, group: JoinAdvancedFilterModel): void {
    void this.announcer.announce(
      `${this.nodeLabel(node)} moved to ${this.groupLabel(group)}, position ${group.conditions.indexOf(node) + 1} of ${group.conditions.length}.`,
    );
  }
  move(group: JoinAdvancedFilterModel, index: number, offset: number): void {
    if (this.disabled || this.readOnly) return;
    if (
      index < 0 ||
      index >= group.conditions.length ||
      index + offset < 0 ||
      index + offset >= group.conditions.length
    )
      return;
    const [node] = group.conditions.splice(index, 1);
    group.conditions.splice(index + offset, 0, node);
    this.announceMove(node, group);
  }
  changeColumn(group: JoinAdvancedFilterModel, index: number, id: string): void {
    if (this.disabled || this.readOnly) return;
    const column = this.columns.find((candidate) => candidate.id === id);
    if (!column) return;
    const current = group.conditions[index];
    if (current?.filterType !== 'join' && current.colId === id) return;
    group.conditions[index] = {
      filterType:
        column.kind === 'date'
          ? 'dateString'
          : column.kind === 'datetime'
            ? 'dateTimeString'
            : column.kind,
      colId: id,
      type: 'equals',
    };
  }
  operatorOptions(node: ColumnAdvancedFilterModel): { value: string; label: string }[] {
    const column = this.columns.find((candidate) => candidate.id === node.colId);
    const options: string[] =
      node.filterType === 'set' ? ['isAnyOf', 'isNoneOf'] : column ? operators(column) : ['equals'];
    if (!options.includes(node.type)) options.push(node.type);
    const dateLabels: Record<string, string> =
      column?.kind === 'date' || column?.kind === 'datetime'
        ? {
            equals: 'On',
            notEqual: 'Not on',
            greaterThan: 'After',
            greaterThanOrEqual: 'On or after',
            lessThan: 'Before',
            lessThanOrEqual: 'On or before',
          }
        : {};
    return options.map((value) => ({
      value,
      label: dateLabels[value] ?? OPERATOR_LABELS[value] ?? value,
    }));
  }
  changeOperator(node: ColumnAdvancedFilterModel, value: string): void {
    if (this.disabled || this.readOnly) return;
    node.type = value as ColumnAdvancedFilterModel['type'];
    if (node.filterType !== 'set' && !this.takesValue(node)) {
      delete node.filter;
      delete node.filterTo;
      this.dateDrafts.delete(node);
    }
  }
  takesValue(node: ColumnAdvancedFilterModel): boolean {
    return (
      !['blank', 'notBlank', 'true', 'false'].includes(node.type) &&
      !/^(last|this|next|today|yesterday|tomorrow)/i.test(node.type)
    );
  }
  inputType(node: ColumnAdvancedFilterModel): string {
    return node.filterType === 'number'
      ? 'number'
      : ['date', 'dateString'].includes(node.filterType)
        ? 'date'
        : 'text';
  }
  valueHint(node: ColumnAdvancedFilterModel): string {
    return ['dateTime', 'dateTimeString'].includes(node.filterType)
      ? 'YYYY-MM-DDTHH:mm:ssZ'
      : 'Value';
  }
  setValues(node: Extract<ColumnAdvancedFilterModel, { filterType: 'set' }>): (string | null)[] {
    const column = this.columns.find((candidate) => candidate.id === node.colId);
    return [
      ...new Set([
        ...(column?.values ?? []),
        ...(node.values ?? []),
        ...(column?.nullable ? [null] : []),
      ]),
    ];
  }
  get validationMessage(): string {
    return this.root.conditions.map((node) => this.nodeValidation(node)).find(Boolean) ?? '';
  }
  setInputValue(node: ColumnAdvancedFilterModel, value: string | number | null, end = false): void {
    if (this.disabled || this.readOnly) return;
    // A dynamic input type uses Angular's text accessor. Keep numeric models numeric.
    if (!('colId' in node) || node.filterType === 'set' || node.filterType === 'boolean') return;
    const normalized =
      node.filterType === 'number'
        ? value === '' || value == null
          ? undefined
          : Number(value)
        : (value ?? undefined);
    if (end) (node as { filterTo?: string | number }).filterTo = normalized;
    else (node as { filter?: string | number }).filter = normalized;
  }
  private draftModel(): AdvancedFilterModel | null {
    return !this.root.conditions.length
      ? null
      : !this.preserveRoot && this.root.conditions.length === 1
        ? this.root.conditions[0]
        : this.root;
  }
  get hasChanges(): boolean {
    return filterModelKey(this.draftModel()) !== this.appliedModelKey;
  }
  nodeValidation(node: AdvancedFilterModel): string {
    if (node.filterType === 'join')
      return !node.conditions.length
        ? 'Add a condition to each nested group, or remove the empty group.'
        : (node.conditions.map((child) => this.nodeValidation(child)).find(Boolean) ?? '');
    if (!this.columns.some((column) => column.id === node.colId))
      return 'Choose a column for each condition.';
    if (node.filterType === 'set') return node.values?.length ? '' : 'Select at least one value.';
    if (!this.takesValue(node)) return '';
    const values = node.type === 'inRange' ? [node.filter, node.filterTo] : [node.filter];
    if (values.some((value) => value == null || value === ''))
      return 'Enter a value for each condition.';
    if (node.filterType === 'number' && values.some((value) => !Number.isFinite(Number(value))))
      return 'Enter a finite number.';
    if (
      ['date', 'dateString', 'dateTime', 'dateTimeString'].includes(node.filterType) &&
      values.some((value) => Number.isNaN(Date.parse(String(value))))
    )
      return 'Enter a valid date or timestamp.';
    return '';
  }
  apply(): void {
    if (this.disabled || this.readOnly || this.validationMessage || !this.hasChanges) return;
    const model = this.draftModel();
    this.applied.emit(model ? structuredClone(model) : null);
  }
}
