/** The small part of AG Grid's client-side API needed by the stream writer. */
export interface AsyncGridStreamApi<Row> {
  applyTransactionAsync(
    transaction: { add: Row[] },
    callback: (result: { add?: Array<{ data?: Row }> } | null | undefined) => void,
  ): void;
  flushAsyncTransactions(): void;
  isDestroyed?(): boolean;
}

export interface AsyncGridStreamStats {
  submittedRows: number;
  appliedRows: number;
  transactions: number;
  /** Includes the transaction already submitted to AG Grid. */
  queuedRows: number;
  peakQueuedRows: number;
  elapsedMs: number;
  firstAppliedMs: number | null;
  transactionRows: number;
  /** Includes AG Grid's configured asynchronous transaction wait. */
  durationMs: number;
  totalTransactionMs: number;
  maxTransactionMs: number;
}

export interface AsyncGridStreamOptions<Row> {
  api: AsyncGridStreamApi<Row>;
  signal?: AbortSignal;
  getRowId?: (row: Row) => string | number;
  transactionRows?: number;
  maxQueuedRows?: number;
  batchDelayMs?: number;
  callbackTimeoutMs?: number;
  onApplied?: (stats: AsyncGridStreamStats) => void;
}

export interface AsyncGridStream<Row> {
  /** Await each push to keep the producer under the configured backpressure bound. */
  push(rows: readonly Row[]): Promise<void>;
  finish(): Promise<void>;
  abort(reason?: unknown): void;
  readonly stats: AsyncGridStreamStats;
}

/**
 * Coalesces wire batches into ordered, bounded AG Grid async transactions.
 * Abort stops future submissions and ignores callbacks. AG Grid cannot cancel an
 * already submitted transaction: the owner must destroy that grid, or flush its
 * pending transactions after abort and before clearing/reusing its row data.
 */
export function createAsyncGridStream<Row>(
  options: AsyncGridStreamOptions<Row>,
): AsyncGridStream<Row> {
  const {
    api,
    signal,
    getRowId,
    transactionRows = 1_000,
    maxQueuedRows = 2_000,
    batchDelayMs = 8,
    callbackTimeoutMs = 10_000,
    onApplied,
  } = options;
  if (
    !Number.isSafeInteger(transactionRows) ||
    transactionRows < 1 ||
    !Number.isSafeInteger(maxQueuedRows) ||
    maxQueuedRows < transactionRows ||
    !Number.isFinite(batchDelayMs) ||
    batchDelayMs < 0 ||
    !Number.isFinite(callbackTimeoutMs) ||
    callbackTimeoutMs <= 0
  ) {
    throw new Error('Invalid async grid stream batch or timeout options.');
  }

  const startedAt = performance.now();
  const queue: Row[] = [];
  const waiters = new Set<() => void>();
  const metrics: AsyncGridStreamStats = {
    submittedRows: 0,
    appliedRows: 0,
    transactions: 0,
    queuedRows: 0,
    peakQueuedRows: 0,
    elapsedMs: 0,
    firstAppliedMs: null,
    transactionRows: 0,
    durationMs: 0,
    totalTransactionMs: 0,
    maxTransactionMs: 0,
  };
  let active: { rows: Row[]; startedAt: number } | undefined;
  let batchTimer: ReturnType<typeof setTimeout> | undefined;
  let callbackTimer: ReturnType<typeof setTimeout> | undefined;
  let failure: Error | undefined;
  let closing = false;
  let finished = false;
  let pushes: Promise<void> = Promise.resolve();
  let completion: Promise<void> | undefined;

  const queuedRows = (): number => queue.length + (active?.rows.length ?? 0);
  const stats = (): AsyncGridStreamStats => ({
    ...metrics,
    queuedRows: queuedRows(),
    elapsedMs: performance.now() - startedAt,
  });
  const notify = (): void => {
    for (const resolve of waiters) resolve();
    waiters.clear();
  };
  const changed = (): Promise<void> => new Promise((resolve) => waiters.add(resolve));
  const cancelTimers = (): void => {
    clearTimeout(batchTimer);
    clearTimeout(callbackTimer);
    batchTimer = undefined;
    callbackTimer = undefined;
  };
  const fail = (reason: unknown): void => {
    if (failure || finished) return;
    failure = reason instanceof Error ? reason : new Error(String(reason));
    cancelTimers();
    queue.length = 0;
    active = undefined;
    signal?.removeEventListener('abort', onAbort);
    notify();
  };
  const onAbort = (): void => fail(signal?.reason ?? new DOMException('Aborted', 'AbortError'));
  const ensureActive = (): void => {
    if (!failure && api.isDestroyed?.())
      fail(new Error('The grid was destroyed during streaming.'));
    if (failure) throw failure;
  };

  const flush = (): void => {
    try {
      ensureActive();
      api.flushAsyncTransactions();
    } catch (error) {
      fail(error);
    }
  };
  const submit = (): void => {
    clearTimeout(batchTimer);
    batchTimer = undefined;
    if (failure || finished || active || !queue.length) return;
    try {
      ensureActive();
      const transaction = {
        rows: queue.splice(0, transactionRows),
        startedAt: performance.now(),
      };
      active = transaction;
      metrics.submittedRows += transaction.rows.length;
      callbackTimer = setTimeout(() => {
        fail(
          new Error(
            api.isDestroyed?.()
              ? 'The grid was destroyed during streaming.'
              : 'The grid did not acknowledge its streamed rows in time.',
          ),
        );
      }, callbackTimeoutMs);
      api.applyTransactionAsync({ add: transaction.rows }, (result) => {
        // Late or duplicate callbacks must never publish progress for another transaction.
        if (failure || finished || active !== transaction) return;
        clearTimeout(callbackTimer);
        callbackTimer = undefined;
        try {
          ensureActive();
          if (
            result?.add?.length !== transaction.rows.length ||
            (getRowId &&
              result.add.some(
                (node, index) =>
                  node.data === undefined ||
                  getRowId(node.data) !== getRowId(transaction.rows[index]),
              ))
          ) {
            throw new Error('The grid did not apply the expected streamed rows.');
          }
          active = undefined;
          const durationMs = performance.now() - transaction.startedAt;
          metrics.appliedRows += transaction.rows.length;
          metrics.transactions++;
          metrics.firstAppliedMs ??= performance.now() - startedAt;
          metrics.transactionRows = transaction.rows.length;
          metrics.durationMs = durationMs;
          metrics.totalTransactionMs += durationMs;
          metrics.maxTransactionMs = Math.max(metrics.maxTransactionMs, durationMs);
          onApplied?.(stats());
          notify();
          schedule();
        } catch (error) {
          fail(error);
        }
      });
      if (closing && active === transaction) flush();
    } catch (error) {
      fail(error);
    }
  };
  const schedule = (): void => {
    if (failure || finished || active || !queue.length) return;
    if (closing || queue.length >= transactionRows) submit();
    else if (batchTimer === undefined) batchTimer = setTimeout(submit, batchDelayMs);
  };

  signal?.addEventListener('abort', onAbort, { once: true });
  if (signal?.aborted) onAbort();

  return {
    get stats() {
      return stats();
    },
    push(rows) {
      if (closing || finished)
        return Promise.reject(new Error('The grid stream is already closing.'));
      // Serialize producers too, so a large push cannot be overtaken while awaiting capacity.
      const result = pushes.then(async () => {
        try {
          ensureActive();
          let offset = 0;
          while (offset < rows.length) {
            ensureActive();
            const count = Math.min(maxQueuedRows - queuedRows(), rows.length - offset);
            if (count > 0) {
              queue.push(...rows.slice(offset, offset + count));
              offset += count;
              metrics.peakQueuedRows = Math.max(metrics.peakQueuedRows, queuedRows());
              schedule();
              ensureActive();
            }
            if (offset < rows.length && queuedRows() >= maxQueuedRows) await changed();
          }
        } catch (error) {
          fail(error);
          throw error;
        }
      });
      pushes = result.catch(() => {});
      return result;
    },
    finish() {
      if (completion) return completion;
      closing = true;
      schedule();
      if (active) flush();
      completion = (async () => {
        await pushes;
        ensureActive();
        schedule();
        while (queuedRows()) {
          await changed();
          ensureActive();
        }
        finished = true;
        cancelTimers();
        signal?.removeEventListener('abort', onAbort);
      })();
      return completion;
    },
    abort(reason = new DOMException('Aborted', 'AbortError')) {
      fail(reason);
    },
  };
}
