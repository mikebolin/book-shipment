import { injectUiState } from '../core/state/index';
import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  Injector,
  Input,
  OnDestroy,
  WritableSignal,
  inject,
} from '@angular/core';
import { DecimalPipe, NgComponentOutlet } from '@angular/common';
import { MatTabsModule } from '@angular/material/tabs';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import { AppComponent } from './app.component';
import { EXPLORER_CONTEXT, type ExplorerContext, type ExplorerSource } from './explorer-context';

interface ExplorerTab extends ExplorerSource {
  key: string;
  injector: Injector;
  active: WritableSignal<boolean>;
  recordCount: WritableSignal<number | null>;
  close: () => void;
}

/** Preserve each explorer while excluding hidden templates from Angular render work. */
@Component({
  selector: 'app-explorer-tab',
  standalone: true,
  imports: [NgComponentOutlet],
  template: `<ng-container *ngComponentOutlet="explorerComponent; injector: injector" />`,
  styles: `
    :host {
      display: block;
      height: 100%;
      min-height: 0;
    }
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExplorerTabComponent {
  private readonly changeDetector = inject(ChangeDetectorRef);
  readonly explorerComponent = AppComponent;
  @Input({ required: true }) injector!: Injector;

  // Input setters run from the parent view even when this child's view is detached.
  @Input({ required: true }) set active(active: boolean) {
    if (active) {
      this.changeDetector.reattach();
      this.changeDetector.markForCheck();
    } else {
      this.changeDetector.detach();
    }
  }
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    ExplorerTabComponent,
    DecimalPipe,
    MatTabsModule,
    MatIconModule,
    MatButtonModule,
    MatTooltipModule,
  ],
  template: `
    <mat-tab-group
      class="explorer-workspace"
      [class.single-explorer]="tabs().length === 1"
      [selectedIndex]="selectedIndex()"
      (selectedIndexChange)="selectTab($event)"
      [preserveContent]="true"
      [animationDuration]="'0ms'"
      [mat-stretch-tabs]="false"
      aria-label="Data explorers"
    >
      @for (tab of tabs(); track tab.key) {
        <mat-tab>
          <ng-template mat-tab-label>
            <mat-icon class="explorer-tab-icon" aria-hidden="true">table_chart</mat-icon>
            <span class="explorer-tab-caption">
              <span class="explorer-tab-name" [matTooltip]="tab.label">{{ tab.label }}</span>
              <span class="explorer-tab-records">
                @if (tab.recordCount() !== null) {
                  {{ tab.recordCount() | number }} records
                } @else {
                  — records
                }
              </span>
            </span>
            @if (tabs().length > 1) {
              <button
                mat-icon-button
                type="button"
                class="close-explorer-tab"
                [attr.aria-label]="'Close ' + tab.label + ' explorer'"
                (keydown)="$event.stopPropagation()"
                (click)="$event.stopPropagation(); closeTab(tab.key)"
              >
                <mat-icon aria-hidden="true">close</mat-icon>
              </button>
            }
          </ng-template>
          <ng-template matTabContent>
            <app-explorer-tab [injector]="tab.injector" [active]="tab.active()" />
          </ng-template>
        </mat-tab>
      }
    </mat-tab-group>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExplorerWorkspaceComponent implements OnDestroy {
  private readonly reactiveState = injectUiState('ExplorerWorkspaceComponent');

  private readonly injector = inject(Injector);
  readonly tabs = this.reactiveState.signal<ExplorerTab[]>([]);
  readonly selectedIndex = this.reactiveState.signal(0);

  constructor() {
    this.openTab({ id: 'local_unconfigured', label: 'Data' });
  }

  selectTab(index: number): void {
    const tabs = this.tabs();
    const selected = tabs[index];
    if (!selected) return;
    this.selectedIndex.set(index);
    for (const tab of tabs) tab.active.set(tab.key === selected.key);
  }

  private activateExisting(source: ExplorerSource['id'], except?: string): boolean {
    const index = this.tabs().findIndex((tab) => tab.id === source && tab.key !== except);
    if (index < 0) return false;
    this.selectTab(index);
    return true;
  }

  openTab(source: ExplorerSource): void {
    if (this.activateExisting(source.id)) return;
    const key = `explorer-${crypto.randomUUID()}`;
    const active = this.reactiveState.signal(false);
    const recordCount = this.reactiveState.signal<number | null>(null);
    let open = true;
    let sourceId = source.id;
    const context: ExplorerContext = {
      id: key,
      initialSource: source.id,
      dataset: source.dataset,
      capabilities: source.capabilities ? { ...source.capabilities } : undefined,
      sourceChanged: (next) => {
        if (!open) return;
        if (next.id !== sourceId) recordCount.set(null);
        sourceId = next.id;
        this.tabs.update((tabs) =>
          tabs.map((tab) => (tab.key === key ? { ...tab, ...next } : tab)),
        );
      },
      // A deferred import from a closed explorer must not open or activate another tab.
      openTab: (next) => {
        if (open) this.openTab(next);
      },
      activateExisting: (next) => open && this.activateExisting(next, key),
      recordsChanged: (count) => {
        if (open)
          recordCount.set(
            count !== null && Number.isFinite(count) && count >= 0 ? Math.trunc(count) : null,
          );
      },
      isActive: active.asReadonly(),
    };
    const injector = Injector.create({
      parent: this.injector,
      providers: [{ provide: EXPLORER_CONTEXT, useValue: context }],
    });
    const close = () => {
      open = false;
      active.set(false);
    };
    this.tabs.update((tabs) => [...tabs, { ...source, key, injector, active, recordCount, close }]);
    this.selectTab(this.tabs().length - 1);
  }

  closeTab(key: string): void {
    if (this.tabs().length === 1) return;
    const index = this.tabs().findIndex((tab) => tab.key === key);
    if (index < 0) return;
    const current = this.selectedIndex();
    this.tabs()[index]!.close();
    this.tabs.update((tabs) => tabs.filter((tab) => tab.key !== key));
    this.selectTab(index < current ? current - 1 : Math.min(current, this.tabs().length - 1));
  }

  ngOnDestroy(): void {
    for (const tab of this.tabs()) tab.close();
  }
}
