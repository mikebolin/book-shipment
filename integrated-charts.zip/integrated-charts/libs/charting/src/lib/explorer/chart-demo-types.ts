import type { ChartPlan } from '../core/domain/integrated-chart';
import type { PromptExample } from './prompt-examples.js';

/** Twenty visual variants: bar/column API aliases are not additional chart types. */
export const CHART_DEMO_VARIANTS = [
  { id: 'groupedColumn', label: 'Column · standard / grouped', family: 'Column' },
  { id: 'stackedColumn', label: 'Column · stacked', family: 'Column' },
  { id: 'normalizedColumn', label: 'Column · 100% stacked', family: 'Column' },
  { id: 'groupedBar', label: 'Bar · standard / grouped', family: 'Bar' },
  { id: 'stackedBar', label: 'Bar · stacked', family: 'Bar' },
  { id: 'normalizedBar', label: 'Bar · 100% stacked', family: 'Bar' },
  { id: 'line', label: 'Line · standard', family: 'Line' },
  { id: 'stackedLine', label: 'Line · stacked', family: 'Line' },
  { id: 'normalizedLine', label: 'Line · 100% stacked', family: 'Line' },
  { id: 'area', label: 'Area · standard', family: 'Area' },
  { id: 'stackedArea', label: 'Area · stacked', family: 'Area' },
  { id: 'normalizedArea', label: 'Area · 100% stacked', family: 'Area' },
  { id: 'pie', label: 'Pie', family: 'Pie' },
  { id: 'donut', label: 'Donut', family: 'Donut' },
  { id: 'scatter', label: 'Scatter', family: 'Scatter' },
  { id: 'bubble', label: 'Bubble', family: 'Bubble' },
  { id: 'histogram', label: 'Histogram', family: 'Histogram' },
  { id: 'columnLineCombo', label: 'Combination · column + line', family: 'Combination' },
  { id: 'areaColumnCombo', label: 'Combination · area + column', family: 'Combination' },
  { id: 'customCombo', label: 'Combination · custom', family: 'Combination' },
] as const satisfies readonly { id: ChartPlan['type']; label: string; family: string }[];

export function normalizeChartDemoType(type: ChartPlan['type']): ChartPlan['type'] {
  return type === 'bar' ? 'groupedBar' : type === 'column' ? 'groupedColumn' : type;
}

export function chartDemoLabel(type: ChartPlan['type']): string {
  return CHART_DEMO_VARIANTS.find((variant) => variant.id === normalizeChartDemoType(type))!.label;
}

// Preserve original demo texts and IDs while exposing their reviewed chart types in the library.
const EXISTING_CHART_TYPES: Readonly<Record<string, ChartPlan['type']>> = {
  'chart-balance-by-status': 'bar',
  'chart-account-counts': 'column',
  'chart-financial-comparison': 'column',
  'chart-daily-creations': 'line',
  'chart-monthly-market-prices': 'line',
  'chart-largest-balance': 'bar',
  'chart-smallest-balance': 'column',
  'chart-revenue-income-relationship': 'scatter',
  'chart-price-volume-relationship': 'scatter',
  'chart-balance-distribution': 'histogram',
  'chart-grouped-bar': 'groupedBar',
  'chart-stacked-bar': 'stackedBar',
  'chart-normalized-bar': 'normalizedBar',
  'chart-grouped-column': 'groupedColumn',
  'chart-stacked-column': 'stackedColumn',
  'chart-normalized-column': 'normalizedColumn',
  'chart-stacked-line': 'stackedLine',
  'chart-normalized-line': 'normalizedLine',
  'chart-stacked-area': 'stackedArea',
  'chart-normalized-area': 'normalizedArea',
  'chart-area-column-combo': 'areaColumnCombo',
  'chart-area': 'area',
  'chart-pie': 'pie',
  'chart-donut': 'donut',
  'chart-bubble': 'bubble',
  'chart-column-line-combo': 'columnLineCombo',
  'chart-nested-exceptions': 'bar',
  'chart-losses-grouped': 'groupedColumn',
  'chart-themed-exceptions': 'column',
  'chart-themed-share': 'pie',
  'chart-custom-revenue-income': 'customCombo',
  'chart-custom-asset-components': 'customCombo',
  'chart-custom-cohort-components': 'customCombo',
  'tx-chart-asset-value': 'column',
  'tx-chart-status-count': 'bar',
  'tx-chart-broker-fees': 'bar',
  'tx-chart-monthly-trades': 'line',
  'tx-chart-distribution': 'histogram',
  'tx-chart-fee-relationship': 'scatter',
  'tx-chart-buy-sell-cash': 'column',
  'tx-chart-preview-refine': 'donut',
  'cu-chart-allocation': 'donut',
  'cu-chart-client-count': 'bar',
  'cu-chart-losses': 'bar',
  'cu-chart-value-cost': 'groupedColumn',
  'cu-chart-relationship': 'scatter',
  'cu-chart-income': 'column',
  'cu-chart-distribution': 'histogram',
  'cu-chart-preview-refine': 'column',
};

export function withChartDemoType(example: PromptExample): PromptExample {
  const chartType = example.chartType ?? EXISTING_CHART_TYPES[example.id];
  return chartType ? { ...example, chartType } : example;
}
