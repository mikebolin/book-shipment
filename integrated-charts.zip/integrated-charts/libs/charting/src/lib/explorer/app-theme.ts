import { inputStyleBordered, themeMaterial, type CustomChartThemes } from 'ag-grid-community';

export interface AppTheme {
  id: string;
  label: string;
  dark: boolean;
  /** Material 2 presets get equivalent system tokens for application-owned surfaces. */
  tokens: Record<string, string>;
  colors: string[];
}

/** Injection providers may replace this collection without changing any consumer. */
export function createGridTheme(theme: AppTheme) {
  const color = (name: string) => theme.tokens[name]!;
  return themeMaterial.withPart(inputStyleBordered).withParams({
    fontFamily: 'Roboto, "Segoe UI", sans-serif',
    fontSize: 12,
    spacing: 4,
    rowHeight: 32,
    headerHeight: 34,
    iconSize: 16,
    browserColorScheme: theme.dark ? 'dark' : 'light',
    accentColor: color('primary'),
    // Material's actions and picker focus use primaryColor independently of accentColor.
    primaryColor: color('primary'),
    backgroundColor: color('surface-container-lowest'),
    dataBackgroundColor: color('surface-container-lowest'),
    foregroundColor: color('on-surface'),
    borderColor: color('outline-variant'),
    chromeBackgroundColor: color('surface-container-low'),
    headerBackgroundColor: color('surface-container-low'),
    headerTextColor: color('on-surface'),
    headerCellHoverBackgroundColor: color('surface-container-high'),
    oddRowBackgroundColor: color('surface'),
    rowHoverColor: color('surface-container'),
    selectedRowBackgroundColor: color('primary-container'),
    rangeSelectionBorderColor: color('primary'),
    // Native filter dialogs (including body-parent popups) share the active palette.
    advancedFilterBuilderJoinPillColor: color('primary-container'),
    advancedFilterBuilderColumnPillColor: color('surface-container-high'),
    advancedFilterBuilderOptionPillColor: color('surface-container'),
    advancedFilterBuilderValuePillColor: color('surface-container-high'),
    advancedFilterBuilderButtonBarBorder: { color: color('outline-variant') },
    panelBackgroundColor: color('surface-container-lowest'),
    panelTitleBarBackgroundColor: color('surface-container-low'),
    panelTitleBarTextColor: color('on-surface'),
    panelTitleBarIconColor: color('on-surface-variant'),
    menuBackgroundColor: color('surface-container-low'),
    menuTextColor: color('on-surface'),
    pickerButtonBackgroundColor: color('surface-container-lowest'),
    pickerButtonFocusBackgroundColor: color('surface-container'),
    pickerButtonFocusBorder: { color: color('primary') },
    pickerListBackgroundColor: color('surface-container-low'),
    pickerListBorder: { color: color('outline-variant') },
    inputBackgroundColor: color('surface-container-lowest'),
    inputTextColor: color('on-surface'),
    inputBorder: { color: color('outline-variant') },
    inputFocusBorder: { color: color('primary') },
    inputFocusBackgroundColor: color('surface-container-lowest'),
    inputFocusTextColor: color('on-surface'),
    inputDisabledBackgroundColor: color('surface-container'),
    inputDisabledTextColor: { ref: 'foregroundColor', mix: 0.38 },
    inputDisabledBorder: { color: color('outline-variant') },
    buttonTextColor: color('primary'),
    buttonBackgroundColor: 'transparent',
    buttonHoverTextColor: color('on-primary-container'),
    buttonHoverBackgroundColor: color('primary-container'),
    buttonActiveTextColor: color('on-primary-container'),
    buttonActiveBackgroundColor: color('primary-container'),
    buttonDisabledTextColor: { ref: 'foregroundColor', mix: 0.38 },
    buttonDisabledBackgroundColor: color('surface-container'),
    cellHorizontalPadding: 10,
    wrapperBorderRadius: 0,
    // Allocate the dock once; animate its content instead of resizing the grid every frame.
    sideBarPanelAnimationDuration: 0,
  });
}

export function createChartTheme(theme: AppTheme): CustomChartThemes[string] {
  return {
    baseTheme: theme.dark ? 'ag-material-dark' : 'ag-material',
    palette: { fills: [...theme.colors], strokes: [...theme.colors] },
    params: {
      foregroundColor: theme.tokens['on-surface'],
      textColor: theme.tokens['on-surface'],
      subtleTextColor: theme.tokens['on-surface-variant'],
      backgroundColor: theme.tokens['surface-container-lowest'],
      chromeBackgroundColor: theme.tokens['surface-container-low'],
      chromeTextColor: theme.tokens['on-surface'],
      panelBackgroundColor: theme.tokens['surface-container-low'],
      menuBackgroundColor: theme.tokens['surface-container'],
      menuTextColor: theme.tokens['on-surface'],
      tooltipBackgroundColor: theme.tokens['surface-container-high'],
      tooltipTextColor: theme.tokens['on-surface'],
      tooltipSubtleTextColor: theme.tokens['on-surface-variant'],
      axisLineColor: theme.tokens['outline-variant'],
      gridLineColor: theme.tokens['outline-variant'],
      accentColor: theme.tokens['primary'],
      fontFamily: 'Roboto, "Segoe UI", sans-serif',
    },
    overrides: {
      common: {
        background: { fill: theme.tokens['surface-container-lowest'] },
        title: { color: theme.tokens['on-surface'], fontSize: 14 },
        subtitle: { color: theme.tokens['on-surface-variant'] },
        legend: { item: { label: { color: theme.tokens['on-surface-variant'], fontSize: 11 } } },
      },
    },
  };
}
