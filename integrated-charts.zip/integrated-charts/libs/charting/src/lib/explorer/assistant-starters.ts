import type { PromptExample } from './prompt-examples';

interface StarterContext {
  source: string;
  columnIds: readonly string[];
  assistant: 'grid' | 'verified';
  mode: 'advanced' | 'columns';
  chartsEnabled: boolean;
  setFiltersEnabled: boolean;
  chartOnly: boolean;
}

/** Only self-contained, supported requests belong on the assistant's welcome screen. */
export function assistantStarters(
  library: readonly PromptExample[],
  context: StarterContext,
): readonly PromptExample[] {
  const columns = new Set(context.columnIds);
  const eligible = library.filter((example) => {
    if (
      example.outcome !== 'apply' ||
      example.benchmarkBaseCase ||
      ['boundaries', 'dashboards', 'calculated'].includes(example.category) ||
      example.fields.some((field) => !columns.has(field))
    )
      return false;
    const chart = !!example.chartType || example.category === 'charts';
    if (chart && (!context.chartsEnabled || context.assistant !== 'grid')) return false;
    if (context.chartOnly && !chart) return false;
    if (context.assistant === 'verified' && !['logic', 'dates', 'sets'].includes(example.category))
      return false;
    return !(example.requirements ?? []).some(
      (requirement) =>
        (requirement === 'Advanced mode' && context.mode !== 'advanced') ||
        (requirement === 'Set Filters on' && !context.setFiltersEnabled) ||
        ['Dashboards available', 'Calculated columns available'].includes(requirement),
    );
  });
  const selected: PromptExample[] = [];
  const add = (example: PromptExample | undefined): void => {
    if (example && !selected.some((item) => item.prompt === example.prompt)) selected.push(example);
  };
  // Only the reviewed filter-only entries above are advertised in Verified mode.
  if (context.assistant === 'verified') return [];
  // Keep fallback choices approachable and varied, including schema-derived uploaded examples.
  const simple = [...eligible].sort((left, right) => left.prompt.length - right.prompt.length);
  if (context.chartOnly) {
    for (const type of ['groupedColumn', 'line', 'pie', 'groupedBar'])
      add(simple.find((item) => item.chartType === type));
  } else {
    for (const category of ['logic', 'analysis', 'charts', 'dates', 'sets']) {
      if (!selected.some((item) => item.category === category))
        add(simple.find((item) => item.category === category));
    }
  }
  for (const example of simple) {
    if (selected.length >= 4) break;
    add(example);
  }
  return selected.slice(0, 4);
}
