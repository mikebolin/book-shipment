import type { GridChatTurn } from '../core/domain/grid-copilot';
import {
  isPlanningDisplayMessage,
  planningConversation,
} from '../core/domain/planning-conversation';
export { LEGACY_AI_BOUNDARY_MESSAGE } from '../core/domain/planning-conversation';

// Older servers returned this validation failure as a clarification. It adds no
// chart constraint and must not become another instruction on the next turn.
export function isOperationalAssistantMessage(text: string): boolean {
  return isPlanningDisplayMessage(text);
}

/** UI status badges and error notices are not part of the user's conversation. */
export function gridChatContext(
  messages: readonly (GridChatTurn & { status?: string; modelContext?: 'dialogue' | 'display' })[],
): GridChatTurn[] {
  const turns: GridChatTurn[] = [];
  let remaining = 16_000;
  const relevant = messages.filter(
    (message) =>
      message.role !== 'assistant' ||
      (message.status !== 'error' &&
        message.modelContext !== 'display' &&
        !isOperationalAssistantMessage(message.text)),
  );
  for (const message of relevant.slice(-12).reverse()) {
    // Each submitted turn is already limited to 4,000 characters. Never add a
    // display status or cut a quoted value merely to assemble model context.
    if (message.text.length > 4000 || message.text.length > remaining) break;
    turns.unshift({ role: message.role, text: message.text });
    remaining -= message.text.length;
  }
  return planningConversation(turns);
}
