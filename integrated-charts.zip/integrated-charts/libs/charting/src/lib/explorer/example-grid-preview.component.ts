import { inject } from '@angular/core';
import { CHARTING_DATA } from '../core/data-access/charting-data';
import { injectUiState } from '../core/state/index';
import { ChangeDetectionStrategy, Component, Input, OnChanges, OnDestroy } from '@angular/core';
import { DatePipe, DecimalPipe } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { isLocalDataSource, type ClientDataSourceId } from './client-data-sources';
import type { LocalDataRecipe } from './local-data-recipes';
import { loadDemoGridPreview, type GridReviewPreview } from './demo-grid-preview-loader';
import { ExampleDataTableComponent } from './example-data-table.component';

@Component({
  selector: 'app-example-grid-preview',
  standalone: true,
  imports: [
    DatePipe,
    DecimalPipe,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    ExampleDataTableComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section aria-label="Saved grid review" [attr.aria-busy]="loading()">
      @if (loading()) {
        <p role="status">Loading saved review…</p>
      } @else if (error()) {
        <p role="alert">{{ error() }}</p>
        <button
          mat-icon-button
          type="button"
          matTooltip="Retry saved review"
          aria-label="Retry saved review"
          (click)="load()"
        >
          <mat-icon>refresh</mat-icon>
        </button>
      } @else if (preview(); as saved) {
        <div class="review-outcome" [attr.data-review-status]="saved.status">
          <strong>{{
            saved.status === 'ready'
              ? 'Changes to review'
              : saved.status === 'clarification'
                ? 'Clarification required'
                : 'Request not applied'
          }}</strong>
          <p>{{ saved.explanation }}</p>
          @if (saved.operations.length) {
            <div class="operation-list">
              @for (operation of saved.operations; track $index) {
                <div class="operation">
                  <mat-icon aria-hidden="true">{{ operationIcon(operation) }}</mat-icon
                  ><span>{{ operation }}</span>
                </div>
              }
            </div>
          }
          @if (saved.clarificationOptions?.length) {
            <ul>
              @for (option of saved.clarificationOptions; track $index) {
                <li>{{ option }}</li>
              }
            </ul>
          }
        </div>
        <div class="filter-review">
          <span>{{
            saved.status === 'ready' ? 'Proposed AG Grid filter' : 'AG Grid filter · unchanged'
          }}</span>
          <code>{{ saved.filterText || 'All rows (no filter)' }}</code>
        </div>
        @if (saved.calculation; as calculation) {
          <div class="filter-review">
            <span>Calculated column · {{ calculation.name }}</span
            ><code>{{ calculation.expression }}</code>
          </div>
        }
        <p class="sample-caption">
          Showing {{ saved.rows.length > 20 ? 20 : saved.rows.length }} of
          {{ saved.rowCount | number }}
          {{
            saved.previewKind === 'grouped-rows'
              ? 'result groups'
              : saved.previewKind === 'unchanged-rows'
                ? 'unchanged source records'
                : 'matching records'
          }}
        </p>
        <app-example-data-table [preview]="saved" />
        <details class="snapshot">
          <summary>About this preview</summary>
          {{ localRecipe ? 'Uploaded file' : 'Saved demo snapshot' }}
          {{ snapshotDate() | date: 'mediumDate' : 'UTC' }} · {{ authorizedRows() | number }} source
          rows · Current grid unchanged. Preview sorting affects this sample only.
        </details>
      }
    </section>
  `,
  styles: [
    `
      :host {
        display: block;
        min-width: 0;
      }
      section {
        color: var(--mat-sys-on-surface-variant);
        font-size: 12px;
      }
      .review-outcome {
        line-height: 1.55;
      }
      .operation-list {
        display: grid;
        gap: 8px;
        margin: 12px 0;
      }
      .operation {
        display: flex;
        gap: 9px;
        padding: 9px 11px;
        border: 1px solid var(--mat-sys-outline-variant);
        border-radius: 8px;
        background: var(--mat-sys-surface-container-low);
        color: var(--mat-sys-on-surface);
      }
      .operation mat-icon {
        flex: 0 0 18px;
        width: 18px;
        height: 18px;
        font-size: 18px;
        color: var(--mat-sys-primary);
      }
      strong {
        font-weight: 500;
        color: var(--mat-sys-on-surface);
      }
      p {
        margin: 6px 0 10px;
      }
      ul {
        margin: 6px 0 12px;
        padding-left: 18px;
      }
      .filter-review {
        padding: 10px 12px;
        margin: 10px 0;
        background: var(--mat-sys-surface-container);
        border-radius: 8px;
      }
      .filter-review span {
        display: block;
        font-size: 10px;
        font-weight: 500;
        margin-bottom: 5px;
      }
      code {
        display: block;
        color: var(--mat-sys-on-surface);
        font-size: 11px;
        line-height: 1.6;
        white-space: pre-wrap;
        overflow-wrap: anywhere;
      }
      .sample-caption {
        margin: 12px 0 8px;
        font-size: 11px;
      }
      .snapshot {
        margin: 8px 0 0;
        font-size: 10px;
      }
    `,
  ],
})
export class ExampleGridPreviewComponent implements OnChanges, OnDestroy {
  private readonly hostData = inject(CHARTING_DATA);
  private readonly reactiveState = injectUiState('ExampleGridPreviewComponent');

  operationIcon(operation: string): string {
    return /^filter/i.test(operation)
      ? 'filter_alt'
      : /^sort/i.test(operation)
        ? 'sort'
        : /^group/i.test(operation)
          ? 'account_tree'
          : /^pivot/i.test(operation)
            ? 'pivot_table_chart'
            : /^column/i.test(operation)
              ? 'view_column'
              : 'functions';
  }
  @Input() sourceId: ClientDataSourceId = 'accounts';
  @Input() localRecipe: LocalDataRecipe | null = null;
  @Input() localSnapshotDate = '';
  @Input() localRowCount = 0;
  @Input() exampleId = '';
  readonly preview = this.reactiveState.signal<GridReviewPreview | null>(null);
  readonly loading = this.reactiveState.signal(false);
  readonly error = this.reactiveState.signal('');
  readonly snapshotDate = this.reactiveState.signal('');
  readonly authorizedRows = this.reactiveState.signal(0);
  private revision = 0;
  ngOnChanges(): void {
    void this.load();
  }
  ngOnDestroy(): void {
    this.revision++;
  }
  async load(): Promise<void> {
    const revision = ++this.revision;
    this.preview.set(null);
    this.error.set('');
    this.loading.set(true);
    try {
      if (this.localRecipe) {
        this.snapshotDate.set(this.localSnapshotDate);
        this.authorizedRows.set(this.localRowCount);
        this.preview.set(this.localRecipe.preview);
        return;
      }
      if (isLocalDataSource(this.sourceId))
        throw new Error('This uploaded example has no grid preview.');
      const saved = await loadDemoGridPreview(this.sourceId, this.exampleId, this.hostData);
      if (revision !== this.revision) return;
      this.snapshotDate.set(saved.snapshotDate);
      this.authorizedRows.set(saved.authorizedRows);
      this.preview.set(saved.preview);
    } catch (error) {
      if (revision === this.revision)
        this.error.set(
          error instanceof Error ? error.message : 'Could not load this saved review.',
        );
    } finally {
      if (revision === this.revision) this.loading.set(false);
    }
  }
}
