import { InjectionToken } from '@angular/core';
import type { StudioQueryExecutor } from '../core/domain/studio-query';

/** Provide a host executor when integrating executeQuery; null selects the local fixture mock. */
export const STUDIO_QUERY_EXECUTOR = new InjectionToken<StudioQueryExecutor | null>(
  'Studio query executor',
  {
    providedIn: 'root',
    factory: () => null,
  },
);
