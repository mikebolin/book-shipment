import { injectUiState } from '../core/state/index';
import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  Output,
  computed,
  inject,
} from '@angular/core';
import { DecimalPipe } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ExplorerDataService } from './explorer-data.service';
import { IntegratedChartComponent } from './integrated-chart.component';
import type { LocalDataset } from './client-data-sources';
import type { LocalDataRecipe } from './local-data-recipes';
import { profileDataset, type DatasetProfile } from './dataset-profile';
import {
  validateAnalysisSelection,
  type DatasetAnalysisResponse,
} from '../core/domain/dataset-analysis';

@Component({
  selector: 'app-dataset-analysis',
  standalone: true,
  imports: [
    DecimalPipe,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    IntegratedChartComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section class="analysis" aria-label="Data analysis" [attr.aria-busy]="busy()">
      <header>
        <span class="analysis-icon"><mat-icon>auto_awesome</mat-icon></span>
        <div class="analysis-title">
          <h3>Understand your data</h3>
          <p>Find patterns, check quality, and choose a starting visual.</p>
        </div>
        <button
          mat-button
          type="button"
          (click)="analyze()"
          [disabled]="busy() || response()?.status === 'ready'"
        >
          <mat-icon>{{ response()?.status === 'ready' ? 'check' : 'auto_awesome' }}</mat-icon>
          {{
            busy()
              ? 'Analyzing…'
              : response()?.status === 'ready'
                ? 'Local analysis ready'
                : 'Analyze sample'
          }}
        </button>
        @if (busy()) {
          <button
            mat-icon-button
            type="button"
            aria-label="Cancel analysis"
            matTooltip="Cancel analysis"
            (click)="cancel()"
          >
            <mat-icon>close</mat-icon>
          </button>
        }
      </header>
      <p class="sharing-note">
        Analysis uses local field profiles and aggregate statistics. Your records stay in this
        browser.
      </p>
      @if (busy()) {
        <p role="status" class="analysis-status">
          Reviewing patterns and useful visuals… You can continue importing while this runs.
        </p>
      }
      @if (error()) {
        <p role="status" class="analysis-status">{{ error() }}</p>
      }
      @if (profile(); as report) {
        <details [open]="!!response()">
          <summary>
            {{ response()?.status === 'ready' ? 'AI highlights' : 'Local data profile'
            }}<span
              >{{ report.request.sampledRows | number }} records ·
              {{ report.request.analyzedFields }} fields</span
            >
          </summary>
          <p class="coverage">
            {{
              report.sampled
                ? 'Based on an evenly spaced sample of up to 12,000 records and the first 40 fields, with identifiers last. Findings describe this sample.'
                : 'All imported records and fields were analyzed locally.'
            }}
            AI prioritizes verified findings and visuals; all figures are calculated from your data.
          </p>
          <ul class="insights">
            @for (fact of facts(); track fact.id) {
              <li>
                <mat-icon>insights</mat-icon><span>{{ fact.text }}</span>
              </li>
            }
          </ul>
          @if (charts().length) {
            <h4>Suggested visuals</h4>
            <div class="chart-choices">
              @for (chart of charts(); track chart.id) {
                <button
                  type="button"
                  class="chart-choice"
                  [class.selected]="selected()?.id === chart.id"
                  [attr.aria-pressed]="selected()?.id === chart.id"
                  (click)="selected.set(chart)"
                >
                  <mat-icon>{{
                    chart.recipe.chart?.type === 'line' ? 'show_chart' : 'bar_chart'
                  }}</mat-icon
                  ><span>{{ chart.text }}</span
                  ><mat-icon>chevron_right</mat-icon>
                </button>
              }
            </div>
          } @else {
            <p class="coverage">
              No chart candidates match these fields yet. Continue to explore and configure a chart.
            </p>
          }
          @if (selected(); as chart) {
            @if (chart.recipe.chartPreview; as preview) {
              <div class="chart-preview">
                <div class="preview-heading">
                  <span
                    >Calculated from {{ preview.matchedRowCount | number }} matching records</span
                  ><button mat-button type="button" (click)="useChart.emit(chart.recipe)">
                    <mat-icon>arrow_forward</mat-icon>Explore this chart
                  </button>
                </div>
                <app-integrated-chart [dataset]="preview" [compact]="true" />
              </div>
            }
          }
        </details>
      }
    </section>
  `,
  styles: `
    :host {
      display: block;
      margin: 20px 0;
    }
    .analysis {
      border: 1px solid var(--mat-sys-outline-variant);
      border-radius: 14px;
      padding: 20px;
      background: var(--mat-sys-surface);
    }
    header {
      display: flex;
      align-items: center;
      gap: 12px;
    }
    .analysis-icon {
      display: grid;
      place-items: center;
      width: 40px;
      height: 40px;
      border-radius: 12px;
      background: var(--mat-sys-primary-container);
      color: var(--mat-sys-on-primary-container);
      flex-shrink: 0;
    }
    .analysis-title {
      flex: 1;
      min-width: 0;
    }
    h3 {
      margin: 0;
      font-size: 16px;
      font-weight: 600;
    }
    .analysis-title p {
      margin: 4px 0 0;
      color: var(--mat-sys-on-surface-variant);
      font-size: 12px;
      line-height: 1.5;
    }
    .sharing-note,
    .coverage {
      font-size: 12px;
      color: var(--mat-sys-on-surface-variant);
      line-height: 1.65;
    }
    .sharing-note {
      margin: 14px 0 0;
    }
    .analysis-status {
      font-size: 13px;
      line-height: 1.5;
      padding: 10px 12px;
      border-radius: 8px;
      background: var(--mat-sys-surface-container);
    }
    details {
      margin-top: 16px;
      border-top: 1px solid var(--mat-sys-outline-variant);
      padding-top: 14px;
    }
    summary {
      cursor: pointer;
      font-weight: 500;
      font-size: 13px;
    }
    summary span {
      font-size: 11px;
      font-weight: 400;
      color: var(--mat-sys-on-surface-variant);
      margin-left: 12px;
    }
    .insights {
      display: grid;
      gap: 10px;
      padding: 0;
      list-style: none;
    }
    .insights li {
      display: flex;
      align-items: flex-start;
      gap: 10px;
      font-size: 13px;
      line-height: 1.65;
    }
    .insights mat-icon {
      font-size: 18px;
      width: 18px;
      height: 20px;
      color: var(--mat-sys-primary);
      flex-shrink: 0;
      margin-top: 3px;
    }
    h4 {
      font-size: 12px;
      font-weight: 600;
      margin: 22px 0 10px;
    }
    .chart-choices {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 8px;
    }
    .chart-choice {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 12px;
      text-align: left;
      font: inherit;
      font-size: 12px;
      color: var(--mat-sys-on-surface);
      background: var(--mat-sys-surface-container-low);
      border: 1px solid var(--mat-sys-outline-variant);
      border-radius: 9px;
      cursor: pointer;
    }
    .chart-choice span {
      flex: 1;
      overflow-wrap: anywhere;
    }
    .chart-choice.selected {
      border-color: var(--mat-sys-primary);
      background: var(--mat-sys-primary-container);
      color: var(--mat-sys-on-primary-container);
    }
    .chart-choice:focus-visible {
      outline: 2px solid var(--mat-sys-primary);
      outline-offset: 2px;
    }
    .chart-choice mat-icon {
      font-size: 19px;
      width: 19px;
      height: 19px;
      flex-shrink: 0;
    }
    .chart-preview {
      margin-top: 14px;
      padding: 12px;
      border: 1px solid var(--mat-sys-outline-variant);
      border-radius: 10px;
    }
    .preview-heading {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      font-size: 12px;
      color: var(--mat-sys-on-surface-variant);
    }
    @media (max-width: 640px) {
      header {
        flex-wrap: wrap;
      }
      .analysis-title {
        flex-basis: calc(100% - 60px);
      }
      .analysis {
        padding: 14px;
      }
      .chart-choices {
        grid-template-columns: 1fr;
      }
      .preview-heading {
        align-items: flex-start;
        flex-direction: column;
      }
      summary span {
        display: block;
        margin: 6px 0 0;
      }
    }
  `,
})
export class DatasetAnalysisComponent implements OnDestroy {
  private readonly reactiveState = injectUiState('DatasetAnalysisComponent');

  private readonly api = inject(ExplorerDataService);
  private current?: LocalDataset;
  private controller?: AbortController;
  @Input({ required: true }) set dataset(value: LocalDataset) {
    this.controller?.abort();
    this.busy.set(false);
    this.response.set(null);
    this.error.set('');
    this.selected.set(null);
    this.current = value;
    try {
      this.profile.set(profileDataset(value));
    } catch {
      this.profile.set(null);
      this.error.set('This file does not contain enough data to profile.');
    }
  }
  @Output() useChart = new EventEmitter<LocalDataRecipe>();
  readonly profile = this.reactiveState.signal<DatasetProfile | null>(null);
  readonly response = this.reactiveState.signal<DatasetAnalysisResponse | null>(null);
  readonly busy = this.reactiveState.signal(false);
  readonly error = this.reactiveState.signal('');
  readonly selected = this.reactiveState.signal<DatasetProfile['charts'][number] | null>(null);
  readonly facts = computed(() => {
    const facts = this.profile()?.request.facts ?? [];
    return this.response()
      ? this.response()!.factIds.flatMap((id) => facts.filter((fact) => fact.id === id))
      : facts.slice(0, 6);
  });
  readonly charts = computed(() => {
    const charts = this.profile()?.charts ?? [];
    return this.response()
      ? this.response()!.chartIds.flatMap((id) => charts.filter((chart) => chart.id === id))
      : charts.slice(0, 4);
  });
  async analyze() {
    const profile = this.profile(),
      dataset = this.current;
    if (!profile || !dataset || this.busy()) return;
    this.controller?.abort();
    const controller = (this.controller = new AbortController());
    this.busy.set(true);
    this.error.set('');
    try {
      const result = await this.api.request<DatasetAnalysisResponse>(
        'analytics/dataset-analysis',
        profile.request,
        AbortSignal.any([controller.signal, AbortSignal.timeout(55_000)]),
        dataset.metadata.id,
      );
      if (controller.signal.aborted) return;
      validateAnalysisSelection(profile.request, {
        factIds: result.factIds,
        chartIds: result.chartIds,
      });
      if (
        !['ai', 'local'].includes(result.source) ||
        !['ready', 'unavailable', 'failed'].includes(result.status)
      )
        throw new Error('Invalid analysis response.');
      this.response.set(result);
      if (result.status !== 'ready')
        this.error.set(
          result.status === 'unavailable'
            ? 'Local profile and chart suggestions are ready below.'
            : 'AI analysis could not complete. Your local profile is available; you can retry.',
        );
    } catch (error) {
      if (!controller.signal.aborted)
        this.error.set(
          error instanceof Error && error.name !== 'TimeoutError'
            ? `AI analysis could not complete: ${error.message} Your local profile is still available.`
            : 'AI analysis timed out. Your local profile is still available; try again.',
        );
    } finally {
      if (this.controller === controller) this.busy.set(false);
    }
  }
  cancel() {
    this.controller?.abort();
    this.busy.set(false);
    this.error.set('Analysis canceled. Your local profile is available.');
  }
  ngOnDestroy() {
    this.controller?.abort();
  }
}
