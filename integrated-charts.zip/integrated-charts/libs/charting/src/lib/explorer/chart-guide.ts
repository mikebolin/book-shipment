import type { ColumnSpec } from '../core/domain/schema';
import type { Node, Operator } from '../core/domain/contracts';
import {
  chartColumnMetadata,
  type ChartPlan,
  type ChartSeriesType,
} from '../core/domain/integrated-chart';
import { validateChartPlan } from '../core/domain/chart-data';
import { filterTimestamp, plainDate, validateNode } from '../core/domain/engine';
import type { ViewFilterControls } from '../core/domain/workspace.types';

export interface ChartGuideSubmission {
  plan: ChartPlan;
  /** Extra conditions are ANDed with the selected current/proposed data scope. */
  filters: Node[];
  /** Reader interaction belongs to the saved chart, never to its data query. */
  filterControls?: ViewFilterControls;
}
export type ChartReaderFilters = 'inherit' | 'hidden' | 'readonly' | 'values' | 'expression';

export function chartReaderFilterMode(controls?: ViewFilterControls): ChartReaderFilters {
  return !controls
    ? 'inherit'
    : !controls.visible
      ? 'hidden'
      : !controls.parameterizable
        ? 'readonly'
        : controls.editMode === 'values'
          ? 'values'
          : 'expression';
}

export function chartReaderFilterControls(
  mode: ChartReaderFilters,
): ViewFilterControls | undefined {
  if (mode === 'inherit') return undefined;
  return {
    visible: mode !== 'hidden',
    parameterizable: mode === 'values' || mode === 'expression',
    ...(mode === 'values' || mode === 'expression' ? { editMode: mode } : {}),
  };
}
export interface ChartGuideFilter {
  columnId: string;
  operator: Operator;
  value: string;
}

export const isRawChart = (type: ChartPlan['type']): boolean =>
  ['scatter', 'bubble', 'histogram'].includes(type);
export const isTimeChart = (type: ChartPlan['type']): boolean =>
  ['line', 'stackedLine', 'normalizedLine', 'area', 'stackedArea', 'normalizedArea'].includes(type);
export const isComboChart = (type: ChartPlan['type']): boolean => type.endsWith('Combo');

export function guideFields(columns: readonly ColumnSpec[]) {
  const metadata = new Map(chartColumnMetadata(columns).map((column) => [column.id, column]));
  return {
    metadata,
    categories: columns.filter((column) =>
      ['dimension', 'temporal'].includes(metadata.get(column.id)!.role),
    ),
    measures: columns.filter((column) => metadata.get(column.id)!.role === 'measure'),
    dates: columns.filter((column) => metadata.get(column.id)!.role === 'temporal'),
  };
}

/** Only sensible defaults are chosen from trusted schema metadata; row values are never inferred. */
export function defaultGuidePlan(
  type: ChartPlan['type'],
  columns: readonly ColumnSpec[],
): ChartPlan {
  const fields = guideFields(columns);
  const category = isTimeChart(type)
    ? fields.dates[0]
    : [...fields.categories].sort((a, b) => {
        const rank = (column: ColumnSpec) =>
          column.values?.length && column.values.length <= 20 ? 0 : column.kind === 'text' ? 1 : 2;
        return rank(a) - rank(b);
      })[0];
  const first = fields.measures[0];
  const count = type === 'bubble' ? 3 : type === 'scatter' || isComboChart(type) ? 2 : 1;
  const unit = first ? fields.metadata.get(first.id)!.unit : null;
  const remaining = fields.measures.filter((column) => column.id !== first?.id);
  const ordered = [...remaining].sort(
    (a, b) =>
      Number(fields.metadata.get(b.id)!.unit === unit) -
      Number(fields.metadata.get(a.id)!.unit === unit),
  );
  const measures = first ? [first, ...ordered].slice(0, count).map((column) => column.id) : [];
  const aggregation = !first
    ? 'count'
    : /price|ratio|percent|rate|yield|temperature/i.test(`${first.label} ${first.description}`)
      ? 'avg'
      : 'sum';
  return {
    type,
    categoryColumnId: isRawChart(type) ? null : (category?.id ?? null),
    measureColumnIds: measures,
    aggregation: isRawChart(type) ? null : aggregation,
    timeBucket:
      !isRawChart(type) && category && ['date', 'datetime'].includes(category.kind)
        ? 'month'
        : null,
    title: '',
    appearance: null,
    seriesChartTypes: type === 'customCombo' ? defaultComboSeries(measures, columns) : null,
  };
}

export function defaultComboSeries(
  ids: readonly string[],
  columns: readonly ColumnSpec[],
): ChartSeriesType[] {
  const metadata = guideFields(columns).metadata;
  const firstUnit = metadata.get(ids[0])?.unit;
  return ids.map((id, index) => ({
    colId: id,
    chartType: index ? 'line' : 'groupedColumn',
    secondaryAxis: index > 0 && (!firstUnit || metadata.get(id)?.unit !== firstUnit),
  }));
}

export function guidePlanError(plan: ChartPlan, columns: readonly ColumnSpec[]): string {
  if (plan.analytics) {
    try {
      validateChartPlan({ ...plan, title: plan.title.trim() || 'Chart' }, columns);
      return '';
    } catch (error) {
      return error instanceof Error ? error.message : 'Check the grouped chart metrics.';
    }
  }
  const fields = guideFields(columns);
  const measures = plan.measureColumnIds.map((id) => fields.metadata.get(id));
  if (measures.some((column) => column?.role !== 'measure'))
    return 'Choose numeric measures from this data source. Identifier fields cannot be chart values.';
  if (new Set(plan.measureColumnIds).size !== measures.length)
    return 'Choose a different measure for each series.';
  if (measures.length > 3) return 'Choose up to three measures.';
  if (isRawChart(plan.type)) {
    const expected = plan.type === 'bubble' ? 3 : plan.type === 'scatter' ? 2 : 1;
    return measures.length === expected
      ? ''
      : `Choose ${expected} distinct numeric measure${expected > 1 ? 's' : ''} for this chart.`;
  }
  const category = fields.metadata.get(plan.categoryColumnId ?? '');
  if (!category || !['dimension', 'temporal'].includes(category.role))
    return 'Choose a category or date field to group the results.';
  if (!plan.aggregation) return 'Choose how to calculate the chart values.';
  if (isTimeChart(plan.type) && (category.role !== 'temporal' || !plan.timeBucket))
    return 'This chart needs a date field and a time interval. Choose a column or bar chart to compare categories.';
  if (category.role !== 'temporal' && plan.timeBucket)
    return 'Time intervals are only available for date fields.';
  if (!measures.length && plan.aggregation !== 'count')
    return 'Choose a numeric measure, or select Count to chart the number of records.';
  if (['pie', 'donut'].includes(plan.type) && measures.length > 1)
    return 'Pie and donut charts use one measure or a count of records.';
  if (isComboChart(plan.type) && measures.length < 2)
    return 'Choose at least two numeric measures for a combination chart.';
  if (plan.type === 'customCombo') {
    const series = plan.seriesChartTypes;
    if (
      !series ||
      series.length !== measures.length ||
      new Set(series.map((item) => item.colId)).size !== measures.length ||
      series.some((item) => !plan.measureColumnIds.includes(item.colId))
    )
      return 'Choose a series style for every selected measure.';
    if (series.some((item) => item.secondaryAxis && !['line', 'area'].includes(item.chartType)))
      return 'Only line and area series support an independent right axis.';
  }
  const shared =
    plan.type === 'customCombo'
      ? measures.filter(
          (column) =>
            !plan.seriesChartTypes!.find((item) => item.colId === column!.id)?.secondaryAxis,
        )
      : measures;
  if (
    plan.aggregation !== 'count' &&
    shared.length > 1 &&
    (shared.some((column) => !column?.unit) ||
      new Set(shared.map((column) => column?.unit)).size > 1)
  )
    return 'These measures use different or unknown units. Choose matching units, or use a custom combination with a line on an independent right axis.';
  return '';
}

export function guideFilterOperators(column?: ColumnSpec): readonly Operator[] {
  if (!column) return ['equals'];
  return column.kind === 'text'
    ? ['equals', 'notEqual', 'contains', 'startsWith', 'blank', 'notBlank']
    : [
        'equals',
        'notEqual',
        'greaterThanOrEqual',
        'lessThanOrEqual',
        'greaterThan',
        'lessThan',
        'blank',
        'notBlank',
      ];
}

export function buildGuideFilters(
  filters: readonly ChartGuideFilter[],
  columns: readonly ColumnSpec[],
): Node[] {
  return filters.map((filter) => {
    const column = columns.find((candidate) => candidate.id === filter.columnId);
    if (!column)
      throw new Error('Choose a field for each condition, or remove the unfinished condition.');
    if (!guideFilterOperators(column).includes(filter.operator))
      throw new Error(`Choose a supported condition for ${column.label}.`);
    if (filter.operator === 'blank' || filter.operator === 'notBlank')
      return { kind: 'rule', field: column.id, op: filter.operator, value: null };
    const text = filter.value.trim();
    if (!text) throw new Error(`Enter a value for ${column.label}.`);
    let value: string | number = text;
    if (column.kind === 'number') {
      value = Number(text);
      if (!Number.isFinite(value)) throw new Error(`Enter a finite number for ${column.label}.`);
    }
    if (column.kind === 'date') {
      value = plainDate(text);
    }
    if (column.kind === 'datetime') {
      // datetime-local inputs omit seconds; exact zoned values still use the shared UTC parser.
      value = filterTimestamp(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(text) ? text + ':00' : text);
    }
    return validateNode({ kind: 'rule', field: column.id, op: filter.operator, value }, columns);
  });
}
