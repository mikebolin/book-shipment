import { LIMITS, type ColumnSpec } from '../core/domain/schema';
import type { GridModel, Mode, Node } from '../core/domain/contracts';
import {
  GRID_FEATURES,
  type GridConfirmation,
  type GridCopilotResult,
} from '../core/domain/grid-copilot';
import { calculatedColumnSpec, CALCULATION_LIMITS } from '../core/domain/calculated-columns';
import { parseNativeCalculation } from '../core/domain/native-calculated-columns';
import { parseLanguage } from '../core/domain/language';
import { expression, Fault } from '../core/domain/engine';
import { fromModel, toModel } from '../core/domain/grid-model';
import { assertSetFiltersEnabled } from '../core/domain/set-filters';
import { describeGridChanges, stableGridState, validateGridState } from '../core/domain/grid-state';
import type { ChartPlan } from '../core/domain/integrated-chart';
import { BrowserDataCache } from './browser-data-cache';
import { ClientDatasetRegistry, type ClientDataSourceId } from './client-data-sources';
import { buildLocalDataRecipes, type LocalDataRecipe } from './local-data-recipes';
import { planLocalChartIntent } from './local-chart-intent';
import {
  clarifyColumnCommand,
  resolveColumnCommands,
} from '../core/domain/column-command-guidance';
import { requestsChartHelp } from '../core/domain/chart-help';

interface Pending {
  source: ClientDataSourceId;
  mode: Mode;
  baseline: string;
  ids: string;
  expires: number;
  confirmation?: GridConfirmation;
  model?: GridModel;
  summary: string;
}
const normalized = (text: string) =>
  text.normalize('NFKC').trim().replace(/\s+/g, ' ').toLowerCase();

/** Browser-only planning and confirmation. No transport, model client, or server imports. */
export class LocalDataRouter {
  private readonly recipes = new Map<ClientDataSourceId, LocalDataRecipe[]>();
  private readonly pending = new Map<string, Pending>();
  constructor(
    readonly registry: ClientDatasetRegistry,
    readonly cache: BrowserDataCache,
  ) {}

  clearDrafts() {
    this.pending.clear();
  }

  register(source: ClientDataSourceId): void {
    const dataset = this.registry.get(source);
    if (!dataset) throw new Error('Import this dataset before registering it.');
    this.recipes.set(source, dataset.preparedRecipes ?? buildLocalDataRecipes(dataset));
    this.cache.setRows(source, dataset.rows, dataset.metadata.columns);
  }
  getRecipes(source: ClientDataSourceId): LocalDataRecipe[] {
    return this.recipes.get(source) ?? [];
  }
  /** Preserve a locally reviewed draft when the user enables live planning for its follow-up. */
  exportGridDraft(source: ClientDataSourceId, input: Record<string, any>): GridConfirmation {
    const pending = this.retrieve(
      source,
      { ...input, id: input['draftId'] },
      this.columns(source, input['calculatedColumnIds']),
    );
    if (!pending.confirmation)
      throw new Fault('PROPOSAL_TYPE', 'This review is not a grid proposal.');
    return structuredClone(pending.confirmation);
  }
  private columns(source: ClientDataSourceId, ids: string[] = []): ColumnSpec[] {
    const base = this.registry.metadata(source).columns;
    const definitions = this.cache.getCalculatedColumns(source);
    return [
      ...base,
      ...ids.map((id) => {
        const definition = definitions.find((column) => column.id === id);
        if (!definition)
          throw new Fault(
            'CALCULATED_COLUMNS',
            'This calculated column is not available in this local dataset.',
          );
        return calculatedColumnSpec(definition, base);
      }),
    ];
  }
  private snapshot(input: Record<string, any>, columns: ColumnSpec[]): string {
    return stableGridState(validateGridState(input['currentState'] ?? {}, input['mode'], columns));
  }
  private save(value: Pending): { id: string; expiresAt: string } {
    for (const [key, pending] of this.pending)
      if (pending.expires <= Date.now()) this.pending.delete(key);
    while (this.pending.size >= 32) this.pending.delete(this.pending.keys().next().value!);
    const id = crypto.randomUUID();
    this.pending.set(id, value);
    return { id, expiresAt: new Date(value.expires).toISOString() };
  }
  private proposal(
    source: ClientDataSourceId,
    input: Record<string, any>,
    confirmation: GridConfirmation,
    columns: ColumnSpec[],
  ): GridCopilotResult {
    const state = validateGridState(confirmation.gridState, input['mode'], columns, false);
    confirmation = { chart: null, ...confirmation, gridState: state };
    const saved = this.save({
      source,
      mode: input['mode'],
      baseline: this.snapshot(input, columns),
      ids: JSON.stringify(input['calculatedColumnIds'] ?? []),
      expires: Date.now() + LIMITS.ttlMs,
      confirmation,
      summary: confirmation.summary,
    });
    return {
      status: 'proposal',
      ...saved,
      ...confirmation,
      changes: describeGridChanges(
        state,
        GRID_FEATURES.filter((feature) => !confirmation.propertiesToIgnore.includes(feature)),
        input['mode'],
        columns,
      ),
    };
  }
  private retrieve(
    source: ClientDataSourceId,
    input: Record<string, any>,
    columns: ColumnSpec[],
    verified = false,
  ): Pending {
    const pending = this.pending.get(input['id']);
    if (!pending || pending.source !== source || pending.expires <= Date.now())
      throw new Fault(
        'EXPIRED',
        'This local review expired or belongs to another dataset. Generate it again.',
      );
    const baseline = verified
      ? JSON.stringify(
          toModel(fromModel(input['currentModel'], input['mode'], columns), input['mode'], columns),
        )
      : this.snapshot(input, columns);
    if (
      pending.mode !== input['mode'] ||
      pending.baseline !== baseline ||
      pending.ids !== JSON.stringify(input['calculatedColumnIds'] ?? [])
    )
      throw new Fault(
        'STALE_STATE',
        'The grid changed after this review. Generate a new proposal for the current state.',
      );
    return pending;
  }
  request(source: ClientDataSourceId, path: string, body?: unknown, signal?: AbortSignal): unknown {
    signal?.throwIfAborted();
    const dataset = this.registry.get(source);
    if (!dataset)
      throw new Fault(
        'LOCAL_DATA_MISSING',
        'This local dataset is no longer available. Import its JSON file again.',
      );
    if (this.cache.handles(path)) return this.cache.query(source, path, body, signal);
    const input = (body ?? {}) as Record<string, any>;
    // A wide Toolkit schema is capability metadata, not an executable filter tree.
    for (const key of ['currentState', 'currentModel', 'builderFilterModel', 'filterModel'])
      assertSetFiltersEnabled(input[key], false);
    const columns = this.columns(source, input['calculatedColumnIds']);
    if (path === 'schema')
      return {
        ...dataset.metadata,
        dataSourceId: source,
        timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        provider: 'mock',
        gridProvider: 'mock',
        tenant: 'local',
        execution: 'mock',
        calculatedColumnsEnabled: true,
        setFiltersEnabled: false,
        dashboardsEnabled: false,
        chartsEnabled: true,
        streamingEnabled: false,
        limits: LIMITS,
      };
    if (path === 'calculated-columns') {
      if (this.cache.getCalculatedColumns(source).length >= CALCULATION_LIMITS.columns)
        throw new Fault(
          'CALCULATION_LIMIT',
          'This local dataset already has eight calculated columns.',
        );
      const draft = parseNativeCalculation(
        { label: input['label'], expression: input['expression'] },
        columns,
      );
      const column = { ...draft, id: `calc_${crypto.randomUUID().replaceAll('-', '')}` };
      this.cache.addCalculatedColumn(source, column);
      return { column };
    }
    if (path === 'nl/grid/confirm') {
      const pending = this.retrieve(source, input, columns);
      if (!pending.confirmation)
        throw new Fault('PROPOSAL_TYPE', 'This review is not a grid proposal.');
      this.pending.delete(input['id']);
      return structuredClone(pending.confirmation);
    }
    if (path === 'grid/chart-proposal' || path === 'nl/grid/refine-chart') {
      const existing =
        path === 'nl/grid/refine-chart'
          ? this.retrieve(source, input, columns)
          : input['draftId']
            ? this.retrieve(source, { ...input, id: input['draftId'] }, columns)
            : undefined;
      if (existing && !existing.confirmation)
        throw new Fault('PROPOSAL_TYPE', 'This draft is not a grid proposal.');
      const fresh = input['requestScope'] === 'fresh';
      const state = validateGridState(
        existing?.confirmation?.gridState ?? (fresh ? {} : (input['currentState'] ?? {})),
        input['mode'],
        columns,
      );
      const key = input['mode'] === 'advanced' ? 'advancedFilterModel' : 'filterModel';
      if (Object.hasOwn(input, 'filterModel'))
        state.filter[key] = toModel(
          fromModel(input['filterModel'], input['mode'], columns),
          input['mode'],
          columns,
        );
      const plan = input['plan'] as ChartPlan;
      this.cache.query(
        source,
        'analytics/chart',
        {
          mode: input['mode'],
          filterModel: state.filter[key],
          calculatedColumnIds: input['calculatedColumnIds'] ?? [],
          plan,
        },
        signal,
      );
      const proposal = this.proposal(
        source,
        input,
        {
          ...existing?.confirmation,
          gridState: state,
          propertiesToIgnore:
            existing?.confirmation?.propertiesToIgnore ??
            (fresh ? [] : GRID_FEATURES.filter((feature) => feature !== 'filter')),
          summary: 'Create this chart from the imported browser data.',
          chart: plan,
          ...(fresh ? { resetView: true } : {}),
        },
        columns,
      );
      if (existing) this.pending.delete(input['id'] ?? input['draftId']);
      return proposal;
    }
    if (path === 'nl/grid/interpret') {
      const text = String(input['text'] ?? '');
      if (!text.trim() || text.length > LIMITS.text)
        throw new Fault(
          'TEXT_LENGTH',
          'Enter a local filter or example prompt within 2,000 characters.',
        );
      if (input['chartsEnabled'] !== false && requestsChartHelp(text))
        return {
          status: 'needs_input',
          reason: 'clarification',
          action: 'open_chart_builder',
          message:
            'Let’s configure a chart using your current filtered results. Choose the chart and fields in the builder.',
        };
      const columnGuidance = clarifyColumnCommand(text, columns);
      if (columnGuidance) return columnGuidance;
      const columnCommands = resolveColumnCommands(text, columns);
      if (columnCommands) {
        const fresh = input['requestScope'] === 'fresh';
        const state = validateGridState(
          fresh ? {} : (input['currentState'] ?? {}),
          input['mode'],
          columns,
        );
        const changed = Object.keys(columnCommands);
        return this.proposal(
          source,
          input,
          {
            gridState: { ...state, ...columnCommands },
            propertiesToIgnore: fresh
              ? []
              : GRID_FEATURES.filter((feature) => !changed.includes(feature)),
            summary: 'Apply the requested columns while preserving the current filters.',
            ...(fresh ? { resetView: true } : {}),
          },
          columns,
        );
      }
      const recipes = this.getRecipes(source);
      const matches = recipes.filter(
        (item) => normalized(item.example.prompt) === normalized(text),
      );
      const recipe =
        recipes.find((item) => item.example.prompt === text) ??
        (matches.length === 1 ? matches[0] : undefined);
      if (!recipe && matches.length > 1)
        return {
          status: 'needs_input',
          reason: 'clarification',
          message:
            'Several fields have similar names. Select the exact example from the library to identify the intended field.',
        };
      if (recipe) {
        const state = structuredClone(recipe.gridState);
        const model = (state['filter'] as Record<string, unknown>)?.['advancedFilterModel'];
        state['filter'] = {
          [input['mode'] === 'advanced' ? 'advancedFilterModel' : 'filterModel']: toModel(
            fromModel(model, 'advanced', columns),
            input['mode'],
            columns,
            false,
          ),
        };
        return this.proposal(
          source,
          input,
          {
            gridState: state,
            propertiesToIgnore: [...recipe.propertiesToIgnore],
            summary: recipe.preview.explanation,
            chart: recipe.chart ?? null,
            resetView: true,
          },
          columns,
        );
      }
      try {
        const intent = planLocalChartIntent(text, columns);
        if (intent) {
          const fresh = input['requestScope'] === 'fresh';
          const state = validateGridState(
            fresh ? {} : (input['currentState'] ?? {}),
            input['mode'],
            columns,
          );
          const key = input['mode'] === 'advanced' ? 'advancedFilterModel' : 'filterModel';
          const previous = fromModel(
            Object.hasOwn(input, 'builderFilterModel')
              ? input['builderFilterModel']
              : state.filter[key],
            input['mode'],
            columns,
          );
          const filter: Node =
            !fresh && input['operation'] === 'refine' && previous
              ? { kind: 'group', join: 'AND', children: [previous, intent.filter] }
              : intent.filter;
          state.filter[key] = toModel(filter, input['mode'], columns, false);
          if (intent.plan.categoryColumnId)
            state.sort = { sortModel: [{ colId: intent.plan.categoryColumnId, sort: 'asc' }] };
          this.cache.query(
            source,
            'analytics/chart',
            {
              mode: input['mode'],
              filterModel: state.filter[key],
              calculatedColumnIds: input['calculatedColumnIds'] ?? [],
              plan: intent.plan,
            },
            signal,
          );
          return this.proposal(
            source,
            input,
            {
              gridState: state,
              propertiesToIgnore: fresh
                ? []
                : GRID_FEATURES.filter((feature) => feature !== 'filter' && feature !== 'sort'),
              summary: `${intent.summary} Filters: ${expression(filter, true, columns)}.`,
              chart: intent.plan,
              ...(fresh ? { resetView: true } : {}),
            },
            columns,
          );
        }
      } catch (error) {
        if (!(error instanceof Fault)) throw error;
        return { status: 'needs_input', reason: 'unsupported', message: error.message };
      }
      if (/\b(?:create|make|build|draw|show)\b[\s\S]*\b(?:chart|graph|plot)\b/i.test(text)) {
        const dateFields = columns
          .filter((column) => column.kind === 'date' || column.kind === 'datetime')
          .map((column) => column.label)
          .slice(0, 5);
        const measureFields = columns
          .filter((column) => column.kind === 'number' && column.chartRole !== 'identifier')
          .map((column) => column.label)
          .slice(0, 5);
        return {
          status: 'needs_input',
          reason: 'unsupported',
          message:
            `The uploaded-file planner could not resolve every part of this chart request from the available fields. LLM Enabled currently ranks chart recommendations for uploads; this message was not sent to the model. ` +
            `Use Add chart or Library to configure a chart from ${dataset.provenance.fileName}. ` +
            (dateFields.length
              ? `Date fields include ${dateFields.join(', ')}. `
              : 'This file has no recognized date fields. ') +
            (measureFields.length
              ? `Measures include ${measureFields.join(', ')}.`
              : 'This file has no recognized numeric measures.'),
        };
      }
      try {
        const state = validateGridState(
          input['requestScope'] === 'fresh' ? {} : (input['currentState'] ?? {}),
          input['mode'],
          columns,
        );
        const key = input['mode'] === 'advanced' ? 'advancedFilterModel' : 'filterModel';
        if (Object.hasOwn(input, 'builderFilterModel')) {
          state.filter = validateGridState(
            { ...state, filter: { [key]: input['builderFilterModel'] } },
            input['mode'],
            columns,
            false,
          ).filter;
        }
        const node = this.parseFilter(
          text,
          input['operation'],
          state.filter[key] as GridModel,
          input['mode'],
          columns,
        );
        state.filter[key] = toModel(node, input['mode'], columns, false);
        return this.proposal(
          source,
          input,
          {
            gridState: state,
            propertiesToIgnore:
              input['requestScope'] === 'fresh'
                ? []
                : GRID_FEATURES.filter((feature) => feature !== 'filter'),
            summary: expression(node, true, columns),
            ...(input['requestScope'] === 'fresh' ? { resetView: true } : {}),
          },
          columns,
        );
      } catch (error) {
        return {
          status: 'needs_input',
          reason: 'unsupported',
          message: `Uploaded-file messages support saved library examples and explicit field filters. This request could not be interpreted for ${dataset.provenance.fileName}. Use a field from this dataset and quote text values. ${error instanceof Error ? error.message : ''}`,
        };
      }
    }
    if (path === 'nl/interpret') {
      try {
        const node = this.parseFilter(
          input['text'],
          input['operation'],
          input['currentModel'],
          input['mode'],
          columns,
        );
        const model = toModel(node, input['mode'], columns);
        const summary = expression(node, true, columns);
        const saved = this.save({
          source,
          mode: input['mode'],
          baseline: JSON.stringify(
            toModel(
              fromModel(input['currentModel'], input['mode'], columns),
              input['mode'],
              columns,
            ),
          ),
          ids: JSON.stringify(input['calculatedColumnIds'] ?? []),
          expires: Date.now() + LIMITS.ttlMs,
          model,
          summary,
        });
        return {
          status: 'proposal',
          ...saved,
          original: input['text'],
          resolved: input['text'],
          summary,
          model,
          mode: input['mode'],
          operation: input['operation'],
          notes: ['Evaluated locally against the imported schema; no model or server request.'],
        };
      } catch (error) {
        return {
          status: 'needs_input',
          message:
            error instanceof Error
              ? error.message
              : 'Use an explicit filter for this imported schema.',
        };
      }
    }
    if (path === 'nl/confirm') {
      const pending = this.retrieve(source, input, columns, true);
      if (!Object.hasOwn(pending, 'model'))
        throw new Fault('PROPOSAL_TYPE', 'This review is not a filter proposal.');
      this.pending.delete(input['id']);
      return { model: structuredClone(pending.model), summary: pending.summary };
    }
    throw new Fault(
      'LOCAL_ONLY',
      'This operation is unavailable for imported JSON. The file stays in this browser; no server or model request was made.',
    );
  }
  private parseFilter(
    text: string,
    operation: string,
    current: GridModel,
    mode: Mode,
    columns: ColumnSpec[],
  ): Node {
    const node = parseLanguage(
      text,
      { now: new Date().toISOString(), timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone },
      columns,
    );
    const previous = operation === 'refine' ? fromModel(current, mode, columns) : null;
    return previous ? { kind: 'group', join: 'AND', children: [previous, node] } : node;
  }
}
