import type { ChartModel } from 'ag-grid-community';
import type { ChartDataset } from '../core/domain/integrated-chart';

/** Exact query bins must win over both automatic binning and saved formatting. */
export function applyHistogramBins(
  options: ChartModel['chartOptions'],
  dataset: Pick<ChartDataset, 'type' | 'histogramBins'>,
): ChartModel['chartOptions'] {
  if (dataset.type !== 'histogram' || !dataset.histogramBins?.length) return options;
  return {
    ...options,
    histogram: {
      ...options.histogram,
      series: {
        ...options.histogram?.series,
        // AG Charts gives binCount precedence over explicit bins. A restored
        // chart may have an old value from its native Format panel.
        binCount: undefined,
        bins: dataset.histogramBins.map(([start, end]) => [start, end]),
        aggregation: 'count',
        areaPlot: false,
      },
    },
  };
}
