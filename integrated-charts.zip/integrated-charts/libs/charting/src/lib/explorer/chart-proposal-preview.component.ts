import { injectUiState } from '../core/state/index';
import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  Output,
  SimpleChanges,
  computed,
  inject,
} from '@angular/core';
import { DecimalPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import {
  CHART_TYPES,
  CHART_TIME_BUCKETS,
  CHART_AGGREGATIONS,
  chartColumnMetadata,
  type ChartPlan,
  type ChartRequest,
  type ChartResponse,
} from '../core/domain/integrated-chart';
import type { ColumnSpec } from '../core/domain/schema';
import { ExplorerDataService } from './explorer-data.service';
import { IntegratedChartComponent, type ChartPresentation } from './integrated-chart.component';
import type { GridCopilotResult } from '../core/domain/grid-copilot';
import { ResponseCopyButtonComponent } from './response-copy-button.component';
import { ChartTypeIconComponent } from './chart-type-icon.component';

export interface ChartPreviewExchange {
  request: ChartRequest;
  response: ChartResponse;
}

export interface ChartRefinement {
  prompt: string;
  reason?: string;
  /** Deterministic field selections are validated directly, without a model request. */
  plan?: ChartPlan;
}

@Component({
  selector: 'app-chart-proposal-preview',
  standalone: true,
  imports: [
    DecimalPipe,
    FormsModule,
    IntegratedChartComponent,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    ResponseCopyButtonComponent,
    ChartTypeIconComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (request) {
      <section class="chart-preview" [attr.aria-label]="label" [attr.aria-busy]="loading()">
        <header class="preview-heading">
          <div class="preview-title">
            <app-chart-type-icon [type]="request.plan.type" />
            <div>
              <span class="preview-kicker">CHART PREVIEW</span>
              <h3>{{ request.plan.title || label }}</h3>
            </div>
          </div>
          <div class="preview-header-actions">
            <app-response-copy-button
              [value]="generationResponse ?? request.plan"
              [label]="generationResponse ? 'Copy generation response' : 'Copy chart configuration'"
              [disabled]="loading()"
            />
            <button
              mat-icon-button
              type="button"
              [matTooltip]="
                guidedEditor
                  ? 'Edit chart'
                  : editing()
                    ? 'Close chart options'
                    : 'Refine this chart'
              "
              [attr.aria-label]="
                guidedEditor
                  ? 'Edit chart'
                  : editing()
                    ? 'Close chart options'
                    : 'Refine this chart'
              "
              (click)="openEditor()"
              [attr.aria-expanded]="guidedEditor ? null : editing()"
            >
              <mat-icon>{{ guidedEditor ? 'edit' : editing() ? 'close' : 'tune' }}</mat-icon>
            </button>
          </div>
        </header>
        @if (editing() && !guidedEditor) {
          <section class="chart-editor" aria-label="Chart refinement options">
            <p>Choose what to show, then update the preview.</p>
            <div class="editor-fields">
              <mat-form-field appearance="outline" subscriptSizing="dynamic">
                <mat-label>Chart type</mat-label>
                <mat-select
                  aria-label="Preview chart type"
                  [disabled]="loading()"
                  [ngModel]="chartType()"
                  (ngModelChange)="chartType.set($event)"
                >
                  @for (type of chartTypes; track type) {
                    <mat-option [value]="type">{{ chartTypeLabel(type) }}</mat-option>
                  }
                </mat-select>
              </mat-form-field>
              @if (!rawChart()) {
                <mat-form-field appearance="outline" subscriptSizing="dynamic">
                  <mat-label>Group by</mat-label>
                  <mat-select
                    aria-label="Preview category"
                    [disabled]="loading()"
                    [ngModel]="categoryId()"
                    (ngModelChange)="categoryId.set($event)"
                  >
                    <mat-option value="">Choose a category</mat-option>
                    @for (column of categoryOptions(); track column.id) {
                      <mat-option [value]="column.id">{{ column.label }}</mat-option>
                    }
                  </mat-select>
                </mat-form-field>
                <mat-form-field appearance="outline" subscriptSizing="dynamic">
                  <mat-label>Calculate</mat-label>
                  <mat-select
                    aria-label="Preview aggregation"
                    [disabled]="loading()"
                    [ngModel]="aggregation()"
                    (ngModelChange)="aggregation.set($event)"
                  >
                    @for (value of aggregations; track value) {
                      <mat-option [value]="value">{{ aggregationLabel(value) }}</mat-option>
                    }
                  </mat-select>
                </mat-form-field>
                @if (temporalCategory()) {
                  <mat-form-field appearance="outline" subscriptSizing="dynamic">
                    <mat-label>Time interval</mat-label>
                    <mat-select
                      aria-label="Preview time interval"
                      [disabled]="loading()"
                      [ngModel]="timeBucket()"
                      (ngModelChange)="timeBucket.set($event)"
                    >
                      @for (bucket of timeBuckets; track bucket) {
                        <mat-option [value]="bucket">{{ bucket }}</mat-option>
                      }
                    </mat-select>
                  </mat-form-field>
                }
              }
              @for (slot of measureSlots(); track slot) {
                <mat-form-field appearance="outline" subscriptSizing="dynamic">
                  <mat-label>{{ measureLabel(slot) }}</mat-label>
                  <mat-select
                    [aria-label]="'Preview ' + measureLabel(slot)"
                    [disabled]="loading()"
                    [ngModel]="measureIds()[slot] || ''"
                    (ngModelChange)="selectMeasure(slot, $event)"
                  >
                    <mat-option value="">
                      {{
                        slot === 0 && aggregation() === 'count' && !rawChart()
                          ? 'Count rows'
                          : slot === 0
                            ? 'Choose a measure'
                            : 'None'
                      }}
                    </mat-option>
                    @for (column of measureOptions(); track column.id) {
                      <mat-option [value]="column.id">{{ column.label }}</mat-option>
                    }
                  </mat-select>
                </mat-form-field>
              }
            </div>
            @if (editorError()) {
              <p class="editor-error" role="alert">{{ editorError() }}</p>
            }
            <button
              mat-icon-button
              matTooltip="Update chart preview"
              aria-label="Update chart preview"
              type="button"
              class="primary-action"
              [disabled]="loading()"
              (click)="updateFromOptions()"
            >
              <mat-icon>preview</mat-icon>
            </button>
            <mat-form-field class="custom-change" appearance="outline" subscriptSizing="dynamic">
              <mat-label>Describe a change to the chart or filters</mat-label>
              <textarea
                matInput
                aria-label="Chart refinement request"
                rows="2"
                [value]="customRequest()"
                (input)="customRequest.set($any($event.target).value)"
                placeholder="For example: use a dark theme, or show only settled trades."
              ></textarea>
            </mat-form-field>
            <button
              mat-icon-button
              matTooltip="Preview requested changes"
              aria-label="Preview requested changes"
              type="button"
              [disabled]="loading() || !customRequest().trim()"
              (click)="submitCustomRequest()"
            >
              <mat-icon>auto_awesome</mat-icon>
            </button>
          </section>
        }
        @if (loading()) {
          <p class="preview-feedback" role="status">Preparing chart preview…</p>
        } @else if (error()) {
          <div class="preview-feedback" role="alert">
            <p>{{ error() }}</p>
            @if (canRetry()) {
              <button
                mat-icon-button
                type="button"
                matTooltip="Retry chart preview"
                aria-label="Retry chart preview"
                (click)="refresh()"
              >
                <mat-icon>refresh</mat-icon>
              </button>
            }
            @if (recoveryActions().length) {
              <p>{{ recoveryExplanation() }}</p>
              <div class="recovery-actions" aria-label="Chart recovery options">
                @for (action of recoveryActions(); track action.label) {
                  <button
                    mat-icon-button
                    type="button"
                    [matTooltip]="action.label"
                    [attr.aria-label]="action.label"
                    (click)="requestRefinement(action.prompt, errorCode())"
                  >
                    <mat-icon>build</mat-icon>
                  </button>
                }
              </div>
            }
          </div>
        } @else if (exchange(); as result) {
          @if (result.response.rows.length) {
            <app-integrated-chart
              [dataset]="result.response"
              [presentation]="currentPresentation()"
              [compact]="true"
              (presentationChange)="onPresentation($event)"
            />
          } @else {
            <p class="preview-feedback">
              No measured values match these proposed filters. Refine the chart or filters to
              continue.
            </p>
            <button
              mat-icon-button
              matTooltip="Help adjust the filters"
              aria-label="Help adjust the filters"
              type="button"
              (click)="
                requestRefinement(
                  'Help me broaden the current proposed filters to find rows for this chart. Explain which filter to change and ask me before changing the cohort.',
                  'EMPTY_CHART'
                )
              "
            >
              <mat-icon>filter_alt</mat-icon>
            </button>
            <button
              mat-icon-button
              type="button"
              matTooltip="Choose another measure"
              aria-label="Choose another measure"
              (click)="openEditor(true)"
            >
              <mat-icon>query_stats</mat-icon>
            </button>
          }
          <details class="chart-details">
            <summary>Chart details</summary>
            <p class="preview-cohort">
              {{ result.response.matchedRowCount | number }} matching records ·
              {{ result.response.plottedRowCount | number }} chart values
            </p>
            @if (result.response.notes.length) {
              <details class="preview-notes">
                <summary>How this preview was calculated</summary>
                <ul>
                  @for (note of result.response.notes; track $index) {
                    <li>{{ note }}</li>
                  }
                </ul>
              </details>
            }
            <details class="preview-values" (toggle)="valuesExpanded.set($any($event.target).open)">
              <summary>Inspect preview API request and returned values</summary>
              @if (valuesExpanded()) {
                <p>The chart uses every observation in this API response.</p>
                <pre aria-label="Chart preview API request and response">{{ exchangeJson() }}</pre>
              }
            </details>
          </details>
        }
      </section>
    }
  `,
  styles: [
    `
      :host {
        display: block;
        width: 100%;
        min-width: 0;
        --integrated-chart-height: 400px;
      }
      .chart-preview {
        padding: 16px 18px;
        border: 1px solid var(--mat-sys-outline-variant);
        border-radius: 10px;
        background: var(--mat-sys-surface-container-lowest);
        color: var(--mat-sys-on-surface);
      }
      .preview-heading {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: center;
        gap: 10px;
        margin-bottom: 8px;
      }
      h3 {
        margin: 0;
        font-size: 16px;
      }
      p {
        margin: 0 0 10px;
        font-size: 13px;
        line-height: 1.5;
      }
      .preview-heading p {
        color: var(--mat-sys-on-surface-variant);
      }
      .preview-title {
        display: flex;
        align-items: center;
        gap: 10px;
        min-width: 0;
      }
      .preview-title > div {
        min-width: 0;
      }
      .preview-title app-chart-type-icon {
        color: var(--mat-sys-primary);
        flex-shrink: 0;
        --chart-icon-size: 25px;
      }
      .preview-title h3 {
        font-size: 13px;
        line-height: 1.5;
        overflow-wrap: anywhere;
      }
      .preview-kicker {
        display: block;
        margin-bottom: 2px;
        font-size: 9px;
        font-weight: 500;
        letter-spacing: 0.8px;
        color: var(--mat-sys-on-surface-variant);
      }
      .preview-header-actions {
        display: flex;
        align-items: center;
        gap: 2px;
        flex-shrink: 0;
      }
      button:focus-visible,
      select:focus-visible,
      textarea:focus-visible,
      summary:focus-visible {
        outline: 2px solid var(--mat-sys-primary);
        outline-offset: 3px;
      }
      .preview-feedback {
        padding: 22px 8px;
      }
      .preview-cohort {
        margin: 10px 0;
        color: var(--mat-sys-on-surface-variant);
      }
      .chart-editor {
        padding: 12px;
        margin: 10px 0 16px;
        background: var(--mat-sys-surface-container-low);
        border: 1px solid var(--mat-sys-outline-variant);
        border-radius: 8px;
      }
      .editor-fields {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(min(180px, 100%), 1fr));
        gap: 10px;
        margin-bottom: 12px;
      }
      mat-form-field {
        width: 100%;
        min-width: 0;
        font-size: 12px;
      }
      textarea {
        width: 100%;
        min-width: 0;
        box-sizing: border-box;
        border: 0;
        padding: 0;
        background: transparent;
        color: var(--mat-sys-on-surface);
        font: inherit;
        font-weight: 400;
      }
      textarea {
        resize: vertical;
      }
      .custom-change {
        margin: 14px 0 8px;
      }
      .primary-action {
        background: var(--mat-sys-primary);
        color: var(--mat-sys-on-primary);
      }
      button:disabled {
        opacity: 0.55;
        cursor: default;
      }
      .editor-error {
        color: var(--mat-sys-error);
      }
      .recovery-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
      }
      details {
        margin-top: 10px;
        font-size: 12px;
      }
      .chart-details {
        padding-top: 8px;
        border-top: 1px solid var(--mat-sys-outline-variant);
        color: var(--mat-sys-on-surface-variant);
      }
      summary {
        cursor: pointer;
        padding: 6px 0;
      }
      li {
        margin: 5px 0;
      }
      pre {
        max-height: 300px;
        overflow: auto;
        padding: 12px;
        border-radius: 6px;
        background: var(--mat-sys-surface-container-low);
        white-space: pre-wrap;
        overflow-wrap: anywhere;
        font-size: 11px;
      }
      @media (max-width: 600px) {
        :host {
          --integrated-chart-height: 320px;
        }
        .chart-preview {
          padding: 12px;
        }
      }
    `,
  ],
})
export class ChartProposalPreviewComponent implements OnChanges, OnDestroy {
  private readonly reactiveState = injectUiState('ChartProposalPreviewComponent');

  @Input() request: ChartRequest | null = null;
  @Input() label = 'Chart preview';
  @Input() guidedEditor = false;
  @Input() presentation: ChartPresentation | null = null;
  @Input() generationResponse: GridCopilotResult | null = null;
  @Input() columns: readonly ColumnSpec[] = [];
  @Output() readonly presentationChange = new EventEmitter<ChartPresentation>();
  @Output() readonly previewChange = new EventEmitter<ChartPreviewExchange | null>();
  @Output() readonly refine = new EventEmitter<ChartRefinement>();
  @Output() readonly editChart = new EventEmitter<void>();
  readonly loading = this.reactiveState.signal(false);
  readonly error = this.reactiveState.signal('');
  readonly errorCode = this.reactiveState.signal('');
  readonly canRetry = this.reactiveState.signal(false);
  readonly editing = this.reactiveState.signal(false);
  readonly editorError = this.reactiveState.signal('');
  readonly customRequest = this.reactiveState.signal('');
  readonly chartType = this.reactiveState.signal<ChartPlan['type']>('column');
  readonly categoryId = this.reactiveState.signal('');
  readonly aggregation = this.reactiveState.signal<NonNullable<ChartPlan['aggregation']>>('sum');
  readonly timeBucket = this.reactiveState.signal<NonNullable<ChartPlan['timeBucket']>>('month');
  readonly measureIds = this.reactiveState.signal<string[]>([]);
  readonly categoryOptions = this.reactiveState.signal<ColumnSpec[]>([]);
  readonly measureOptions = this.reactiveState.signal<ColumnSpec[]>([]);
  readonly chartTypes = CHART_TYPES;
  readonly aggregations = CHART_AGGREGATIONS;
  readonly timeBuckets = CHART_TIME_BUCKETS;
  readonly exchange = this.reactiveState.signal<ChartPreviewExchange | null>(null);
  readonly valuesExpanded = this.reactiveState.signal(false);
  readonly currentPresentation = this.reactiveState.signal<ChartPresentation | null>(null);
  readonly exchangeJson = computed(() => JSON.stringify(this.exchange(), null, 2));
  private readonly api = inject(ExplorerDataService);
  private controller?: AbortController;
  private signature = '';

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['presentation']) this.currentPresentation.set(this.presentation);
    if (changes['columns']) {
      const metadata = new Map(
        chartColumnMetadata(this.columns).map((column) => [column.id, column]),
      );
      this.categoryOptions.set(
        this.columns.filter((column) =>
          ['dimension', 'temporal'].includes(metadata.get(column.id)!.role),
        ),
      );
      this.measureOptions.set(
        this.columns.filter((column) => metadata.get(column.id)!.role === 'measure'),
      );
    }
    if (!changes['request']) return;
    const signature = this.request ? JSON.stringify(this.request) : '';
    if (signature === this.signature) return;
    this.signature = signature;
    if (this.request) {
      this.chartType.set(this.request.plan.type);
      this.categoryId.set(this.request.plan.categoryColumnId ?? '');
      this.aggregation.set(this.request.plan.aggregation ?? 'sum');
      this.timeBucket.set(this.request.plan.timeBucket ?? 'month');
      this.measureIds.set([...this.request.plan.measureColumnIds]);
      this.editorError.set('');
      this.customRequest.set('');
      this.editing.set(false);
    }
    void this.refresh();
  }

  ngOnDestroy(): void {
    this.controller?.abort();
  }

  onPresentation(presentation: ChartPresentation): void {
    this.currentPresentation.set(presentation);
    this.presentationChange.emit(presentation);
  }

  openEditor(forceOpen = false): void {
    if (this.guidedEditor) this.editChart.emit();
    else this.editing.set(forceOpen || !this.editing());
  }

  chartTypeLabel(type: string): string {
    const name = type.replace(/([a-z])([A-Z])/g, '$1 $2').replace('Combo', 'combination');
    return name.charAt(0).toUpperCase() + name.slice(1);
  }
  aggregationLabel(value: string): string {
    return (
      (
        { sum: 'Total', avg: 'Average', min: 'Minimum', max: 'Maximum', count: 'Count' } as Record<
          string,
          string
        >
      )[value] ?? value
    );
  }
  rawChart(): boolean {
    return ['scatter', 'bubble', 'histogram'].includes(this.chartType());
  }
  temporalCategory(): boolean {
    return this.categoryOptions().some(
      (column) => column.id === this.categoryId() && ['date', 'datetime'].includes(column.kind),
    );
  }
  measureSlots(): number[] {
    if (['pie', 'donut', 'histogram'].includes(this.chartType())) return [0];
    return this.chartType() === 'scatter' ? [0, 1] : [0, 1, 2];
  }
  measureLabel(slot: number): string {
    if (this.chartType() === 'scatter' || this.chartType() === 'bubble')
      return ['X measure', 'Y measure', 'Bubble size'][slot];
    return slot === 0 ? 'Measure' : `Additional measure ${slot}`;
  }
  selectMeasure(slot: number, id: string): void {
    const selected = [...this.measureIds()];
    selected[slot] = id;
    this.measureIds.set(selected);
  }
  requestRefinement(prompt: string, reason?: string): void {
    if (this.loading()) return;
    this.refine.emit({ prompt, ...(reason ? { reason } : {}) });
  }
  submitCustomRequest(): void {
    const text = this.customRequest().trim();
    if (text) this.requestRefinement(text, 'CUSTOM_CHANGE');
  }
  updateFromOptions(): void {
    const category = this.categoryOptions().find((column) => column.id === this.categoryId());
    const selected = this.measureSlots()
      .map((slot) => this.measureOptions().find((column) => column.id === this.measureIds()[slot]))
      .filter((column): column is ColumnSpec => !!column);
    const type = this.chartType();
    const minimum =
      type === 'bubble'
        ? 3
        : type === 'scatter' || type.endsWith('Combo')
          ? 2
          : this.aggregation() === 'count' && !this.rawChart()
            ? 0
            : 1;
    if (
      (!this.rawChart() && !category) ||
      selected.length < minimum ||
      new Set(selected.map((column) => column.id)).size !== selected.length
    ) {
      this.editorError.set('Choose a category and the required distinct measures for this chart.');
      return;
    }
    if (/line|area/i.test(type) && !type.endsWith('Combo') && !this.temporalCategory()) {
      this.editorError.set('Choose a date field for a line or area chart.');
      return;
    }
    const labels = selected.map((column) => JSON.stringify(column.label));
    let detail: string;
    if (type === 'scatter' || type === 'bubble')
      detail = `Use ${labels[0]} for X and ${labels[1]} for Y${type === 'bubble' ? ` and ${labels[2]} for bubble size` : ''}, one point per complete matching row.`;
    else if (type === 'histogram')
      detail = `Show the distribution of ${labels[0]}, one observation per nonblank matching value.`;
    else
      detail = `Show ${this.aggregation() === 'count' && !labels.length ? 'a count of rows' : `${this.aggregationLabel(this.aggregation()).toLowerCase()} of ${labels.join(' and ')}`} by ${JSON.stringify(category!.label)}${this.temporalCategory() ? ` using calendar ${this.timeBucket()} buckets` : ''}.`;
    if (type === 'customCombo')
      detail += ` Render ${labels[0]} as grouped columns and every remaining measure as a line on its own right-side axis.`;
    this.editorError.set('');
    if (!this.request) return;
    const plan: ChartPlan = {
      type,
      categoryColumnId: this.rawChart() ? null : category!.id,
      measureColumnIds: selected.map((column) => column.id),
      aggregation: this.rawChart() ? null : this.aggregation(),
      timeBucket: !this.rawChart() && this.temporalCategory() ? this.timeBucket() : null,
      title: this.request.plan.title,
      appearance: this.currentPresentation()?.appearance ?? this.request.plan.appearance,
      ...(type === 'customCombo'
        ? {
            seriesChartTypes: selected.map((column, index) => ({
              colId: column.id,
              chartType: index ? ('line' as const) : ('groupedColumn' as const),
              secondaryAxis: index > 0,
            })),
          }
        : {}),
    };
    const previous = this.request.plan;
    if (
      plan.categoryColumnId !== previous.categoryColumnId ||
      plan.aggregation !== previous.aggregation ||
      plan.timeBucket !== previous.timeBucket ||
      JSON.stringify(plan.measureColumnIds) !== JSON.stringify(previous.measureColumnIds)
    ) {
      const measures = selected.map((column) => column.label).join(' and ');
      plan.title = (
        this.rawChart()
          ? type === 'histogram'
            ? `${measures} distribution`
            : measures
          : `${plan.aggregation === 'count' && !selected.length ? 'Record count' : `${this.aggregationLabel(this.aggregation())} ${measures}`} by ${category!.label}${plan.timeBucket ? ` (${plan.timeBucket})` : ''}`
      ).slice(0, 160);
    }
    this.refine.emit({
      prompt: `Update this preview to a ${this.chartTypeLabel(type)} chart. ${detail}`,
      reason: 'CHART_OPTIONS',
      plan,
    });
  }
  recoveryExplanation(): string {
    if (this.errorCode() === 'CHART_CARDINALITY')
      return 'Use fewer categories or a shorter date range, then review the updated preview.';
    if (this.errorCode() === 'CHART_SIZE')
      return 'Narrow the source rows before creating the chart. No rows were silently removed.';
    return 'Choose how to adjust the chart, then review the new preview before applying.';
  }
  recoveryActions(): { label: string; prompt: string }[] {
    const code = this.errorCode();
    if (!code.startsWith('CHART_') || !this.request) return [];
    const plan = this.request.plan;
    const category = this.columns.find((column) => column.id === plan.categoryColumnId);
    const date =
      category && ['date', 'datetime'].includes(category.kind)
        ? category
        : this.categoryOptions().find((column) => ['date', 'datetime'].includes(column.kind));
    const datePrompt = `Help me choose a narrower date range${date ? ` for ${JSON.stringify(date.label)}` : ''} for the current proposed chart. Ask me for the start and end dates before changing the filters.`;
    if (code === 'CHART_CARDINALITY') {
      const bucket =
        plan.timeBucket === 'month' ? 'quarter' : plan.timeBucket === 'quarter' ? 'year' : 'month';
      const actions =
        category && ['date', 'datetime'].includes(category.kind) && plan.timeBucket !== 'year'
          ? [
              {
                label: `Group by ${bucket}`,
                prompt: `Keep the current proposed filters, chart type, selected measures and aggregation. Group ${JSON.stringify(category.label)} into calendar ${bucket} buckets and refresh the chart preview.`,
              },
            ]
          : [];
      const smaller = this.categoryOptions().find(
        (column) => column.values && column.values.length <= 20 && column.id !== category?.id,
      );
      if (smaller && !/line|area/i.test(plan.type))
        actions.push({
          label: `Group by ${smaller.label}`,
          prompt: `Keep the current proposed filters and measures. Group the chart by ${JSON.stringify(smaller.label)} instead, using the same aggregation and a column chart.`,
        });
      actions.push({ label: 'Choose a date range', prompt: datePrompt });
      return actions;
    }
    if (code === 'CHART_SIZE')
      return [
        { label: 'Choose a date range', prompt: datePrompt },
        {
          label: 'Help narrow the filters',
          prompt:
            'Help me narrow the current proposed filters so the chart includes fewer source rows. Offer concrete filter choices from this data source and ask me which to use.',
        },
      ];
    if (code === 'CHART_NEGATIVE_PROPORTION')
      return [
        {
          label: 'Show values as columns',
          prompt:
            'Change the current proposed chart to a column chart so negative values remain visible. Keep its filters, category, measures and aggregation.',
        },
      ];
    if (code === 'CHART_NEGATIVE_SIZE') {
      const size = this.columns.find((column) => column.id === plan.measureColumnIds[2]);
      return [
        {
          label: 'Use nonnegative sizes',
          prompt: `Keep this bubble chart and the current proposed filters; additionally require ${JSON.stringify(size?.label ?? plan.measureColumnIds[2])} to be greater than or equal to zero for bubble size. Refresh the preview.`,
        },
      ];
    }
    return [
      {
        label: 'Help choose chart fields',
        prompt: `Help me revise the current proposed chart after this validation message: ${this.error()}. Offer valid chart fields or options from the current data source and ask me which to use.`,
      },
    ];
  }

  async refresh(): Promise<void> {
    this.controller?.abort();
    this.exchange.set(null);
    this.error.set('');
    this.errorCode.set('');
    this.canRetry.set(false);
    this.valuesExpanded.set(false);
    this.previewChange.emit(null);
    if (!this.request) {
      this.loading.set(false);
      return;
    }
    const controller = new AbortController();
    this.controller = controller;
    const request = structuredClone(this.request);
    this.loading.set(true);
    try {
      const response = await this.api.request<ChartResponse>(
        'analytics/chart',
        request,
        controller.signal,
      );
      if (controller.signal.aborted || this.controller !== controller) return;
      const exchange = { request, response };
      this.exchange.set(exchange);
      this.previewChange.emit(exchange);
    } catch (error) {
      if (controller.signal.aborted || this.controller !== controller) return;
      this.error.set(
        error instanceof Error
          ? error.message
          : 'The chart preview could not be loaded. Please retry.',
      );
      const details = error as { code?: string; status?: number } | null;
      const code = details?.code ?? 'NETWORK_ERROR';
      this.errorCode.set(code);
      this.canRetry.set(
        !code.startsWith('CHART_') &&
          (!details?.status || details.status >= 500 || [408, 429].includes(details.status)),
      );
    } finally {
      if (!controller.signal.aborted && this.controller === controller) this.loading.set(false);
    }
  }
}
