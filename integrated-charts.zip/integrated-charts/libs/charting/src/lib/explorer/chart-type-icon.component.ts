import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';

type Mark = { d: string; fill?: boolean; opacity?: number };
const line = (d: string, opacity = 1): Mark => ({ d, opacity });
const fill = (d: string, opacity = 1): Mark => ({ d, fill: true, opacity });
const icons: Record<string, Mark[]> = {
  groupedColumn: [
    fill('M3 13h3v7H3z M10 5h3v15h-3z M17 9h3v11h-3z'),
    fill('M6 16h2v4H6z M13 10h2v10h-2z M20 13h2v7h-2z', 0.4),
  ],
  stackedColumn: [
    fill('M4 13h4v7H4z M10 10h4v10h-4z M16 14h4v6h-4z'),
    fill('M4 7h4v5H4z M10 3h4v6h-4z M16 8h4v5h-4z', 0.4),
  ],
  normalizedColumn: [
    fill('M4 13h4v7H4z M10 10h4v10h-4z M16 15h4v5h-4z'),
    fill('M4 4h4v8H4z M10 4h4v5h-4z M16 4h4v10h-4z', 0.4),
  ],
  groupedBar: [
    fill('M4 3h10v3H4z M4 10h16v3H4z M4 17h12v3H4z'),
    fill('M4 6h6v2H4z M4 13h11v2H4z M4 20h8v2H4z', 0.4),
  ],
  stackedBar: [
    fill('M4 4h7v4H4z M4 10h10v4H4z M4 16h5v4H4z'),
    fill('M12 4h5v4h-5z M15 10h6v4h-6z M10 16h5v4h-5z', 0.4),
  ],
  normalizedBar: [
    fill('M4 4h7v4H4z M4 10h10v4H4z M4 16h5v4H4z'),
    fill('M12 4h8v4h-8z M15 10h5v4h-5z M10 16h10v4H10z', 0.4),
  ],
  line: [
    line('M3 18 8 11 13 14 21 5'),
    fill('M2 17h2v2H2z M7 10h2v2H7z M12 13h2v2h-2z M20 4h2v2h-2z'),
  ],
  stackedLine: [line('M3 18 8 14 13 16 21 11'), line('M3 12 8 6 13 9 21 3', 0.45)],
  normalizedLine: [line('M3 17 8 12 14 15 21 8'), line('M3 5h18', 0.45), line('M3 20h18', 0.25)],
  area: [fill('M3 19 3 14 8 9 13 12 21 4 21 19z', 0.3), line('M3 14 8 9 13 12 21 4')],
  stackedArea: [
    fill('M3 20 3 15 9 11 14 14 21 9 21 20z', 0.65),
    fill('M3 14 3 9 9 4 14 7 21 3 21 8 14 13 9 10z', 0.3),
  ],
  normalizedArea: [
    fill('M3 20 3 14 9 9 15 13 21 8 21 20z', 0.65),
    fill('M3 4h18v3l-6 5-6-4-6 5z', 0.3),
  ],
  pie: [fill('M11 3a9 9 0 1 0 10 10H11z', 0.35), fill('M13 2v9h9a9 9 0 0 0-9-9')],
  donut: [
    line('M11 3a9 9 0 1 0 10 10', 0.4),
    line('M14 3.2a9 9 0 0 1 6.8 6.8'),
    line('M11 7a5 5 0 1 0 6 6', 0.4),
    line('M14 7.4a5 5 0 0 1 2.6 2.6'),
  ],
  scatter: [fill('M4 16h3v3H4z M7 9h3v3H7z M11 13h3v3h-3z M15 6h3v3h-3z M19 3h3v3h-3z')],
  bubble: [
    fill('M3 15a3 3 0 1 0 6 0a3 3 0 1 0-6 0', 0.45),
    fill('M10 9a5 5 0 1 0 10 0a5 5 0 1 0-10 0', 0.7),
    fill('M16 19a2 2 0 1 0 4 0a2 2 0 1 0-4 0'),
  ],
  histogram: [fill('M2 16h4v4H2z M6 9h4v11H6z M10 3h4v17h-4z M14 7h4v13h-4z M18 14h4v6h-4z', 0.7)],
  columnLineCombo: [
    fill('M4 13h4v7H4z M10 8h4v12h-4z M16 11h4v9h-4z', 0.3),
    line('M3 10 8 5 14 7 21 2'),
  ],
  areaColumnCombo: [
    fill('M3 20V9l6-5 6 5 6-3v14z', 0.2),
    fill('M5 14h3v6H5z M11 10h3v10h-3z M17 12h3v8h-3z', 0.8),
  ],
  customCombo: [
    fill('M3 20V13l6-4 6 5 6-4v10z', 0.2),
    fill('M4 15h3v5H4z M10 12h3v8h-3z M16 16h3v4h-3z', 0.55),
    line('M3 9 8 4 14 6 21 2'),
  ],
};

/** Distinct, theme-colored glyphs for every supported chart family and variant. */
@Component({
  selector: 'app-chart-type-icon',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { 'aria-hidden': 'true' },
  template: `
    <svg viewBox="0 0 24 24" focusable="false" aria-hidden="true">
      @for (mark of marks(); track $index) {
        <path
          [attr.d]="mark.d"
          [attr.fill]="mark.fill ? 'currentColor' : 'none'"
          [attr.stroke]="mark.fill ? 'none' : 'currentColor'"
          [attr.opacity]="mark.opacity ?? 1"
        />
      }
    </svg>
  `,
  styles: [
    `
      :host {
        display: inline-flex;
        flex: 0 0 auto;
        width: var(--chart-icon-size, 24px);
        height: var(--chart-icon-size, 24px);
        vertical-align: middle;
        color: inherit;
      }
      svg {
        width: 100%;
        height: 100%;
        overflow: visible;
      }
      path {
        stroke-width: 1.7;
        stroke-linejoin: round;
        stroke-linecap: round;
      }
    `,
  ],
})
export class ChartTypeIconComponent {
  readonly type = input<string | null | undefined>('column');
  readonly marks = computed(() => {
    const type = this.type();
    return (
      icons[
        type === 'column'
          ? 'groupedColumn'
          : type === 'doughnut'
            ? 'donut'
            : type === 'bar'
              ? 'groupedBar'
              : (type ?? 'groupedColumn')
      ] ?? icons['groupedColumn']
    );
  });
}
