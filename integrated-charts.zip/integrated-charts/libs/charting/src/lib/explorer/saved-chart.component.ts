import { FilterValuesFormComponent } from '../rendering/filter-values-form.component';
import type { FilterPreviewSource } from '../rendering/filter-preview';
import { injectUiState } from '../core/state/index';
import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output,
  inject,
} from '@angular/core';
import { Clipboard } from '@angular/cdk/clipboard';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import type { ChartResponse } from '../core/domain/integrated-chart';
import { IntegratedChartComponent, type ChartPresentation } from './integrated-chart.component';
import { ChartDataSummaryComponent } from './chart-data-summary.component';
import type { GridCopilotResult } from '../core/domain/grid-copilot';
import { ChartTypeIconComponent } from './chart-type-icon.component';
import type { ViewChart, ViewChartDataScope } from '../core/domain/workspace.types';
import type { ColumnSpec } from '../core/domain/schema';
import { describeFilterScope } from '../rendering/filter-summary';
import { FilterScopeChipComponent } from '../rendering/filter-scope-chip.component';

/** Each chart keeps its appearance and saved data scope over the shared dataset. */
export interface SavedChartItem extends ViewChart {
  /** The actual structured response received when the chart was proposed. */
  generationResponse?: GridCopilotResult;
}

@Component({
  selector: 'app-saved-chart',
  standalone: true,
  imports: [
    MatButtonModule,
    MatDividerModule,
    MatIconModule,
    MatMenuModule,
    MatTooltipModule,
    IntegratedChartComponent,
    ChartDataSummaryComponent,
    ChartTypeIconComponent,
    FilterScopeChipComponent,
    FilterValuesFormComponent,
  ],
  template: `
    <article
      class="saved-chart-card"
      [class.carousel-card]="carousel"
      [attr.data-chart-id]="item.id"
      [attr.aria-labelledby]="item.id + '-title'"
      [attr.aria-busy]="loading"
    >
      <header>
        <div class="chart-heading">
          <div class="chart-title">
            <app-chart-type-icon [type]="item.plan.type" />
            <h2 [id]="item.id + '-title'">{{ data?.title ?? item.plan.title }}</h2>
            @if (showRecordCounts && data; as chart) {
              <span class="record-count" [matTooltip]="rowLabel + 's in this chart'"
                >{{ chart.matchedRowCount.toLocaleString() }} {{ rowLabel }}s</span
              >
            }
          </div>
          @if (showDescriptions && item.description?.trim()) {
            <p class="chart-description">{{ item.description }}</p>
          }
        </div>
        <div class="chart-actions">
          <button
            mat-icon-button
            type="button"
            matTooltip="Edit chart"
            aria-label="Refine in chat"
            [disabled]="disabled"
            (click)="refine.emit()"
          >
            <mat-icon>edit</mat-icon>
          </button>
          <button
            mat-icon-button
            type="button"
            [matMenuTriggerFor]="moreMenu"
            [disabled]="disabled"
            aria-label="More chart actions"
            matTooltip="More"
          >
            <mat-icon>more_vert</mat-icon>
          </button>
          <mat-menu #moreMenu="matMenu">
            @if (showFocus) {
              <button mat-menu-item (click)="focusChart.emit()">
                <mat-icon>open_in_full</mat-icon><span>Expand</span>
              </button>
            }
            @if (showResize) {
              <button mat-menu-item (click)="expand.emit()">
                <mat-icon>{{ expanded ? 'width_normal' : 'width_wide' }}</mat-icon
                ><span>{{ expanded ? 'Standard width' : 'Wide' }}</span>
              </button>
            }
            <button mat-menu-item (click)="duplicate.emit()">
              <mat-icon>content_copy</mat-icon><span>Duplicate chart</span>
            </button>
            <button mat-menu-item (click)="copyConfiguration()" [disabled]="loading">
              <mat-icon>data_object</mat-icon
              ><span>{{ copied() ? 'Copied' : 'Copy configuration' }}</span>
            </button>
            <mat-divider />
            <button mat-menu-item class="destructive" (click)="remove.emit()">
              <mat-icon>delete_outline</mat-icon><span>Remove chart</span>
            </button>
          </mat-menu>
        </div>
      </header>
      @if (showFilters && valuesEditable) {
        <workspace-filter-values-form
          [columns]="columns"
          [scope]="scope"
          [label]="item.plan.title"
          [disabled]="disabled"
          (scopeChange)="scopeChange.emit($event)"
        />
      }
      <div class="chart-scope">
        @if (showRecordCounts && data; as chart) {
          <app-chart-data-summary [data]="chart" />
        }
        @if (showFilters && item.filterControls?.visible !== false) {
          <workspace-filter-scope-chip
            [scope]="scope"
            [preview]="preview"
            [columns]="columns"
            [componentLabel]="item.plan.title"
            component="chart"
            [scopeId]="item.id"
            [independent]="!!item.dataScope"
            [editable]="true"
            access="expression"
            [disabled]="disabled"
            (scopeChange)="scopeChange.emit($event)"
            (reset)="scopeChange.emit({ mode: scope.mode, filterModel: null })"
            (makeIndependent)="scopeChange.emit(scope)"
          />
        }
      </div>
      @if (loading) {
        <div class="chart-feedback" role="status">
          <mat-icon class="loading-icon" aria-hidden="true">query_stats</mat-icon>
          <p>Updating chart from the matching records…</p>
        </div>
      } @else if (error) {
        <div class="chart-feedback" role="alert">
          <mat-icon aria-hidden="true">error_outline</mat-icon>
          <h3>This chart could not be loaded</h3>
          <p>{{ error }}</p>
          <button
            mat-icon-button
            type="button"
            matTooltip="Retry chart data"
            aria-label="Retry chart data"
            (click)="retry.emit()"
          >
            <mat-icon>refresh</mat-icon>
          </button>
        </div>
      } @else if (data; as chart) {
        @if (chart.rows.length) {
          <app-integrated-chart
            [compact]="!expanded"
            [disabled]="disabled"
            [dataset]="chart"
            [presentation]="item.presentation"
            (presentationChange)="presentationChange.emit($event)"
          />
        } @else {
          <div class="chart-feedback" role="status">
            <mat-icon aria-hidden="true">filter_alt_off</mat-icon>
            <h3>No measured values to chart</h3>
            <p>Adjust this chart's filters or choose another measure.</p>
          </div>
        }
      } @else {
        <div class="chart-feedback" role="status">
          <mat-icon aria-hidden="true">query_stats</mat-icon>
          <p>The chart will appear when the data is ready.</p>
        </div>
      }
    </article>
  `,
  styles: [
    `
      :host {
        display: block;
        min-width: 0;
        height: 100%;
        --integrated-chart-height: 300px;
        container-type: inline-size;
      }
      .saved-chart-card {
        display: flex;
        flex-direction: column;
        height: 100%;
        min-width: 0;
        min-height: 440px;
        padding: 14px;
        border: 1px solid var(--mat-sys-outline-variant);
        border-radius: 16px;
        background: var(--mat-sys-surface-container-lowest);
        color: var(--mat-sys-on-surface);
      }
      .carousel-card {
        border: 0;
        border-radius: 0;
        min-height: 360px;
      }
      header {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 12px;
        flex-wrap: wrap;
        padding-bottom: 10px;
      }
      .chart-heading {
        min-width: 0;
        flex: 1 1 150px;
      }
      .chart-title {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 6px 9px;
      }
      .chart-title app-chart-type-icon {
        color: var(--mat-sys-primary);
        flex-shrink: 0;
        --chart-icon-size: 22px;
      }
      .record-count {
        flex-shrink: 0;
        padding: 2px 7px;
        border-radius: 4px;
        background: var(--mat-sys-surface-container);
        color: var(--mat-sys-on-surface-variant);
        font-size: 11px;
        font-variant-numeric: tabular-nums;
        white-space: nowrap;
      }
      .destructive {
        color: var(--mat-sys-error);
      }
      h2 {
        margin: 0;
        font-size: 15px;
        line-height: 1.4;
        font-weight: 600;
        overflow-wrap: anywhere;
      }
      .chart-heading p {
        margin: 4px 0 0;
        font-size: 12px;
        line-height: 1.5;
        color: var(--mat-sys-on-surface-variant);
        white-space: pre-wrap;
        overflow-wrap: anywhere;
      }
      .chart-actions {
        display: flex;
        align-items: center;
        flex: 0 0 auto;
        gap: 2px;
        margin-left: auto;
      }
      .chart-actions > button {
        width: 32px;
        height: 32px;
        padding: 4px;
        --mdc-icon-button-state-layer-size: 32px;
      }
      .chart-scope {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 6px 10px;
        padding-bottom: 8px;
        border-bottom: 1px solid var(--mat-sys-outline-variant);
        margin-bottom: 8px;
        min-width: 0;
      }
      .filter-description {
        display: flex;
        gap: 6px;
        align-items: flex-start;
        margin: 4px 0 8px;
        font-size: 11px;
        line-height: 1.5;
        overflow-wrap: anywhere;
        color: var(--mat-sys-on-surface-variant);
      }
      .filter-description mat-icon {
        width: 15px;
        height: 15px;
        font-size: 15px;
        margin-top: 1px;
        flex-shrink: 0;
      }
      .filter-description strong {
        font-weight: 500;
        color: var(--mat-sys-on-surface);
      }
      .chart-feedback {
        display: flex;
        flex: 1;
        min-height: 240px;
        padding: 28px 18px;
        align-items: center;
        justify-content: center;
        flex-direction: column;
        gap: 10px;
        text-align: center;
        color: var(--mat-sys-on-surface-variant);
      }
      .chart-feedback h3,
      .chart-feedback p {
        margin: 0;
        max-width: 380px;
        font-size: 13px;
        line-height: 1.5;
      }
      .chart-feedback h3 {
        color: var(--mat-sys-on-surface);
      }
      .chart-feedback mat-icon {
        color: var(--mat-sys-primary);
      }
      footer {
        display: flex;
        flex-wrap: wrap;
        gap: 4px 16px;
        padding-top: 10px;
        color: var(--mat-sys-on-surface-variant);
        font-size: 11px;
        line-height: 1.5;
      }
      @media (max-width: 600px) {
        .saved-chart-card {
          padding: 12px;
        }
      }
    `,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SavedChartComponent {
  @Input() preview?: FilterPreviewSource;
  private readonly reactiveState = injectUiState('SavedChartComponent');

  @Input() showFilters = true;
  @Input() valuesEditable = false;
  @Input() showRecordCounts = true;
  @Input() showDescriptions = true;
  @Input() expanded = false;
  @Input() showResize = true;
  @Input() showFocus = true;
  @Input() carousel = false;
  @Input() disabled = false;
  @Input() columns: readonly ColumnSpec[] = [];
  @Input() scope: ViewChartDataScope = { mode: 'advanced', filterModel: null };
  @Output() readonly scopeChange = new EventEmitter<ViewChartDataScope>();
  @Output() readonly expand = new EventEmitter<void>();
  @Output() readonly focusChart = new EventEmitter<void>();
  @Input({ required: true }) item!: SavedChartItem;
  @Input() data: ChartResponse | null = null;
  @Input() loading = false;
  @Input() error = '';
  @Input() rowLabel = 'record';
  @Output() readonly presentationChange = new EventEmitter<ChartPresentation>();
  @Output() readonly refine = new EventEmitter<void>();
  @Output() readonly remove = new EventEmitter<void>();
  @Output() readonly retry = new EventEmitter<void>();
  @Output() readonly duplicate = new EventEmitter<void>();
  private readonly clipboard = inject(Clipboard);
  readonly copied = this.reactiveState.signal(false);
  private copiedTimer?: ReturnType<typeof setTimeout>;
  get filterDescription(): string {
    return describeFilterScope(this.scope, this.columns);
  }
  /** The chart's saved configuration (or its generation response) as JSON, never row data. */
  copyConfiguration() {
    const value = this.item.generationResponse ?? {
      plan: this.item.plan,
      dataScope: this.item.dataScope,
      presentation: this.item.presentation,
    };
    if (this.clipboard.copy(JSON.stringify(value, null, 2))) {
      this.copied.set(true);
      clearTimeout(this.copiedTimer);
      this.copiedTimer = setTimeout(() => this.copied.set(false), 1800);
    }
  }
}
