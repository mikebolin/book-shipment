import type { IServerSideDatasource, IServerSideGetRowsRequest } from 'ag-grid-community';
import { analyticsGroupKey, type AnalyticsRowsRequest } from '../core/domain/analytics-query';
import type { Mode, GridModel } from '../core/domain/contracts';
import type { CalculatedColumnDefinition } from '../core/domain/calculated-columns';
import type { SqlDataset } from '../core/domain/sql-dataset';
import { Fault } from '../core/domain/engine';
import { validateStudioQueryResult } from './studio-query-result';
import {
  compileStudioPivotDiscovery,
  compileStudioQuery,
  type StudioQuery,
  type StudioQueryExecutor,
  type StudioQueryResult,
  type SqlValue,
  type StudioExecutionContext,
} from '../core/domain/studio-query';

export const STUDIO_BLOCK_SIZE = 250;
export const STUDIO_CACHE_BLOCKS = 3;

export function studioRowsRequest(
  request: IServerSideGetRowsRequest,
  mode: Mode,
  definitions: readonly CalculatedColumnDefinition[],
): AnalyticsRowsRequest {
  return {
    mode,
    calculatedColumnIds: definitions.map((d) => d.id),
    request: {
      startRow: request.startRow ?? 0,
      endRow: request.endRow ?? (request.startRow ?? 0) + STUDIO_BLOCK_SIZE,
      filterModel: (request.filterModel ?? null) as GridModel,
      // AG Grid also sends display metadata (for example sort item `type`).
      // Keep the compiler contract independent of that version-specific metadata.
      sortModel: request.sortModel.map(({ colId, sort }) => ({ colId, sort })),
      rowGroupCols: request.rowGroupCols,
      valueCols: request.valueCols,
      pivotCols: request.pivotCols,
      pivotMode: request.pivotMode,
      groupKeys: request.groupKeys,
    },
  };
}

/** Every column a filter model constrains. */
function filterColumns(model: GridModel): Set<string> {
  const ids = new Set<string>();
  const walk = (node: unknown): void => {
    if (!node || typeof node !== 'object') return;
    const record = node as Record<string, unknown>;
    if (typeof record['colId'] === 'string') ids.add(record['colId']);
    if (Array.isArray(record['conditions'])) record['conditions'].forEach(walk);
  };
  walk(model);
  return ids;
}
/** True when every rule inside the node constrains one of the given columns. */
function constrainsOnly(node: unknown, ids: Set<string>): boolean {
  if (!node || typeof node !== 'object') return false;
  const record = node as Record<string, unknown>;
  if (Array.isArray(record['conditions']))
    return (
      record['conditions'].length > 0 && record['conditions'].every((c) => constrainsOnly(c, ids))
    );
  return typeof record['colId'] === 'string' && ids.has(record['colId']);
}

/**
 * A dashboard filter context combined with an element's own advanced filter. The dashboard
 * filter supplies the values for the columns it constrains: an element's top-level conditions on
 * those columns are defaults it replaces (so a dashboard can widen as well as narrow them), while
 * conditions on other columns stay ANDed.
 */
export function combineFilterModels(mode: Mode, scope: GridModel, model: GridModel): GridModel {
  const empty = (value: GridModel) =>
    value == null || (typeof value === 'object' && Object.keys(value).length === 0);
  if (empty(scope)) return empty(model) ? null : model;
  if (mode !== 'advanced')
    throw new Fault('SCOPE', 'A dashboard scope requires the advanced filter mode.');
  if (empty(model)) return scope;
  const ids = filterColumns(scope);
  const node = model as Record<string, unknown>;
  const conditions =
    node['filterType'] === 'join' && node['type'] === 'AND' && Array.isArray(node['conditions'])
      ? (node['conditions'] as unknown[])
      : [model];
  const kept = conditions.filter((condition) => !constrainsOnly(condition, ids));
  if (!kept.length) return scope;
  const remainder: GridModel =
    kept.length === 1
      ? (kept[0] as GridModel)
      : { filterType: 'join', type: 'AND', conditions: kept };
  return { filterType: 'join', type: 'AND', conditions: [scope, remainder] };
}

export interface StudioDatasourceOptions {
  context(): StudioExecutionContext & { mode: Mode };
  /** Optional dashboard scope (time window, status, selected interval) shared by every block. */
  scope?(): GridModel;
  executor: StudioQueryExecutor;
  compiled?(query: StudioQuery): void;
  loaded?(query: StudioQuery, result: StudioQueryResult): void;
  loading?(pending: number): void;
  error?(error: Error): void;
}

/** Owns request cancellation and blocks; AG Grid owns cache eviction and route stores. */
export function createStudioDatasource(options: StudioDatasourceOptions): IServerSideDatasource {
  const active = new Map<string, AbortController>();
  let destroyed = false;
  let signature = '';
  let revision = 0;
  let discovery: { key: string; result: Promise<SqlValue[][]> } | undefined;
  let discoveryController: AbortController | undefined;
  const cancel = () => {
    for (const c of active.values()) c.abort();
    active.clear();
    discoveryController?.abort();
  };
  return {
    getRows(params) {
      if (destroyed) return;
      try {
        const context = options.context();
        const input = studioRowsRequest(params.request, context.mode, context.definitions);
        const scope = options.scope?.() ?? null;
        if (scope !== null)
          input.request.filterModel = combineFilterModels(
            context.mode,
            scope,
            input.request.filterModel,
          );
        const { startRow, endRow, groupKeys, ...shape } = input.request;
        const next = JSON.stringify([
          context.mode,
          context.sourceId,
          context.tenant,
          context.dataset,
          context.definitions,
          shape,
        ]);
        if (signature !== next) {
          signature = next;
          revision++;
          cancel();
          discovery = undefined;
        }
        const current = revision;
        const key = JSON.stringify([groupKeys, startRow, endRow]);
        active.get(key)?.abort();
        const controller = new AbortController();
        active.set(key, controller);
        options.loading?.(active.size);
        const live = () =>
          !destroyed &&
          revision === current &&
          !controller.signal.aborted &&
          active.get(key) === controller;
        void (async () => {
          try {
            let pivotValues: SqlValue[][] = [];
            if (input.request.pivotMode && input.request.pivotCols.length) {
              if (!discovery) {
                const statement = compileStudioPivotDiscovery(
                  input,
                  context.tenant,
                  context.dataset,
                  context.definitions,
                );
                discoveryController = new AbortController();
                discovery = {
                  key: next,
                  result: options.executor.discoverPivots(
                    statement,
                    input,
                    discoveryController.signal,
                    context,
                  ),
                };
              }
              pivotValues = await discovery.result;
            }
            if (!live()) return;
            const query = compileStudioQuery(
              input,
              context.tenant,
              context.dataset,
              context.definitions,
              pivotValues,
            );
            options.compiled?.(query);
            const result = await options.executor.execute(query, controller.signal, context);
            if (!live() || params.api.isDestroyed()) return;
            validateStudioQueryResult(query, result, context.dataset);
            const rowData = result.rowData.map((row) =>
              query.groupField
                ? { ...row, [query.groupField]: analyticsGroupKey(row[query.groupField] ?? null) }
                : row,
            );
            params.success({
              rowData,
              rowCount: result.rowCount,
              ...(!groupKeys.length ? { grandTotalData: result.grandTotalData ?? null } : {}),
              ...(query.pivotResultFields ? { pivotResultFields: query.pivotResultFields } : {}),
            });
            options.loaded?.(query, result);
          } catch (error) {
            if (!live() || params.api.isDestroyed()) return;
            discovery = undefined;
            params.fail();
            options.error?.(error instanceof Error ? error : new Error(String(error)));
          } finally {
            if (active.get(key) === controller) active.delete(key);
            if (!destroyed) options.loading?.(active.size);
          }
        })();
      } catch (error) {
        revision++;
        cancel();
        signature = '';
        discovery = undefined;
        options.loading?.(0);
        params.fail();
        options.error?.(error instanceof Error ? error : new Error(String(error)));
      }
    },
    destroy() {
      destroyed = true;
      revision++;
      cancel();
      discovery = undefined;
      options.loading?.(0);
    },
  };
}
