import { GridPopupLayer } from '../ui/grid-popup-layer';
import { injectUiState } from '../core/state/index';
import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  Output,
  SimpleChanges,
  ViewChild,
  effect,
  inject,
  untracked,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDialog, type MatDialogRef } from '@angular/material/dialog';
import {
  ClientSideRowModelModule,
  ModuleRegistry,
  createGrid,
  type ChartModel,
  type ChartRef,
  type GridApi,
} from 'ag-grid-community';
import { IntegratedChartsModule } from 'ag-grid-enterprise';
import {
  CHART_THEMES,
  type ChartAppearance,
  type ChartDataset,
} from '../core/domain/integrated-chart';
import type { DashboardChart } from '../core/domain/dashboard';
import { AppThemeService } from './app-theme.service';
import { EXPLORER_CONTEXT } from './explorer-context';
import { chartPreviewTurn } from './chart-preview-scheduler';
import { applyHistogramBins } from './chart-histogram-options';
import { ChartTypeIconComponent } from './chart-type-icon.component';
import {
  ChartFormatDialogComponent,
  type ChartFormatSettings,
} from './chart-format-dialog.component';

/** Native presentation state contains formatting and column references, never source rows. */
export interface ChartPresentation {
  signature: string;
  /** Live render id only; saved views drop it because AG Charts regenerates it on restore. */
  chartId?: string;
  chartType: ChartModel['chartType'];
  theme: string;
  model: ChartModel;
  appearance: ChartAppearance;
  requestedAppearance: ChartAppearance | null;
  requestedTitle: string;
}

let chartsModule: Promise<void> | undefined;
function loadCharts(): Promise<void> {
  return (chartsModule ??= import('ag-charts-community')
    .then(({ AgChartsCommunityModule }) => {
      ModuleRegistry.registerModules([
        ClientSideRowModelModule,
        IntegratedChartsModule.with(AgChartsCommunityModule),
      ]);
    })
    .catch((error) => {
      chartsModule = undefined;
      throw error;
    }));
}

@Component({
  selector: 'app-integrated-chart',
  host: { '[class.readonly-chart]': 'readonlyView' },
  standalone: true,
  imports: [
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    MatFormFieldModule,
    MatInputModule,
    ChartTypeIconComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div
      class="integrated-chart"
      [class.thumbnail]="thumbnail"
      [attr.aria-busy]="loading()"
      [attr.data-chart-type]="dataset?.type ?? chart?.kind"
      [attr.data-chart-theme]="selectedTheme()"
    >
      @if (!readonlyView && available() && (!thumbnail || previewMenu)) {
        <div class="chart-controls" role="group" aria-label="Chart appearance and export">
          <app-chart-type-icon class="chart-type-mark" [type]="dataset?.type ?? chart?.kind" />
          <button
            mat-icon-button
            type="button"
            matTooltip="Customize chart"
            aria-label="Customize chart"
            [attr.aria-expanded]="formatOpen()"
            [disabled]="disabled || loading()"
            (click)="customize()"
          >
            <mat-icon>tune</mat-icon>
          </button>
          <button
            mat-icon-button
            type="button"
            matTooltip="Download PNG"
            aria-label="Download PNG"
            [disabled]="disabled || loading()"
            (click)="download()"
          >
            <mat-icon>download</mat-icon>
          </button>
          <button
            mat-icon-button
            type="button"
            matTooltip="Reset appearance"
            aria-label="Reset appearance"
            [disabled]="disabled || loading()"
            (click)="resetAppearance()"
          >
            <mat-icon>restart_alt</mat-icon>
          </button>
          @if (!compact) {
            <span class="chart-theme-note">{{ appTheme.current().label }}</span>
          }
        </div>
        @if (!compact) {
          <p class="chart-format-help">
            Format titles, legend, axes and labels. Colors follow your application theme.
          </p>
        }
      }
      @if (readonlyView && allowDownload && showDownloadControl && available()) {
        <div class="chart-controls" role="group" aria-label="Chart export">
          <button
            mat-icon-button
            type="button"
            matTooltip="Download chart as PNG"
            aria-label="Download PNG"
            [disabled]="loading()"
            (click)="download()"
          >
            <mat-icon>download</mat-icon>
          </button>
        </div>
      }
      <div
        #container
        class="chart-container"
        [attr.aria-label]="dataset?.title ?? chart?.title"
      ></div>
      <div #gridHost class="chart-data-grid" aria-hidden="true" inert></div>
      @if (loading()) {
        <p class="chart-message" role="status">Preparing chart…</p>
      }
      @if (error()) {
        <div class="chart-message" role="alert">
          <p>{{ error() }}</p>
          <button
            mat-icon-button
            type="button"
            matTooltip="Retry chart"
            aria-label="Retry chart"
            (click)="render()"
          >
            <mat-icon>refresh</mat-icon>
          </button>
        </div>
      }
      @if (empty()) {
        <p class="chart-message">No measured values are available in this view.</p>
      }
      @if (actionError()) {
        <p class="chart-action-error" role="alert">{{ actionError() }}</p>
      }
    </div>
  `,
  styles: [
    `
      :host {
        display: block;
        min-width: 0;
      }
      .integrated-chart {
        position: relative;
        min-height: 300px;
      }
      .integrated-chart.thumbnail {
        min-height: 130px;
      }
      .chart-container {
        width: 100%;
        height: var(--integrated-chart-height, 380px);
      }
      :host(.readonly-chart),
      :host(.readonly-chart) .integrated-chart,
      :host(.readonly-chart) .chart-container {
        height: 100%;
        min-height: 0;
      }
      .chart-controls {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 4px;
        padding: 6px 8px;
        border-bottom: 1px solid var(--mat-sys-outline-variant);
        background: var(--mat-sys-surface-container-low);
        border-radius: 10px 10px 0 0;
      }
      .chart-type-mark {
        --chart-icon-size: 20px;
        margin: 0 6px 0 4px;
        color: var(--mat-sys-primary);
      }
      .chart-controls .mat-mdc-button {
        font-weight: 600;
      }
      .chart-controls mat-form-field {
        width: 170px;
        --mat-form-field-container-height: 40px;
        --mat-form-field-container-vertical-padding: 8px;
      }
      .chart-controls button,
      .chart-controls select {
        font-size: 12px;
      }
      .chart-format-help,
      .chart-action-error {
        margin: 4px 0 8px;
        color: var(--muted);
        font-size: 12px;
      }
      .chart-action-error {
        color: var(--mat-sys-error);
      }
      .chart-data-grid {
        position: absolute;
        width: 1px;
        height: 1px;
        overflow: hidden;
        visibility: hidden;
        pointer-events: none;
      }
      .chart-message {
        position: absolute;
        inset: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
        color: var(--muted);
        background: var(--mat-sys-surface-container-lowest);
        font-size: 13px;
        text-align: center;
        padding: 24px;
      }
      .chart-theme-note {
        margin-left: auto;
        color: var(--muted);
        font-size: 10px;
      }
    `,
  ],
})
export class IntegratedChartComponent implements OnChanges, AfterViewInit, OnDestroy {
  private readonly reactiveState = injectUiState('IntegratedChartComponent');

  readonly appTheme = inject(AppThemeService);
  private readonly popups = inject(GridPopupLayer);
  private readonly dialogs = inject(MatDialog);
  private readonly explorerContext = inject(EXPLORER_CONTEXT);
  @Input() readonlyView = false;
  @Input() allowDownload = false;
  /** A parent toolbar can offer the same download without taking a second row. */
  @Input() showDownloadControl = true;
  @Input() compact = false;
  @Input() thumbnail = false;
  @Input() disabled = false;
  /** Compact builder previews expose Material formatting/export; gallery thumbnails stay passive. */
  @Input() previewMenu = false;
  @Input() dataset: ChartDataset | null = null;
  @Input() chart: DashboardChart | null = null;
  @Input() presentation: ChartPresentation | null = null;
  /** Authoring previews capture generated layouts; saved readers emit only deliberate edits. */
  @Input() captureInitialPresentation = true;
  @Output() readonly presentationChange = new EventEmitter<ChartPresentation>();
  /** Clicked category value, for parents that offer click-to-filter investigation. */
  @Output() readonly categoryClick = new EventEmitter<string | number>();
  @ViewChild('container', { static: true }) private container!: ElementRef<HTMLDivElement>;
  @ViewChild('gridHost', { static: true }) private gridHost!: ElementRef<HTMLDivElement>;
  readonly loading = this.reactiveState.signal(false);
  readonly error = this.reactiveState.signal('');
  readonly empty = this.reactiveState.signal(false);
  readonly available = this.reactiveState.signal(false);
  readonly selectedTheme = this.reactiveState.signal('ag-default');
  readonly actionError = this.reactiveState.signal('');
  readonly formatOpen = this.reactiveState.signal(false);
  private formatDialog?: MatDialogRef<ChartFormatDialogComponent, ChartFormatSettings>;
  readonly themes = [
    { id: 'ag-default', label: 'Default' },
    { id: 'ag-default-dark', label: 'Default dark' },
    { id: 'ag-sheets', label: 'Sheets' },
    { id: 'ag-sheets-dark', label: 'Sheets dark' },
    { id: 'ag-polychroma', label: 'Polychroma' },
    { id: 'ag-polychroma-dark', label: 'Polychroma dark' },
    { id: 'ag-vivid', label: 'Vivid' },
    { id: 'ag-vivid-dark', label: 'Vivid dark' },
    { id: 'ag-material', label: 'Material' },
    { id: 'ag-material-dark', label: 'Material dark' },
    { id: 'ag-financial', label: 'Financial' },
    { id: 'ag-financial-dark', label: 'Financial dark' },
  ];
  private ready = false;
  private generation = 0;
  private grid?: GridApi;
  private reference?: ChartRef;
  private signature = '';
  private savedPresentation?: ChartPresentation;
  private incomingPresentation?: ChartPresentation;
  private activeDataset?: ChartDataset;
  private renderPending = false;
  private resetPending = false;
  private appliedThemeName = '';

  constructor() {
    effect(() => {
      if (this.explorerContext.isActive?.() === false) return;
      const name = this.appTheme.chartThemeName();
      const gridTheme = this.appTheme.gridTheme();
      untracked(() => {
        if (this.ready && this.renderPending) {
          void this.render();
          return;
        }
        if (!this.grid || this.grid.isDestroyed()) return;
        if (name === this.appliedThemeName) return;
        // Changing the theme list can reset AG Charts' per-chart formatting. Capture
        // native title/legend/axis edits before changing any option, then restore them
        // on the new shared palette rather than reverting to the original proposal.
        const formatting = this.grid
          .getChartModels()
          ?.find((model) => model.chartId === this.reference?.chartId)?.chartOptions;
        this.grid.setGridOption('theme', gridTheme);
        this.grid.setGridOption('chartThemes', [
          name,
          ...Object.keys(this.appTheme.customChartThemes).filter((theme) => theme !== name),
        ]);
        this.appliedThemeName = name;
        if (this.reference) {
          this.grid.updateChart({
            type: 'rangeChartUpdate',
            chartId: this.reference.chartId,
            chartThemeName: name,
            ...(formatting ? { chartThemeOverrides: structuredClone(formatting) } : {}),
          });
          this.selectedTheme.set(name);
          this.capturePresentation();
        }
      });
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    const incoming = changes['presentation']?.currentValue as ChartPresentation | null | undefined;
    const changedPresentation =
      !!incoming && this.presentationKey(incoming) !== this.presentationKey(this.savedPresentation);
    if (changedPresentation) this.incomingPresentation = structuredClone(incoming);
    if (
      this.ready &&
      (changes['dataset'] || changes['chart'] || changes['thumbnail'] || changedPresentation)
    )
      void this.render();
  }
  private presentationKey(presentation: ChartPresentation | undefined): string {
    return JSON.stringify(
      presentation
        ? {
            signature: presentation.signature,
            options: presentation.model.chartOptions,
            palette: presentation.model.chartPalette,
            theme: presentation.theme,
            requestedTitle: presentation.requestedTitle,
            requestedAppearance: presentation.requestedAppearance,
          }
        : null,
    );
  }
  ngAfterViewInit(): void {
    this.ready = true;
    void this.render();
  }
  ngOnDestroy(): void {
    this.generation++;
    this.destroyChart();
  }

  private destroyChart(): void {
    this.formatDialog?.close();
    this.formatDialog = undefined;
    this.formatOpen.set(false);
    this.reference?.destroyChart();
    this.reference = undefined;
    this.grid?.destroy();
    this.grid = undefined;
    this.available.set(false);
  }

  customize(): void {
    if (this.disabled || this.loading() || this.formatDialog) return;
    this.chartAction(() => {
      const initial = this.formattingSnapshot();
      const generation = this.generation;
      this.formatOpen.set(true);
      this.formatDialog = this.dialogs.open(ChartFormatDialogComponent, {
        width: '540px',
        maxWidth: 'calc(100vw - 24px)',
        maxHeight: '90dvh',
        autoFocus: 'first-heading',
        restoreFocus: true,
        ariaLabel: 'Customize chart',
        data: {
          type: this.activeDataset?.type ?? 'column',
          settings: initial,
          seriesTypes: this.seriesTypes(this.activeDataset?.type ?? 'column'),
        },
      });
      this.formatDialog.afterClosed().subscribe((settings) => {
        this.formatDialog = undefined;
        this.formatOpen.set(false);
        if (settings && generation === this.generation && !this.disabled)
          this.applyFormatting(settings, initial);
      });
    });
  }

  changeTheme(theme: string): void {
    if (!this.themes.some((option) => option.id === theme)) return;
    this.chartAction(() => {
      this.grid!.updateChart({
        type: 'rangeChartUpdate',
        chartId: this.reference!.chartId,
        chartThemeName: theme,
      });
      this.capturePresentation(true);
    });
  }

  download(): void {
    if (this.readonlyView && !this.allowDownload) return;
    this.chartAction(
      () =>
        this.grid!.downloadChart({
          chartId: this.reference!.chartId,
          fileName:
            (this.dataset?.title ?? this.chart?.title ?? 'chart')
              .replace(/[^a-z0-9]+/gi, '-')
              .slice(0, 80) || 'chart',
          fileFormat: 'image/png',
        }),
      true,
    );
  }

  /** Export callers can mount a chart offscreen without changing the reader's selection. */
  async imageDataUrl(): Promise<string> {
    if (this.readonlyView && !this.allowDownload)
      throw new Error('Downloads are disabled for this view.');
    const deadline = Date.now() + 20_000;
    while (!this.available() && !this.empty() && !this.error() && Date.now() < deadline) {
      await new Promise((resolve) => setTimeout(resolve, 50));
    }
    if (this.error()) throw new Error(this.error());
    if (this.empty()) {
      const canvas = document.createElement('canvas');
      canvas.width = 1200;
      canvas.height = 720;
      const context = canvas.getContext('2d');
      if (!context) throw new Error('Unable to prepare the empty chart image.');
      context.fillStyle = '#ffffff';
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.textAlign = 'center';
      context.fillStyle = '#1e293b';
      context.font = '600 24px Arial';
      context.fillText(this.dataset?.title ?? 'Chart', 600, 70, 1080);
      context.fillStyle = '#64748b';
      context.font = '18px Arial';
      context.fillText('No matching data for this chart', 600, 360);
      return canvas.toDataURL('image/png');
    }
    const reference = this.reference;
    if (!reference || !this.grid || this.grid.isDestroyed())
      throw new Error('The chart is not ready to download. Try again.');
    const native = reference.chart as { waitForUpdate?: () => Promise<void> };
    let timeout: ReturnType<typeof setTimeout> | undefined;
    try {
      await Promise.race([
        native.waitForUpdate?.() ?? Promise.resolve(),
        new Promise<never>((_, reject) => {
          timeout = setTimeout(
            () => reject(new Error('The chart image took too long to prepare. Try again.')),
            20_000,
          );
        }),
      ]);
    } finally {
      if (timeout) clearTimeout(timeout);
    }
    const result = this.grid.getChartImageDataURL({
      chartId: reference.chartId,
      fileFormat: 'image/png',
    });
    if (!result) throw new Error('Unable to prepare the chart image.');
    return result;
  }

  resetAppearance(): void {
    if (this.disabled || this.loading()) return;
    void this.render(true);
  }

  private chartAction(action: () => void, exporting = false): void {
    if (
      (this.disabled && !(exporting && this.readonlyView && this.allowDownload)) ||
      this.loading() ||
      !this.grid ||
      !this.reference
    )
      return;
    this.actionError.set('');
    try {
      action();
    } catch {
      this.actionError.set('The chart action could not be completed. Please try again.');
    }
  }

  private capturePresentation(userInitiated = false): void {
    const model = this.grid
      ?.getChartModels()
      ?.find((entry) => entry.chartId === this.reference?.chartId);
    if (!model) return;
    this.selectedTheme.set(model.chartThemeName ?? 'ag-default');
    this.savedPresentation = {
      signature: this.signature,
      chartId: model.chartId,
      chartType: model.chartType,
      theme: this.selectedTheme(),
      model: structuredClone(model),
      appearance: this.summarizeAppearance(model),
      requestedAppearance: this.activeDataset?.appearance
        ? structuredClone(this.activeDataset.appearance)
        : null,
      requestedTitle: this.activeDataset?.title ?? '',
    };
    if (this.captureInitialPresentation || userInitiated)
      this.presentationChange.emit(this.savedPresentation);
  }

  async render(resetAppearance = false): Promise<void> {
    // Keep a retained explorer's chart and formatting until it is visible again.
    // Async data may finish in another tab; only its latest input needs rendering.
    if (this.explorerContext.isActive?.() === false) {
      this.renderPending = true;
      this.resetPending ||= resetAppearance;
      return;
    }
    resetAppearance ||= this.resetPending;
    this.renderPending = false;
    this.resetPending = false;
    const generation = ++this.generation;
    const incoming = this.incomingPresentation;
    this.incomingPresentation = undefined;
    // Parent edits belong to the current preview/save. Capturing the old native chart
    // here would emit stale formatting back into that newly updated parent state.
    if (!resetAppearance && !incoming) this.capturePresentation();
    this.destroyChart();
    this.error.set('');
    this.empty.set(false);
    this.actionError.set('');
    const dataset: ChartDataset | null =
      this.dataset ??
      (this.chart
        ? {
            type: this.chart.kind,
            title: this.chart.title,
            columns: [
              { id: 'category', label: 'Category', dataType: 'category' as const },
              ...this.chart.series.map((series, index) => ({
                id: `measure${index}`,
                label: series.label,
                dataType: 'series' as const,
              })),
            ],
            rows: this.chart.categories.map((category, index) => ({
              category,
              ...Object.fromEntries(
                this.chart!.series.map((series, seriesIndex) => [
                  `measure${seriesIndex}`,
                  series.values[index] ?? null,
                ]),
              ),
            })),
          }
        : null);
    this.signature = dataset
      ? JSON.stringify({
          type: dataset.type,
          columns: dataset.columns,
          seriesChartTypes: dataset.seriesChartTypes ?? null,
        })
      : '';
    const saved = resetAppearance
      ? undefined
      : [incoming, this.savedPresentation, this.presentation].find(
          (entry) => entry?.signature === this.signature,
        );
    this.savedPresentation = saved ?? undefined;
    // A reviewed chart owns its layout and data. Application appearance stays global,
    // including saved examples authored before the shared theme selector existed.
    this.selectedTheme.set(this.appTheme.chartThemeName());
    this.activeDataset = dataset ?? undefined;
    if (
      !dataset?.rows.length ||
      !dataset.rows.some((row) =>
        dataset.columns.some(
          (column) =>
            column.dataType === 'series' &&
            typeof row[column.id] === 'number' &&
            Number.isFinite(row[column.id]),
        ),
      )
    ) {
      this.loading.set(false);
      this.empty.set(true);
      return;
    }
    this.loading.set(true);
    try {
      await loadCharts();
      if (!this.isRenderCurrent(generation)) return;
      if (!(await chartPreviewTurn(() => this.isRenderCurrent(generation)))) return;
      this.appliedThemeName = this.appTheme.chartThemeName();
      this.selectedTheme.set(this.appliedThemeName);
      // A private client row model owns the complete server chart result. It never reads
      // the visible SSRM cache, which might hold only one page of source records.
      this.grid = createGrid(this.gridHost.nativeElement, {
        theme: this.appTheme.gridTheme(),
        // The private grid is hidden and inert. Menus belong in the visible wrapper
        // that contains both the data grid and its externally mounted chart.
        popupParent: this.popups.parentFor(this.container.nativeElement),
        rowData: dataset.categoryDisplayLabels
          ? dataset.rows.map((row) => ({
              ...row,
              category: dataset.categoryDisplayLabels?.[String(row['category'])] ?? row['category'],
            }))
          : dataset.rows,
        columnDefs: dataset.columns.map((column) => ({
          field: column.id,
          headerName: column.label,
          chartDataType: column.dataType,
          cellDataType: false,
        })),
        rowModelType: 'clientSide',
        enableCharts: true,
        animateRows: false,
        suppressCellFocus: true,
        chartThemes: [
          this.appTheme.chartThemeName(),
          ...Object.keys(this.appTheme.customChartThemes).filter(
            (theme) => theme !== this.appTheme.chartThemeName(),
          ),
        ],
        customChartThemes: this.appTheme.customChartThemes,
        // Formatting lives in the accessible Material dialog. Data/aggregation
        // stay in the validated builder, never in AG's separate tool panels.
        chartToolPanelsDef: { panels: [] },
        getChartToolbarItems: () => [],
        chartMenuItems: [],
        chartThemeOverrides: this.appearanceOverrides(dataset),
        onChartOptionsChanged: () => {
          if (generation === this.generation) this.capturePresentation();
        },
        onFirstDataRendered: ({ api }) => {
          if (!this.isRenderCurrent(generation)) return;
          try {
            const columns = dataset.columns.map((column) => column.id);
            this.reference = saved
              ? api.restoreChart(
                  {
                    ...structuredClone(saved.model),
                    chartType: dataset.type,
                    // AG Grid treats supplied series definitions as a custom
                    // combination. Presets regenerate their own definitions.
                    seriesChartTypes:
                      dataset.type === 'customCombo'
                        ? (dataset.seriesChartTypes ?? saved.model.seriesChartTypes)
                        : undefined,
                    chartThemeName: this.selectedTheme(),
                    chartPalette:
                      !this.selectedTheme().startsWith('app-material-') &&
                      this.selectedTheme() === saved.theme
                        ? saved.model.chartPalette
                        : undefined,
                    // Saved row bounds must never truncate a fresh API cohort.
                    cellRange: { columns, rowStartIndex: 0, rowEndIndex: dataset.rows.length - 1 },
                    aggFunc: undefined,
                    switchCategorySeries: false,
                    suppressChartRanges: true,
                    unlinkChart: true,
                    chartOptions: this.restoredAppearance(dataset, saved),
                  },
                  this.container.nativeElement,
                )
              : api.createRangeChart({
                  chartType: dataset.type,
                  seriesChartTypes: dataset.seriesChartTypes ?? undefined,
                  chartThemeName: this.selectedTheme(),
                  cellRange: { columns },
                  chartContainer: this.container.nativeElement,
                  suppressChartRanges: true,
                  unlinkChart: true,
                });
            if (!this.reference) throw new Error('Chart creation failed.');
            this.loading.set(false);
            this.available.set(true);
            this.capturePresentation(resetAppearance);
          } catch {
            this.loading.set(false);
            this.error.set(
              'The chart could not be displayed. Your filters and data are unchanged.',
            );
          }
        },
      });
    } catch {
      if (generation !== this.generation) return;
      this.loading.set(false);
      this.error.set('The chart could not be loaded. Your filters and data are unchanged.');
    }
  }

  private isRenderCurrent(generation: number): boolean {
    if (generation !== this.generation) return false;
    if (this.explorerContext.isActive?.() === false) {
      this.renderPending = true;
      return false;
    }
    return true;
  }

  private formattingSnapshot(): ChartFormatSettings {
    const model = this.grid
      ?.getChartModels()
      ?.find((entry) => entry.chartId === this.reference?.chartId);
    const native = this.reference?.chart as { getOptions?: () => unknown } | undefined;
    const options = native?.getOptions?.();
    const types = this.seriesTypes(this.activeDataset?.type ?? 'column');
    const sections = ['common', ...types];
    const read = (path: string[], fallback: unknown): unknown => {
      let value = this.getOption(options, path) ?? fallback;
      for (const section of sections)
        value = this.getOption(model?.chartOptions, [section, ...path]) ?? value;
      return value;
    };
    const nativeSeries = this.getOption(options, ['series']);
    const firstSeries = Array.isArray(nativeSeries) ? nativeSeries[0] : undefined;
    const series = (path: string[], fallback: unknown) =>
      read(['series', ...path], this.getOption(firstSeries, path) ?? fallback);
    const axes = this.getOption(options, ['axes']);
    const axis = (positions: string[], path: string[], fallback: unknown) => {
      let value = fallback;
      if (axes && typeof axes === 'object') {
        for (const entry of Object.values(axes)) {
          if (positions.includes(String(this.getOption(entry, ['position']))))
            value = this.getOption(entry, path) ?? value;
        }
      }
      for (const section of sections) {
        for (const type of [
          'number',
          'category',
          'time',
          'grouped-category',
          'ordinal-time',
          'unit-time',
        ]) {
          for (const position of positions)
            value =
              this.getOption(model?.chartOptions, [section, 'axes', type, position, ...path]) ??
              value;
        }
      }
      return value;
    };
    const appearance = model ? this.summarizeAppearance(model) : this.activeDataset?.appearance;
    return {
      title: String(read(['title', 'text'], this.activeDataset?.title ?? '')),
      titleEnabled: Boolean(read(['title', 'enabled'], true)),
      titleSize: Number(read(['title', 'fontSize'], 14)),
      subtitle: String(read(['subtitle', 'text'], '')),
      footnote: String(read(['footnote', 'text'], '')),
      legendEnabled: Boolean(appearance?.showLegend ?? read(['legend', 'enabled'], true)),
      legendPosition: appearance?.legendPosition ?? 'bottom',
      legendSize: Number(read(['legend', 'item', 'label', 'fontSize'], 11)),
      xAxisTitle: appearance?.xAxisTitle ?? '',
      yAxisTitle: appearance?.yAxisTitle ?? '',
      axisLabelSize: Number(axis(['bottom', 'top', 'left', 'right'], ['label', 'fontSize'], 12)),
      axisLabelRotation: Number(axis(['bottom', 'top'], ['label', 'rotation'], 0)),
      gridLines: Boolean(axis(['left', 'right'], ['gridLine', 'enabled'], true)),
      labels: Boolean(appearance?.showLabels ?? false),
      labelSize: Number(
        series(
          [
            this.activeDataset?.type === 'pie' || this.activeDataset?.type === 'donut'
              ? 'sectorLabel'
              : 'label',
            'fontSize',
          ],
          12,
        ),
      ),
      markers: Boolean(series(['marker', 'enabled'], types.includes('line'))),
      markerSize: Number(
        series(this.activeDataset?.type === 'scatter' ? ['size'] : ['marker', 'size'], 6),
      ),
      lineStyle: String(
        series(['interpolation', 'type'], 'linear'),
      ) as ChartFormatSettings['lineStyle'],
      strokeWidth: Number(series(['strokeWidth'], types.includes('line') ? 2 : 0)),
      fillOpacity: Number(series(['fillOpacity'], types.includes('area') ? 0.7 : 1)),
      cornerRadius: Number(series(['cornerRadius'], 0)),
      donutHole: Number(series(['innerRadiusRatio'], 0.5)),
      tooltips: Boolean(read(['tooltip', 'enabled'], true)),
    };
  }

  private applyFormatting(settings: ChartFormatSettings, previous: ChartFormatSettings): void {
    this.chartAction(() => {
      const model = this.grid!.getChartModels()?.find(
        (entry) => entry.chartId === this.reference!.chartId,
      );
      if (!model) return;
      const overrides = structuredClone(model.chartOptions);
      const types = this.seriesTypes(this.activeDataset?.type ?? 'column');
      const sections = ['common', ...types];
      const changed = (key: keyof ChartFormatSettings) => settings[key] !== previous[key];
      const common = (path: string[], value: unknown) => {
        for (const section of sections) this.setOption(overrides, [section, ...path], value);
      };
      const setSeries = (type: string, path: string[], value: unknown) =>
        this.setOption(overrides, [type, 'series', ...path], value);
      const setAxes = (positions: string[], path: string[], value: unknown) => {
        for (const section of sections) {
          for (const axis of [
            'number',
            'category',
            'time',
            'grouped-category',
            'ordinal-time',
            'unit-time',
          ]) {
            for (const position of positions)
              this.setOption(overrides, [section, 'axes', axis, position, ...path], value);
          }
        }
      };
      if (changed('title')) common(['title', 'text'], settings.title.trim());
      if (changed('titleEnabled')) common(['title', 'enabled'], settings.titleEnabled);
      if (changed('titleSize')) common(['title', 'fontSize'], settings.titleSize);
      for (const key of ['subtitle', 'footnote'] as const) {
        if (changed(key)) {
          common([key, 'text'], settings[key].trim());
          common([key, 'enabled'], !!settings[key].trim());
        }
      }
      if (changed('legendEnabled')) common(['legend', 'enabled'], settings.legendEnabled);
      if (changed('legendPosition')) common(['legend', 'position'], settings.legendPosition);
      if (changed('legendSize'))
        common(['legend', 'item', 'label', 'fontSize'], settings.legendSize);
      if (changed('tooltips')) common(['tooltip', 'enabled'], settings.tooltips);
      if (this.activeDataset?.type !== 'pie' && this.activeDataset?.type !== 'donut') {
        for (const [key, positions] of [
          ['xAxisTitle', ['bottom', 'top']],
          ['yAxisTitle', ['left', 'right']],
        ] as const) {
          if (changed(key)) {
            setAxes([...positions], ['title', 'text'], settings[key].trim());
            setAxes([...positions], ['title', 'enabled'], !!settings[key].trim());
          }
        }
        if (changed('axisLabelSize'))
          setAxes(
            ['bottom', 'top', 'left', 'right'],
            ['label', 'fontSize'],
            settings.axisLabelSize,
          );
        if (changed('axisLabelRotation'))
          setAxes(['bottom', 'top'], ['label', 'rotation'], settings.axisLabelRotation);
        if (changed('gridLines'))
          setAxes(['bottom', 'top', 'left', 'right'], ['gridLine', 'enabled'], settings.gridLines);
      }
      for (const type of types) {
        const polar = type === 'pie' || type === 'donut';
        for (const label of polar ? ['calloutLabel', 'sectorLabel'] : ['label']) {
          if (changed('labels')) setSeries(type, [label, 'enabled'], settings.labels);
          if (changed('labelSize')) setSeries(type, [label, 'fontSize'], settings.labelSize);
        }
        if (changed('strokeWidth')) setSeries(type, ['strokeWidth'], settings.strokeWidth);
        if (type !== 'line' && changed('fillOpacity'))
          setSeries(type, ['fillOpacity'], settings.fillOpacity);
        if ((type === 'bar' || polar) && changed('cornerRadius'))
          setSeries(type, ['cornerRadius'], settings.cornerRadius);
        if (type === 'donut' && changed('donutHole'))
          setSeries(type, ['innerRadiusRatio'], settings.donutHole);
        if (type === 'line' || type === 'area') {
          if (changed('markers')) setSeries(type, ['marker', 'enabled'], settings.markers);
          if (changed('markerSize')) setSeries(type, ['marker', 'size'], settings.markerSize);
          if (changed('lineStyle')) setSeries(type, ['interpolation', 'type'], settings.lineStyle);
        }
        if (type === 'scatter' && changed('markerSize'))
          setSeries(type, ['size'], settings.markerSize);
      }
      this.grid!.updateChart({
        type: 'rangeChartUpdate',
        chartId: this.reference!.chartId,
        chartThemeName: this.appTheme.chartThemeName(),
        chartThemeOverrides: overrides,
      });
      this.capturePresentation(true);
    });
  }

  private appearanceOverrides(dataset: ChartDataset): ChartModel['chartOptions'] {
    const appearance = dataset.appearance;
    const overrides: ChartModel['chartOptions'] = {
      common: {
        // Animation requires Charts Enterprise in the installed version. Keeping
        // it off also respects reduced-motion preferences without extra modules.
        animation: { enabled: false },
        legend: {
          position: appearance?.legendPosition ?? 'bottom',
          ...(appearance?.showLegend != null ? { enabled: appearance.showLegend } : {}),
        },
        title: { enabled: true, text: dataset.title },
      },
    };
    if (this.categoryClick.observed) {
      overrides.common!.listeners = {
        seriesNodeClick: (event) => {
          const node = event as { datum?: Record<string, unknown>; xKey?: string };
          const value = node.datum?.[node.xKey ?? 'category'];
          if (typeof value === 'string' || typeof value === 'number')
            this.categoryClick.emit(value);
        },
      };
    }
    if (appearance?.showLabels != null) {
      const label = { enabled: appearance.showLabels };
      for (const series of ['bar', 'line', 'area', 'scatter', 'bubble', 'histogram'] as const) {
        overrides[series] = { series: { label } };
      }
      overrides.pie = { series: { calloutLabel: label, sectorLabel: label } };
      overrides.donut = { series: { calloutLabel: label, sectorLabel: label } };
    }
    if (
      dataset.type !== 'pie' &&
      dataset.type !== 'donut' &&
      (appearance?.xAxisTitle != null || appearance?.yAxisTitle != null)
    ) {
      // Position-specific overrides also handle scatter/histogram's two number
      // axes and horizontal bars without confusing horizontal/vertical titles.
      const horizontal =
        appearance?.xAxisTitle != null
          ? { title: { enabled: true, text: appearance.xAxisTitle } }
          : undefined;
      const vertical =
        appearance?.yAxisTitle != null
          ? { title: { enabled: true, text: appearance.yAxisTitle } }
          : undefined;
      const axis = { bottom: horizontal, top: horizontal, left: vertical, right: vertical };
      overrides.common!.axes = {
        number: axis,
        category: axis,
        time: axis,
        'grouped-category': axis,
        'ordinal-time': axis,
        'unit-time': axis,
      };
    }
    return applyHistogramBins(overrides, dataset);
  }

  private seriesTypes(type: ChartDataset['type']): (keyof ChartModel['chartOptions'])[] {
    if (type === 'customCombo') {
      return [
        ...new Set(
          (this.activeDataset?.seriesChartTypes ?? []).map((series) =>
            /column/i.test(series.chartType)
              ? 'bar'
              : /area/i.test(series.chartType)
                ? 'area'
                : 'line',
          ),
        ),
      ];
    }
    if (type === 'columnLineCombo') return ['bar', 'line'];
    if (type === 'areaColumnCombo') return ['area', 'bar'];
    if (/bar|column/i.test(type)) return ['bar'];
    if (/line/i.test(type)) return ['line'];
    if (/area/i.test(type)) return ['area'];
    return [type as 'pie' | 'donut' | 'scatter' | 'bubble' | 'histogram'];
  }

  private restoredAppearance(
    dataset: ChartDataset,
    saved: ChartPresentation,
  ): ChartModel['chartOptions'] {
    const overrides = applyHistogramBins(structuredClone(saved.model.chartOptions), dataset);
    overrides.common = { ...overrides.common, animation: { enabled: false } };
    const sections = ['common', ...this.seriesTypes(dataset.type)];
    if (dataset.title !== saved.requestedTitle) {
      for (const section of sections) {
        this.setOption(overrides, [section, 'title', 'text'], dataset.title);
        this.setOption(overrides, [section, 'title', 'enabled'], true);
      }
    }
    const appearance = dataset.appearance;
    if (!appearance) return overrides;
    const changed = (key: keyof ChartAppearance) =>
      appearance[key] != null && appearance[key] !== saved.requestedAppearance?.[key];
    // Native edits are stored in series-specific theme sections. Write reviewed
    // changes at the same scope so they override only the requested settings.
    for (const section of sections) {
      if (changed('legendPosition'))
        this.setOption(overrides, [section, 'legend', 'position'], appearance.legendPosition);
      if (changed('showLegend'))
        this.setOption(overrides, [section, 'legend', 'enabled'], appearance.showLegend);
      for (const [key, positions] of [
        ['xAxisTitle', ['bottom', 'top']],
        ['yAxisTitle', ['left', 'right']],
      ] as const) {
        if (changed(key) && dataset.type !== 'pie' && dataset.type !== 'donut') {
          for (const axis of [
            'number',
            'category',
            'time',
            'grouped-category',
            'ordinal-time',
            'unit-time',
          ]) {
            for (const position of positions) {
              this.setOption(
                overrides,
                [section, 'axes', axis, position, 'title', 'text'],
                appearance[key],
              );
              this.setOption(
                overrides,
                [section, 'axes', axis, position, 'title', 'enabled'],
                true,
              );
            }
          }
        }
      }
    }
    if (changed('showLabels')) {
      for (const type of this.seriesTypes(dataset.type)) {
        for (const label of type === 'pie' || type === 'donut'
          ? ['calloutLabel', 'sectorLabel']
          : ['label']) {
          this.setOption(overrides, [type, 'series', label, 'enabled'], appearance.showLabels);
        }
      }
    }
    return overrides;
  }

  private summarizeAppearance(model: ChartModel): ChartAppearance {
    const requested = this.activeDataset?.appearance;
    const sections = ['common', ...this.seriesTypes(this.activeDataset?.type ?? 'column')];
    const option = (paths: string[][]): unknown => {
      let result: unknown;
      for (const section of sections) {
        for (const path of paths) {
          const value = this.getOption(model.chartOptions, [section, ...path]);
          if (value !== undefined) result = value;
        }
      }
      return result;
    };
    const nativeChart = this.reference?.chart as { getOptions?: () => unknown } | undefined;
    const chartAxes = this.getOption(nativeChart?.getOptions?.(), ['axes']);
    const axisTitle = (positions: string[], fallback: string | null): string | null => {
      const actualTypes =
        chartAxes && typeof chartAxes === 'object'
          ? Object.values(chartAxes).flatMap((axis: unknown) => {
              const type = this.getOption(axis, ['type']);
              const position = this.getOption(axis, ['position']);
              return typeof type === 'string' &&
                typeof position === 'string' &&
                positions.includes(position)
                ? [type]
                : [];
            })
          : [];
      const axes = actualTypes.length
        ? actualTypes
        : ['number', 'category', 'time', 'grouped-category', 'ordinal-time', 'unit-time'];
      const paths = axes.flatMap((axis) =>
        positions.map((position) => ['axes', axis, position, 'title']),
      );
      if (option(paths.map((path) => [...path, 'enabled'])) === false) return null;
      const title = option(paths.map((path) => [...path, 'text']));
      return typeof title === 'string' ? title : fallback;
    };
    const legendPosition = option([['legend', 'position']]);
    const showLegend = option([['legend', 'enabled']]);
    const showLabels = option([
      [
        'series',
        this.activeDataset?.type === 'pie' || this.activeDataset?.type === 'donut'
          ? 'sectorLabel'
          : 'label',
        'enabled',
      ],
    ]);
    return {
      theme:
        CHART_THEMES.find((theme) => theme === model.chartThemeName) ??
        (this.appTheme.current().dark ? 'ag-material-dark' : 'ag-material'),
      legendPosition:
        legendPosition === 'top' ||
        legendPosition === 'right' ||
        legendPosition === 'bottom' ||
        legendPosition === 'left'
          ? legendPosition
          : legendPosition === undefined
            ? (requested?.legendPosition ?? 'bottom')
            : null,
      showLegend: typeof showLegend === 'boolean' ? showLegend : (requested?.showLegend ?? null),
      showLabels: typeof showLabels === 'boolean' ? showLabels : (requested?.showLabels ?? null),
      xAxisTitle: axisTitle(['bottom', 'top'], requested?.xAxisTitle ?? null),
      yAxisTitle: axisTitle(['left', 'right'], requested?.yAxisTitle ?? null),
    };
  }

  private getOption(object: unknown, path: string[]): unknown {
    return path.reduce<unknown>(
      (value, key) =>
        value && typeof value === 'object' ? (value as Record<string, unknown>)[key] : undefined,
      object,
    );
  }

  private setOption(object: object, path: string[], value: unknown): void {
    let target = object as Record<string, unknown>;
    for (const key of path.slice(0, -1)) {
      if (!target[key] || typeof target[key] !== 'object') target[key] = {};
      target = target[key] as Record<string, unknown>;
    }
    target[path[path.length - 1]] = value;
  }
}
