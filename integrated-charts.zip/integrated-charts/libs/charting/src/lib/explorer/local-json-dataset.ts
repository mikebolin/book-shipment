import type { LocalDataset } from './client-data-sources';
import { parseLocalJson, LOCAL_JSON_LIMITS, type LocalImportOptions } from './local-json-parser';
import { parseLocalCsv } from './local-csv-parser';
import { sha256Text } from './content-hash';
export {
  parseLocalJson,
  LOCAL_JSON_LIMITS,
  type LocalImportOptions,
  type LocalImportProgress,
} from './local-json-parser';

/** Parse and infer off the UI thread. The same-origin module worker needs no blob or eval. */
export async function parseLocalJsonFile(
  file: File,
  options: LocalImportOptions = {},
): Promise<LocalDataset> {
  options.signal?.throwIfAborted();
  if (file.size > LOCAL_JSON_LIMITS.bytes)
    throw new Error('Choose a JSON or CSV file no larger than 800 MiB.');
  options.onProgress?.({ phase: 'reading' });
  if (typeof Worker === 'undefined') {
    const text = await file.text();
    const dataset = /\.csv$/i.test(file.name)
      ? parseLocalCsv(text, file.name, options)
      : parseLocalJson(text, file.name, options);
    dataset.contentHash = await sha256Text(text);
    options.signal?.throwIfAborted();
    return dataset;
  }
  const worker = new Worker(new URL('./local-json.worker.ts', import.meta.url), { type: 'module' });
  return new Promise((resolve, reject) => {
    const close = () => {
      options.signal?.removeEventListener('abort', abort);
      worker.terminate();
    };
    const abort = () => {
      close();
      reject(options.signal?.reason ?? new DOMException('Aborted', 'AbortError'));
    };
    worker.onmessage = ({ data }) => {
      if (data.type === 'progress') options.onProgress?.(data.progress);
      else if (data.type === 'complete') {
        close();
        resolve(data.dataset as LocalDataset);
      } else if (data.type === 'error') {
        close();
        reject(new Error(data.message));
      }
    };
    worker.onerror = () => {
      close();
      reject(
        new Error(
          'The file import worker could not start. Reload the page and try the file again.',
        ),
      );
    };
    options.signal?.addEventListener('abort', abort, { once: true });
    if (options.signal?.aborted) abort();
    else worker.postMessage({ file, metadata: options.metadata, skipRecipes: options.skipRecipes });
  });
}
