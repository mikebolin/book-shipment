import type { ChartingDataSource } from '../core/data-access/charting-data';

export interface GridReviewPreview {
  prompt: string;
  status: 'ready' | 'clarification' | 'unsupported';
  filterText: string;
  operations: string[];
  columns: { id: string; label: string }[];
  rows: Record<string, string | number | boolean | null>[];
  rowCount: number;
  previewKind: 'filtered-rows' | 'grouped-rows' | 'unchanged-rows';
  explanation: string;
  clarificationOptions?: string[];
  calculation?: { name: string; expression: string };
}

export interface GridReviewPreviewPack {
  snapshotDate: string;
  sourceId: string;
  provenance: {
    kind: 'expanded-demo-fixture';
    baseRows: number;
    logicalRows: number;
    authorizedRows: number;
    tenant: 'demo';
  };
  previews: Record<string, GridReviewPreview>;
}

async function readPreviewPack(
  sourceId: string,
  data: ChartingDataSource,
): Promise<GridReviewPreviewPack> {
  const pack = await data.loadGridPreviews?.(sourceId);
  if (!pack || pack.sourceId !== sourceId)
    throw new Error('This host has no saved preview for this example.');
  return pack;
}

/** Saved, reviewed fixture results only; never calls a planner or data API. */
export async function loadDemoGridPreviews(
  sourceId: string,
  data: ChartingDataSource,
): Promise<GridReviewPreviewPack> {
  return structuredClone(await readPreviewPack(sourceId, data));
}

/** A visible card needs one isolated preview, rather than a clone of the entire library. */
export async function loadDemoGridPreview(
  sourceId: string,
  exampleId: string,
  data: ChartingDataSource,
) {
  const pack = await readPreviewPack(sourceId, data);
  const preview = pack.previews[exampleId];
  if (!preview) throw new Error('A saved review is not available for this example.');
  return {
    snapshotDate: pack.snapshotDate,
    authorizedRows: pack.provenance.authorizedRows,
    preview: structuredClone(preview),
  };
}
