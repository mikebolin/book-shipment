export type WorkflowIntent = 'data' | 'chart';
import { startsNewChartRequest } from '../core/domain/chart-request-intent';
export {
  isChartTypeChoice,
  startsNewChartRequest,
  targetsExistingChart,
  usesChartBuilderSettings,
} from '../core/domain/chart-request-intent';

/** Only explicit visual terms change the locally selected goal; no paid routing call. */
export function requestedWorkflow(text: string, selected: WorkflowIntent): WorkflowIntent {
  return startsNewChartRequest(text) ||
    /\b(chart|plot|graph|histogram|scatter|bubble|donut|pie|visuali[sz]e)\b/i.test(text)
    ? 'chart'
    : selected;
}

/** Clear references continue an applied view; ordinary new requests still start fresh. */
export function refersToCurrentResults(text: string): boolean {
  return /\b(these|those|current|existing|same)\s+(results|rows|records|holdings|transactions|accounts|filters|chart|data|view)\b|\b(keep|retain)\s+(the\s+)?(filters|cohort)|\b(refine|narrow|visuali[sz]e)\s+(this|these|those|it)\b|\b(chart|graph|plot)\s+(?:for|of|from)\s+(this|that|these|those|it)\b/i.test(
    text,
  );
}

/** A complete new data query supersedes a pending clarification. */
export function startsIndependentDataRequest(text: string): boolean {
  return (
    !refersToCurrentResults(text) &&
    /^(?:show|find|list|give me|get me)\s+(?:(?:all|the|me)\s+)?(?:[\w-]+\s+){0,5}(?:records|rows|cases|accounts|transactions|holdings|orders|trades)\b/i.test(
      text,
    ) &&
    /\b(?:where|whose|that|with|in|between|opened|contains|equals|is)\b/i.test(text)
  );
}
