import { injectUiState } from '../core/state/index';
import { analyticColumns } from '../core/domain/chart-analytics';
import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  Output,
  SimpleChanges,
  computed,
  effect,
  inject,
  untracked,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatSelectModule } from '@angular/material/select';
import type { AdvancedFilterModel } from 'ag-grid-community';
import { DraftFilterEditorComponent } from './draft-filter-editor.component';
import { ExplorerDataService } from './explorer-data.service';
import type { ClientDataSourceId } from './client-data-sources';
import {
  chartObservationNote,
  profileChartRows,
  type ChartDataProfile,
} from './chart-data-profile';
import type { ColumnSpec } from '../core/domain/schema';
import { filterPreview } from '../core/domain/filter-preview';
import {
  CHART_MAX_SOURCE_ROWS,
  buildChartDataset,
  validateChartPlan,
  type ChartSourceRow,
} from '../core/domain/chart-data';
import type { GridModel, Node } from '../core/domain/contracts';
import {
  CHART_AGGREGATIONS,
  CHART_LEGEND_POSITIONS,
  CHART_TIME_BUCKETS,
  COMBO_SERIES_TYPES,
  type ChartAppearance,
  type ChartDataset,
  type ChartPlan,
  type ChartSeriesType,
  type ChartResponse,
  describeChartPlan,
} from '../core/domain/integrated-chart';
import { CHART_DEMO_VARIANTS } from './chart-demo-types';
import {
  chartArchetypes,
  chartGuideRoles,
  rankedChartFields,
  schemaChartInsights,
  guideIllustration,
  chartVariantSelection,
  type GuideRole,
  type ChartArchetype,
} from './chart-archetypes';
import { ChartFieldPickerComponent } from './chart-field-picker.component';
import { ChartTypeIconComponent } from './chart-type-icon.component';
import { IntegratedChartComponent, type ChartPresentation } from './integrated-chart.component';
import { ChartDataSummaryComponent } from './chart-data-summary.component';
import { PreviewViewportDirective } from './preview-viewport.directive';
import {
  defaultComboSeries,
  defaultGuidePlan,
  guideFields,
  guidePlanError,
  isComboChart,
  isRawChart,
  isTimeChart,
  chartReaderFilterMode,
  chartReaderFilterControls,
  type ChartReaderFilters,
  type ChartGuideSubmission,
} from './chart-guide';

export type { ChartGuideSubmission } from './chart-guide';
export interface ChartGuideDraft extends ChartGuideSubmission {
  stage: 'gallery' | 'fields' | 'review';
  valid: boolean;
  validationMessage: string;
}

@Component({
  selector: 'app-chart-guide',
  standalone: true,
  imports: [
    ChartDataSummaryComponent,
    FormsModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatCheckboxModule,
    MatIconModule,
    MatTooltipModule,
    MatAutocompleteModule,
    MatSelectModule,
    ChartFieldPickerComponent,
    ChartTypeIconComponent,
    IntegratedChartComponent,
    PreviewViewportDirective,
    DraftFilterEditorComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './chart-guide.component.html',
  styleUrl: './chart-guide.component.scss',
})
export class ChartGuideComponent implements OnChanges, OnDestroy {
  private readonly reactiveState = injectUiState('ChartGuideComponent');

  @Input() dataSource: ClientDataSourceId = 'accounts';
  @Input() dataReady = false;
  @Input() set liveRecommendations(value: boolean) {
    this.liveRecommendationsEnabled.set(value);
  }
  readonly liveRecommendationsEnabled = this.reactiveState.signal(false);
  @Input() calculatedColumnIds: string[] = [];
  @Input() active = true;
  private readonly api = inject(ExplorerDataService);
  private sampleAbort?: AbortController;
  private sampleKey = '';
  readonly dataProfile = this.reactiveState.signal<ChartDataProfile | null>(null);
  readonly sampleLoading = this.reactiveState.signal(false);
  readonly sampleError = this.reactiveState.signal('');
  readonly sampleMatchCount = this.reactiveState.signal(0);
  readonly galleryDataNote = computed(() => {
    if (this.sampleLoading()) return 'Finding useful fields in your records…';
    const profile = this.dataProfile();
    if (profile)
      return profile.rows.length
        ? `Real values from ${profile.rows.length.toLocaleString()} of ${this.sampleMatchCount().toLocaleString()} matching records. Select a chart to use all matching records.`
        : 'No records match these filters. Change the filters to see your data.';
    return (
      this.sampleError() ||
      'Illustrations show the selected fields. Real-data suggestions appear when loading finishes.'
    );
  });
  readonly previewDataNote = computed(() =>
    this.dataProfile() ? chartObservationNote(this.plan(), this.schema(), this.dataProfile()!) : '',
  );
  @Input() columns: readonly ColumnSpec[] = [];
  @Input() cohortLabel = 'All records in this data source.';
  @Input() busy = false;
  get interactionLocked(): boolean {
    return this.busy || !this.dataReady;
  }
  @Input() error = '';
  @Input() description = '';
  @Output() readonly descriptionChange = new EventEmitter<string>();
  @Input() initialPlan: ChartPlan | null = null;
  @Input() initialFilterControls: ChartGuideSubmission['filterControls'];
  readonly readerFilters = this.reactiveState.signal<ChartReaderFilters>('inherit');
  readonly readerFilterHint = computed(() => {
    switch (this.readerFilters()) {
      case 'hidden':
        return 'Readers see the chart without its filter. The saved filter still applies.';
      case 'readonly':
        return 'Readers see the filter summary and cannot change it.';
      case 'values':
        return 'Readers can change comparison values. Fields, operators and grouping stay fixed.';
      case 'expression':
        return 'Readers can edit the whole expression: fields, operators, values and groups.';
      default:
        return 'This chart follows the view’s reader setting (View settings › Reader experience).';
    }
  });
  @Input() initialFilters: Node[] = [];
  @Input() dataFilter: AdvancedFilterModel | null = null;
  /** The table's current filter, offered as a starting point for this chart's own filter. */
  @Input() tableFilter: AdvancedFilterModel | null = null;
  @Input() liveDataset: ChartDataset | null = null;
  @Input() previewPresentation: ChartPresentation | null = null;
  @Output() readonly previewPresentationChange = new EventEmitter<ChartPresentation>();
  @Input() liveBusy = false;
  @Input() resetToken = 0;
  @Input() editorMode: 'new' | 'edit' = 'new';
  @Input() dirty = false;
  @Input() canApply = false;
  @Output() readonly applyDraft = new EventEmitter<void>();
  @Output() readonly cancelEdit = new EventEmitter<void>();
  @Output() readonly preview = new EventEmitter<ChartGuideSubmission>();
  @Output() readonly filterChange = new EventEmitter<AdvancedFilterModel | null>();
  @Output() readonly filterAi = new EventEmitter<ChartGuideDraft>();
  @Output() readonly draftChange = new EventEmitter<ChartGuideDraft>();
  @Output() readonly askAi = new EventEmitter<ChartGuideDraft>();
  readonly step = this.reactiveState.signal(0);
  readonly furthestStep = this.reactiveState.signal(0);
  readonly fieldStep = this.reactiveState.signal(0);
  readonly gallerySearch = this.reactiveState.signal('');
  readonly galleryFamily = this.reactiveState.signal('');
  readonly recommendationsOnly = this.reactiveState.signal(true);
  readonly galleryVariant = this.reactiveState.signal('');
  readonly stageLabels = ['Choose chart', 'Configure', 'Review'];
  /** Chart styles the current scope can actually render; size limits surface here, not at review. */
  readonly archetypes = computed(() => {
    const items = chartArchetypes(this.schema(), this.dataProfile());
    const matching = this.sampleMatchCount();
    if (matching <= CHART_MAX_SOURCE_ROWS) return items;
    const limitation = `${matching.toLocaleString()} matching records exceed the chart limit of ${CHART_MAX_SOURCE_ROWS.toLocaleString()}. Narrow this chart’s data filter first.`;
    return items.map((item) => ({ ...item, supported: false, limitation, reason: limitation }));
  });
  readonly recommendationState = computed(() => {
    this.schema();
    return this.liveRecommendationsEnabled()
      ? this.api.chartRecommendations().get(this.dataSource)
      : undefined;
  });
  readonly recommendationNote = computed(() => {
    const state = this.recommendationState();
    if (!this.liveRecommendationsEnabled())
      return 'Suggested from the fields and values in your data.';
    if (!this.api.capabilities().chartRecommendationsAvailable)
      return 'Suggested from the fields and values in your data.';
    if (!state || state.status === 'loading')
      return 'Finding chart recommendations for this dataset…';
    if (state.status === 'pending')
      return 'Start with these suggestions while more recommendations are prepared.';
    if (state.status === 'ready' && state.source === 'llm')
      return state.cached
        ? 'Saved AI recommendations for this dataset.'
        : 'AI recommendations ready and saved for this dataset.';
    return 'Suggested from the fields and values in your data.';
  });
  readonly recommendedArchetypes = computed<ChartArchetype[]>(() => {
    const state = this.recommendationState();
    const profile = this.dataProfile();
    if (!state || state.status !== 'ready' || state.source !== 'llm' || !profile) return [];
    return state.candidateIds
      .flatMap((id) => {
        const candidate = state.candidates.find((c) => c.descriptor.id === id);
        const style = this.archetypes().find((c) => c.id === candidate?.plan.type);
        if (!candidate || !style || guidePlanError(candidate.plan, this.schema())) return [];
        try {
          const plan = validateChartPlan(candidate.plan, this.schema());
          const illustration = buildChartDataset(
            plan,
            this.schema(),
            profile.rows as readonly ChartSourceRow[],
          );
          return [
            {
              ...style,
              candidateId: id,
              plan,
              supported: true,
              limitation: '',
              illustration,
              label: plan.title,
              description: style.description,
              reason: 'Recommended for the fields and chart purposes in this dataset.',
              fields: [plan.categoryColumnId, ...plan.measureColumnIds]
                .filter((field): field is string => !!field)
                .map((field) => this.fieldLabel(field)),
              dataNote: chartObservationNote(plan, this.schema(), profile),
            },
          ];
        } catch {
          return [];
        }
      })
      .slice(0, 6);
  });
  readonly insights = computed(() => schemaChartInsights(this.schema()));
  readonly filteredArchetypes = computed(() => {
    const search = this.gallerySearch().trim().toLocaleLowerCase();
    const items = this.archetypes().filter(
      (item) =>
        (!search ||
          `${item.label} ${item.description} ${item.fields.join(' ')}`
            .toLocaleLowerCase()
            .includes(search)) &&
        (!this.galleryFamily() || item.family === this.galleryFamily()) &&
        (!this.galleryVariant() || item.id === this.galleryVariant()),
    );
    return this.recommendationsOnly() && !this.galleryFamily() && !search && !this.galleryVariant()
      ? this.recommendedArchetypes().length
        ? this.recommendedArchetypes()
        : items.filter((item) => item.supported).slice(0, 6)
      : items;
  });
  readonly galleryMatches = computed(() =>
    this.archetypes()
      .filter(
        (item) =>
          (!this.galleryFamily() || item.family === this.galleryFamily()) &&
          `${item.label} ${item.description} ${item.fields.join(' ')}`
            .toLocaleLowerCase()
            .includes(this.gallerySearch().toLocaleLowerCase()),
      )
      .slice(0, 8),
  );
  readonly roles = computed(() => chartGuideRoles(this.plan()));
  private readonly rankedRoleOptions = computed(() => {
    const columns = this.schema();
    const plan = this.plan();
    const profile = this.dataProfile();
    return new Map(
      this.roles()
        .filter((role) => role.kind === 'category' || role.kind === 'measure')
        .map((role) => [
          role.label,
          rankedChartFields(columns, role, plan, '', columns.length, profile),
        ]),
    );
  });
  readonly currentRole = computed(
    () => this.roles()[Math.min(this.fieldStep(), this.roles().length - 1)],
  );
  readonly roleOptions = computed(() =>
    this.currentRole() ? this.optionsFor(this.currentRole()!) : [],
  );
  readonly currentField = computed(() =>
    this.currentRole()?.kind === 'category'
      ? (this.plan().categoryColumnId ?? '')
      : (this.plan().measureColumnIds[this.currentRole()?.slot ?? 0] ?? ''),
  );
  readonly selectedArchetype = computed(() =>
    this.archetypes().find((item) => item.id === this.plan().type),
  );
  readonly illustration = computed(() => guideIllustration(this.plan(), this.schema()));
  readonly familyVariants = computed(() =>
    this.chartTypes.filter((type) => !this.galleryFamily() || type.family === this.galleryFamily()),
  );
  readonly selectedVariants = computed(() => {
    const family = this.chartTypes.find((type) => type.id === this.plan().type)?.family;
    return this.archetypes()
      .filter((type) => type.family === family)
      .map((type) => {
        const selection = chartVariantSelection(
          this.plan(),
          type.id,
          this.schema(),
          this.dataProfile(),
        );
        return {
          ...type,
          plan: selection.plan,
          supported: !selection.limitation,
          limitation: selection.limitation,
        };
      });
  });
  readonly variantLimitation = computed(
    () => this.selectedVariants().find((variant) => !variant.supported)?.limitation ?? '',
  );
  readonly localError = this.reactiveState.signal('');
  readonly invalidFields = this.reactiveState.signal<ReadonlySet<string>>(new Set());
  readonly plan = this.reactiveState.signal<ChartPlan>(defaultGuidePlan('groupedColumn', []));
  readonly reviewDescription = computed(() => {
    const plan = this.plan();
    return describeChartPlan({ ...plan, appearance: null }, this.schema())
      .slice(`Chart: ${plan.title} (${plan.type}). `.length)
      .replace(/^SUM:/, 'Total of')
      .replace(/^AVG:/, 'Average of')
      .replace(/^MIN:/, 'Minimum of')
      .replace(/^MAX:/, 'Maximum of')
      .replace(', using all filtered source rows.', '. Includes all matching records.');
  });
  readonly inheritedFilters = this.reactiveState.signal<Node[]>([]);
  readonly schema = this.reactiveState.signal<readonly ColumnSpec[]>([]);
  readonly fields = computed(() => {
    const plan = this.plan();
    if (!plan.analytics) return guideFields(this.schema());
    try {
      return guideFields(analyticColumns(plan, this.schema()));
    } catch {
      return guideFields(this.schema());
    }
  });
  readonly categoryOptions = computed(() =>
    isTimeChart(this.plan().type) ? this.fields().dates : this.fields().categories,
  );
  readonly measureSearch = this.reactiveState.signal('');
  readonly measureOptions = computed(() => {
    const query = this.measureSearch().trim().toLocaleLowerCase();
    const selected = new Set(this.plan().measureColumnIds);
    return this.fields().measures.filter(
      (column) =>
        selected.has(column.id) ||
        !query ||
        `${column.label} ${column.id} ${column.unit ?? ''}`.toLocaleLowerCase().includes(query),
    );
  });
  readonly raw = computed(() => isRawChart(this.plan().type));
  readonly temporal = computed(
    () => this.fields().metadata.get(this.plan().categoryColumnId ?? '')?.role === 'temporal',
  );
  readonly chartTypes = CHART_DEMO_VARIANTS;
  readonly chartFamilies = [...new Set(CHART_DEMO_VARIANTS.map((variant) => variant.family))];
  readonly aggregations = CHART_AGGREGATIONS;
  readonly buckets = CHART_TIME_BUCKETS;
  readonly legendPositions = CHART_LEGEND_POSITIONS;
  readonly comboTypes = COMBO_SERIES_TYPES;
  readonly slots = computed(() =>
    ['pie', 'donut', 'histogram'].includes(this.plan().type)
      ? [0]
      : this.plan().type === 'scatter'
        ? [0, 1]
        : [0, 1, 2],
  );

  constructor() {
    effect(() => {
      const draft = this.currentDraft();
      untracked(() => this.draftChange.emit(draft));
    });
  }

  currentDraft(): ChartGuideDraft {
    const filters = structuredClone(this.inheritedFilters());
    const validationMessage = this.selectionError();
    const plan = structuredClone(this.plan());
    const measure = plan.measureColumnIds.map((id) => this.fieldLabel(id)).join(' and ');
    plan.title =
      plan.title.trim() ||
      (this.raw()
        ? `${this.chartLabel()}: ${measure}`
        : `${plan.aggregation === 'count' && !measure ? 'Record count' : `${this.aggregationLabel(plan.aggregation ?? 'sum')} ${measure}`} by ${this.fieldLabel(plan.categoryColumnId ?? '')}`
      ).slice(0, 160);
    return {
      plan,
      filters,
      filterControls: chartReaderFilterControls(this.readerFilters()),
      stage: (['gallery', 'fields', 'review'] as const)[this.step()]!,
      valid: this.step() > 0 && !validationMessage,
      validationMessage,
    };
  }

  private selectionError(): string {
    const editing = this.roles().find((role) => this.invalidFields().has(role.label));
    if (editing) return `Choose ${editing.label.toLocaleLowerCase()} from the matching fields.`;
    const invalid = guidePlanError(this.plan(), this.schema());
    if (invalid) return invalid;
    const missing = this.roles().find(
      (role) => (role.kind === 'category' || role.kind === 'measure') && !this.fieldFor(role),
    );
    return missing ? `Choose ${missing.label.toLocaleLowerCase()} to complete this chart.` : '';
  }

  requestAiHelp(): void {
    if (this.interactionLocked) return;
    this.askAi.emit(this.currentDraft());
  }
  dataFilterDescription(): string {
    return filterPreview(this.dataFilter as GridModel, 'advanced', this.columns) || 'All records';
  }
  startFromTableFilter(): void {
    if (this.interactionLocked || !this.tableFilter) return;
    this.filterChange.emit(structuredClone(this.tableFilter));
  }
  previewRecordCount(): number | null {
    const count = (this.liveDataset as Partial<ChartResponse> | null)?.matchedRowCount;
    return typeof count === 'number' && Number.isFinite(count) ? count : null;
  }
  appearanceDescription(): string {
    const appearance = this.previewPresentation?.appearance ?? this.plan().appearance;
    const legend =
      appearance?.showLegend === false
        ? 'Legend hidden'
        : appearance?.showLegend === true
          ? 'Legend shown'
          : 'Automatic legend';
    const labels =
      appearance?.showLabels === true
        ? 'values labeled'
        : appearance?.showLabels === false
          ? 'value labels hidden'
          : 'automatic value labels';
    return `${legend}; ${labels}.`;
  }

  setFamily(family: string): void {
    if (this.interactionLocked) return;
    this.galleryFamily.set(family);
    this.galleryVariant.set('');
    this.gallerySearch.set('');
    if (family) this.recommendationsOnly.set(false);
  }

  variantLabel(label: string): string {
    return label.split(' · ')[1] ?? label;
  }

  optionsFor(role: GuideRole): ColumnSpec[] {
    return this.rankedRoleOptions().get(role.label) ?? [];
  }

  fieldFor(role: GuideRole): string {
    return role.kind === 'category'
      ? (this.plan().categoryColumnId ?? '')
      : (this.plan().measureColumnIds[role.slot ?? 0] ?? '');
  }

  selectField(role: GuideRole, id: string): void {
    if (role.kind === 'category') this.chooseCategory(id);
    else this.selectMeasure(role.slot ?? 0, id);
  }
  setFieldValidity(role: GuideRole, valid: boolean): void {
    this.invalidFields.update((fields) => {
      if (fields.has(role.label) === !valid) return fields;
      const next = new Set(fields);
      if (valid) next.delete(role.label);
      else next.add(role.label);
      return next;
    });
  }

  resetToGallery(force = false): void {
    if (this.interactionLocked && !force) return;
    this.plan.set(defaultGuidePlan('groupedColumn', this.schema()));
    this.invalidFields.set(new Set());
    this.inheritedFilters.set([]);
    this.step.set(0);
    this.furthestStep.set(0);
    this.fieldStep.set(0);
    this.localError.set('');
    this.galleryFamily.set('');
    this.galleryVariant.set('');
    this.gallerySearch.set('');
    this.recommendationsOnly.set(true);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['initialFilterControls'] || changes['resetToken'])
      this.readerFilters.set(chartReaderFilterMode(this.initialFilterControls));
    if (changes['resetToken'] && !changes['resetToken'].firstChange) this.resetToGallery(true);
    if (changes['columns']) {
      this.schema.set(this.columns);
      this.plan.set(defaultGuidePlan('groupedColumn', this.columns));
      this.inheritedFilters.set([]);
      this.step.set(0);
      this.furthestStep.set(0);
      this.fieldStep.set(0);
      this.gallerySearch.set('');
      this.galleryFamily.set('');
      this.galleryVariant.set('');
      this.recommendationsOnly.set(true);
      this.localError.set('');
    }
    if (changes['initialPlan'] && this.initialPlan) {
      this.invalidFields.set(new Set());
      this.plan.set({
        ...structuredClone(this.initialPlan),
        type:
          this.initialPlan.type === 'bar'
            ? 'groupedBar'
            : this.initialPlan.type === 'column'
              ? 'groupedColumn'
              : this.initialPlan.type,
      });
      this.step.set(1);
      this.furthestStep.set(2);
      this.fieldStep.set(0);
      this.localError.set('');
    }
    if (changes['initialFilters']) {
      // Native models already preserve validated date/time and nested AND/OR values.
      this.inheritedFilters.set(structuredClone(this.initialFilters));
    }
    if (
      ['columns', 'dataSource', 'dataReady', 'dataFilter', 'calculatedColumnIds', 'active'].some(
        (key) => changes[key],
      )
    )
      this.refreshGallerySample();
  }
  private refreshGallerySample(): void {
    if (!this.active) {
      this.sampleAbort?.abort();
      if (this.sampleLoading()) this.sampleKey = '';
      this.sampleLoading.set(false);
      return;
    }
    const key = JSON.stringify([
      this.dataSource,
      this.dataReady,
      this.dataFilter,
      this.calculatedColumnIds,
      this.columns.map((column) => column.id),
    ]);
    if (key === this.sampleKey) return;
    this.sampleAbort?.abort();
    this.sampleKey = key;
    this.dataProfile.set(null);
    this.sampleError.set('');
    // The gallery waits for this sample instead of briefly mounting every synthetic
    // illustration and rebuilding those canvases with different fields and values.
    this.sampleLoading.set(this.dataReady && this.columns.length > 0);
    if (!this.dataReady || !this.columns.length) return;
    const controller = new AbortController();
    this.sampleAbort = controller;
    const columns = this.columns;
    this.api.cache
      .sampleChartRows(
        this.dataSource,
        {
          mode: 'advanced',
          filterModel: this.dataFilter as GridModel,
          calculatedColumnIds: this.calculatedColumnIds,
        },
        controller.signal,
      )
      .then((sample) => {
        if (controller.signal.aborted || this.sampleKey !== key) return;
        this.sampleMatchCount.set(sample.matchedRowCount);
        this.dataProfile.set(profileChartRows(columns, sample.rows));
      })
      .catch((error: Error) => {
        if (!controller.signal.aborted && this.sampleKey === key)
          this.sampleError.set(error.message);
      })
      .finally(() => {
        if (!controller.signal.aborted && this.sampleKey === key) this.sampleLoading.set(false);
      });
  }
  ngOnDestroy(): void {
    this.sampleAbort?.abort();
  }
  typesFor(family: string) {
    return this.chartTypes.filter((type) => type.family === family);
  }
  chooseArchetype(id: string): void {
    const item =
      this.recommendedArchetypes().find((candidate) => candidate.candidateId === id) ??
      this.archetypes().find((candidate) => candidate.id === id);
    if (this.interactionLocked || this.sampleLoading() || !item?.supported) return;
    this.invalidFields.set(new Set());
    this.plan.set(structuredClone(item.plan));
    this.fieldStep.set(0);
    this.step.set(1);
    this.furthestStep.update((step) => Math.max(step, 1));
    this.localError.set('');
    this.gallerySearch.set('');
  }
  switchVariant(id: ChartPlan['type']): void {
    const item = this.selectedVariants().find((candidate) => candidate.id === id);
    if (this.interactionLocked || !item?.supported) return;
    this.plan.set(structuredClone(item.plan));
    this.localError.set('');
  }
  chooseRoleField(id: string): void {
    if (this.currentRole()?.kind === 'category') this.chooseCategory(id);
    else this.selectMeasure(this.currentRole()?.slot ?? 0, id);
  }
  addSeries(): void {
    const ids = [...this.plan().measureColumnIds];
    if (
      this.interactionLocked ||
      ids.length >= 3 ||
      this.raw() ||
      ['pie', 'donut'].includes(this.plan().type)
    )
      return;
    const slot = ids.length;
    const next = rankedChartFields(
      this.schema(),
      { kind: 'measure', slot, label: 'Measure', help: '' },
      this.plan(),
      '',
      this.schema().length,
      this.dataProfile(),
    )[0];
    if (!next) return;
    this.patchPlan({
      measureColumnIds: [...ids, next.id],
      seriesChartTypes:
        this.plan().type === 'customCombo'
          ? defaultComboSeries([...ids, next.id], this.columns)
          : null,
    });
    this.fieldStep.set(
      this.roles().findIndex((role) => role.kind === 'measure' && role.slot === slot),
    );
  }
  canRemoveSeries(role: GuideRole): boolean {
    return (
      role.kind === 'measure' &&
      (role.slot ?? 0) > 0 &&
      ['bar', 'groupedBar', 'column', 'groupedColumn', 'line', 'area'].includes(this.plan().type) &&
      this.plan().measureColumnIds.length > 1
    );
  }
  removeSeries(role: GuideRole): void {
    if (this.interactionLocked || !this.canRemoveSeries(role)) return;
    this.patchPlan({
      measureColumnIds: this.plan().measureColumnIds.filter((_, index) => index !== role.slot),
    });
    this.invalidFields.update(
      (fields) => new Set([...fields].filter((label) => label !== role.label)),
    );
  }
  additionalSeriesAvailable(): boolean {
    return (
      !this.raw() &&
      !['pie', 'donut'].includes(this.plan().type) &&
      this.plan().aggregation !== 'count' &&
      this.plan().measureColumnIds.length < 3 &&
      rankedChartFields(
        this.schema(),
        { kind: 'measure', slot: this.plan().measureColumnIds.length, label: 'Measure', help: '' },
        this.plan(),
      ).length > 0
    );
  }
  back(): void {
    if (this.interactionLocked) return;
    this.localError.set('');
    this.step.update((stage) => Math.max(0, stage - 1));
  }
  chartLabel(): string {
    return this.chartTypes.find((type) => type.id === this.plan().type)?.label ?? this.plan().type;
  }
  chooseType(type: ChartPlan['type']): void {
    if (this.interactionLocked) return;
    const previous = this.plan();
    const defaults = defaultGuidePlan(type, this.columns);
    const compatibleCategory = this.categoryOptionsFor(type).find(
      (column) => column.id === previous.categoryColumnId,
    );
    this.plan.set({
      ...defaults,
      ...(compatibleCategory && !isRawChart(type)
        ? {
            categoryColumnId: compatibleCategory.id,
            timeBucket: ['date', 'datetime'].includes(compatibleCategory.kind)
              ? (previous.timeBucket ?? 'month')
              : null,
          }
        : {}),
      title: previous.title,
      appearance: previous.appearance,
    });
    this.localError.set('');
  }
  private categoryOptionsFor(type: ChartPlan['type']) {
    return isTimeChart(type) ? this.fields().dates : this.fields().categories;
  }
  patchPlan(patch: Partial<ChartPlan>): void {
    if (this.interactionLocked) return;
    this.plan.update((plan) => {
      const updated = { ...plan, ...patch };
      if (
        updated.timeRange &&
        (updated.categoryColumnId !== plan.categoryColumnId ||
          updated.timeBucket !== 'day' ||
          !['sum', 'count'].includes(updated.aggregation ?? '') ||
          isRawChart(updated.type))
      )
        delete updated.timeRange;
      return updated;
    });
    this.localError.set('');
  }
  chooseCategory(id: string): void {
    const temporal = this.fields().metadata.get(id)?.role === 'temporal';
    this.patchPlan({
      categoryColumnId: id || null,
      timeBucket: temporal ? (this.plan().timeBucket ?? 'month') : null,
    });
  }
  chooseAggregation(aggregation: NonNullable<ChartPlan['aggregation']>): void {
    this.patchPlan({ aggregation });
  }
  selectMeasure(index: number, id: string): void {
    const ids = [...this.plan().measureColumnIds];
    const previous = ids[index] ?? '';
    const conflict = ids.indexOf(id);
    if (id && conflict >= 0 && conflict < index) return;
    if (id && conflict > index) ids[conflict] = previous;
    ids[index] = id;
    if (
      index === 0 &&
      !this.raw() &&
      this.plan().type !== 'customCombo' &&
      this.plan().aggregation !== 'count'
    ) {
      const unit = this.fields().metadata.get(id)?.unit;
      for (let slot = 1; slot < ids.length; slot++) {
        if (!unit || this.fields().metadata.get(ids[slot]!)?.unit !== unit) {
          ids[slot] =
            this.fields().measures.find(
              (field) =>
                !ids.slice(0, slot).includes(field.id) &&
                Boolean(unit && this.fields().metadata.get(field.id)?.unit === unit),
            )?.id ?? '';
        }
      }
    }
    // Retain empty intermediate slots while editing so X/Y/bubble size never silently switch roles.
    while (ids.length && !ids[ids.length - 1]) ids.pop();
    const oldSeries = this.plan().seriesChartTypes ?? [];
    const defaults = defaultComboSeries(ids, this.columns);
    this.patchPlan({
      measureColumnIds: ids,
      seriesChartTypes:
        this.plan().type === 'customCombo'
          ? defaults.map((series) => oldSeries.find((old) => old.colId === series.colId) ?? series)
          : null,
    });
  }
  countRows(): void {
    this.patchPlan({ measureColumnIds: [], aggregation: 'count', seriesChartTypes: null });
    this.fieldStep.set(this.roles().length - 1);
  }
  measureLabel(index: number): string {
    return this.raw() && this.plan().type !== 'histogram'
      ? ['X measure', 'Y measure', 'Bubble size'][index]
      : index
        ? `Additional measure ${index}`
        : 'Measure';
  }
  fieldLabel(id: string): string {
    return (
      this.plan().analytics?.metrics.find((metric) => metric.id === id)?.label ??
      this.columns.find((column) => column.id === id)?.label ??
      'Choose a measure'
    );
  }
  fieldUnit(id: string): string {
    return this.fields().metadata.get(id)?.unit ?? '';
  }
  aggregationLabel(value: string): string {
    return (
      (
        { sum: 'Total', avg: 'Average', min: 'Minimum', max: 'Maximum', count: 'Count' } as Record<
          string,
          string
        >
      )[value] ?? value
    );
  }
  guidance(): string {
    const type = this.plan().type;
    if (type === 'scatter')
      return 'Compare two numeric values, one point per matching record. Narrow the data first for large datasets.';
    if (type === 'bubble')
      return 'Compare X and Y, with a third nonnegative measure controlling bubble size. Each point is one matching record.';
    if (type === 'histogram')
      return 'See the distribution of one numeric field. Each nonblank matching value is an observation.';
    if (['pie', 'donut'].includes(type))
      return 'Compare parts of a whole using one nonnegative measure or record counts. A category with a few values is easiest to read.';
    if (type.startsWith('normalized'))
      return 'Show each group as percentages of its nonnegative series total. Choose at least two measures for a useful comparison.';
    if (isComboChart(type))
      return 'Compare two or three measures. Use a custom combination with an independent right axis when their units differ.';
    if (isTimeChart(type))
      return 'Show change over time. Monthly buckets are a useful starting point; use quarters or years for long histories.';
    return 'Compare totals, averages or record counts across categories. Choose a category with a manageable number of values.';
  }
  setAppearance(key: keyof ChartAppearance, value: string | boolean | null): void {
    const appearance: ChartAppearance = this.plan().appearance ?? {
      theme: null,
      legendPosition: null,
      showLegend: null,
      showLabels: null,
      xAxisTitle: null,
      yAxisTitle: null,
    };
    this.patchPlan({ appearance: { ...appearance, [key]: value === '' ? null : value } });
  }
  setSeries(index: number, patch: Partial<ChartSeriesType>): void {
    const series = [...(this.plan().seriesChartTypes ?? [])];
    const next = { ...series[index], ...patch };
    if (!['line', 'area'].includes(next.chartType)) next.secondaryAxis = false;
    series[index] = next;
    this.patchPlan({ seriesChartTypes: series });
  }
  next(): void {
    if (this.interactionLocked) return;
    try {
      if (this.step() === 1) {
        const error = this.selectionError();
        if (error) throw new Error(error);
      }
      this.localError.set('');
      this.step.update((step) => Math.min(2, step + 1));
      this.furthestStep.update((step) => Math.max(step, this.step()));
    } catch (error) {
      this.localError.set((error as Error).message);
    }
  }
  showStep(step: number): void {
    if (this.interactionLocked || step < 0 || step > 2 || step > this.furthestStep()) return;
    if (step > this.step()) {
      const error = this.selectionError();
      if (error) {
        this.localError.set(error);
        return;
      }
    }
    this.step.set(step);
    this.localError.set('');
  }
  submit(): void {
    if (this.interactionLocked) return;
    try {
      const filters = structuredClone(this.inheritedFilters());
      const plan = structuredClone(this.plan());
      const error = this.selectionError();
      if (error) {
        this.step.set(1);
        throw new Error(error);
      }
      const measure = plan.measureColumnIds.map((id) => this.fieldLabel(id)).join(' and ');
      plan.title =
        plan.title.trim() ||
        (this.raw()
          ? `${this.chartLabel()}: ${measure}`
          : `${plan.aggregation === 'count' && !measure ? 'Record count' : `${this.aggregationLabel(plan.aggregation!)} ${measure}`} by ${this.fieldLabel(plan.categoryColumnId!)}`
        ).slice(0, 160);
      this.localError.set('');
      this.preview.emit({
        plan,
        filters,
        filterControls: chartReaderFilterControls(this.readerFilters()),
      });
    } catch (error) {
      this.localError.set((error as Error).message);
    }
  }
}
