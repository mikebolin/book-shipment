import { injectUiState } from '../core/state/index';
import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnDestroy,
  ViewChild,
  computed,
  inject,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CdkVirtualScrollViewport, ScrollingModule } from '@angular/cdk/scrolling';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatSelectModule } from '@angular/material/select';
import { MatTooltipModule } from '@angular/material/tooltip';
import { isColumnGroupTag, MAX_COLUMN_GROUP_TAG_LENGTH } from '../core/domain/column-grouping';

export interface CategoryManagerColumn {
  id: string;
  label: string;
  kind: string;
  description: string;
  category?: string;
}
export interface ColumnCategoryManagerData {
  columns: readonly CategoryManagerColumn[];
  categories: readonly string[];
}
export interface ColumnCategoryManagerResult {
  assignments: Record<string, string | undefined>;
  categoryOrder?: readonly string[];
}

@Component({
  selector: 'app-column-category-manager',
  standalone: true,
  imports: [
    FormsModule,
    ScrollingModule,
    MatDialogModule,
    MatButtonModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatMenuModule,
    MatSelectModule,
    MatTooltipModule,
  ],
  templateUrl: './column-category-manager.component.html',
  styleUrl: './column-category-manager.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ColumnCategoryManagerComponent implements AfterViewInit, OnDestroy {
  private readonly reactiveState = injectUiState('ColumnCategoryManagerComponent');

  readonly data = inject<ColumnCategoryManagerData>(MAT_DIALOG_DATA);
  private readonly dialog = inject(MatDialogRef<ColumnCategoryManagerComponent>);
  private readonly element = inject<ElementRef<HTMLElement>>(ElementRef);
  @ViewChild(CdkVirtualScrollViewport) private viewport?: CdkVirtualScrollViewport;
  @ViewChild('categoryName') set nameInput(input: ElementRef<HTMLInputElement> | undefined) {
    if (input)
      queueMicrotask(() => {
        input.nativeElement.focus();
        input.nativeElement.select();
      });
  }
  private readonly initial: Record<string, string | undefined> = Object.fromEntries(
    this.data.columns.map((column) => [column.id, column.category]),
  );
  private readonly initialCategories = [
    ...new Set([
      ...this.data.categories,
      ...this.data.columns
        .map((column) => column.category)
        .filter((category): category is string => !!category),
    ]),
  ];
  readonly categories = this.reactiveState.signal<readonly string[]>(this.initialCategories);
  readonly assignments = this.reactiveState.signal<Record<string, string | undefined>>({
    ...this.initial,
  });
  readonly selected = this.reactiveState.signal<string | undefined>(this.initialCategories[0]);
  readonly allColumns = this.reactiveState.signal(false);
  readonly selectedIds = this.reactiveState.signal<ReadonlySet<string>>(new Set());
  // null means no destination; an empty string explicitly means Uncategorized.
  readonly destination = this.reactiveState.signal<string | null>(null);
  readonly lastMove = this.reactiveState.signal<{
    before: Record<string, string | undefined>;
    count: number;
  } | null>(null);
  readonly query = this.reactiveState.signal('');
  readonly editor = this.reactiveState.signal<{
    mode: 'create' | 'rename';
    original?: string;
  } | null>(null);
  readonly name = this.reactiveState.signal('');
  readonly nameError = this.reactiveState.signal('');
  readonly status = this.reactiveState.signal('');
  readonly maximumLength = MAX_COLUMN_GROUP_TAG_LENGTH;
  readonly counts = computed(() => {
    const counts = new Map<string | undefined, number>();
    for (const column of this.data.columns) {
      const category = this.assignments()[column.id];
      counts.set(category, (counts.get(category) ?? 0) + 1);
    }
    return counts;
  });
  readonly sourceLabel = computed(() =>
    this.allColumns() ? 'All columns' : this.selected() || 'Uncategorized',
  );
  readonly sourceColumns = computed(() =>
    this.data.columns.filter(
      (column) => this.allColumns() || this.assignments()[column.id] === this.selected(),
    ),
  );
  readonly matchingColumns = computed(() => {
    const query = this.query().trim().toLocaleLowerCase();
    return this.sourceColumns().filter(
      (column) =>
        !query ||
        [column.label, column.id, column.description, column.kind, this.assignments()[column.id]]
          .filter(Boolean)
          .join(' ')
          .toLocaleLowerCase()
          .includes(query),
    );
  });
  readonly changes = computed(() =>
    Object.fromEntries(
      this.data.columns
        .filter((column) => this.assignments()[column.id] !== this.initial[column.id])
        .map((column) => [column.id, this.assignments()[column.id]]),
    ),
  );
  readonly changedCount = computed(() => Object.keys(this.changes()).length);
  readonly emptyNewCategories = computed(() =>
    this.categories().filter(
      (category) => !this.initialCategories.includes(category) && !this.counts().get(category),
    ),
  );
  readonly canSave = computed(
    () => this.changedCount() > 0 && !this.editor() && !this.emptyNewCategories().length,
  );
  readonly selectedCount = computed(() => this.selectedIds().size);
  readonly selectedOutsideSearch = computed(() => {
    const shown = new Set(this.matchingColumns().map((column) => column.id));
    return [...this.selectedIds()].filter((id) => !shown.has(id)).length;
  });
  readonly allShownSelected = computed(
    () =>
      this.matchingColumns().length > 0 &&
      this.matchingColumns().every((column) => this.selectedIds().has(column.id)),
  );
  readonly movableIds = computed(() => {
    const destination = this.destination();
    if (destination === null) return [];
    const category = destination || undefined;
    return this.data.columns
      .filter(
        (column) => this.selectedIds().has(column.id) && this.assignments()[column.id] !== category,
      )
      .map((column) => column.id);
  });
  readonly canMove = computed(() => !this.editor() && this.movableIds().length > 0);
  readonly trackColumn = (_index: number, column: CategoryManagerColumn) => column.id;
  private observer?: ResizeObserver;

  ngAfterViewInit(): void {
    this.observer = new ResizeObserver(() => this.viewport?.checkViewportSize());
    this.observer.observe(this.element.nativeElement);
    this.viewport?.checkViewportSize();
  }

  selectCategory(category: string | undefined): void {
    this.allColumns.set(false);
    this.selected.set(category);
    this.resetSourceView();
  }

  selectAllColumns(): void {
    this.allColumns.set(true);
    this.resetSourceView();
  }

  browseForSelected(): void {
    this.destination.set(this.selected() || '');
    this.selectAllColumns();
  }

  private resetSourceView(): void {
    this.query.set('');
    this.selectedIds.set(new Set());
    this.viewport?.scrollToIndex(0);
    this.editor.set(null);
    this.nameError.set('');
  }

  setQuery(query: string): void {
    this.query.set(query);
    this.viewport?.scrollToIndex(0);
  }

  beginCreate(): void {
    this.editor.set({ mode: 'create' });
    this.name.set('');
    this.nameError.set('');
  }

  beginRename(): void {
    const selected = this.selected();
    if (!selected || this.allColumns()) return;
    this.editor.set({ mode: 'rename', original: selected });
    this.name.set(selected);
    this.nameError.set('');
  }

  commitName(event?: Event): void {
    event?.preventDefault();
    const editor = this.editor();
    const name = this.name().trim();
    if (!editor) return;
    if (!isColumnGroupTag(name)) {
      this.nameError.set(
        `Enter a name of 1–${MAX_COLUMN_GROUP_TAG_LENGTH} characters without control characters.`,
      );
      return;
    }
    if (
      this.categories().some(
        (category) =>
          category !== editor.original && category.toLocaleLowerCase() === name.toLocaleLowerCase(),
      )
    ) {
      this.nameError.set('A category with this name already exists.');
      return;
    }
    if (editor.mode === 'rename') {
      this.categories.update((categories) =>
        categories.map((category) => (category === editor.original ? name : category)),
      );
      this.assignments.update((current) =>
        Object.fromEntries(
          Object.entries(current).map(([id, category]) => [
            id,
            category === editor.original ? name : category,
          ]),
        ),
      );
      if (this.destination() === editor.original) this.destination.set(name);
      this.lastMove.set(null);
      this.selectCategory(name);
      this.status.set(`Category renamed to ${name}. Save changes to apply.`);
    } else {
      this.categories.update((categories) => [...categories, name]);
      this.destination.set(name);
      this.editor.set(null);
      this.nameError.set('');
      this.status.set(
        `${name} created and selected as your destination. Select columns and choose Move selected.`,
      );
    }
  }

  deleteCategory(): void {
    const category = this.selected();
    if (!category || this.allColumns()) return;
    const count = this.counts().get(category) ?? 0;
    this.categories.update((categories) => categories.filter((name) => name !== category));
    this.assignments.update((current) =>
      Object.fromEntries(
        Object.entries(current).map(([id, value]) => [id, value === category ? undefined : value]),
      ),
    );
    if (this.destination() === category) this.destination.set(null);
    this.lastMove.set(null);
    this.selectCategory(undefined);
    this.status.set(
      `${category} removed from this draft. ${count} columns are now uncategorized. Save changes to apply.`,
    );
  }

  toggleColumn(column: CategoryManagerColumn, checked: boolean): void {
    this.selectedIds.update((current) => {
      const next = new Set(current);
      checked ? next.add(column.id) : next.delete(column.id);
      return next;
    });
  }

  selectShown(): void {
    const shown = this.matchingColumns();
    this.selectedIds.update((current) => {
      const next = new Set(current);
      for (const column of shown) next.add(column.id);
      return next;
    });
    this.status.set(
      `${this.selectedCount()} columns selected. Choose a destination, then Move selected.`,
    );
  }

  clearSelection(): void {
    this.selectedIds.set(new Set());
  }

  moveSelected(): void {
    if (!this.canMove()) return;
    const ids = this.movableIds();
    const destination = this.destination();
    if (destination === null || (destination && !this.categories().includes(destination))) return;
    this.lastMove.set({
      before: Object.fromEntries(ids.map((id) => [id, this.assignments()[id]])),
      count: ids.length,
    });
    this.assignments.update((current) => {
      const next = { ...current };
      for (const id of ids) next[id] = destination || undefined;
      return next;
    });
    this.clearSelection();
    this.viewport?.checkViewportSize();
    this.status.set(
      `${ids.length} ${ids.length === 1 ? 'column' : 'columns'} moved to ${destination || 'Uncategorized'}. Save changes to apply.`,
    );
  }

  undoMove(): void {
    const move = this.lastMove();
    if (!move) return;
    this.assignments.update((current) => ({ ...current, ...move.before }));
    this.lastMove.set(null);
    this.clearSelection();
    this.status.set(
      `Last move undone. ${move.count} columns restored to their previous categories.`,
    );
  }

  save(): void {
    if (this.canSave())
      this.dialog.close({
        assignments: this.changes(),
        categoryOrder: this.categories(),
      } satisfies ColumnCategoryManagerResult);
  }

  ngOnDestroy(): void {
    this.observer?.disconnect();
  }
}
