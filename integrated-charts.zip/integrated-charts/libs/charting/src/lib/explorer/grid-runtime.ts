import { ModuleRegistry } from 'ag-grid-community';
import { AllEnterpriseModule, LicenseManager } from 'ag-grid-enterprise';

let registered = false;
/** Loaded by interactive data routes, never by the metadata-only galleries. */
export function registerGridRuntime(): void {
  if (registered) return;
  ModuleRegistry.registerModules([AllEnterpriseModule]);
  const key = (window as unknown as { AG_GRID_LICENSE_KEY?: string }).AG_GRID_LICENSE_KEY;
  if (key) LicenseManager.setLicenseKey(key);
  registered = true;
}
