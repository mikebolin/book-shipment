import { applyUploadSemantics } from '../core/domain/upload-semantics';
import type { ColumnSpec } from '../core/domain/schema';
import type { LocalDataset, LocalDataSourceId, LocalField } from './client-data-sources';
import type { StreamRow } from './ndjson-row-stream';
import { Temporal } from '@js-temporal/polyfill';

export const LOCAL_JSON_LIMITS = {
  bytes: 800 * 1024 * 1024,
  rows: 250000,
  columns: 500,
  cells: 10000000,
  cellCharacters: 1000000,
} as const;
export interface LocalImportProgress {
  phase: 'reading' | 'parsing' | 'inferring' | 'recipes';
  rowsProcessed?: number;
  totalRows?: number;
}
export interface LocalImportOptions {
  signal?: AbortSignal;
  onProgress?: (progress: LocalImportProgress) => void;
  /** Optional local-only schema sidecar; it never authorizes outbound disclosure. */
  metadata?: unknown;
  /** Skip automatically calculated example previews for a prompt-only fixture. */
  skipRecipes?: boolean;
}
interface FieldStats {
  name: string;
  present: number;
  nonNull: number;
  kinds: Set<string>;
  values: Set<string>;
  distinct: Set<string>;
  dates: boolean;
  timestamps: boolean;
  fractional: boolean;
}
function fail(message: string): never {
  throw new Error(message);
}
const object = (value: unknown): value is Record<string, unknown> =>
  !!value && typeof value === 'object' && !Array.isArray(value);
const validDate = (value: string): boolean =>
  /^\d{4}-\d{2}-\d{2}$/.test(value) &&
  Number.isFinite(Date.parse(value)) &&
  new Date(value).toISOString().slice(0, 10) === value;
const validTimestamp = (value: string): boolean => {
  if (
    !/^\d{4}-\d{2}-\d{2}T(?:[01]\d|2[0-3]):[0-5]\d:[0-5]\d(?:\.\d{1,9})?(?:Z|[+-](?:[01]\d|2[0-3]):[0-5]\d)$/i.test(
      value,
    )
  )
    return false;
  try {
    Temporal.Instant.from(value);
    return true;
  } catch {
    return false;
  }
};
const identifierName = (name: string): boolean =>
  /(^id$|(?:^|[_\s-])(?:id|key|uuid|guid)$|(?:Id|ID|Key|UUID|GUID)$|surrogate|primary.?key|foreign.?key)/.test(
    name,
  );
const cellText = (value: unknown): string =>
  typeof value === 'string'
    ? value
    : typeof value === 'object'
      ? JSON.stringify(value)
      : String(value);

/** Pure bounded parser, shared by the worker and offline tests. */
export function parseLocalJson(
  text: string,
  fileName = 'Uploaded data.json',
  options: LocalImportOptions = {},
): LocalDataset {
  options.signal?.throwIfAborted();
  const bytes = new TextEncoder().encode(text).byteLength;
  if (bytes > LOCAL_JSON_LIMITS.bytes) fail('Choose a JSON file no larger than 800 MiB.');
  options.onProgress?.({ phase: 'parsing' });
  const warnings = new Set<string>();
  let parsed: unknown;
  try {
    parsed = JSON.parse(
      text.replace(/^\uFEFF/, ''),
      (_key, value, context?: { source: string }) => {
        if (
          typeof value === 'number' &&
          (!Number.isFinite(value) || (Number.isInteger(value) && !Number.isSafeInteger(value)))
        ) {
          if (!context?.source)
            fail(
              'An integer exceeds JavaScript precision. Quote large IDs and integer values in the JSON file to preserve them exactly.',
            );
          warnings.add(
            'Integers outside JavaScript safe precision are preserved as text, including their original digits.',
          );
          return context.source;
        }
        return value;
      },
    );
  } catch (error) {
    if (error instanceof SyntaxError)
      fail(
        'The file is not valid JSON. Use an array of objects, or an object with a rows or data array.',
      );
    throw error;
  }
  const records = Array.isArray(parsed)
    ? parsed
    : object(parsed) && Array.isArray(parsed['rows'])
      ? parsed['rows']
      : object(parsed) && Array.isArray(parsed['data'])
        ? parsed['data']
        : undefined;
  if (!records) fail('Use an array of objects, or an object containing a rows or data array.');
  if (!records.length) fail('The JSON array is empty. Include at least one row with named fields.');
  if (records.length > LOCAL_JSON_LIMITS.rows)
    fail('This local demo accepts at most 250,000 rows per file; no rows were imported.');
  const fields = new Map<string, FieldStats>();
  let cells = 0;
  for (let index = 0; index < records.length; index++) {
    options.signal?.throwIfAborted();
    const row: unknown = records[index];
    if (!object(row)) fail(`Row ${index + 1} must be an object with named fields.`);
    for (const [name, value] of Object.entries(row)) {
      if (!name.length || name.length > 200 || /[\u0000-\u001f\u007f]/.test(name))
        fail(`Row ${index + 1} has an empty, control-character, or overlong field name.`);
      if (++cells > LOCAL_JSON_LIMITS.cells)
        fail(
          'This local demo accepts at most 10,000,000 populated cells per file; choose fewer rows or fields.',
        );
      let stats = fields.get(name);
      if (!stats) {
        if (fields.size >= LOCAL_JSON_LIMITS.columns)
          fail('This local demo accepts at most 500 fields per file.');
        stats = {
          name,
          present: 0,
          nonNull: 0,
          kinds: new Set(),
          values: new Set(),
          distinct: new Set(),
          dates: true,
          timestamps: true,
          fractional: false,
        };
        fields.set(name, stats);
      }
      stats.present++;
      if (value === null) continue;
      const display = cellText(value);
      if (display.length > LOCAL_JSON_LIMITS.cellCharacters)
        fail(`Field ${JSON.stringify(name)} contains a value longer than 1,000,000 characters.`);
      stats.nonNull++;
      stats.kinds.add(typeof value === 'object' ? 'json' : typeof value);
      if (stats.values.size <= 30) stats.values.add(display);
      stats.distinct.add(`${typeof value}:${display}`);
      stats.dates &&= typeof value === 'string' && validDate(value);
      stats.timestamps &&= typeof value === 'string' && validTimestamp(value);
      stats.fractional ||=
        typeof value === 'string' && /\.\d*[1-9]\d*(?:Z|[+-]\d{2}:\d{2})$/i.test(value);
    }
    if (index % 4096 === 0)
      options.onProgress?.({ phase: 'inferring', rowsProcessed: index, totalRows: records.length });
  }
  if (!fields.size) fail('The rows have no named fields. Include at least one data field.');
  if (fields.size * records.length > LOCAL_JSON_LIMITS.cells)
    fail(
      'This local demo accepts at most 10,000,000 grid cells including missing values; choose fewer rows or fields.',
    );
  const id = `local_${crypto.randomUUID().replaceAll('-', '')}` as LocalDataSourceId;
  const used = new Set(['id', 'tenant', 'constructor', 'prototype', '__proto__']);
  const columns: ColumnSpec[] = [
    {
      id: 'id',
      label: 'Row ID',
      kind: 'text',
      aliases: ['row id'],
      nullable: false,
      sql: 'ROW_ID',
      description: 'Stable browser-generated row identifier; not a numeric measure.',
      chartRole: 'identifier',
    },
  ];
  const originalFields: LocalField[] = [];
  for (const stats of fields.values()) {
    let candidate =
      stats.name
        .normalize('NFKD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^A-Za-z0-9_]+/g, '_')
        .replace(/^_+|_+$/g, '')
        .slice(0, 70) || 'field';
    if (!/^[A-Za-z]/.test(candidate) || /^calc_/i.test(candidate)) candidate = 'field_' + candidate;
    const base = candidate;
    for (let suffix = 2; used.has(candidate.toLowerCase()); suffix++)
      candidate = `${base}_${suffix}`;
    used.add(candidate.toLowerCase());
    const nullable = stats.nonNull < records.length;
    const unique = stats.nonNull === records.length && stats.distinct.size === records.length;
    const namedKey = identifierName(stats.name);
    const inferredType: LocalField['inferredType'] =
      stats.kinds.size > 1
        ? 'mixed'
        : !stats.nonNull
          ? 'text'
          : stats.kinds.has('number')
            ? 'number'
            : stats.kinds.has('boolean')
              ? 'boolean'
              : stats.kinds.has('json')
                ? 'json'
                : stats.dates
                  ? 'date'
                  : stats.timestamps
                    ? 'datetime'
                    : 'text';
    const gridType =
      inferredType === 'datetime' && stats.fractional
        ? 'text'
        : ['number', 'date', 'datetime'].includes(inferredType)
          ? (inferredType as 'number' | 'date' | 'datetime')
          : 'text';
    if (inferredType === 'datetime' && stats.fractional)
      warnings.add(
        'Timestamps with fractional seconds are kept as their exact original text because the grid date filter supports whole seconds. Text equality preserves distinctions such as .123 and .987.',
      );
    if (inferredType === 'boolean')
      warnings.add(
        'Boolean fields use the categorical labels true and false in grid filters; they are never summed.',
      );
    if (inferredType === 'mixed')
      warnings.add(
        'Fields containing mixed primitive types are displayed as text without guessing numeric conversions.',
      );
    if (stats.kinds.has('json'))
      warnings.add(
        'Nested objects and arrays are preserved as JSON text in their original field; they are not flattened.',
      );
    const values =
      gridType === 'text' &&
      stats.values.size > 0 &&
      stats.values.size <= 20 &&
      new Set([...stats.values].map((value) => value.toLowerCase())).size === stats.values.size
        ? [...stats.values]
        : undefined;
    columns.push({
      id: candidate,
      label: stats.name,
      kind: gridType,
      aliases: [stats.name, candidate].filter((value, index, all) => all.indexOf(value) === index),
      nullable,
      sql: candidate.toUpperCase(),
      description: `Imported JSON field ${JSON.stringify(stats.name)}. Inferred ${inferredType}; ${nullable ? 'missing values remain blank' : 'every row has a value'}.${namedKey ? ' Identifier/key field; excluded from numeric chart measures.' : ''}`,
      ...(values ? { values } : {}),
      chartRole: namedKey
        ? 'identifier'
        : gridType === 'number'
          ? 'measure'
          : gridType === 'date' || gridType === 'datetime'
            ? 'temporal'
            : 'dimension',
    });
    originalFields.push({
      originalName: stats.name,
      columnId: candidate,
      inferredType,
      gridType,
      nullable,
      identifier: namedKey,
      unique,
    });
  }
  const keyFieldId = originalFields.find((field) => field.identifier && field.unique)?.columnId;
  const rows: StreamRow[] = records.map((record: Record<string, unknown>, index: number) => {
    const row: StreamRow = Object.create(null);
    row.id = `${id}:${index + 1}`;
    for (const field of originalFields) {
      const value = Object.hasOwn(record, field.originalName) ? record[field.originalName] : null;
      row[field.columnId] =
        value == null
          ? null
          : field.gridType === 'number'
            ? (value as number)
            : field.gridType === 'datetime'
              ? Temporal.Instant.from(String(value))
                  .toString({ smallestUnit: 'second' })
                  .replace('T', ' ')
                  .replace('Z', '')
              : cellText(value);
    }
    return row;
  });
  const semantics = options.metadata ?? (object(parsed) ? parsed['metadata'] : undefined);
  if (semantics !== undefined) {
    const enriched = applyUploadSemantics(columns, originalFields, semantics);
    columns.splice(0, columns.length, ...enriched);
  }
  options.onProgress?.({ phase: 'inferring', rowsProcessed: rows.length, totalRows: rows.length });
  const label =
    fileName
      .replace(/\.json$/i, '')
      .trim()
      .slice(0, 100) || 'Uploaded data';
  return {
    metadata: {
      id,
      local: true,
      label,
      description: `${rows.length.toLocaleString()} rows imported locally from ${fileName}.`,
      rowLabel: 'row',
      version: `${id}-v1`,
      columns,
      sqlDataset: {
        columns,
        table: ['LOCAL_JSON_PREVIEW'],
        tenantColumn: 'LOCAL_TENANT',
        rowIdColumn: 'id',
      },
      defaultVisibleColumnIds: originalFields.slice(0, 10).map((field) => field.columnId),
    },
    rows,
    originalFields,
    ...(keyFieldId ? { keyFieldId } : {}),
    warnings: [...warnings],
    provenance: {
      kind: 'local-json',
      fileName,
      bytes,
      importedAt: new Date().toISOString(),
      rowCount: rows.length,
    },
  };
}
