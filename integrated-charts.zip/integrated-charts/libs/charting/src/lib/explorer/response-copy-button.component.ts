import { injectUiState } from '../core/state/index';
import { ChangeDetectionStrategy, Component, Input, OnDestroy, inject } from '@angular/core';
import { Clipboard } from '@angular/cdk/clipboard';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';

/** Copies the received object verbatim as JSON; it never derives a response from chart rows. */
@Component({
  selector: 'app-response-copy-button',
  standalone: true,
  imports: [MatButtonModule, MatIconModule, MatTooltipModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <button
      mat-icon-button
      type="button"
      [disabled]="disabled || value == null || copying()"
      [attr.aria-label]="label"
      [matTooltip]="copied() ? 'Copied to clipboard' : label"
      (click)="copy()"
    >
      <mat-icon aria-hidden="true">{{ copied() ? 'check' : 'content_copy' }}</mat-icon>
    </button>
    <span class="copy-status" role="status" aria-live="polite">{{
      copied() ? 'Copied to clipboard' : ''
    }}</span>
    @if (error()) {
      <span class="copy-error" role="alert">{{ error() }}</span>
    }
  `,
  styles: [
    `
      :host {
        position: relative;
        display: inline-flex;
        flex-shrink: 0;
        align-items: center;
      }
      .copy-status {
        position: absolute;
        width: 1px;
        height: 1px;
        overflow: hidden;
        clip-path: inset(50%);
      }
      .copy-error {
        position: absolute;
        z-index: 2;
        top: 100%;
        right: 0;
        width: min(240px, 65vw);
        padding: 8px 10px;
        border: 1px solid var(--mat-sys-outline-variant);
        border-radius: 8px;
        background: var(--mat-sys-surface-container);
        color: var(--mat-sys-error);
        font-size: 11px;
        line-height: 1.5;
        box-shadow: var(--mat-sys-level2);
      }
    `,
  ],
})
export class ResponseCopyButtonComponent implements OnDestroy {
  private readonly reactiveState = injectUiState('ResponseCopyButtonComponent');

  @Input() value: unknown;
  @Input() label = 'Copy generation response';
  @Input() disabled = false;
  readonly copied = this.reactiveState.signal(false);
  readonly copying = this.reactiveState.signal(false);
  readonly error = this.reactiveState.signal('');
  private readonly clipboard = inject(Clipboard);
  private resetTimer?: ReturnType<typeof setTimeout>;

  async copy(): Promise<void> {
    if (this.disabled || this.value == null || this.copying()) return;
    this.copying.set(true);
    this.error.set('');
    try {
      const text = JSON.stringify(this.value, null, 2);
      let copied = false;
      if (navigator.clipboard?.writeText) {
        try {
          await navigator.clipboard.writeText(text);
          copied = true;
        } catch {
          /* Fall back when clipboard permissions are restricted. */
        }
      }
      if (!copied) copied = this.clipboard.copy(text);
      if (!copied) throw new Error('Clipboard unavailable. Allow clipboard access and try again.');
      this.copied.set(true);
      clearTimeout(this.resetTimer);
      this.resetTimer = setTimeout(() => this.copied.set(false), 2200);
    } catch (error) {
      this.error.set(
        error instanceof Error ? error.message : 'Could not copy this response. Please try again.',
      );
    } finally {
      this.copying.set(false);
    }
  }
  ngOnDestroy(): void {
    clearTimeout(this.resetTimer);
  }
}
