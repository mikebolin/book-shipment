/** Palette slots follow the application theme, including menus and retained grids. */
export type ColumnHighlightColor = '1' | '2' | '3' | '4' | '5' | '6';
export type ColumnHighlights = Readonly<Record<string, ColumnHighlightColor>>;

export const COLUMN_HIGHLIGHT_COLORS: readonly {
  id: ColumnHighlightColor;
  label: string;
  cssVariable: string;
}[] = Object.freeze(
  (['1', '2', '3', '4', '5', '6'] as const).map((id) => ({
    id,
    label: `Color ${id}`,
    cssVariable: `--app-chart-${id}`,
  })),
);

export function isColumnHighlightColor(value: unknown): value is ColumnHighlightColor {
  return typeof value === 'string' && /^[1-6]$/.test(value);
}

export function columnHighlightClass(color: ColumnHighlightColor): string {
  return `explorer-column-highlight-${color}`;
}
