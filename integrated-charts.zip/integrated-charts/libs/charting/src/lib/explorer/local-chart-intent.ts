import { Temporal } from '@js-temporal/polyfill';
import type { Node } from '../core/domain/contracts';
import { Fault, plainDate, rule } from '../core/domain/engine';
import type { ChartPlan } from '../core/domain/integrated-chart';
import type { ColumnSpec } from '../core/domain/schema';

const normalized = (value: string) => value.normalize('NFKC').trim().replace(/\s+/g, ' ');
const words = (value: string) =>
  normalized(value.replace(/([a-z0-9])([A-Z])/g, '$1 $2'))
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
const MONTHS = [
  'january',
  'february',
  'march',
  'april',
  'may',
  'june',
  'july',
  'august',
  'september',
  'october',
  'november',
  'december',
];
const MONTH = `(?:${MONTHS.join('|')}|jan|feb|mar|apr|jun|jul|aug|sep|sept|oct|nov|dec)`;
const NATURAL_RANGE = new RegExp(
  `^(${MONTH})\\s+(\\d{1,2})(?:st|nd|rd|th)?(?:,?\\s+(\\d{4}))?\\s+` +
    `(?:through|to)\\s+(?:(${MONTH})\\s+)?(\\d{1,2})(?:st|nd|rd|th)?(?:,?\\s+(\\d{4}))?` +
    '(?=$|[\\s.,;])',
  'i',
);
type LocalChartIntent = { plan: ChartPlan; filter: Node; summary: string };
const CURRENCIES = /\b(?:usd|eur|gbp|jpy|cad|aud|chf)\b/g;

function columnNames(column: ColumnSpec): string[] {
  return [column.id, column.label, ...column.aliases].map(words);
}

function namedMeasure(name: string, columns: ColumnSpec[]): ColumnSpec {
  const requested = words(name).replace(/^the /, '');
  const matches = columns.filter(
    (column) =>
      column.kind === 'number' &&
      column.chartRole !== 'identifier' &&
      columnNames(column).some(
        (alias) =>
          alias === requested ||
          alias.replace(CURRENCIES, '').replace(/\s+/g, ' ').trim() === requested,
      ),
  );
  if (matches.length !== 1)
    throw new Fault(
      'CHART_MEASURE',
      matches.length
        ? `The measure ${JSON.stringify(name)} matches multiple columns. Choose its exact field in the chart builder.`
        : `No numeric measure matches ${JSON.stringify(name)} in this dataset.`,
    );
  return matches[0];
}

function columnCurrency(column: ColumnSpec): string | null {
  const currencies = new Set(
    [words(column.unit ?? ''), ...columnNames(column)]
      .flatMap((name) => name.match(CURRENCIES) ?? [])
      .map((currency) => currency.toUpperCase()),
  );
  return currencies.size === 1 ? [...currencies][0] : null;
}

/** Resolve a list of categorical values against a single unambiguous schema column. */
function valueSelection(
  input: string,
  columns: ColumnSpec[],
): { column: ColumnSpec; values: string[] } | null {
  const candidates: { column: ColumnSpec; values: string[] }[] = [];
  for (const column of columns.filter(
    (candidate) => candidate.kind === 'text' && candidate.values?.length,
  )) {
    const allowed = [...column.values!].sort((left, right) => right.length - left.length);
    const values: string[] = [];
    let rest = input.trim();
    while (rest) {
      const quoted = rest[0] === '"' || rest[0] === "'";
      const valueStart = quoted ? 1 : 0;
      const value = allowed.find((candidate) => {
        const name = normalized(candidate);
        return (
          rest.slice(valueStart, valueStart + name.length).toLowerCase() === name.toLowerCase() &&
          (quoted
            ? rest[valueStart + name.length] === rest[0]
            : !/[\p{L}\p{N}_]/u.test(rest[valueStart + name.length] ?? ''))
        );
      });
      if (!value) break;
      values.push(value);
      rest = rest.slice(normalized(value).length + (quoted ? 2 : 0)).trim();
      if (!rest) break;
      const separator = /^(?:,\s*(?:and\s+|or\s+)?|(?:and|or)\s+)/i.exec(rest);
      if (!separator) break;
      rest = rest.slice(separator[0].length).trim();
      if (!rest) {
        values.length = 0;
        break;
      }
    }
    if (!rest && values.length) candidates.push({ column, values: [...new Set(values)] });
  }
  if (candidates.length > 1)
    throw new Fault(
      'CHART_SCOPE',
      'These outcome values match multiple columns. Choose the outcome field in the chart builder.',
    );
  return candidates[0] ?? null;
}

function monthlyCombinationIntent(input: string, columns: ColumnSpec[]): LocalChartIntent | null {
  const headline =
    /^for\s+(?:the\s+)?orders\s+placed\s+(.+?),\s*(?:create|make|build|show)\s+(?:a\s+)?monthly\s+(?:combination|combo)\s+chart\s+with\s+(.+?)\s+as\s+columns\s+and\s+(.+?)\s+as\s+(?:a\s+)?line(?=$|[.;])/i.exec(
      input,
    );
  if (!headline) return null;
  const calendar = new RegExp(
    `^(${MONTH})(?:\\s+(\\d{4}))?\\s+(?:through|to)\\s+(${MONTH})(?:\\s+(\\d{4}))?(?=$|\\s)`,
    'i',
  ).exec(headline[1]);
  if (!calendar) return null;
  const year = calendar[2] ?? calendar[4];
  if (!year) throw new Fault('CHART_DATE_RANGE', 'Include the year for the monthly chart.');
  const monthStart = (month: string, dateYear: string) =>
    Temporal.PlainDate.from(
      plainDate(
        `${dateYear}-${String(MONTHS.findIndex((name) => name.startsWith(month.slice(0, 3).toLowerCase())) + 1).padStart(2, '0')}-01`,
      ),
    );
  const start = monthStart(calendar[1], year).toString();
  const endExclusive = monthStart(calendar[3], calendar[4] ?? year)
    .add({ months: 1 })
    .toString();
  if (start >= endExclusive)
    throw new Fault(
      'CHART_DATE_RANGE',
      'The final chart month must be on or after its first month.',
    );
  const scope = scopeFilters(headline[1].slice(calendar[0].length).trim(), columns);
  if (!scope) return null;
  const columnMeasure = namedMeasure(headline[2], columns);
  const lineMeasure = namedMeasure(headline[3], columns);
  if (columnMeasure.id === lineMeasure.id)
    throw new Fault('CHART_MEASURE', 'Choose two distinct measures for this combination chart.');
  const placement = columns.filter(
    (column) =>
      (column.kind === 'date' || column.kind === 'datetime') &&
      columnNames(column).some((name) =>
        /\b(?:order(?:ed)? (?:at|date|time|timestamp)|(?:order )?placement (?:date|time)|placed (?:at|on|date))\b/.test(
          name,
        ),
      ),
  );
  const dates = placement.filter((column) => column.kind === 'date');
  const dateChoices = dates.length ? dates : placement;
  if (dateChoices.length !== 1)
    throw new Fault(
      'CHART_DATE_COLUMN',
      dateChoices.length
        ? 'More than one order-placement date matches. Choose the date field in the chart builder.'
        : 'No unambiguous order-placement date is available in this dataset.',
    );
  const date = dateChoices[0];
  let rest = input.slice(headline[0].length);
  let included: ReturnType<typeof valueSelection> = null;
  let excluded: ReturnType<typeof valueSelection> = null;
  let sumCurrency: string | undefined;
  let axisCurrency: string | undefined;
  let preserveLosses = false;
  while (rest.trim()) {
    rest = rest.replace(/^[\s.,;]+/, '').replace(/^and\s+/i, '');
    if (!rest) break;
    const include = /^include\s+(.+?)\s+orders(?=$|[,.;])/i.exec(rest);
    const exclude = /^exclude\s+(.+?)(?=$|[,.;])/i.exec(rest);
    const sum = /^sum\s+both\s+(USD|EUR|GBP|JPY|CAD|AUD|CHF)\s+measures(?=$|[\s,.;])/i.exec(rest);
    const axis = /^use\s+(?:the\s+)?same\s+(USD|EUR|GBP|JPY|CAD|AUD|CHF)\s+axis(?=$|[\s,.;])/i.exec(
      rest,
    );
    const losses =
      /^(?:keep|retain|preserve)\s+(?:return[- ]related\s+losses|negative\s+(?:values|contributions|profits))(?=$|[\s,.;])/i.exec(
        rest,
      );
    const order =
      /^(?:sort|order)\s+(?:the\s+)?months\s+(?:chronologically|(?:in\s+)?ascending\s+order|(?:from\s+)?earliest\s+to\s+latest)(?=$|[\s,.;])/i.exec(
        rest,
      );
    const clause = include ?? exclude ?? sum ?? axis ?? losses ?? order;
    if (!clause) return null;
    if (include) {
      if (included) return null;
      included = valueSelection(include[1], columns);
      if (!included) return null;
    }
    if (exclude) {
      if (excluded) return null;
      excluded = valueSelection(exclude[1], columns);
      if (!excluded) return null;
    }
    if (sum) {
      if (sumCurrency && sumCurrency !== sum[1].toUpperCase()) return null;
      sumCurrency = sum[1].toUpperCase();
    }
    if (axis) {
      if (axisCurrency && axisCurrency !== axis[1].toUpperCase()) return null;
      axisCurrency = axis[1].toUpperCase();
    }
    if (losses) preserveLosses = true;
    rest = rest.slice(clause[0].length);
  }
  if (!sumCurrency || !axisCurrency)
    throw new Fault(
      'CHART_AGGREGATION',
      'Specify summing both measures and their shared currency axis.',
    );
  if (
    sumCurrency !== axisCurrency ||
    columnCurrency(columnMeasure) !== sumCurrency ||
    columnCurrency(lineMeasure) !== sumCurrency
  )
    throw new Fault(
      'CHART_UNITS',
      'Both measures must have the requested currency in their metadata or field names to share that axis.',
    );
  if (
    included &&
    excluded &&
    included.column.id === excluded.column.id &&
    included.values.some((value) => excluded!.values.includes(value))
  )
    throw new Fault('CHART_SCOPE', 'An outcome cannot be both included and excluded.');
  const children = [...scope];
  if (included) {
    const values = included.values.map((value) => rule(included!.column.id, 'equals', value));
    children.push(
      values.length === 1 ? values[0] : { kind: 'group', join: 'OR', children: values },
    );
  }
  if (excluded)
    children.push(...excluded.values.map((value) => rule(excluded!.column.id, 'notEqual', value)));
  const dateValue = (value: string) => (date.kind === 'datetime' ? `${value} 00:00:00` : value);
  children.push(
    rule(date.id, 'greaterThanOrEqual', dateValue(start)),
    rule(date.id, 'lessThan', dateValue(endExclusive)),
  );
  return {
    plan: {
      type: 'customCombo',
      categoryColumnId: date.id,
      measureColumnIds: [columnMeasure.id, lineMeasure.id],
      aggregation: 'sum',
      timeBucket: 'month',
      title: `Monthly ${columnMeasure.label} and ${lineMeasure.label}`.slice(0, 160),
      seriesChartTypes: [
        { colId: columnMeasure.id, chartType: 'groupedColumn', secondaryAxis: false },
        { colId: lineMeasure.id, chartType: 'line', secondaryAxis: false },
      ],
      appearance: {
        theme: null,
        legendPosition: null,
        showLegend: null,
        showLabels: null,
        xAxisTitle: null,
        yAxisTitle: sumCurrency,
      },
    },
    filter: { kind: 'group', join: 'AND', children },
    summary: `Sum ${columnMeasure.label} as columns and ${lineMeasure.label} as a line by ${date.label}, from ${start} before ${endExclusive}. Both series use the same ${sumCurrency} axis; months run earliest to latest.${preserveLosses ? ' Negative values, including return-related losses, are retained.' : ''}`,
  };
}

function dateRange(input: string): { start: string; end: string; rest: string } | null {
  const iso = /^(\d{4}-\d{2}-\d{2})\s+(?:through|to)\s+(\d{4}-\d{2}-\d{2})(?=$|[\s.,;])/i.exec(
    input,
  );
  if (iso)
    return { start: plainDate(iso[1]), end: plainDate(iso[2]), rest: input.slice(iso[0].length) };
  const natural = NATURAL_RANGE.exec(input);
  if (!natural) return null;
  const year = natural[3] ?? natural[6];
  if (!year) throw new Fault('CHART_DATE_RANGE', 'Include a year in the chart date range.');
  const asDate = (month: string, day: string, dateYear: string) =>
    plainDate(
      `${dateYear}-${String(MONTHS.findIndex((name) => name.startsWith(month.toLowerCase().slice(0, 3))) + 1).padStart(2, '0')}-${day.padStart(2, '0')}`,
    );
  return {
    start: asDate(natural[1], natural[2], year),
    end: asDate(natural[4] ?? natural[1], natural[5], natural[6] ?? year),
    rest: input.slice(natural[0].length),
  };
}

function scopeFilters(input: string, columns: ColumnSpec[]): Node[] | null {
  const candidates = columns
    .filter((column) => column.kind === 'text')
    .flatMap((column) =>
      (column.values ?? []).filter(Boolean).map((value) => ({
        column,
        value,
        match: normalized(value).toLowerCase(),
      })),
    )
    .sort((left, right) => right.match.length - left.match.length);
  const selected = new Map<string, { column: ColumnSpec; value: string }>();
  let remainder = '';
  const lower = input.toLowerCase();
  const wordCharacter = (character: string | undefined) =>
    !!character && /[\p{L}\p{N}_]/u.test(character);
  for (let offset = 0; offset < input.length; ) {
    const matches = candidates.filter(
      (candidate) =>
        lower.startsWith(candidate.match, offset) &&
        !wordCharacter(input[offset - 1]) &&
        !wordCharacter(input[offset + candidate.match.length]),
    );
    const longest = matches[0]?.match.length;
    const exact = matches.filter((candidate) => candidate.match.length === longest);
    if (!exact.length) {
      remainder += input[offset++];
      continue;
    }
    if (new Set(exact.map((candidate) => candidate.column.id)).size > 1)
      throw new Fault(
        'CHART_SCOPE',
        `The value ${JSON.stringify(exact[0].value)} occurs in multiple columns. Specify the filter in the chart builder.`,
      );
    const candidate = exact[0];
    const previous = selected.get(candidate.column.id);
    if (previous && previous.value !== candidate.value)
      throw new Fault(
        'CHART_SCOPE',
        `Choose one ${candidate.column.label} value for this chart, or use the chart builder.`,
      );
    selected.set(candidate.column.id, candidate);
    remainder += ' ';
    offset += candidate.match.length;
  }
  const allowed = new Set(['for', 'the', 'in', 'of', 'with', 'where', 'is', 'equals', 'and']);
  for (const { column } of selected.values())
    for (const name of [column.id, column.label, ...column.aliases])
      for (const word of words(name).split(' ')) allowed.add(word);
  // Values are the only operands accepted here. Negation, OR and unknown clauses stay unconsumed.
  if (/[^\p{L}\p{N}_\s,'"=()-]/u.test(remainder)) return null;
  if (
    words(remainder)
      .split(' ')
      .filter(Boolean)
      .some((word) => !allowed.has(word))
  )
    return null;
  if (input.trim() && !selected.size) return null;
  return [...selected.values()].map(({ column, value }) => rule(column.id, 'equals', value));
}

/** Bounded, schema-driven chart grammars; every clause must be accounted for. */
export function planLocalChartIntent(
  text: string,
  columns: ColumnSpec[],
): { plan: ChartPlan; filter: Node; summary: string } | null {
  const input = normalized(text);
  const combination = monthlyCombinationIntent(input, columns);
  if (combination) return combination;
  const headline =
    /^(?:please\s+)?(?:create|make|build|show|plot)(?:\s+me)?\s+(?:a\s+)?(line|area|bar|column)\s+chart\s+(?:of|showing)\s+daily\s+(?:failed\s+(?:execution\s+)?(?:attempts|runs)|failure\s+counts?)\b\s*/i.exec(
      input,
    );
  if (!headline) return null;
  const remainder = input.slice(headline[0].length);
  const from = /\bfrom\s+/i.exec(remainder);
  if (!from) return null;
  const scope = scopeFilters(remainder.slice(0, from.index).trim(), columns);
  if (!scope) return null;
  const range = dateRange(remainder.slice(from.index + from[0].length));
  if (!range) return null;
  if (range.end < range.start)
    throw new Fault('CHART_DATE_RANGE', 'The chart end date must be on or after its start date.');
  let rest = range.rest;
  let fillZero = false;
  while (rest.trim()) {
    rest = rest.replace(/^[\s.,;]+/, '').replace(/^and\s+/i, '');
    if (!rest) break;
    const count =
      /^count\s+(?:failures|failed\s+(?:execution\s+)?(?:attempts|runs))(?:\s*,?\s*not\s+input\s+records)?(?=$|[\s.,;])/i.exec(
        rest,
      );
    const zero =
      /^(?:include|show|keep)\s+(?:all\s+)?days\s+(?:with\s+(?:zero|no)\s+failures|without\s+failures)(?=$|[\s.,;])/i.exec(
        rest,
      );
    const order =
      /^(?:order|sort)\s+(?:the\s+)?dates\s+(?:(?:from\s+)?earliest\s+to\s+latest|chronologically|(?:in\s+)?ascending\s+order)(?=$|[\s.,;])/i.exec(
        rest,
      );
    const consumed = count ?? zero ?? order;
    if (!consumed) return null;
    if (zero) fillZero = true;
    rest = rest.slice(consumed[0].length);
  }

  const measures = columns.filter((column) => {
    if (column.kind !== 'number' || column.chartRole === 'identifier') return false;
    const name = words(`${column.id} ${column.label} ${column.aliases.join(' ')}`);
    return (
      /\b(?:failed|failure|failures)\b/.test(name) &&
      /\bcount\b/.test(name) &&
      !/\b(?:rate|percent|pct|input|records?|cost|duration)\b/.test(name)
    );
  });
  if (measures.length !== 1)
    throw new Fault(
      'CHART_MEASURE',
      measures.length
        ? 'More than one failure-count measure is available. Choose the measure in the chart builder.'
        : 'This dataset needs a numeric failure-count column to chart failed attempts safely.',
    );
  const dates = columns.filter((column) => column.kind === 'date');
  const temporal = dates.length ? dates : columns.filter((column) => column.kind === 'datetime');
  if (temporal.length !== 1)
    throw new Fault(
      'CHART_DATE_COLUMN',
      temporal.length
        ? 'More than one date column is available. Choose the daily date in the chart builder.'
        : 'This dataset needs a date or timestamp column for daily failure counts.',
    );
  const date = temporal[0],
    measure = measures[0];
  const endExclusive = Temporal.PlainDate.from(range.end).add({ days: 1 }).toString();
  const dateValue = (day: string) => (date.kind === 'datetime' ? `${day} 00:00:00` : day);
  const filter: Node = {
    kind: 'group',
    join: 'AND',
    children: [
      ...scope,
      rule(date.id, 'greaterThanOrEqual', dateValue(range.start)),
      rule(date.id, 'lessThan', dateValue(endExclusive)),
    ],
  };
  const plan: ChartPlan = {
    type: headline[1].toLowerCase() as ChartPlan['type'],
    categoryColumnId: date.id,
    measureColumnIds: [measure.id],
    aggregation: 'sum',
    timeBucket: 'day',
    title: `Daily ${measure.label}`.slice(0, 160),
    ...(fillZero ? { timeRange: { start: range.start, endExclusive, fill: 'zero' as const } } : {}),
  };
  return {
    plan,
    filter,
    summary: `Sum ${measure.label} by ${date.label} from ${range.start} through ${range.end}, earliest to latest${date.kind === 'datetime' ? ' (UTC)' : ''}.${fillZero ? ' Include every day in the range, using zero when no matching failures are recorded.' : ''}`,
  };
}
