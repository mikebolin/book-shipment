import type { GridModel } from '../core/domain/contracts';
import { Fault } from '../core/domain/engine';
import type { GridClarificationOption, GridCopilotResult } from '../core/domain/grid-copilot';
import {
  chartColumnMetadata,
  type ChartPlan,
  type ChartResponse,
} from '../core/domain/integrated-chart';
import type { ColumnSpec } from '../core/domain/schema';

type RecoveryReason = 'empty_cohort' | 'empty_values' | Fault;

/** Validate every uploaded-data choice against the same complete local snapshot as the failed preview. */
export async function uploadedChartRecovery(
  plan: ChartPlan,
  filterModel: GridModel,
  draftId: string,
  columns: readonly ColumnSpec[],
  reason: RecoveryReason,
  preview: (plan: ChartPlan, filterModel: GridModel) => Promise<ChartResponse>,
): Promise<Extract<GridCopilotResult, { status: 'needs_input' }>> {
  const chart = (choice: ChartPlan, selectedFilter = filterModel) => ({
    plan: choice,
    filterModel: selectedFilter,
    requestScope: 'current' as const,
    draftId,
  });
  const builder: GridClarificationOption = {
    label: 'Edit chart and filters',
    answer: 'Open the chart builder.',
    action: 'open_chart_builder',
    chart: chart(plan),
  };
  const validated = async (
    label: string,
    choice: ChartPlan,
    selectedFilter = filterModel,
  ): Promise<GridClarificationOption | null> => {
    try {
      const data = await preview(choice, selectedFilter);
      if (!data.matchedRowCount || !data.rows.length) return null;
      return {
        label,
        answer: `Create ${label.toLowerCase()} with the selected data.`,
        chart: chart(choice, selectedFilter),
      };
    } catch (error) {
      if (error instanceof Fault) return null;
      throw error;
    }
  };
  const choices: GridClarificationOption[] = [];
  let message: string;
  if (reason === 'empty_cohort' || reason === 'empty_values') {
    message =
      reason === 'empty_cohort'
        ? 'The proposed filter matches no uploaded rows. Remove it or edit the chart filters.'
        : 'The matching uploaded rows have no complete chart values. Choose another measure or broaden the filter.';
    const all = await validated('Chart all rows', plan, null);
    if (all) choices.push(all);
  } else if (reason.code === 'CHART_CARDINALITY') {
    const category = columns.find((column) => column.id === plan.categoryColumnId);
    if (category?.kind === 'date' || category?.kind === 'datetime') {
      message =
        'There are too many individual dates for a readable chart. Choose a wider time period.';
      for (const bucket of ['month', 'quarter', 'year'] as const) {
        const choice = await validated(`By ${bucket}`, { ...plan, timeBucket: bucket });
        if (choice) choices.push(choice);
      }
    } else {
      message =
        'The selected field has more than 200 categories. Choose a validated chart or edit its fields and filters.';
      if (
        plan.analytics &&
        plan.analytics.limit == null &&
        plan.measureColumnIds[0] &&
        ['bar', 'groupedBar', 'column', 'groupedColumn'].includes(plan.type)
      ) {
        const ranked: ChartPlan = {
          ...plan,
          title: `Top 20 ${plan.title}`.slice(0, 160),
          analytics: {
            ...plan.analytics,
            orderBy: plan.analytics.orderBy.length
              ? plan.analytics.orderBy
              : [{ field: plan.measureColumnIds[0], direction: 'desc' }],
            limit: 20,
          },
        };
        const choice = await validated('Top 20 by value', ranked);
        if (choice) choices.push(choice);
      }
      if (
        !plan.analytics &&
        plan.categoryColumnId &&
        ['bar', 'groupedBar', 'column', 'groupedColumn'].includes(plan.type) &&
        (plan.measureColumnIds.length === 1 || plan.aggregation === 'count')
      ) {
        const source = plan.measureColumnIds[0] ?? null;
        const metricId = 'metric_recovery_rank';
        const ranked: ChartPlan = {
          ...plan,
          title: `Top 20 ${plan.title}`.slice(0, 160),
          measureColumnIds: [metricId],
          analytics: {
            metrics: [
              {
                id: metricId,
                label: source
                  ? `${plan.aggregation} ${columns.find((column) => column.id === source)?.label ?? source}`
                  : 'Account count',
                operation: plan.aggregation ?? 'count',
                columnId: source,
                numeratorColumnId: null,
                denominatorColumnId: null,
                scale: null,
                percentile: null,
              },
            ],
            groupFilter: [],
            orderBy: [
              { field: metricId, direction: 'desc' },
              { field: plan.categoryColumnId, direction: 'asc' },
            ],
            limit: 20,
            seriesByColumnId: null,
          },
        };
        const choice = await validated('Top 20 by value', ranked);
        if (choice) choices.push(choice);
      }
      const metadata = new Map(chartColumnMetadata(columns).map((column) => [column.id, column]));
      for (const candidate of columns) {
        if (choices.length >= 4) break;
        if (
          candidate.id === plan.categoryColumnId ||
          metadata.get(candidate.id)?.role !== 'dimension'
        )
          continue;
        const choice = await validated(`By ${candidate.label}`, {
          ...plan,
          categoryColumnId: candidate.id,
          timeBucket: null,
          title: `${plan.title} by ${candidate.label}`.slice(0, 160),
        });
        if (choice) choices.push(choice);
      }
    }
  } else if (reason.code === 'CHART_NEGATIVE_PROPORTION') {
    message =
      'Some chart values are negative. A bar or column chart can show those values accurately.';
    for (const type of ['groupedBar', 'groupedColumn'] as const) {
      const choice = await validated(`Use a ${type === 'groupedBar' ? 'bar' : 'column'} chart`, {
        ...plan,
        type,
      });
      if (choice) choices.push(choice);
    }
  } else {
    message = reason.message;
  }
  return {
    status: 'needs_input',
    reason: 'clarification',
    message,
    options: [...choices, builder],
  };
}
