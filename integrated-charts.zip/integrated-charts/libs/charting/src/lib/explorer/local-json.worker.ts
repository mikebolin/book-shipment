import { parseLocalJson } from './local-json-parser';
import { buildLocalDataRecipes } from './local-data-recipes';
import { parseLocalCsv } from './local-csv-parser';
import { sha256Text } from './content-hash';
self.onmessage = async ({
  data,
}: MessageEvent<File | { file: File; metadata?: unknown; skipRecipes?: boolean }>) => {
  const request: { file: File; metadata?: unknown; skipRecipes?: boolean } =
    data instanceof File ? { file: data } : data;
  const file = request.file;
  try {
    const text = await file.text();
    const parse = /\.csv$/i.test(file.name) ? parseLocalCsv : parseLocalJson;
    const dataset = parse(text, file.name, {
      metadata: request.metadata,
      onProgress: (progress) => self.postMessage({ type: 'progress', progress }),
    });
    dataset.contentHash = await sha256Text(text);
    self.postMessage({ type: 'progress', progress: { phase: 'recipes' } });
    dataset.preparedRecipes = request.skipRecipes ? [] : buildLocalDataRecipes(dataset);
    self.postMessage({ type: 'complete', dataset });
  } catch (error) {
    self.postMessage({
      type: 'error',
      message: error instanceof Error ? error.message : 'Could not read this file.',
    });
  }
};
