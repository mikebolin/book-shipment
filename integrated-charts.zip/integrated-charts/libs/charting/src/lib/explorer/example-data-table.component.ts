import { GridPopupLayerDirective } from '../ui/grid-popup-layer';
import { ChangeDetectionStrategy, Component, Input, OnChanges, inject } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { AllCommunityModule, type ColDef } from 'ag-grid-community';
import { RowGroupingModule } from 'ag-grid-enterprise';
import { AppThemeService } from './app-theme.service';
import type { GridReviewPreview } from './demo-grid-preview-loader';

@Component({
  selector: 'app-example-data-table',
  standalone: true,
  imports: [GridPopupLayerDirective, AgGridAngular],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <ag-grid-angular
      prismPopupLayer
      aria-label="Saved result sample"
      [theme]="theme.gridTheme()"
      [modules]="modules"
      [rowData]="rows"
      [columnDefs]="columnDefs"
      [defaultColDef]="defaultColDef"
      [autoGroupColumnDef]="autoGroupColumnDef"
      [groupDefaultExpanded]="-1"
      [suppressAggFuncInHeader]="true"
      [rowHeight]="25"
      [headerHeight]="30"
      [animateRows]="false"
      [suppressCellFocus]="false"
      [tooltipShowDelay]="200"
    />
  `,
  styles: [
    `
      :host {
        display: block;
        min-width: 0;
      }
      ag-grid-angular {
        display: block;
        width: 100%;
        height: 292px;
      }
    `,
  ],
})
export class ExampleDataTableComponent implements OnChanges {
  @Input({ required: true }) preview!: GridReviewPreview;
  readonly theme = inject(AppThemeService);
  readonly modules = [AllCommunityModule, RowGroupingModule];
  readonly autoGroupColumnDef: ColDef = {
    headerName: 'Groups',
    minWidth: 180,
    flex: 1,
    cellRendererParams: { suppressCount: true },
  };
  readonly defaultColDef: ColDef = {
    flex: 1,
    minWidth: 110,
    sortable: true,
    resizable: true,
    filter: false,
  };
  rows: GridReviewPreview['rows'] = [];
  columnDefs: ColDef[] = [];

  ngOnChanges(): void {
    this.rows = this.preview.rows.slice(0, 20).map((row) => ({ ...row }));
    this.columnDefs = this.preview.columns.map((column) => ({
      colId: column.id,
      headerName: column.label,
      headerTooltip: column.label,
      // Saved grouped rows already contain query aggregates. Group their key for
      // an expandable hierarchy; never aggregate those totals a second time.
      rowGroup: this.groupedColumn(column.id),
      hide: this.groupedColumn(column.id),
      valueGetter: ({ data }) => data?.[column.id],
      valueFormatter: ({ value }) =>
        value == null
          ? '—'
          : typeof value === 'number'
            ? value.toLocaleString('en-US', { maximumFractionDigits: 4 })
            : String(value),
    }));
  }
  private groupedColumn(id: string): boolean {
    return (
      this.preview.previewKind === 'grouped-rows' &&
      this.preview.operations.some((operation) => /^Group by /i.test(operation)) &&
      id === this.preview.columns[0]?.id
    );
  }
}
