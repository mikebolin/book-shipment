export type StreamRow = Record<string, string | number | boolean | null>;
export interface RowStreamStart {
  type: 'start';
  streamId: string;
  totalRows: number;
  columns: string[];
  encoding?: 'template-rows-v1';
  batchPolicy?: { maxRows: number; targetBytes: number; maxBytes: number; maxDelayMs: number };
}
export interface RowStreamBatch {
  type: 'batch';
  sequence: number;
  rows: StreamRow[];
  receivedRows: number;
}
export interface RowStreamComplete {
  type: 'complete';
  rowCount: number;
  totalRows?: number;
  elapsedMs: number;
}
export interface RowStreamMetrics {
  receivedRows: number;
  batches: number;
  bytes: number;
  elapsedMs: number;
}
export interface RowStreamOptions {
  source: string;
  body: unknown;
  signal: AbortSignal;
  rows?: readonly StreamRow[];
  onStart?: (event: RowStreamStart) => void | Promise<void>;
  onBatch: (event: RowStreamBatch, metrics: RowStreamMetrics) => void | Promise<void>;

  yieldControl?: () => Promise<void>;
}

export const yieldToBrowser = () => new Promise<void>((resolve) => setTimeout(resolve, 0));
/** Bounded, cancellable iteration over a dataset that is already in browser memory. */
export async function consumeRowStream(
  options: RowStreamOptions,
): Promise<RowStreamComplete & RowStreamMetrics> {
  const { signal } = options;
  signal.throwIfAborted();
  const rows = options.rows ?? [];
  const started = performance.now();
  let batches = 0,
    receivedRows = 0;
  await options.onStart?.({
    type: 'start',
    streamId: crypto.randomUUID(),
    totalRows: rows.length,
    columns: Object.keys(rows[0] ?? {}),
  });
  for (let offset = 0; offset < rows.length; offset += 500) {
    signal.throwIfAborted();
    const batch = rows.slice(offset, offset + 500);
    receivedRows += batch.length;
    await options.onBatch(
      { type: 'batch', sequence: batches++, rows: batch, receivedRows },
      { receivedRows, batches, bytes: 0, elapsedMs: performance.now() - started },
    );
    await (options.yieldControl ?? yieldToBrowser)();
  }
  signal.throwIfAborted();
  return {
    type: 'complete',
    rowCount: receivedRows,
    totalRows: rows.length,
    receivedRows,
    batches,
    bytes: 0,
    elapsedMs: performance.now() - started,
  };
}
