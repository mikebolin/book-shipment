import { LOCAL_JSON_LIMITS, parseLocalJson, type LocalImportOptions } from './local-json-parser';
import type { LocalDataset } from './client-data-sources';

/** RFC 4180 quoting, including embedded newlines and doubled quotes. No evaluation or network. */
export function parseLocalCsv(
  text: string,
  fileName = 'Uploaded data.csv',
  options: LocalImportOptions = {},
): LocalDataset {
  options.signal?.throwIfAborted();
  if (new TextEncoder().encode(text).byteLength > LOCAL_JSON_LIMITS.bytes)
    throw new Error('The CSV file exceeds the local import size limit.');
  options.onProgress?.({ phase: 'parsing' });
  const source = text.replace(/^\uFEFF/, '');
  const records: Record<string, unknown>[] = [];
  let headers: string[] | undefined;
  let fields: string[] = [];
  let field = '';
  let quoted = false;
  let closedQuote = false;
  let explicitRecord = false;
  const endRow = () => {
    fields.push(field);
    field = '';
    closedQuote = false;
    if (fields.length === 1 && fields[0] === '' && !explicitRecord) {
      fields = [];
      return;
    }
    explicitRecord = false;
    if (!headers) {
      headers = fields.map((name) => name.trim());
      if (headers.some((name) => !name) || new Set(headers).size !== headers.length)
        throw new Error('CSV headers must be nonempty and unique.');
      if (headers.length > LOCAL_JSON_LIMITS.columns)
        throw new Error('This local import accepts at most 500 fields.');
    } else {
      if (fields.length !== headers.length)
        throw new Error(
          `CSV row ${records.length + 2} has ${fields.length} fields; expected ${headers.length}.`,
        );
      if (
        records.length >= LOCAL_JSON_LIMITS.rows ||
        (records.length + 1) * headers.length > LOCAL_JSON_LIMITS.cells
      )
        throw new Error('The CSV file exceeds the local row or cell limit. No rows were imported.');
      const row: Record<string, unknown> = Object.create(null);
      fields.forEach((value, index) => {
        const trimmed = value.trim();
        const numeric = /^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?$/.test(trimmed);
        const number = numeric ? Number(trimmed) : NaN;
        row[headers![index]!] =
          value === ''
            ? null
            : /^(true|false)$/i.test(trimmed)
              ? trimmed.toLowerCase() === 'true'
              : numeric &&
                  Number.isFinite(number) &&
                  (!Number.isInteger(number) || Number.isSafeInteger(number))
                ? number
                : value;
      });
      records.push(row);
    }
    fields = [];
  };
  for (let index = 0; index < source.length; index++) {
    if (index % 65536 === 0) options.signal?.throwIfAborted();
    const character = source[index]!;
    if (quoted) {
      if (character === '"') {
        if (source[index + 1] === '"') {
          field += '"';
          index++;
        } else {
          quoted = false;
          closedQuote = true;
        }
      } else field += character;
    } else if (character === ',') {
      explicitRecord = true;
      fields.push(field);
      field = '';
      closedQuote = false;
      if (fields.length >= LOCAL_JSON_LIMITS.columns)
        throw new Error('This local import accepts at most 500 fields.');
    } else if (character === '\r' || character === '\n') {
      if (character === '\r' && source[index + 1] === '\n') index++;
      endRow();
    } else if (closedQuote) {
      throw new Error('Only a comma or a line ending may follow a quoted CSV value.');
    } else if (character === '"') {
      if (field.length) throw new Error('CSV quotes must surround an entire field.');
      explicitRecord = true;
      quoted = true;
    } else field += character;
    if (field.length > LOCAL_JSON_LIMITS.cellCharacters)
      throw new Error('A CSV value exceeds the local cell size limit.');
  }
  if (quoted) throw new Error('The CSV file ends inside a quoted field.');
  if (field.length || fields.length || closedQuote) endRow();
  if (!headers || !records.length)
    throw new Error('Include a CSV header row and at least one data row.');
  const dataset = parseLocalJson(
    JSON.stringify(records),
    fileName.replace(/\.csv$/i, '.json'),
    options,
  );
  dataset.metadata.label =
    fileName
      .replace(/\.csv$/i, '')
      .trim()
      .slice(0, 100) || 'Uploaded data';
  dataset.metadata.description = `${records.length.toLocaleString()} rows imported locally from ${fileName}.`;
  dataset.metadata.columns = dataset.metadata.columns.map((column) => ({
    ...column,
    description: column.description.replace('Imported JSON field', 'Imported CSV field'),
  }));
  dataset.metadata.sqlDataset.columns = dataset.metadata.columns;
  dataset.provenance = {
    ...dataset.provenance,
    kind: 'local-csv',
    fileName,
    bytes: new TextEncoder().encode(text).byteLength,
  };
  return dataset;
}
