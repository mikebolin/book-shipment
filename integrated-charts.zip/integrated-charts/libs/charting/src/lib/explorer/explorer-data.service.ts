import { injectUiState } from '../core/state/index';
import { DestroyRef, Injectable, inject, type OnDestroy } from '@angular/core';
import type { InterpretRequest, InterpretResult, GridModel, Mode } from '../core/domain/contracts';
import type {
  GridCopilotRequest,
  GridCopilotResult,
  GridConfirmation,
  ChartProposalRequest,
} from '../core/domain/grid-copilot';
import type { CalculatedColumnDefinition } from '../core/domain/calculated-columns';
import type { ChartPlan } from '../core/domain/integrated-chart';
import { BrowserDataCache } from './browser-data-cache';
import {
  ClientDatasetRegistry,
  isLocalDataSource,
  type ClientDataSourceId,
  type ClientSourceMetadata,
  type LocalDataset,
} from './client-data-sources';
import { LocalDataRouter } from './local-data-router';
import type { ChartRecommendationsResponse } from '../core/domain/chart-recommendations';
import {
  buildRecommendationCandidates,
  type LocalChartCandidate,
} from './chart-recommendation-candidates';
import { WorkspaceRepository } from '../core/data-access/workspace-repository.service';
import { WorkspaceStore } from '../core/state/index';

export interface DatasetChartRecommendations {
  status: 'loading' | ChartRecommendationsResponse['status'];
  candidates: LocalChartCandidate[];
  candidateIds: string[];
  source: 'llm' | 'heuristic';
  cached: boolean;
}
/** Editor-scoped pure computation facade. The root store owns datasets and reactive editor state. */
@Injectable({ providedIn: 'root' })
export class ExplorerDataService implements OnDestroy {
  private readonly reactiveState = injectUiState('ExplorerDataService');

  readonly cache = new BrowserDataCache();
  private readonly store = inject(WorkspaceStore);
  private readonly workspace = inject(WorkspaceRepository);
  private readonly registry = new ClientDatasetRegistry();
  private readonly localRouter = new LocalDataRouter(this.registry, this.cache);
  private readonly lifetime = new AbortController();
  readonly localSources = this.reactiveState.signal<ClientSourceMetadata[]>([]);
  readonly capabilities = this.reactiveState.signal({
    liveAiAvailable: false,
    liveAiProvider: null as string | null,
    chartRecommendationsAvailable: true,
  });
  readonly chartRecommendations = this.reactiveState.signal<
    ReadonlyMap<ClientDataSourceId, DatasetChartRecommendations>
  >(new Map());
  private dataSource: ClientDataSourceId = 'local_unconfigured';
  private serverSideOnly = false;
  constructor() {
    inject(DestroyRef).onDestroy(() => this.ngOnDestroy());
  }
  resetAiSession() {
    this.localRouter.clearDrafts();
  }
  setDataSource(source: ClientDataSourceId) {
    if (source !== this.dataSource) this.resetAiSession();
    this.dataSource = source;
  }
  setServerSideOnly(enabled: boolean): void {
    this.serverSideOnly = enabled;
  }
  isLocalSource(source: ClientDataSourceId) {
    return isLocalDataSource(source);
  }
  sourceMetadata(source: ClientDataSourceId) {
    const model = this.store.resources
      .models()
      .find((model) => model.body.clientSourceId === source);
    if (model) return { ...model.body, id: source } as ClientSourceMetadata;
    return this.registry.metadata(source);
  }
  getLocalDataset(source: ClientDataSourceId) {
    return this.registry.get(source);
  }
  getLocalRecipes(source: ClientDataSourceId) {
    return this.localRouter.getRecipes(source);
  }
  registerLocalDataset(dataset: LocalDataset) {
    this.registry.register(dataset);
    this.localRouter.register(dataset.metadata.id);
    this.store.setDataset(dataset.metadata.id, dataset.rows);
    this.localSources.set(this.registry.list().map((entry) => entry.metadata));
  }
  private async prepare(source: ClientDataSourceId) {
    if (this.serverSideOnly)
      throw new Error(
        'This action requires a complete authorized snapshot or a host chart/planning adapter.',
      );
    if (this.registry.get(source)) return;
    const model = this.store.resources
      .models()
      .find((model) => model.body.clientSourceId === source);
    if (!model) throw new Error('Import this dataset before opening it.');
    const rows =
      this.cache.getRows(source) ?? (await this.workspace.lease(model as any).result).rows;
    const metadata = { ...model.body, id: source, local: true as const };
    this.registerLocalDataset({
      metadata,
      rows: rows as any,
      originalFields: metadata.columns.map((c: any) => ({
        originalName: c.id,
        columnId: c.id,
        inferredType: c.kind,
        gridType: c.kind,
        nullable: c.nullable,
        identifier: c.chartRole === 'identifier',
        unique: c.chartRole === 'identifier',
      })),
      warnings: [],
      provenance: {
        kind: 'local-json',
        fileName: model.slug,
        bytes: 0,
        importedAt: '2026-10-01T00:00:00Z',
        rowCount: rows.length,
      },
    });
  }
  async request<T>(
    path: string,
    body?: unknown,
    signal?: AbortSignal,
    sourceOverride?: ClientDataSourceId,
  ): Promise<T> {
    signal = signal ? AbortSignal.any([signal, this.lifetime.signal]) : this.lifetime.signal;
    signal.throwIfAborted();
    const source = sourceOverride ?? this.dataSource;
    if (path === 'analytics/dataset-analysis') {
      const input = body as any;
      return {
        status: 'ready',
        source: 'local',
        factIds: input.facts.slice(0, 6).map((f: any) => f.id),
        chartIds: input.charts.slice(0, 4).map((c: any) => c.id),
      } as T;
    }
    await this.prepare(source);
    signal.throwIfAborted();
    return (await this.localRouter.request(source, path, body, signal)) as T;
  }
  async ensureChartRecommendations(source: ClientDataSourceId): Promise<void> {
    this.lifetime.signal.throwIfAborted();
    await this.prepare(source);
    const metadata = this.registry.metadata(source);
    const sample = await this.cache.sampleChartRows(
      source,
      { mode: 'advanced', filterModel: null, calculatedColumnIds: [] },
      this.lifetime.signal,
    );
    const candidates = await buildRecommendationCandidates(
      metadata.version,
      metadata.columns,
      sample.rows,
    );
    this.lifetime.signal.throwIfAborted();
    this.chartRecommendations.update((current) =>
      new Map(current).set(source, {
        status: 'ready',
        candidates,
        candidateIds: candidates.slice(0, 6).map((c) => c.descriptor.id),
        source: 'heuristic',
        cached: true,
      }),
    );
  }
  ngOnDestroy() {
    this.lifetime.abort();
  }
  interpret(input: InterpretRequest, signal: AbortSignal) {
    return this.request<InterpretResult>('nl/interpret', input, signal);
  }
  interpretGrid(input: GridCopilotRequest, signal: AbortSignal) {
    return this.request<GridCopilotResult>('nl/grid/interpret', input, signal);
  }
  proposeChart(input: ChartProposalRequest, signal: AbortSignal) {
    return this.request<GridCopilotResult>('grid/chart-proposal', input, signal);
  }
  reviseChart(
    id: string,
    plan: ChartPlan,
    mode: Mode,
    currentState: Record<string, unknown>,
    calculatedColumnIds: string[],
    signal: AbortSignal,
  ) {
    return this.request<GridCopilotResult>(
      'nl/grid/refine-chart',
      { id, plan, mode, currentState, calculatedColumnIds },
      signal,
    );
  }
  confirmGrid(
    id: string,
    mode: Mode,
    currentState: Record<string, unknown>,
    calculatedColumnIds: string[],
    signal: AbortSignal,
  ) {
    return this.request<GridConfirmation>(
      'nl/grid/confirm',
      { id, mode, currentState, calculatedColumnIds },
      signal,
    );
  }
  confirmCalculatedColumn(
    id: string,
    mode: Mode,
    currentState: Record<string, unknown>,
    calculatedColumnIds: string[],
    signal: AbortSignal,
  ) {
    return this.request<{ column: CalculatedColumnDefinition; plan?: GridConfirmation }>(
      'nl/grid/calculated-column/confirm',
      { id, mode, currentState, calculatedColumnIds },
      signal,
    );
  }
  clarify(id: string, choice: string, signal: AbortSignal, useLiveAi = true) {
    return this.request<InterpretResult>('nl/clarify', { id, choice, useLiveAi }, signal);
  }
  confirm(id: string, mode: Mode, currentModel: GridModel, signal: AbortSignal) {
    return this.request<{ model: GridModel; summary: string }>(
      'nl/confirm',
      { id, mode, currentModel },
      signal,
    );
  }
}
