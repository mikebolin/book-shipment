import type { ColumnSpec } from '../core/domain/schema';
import type { ChartPlan } from '../core/domain/integrated-chart';
import { validateChartPlan } from '../core/domain/chart-data';
import {
  CHART_RECOMMENDATION_VERSION,
  type RecommendationCandidate,
} from '../core/domain/chart-recommendations';
import { defaultComboSeries, guideFields, guidePlanError } from './chart-guide';
import {
  comparableObservedMeasures,
  observedCategoryScore,
  observedMeasureScore,
  observedTimeBucket,
  preferredAggregation,
  profileChartRows,
  type ProfileRow,
} from './chart-data-profile';
import { sha256Text } from './content-hash';

export interface LocalChartCandidate {
  descriptor: RecommendationCandidate;
  plan: ChartPlan;
}

/** Names stay in the browser. Only these fixed vocabulary classifications may leave it. */
export function measureMeaning(column: ColumnSpec): RecommendationCandidate['measures'][number] {
  const name = `${column.id.replace(/([a-z])([A-Z])/g, '$1 $2')} ${column.label}`.toLowerCase();
  for (const [meaning, pattern] of [
    ['revenue', /revenue|sales|income/],
    ['balance', /balance|assets|holdings|exposure|market value|gross amount|net amount/],
    ['cost', /cost|expense|fee|commission/],
    ['price', /price/],
    ['percentage', /percent|margin/],
    ['rate', /rate|yield|ratio/],
    ['score', /score|risk/],
    ['duration', /duration|age|days|hours|latency/],
    ['quantity', /quantity|units|shares/],
    ['volume', /volume/],
    ['count', /count|number of/],
  ] as const)
    if (pattern.test(name)) return meaning;
  return 'other';
}
export function categoryMeaning(column?: ColumnSpec): RecommendationCandidate['category'] {
  if (!column) return 'none';
  if (['date', 'datetime'].includes(column.kind)) return 'time';
  const name = `${column.id.replace(/([a-z])([A-Z])/g, '$1 $2')} ${column.label}`.toLowerCase();
  if (/status|state|stage/.test(name)) return 'status';
  if (/country|region|city|territory|geograph/.test(name)) return 'geography';
  if (/product|asset class|instrument|sector/.test(name)) return 'product';
  if (/organization|department|desk|team|division|business|custodian|broker/.test(name))
    return 'organization';
  if (/type|category|side|class|tier|segment/.test(name)) return 'type';
  return 'other';
}

export function recommendationSchemaKey(columns: readonly ColumnSpec[]): string {
  return JSON.stringify(
    columns.map(({ id, label, kind, unit, scale, chartRole }) => ({
      id,
      label,
      kind,
      unit,
      scale,
      chartRole,
    })),
  );
}

/** A bounded, diverse pool, built from an unfiltered sample once per dataset. All plans remain local. */
export async function buildRecommendationCandidates(
  datasetKey: string,
  columns: readonly ColumnSpec[],
  rows: readonly ProfileRow[],
): Promise<LocalChartCandidate[]> {
  const profile = profileChartRows(columns, rows);
  const fields = guideFields(columns);
  const measures = fields.measures
    .filter((c) => (profile.fields.get(c.id)?.distinct ?? 0) > 1)
    .sort(
      (a, b) =>
        observedMeasureScore(b, profile) - observedMeasureScore(a, profile) ||
        Number(measureMeaning(b) !== 'other') - Number(measureMeaning(a) !== 'other'),
    )
    .slice(0, 6);
  const base: ChartPlan = {
    type: 'groupedColumn',
    categoryColumnId: null,
    measureColumnIds: [],
    aggregation: 'count',
    timeBucket: null,
    title: '',
    appearance: null,
    seriesChartTypes: null,
  };
  const categories = fields.categories
    .filter(
      (c) =>
        !['date', 'datetime'].includes(c.kind) &&
        (profile.fields.get(c.id)?.distinct ?? 0) >= 2 &&
        (profile.fields.get(c.id)?.distinct ?? Infinity) <= 25,
    )
    .sort(
      (a, b) => observedCategoryScore(b, base, profile) - observedCategoryScore(a, base, profile),
    )
    .slice(0, 5);
  const dates = fields.dates
    .filter((c) => (profile.fields.get(c.id)?.distinct ?? 0) > 1)
    .slice(0, 3);
  const plans: { plan: ChartPlan; intent: RecommendationCandidate['intent'] }[] = [];
  const seen = new Set<string>();
  const add = (
    type: ChartPlan['type'],
    category: ColumnSpec | undefined,
    selected: ColumnSpec[],
    intent: RecommendationCandidate['intent'],
    count = false,
  ) => {
    const raw = ['scatter', 'bubble', 'histogram'].includes(type);
    const ids = selected.map((c) => c.id);
    const plan: ChartPlan = {
      ...base,
      type,
      categoryColumnId: raw ? null : (category?.id ?? null),
      measureColumnIds: ids,
      aggregation: raw ? null : count ? 'count' : preferredAggregation(selected[0]),
      timeBucket: raw ? null : observedTimeBucket(category, profile),
      seriesChartTypes: type === 'customCombo' ? defaultComboSeries(ids, columns) : null,
    };
    const key = JSON.stringify(plan);
    if (seen.has(key) || guidePlanError(plan, columns)) return;
    const labels = selected.map((c) => c.label).join(' and ');
    plan.title = (
      raw
        ? `${type === 'histogram' ? 'Distribution of' : 'Relationship between'} ${labels}`
        : `${count ? 'Record count' : `${plan.aggregation === 'avg' ? 'Average' : 'Total'} ${labels}`} by ${category!.label}`
    ).slice(0, 160);
    try {
      validateChartPlan(plan, columns);
    } catch {
      return;
    }
    if (type === 'bubble' && (profile.fields.get(ids[2]!)?.minimum ?? -1) < 0) return;
    if (
      /stacked|normalized/i.test(type) &&
      selected.some(
        (c) => preferredAggregation(c) !== 'sum' || (profile.fields.get(c.id)?.minimum ?? -1) < 0,
      )
    )
      return;
    seen.add(key);
    plans.push({ plan, intent });
  };
  // Interleave dimensions, metrics and chart purposes so a wide schema cannot monopolize the pool.
  categories.forEach((category, i) => {
    add(
      i % 2 ? 'groupedBar' : 'groupedColumn',
      category,
      measures.slice(0, 1),
      'comparison',
      !measures.length,
    );
    add('groupedBar', category, [], 'comparison', true);
  });
  dates.forEach((date) =>
    measures
      .slice(0, 3)
      .forEach((measure, i) => add(i % 2 ? 'area' : 'line', date, [measure], 'trend')),
  );
  measures.slice(0, 5).forEach((measure) => add('histogram', undefined, [measure], 'distribution'));
  for (let i = 0; i < Math.min(measures.length, 4); i++)
    for (let j = i + 1; j < Math.min(measures.length, 5); j++)
      add('scatter', undefined, [measures[i]!, measures[j]!], 'relationship');
  categories.forEach((category, i) => {
    if ((profile.fields.get(category.id)?.distinct ?? 99) <= 8) {
      const additive = measures.find(
        (m) => preferredAggregation(m) === 'sum' && (profile.fields.get(m.id)?.minimum ?? -1) >= 0,
      );
      add(i % 2 ? 'pie' : 'donut', category, additive ? [additive] : [], 'composition', !additive);
    }
    measures
      .slice(1, 4)
      .forEach((measure, m) =>
        add(m % 2 ? 'groupedBar' : 'groupedColumn', category, [measure], 'comparison'),
      );
  });
  const first = measures[0];
  if (first) {
    const comparable = measures.find(
      (m) =>
        m.id !== first.id &&
        fields.metadata.get(m.id)?.unit === fields.metadata.get(first.id)?.unit &&
        comparableObservedMeasures(first, m, profile),
    );
    if (comparable) {
      categories.slice(0, 3).forEach((c) => {
        add('groupedColumn', c, [first, comparable], 'comparison');
        add('stackedBar', c, [first, comparable], 'composition');
      });
      dates.slice(0, 2).forEach((d) => add('stackedArea', d, [first, comparable], 'trend'));
    }
    if (measures[1])
      dates.slice(0, 2).forEach((d) => add('customCombo', d, [first, measures[1]!], 'trend'));
    if (measures[2]) add('bubble', undefined, measures.slice(0, 3), 'relationship');
  }
  // Schemas with only temporal/category fields still get useful count charts.
  if (!plans.length) dates.forEach((d) => add('line', d, [], 'trend', true));
  return Promise.all(
    plans.slice(0, 64).map(async ({ plan, intent }) => {
      const category = columns.find((c) => c.id === plan.categoryColumnId);
      const selected = plan.measureColumnIds.map((id) => columns.find((c) => c.id === id)!);
      const used = [...selected, ...(category ? [category] : [])];
      const quality: RecommendationCandidate['quality'] = [];
      if (used.every((c) => (profile.fields.get(c.id)?.distinct ?? 0) > 1)) quality.push('varying');
      if (used.every((c) => profile.fields.get(c.id)?.count === rows.length))
        quality.push('complete');
      if (
        selected.length > 1 &&
        selected.slice(1).every((c) => comparableObservedMeasures(selected[0]!, c, profile))
      )
        quality.push('comparable');
      if (selected.every((c) => (profile.fields.get(c.id)?.minimum ?? -1) >= 0))
        quality.push('nonnegative');
      if (
        plan.aggregation === 'count' ||
        (selected.length > 0 && selected.every((c) => preferredAggregation(c) === 'sum'))
      )
        quality.push('additive');
      if (category && (profile.fields.get(category.id)?.distinct ?? Infinity) <= 12)
        quality.push('lowCardinality');
      const id = `r_${await sha256Text(JSON.stringify([CHART_RECOMMENDATION_VERSION, datasetKey, { ...plan, title: '' }]))}`;
      return {
        plan,
        descriptor: {
          id,
          chartType: plan.type,
          intent,
          category: categoryMeaning(category),
          measures: selected.map(measureMeaning),
          aggregation: plan.aggregation,
          timeBucket: plan.timeBucket,
          quality,
        },
      };
    }),
  );
}
