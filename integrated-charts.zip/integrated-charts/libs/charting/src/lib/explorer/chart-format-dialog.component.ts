import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTooltipModule } from '@angular/material/tooltip';
import { AppThemeService } from './app-theme.service';
import { ChartTypeIconComponent } from './chart-type-icon.component';

export interface ChartFormatSettings {
  title: string;
  titleEnabled: boolean;
  titleSize: number;
  subtitle: string;
  footnote: string;
  legendEnabled: boolean;
  legendPosition: 'top' | 'right' | 'bottom' | 'left';
  legendSize: number;
  xAxisTitle: string;
  yAxisTitle: string;
  axisLabelSize: number;
  axisLabelRotation: number;
  gridLines: boolean;
  labels: boolean;
  labelSize: number;
  markers: boolean;
  markerSize: number;
  lineStyle: 'linear' | 'smooth' | 'step';
  strokeWidth: number;
  fillOpacity: number;
  cornerRadius: number;
  donutHole: number;
  tooltips: boolean;
}

export interface ChartFormatDialogData {
  type: string;
  settings: ChartFormatSettings;
  seriesTypes: string[];
}

@Component({
  selector: 'app-chart-format-dialog',
  standalone: true,
  imports: [
    FormsModule,
    MatButtonModule,
    MatDialogModule,
    MatExpansionModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatSelectModule,
    MatSlideToggleModule,
    MatTooltipModule,
    ChartTypeIconComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="format-header">
      <span class="format-chart-icon"><app-chart-type-icon [type]="data.type" /></span>
      <div>
        <h2 mat-dialog-title>Customize chart</h2>
        <p>Fine-tune the appearance of this chart.</p>
      </div>
      <button mat-icon-button type="button" mat-dialog-close aria-label="Close chart customization">
        <mat-icon>close</mat-icon>
      </button>
    </header>
    <form #formatForm="ngForm" (ngSubmit)="save(formatForm.valid === true)">
      <mat-dialog-content>
        <div class="theme-summary">
          <mat-icon aria-hidden="true">palette</mat-icon
          ><span
            >Colors follow <strong>{{ theme.current().label }}</strong></span
          >
        </div>
        <mat-accordion multi>
          <mat-expansion-panel [expanded]="true">
            <mat-expansion-panel-header
              ><mat-panel-title
                ><mat-icon aria-hidden="true">title</mat-icon>Titles & context</mat-panel-title
              ></mat-expansion-panel-header
            >
            <mat-slide-toggle name="titleEnabled" [(ngModel)]="draft.titleEnabled"
              >Show chart title</mat-slide-toggle
            >
            <div class="format-fields">
              <mat-form-field appearance="outline" class="wide"
                ><mat-label>Chart title</mat-label
                ><input
                  matInput
                  name="title"
                  maxlength="250"
                  [(ngModel)]="draft.title"
                  [disabled]="!draft.titleEnabled"
              /></mat-form-field>
              <mat-form-field appearance="outline"
                ><mat-label>Title size</mat-label
                ><input
                  matInput
                  type="number"
                  name="titleSize"
                  required
                  min="10"
                  max="48"
                  [(ngModel)]="draft.titleSize"
                  [disabled]="!draft.titleEnabled"
                /><span matTextSuffix>px</span></mat-form-field
              >
              <mat-form-field appearance="outline" class="wide"
                ><mat-label>Subtitle</mat-label
                ><input matInput name="subtitle" maxlength="300" [(ngModel)]="draft.subtitle"
              /></mat-form-field>
              <mat-form-field appearance="outline" class="wide"
                ><mat-label>Source note or caption</mat-label
                ><input matInput name="footnote" maxlength="300" [(ngModel)]="draft.footnote"
              /></mat-form-field>
            </div>
          </mat-expansion-panel>
          <mat-expansion-panel>
            <mat-expansion-panel-header
              ><mat-panel-title
                ><mat-icon aria-hidden="true">view_list</mat-icon>Legend</mat-panel-title
              ></mat-expansion-panel-header
            >
            <mat-slide-toggle name="legendEnabled" [(ngModel)]="draft.legendEnabled"
              >Show legend</mat-slide-toggle
            >
            <div class="format-fields">
              <mat-form-field appearance="outline"
                ><mat-label>Position</mat-label
                ><mat-select
                  name="legendPosition"
                  [(ngModel)]="draft.legendPosition"
                  [disabled]="!draft.legendEnabled"
                >
                  @for (position of positions; track position) {
                    <mat-option [value]="position">{{
                      position[0].toUpperCase() + position.slice(1)
                    }}</mat-option>
                  }
                </mat-select></mat-form-field
              >
              <mat-form-field appearance="outline"
                ><mat-label>Text size</mat-label
                ><input
                  matInput
                  type="number"
                  name="legendSize"
                  required
                  min="8"
                  max="24"
                  [(ngModel)]="draft.legendSize"
                  [disabled]="!draft.legendEnabled"
                /><span matTextSuffix>px</span></mat-form-field
              >
            </div>
          </mat-expansion-panel>
          @if (!polar) {
            <mat-expansion-panel>
              <mat-expansion-panel-header
                ><mat-panel-title
                  ><mat-icon aria-hidden="true">grid_on</mat-icon>Axes & grid</mat-panel-title
                ></mat-expansion-panel-header
              >
              <div class="format-fields">
                <mat-form-field appearance="outline" class="wide"
                  ><mat-label>Horizontal axis title</mat-label
                  ><input matInput name="xAxisTitle" maxlength="120" [(ngModel)]="draft.xAxisTitle"
                /></mat-form-field>
                <mat-form-field appearance="outline" class="wide"
                  ><mat-label>Vertical axis title</mat-label
                  ><input matInput name="yAxisTitle" maxlength="120" [(ngModel)]="draft.yAxisTitle"
                /></mat-form-field>
                <mat-form-field appearance="outline"
                  ><mat-label>Axis text size</mat-label
                  ><input
                    matInput
                    type="number"
                    name="axisLabelSize"
                    required
                    min="8"
                    max="24"
                    [(ngModel)]="draft.axisLabelSize"
                  /><span matTextSuffix>px</span></mat-form-field
                >
                <mat-form-field appearance="outline"
                  ><mat-label>Horizontal labels</mat-label
                  ><mat-select name="axisLabelRotation" [(ngModel)]="draft.axisLabelRotation"
                    ><mat-option [value]="0">Straight</mat-option
                    ><mat-option [value]="-30">Tilt 30°</mat-option
                    ><mat-option [value]="-45">Tilt 45°</mat-option
                    ><mat-option [value]="-90">Vertical</mat-option>
                    @if (![0, -30, -45, -90].includes(draft.axisLabelRotation)) {
                      <mat-option [value]="draft.axisLabelRotation"
                        >Custom · {{ draft.axisLabelRotation }}°</mat-option
                      >
                    }
                  </mat-select></mat-form-field
                >
              </div>
              <mat-slide-toggle name="gridLines" [(ngModel)]="draft.gridLines"
                >Show gridlines</mat-slide-toggle
              >
            </mat-expansion-panel>
          }
          <mat-expansion-panel>
            <mat-expansion-panel-header
              ><mat-panel-title
                ><app-chart-type-icon [type]="data.type" />Series & labels</mat-panel-title
              ></mat-expansion-panel-header
            >
            <div class="format-toggles">
              <mat-slide-toggle name="labels" [(ngModel)]="draft.labels"
                >Show value labels</mat-slide-toggle
              >
              <mat-slide-toggle name="tooltips" [(ngModel)]="draft.tooltips"
                >Show tooltips</mat-slide-toggle
              >
              @if (hasLines) {
                <mat-slide-toggle name="markers" [(ngModel)]="draft.markers"
                  >Show data point markers</mat-slide-toggle
                >
              }
            </div>
            <div class="format-fields">
              <mat-form-field appearance="outline"
                ><mat-label>Label text size</mat-label
                ><input
                  matInput
                  type="number"
                  name="labelSize"
                  required
                  min="8"
                  max="24"
                  [(ngModel)]="draft.labelSize"
                  [disabled]="!draft.labels"
                /><span matTextSuffix>px</span></mat-form-field
              >
              <mat-form-field appearance="outline"
                ><mat-label>Stroke width</mat-label
                ><input
                  matInput
                  type="number"
                  name="strokeWidth"
                  required
                  min="0"
                  max="8"
                  step="0.5"
                  [(ngModel)]="draft.strokeWidth"
                /><span matTextSuffix>px</span></mat-form-field
              >
              @if (hasLines) {
                <mat-form-field appearance="outline"
                  ><mat-label>Line shape</mat-label
                  ><mat-select name="lineStyle" [(ngModel)]="draft.lineStyle"
                    ><mat-option value="linear">Straight</mat-option
                    ><mat-option value="smooth">Smooth</mat-option
                    ><mat-option value="step">Stepped</mat-option></mat-select
                  ></mat-form-field
                >
              }
              @if (hasLines || data.type === 'scatter') {
                <mat-form-field appearance="outline"
                  ><mat-label>Marker size</mat-label
                  ><input
                    matInput
                    type="number"
                    name="markerSize"
                    required
                    min="2"
                    max="24"
                    [(ngModel)]="draft.markerSize"
                    [disabled]="hasLines && !draft.markers"
                  /><span matTextSuffix>px</span></mat-form-field
                >
              }
              @if (hasFill) {
                <mat-form-field appearance="outline"
                  ><mat-label>Fill opacity</mat-label
                  ><mat-select name="fillOpacity" [(ngModel)]="draft.fillOpacity"
                    ><mat-option [value]="1">100%</mat-option
                    ><mat-option [value]="0.8">80%</mat-option
                    ><mat-option [value]="0.6">60%</mat-option
                    ><mat-option [value]="0.4">40%</mat-option
                    ><mat-option [value]="0.2">20%</mat-option>
                    @if (![1, 0.8, 0.6, 0.4, 0.2].includes(draft.fillOpacity)) {
                      <mat-option [value]="draft.fillOpacity"
                        >{{ draft.fillOpacity * 100 }}%</mat-option
                      >
                    }
                  </mat-select></mat-form-field
                >
              }
              @if (hasBars || polar) {
                <mat-form-field appearance="outline"
                  ><mat-label>Corner radius</mat-label
                  ><input
                    matInput
                    type="number"
                    name="cornerRadius"
                    required
                    min="0"
                    max="20"
                    [(ngModel)]="draft.cornerRadius"
                  /><span matTextSuffix>px</span></mat-form-field
                >
              }
              @if (data.type === 'donut') {
                <mat-form-field appearance="outline"
                  ><mat-label>Donut hole</mat-label
                  ><mat-select name="donutHole" [(ngModel)]="draft.donutHole"
                    ><mat-option [value]="0.3">Small · 30%</mat-option
                    ><mat-option [value]="0.5">Medium · 50%</mat-option
                    ><mat-option [value]="0.7">Large · 70%</mat-option
                    ><mat-option [value]="0.8">Extra large · 80%</mat-option>
                    @if (![0.3, 0.5, 0.7, 0.8].includes(draft.donutHole)) {
                      <mat-option [value]="draft.donutHole"
                        >Custom · {{ draft.donutHole * 100 }}%</mat-option
                      >
                    }
                  </mat-select></mat-form-field
                >
              }
            </div>
          </mat-expansion-panel>
        </mat-accordion>
        <p class="format-note">
          Your chart data and filters stay the same. Changes are saved with the chart.
        </p>
      </mat-dialog-content>
      <mat-dialog-actions align="end"
        ><button
          mat-icon-button
          type="button"
          mat-dialog-close
          aria-label="Cancel"
          matTooltip="Cancel"
        >
          <mat-icon>close</mat-icon></button
        ><button
          mat-icon-button
          type="submit"
          [disabled]="formatForm.invalid"
          aria-label="Apply appearance"
          matTooltip="Apply appearance"
        >
          <mat-icon>check</mat-icon>
        </button></mat-dialog-actions
      >
    </form>
  `,
  styleUrl: './chart-format-dialog.component.scss',
})
export class ChartFormatDialogComponent {
  readonly data = inject<ChartFormatDialogData>(MAT_DIALOG_DATA);
  readonly theme = inject(AppThemeService);
  private readonly dialog = inject(MatDialogRef<ChartFormatDialogComponent, ChartFormatSettings>);
  readonly draft = structuredClone(this.data.settings);
  readonly positions = ['top', 'right', 'bottom', 'left'] as const;
  readonly polar = this.data.type === 'pie' || this.data.type === 'donut';
  readonly hasLines = this.data.seriesTypes.some((type) => type === 'line' || type === 'area');
  readonly hasBars = this.data.seriesTypes.includes('bar');
  readonly hasFill = this.data.seriesTypes.some((type) => type !== 'line');
  save(valid: boolean): void {
    if (valid) this.dialog.close(this.draft);
  }
}
