import type { ColumnSpec } from '../core/domain/schema';
import type { Node, Operator } from '../core/domain/contracts';
import { toModel } from '../core/domain/grid-model';
import { filterPreview } from '../core/domain/filter-preview';
import { queryAnalyticsRows, type AnalyticsSourceRow } from '../core/domain/analytics-engine';
import type { AnalyticsRowsRequest } from '../core/domain/analytics-query';
import { buildChartDataset } from '../core/domain/chart-data';
import { suggestCharts } from '../core/domain/chart-suggestion-engine';
import {
  describeChartPlan,
  type ChartPlan,
  type ChartResponse,
} from '../core/domain/integrated-chart';
import type { GridFeature } from '../core/domain/grid-copilot';
import type { PromptExample } from './prompt-examples';
import type { GridReviewPreview } from './demo-grid-preview-loader';
import type { LocalDataset } from './client-data-sources';

export interface LocalDataRecipe {
  example: PromptExample;
  gridState: Record<string, unknown>;
  propertiesToIgnore: GridFeature[];
  chart?: ChartPlan | null;
  preview: GridReviewPreview;
  chartPreview?: ChartResponse;
}

/** Typed, deterministic examples and their exact local query results. No network or model. */
export function buildLocalDataRecipes(dataset: LocalDataset): LocalDataRecipe[] {
  const columns = dataset.metadata.columns;
  const rows = dataset.rows as readonly AnalyticsSourceRow[];
  const fields = columns.filter((column) => column.chartRole !== 'identifier');
  const numbers = fields.filter((column) => column.kind === 'number');
  const texts = fields.filter((column) => column.kind === 'text');
  const dates = fields.filter((column) => column.kind === 'date' || column.kind === 'datetime');
  const spread = <T>(items: readonly T[], take: number): T[] => {
    if (items.length <= take) return [...items];
    return Array.from(
      { length: take },
      (_, index) => items[Math.round((index * (items.length - 1)) / (take - 1))],
    );
  };
  const candidates = [spread(numbers, 4), spread(texts, 4), spread(dates, 3)];
  const filterFields = Array.from({ length: 4 }, (_, index) =>
    candidates.flatMap((items) => (items[index] ? [items[index]] : [])),
  ).flat();
  const recipes: LocalDataRecipe[] = [];
  const maxRecipes = Math.min(30, Math.max(8, fields.length * 3 + 5));
  const label = (id: string) => columns.find((column) => column.id === id)?.label ?? id;
  const predicate = (column: ColumnSpec, op: Operator, value: string | number | null): Node => ({
    kind: 'rule',
    field: column.id,
    op,
    value,
  });
  const values = (column: ColumnSpec) =>
    rows.map((row) => row[column.id]).filter((value) => value != null);
  const distinct = new Map<string, (string | number)[]>();
  for (const column of [...spread(texts, 6), ...spread(dates, 3)]) {
    const set = new Set<string | number>();
    for (const row of rows) {
      const value = row[column.id];
      if (value != null) set.add(value);
      if (set.size > 200) break;
    }
    distinct.set(column.id, [...set]);
  }
  const dimensions = texts.filter((column) => {
    const count = distinct.get(column.id)?.length ?? 0;
    return count >= 2 && count <= 12;
  });
  type Options = {
    node?: Node;
    sort?: { colId: string; sort: 'asc' | 'desc' }[];
    group?: string;
    pivot?: string;
    measure?: string;
    chart?: ChartPlan;
    explanation?: string;
  };
  const add = (
    id: string,
    title: string,
    prompt: string,
    category: string,
    chosen: string[],
    options: Options = {},
  ) => {
    if (recipes.length >= maxRecipes) return;
    const filter = toModel(options.node ?? null, 'advanced', columns);
    const rowGroupCols = options.group ? [{ id: options.group }] : [];
    const valueCols = options.measure ? [{ id: options.measure, aggFunc: 'avg' }] : [];
    const pivotCols = options.pivot ? [{ id: options.pivot }] : [];
    const request: AnalyticsRowsRequest = {
      mode: 'advanced',
      calculatedColumnIds: [],
      request: {
        startRow: 0,
        endRow: 20,
        filterModel: filter,
        sortModel: options.sort ?? [],
        rowGroupCols,
        valueCols,
        pivotCols,
        pivotMode: !!options.pivot,
        groupKeys: [],
      },
    };
    const result = queryAnalyticsRows(null, request, {
      columns,
      rows,
      preserveRowReferences: true,
    });
    const grouped = !!options.group;
    const shown = grouped
      ? [
          options.group!,
          ...(result.pivotResultFields ?? (options.measure ? [options.measure] : [])),
        ]
      : [...new Set([...chosen, ...dataset.metadata.defaultVisibleColumnIds])].slice(0, 8);
    const operations = [
      ...(filter ? [filterPreview(filter, 'advanced', columns)] : ['Use all uploaded records.']),
      ...(options.sort ?? []).map(
        (sort) =>
          'Sort ' + label(sort.colId) + (sort.sort === 'desc' ? ' descending.' : ' ascending.'),
      ),
      ...(options.group ? ['Group by ' + label(options.group) + '.'] : []),
      ...(options.pivot ? ['Pivot by ' + label(options.pivot) + '.'] : []),
      ...(options.measure ? ['Average ' + label(options.measure) + ' within each group.'] : []),
    ];
    let chartPreview: ChartResponse | undefined;
    if (options.chart) {
      // Recipes use aggregate charts for large inputs. Raw point charts stay bounded and exact.
      if (['scatter', 'bubble', 'histogram'].includes(options.chart.type) && rows.length > 2000)
        return;
      try {
        const data = buildChartDataset(options.chart, columns, rows, Math.max(1, rows.length));
        if (data.rows.length < 2 || data.rows.length > 2000) return;
        chartPreview = { ...data, source: 'mock', scope: 'filtered-source-rows' };
        operations.push(describeChartPlan(options.chart, columns));
      } catch {
        return;
      }
    }
    const explanation =
      options.explanation ??
      (grouped
        ? 'Review the grouped result calculated from every uploaded row that matches the filter.'
        : 'Review the exact matching rows from your uploaded data before applying these changes.');
    const preview: GridReviewPreview = {
      prompt,
      status: 'ready',
      filterText: filterPreview(filter, 'advanced', columns),
      operations,
      columns: shown.map((id) => ({ id, label: id.split('|').map(label).join(' / ') })),
      rows: result.rowData.map((row) =>
        Object.fromEntries(shown.map((id) => [id, row[id] ?? null])),
      ),
      rowCount: result.rowCount,
      previewKind: grouped ? 'grouped-rows' : 'filtered-rows',
      explanation,
    };
    recipes.push({
      example: {
        id: 'local-' + id,
        title,
        prompt,
        category,
        outcome: 'apply',
        expectation: explanation + ' ' + operations.join(' '),
        fields: chosen,
        ...(options.chart ? { chartType: options.chart.type } : {}),
      },
      gridState: {
        filter: { advancedFilterModel: filter },
        sort: { sortModel: options.sort ?? [] },
        rowGroup: { groupColIds: rowGroupCols.map((column) => column.id) },
        aggregation: {
          aggregationModel: valueCols.map((column) => ({
            colId: column.id,
            aggFunc: column.aggFunc,
          })),
        },
        pivot: { pivotMode: !!options.pivot, pivotColIds: pivotCols.map((column) => column.id) },
      },
      propertiesToIgnore: [],
      chart: options.chart ?? null,
      preview,
      ...(chartPreview ? { chartPreview } : {}),
    });
  };

  add(
    'all',
    'Explore all uploaded records',
    'Show all records from ' + dataset.metadata.label + '.',
    'workflows',
    dataset.metadata.defaultVisibleColumnIds,
  );
  // Reserve room for chart and grouped examples even on wide schemas.
  const filterBudget = Math.min(14, Math.ceil(maxRecipes / 2));
  for (const column of filterFields) {
    if (recipes.length >= filterBudget) break;
    const observed = values(column);
    if (!observed.length) continue;
    if (column.kind === 'number') {
      const finite = observed.filter(
        (value): value is number => typeof value === 'number' && Number.isFinite(value),
      );
      if (!finite.length) continue;
      const threshold = finite[Math.floor(finite.length / 2)];
      add(
        'above-' + column.id,
        column.label + ' above ' + threshold,
        'Show records where ' + column.label + ' is greater than ' + threshold + '.',
        'logic',
        [column.id],
        { node: predicate(column, 'greaterThan', threshold) },
      );
      add(
        'sort-' + column.id,
        'Highest ' + column.label + ' first',
        'Sort all records by ' + column.label + ' descending.',
        'analysis',
        [column.id],
        { sort: [{ colId: column.id, sort: 'desc' }] },
      );
    } else if (column.kind === 'text') {
      const value = String(observed[0]);
      if (value.length > 160) continue;
      add(
        'equals-' + column.id,
        'Focus on ' + column.label,
        'Show records where ' + column.label + ' equals ' + JSON.stringify(value) + '.',
        'sets',
        [column.id],
        { node: predicate(column, 'equals', value) },
      );
      const choices = distinct.get(column.id) ?? [];
      if (choices.length >= 2)
        add(
          'either-' + column.id,
          'Either of two ' + column.label + ' values',
          'Show records where ' +
            column.label +
            ' equals ' +
            JSON.stringify(choices[0]) +
            ' or ' +
            JSON.stringify(choices[1]) +
            '.',
          'logic',
          [column.id],
          {
            node: {
              kind: 'group',
              join: 'OR',
              children: choices
                .slice(0, 2)
                .map((value) => predicate(column, 'equals', String(value))),
            },
          },
        );
    } else {
      const value = String(observed[Math.floor(observed.length / 2)]);
      add(
        'after-' + column.id,
        column.label + ' from an observed date',
        'Show records where ' + column.label + ' is on or after ' + value + '.',
        'dates',
        [column.id],
        { node: predicate(column, 'greaterThanOrEqual', value) },
      );
    }
    if (observed.length < rows.length && recipes.length < filterBudget)
      add(
        'missing-' + column.id,
        'Missing ' + column.label,
        'Show records with blank ' + column.label + '.',
        'sets',
        [column.id],
        { node: predicate(column, 'blank', null) },
      );
  }
  if (texts[0] && numbers[0]) {
    const textValue = values(texts[0])[0],
      numberValue = values(numbers[0]).find((value) => typeof value === 'number');
    if (textValue != null && typeof numberValue === 'number')
      add(
        'combined',
        'Combine a category and numeric threshold',
        'Show records where ' +
          texts[0].label +
          ' equals ' +
          JSON.stringify(textValue) +
          ' and ' +
          numbers[0].label +
          ' is at least ' +
          numberValue +
          '.',
        'logic',
        [texts[0].id, numbers[0].id],
        {
          node: {
            kind: 'group',
            join: 'AND',
            children: [
              predicate(texts[0], 'equals', String(textValue)),
              predicate(numbers[0], 'greaterThanOrEqual', numberValue),
            ],
          },
        },
      );
  }
  if (dimensions[0] && numbers[0]) {
    add(
      'group',
      'Average ' + numbers[0].label + ' by ' + dimensions[0].label,
      'Group by ' + dimensions[0].label + ' and average ' + numbers[0].label + '.',
      'analysis',
      [dimensions[0].id, numbers[0].id],
      { group: dimensions[0].id, measure: numbers[0].id },
    );
    if (dimensions[1])
      add(
        'pivot',
        'Pivot ' + numbers[0].label + ' across ' + dimensions[1].label,
        'Group by ' +
          dimensions[0].label +
          ', pivot by ' +
          dimensions[1].label +
          ', and average ' +
          numbers[0].label +
          '.',
        'analysis',
        [dimensions[0].id, dimensions[1].id, numbers[0].id],
        { group: dimensions[0].id, pivot: dimensions[1].id, measure: numbers[0].id },
      );
  }

  const plans: ChartPlan[] = [];
  for (const dimension of dimensions.slice(0, 3)) {
    const base: ChartPlan = {
      type: 'bar',
      categoryColumnId: dimension.id,
      measureColumnIds: numbers[0] ? [numbers[0].id] : [],
      aggregation: numbers[0] ? 'avg' : 'count',
      timeBucket: null,
      title: numbers[0]
        ? 'Average ' + numbers[0].label + ' by ' + dimension.label
        : 'Record count by ' + dimension.label,
    };
    plans.push(base, { ...base, type: 'groupedColumn', title: base.title + ' as columns' });
    plans.push({
      ...base,
      type: 'donut',
      aggregation: 'count',
      measureColumnIds: [],
      title: 'Record share by ' + dimension.label,
    });
  }
  try {
    for (const suggestion of suggestCharts(columns, rows, Math.max(rows.length, 1)).suggestions)
      plans.push(suggestion.plan);
  } catch {
    /* A schema with no useful chart dimensions still has exact grid recipes. */
  }
  for (const date of dates.slice(0, 2))
    plans.push({
      type: 'line',
      categoryColumnId: date.id,
      measureColumnIds: numbers[0] ? [numbers[0].id] : [],
      aggregation: numbers[0] ? 'avg' : 'count',
      timeBucket: 'month',
      title:
        (numbers[0] ? 'Average ' + numbers[0].label : 'Record count') +
        ' by ' +
        date.label +
        ' month',
    });
  if (numbers.length >= 2 && rows.length <= 2000)
    plans.push({
      type: 'scatter',
      categoryColumnId: null,
      measureColumnIds: numbers.slice(0, 2).map((column) => column.id),
      aggregation: null,
      timeBucket: null,
      title: numbers[0].label + ' versus ' + numbers[1].label,
    });
  const seen = new Set<string>();
  for (const plan of plans) {
    const signature = JSON.stringify([
      plan.type,
      plan.categoryColumnId,
      plan.measureColumnIds,
      plan.timeBucket,
    ]);
    if (seen.has(signature)) continue;
    seen.add(signature);
    const prompt = 'Create a ' + plan.type + ' chart: ' + plan.title + '.';
    add(
      'chart-' + recipes.length,
      plan.title,
      prompt,
      'charts',
      [plan.categoryColumnId, ...plan.measureColumnIds].filter((id): id is string => !!id),
      {
        chart: plan,
        explanation:
          'This chart is calculated from your uploaded rows with the reviewed aggregation and inferred column types.',
      },
    );
  }
  return recipes;
}
