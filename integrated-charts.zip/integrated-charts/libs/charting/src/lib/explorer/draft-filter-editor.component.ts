import { GridPopupLayer } from '../ui/grid-popup-layer';
import { injectUiState } from '../core/state/index';
import { DOCUMENT } from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  Output,
  SimpleChanges,
  ViewChild,
  effect,
  inject,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import {
  createGrid,
  type AdvancedFilterModel,
  type ColDef,
  type FilterChangedEvent,
  type GridApi,
} from 'ag-grid-community';
import { operators, type ColumnSpec } from '../core/domain/schema';
import { AppThemeService } from './app-theme.service';
import { AdvancedFilterBuilderComponent } from './advanced-filter-builder.component';

/** Native filter controls backed by an empty, private grid. No source rows are copied. */
@Component({
  selector: 'app-draft-filter-editor',
  standalone: true,
  imports: [MatButtonModule, MatIconModule, MatTooltipModule, AdvancedFilterBuilderComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="filter-expression-row">
      <div
        #filterHost
        class="draft-filter-host"
        role="group"
        [attr.aria-label]="label"
        [attr.inert]="disabled ? '' : null"
        [attr.aria-disabled]="disabled"
      ></div>
      @if (showBuilder) {
        <button
          mat-button
          class="filter-builder-icon"
          type="button"
          (click)="openBuilder()"
          [disabled]="disabled"
          [attr.aria-expanded]="builderOpen()"
          aria-label="Build visually"
          matTooltip="Filter builder"
        >
          <mat-icon>account_tree</mat-icon>Build visually
        </button>
      }
    </div>
    <div #gridHost class="draft-filter-grid" aria-hidden="true" inert></div>
    @if (builderOpen()) {
      <app-advanced-filter-builder
        [embedded]="embedded"
        [inline]="embedded"
        [columns]="columns"
        [model]="builderModel()"
        [title]="label"
        [applyLabel]="applyLabel"
        resetLabel="Include all records"
        (applied)="applyBuilder($event)"
        (closed)="builderOpen.set(false)"
      />
    }
  `,
  styles: `
    :host {
      display: block;
      min-width: 0;
      position: relative;
      container-type: inline-size;
    }
    .filter-expression-row {
      display: flex;
      align-items: center;
      gap: 8px;
      min-width: 0;
      min-height: 40px;
    }
    .draft-filter-host {
      flex: 1 1 0;
      min-width: 0;
      --ag-input-height: 42px;
      --ag-font-size: 13px;
      --ag-spacing: 6px;
      --ag-input-background-color: var(--mat-sys-surface-container-lowest);
      --ag-input-text-color: var(--mat-sys-on-surface);
      --ag-input-border: 1px solid var(--mat-sys-outline);
      --ag-input-focus-border: 1px solid var(--mat-sys-primary);
      --ag-input-border-radius: 8px;
    }
    .filter-builder-icon {
      --mat-icon-button-state-layer-size: 40px;
      --mat-icon-button-touch-target-display: none;
      flex: 0 0 auto;
      height: 40px;
      padding: 0 12px;
      color: var(--mat-sys-primary);
      background: var(--mat-sys-primary-container);
    }
    .filter-builder-icon mat-icon {
      width: 20px;
      height: 20px;
      font-size: 20px;
    }
    .draft-filter-grid {
      position: absolute;
      width: 1px;
      height: 1px;
      overflow: hidden;
      visibility: hidden;
      pointer-events: none;
    }
    :host ::ng-deep .draft-filter-host .ag-advanced-filter {
      flex-wrap: wrap;
      gap: 8px;
      padding: 0;
      min-height: 42px;
    }
    :host ::ng-deep .draft-filter-host .ag-autocomplete {
      flex: 1 1 160px;
      min-width: 0;
    }
    :host ::ng-deep .draft-filter-host .ag-advanced-filter-buttons {
      display: flex;
      flex: 0 0 auto;
      margin-left: 0;
      padding: 0;
      overflow: visible;
    }
    :host ::ng-deep .draft-filter-host .ag-input-field-input {
      min-height: 40px;
      font: inherit;
      font-size: 13px;
      color: var(--mat-sys-on-surface);
    }
    :host
      ::ng-deep
      .draft-filter-host
      :is(.ag-advanced-filter-apply-button, .ag-filter-apply-panel-apply-button) {
      display: flex;
      align-items: center;
      justify-content: center;
      flex: 0 0 auto;
      width: auto;
      min-width: 64px;
      height: 40px;
      margin: 0;
      padding: 0 12px;
      border: 0;
      border-radius: 8px;
      font: inherit;
      font-size: 12px;
      color: light-dark(#197a46, #6edc9b);
      background: color-mix(in srgb, currentColor 10%, transparent);
      text-transform: none;
    }
    :host
      ::ng-deep
      .draft-filter-host
      :is(.ag-advanced-filter-apply-button, .ag-filter-apply-panel-apply-button):disabled {
      color: var(--mat-sys-on-surface-variant);
      background: transparent;
      opacity: 0.4;
    }
    :host
      ::ng-deep
      .draft-filter-host
      :is(.ag-advanced-filter-apply-button, .ag-filter-apply-panel-apply-button):focus-visible {
      outline: 2px solid var(--mat-sys-primary);
      outline-offset: 2px;
    }
    @media (pointer: coarse) {
      :host ::ng-deep .draft-filter-host .ag-input-field-input {
        font-size: 16px;
      }
      :host
        ::ng-deep
        .draft-filter-host
        :is(.ag-advanced-filter-apply-button, .ag-filter-apply-panel-apply-button) {
        flex-basis: auto;
        width: auto;
        height: 44px;
      }
    }
  `,
})
export class DraftFilterEditorComponent implements AfterViewInit, OnChanges, OnDestroy {
  private readonly reactiveState = injectUiState('DraftFilterEditorComponent');

  @Input({ required: true }) columns: readonly ColumnSpec[] = [];
  @Input() model: AdvancedFilterModel | null = null;
  @Input() disabled = false;
  @Input() embedded = false;
  @Input() showBuilder = true;
  @Input() label = 'Choose records for the preview';
  @Input() applyLabel = 'Update preview';
  @Output() readonly modelChange = new EventEmitter<AdvancedFilterModel | null>();
  @ViewChild('filterHost', { static: true }) private filterHost!: ElementRef<HTMLElement>;
  @ViewChild('gridHost', { static: true }) private gridHost!: ElementRef<HTMLElement>;

  private readonly popups = inject(GridPopupLayer);
  private readonly theme = inject(AppThemeService);
  private readonly document = inject(DOCUMENT);
  private readonly element = inject(ElementRef<HTMLElement>);
  private api?: GridApi;
  private acceptedSignature = 'null';
  private inputSignature = '';
  private syncing = false;
  private destroyed = false;
  private builderPopup?: HTMLElement;
  readonly builderOpen = this.reactiveState.signal(false);
  readonly builderModel = this.reactiveState.signal<AdvancedFilterModel | null>(null);

  constructor() {
    effect(() => {
      const theme = this.theme.gridTheme();
      this.api?.setGridOption('theme', theme);
    });
  }

  ngAfterViewInit(): void {
    this.api = createGrid(this.gridHost.nativeElement, {
      theme: this.theme.gridTheme(),
      rowData: [],
      columnDefs: this.columnDefinitions(),
      defaultColDef: { cellDataType: false, sortable: false, resizable: false },
      enableAdvancedFilter: true,
      enableFilterHandlers: true,
      includeHiddenColumnsInAdvancedFilter: true,
      suppressSetFilterByDefault: true,
      advancedFilterParent: this.filterHost.nativeElement,
      advancedFilterParams: { suppressBuilderButton: true },
      popupParent: this.popups.parentFor(this.element.nativeElement),
      advancedFilterBuilderParams: {
        minWidth: Math.min(500, Math.max(280, (this.document.defaultView?.innerWidth ?? 720) - 32)),
        buttons: ['reset', 'cancel', 'apply'],
        showMoveButtons: true,
      },
      localeText: {
        ariaAdvancedFilterInput: this.label + ' expression',
        advancedFilterApply: this.applyLabel,
        advancedFilterBuilder: 'Filter builder',
        advancedFilterBuilderTitle: 'Choose records for the preview',
        advancedFilterBuilderApply: 'Update preview',
        advancedFilterBuilderReset: 'Include all records',
      },
      suppressNoRowsOverlay: true,
      suppressCellFocus: true,
      suppressHeaderFocus: true,
      animateRows: false,
      onFilterChanged: (event) => this.filterChanged(event),
      postProcessPopup: ({ type, ePopup }) => {
        if (type === 'advancedFilterBuilder') {
          this.builderPopup = ePopup;
          ePopup.dataset['chartDraftFilters'] = 'true';
        }
      },
    });
    this.syncModel();
    this.labelApplyButton();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (!this.api) return;
    if (this.disabled || !this.showBuilder) this.builderOpen.set(false);
    this.syncing = true;
    try {
      if (changes['columns']) this.api.setGridOption('columnDefs', this.columnDefinitions());
      if (changes['columns'] || this.inputSignature !== JSON.stringify(this.model))
        this.syncModel();
      this.labelApplyButton();
    } finally {
      this.syncing = false;
    }
  }

  openBuilder(): void {
    if (this.disabled || !this.showBuilder || !this.api) return;
    this.builderModel.set(this.api.getAdvancedFilterModel());
    this.builderOpen.set(true);
  }

  applyBuilder(model: AdvancedFilterModel | null): void {
    if (this.disabled) return;
    this.api?.setAdvancedFilterModel(model);
    const accepted = this.api?.getAdvancedFilterModel() ?? null;
    this.acceptedSignature = JSON.stringify(accepted);
    this.modelChange.emit(accepted ? structuredClone(accepted) : null);
    this.builderOpen.set(false);
  }

  private columnDefinitions(): ColDef[] {
    return this.columns.map((column) => ({
      field: column.id,
      headerName: column.label,
      cellDataType:
        column.kind === 'date'
          ? 'dateString'
          : column.kind === 'datetime'
            ? 'dateTimeString'
            : column.kind,
      filter:
        column.kind === 'text'
          ? 'agTextColumnFilter'
          : column.kind === 'number'
            ? 'agNumberColumnFilter'
            : 'agDateColumnFilter',
      filterParams: {
        filterOptions: operators(column),
        includeTime: column.kind === 'datetime',
        includeBlanksInEquals: false,
        includeBlanksInNotEqual: false,
        includeBlanksInLessThan: false,
        includeBlanksInGreaterThan: false,
      },
    }));
  }

  private syncModel(): void {
    if (!this.api) return;
    this.inputSignature = JSON.stringify(this.model);
    this.api.setAdvancedFilterModel(this.model ? structuredClone(this.model) : null);
    // AG Grid normalizes model property order and date literals. Compare its own
    // representation so input initialization is never mistaken for a user edit.
    this.acceptedSignature = JSON.stringify(this.api.getAdvancedFilterModel());
  }

  private labelApplyButton(): void {
    const button = this.filterHost.nativeElement.querySelector<HTMLButtonElement>(
      '.ag-advanced-filter-apply-button, .ag-filter-apply-panel-apply-button',
    );
    button?.setAttribute('aria-label', this.applyLabel);
    button?.setAttribute('title', this.applyLabel);
  }

  private filterChanged(event: FilterChangedEvent): void {
    if (this.destroyed || this.disabled || this.syncing || event.source !== 'advancedFilter')
      return;
    const model = event.api.getAdvancedFilterModel();
    const signature = JSON.stringify(model);
    if (signature === this.acceptedSignature) return;
    this.acceptedSignature = signature;
    this.modelChange.emit(model ? structuredClone(model) : null);
  }

  ngOnDestroy(): void {
    this.destroyed = true;
    const active = this.document.activeElement;
    const ownsFocus =
      !!active &&
      (this.element.nativeElement.contains(active) || this.builderPopup?.contains(active));
    let focusTarget: HTMLElement | undefined;
    if (ownsFocus) {
      // Preserve keyboard focus when changing steps with the native popup open.
      let parent: HTMLElement | null = this.element.nativeElement.parentElement;
      while (parent && !focusTarget) {
        focusTarget = Array.from(
          parent.querySelectorAll<HTMLElement>('button:not(:disabled), [tabindex="0"]'),
        ).find(
          (candidate) =>
            !this.element.nativeElement.contains(candidate) && !!candidate.getClientRects().length,
        );
        parent = parent.parentElement;
      }
    }
    if (this.api && !this.api.isDestroyed()) {
      this.api.hideAdvancedFilterBuilder();
      this.api.destroy();
    }
    this.api = undefined;
    this.builderPopup = undefined;
    focusTarget?.focus({ preventScroll: true });
  }
}
