import { CHARTING_DATA } from '../core/data-access/charting-data';
import { injectUiState } from '../core/state/index';
import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  Directive,
  ElementRef,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  Output,
  ViewChild,
  TemplateRef,
  computed,
  inject,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSelectModule } from '@angular/material/select';
import { MatDialog, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { PROMPT_CATEGORIES, PROMPT_OUTCOMES } from './prompt-examples';
import { ExampleChartPreviewComponent } from './example-chart-preview.component';
import { ExampleGridPreviewComponent } from './example-grid-preview.component';
import { CHART_DEMO_VARIANTS, chartDemoLabel, normalizeChartDemoType } from './chart-demo-types';
import {
  isLocalDataSource,
  type ClientDataSourceId,
  type LocalDataset,
} from './client-data-sources';
import type { LocalDataRecipe } from './local-data-recipes';
import { JsonImportComponent } from './json-import.component';

// The library is rendered through a dialog portal, outside the declaring component's view.
// Report the live viewport directly rather than relying on parent view queries.
@Directive({ selector: '[appLibraryViewport]', standalone: true })
export class LibraryViewportDirective implements AfterViewInit, OnDestroy {
  private readonly element = inject<ElementRef<HTMLDivElement>>(ElementRef);
  @Output() readonly viewportMounted = new EventEmitter<HTMLDivElement | null>();
  ngAfterViewInit(): void {
    this.viewportMounted.emit(this.element.nativeElement);
  }
  ngOnDestroy(): void {
    this.viewportMounted.emit(null);
  }
}

@Component({
  selector: 'app-prompt-library',
  standalone: true,
  imports: [
    FormsModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatTooltipModule,
    MatSelectModule,
    MatDialogModule,
    ExampleChartPreviewComponent,
    ExampleGridPreviewComponent,
    JsonImportComponent,
    LibraryViewportDirective,
  ],
  templateUrl: './prompt-library.component.html',
  styleUrl: './prompt-library.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PromptLibraryComponent implements OnChanges, AfterViewInit, OnDestroy {
  private readonly reactiveState = injectUiState('PromptLibraryComponent');

  @Input() open = false;
  @Input() provider = '';
  private readonly selectedSource = this.reactiveState.signal<ClientDataSourceId>('local_unconfigured');
  readonly uploadedDataset = this.reactiveState.signal<LocalDataset | null>(null);
  private readonly uploadedRecipes = this.reactiveState.signal<readonly LocalDataRecipe[]>([]);
  @Input() set localDataset(value: LocalDataset | null | undefined) {
    this.uploadedDataset.set(value ?? null);
  }
  @Input() set localRecipes(value: readonly LocalDataRecipe[] | undefined) {
    this.uploadedRecipes.set(value ?? []);
  }
  @Input() set dataSourceId(value: ClientDataSourceId) {
    if (value === this.selectedSource()) return;
    this.selectedSource.set(value);
    this.query.set('');
    this.category.set('all');
    this.chartVariant.set('all');
    this.resetViewport();
  }
  @Output() closed = new EventEmitter<void>();
  @Output() usePrompt = new EventEmitter<{ prompt: string; followUp: boolean }>();
  @Output() imported = new EventEmitter<LocalDataset>();
  readonly importing = this.reactiveState.signal(false);
  readonly recipeMap = computed(
    () => new Map(this.uploadedRecipes().map((recipe) => [recipe.example.id, recipe])),
  );
  readonly localSource = computed(() => isLocalDataSource(this.selectedSource()));
  readonly normalPeopleSource = computed(() => false);
  readonly benchmarkSource = computed(() => false);
  @ViewChild('dialog', { static: true }) private dialog?: TemplateRef<unknown>;
  private readonly dialogs = inject(MatDialog);
  private dialogRef?: MatDialogRef<unknown>;
  connectViewport(viewport: HTMLDivElement | null): void {
    // Updating the virtual rows can refresh Angular's ElementRef wrapper even
    // though the scrolling element has not changed. Do not restore its saved
    // position again on those updates, or every scroll backtracks to the anchor.
    if (viewport === this.viewport) return;
    if (this.viewport) this.rememberViewport();
    this.viewport = viewport ?? undefined;
    this.viewportObserver?.disconnect();
    this.rowMutationObserver?.disconnect();
    this.rowObserver?.disconnect();
    if (!this.viewport) return;
    this.viewportObserver = new ResizeObserver(() => this.measureViewport());
    this.viewportObserver.observe(this.viewport);
    this.rowMutationObserver = new MutationObserver(() => this.observeRows());
    this.rowMutationObserver.observe(this.viewport, { childList: true });
    this.observeRows();
    this.restoreViewport();
  }
  private viewport?: HTMLDivElement;
  private viewportObserver?: ResizeObserver;
  private rowObserver?: ResizeObserver;
  private rowMutationObserver?: MutationObserver;
  private scrollFrame = 0;
  private restoreFrame = 0;
  private preservedAnchor: { id: string; offset: number } | null = null;
  private rowFrame = 0;
  private readonly measuredRows = new Map<number, number>();
  private readonly rowHeights = this.reactiveState.signal<ReadonlyMap<number, number>>(new Map());
  private readonly viewportTop = this.reactiveState.signal(0);
  private readonly viewportHeight = this.reactiveState.signal(700);
  private readonly columnsPerRow = this.reactiveState.signal(2);
  private get estimatedRowHeight(): number {
    return this.benchmarkSource() ? 340 : 760;
  }
  private readonly rowGap = 20;
  readonly maxWindowRows = 6;
  readonly categories = computed(() =>
    PROMPT_CATEGORIES.map((category) => ({
      ...category,
      count: this.sourceExamples().filter((example) => example.category === category.id).length,
    })).filter((category) => category.count > 0),
  );
  readonly outcomes = PROMPT_OUTCOMES;
  readonly query = this.reactiveState.signal('');
  readonly category = this.reactiveState.signal('all');
  readonly chartVariant = this.reactiveState.signal('all');
  readonly previewSource = this.selectedSource.asReadonly();
  readonly chartLabel = chartDemoLabel;
  readonly chartVariants = computed(() =>
    CHART_DEMO_VARIANTS.map((variant) => ({
      ...variant,
      count: this.sourceExamples().filter(
        (example) => example.chartType && normalizeChartDemoType(example.chartType) === variant.id,
      ).length,
    })).filter((variant) => variant.count > 0),
  );
  readonly sourceLabel = computed(() => this.uploadedDataset()?.metadata.label ?? 'Model data');
  private readonly hostData = inject(CHARTING_DATA);
  readonly sourceExamples = computed(() =>
    this.hostData.prompts?.[this.selectedSource()] ?? this.uploadedRecipes().map((recipe) => recipe.example),
  );
  readonly total = computed(() => this.sourceExamples().length);
  readonly examples = computed(() => {
    const query = this.query().trim().toLowerCase();
    return this.sourceExamples().filter(
      (example) =>
        (this.category() === 'all' || example.category === this.category()) &&
        (this.category() !== 'charts' ||
          this.chartVariant() === 'all' ||
          (example.chartType &&
            normalizeChartDemoType(example.chartType) === this.chartVariant())) &&
        (!query ||
          `${example.title} ${example.prompt} ${example.expectation} ${this.outcomes[example.outcome]} ${example.chartType ? chartDemoLabel(example.chartType) : ''}`
            .toLowerCase()
            .includes(query)),
    );
  });
  readonly exampleRows = computed(() => {
    const examples = this.examples();
    const columns = this.columnsPerRow();
    return Array.from({ length: Math.ceil(examples.length / columns) }, (_, index) =>
      examples.slice(index * columns, (index + 1) * columns),
    );
  });
  readonly virtualWindow = computed(() => {
    const rows = this.exampleRows();
    const heights = this.rowHeights();
    const offsets = [0];
    for (let index = 0; index < rows.length; index++)
      offsets.push(offsets[index]! + (heights.get(index) ?? this.estimatedRowHeight));
    const top = this.viewportTop();
    let first = 0;
    while (first < rows.length - 1 && offsets[first + 1]! <= top) first++;
    let last = first;
    while (last < rows.length && offsets[last]! < top + this.viewportHeight()) last++;
    const start = Math.max(0, first - 1);
    const end = Math.min(rows.length, start + this.maxWindowRows, last + 1);
    return {
      rows: rows.slice(start, end).map((examples, index) => ({
        index: start + index,
        examples,
        minimumHeight: (heights.get(start + index) ?? this.estimatedRowHeight) - this.rowGap,
      })),
      before: offsets[start] ?? 0,
      after: offsets[rows.length]! - offsets[end]!,
    };
  });
  setQuery(value: string): void {
    this.query.set(value);
    this.resetViewport();
  }
  selectVariant(value: string): void {
    this.chartVariant.set(value);
    this.resetViewport();
  }
  selectCategory(value: string): void {
    this.category.set(value);
    this.chartVariant.set('all');
    this.resetViewport();
  }
  onViewportScroll(): void {
    if (!this.open || !this.viewport || this.restoreFrame || this.scrollFrame) return;
    this.scrollFrame = requestAnimationFrame(() => {
      this.scrollFrame = 0;
      if (this.open && this.viewport) this.viewportTop.set(this.viewport.scrollTop);
    });
  }
  private resetViewport(): void {
    this.stopRestoring();
    globalThis.cancelAnimationFrame?.(this.scrollFrame);
    this.scrollFrame = 0;
    this.preservedAnchor = null;
    this.measuredRows.clear();
    this.rowHeights.set(new Map());
    this.viewportTop.set(0);
    if (this.viewport) this.viewport.scrollTop = 0;
  }
  private measureViewport(): void {
    if (!this.open || !this.viewport || !this.viewport.clientHeight) return;
    this.viewportHeight.set(this.viewport.clientHeight);
    const columns = window.innerWidth <= 800 ? 1 : 2;
    if (columns !== this.columnsPerRow()) {
      this.columnsPerRow.set(columns);
      this.resetViewport();
    }
  }
  private restoreViewport(): void {
    globalThis.cancelAnimationFrame?.(this.restoreFrame);
    this.restoreFrame = requestAnimationFrame(() => {
      this.restoreFrame = 0;
      if (this.open && this.viewport) {
        this.measureViewport();
        this.viewport.scrollTop = this.viewportTop();
        const anchor = this.preservedAnchor;
        this.preservedAnchor = null;
        if (anchor) {
          const card = [...this.viewport.querySelectorAll<HTMLElement>('.example-card')].find(
            (element) => element.dataset['testid'] === anchor.id,
          );
          if (card) {
            const currentOffset =
              card.getBoundingClientRect().top - this.viewport.getBoundingClientRect().top;
            const desiredTop = this.viewport.scrollTop + currentOffset - anchor.offset;
            this.viewport.scrollTop = desiredTop;
            this.viewportTop.set(this.viewport.scrollTop);
          }
        }
      }
      // Restore once after the saved window is mounted. Repeating this while
      // previews load overrides native scrollbar input, whose pointer events
      // do not reach the viewport. Measured row sizes preserve the space until
      // those previews are ready; the user owns scrolling from this point on.
    });
  }
  stopRestoring(): void {
    globalThis.cancelAnimationFrame?.(this.restoreFrame);
    this.restoreFrame = 0;
  }
  private rememberViewport(): void {
    if (!this.viewport) return;
    this.viewportTop.set(this.viewport.scrollTop);
    const bounds = this.viewport.getBoundingClientRect();
    const card = [...this.viewport.querySelectorAll<HTMLElement>('.example-card')].find(
      (element) => {
        const rect = element.getBoundingClientRect();
        return rect.bottom > bounds.top + 32 && rect.top < bounds.bottom - 32;
      },
    );
    this.preservedAnchor = card?.dataset['testid']
      ? { id: card.dataset['testid'], offset: card.getBoundingClientRect().top - bounds.top }
      : null;
  }
  private observeRows(): void {
    this.rowObserver?.disconnect();
    this.rowObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const index = Number((entry.target as HTMLElement).dataset['rowIndex']);
        const height = Math.ceil(entry.borderBoxSize[0]?.blockSize ?? entry.contentRect.height);
        if (height) this.measuredRows.set(index, height + this.rowGap);
      }
      if (this.rowFrame) return;
      this.rowFrame = requestAnimationFrame(() => {
        this.rowFrame = 0;
        if (!this.open) return;
        const previous = this.rowHeights();
        if ([...this.measuredRows].some(([index, height]) => previous.get(index) !== height)) {
          // Keep the visible row anchored when a buffered preview above it finishes loading.
          // Read the actual position: wheel/scrollbar input may have moved it
          // since the last scroll event's animation frame was processed.
          const top = this.viewport?.scrollTop ?? this.viewportTop();
          let oldOffset = 0;
          let correction = 0;
          for (let index = 0; index < this.exampleRows().length; index++) {
            const oldHeight = previous.get(index) ?? this.estimatedRowHeight;
            if (oldOffset + oldHeight > top) break;
            correction += (this.measuredRows.get(index) ?? oldHeight) - oldHeight;
            oldOffset += oldHeight;
          }
          this.rowHeights.set(new Map(this.measuredRows));
          if (correction) {
            this.viewportTop.set(Math.max(0, top + correction));
            if (this.viewport) this.viewport.scrollTop = this.viewportTop();
          }
        }
      });
    });
    this.viewport
      ?.querySelectorAll<HTMLElement>('.example-row')
      .forEach((row) => this.rowObserver!.observe(row));
  }
  ngOnChanges(): void {
    this.syncDialog();
  }
  ngAfterViewInit(): void {
    this.syncDialog();
  }
  ngOnDestroy(): void {
    globalThis.cancelAnimationFrame?.(this.scrollFrame);
    globalThis.cancelAnimationFrame?.(this.restoreFrame);
    globalThis.cancelAnimationFrame?.(this.rowFrame);
    this.viewportObserver?.disconnect();
    this.rowObserver?.disconnect();
    this.rowMutationObserver?.disconnect();
    this.dialogRef?.close();
  }
  private syncDialog(): void {
    if (!this.open) this.importing.set(false);
    const dialog = this.dialog;
    if (!dialog) return;
    if (this.open && !this.dialogRef) {
      const ref = this.dialogs.open(dialog, {
        width: 'calc(100vw - 24px)',
        maxWidth: '1440px',
        height: 'calc(100dvh - 24px)',
        maxHeight: 'calc(100dvh - 24px)',
        panelClass: 'prompt-library-overlay',
        ariaLabelledBy: 'prompt-library-title',
        autoFocus: '[aria-label="Search prompt examples"]',
        restoreFocus: true,
        disableClose: true,
      });
      this.dialogRef = ref;
      ref.backdropClick().subscribe(() => this.dismiss());
      ref.keydownEvents().subscribe((event) => {
        if (event.key === 'Escape' && !event.defaultPrevented) {
          this.dismiss(event);
          event.stopPropagation();
        }
      });
      this.restoreViewport();
    } else if (!this.open && this.dialogRef) {
      this.rememberViewport();
      this.dialogRef.close();
      this.dialogRef = undefined;
    }
  }
  dismiss(event?: Event): void {
    this.rememberViewport();
    this.importing.set(false);
    event?.preventDefault();
    this.closed.emit();
  }
  select(prompt: string, followUp = false): void {
    this.usePrompt.emit({ prompt, followUp });
    this.closed.emit();
  }
  completeImport(dataset: LocalDataset): void {
    this.imported.emit(dataset);
    this.importing.set(false);
  }
}
