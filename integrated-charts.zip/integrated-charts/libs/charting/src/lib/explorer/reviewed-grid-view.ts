import type { Mode } from '../core/domain/contracts';
import type { ColumnSpec } from '../core/domain/schema';
import { GRID_FEATURES, type GridConfirmation } from '../core/domain/grid-copilot';
import { Fault } from '../core/domain/engine';
import { validateGridState } from '../core/domain/grid-state';
import { validateChartPlan } from '../core/domain/chart-data';
import { assertSetFiltersEnabled } from '../core/domain/set-filters';
import { DASHBOARD_PERIODS, DASHBOARD_TEMPLATES } from '../core/domain/dashboard';

/** Validate the whole reviewed change before touching either AG Grid or saved charts. */
export function prepareReviewedGridView(
  confirmation: GridConfirmation,
  currentState: Record<string, unknown>,
  mode: Mode,
  columns: readonly ColumnSpec[],
): GridConfirmation {
  const ignored = confirmation.propertiesToIgnore;
  if (
    !Array.isArray(ignored) ||
    new Set(ignored).size !== ignored.length ||
    ignored.some((feature) => !GRID_FEATURES.includes(feature))
  )
    throw new Fault('GRID_STATE', 'The reviewed changes contain unsupported grid features.');
  assertSetFiltersEnabled(confirmation.gridState, false);
  const state = { ...confirmation.gridState };
  for (const feature of ignored) state[feature] = currentState[feature];
  assertSetFiltersEnabled(state, false);
  const gridState = validateGridState(state, mode, columns, false);
  const chart = confirmation.chart ? validateChartPlan(confirmation.chart, columns) : null;
  const dashboard = confirmation.dashboard;
  if (
    dashboard &&
    (!DASHBOARD_TEMPLATES.includes(dashboard.template) ||
      (dashboard.period != null &&
        (dashboard.template !== 'financial' || !DASHBOARD_PERIODS.includes(dashboard.period))))
  )
    throw new Fault('DASHBOARD_PLAN', 'The reviewed dashboard settings are invalid.');
  return { ...structuredClone(confirmation), gridState, chart };
}
