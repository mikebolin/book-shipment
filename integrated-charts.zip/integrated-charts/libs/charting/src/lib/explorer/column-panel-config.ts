export type ColumnPanelAction = 'reveal' | 'pin' | 'group' | 'highlight' | 'move' | 'category';

/** Central defaults for column discovery, category editing and available actions. */
export interface ColumnPanelConfig {
  /** Preferred category order; other categories follow their source metadata order. */
  categories?: readonly string[];
  uncategorizedLabel?: string;
  allowCategoryEditing?: boolean;
  showAnalysis?: boolean;
  actions?: readonly ColumnPanelAction[];
}

export const DEFAULT_COLUMN_PANEL_CONFIG: Readonly<Required<ColumnPanelConfig>> = Object.freeze({
  categories: [],
  uncategorizedLabel: 'Other columns',
  allowCategoryEditing: true,
  showAnalysis: true,
  actions: ['reveal', 'pin', 'group', 'highlight', 'move', 'category'] as const,
});
