import { DecimalPipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, Input, OnChanges } from '@angular/core';
import type { ChartDataset, ChartResponse } from '../core/domain/integrated-chart';

@Component({
  selector: 'app-chart-data-summary',
  standalone: true,
  imports: [DecimalPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="chart-data-summary" role="status" aria-label="Chart data totals">
      @if (data.matchedRowCount != null) {
        <span
          ><strong>{{ data.matchedRowCount | number }}</strong> matching records</span
        >
      }
      @if (totals.length) {
        <details>
          <summary>Totals</summary>
          <div class="measure-totals">
            @for (total of totals; track total.id) {
              <span
                >{{ total.label }}: <strong>{{ total.value | number: '1.0-2' }}</strong></span
              >
            }
            @if (data.omittedRowCount) {
              <span>Displayed values only</span>
            }
          </div>
        </details>
      }
    </div>
  `,
  styles: `
    .chart-data-summary {
      display: flex;
      flex-wrap: wrap;
      gap: 8px 20px;
      padding: 6px 12px;
      color: var(--mat-sys-on-surface-variant);
      font-size: 11px;
      font-variant-numeric: tabular-nums;
    }
    strong {
      color: var(--mat-sys-on-surface);
    }
    summary {
      cursor: pointer;
      color: var(--mat-sys-primary);
    }
    summary:focus-visible {
      outline: 2px solid var(--mat-sys-primary);
      outline-offset: 2px;
    }
    .measure-totals {
      display: flex;
      flex-wrap: wrap;
      gap: 6px 16px;
      padding-top: 6px;
    }
  `,
})
export class ChartDataSummaryComponent implements OnChanges {
  @Input({ required: true }) data!: ChartDataset & Partial<ChartResponse>;
  totals: { id: string; label: string; value: number }[] = [];

  ngOnChanges(): void {
    // Only additive aggregates have a meaningful total across plotted categories.
    this.totals = this.data.columns.flatMap((column) => {
      if (column.aggregation !== 'sum' && column.aggregation !== 'count') return [];
      const values = this.data.rows
        .map((row) => row[column.id])
        .filter((value): value is number => typeof value === 'number' && Number.isFinite(value));
      return values.length || !this.data.rows.length
        ? [{ id: column.id, label: column.label, value: values.reduce((a, b) => a + b, 0) }]
        : [];
    });
  }
}
