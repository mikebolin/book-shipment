import type { ChartingDataSource } from '../core/data-access/charting-data';
import type { ChartResponse } from '../core/domain/integrated-chart';
export interface ExampleChartPreview {
  prompt: string;
  filterText: string;
  response: ChartResponse;
}
export interface ChartPreviewPack {
  snapshotDate: string;
  sourceId: string;
  previews: Record<string, ExampleChartPreview>;
}
/** Built assets only. No ExplorerDataService, fetch, provider, or live data endpoint. */
export async function loadExampleChartPreview(
  source: string,
  id: string,
  data: ChartingDataSource,
): Promise<{ snapshotDate: string; preview: ExampleChartPreview }> {
  const pack = await data.loadChartPreviews?.(source);
  if (!pack) throw new Error('This host has no saved chart previews.');
  const preview = pack.previews[id];
  if (!preview || pack.sourceId !== source)
    throw new Error('This example has no saved preview. Choose another chart example.');
  return { snapshotDate: pack.snapshotDate, preview: structuredClone(preview) };
}
