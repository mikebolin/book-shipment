import { injectUiState } from '../core/state/index';
import { DOCUMENT } from '@angular/common';
import { Clipboard } from '@angular/cdk/clipboard';
import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnDestroy,
  ViewChild,
  afterNextRender,
  computed,
  effect,
  inject,
  input,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import type { editor } from 'monaco-editor/editor';
import type { AppTheme } from './app-theme';
import { AppThemeService } from './app-theme.service';
import { EXPLORER_CONTEXT } from './explorer-context';

type Monaco = typeof import('monaco-editor/editor');
let editorModule: Promise<Monaco> | undefined;
let editorStyles: Promise<void> | undefined;
const registeredThemes = new WeakSet<AppTheme>();

function loadEditorStyles(document: Document): Promise<void> {
  if (!editorStyles) {
    editorStyles = new Promise<void>((resolve, reject) => {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = new URL('assets/monaco-editor/0.57.0/editor.main.css', document.baseURI).href;
      link.onload = () => {
        link.onload = null;
        link.onerror = null;
        resolve();
      };
      link.onerror = () => {
        link.remove();
        editorStyles = undefined;
        reject(new Error('The SQL editor stylesheet could not be loaded.'));
      };
      // Angular's production ESM splitting emits imported editor CSS without
      // linking it. Load Monaco's official self-contained stylesheet explicitly,
      // before creating the editor; its icons are embedded, with no CDN requests.
      document.head.appendChild(link);
    });
  }
  return editorStyles;
}

/** Load only the editor, SQL grammar and preview tools, never the language servers. */
function loadEditor(document: Document): Promise<Monaco> {
  if (!editorModule) {
    globalThis.MonacoEnvironment = {
      ...globalThis.MonacoEnvironment,
      getWorker: () =>
        new Worker(new URL('./sql-editor.worker.ts', import.meta.url), { type: 'module' }),
    };
    editorModule = Promise.all([
      import('monaco-editor/editor'),
      import('monaco-editor/languages/definitions/sql/register'),
      import('monaco-editor/features/find/register'),
      import('monaco-editor/features/folding/register'),
      import('monaco-editor/features/bracketMatching/register'),
      import('monaco-editor/features/clipboard/register'),
      import('monaco-editor/features/tokenization/register'),
      import('monaco-editor/features/toggleTabFocusMode/register'),
      loadEditorStyles(document),
    ])
      .then(([monaco]) => monaco)
      .catch((error: unknown) => {
        editorModule = undefined;
        throw error;
      });
  }
  return editorModule;
}

@Component({
  selector: 'app-sql-editor',
  standalone: true,
  imports: [MatButtonModule, MatIconModule, MatTooltipModule],
  template: `
    <section
      class="sql-editor"
      [attr.aria-label]="label()"
      [attr.aria-busy]="loading() || disabled()"
    >
      <div class="sql-editor-toolbar">
        <div class="sql-editor-language">
          <mat-icon aria-hidden="true">code</mat-icon>
          <span>SQL</span>
          <span class="sql-editor-readonly">Read only</span>
        </div>
        <div class="sql-editor-tools" role="toolbar" aria-label="SQL preview tools">
          @if (!mobile() && !plainText() && !failed()) {
            <button
              mat-icon-button
              type="button"
              aria-label="Find in SQL"
              matTooltip="Find in SQL (Ctrl/Cmd + F)"
              [disabled]="disabled() || !ready()"
              (click)="find()"
            >
              <mat-icon>search</mat-icon>
            </button>
          }
          <button
            mat-icon-button
            type="button"
            aria-label="Wrap SQL lines"
            matTooltip="Wrap lines"
            [attr.aria-pressed]="wrap()"
            [class.active]="wrap()"
            [disabled]="disabled()"
            (click)="toggleWrap()"
          >
            <mat-icon>wrap_text</mat-icon>
          </button>
          @if (!mobile()) {
            <button
              mat-icon-button
              type="button"
              aria-label="Use plain text SQL view"
              matTooltip="Accessible text view"
              [attr.aria-pressed]="plainText()"
              [class.active]="plainText()"
              [disabled]="disabled()"
              (click)="plainText.set(!plainText())"
            >
              <mat-icon>text_fields</mat-icon>
            </button>
          }
          <button
            mat-icon-button
            type="button"
            [attr.aria-label]="copied() ? 'SQL copied' : 'Copy SQL'"
            [matTooltip]="copied() ? 'Copied' : 'Copy SQL'"
            [disabled]="disabled() || !value()"
            (click)="copy()"
          >
            <mat-icon>{{ copied() ? 'check' : 'content_copy' }}</mat-icon>
          </button>
        </div>
      </div>
      <div class="sql-editor-content" [style.height.px]="height()">
        <div
          #editorHost
          class="monaco-host"
          [hidden]="!ready() || simpleView()"
          [attr.aria-hidden]="simpleView() || null"
        ></div>
        @if (simpleView() || !ready()) {
          <pre
            class="sql-text"
            [class.wrap]="wrap()"
            tabindex="0"
            [attr.aria-label]="label() + ', read only'"
            >{{ displayValue() || '-- No query to preview yet.' }}</pre
          >
        }
        @if (loading()) {
          <div class="sql-editor-loading" role="status">
            <span class="loading-dot"></span>Loading SQL editor
          </div>
        }
      </div>
      @if (failed() || copyError()) {
        <div class="sql-editor-notice" role="status">
          {{ copyError() || 'Editor unavailable. Your SQL is still available in the text view.' }}
          @if (failed() && !mobile()) {
            <button mat-button type="button" [disabled]="disabled()" (click)="retry()">
              Retry editor
            </button>
          }
        </div>
      }
      <span class="sr-only" role="status" aria-live="polite">{{
        copied() ? 'SQL copied to clipboard.' : ''
      }}</span>
    </section>
  `,
  styleUrl: './sql-editor.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SqlEditorComponent implements OnDestroy {
  private readonly reactiveState = injectUiState('SqlEditorComponent');

  readonly value = input('');
  readonly displayValue = computed(() => formatSqlPreview(this.value()));
  readonly label = input('Snowflake SQL preview');
  readonly disabled = input(false);
  readonly wrap = this.reactiveState.signal(true);
  readonly plainText = this.reactiveState.signal(false);
  readonly mobile = this.reactiveState.signal(false);
  readonly ready = this.reactiveState.signal(false);
  readonly loading = this.reactiveState.signal(false);
  readonly failed = this.reactiveState.signal(false);
  readonly copied = this.reactiveState.signal(false);
  readonly copyError = this.reactiveState.signal('');
  readonly simpleView = computed(() => this.mobile() || this.plainText() || this.failed());
  readonly height = computed(() =>
    Math.min(
      this.mobile() ? 360 : 480,
      Math.max(200, this.displayValue().split('\n').length * 21 + 32),
    ),
  );

  @ViewChild('editorHost', { static: true }) private host!: ElementRef<HTMLDivElement>;
  private readonly themes = inject(AppThemeService);
  private readonly explorerContext = inject(EXPLORER_CONTEXT);
  private readonly document = inject(DOCUMENT);
  private readonly clipboard = inject(Clipboard);
  private readonly rendered = this.reactiveState.signal(false);
  private instance?: editor.IStandaloneCodeEditor;
  private model?: editor.ITextModel;
  private generation = 0;
  private destroyed = false;
  private media?: MediaQueryList;
  private copyTimer?: ReturnType<typeof setTimeout>;
  private readonly onMediaChange = (event: MediaQueryListEvent) => this.mobile.set(event.matches);

  constructor() {
    afterNextRender(() => {
      // Monaco does not support mobile browsers; native text keeps selection,
      // touch scrolling and accessibility dependable on phones and tablets.
      this.media = this.document.defaultView?.matchMedia('(max-width: 640px), (pointer: coarse)');
      this.mobile.set(this.media?.matches ?? false);
      this.media?.addEventListener('change', this.onMediaChange);
      this.rendered.set(true);
    });
    effect(() => {
      if (this.explorerContext.isActive?.() === false || !this.rendered()) return;
      if (this.simpleView()) this.disposeEditor();
      else void this.mountEditor();
    });
    effect(() => {
      if (this.explorerContext.isActive?.() === false) return;
      const value = this.displayValue();
      const ready = this.ready();
      if (!ready || !this.instance || !this.model) return;
      if (this.model.getValue() !== value) {
        const viewState = this.instance.saveViewState();
        this.model.setValue(value);
        if (viewState) this.instance.restoreViewState(viewState);
      }
    });
    effect(() => {
      if (this.explorerContext.isActive?.() === false) return;
      const theme = this.themes.current();
      const wrap = this.wrap();
      const label = this.label();
      if (!this.ready() || !this.instance) return;
      this.instance.updateOptions({
        wordWrap: wrap ? 'on' : 'off',
        ariaLabel: `${label}, read only`,
        theme: themeName(theme),
      });
      // automaticLayout observes the host, including when a retained tab returns.
      // SQL-only updates do not need to reconfigure or relayout the editor.
    });
  }

  private async mountEditor(): Promise<void> {
    if (this.instance) return;
    const generation = ++this.generation;
    this.loading.set(true);
    try {
      const monaco = await loadEditor(this.document);
      if (
        this.destroyed ||
        generation !== this.generation ||
        this.explorerContext.isActive?.() === false
      )
        return;
      for (const theme of this.themes.choices) {
        // Theme definitions are global to Monaco; registering them per tab also
        // refreshes every existing editor using that theme.
        if (registeredThemes.has(theme)) continue;
        monaco.editor.defineTheme(themeName(theme), editorTheme(theme));
        registeredThemes.add(theme);
      }
      this.model = monaco.editor.createModel(this.displayValue(), 'sql');
      this.instance = monaco.editor.create(this.host.nativeElement, {
        model: this.model,
        theme: themeName(this.themes.current()),
        ariaLabel: `${this.label()}, read only`,
        readOnly: true,
        domReadOnly: true,
        automaticLayout: true,
        accessibilitySupport: 'auto',
        tabFocusMode: true,
        minimap: { enabled: false },
        fontFamily: 'Consolas, "SFMono-Regular", "Liberation Mono", monospace',
        fontSize: 13,
        lineHeight: 21,
        padding: { top: 16, bottom: 16 },
        lineNumbers: 'on',
        lineNumbersMinChars: 3,
        glyphMargin: false,
        folding: true,
        showFoldingControls: 'mouseover',
        renderLineHighlight: 'none',
        scrollBeyondLastLine: false,
        wordWrap: this.wrap() ? 'on' : 'off',
        contextmenu: false,
        occurrencesHighlight: 'off',
        selectionHighlight: true,
        overviewRulerLanes: 0,
        hideCursorInOverviewRuler: true,
        stickyScroll: { enabled: false },
        links: false,
        unicodeHighlight: { ambiguousCharacters: false, invisibleCharacters: false },
        scrollbar: {
          alwaysConsumeMouseWheel: false,
          verticalScrollbarSize: 10,
          horizontalScrollbarSize: 10,
        },
      });
      this.ready.set(true);
    } catch {
      if (!this.destroyed && generation === this.generation) this.failed.set(true);
    } finally {
      if (!this.destroyed && generation === this.generation) this.loading.set(false);
    }
  }

  find(): void {
    if (this.disabled()) return;
    this.instance?.focus();
    void this.instance?.getAction('actions.find')?.run();
  }

  toggleWrap(): void {
    if (!this.disabled()) this.wrap.update((value) => !value);
  }

  copy(): void {
    if (this.disabled() || !this.value()) return;
    this.copyError.set('');
    if (this.clipboard.copy(this.displayValue())) {
      clearTimeout(this.copyTimer);
      this.copied.set(true);
      this.copyTimer = setTimeout(() => this.copied.set(false), 2200);
    } else {
      this.plainText.set(true);
      this.copyError.set('Select the SQL text to copy it with your device’s copy command.');
    }
  }

  retry(): void {
    if (this.disabled()) return;
    this.failed.set(false);
    this.plainText.set(false);
  }

  private disposeEditor(): void {
    this.generation++;
    this.instance?.dispose();
    this.model?.dispose();
    this.instance = undefined;
    this.model = undefined;
    this.ready.set(false);
    this.loading.set(false);
  }

  ngOnDestroy(): void {
    this.destroyed = true;
    this.media?.removeEventListener('change', this.onMediaChange);
    clearTimeout(this.copyTimer);
    this.disposeEditor();
  }
}

/** Whitespace-only presentation of generated SELECTs; quoted identifiers and
 * literals, comments, bind parameters and expression arguments stay intact. */
function formatSqlPreview(sql: string): string {
  if (!/^\s*SELECT\b/i.test(sql)) return sql;
  const tokens =
    sql.match(
      /"(?:[^"]|"")*"|'(?:[^']|'')*'|--[^\r\n]*|\/\*[\s\S]*?\*\/|\$\$[\s\S]*?\$\$|[A-Za-z_][A-Za-z_0-9$]*|\s+|./g,
    ) ?? [];
  let formatted = '';
  let depth = 0;
  let projection = false;
  let skipSpace = false;
  for (const token of tokens) {
    if (skipSpace && /^\s+$/.test(token)) continue;
    skipSpace = false;
    if (token === '(') depth++;
    if (token === ')') depth = Math.max(0, depth - 1);
    if (depth === 0 && /^SELECT$/i.test(token)) {
      formatted += `${token}\n  `;
      projection = true;
      skipSpace = true;
    } else if (depth === 0 && projection && token === ',') {
      formatted += ',\n  ';
      skipSpace = true;
    } else if (depth === 0 && /^(FROM|WHERE|ORDER|GROUP|HAVING|QUALIFY|LIMIT)$/i.test(token)) {
      formatted = `${formatted.trimEnd()}\n${token}`;
      projection = false;
    } else {
      formatted += token;
    }
  }
  return formatted;
}

function themeName(theme: AppTheme): string {
  return `sql-material-${theme.id}`;
}

function editorTheme(theme: AppTheme): editor.IStandaloneThemeData {
  const color = (name: string) => theme.tokens[name]!;
  const token = (name: string) => color(name).replace('#', '');
  return {
    base: theme.dark ? 'vs-dark' : 'vs',
    inherit: true,
    rules: [
      { token: 'keyword', foreground: token('primary') },
      { token: 'string', foreground: token('tertiary') },
      { token: 'number', foreground: token('secondary') },
      { token: 'comment', foreground: token('on-surface-variant'), fontStyle: 'italic' },
      { token: 'delimiter', foreground: token('on-surface-variant') },
      { token: 'operator', foreground: token('primary') },
    ],
    colors: {
      'editor.background': color('surface-container-lowest'),
      'editor.foreground': color('on-surface'),
      'editorLineNumber.foreground': color('outline'),
      'editorLineNumber.activeForeground': color('primary'),
      'editorCursor.foreground': color('primary'),
      'editor.selectionBackground': color('primary-container'),
      'editor.inactiveSelectionBackground': color('secondary-container'),
      'editor.selectionHighlightBackground': `${color('primary-container')}80`,
      'editor.findMatchBackground': color('primary-container'),
      'editor.findMatchHighlightBackground': `${color('secondary-container')}a0`,
      'editor.findMatchBorder': color('primary'),
      'editorGutter.background': color('surface-container-lowest'),
      'editorWidget.background': color('surface-container'),
      'editorWidget.foreground': color('on-surface'),
      'editorWidget.border': color('outline-variant'),
      'input.background': color('surface-container-lowest'),
      'input.foreground': color('on-surface'),
      'input.border': color('outline-variant'),
      'inputOption.activeBackground': color('primary-container'),
      'inputOption.activeForeground': color('on-primary-container'),
      'inputOption.activeBorder': color('primary'),
      focusBorder: color('primary'),
      'widget.shadow': '#00000020',
      'scrollbarSlider.background': `${color('outline')}50`,
      'scrollbarSlider.hoverBackground': `${color('outline')}80`,
      'scrollbarSlider.activeBackground': `${color('outline')}a0`,
    },
  };
}
