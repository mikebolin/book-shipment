import { createGrid, type ColDef, type GridApi } from 'ag-grid-community';
import type { ColumnSpec } from '../core/domain/schema';
import type { Mode } from '../core/domain/contracts';
import { GRID_FEATURES } from '../core/domain/grid-copilot';

/** Build planning capabilities from the actual primary-column definitions.
 * AG Grid 36.2 builds Toolkit features from its current result columns. Pivoting
 * replaces those columns, omits filter/pivot capabilities, and exposes generated
 * IDs. A detached, empty native grid keeps the same Toolkit/configuration without
 * changing the user's filters, pivot, sorting, rows or selection.
 */
export function primaryColumnToolkitSchema(options: {
  columnDefs: readonly ColDef[];
  defaultColDef: ColDef;
  columns: readonly ColumnSpec[];
  mode: Mode;
  setFiltersEnabled: boolean;
}): Record<string, unknown> {
  const host = document.createElement('div');
  let api: GridApi | undefined;
  try {
    api = createGrid(host, {
      columnDefs: options.columnDefs.map((definition) => ({
        ...definition,
        rowGroup: false,
        initialRowGroup: false,
        pivot: false,
        initialPivot: false,
        aggFunc: null,
        initialAggFunc: undefined,
        sort: null,
        initialSort: null,
      })),
      defaultColDef: options.defaultColDef,
      rowModelType: 'clientSide',
      rowData: [],
      pivotMode: false,
      enableAdvancedFilter: options.mode === 'advanced',
      enableFilterHandlers: true,
      includeHiddenColumnsInAdvancedFilter: true,
      suppressSetFilterByDefault: true,
      suppressColumnVirtualisation: true,
      suppressRowVirtualisation: true,
      suppressAnimationFrame: true,
      animateRows: false,
    });
    const schema = api.getStructuredSchema({
      exclude: ['columnVisibility', 'columnSizing'],
      columns: Object.fromEntries(
        options.columns.map((column) => [
          column.id,
          {
            description: column.description,
            includeSetValues: false,
          },
        ]),
      ),
    }) as Record<string, any> | undefined;
    if (!schema?.properties || GRID_FEATURES.some((feature) => !schema.properties[feature])) {
      throw new Error(
        'The AG Grid AI Toolkit could not describe the configured source columns. Reload the grid.',
      );
    }
    return schema;
  } finally {
    api?.destroy();
    host.remove();
  }
}
