// Angular builds and serves this worker from the same origin as the application.
import 'monaco-editor/editor/editor.worker';
