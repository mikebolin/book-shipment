import type { FilterPreviewSource } from '../rendering/filter-preview';
import { GridPopupLayerDirective } from '../ui/grid-popup-layer';
import { CHARTING_DATA } from '../core/data-access/charting-data';
import { injectUiState } from '../core/state/index';
import type { ViewChartDataScope, WidgetConfiguration } from '../core/domain/workspace.types';
import { normalizeServerGridSettings } from '../core/domain/server-grid-settings';
import { captureViewCharts, chartDataScope, viewCharts } from '../rendering/view-charts';
import { UserPreferencesService } from '../core/data-access/user-preferences.service';
import { ChartCarouselComponent } from '../rendering/chart-carousel.component';
import { ChartFocusComponent } from '../rendering/chart-focus.component';
import { describeFilterScope } from '../rendering/filter-summary';
import { ViewExportService } from '../rendering/view-export.service';
import { registerGridRuntime } from './grid-runtime';
import { createStudioDatasource } from './studio-server-datasource';
import { MockStudioQueryExecutor } from './mock-studio-query-executor';
import { STUDIO_QUERY_EXECUTOR } from './studio-query-executor.token';
import type { StudioQuery } from '../core/domain/studio-query';
import type { AnalyticsSourceRow } from '../core/domain/analytics-engine';
import { viewCsv, viewExportColumns, downloadCsv } from '../rendering/view-export';
import { filteredExportRows } from '../rendering/filtered-export-rows';
import { capturePreview } from '../rendering/capture-preview';
import { configurationKey } from '../studio/studio-state';
import { persistedGridState } from '../rendering/grid-state-normalization';
import { MatDialog } from '@angular/material/dialog';
import { firstValueFrom } from 'rxjs';
import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  Injector,
  OnDestroy,
  ViewChild,
  afterNextRender,
  computed,
  effect,
  inject,
  untracked,
} from '@angular/core';
import { CommonModule, DOCUMENT } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TextFieldModule } from '@angular/cdk/text-field';
import { MatButtonModule } from '@angular/material/button';
import { MatBadgeModule } from '@angular/material/badge';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MAT_TOOLTIP_DEFAULT_OPTIONS, MatTooltipModule } from '@angular/material/tooltip';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSelectModule } from '@angular/material/select';
import { MatMenuModule } from '@angular/material/menu';
import { SqlEditorComponent } from './sql-editor.component';
import { AgGridAngular } from 'ag-grid-angular';
import type {
  AdvancedFilterModel,
  CalculatedColumnCreatedEvent,
  CalculatedColumnsGridOption,
  ColDef,
  GridApi,
  GridReadyEvent,
  IServerSideDatasource,
  GetRowIdParams,
  GetColumnMenuItemsParams,
  DefaultColumnMenuItem,
  MenuItemDef,
  GridState,
  IAdvancedFilterBuilderParams,
  ProcessPivotResultColDef,
  ProcessPivotResultColGroupDef,
  SideBarDef,
  StateUpdatedEvent,
  ToolPanelVisibleChangedEvent,
} from 'ag-grid-community';
import { AppThemeService } from './app-theme.service';
import { FilterToolPanelComponent, EXPLORER_FILTER_PANEL } from './filter-tool-panel.component';
import { ColumnsToolPanelComponent, EXPLORER_COLUMNS_PANEL } from './columns-tool-panel.component';
import { DEFAULT_COLUMN_PANEL_CONFIG } from './column-panel-config';
import {
  COLUMN_HIGHLIGHT_COLORS,
  columnHighlightClass,
  isColumnHighlightColor,
  type ColumnHighlightColor,
  type ColumnHighlights,
} from './column-highlights';
import { isColumnGroupTag } from '../core/domain/column-grouping';
import { ExplorerDataService } from './explorer-data.service';
import { EXPLORER_CONTEXT } from './explorer-context';
import type { RowStreamMetrics, StreamRow } from './ndjson-row-stream';
import type { AsyncGridStreamStats } from './async-grid-stream';
import { DashboardComponent } from './dashboard.component';
import type { ChartPresentation } from './integrated-chart.component';
import { SavedChartComponent, type SavedChartItem } from './saved-chart.component';
import {
  ChartProposalPreviewComponent,
  type ChartPreviewExchange,
} from './chart-proposal-preview.component';
import { filterPreview } from '../core/domain/filter-preview';
import type { ChartPlan, ChartRequest, ChartResponse } from '../core/domain/integrated-chart';
import { PromptLibraryComponent } from './prompt-library.component';
import {
  ChartGuideComponent,
  type ChartGuideSubmission,
  type ChartGuideDraft,
} from './chart-guide.component';
import {
  ProposalDataPreviewComponent,
  type ProposalDataRequest,
} from './proposal-data-preview.component';
import { assistantStarters } from './assistant-starters';
import { guidePlanError } from './chart-guide';
import { chartGuideRoles } from './chart-archetypes';
import { CHART_DEMO_VARIANTS, normalizeChartDemoType } from './chart-demo-types';
import type { ClientDataSourceId, LocalDataset } from './client-data-sources';
import {
  requestedWorkflow,
  refersToCurrentResults,
  startsIndependentDataRequest,
  targetsExistingChart,
  startsNewChartRequest,
  isChartTypeChoice,
  usesChartBuilderSettings,
  type WorkflowIntent,
} from './chat-workflow';
import { primaryColumnToolkitSchema } from './primary-column-toolkit';
import { prepareReviewedGridView } from './reviewed-grid-view';
import { clarificationContext, type PendingGridIntent } from './clarification-context';
import { gridChatContext } from './grid-chat-context';
import { parseNativeCalculation } from '../core/domain/native-calculated-columns';
import {
  DASHBOARD_PERIODS,
  type DashboardPlan,
  type DashboardResponse,
  type DashboardTemplate,
} from '../core/domain/dashboard';
import { operators, type ColumnSpec } from '../core/domain/schema';
import type { DataSourceId } from '../core/domain/demo-sources';
import type { GridModel, InterpretResult, Mode, Operation, Node } from '../core/domain/contracts';
import { expression, group } from '../core/domain/engine';
import { fromModel, toModel } from '../core/domain/grid-model';
import {
  GRID_FEATURES,
  type GridCopilotResult,
  type GridClarificationOption,
  type GridConfirmation,
  type GridChatTurn,
} from '../core/domain/grid-copilot';
import { groupKeyLabel, pivotKeyLabel } from '../core/domain/analytics-query';
import {
  CALCULATION_LIMITS,
  calculatedColumnSpec,
  type CalculatedColumnDefinition,
} from '../core/domain/calculated-columns';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  modelContext?: 'dialogue' | 'display';
  gridResult?: GridCopilotResult;
  filterResult?: InterpretResult;
  features?: string[];
  status?: 'active' | 'applied' | 'answered' | 'cancelled' | 'superseded' | 'error';
}
interface SavedChartState extends SavedChartItem {
  data: ChartResponse | null;
  loading: boolean;
  error: string;
  signature: string;
}
function chartEditorKey(plan: ChartPlan, filters: readonly Node[] = []): string {
  const stable = (value: unknown): unknown =>
    Array.isArray(value)
      ? value.map(stable)
      : value && typeof value === 'object'
        ? Object.fromEntries(
            Object.entries(value)
              .filter(([, child]) => child != null)
              .sort(([a], [b]) => a.localeCompare(b))
              .map(([key, child]) => [key, stable(child)]),
          )
        : value;
  return JSON.stringify(
    stable({ plan: { ...plan, type: normalizeChartDemoType(plan.type) }, filters }),
  );
}

const currencyFormatter = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' });
const countFormatter = new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 });
interface StreamProgress extends RowStreamMetrics {
  totalRows: number | null;
}
const emptyStreamProgress = (): StreamProgress => ({
  totalRows: null,
  receivedRows: 0,
  batches: 0,
  bytes: 0,
  elapsedMs: 0,
});

@Component({
  selector: 'app-data-explorer',
  standalone: true,
  providers: [
    {
      provide: ExplorerDataService,
      useFactory: () => {
        const context = inject(EXPLORER_CONTEXT);
        const api = new ExplorerDataService();
        api.setServerSideOnly(!!context.serverSideOnly);
        if (context.capabilities) api.capabilities.set({ ...context.capabilities });
        if (context.dataset) api.registerLocalDataset(context.dataset);
        if (context.snapshotRows && context.modelDefinition)
          api.cache.setRows(
            context.initialSource,
            context.snapshotRows,
            context.modelDefinition.columns,
          );
        api.setDataSource(context.initialSource);
        return api;
      },
    },
    {
      provide: MAT_TOOLTIP_DEFAULT_OPTIONS,
      useValue: {
        showDelay: 0,
        hideDelay: 0,
        touchendHideDelay: 1500,
        disableTooltipInteractivity: true,
      },
    },
  ],
  imports: [
    GridPopupLayerDirective,
    CommonModule,
    FormsModule,
    TextFieldModule,
    MatButtonModule,
    MatBadgeModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatProgressBarModule,
    MatTooltipModule,
    MatCheckboxModule,
    MatSelectModule,
    MatMenuModule,
    SqlEditorComponent,
    AgGridAngular,
    DashboardComponent,
    SavedChartComponent,
    ChartCarouselComponent,
    ChartFocusComponent,
    ChartProposalPreviewComponent,
    PromptLibraryComponent,
    ChartGuideComponent,
    ProposalDataPreviewComponent,
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AppComponent implements OnDestroy {
  readonly hostData = inject(CHARTING_DATA);
  private readonly reactiveState = injectUiState('AppComponent');

  readonly explorerContext = inject(EXPLORER_CONTEXT);
  private readonly workspaceRevision = this.reactiveState.signal(0);
  private readonly workspaceBaseline = this.reactiveState.signal<string | null>(null);
  private readonly workspaceDirty = computed(() => {
    this.workspaceRevision();
    const baseline = this.workspaceBaseline();
    return baseline !== null && baseline !== this.workspaceKey();
  });
  private workspaceKey(): string {
    if (!this.api || this.api.isDestroyed()) return '';
    return configurationKey({
      displayMode: this.savedDisplayMode(),
      serverGrid: this.serverGridSettings(),
      bothChartCount: this.bothChartCount(),
      viewLayout: this.viewLayout(),
      mode: this.mode(),
      gridState: this.api.getState(),
      calculatedColumns: this.calculatedColumns(),
      charts: captureViewCharts(this.savedCharts()),
      columnHighlights: this.columnHighlights(),
      columnCategories: Object.fromEntries(
        Object.entries(this.columnCategoryOverrides()).filter(
          (entry): entry is [string, string] => typeof entry[1] === 'string',
        ),
      ),
      categoryOrder: this.columnCategoryOrder().filter(
        (value): value is string => typeof value === 'string',
      ),
      showRowNumbers: this.showRowNumbers(),
    });
  }
  private markWorkspaceSaved(): void {
    this.workspaceBaseline.set(this.workspaceKey());
    this.workspaceRevision.update((value) => value + 1);
  }
  private requestWorkspaceBaseline(): void {
    if (this.pendingGridConfiguration || !this.ready() || this.streamState() !== 'completed') {
      this.baselineAfterRemount = true;
      return;
    }
    void this.settleWorkspaceBaseline();
  }
  /** Exploration is scratch work; only charts, filters and calculations are worth a prompt. */
  private hasMeaningfulWork(): boolean {
    return (
      this.savedCharts().length > 0 || this.hasActiveFilter() || this.calculatedColumns().length > 0
    );
  }
  private settleGeneration = 0;
  /**
   * The saved baseline is read from the live grid once it has settled: AG Grid applies
   * filters and expansion state in a deferred task, and Angular applies signal-driven
   * column definitions on the next frame. Until then nothing counts as a change.
   */
  private async settleWorkspaceBaseline(): Promise<void> {
    const generation = ++this.settleGeneration;
    this.workspaceBaseline.set(null);
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    await new Promise<void>((resolve) => {
      let done = false;
      const finish = () => {
        if (!done) {
          done = true;
          resolve();
        }
      };
      requestAnimationFrame(() => requestAnimationFrame(finish));
      // Background documents do not paint; do not leave the baseline open forever.
      setTimeout(finish, 150);
    });
    if (!this.destroyed && generation === this.settleGeneration) this.markWorkspaceSaved();
  }
  private readonly host = inject<ElementRef<HTMLElement>>(ElementRef);
  private readonly dialog = inject(MatDialog);
  private data = inject(ExplorerDataService);
  private readonly viewExport = inject(ViewExportService);

  private readonly injector = inject(Injector);
  private api?: GridApi;
  private request?: AbortController;
  private queuedLibraryPrompt?: { prompt: string; followUp: boolean };
  private previewRequest?: AbortController;
  private previewSignature = '';
  private dashboardRequest?: AbortController;
  private dashboardSignature = '';
  private readonly savedChartRequests = new Map<string, AbortController>();
  readonly savedCharts = this.reactiveState.signal<SavedChartState[]>([]);
  private gridEntityId: string = crypto.randomUUID();
  private gridFilterControls: NonNullable<WidgetConfiguration['grid']>['filterControls'];
  readonly viewFilterControls =
    this.reactiveState.signal<WidgetConfiguration['filterControls']>(undefined);
  readonly chartPage = this.reactiveState.signal(0);
  readonly chartSearch = this.reactiveState.signal('');
  private readonly preferences = inject(UserPreferencesService);
  /** Charts per page and per row are personal choices, shared with the reader. */
  readonly chartPageSize = computed(() => this.preferences.settings().chartGalleryPageSize);
  readonly chartColumns = computed(() => this.preferences.settings().chartGalleryColumns);
  readonly matchingCharts = computed(() => {
    const query = this.chartSearch().trim().toLocaleLowerCase();
    const charts = this.savedCharts();
    return query
      ? charts.filter((chart) =>
          `${chart.plan.title} ${chart.description ?? ''}`.toLocaleLowerCase().includes(query),
        )
      : charts;
  });
  readonly chartPageCount = computed(() =>
    Math.max(1, Math.ceil(this.matchingCharts().length / this.chartPageSize())),
  );
  readonly currentChartPage = computed(() => Math.min(this.chartPage(), this.chartPageCount() - 1));
  readonly galleryCharts = computed(() =>
    this.matchingCharts().slice(
      this.currentChartPage() * this.chartPageSize(),
      (this.currentChartPage() + 1) * this.chartPageSize(),
    ),
  );
  setChartColumns(columns: 1 | 2 | 3 | 4): void {
    void this.preferences.updateSettings({ chartGalleryColumns: columns }).catch(() => undefined);
  }
  setChartPageSize(size: 8 | 16 | 32): void {
    this.chartPage.set(0);
    void this.preferences.updateSettings({ chartGalleryPageSize: size }).catch(() => undefined);
  }
  readonly carouselChartId = this.reactiveState.signal<string | null>(null);
  readonly viewLayout = this.reactiveState.signal<NonNullable<WidgetConfiguration['viewLayout']>>(
    {},
  );
  readonly layoutVisibility = [
    { key: 'showTitle', label: 'Dataset title' },
    { key: 'showRecordCounts', label: 'Record counts' },
    { key: 'showFilterSummaries', label: 'Filter summaries' },
    { key: 'showChartDescriptions', label: 'Chart descriptions' },
  ] as const;
  setViewLayout(
    key: keyof NonNullable<WidgetConfiguration['viewLayout']>,
    value: boolean | 'top' | 'bottom',
  ) {
    this.viewLayout.update((layout) => ({ ...layout, [key]: value }));
    this.workspaceRevision.update((value) => value + 1);
  }
  readonly bothChartCount = this.reactiveState.signal<1 | 2 | 3>(2);
  readonly focusedChartId = this.reactiveState.signal<string | null>(null);
  readonly focusedChart = computed(
    () => this.savedCharts().find((chart) => chart.id === this.focusedChartId()) ?? null,
  );
  readonly visibleCarouselCharts = computed(() => {
    const charts = this.savedCharts();
    const start = Math.max(
      0,
      charts.findIndex((chart) => chart.id === this.carouselChartId()),
    );
    return Array.from(
      { length: Math.min(this.bothChartCount(), charts.length) },
      (_, offset) => charts[(start + offset) % charts.length],
    );
  });
  readonly carouselItems = computed(() =>
    this.savedCharts().map((chart) => ({ id: chart.id, title: chart.plan.title })),
  );
  readonly activeCarouselChart = computed<SavedChartState | null>(
    () =>
      this.savedCharts().find((chart) => chart.id === this.carouselChartId()) ??
      this.savedCharts().at(0) ??
      null,
  );
  readonly downloadingView = this.reactiveState.signal(false);
  readonly downloadError = this.reactiveState.signal('');
  private selectedChartId: string | null = null;
  private editingChartId: string | null = null;
  private followUpChartId: string | null = null;
  readonly builderDraft = this.reactiveState.signal<ChartGuideDraft | null>(null);
  readonly builderInitialPlan = this.reactiveState.signal<ChartPlan | null>(null);
  readonly builderInitialFilterControls =
    this.reactiveState.signal<WidgetConfiguration['filterControls']>(undefined);
  readonly builderDescription = this.reactiveState.signal('');
  private readonly builderDescriptionBaseline = this.reactiveState.signal('');
  readonly builderPresentation = this.reactiveState.signal<ChartPresentation | null>(null);
  private readonly builderPresentationBaseline = this.reactiveState.signal<string | null>(null);
  readonly builderResetToken = this.reactiveState.signal(0);
  readonly builderEditorMode = this.reactiveState.signal<'new' | 'edit'>('new');
  private readonly builderBaseline = this.reactiveState.signal<string | null>(null);
  private readonly builderReadySnapshot = this.reactiveState.signal<{
    key: string;
    request: ChartRequest;
    queryKey: string;
    source: ClientDataSourceId;
  } | null>(null);
  readonly builderDirty = computed(() => {
    const draft = this.builderDraft();
    return (
      !!draft &&
      draft.stage !== 'gallery' &&
      (this.builderEditorMode() === 'new' ||
        this.builderDescription() !== this.builderDescriptionBaseline() ||
        (this.builderBaseline() !== null &&
          this.builderDraftKey(draft) !== this.builderBaseline()) ||
        (this.builderPresentationBaseline() !== null &&
          this.builderPresentationKey(this.builderPresentation()) !==
            this.builderPresentationBaseline()))
    );
  });
  readonly builderCanApply = computed(() => {
    const draft = this.builderDraft();
    const snapshot = this.builderReadySnapshot();
    return (
      this.chartGuideOpen() &&
      draft?.stage === 'review' &&
      this.builderDirty() &&
      !!draft?.valid &&
      !!snapshot &&
      !this.busy() &&
      !this.builderLiveBusy() &&
      !this.builderLiveError() &&
      snapshot.source === this.dataSourceId() &&
      snapshot.key === this.builderDraftKey(draft)
    );
  });
  readonly builderInitialFilters = this.reactiveState.signal<Node[]>([]);
  readonly builderDataFilter = this.reactiveState.signal<AdvancedFilterModel | null>(null);
  readonly builderLiveData = this.reactiveState.signal<ChartResponse | null>(null);
  readonly builderLiveBusy = this.reactiveState.signal(false);
  readonly builderLiveError = this.reactiveState.signal('');
  readonly builderSuggestions = this.reactiveState.signal<
    { label: string; plan: ChartPlan; filters: Node[] }[]
  >([]);
  private builderPreviewController?: AbortController;
  private builderPreviewTimer?: ReturnType<typeof setTimeout>;
  private builderPreviewRevision = 0;
  @ViewChild('chatScroll') private chatScroll?: ElementRef<HTMLElement>;
  @ViewChild('composerInput') private composerInput?: ElementRef<HTMLTextAreaElement>;
  @ViewChild('assistantPanel') private assistantPanel?: ElementRef<HTMLElement>;
  @ViewChild('assistantToggle', { read: ElementRef })
  private assistantToggle?: ElementRef<HTMLButtonElement>;
  @ViewChild('previewTab', { read: ElementRef })
  private previewTab?: ElementRef<HTMLButtonElement>;
  readonly advancedFilterParams = { suppressBuilderButton: true };
  readonly filterBuilderOpen = this.reactiveState.signal(false);
  readonly columnsPanelOpen = this.reactiveState.signal(false);
  readonly columnHighlights = this.reactiveState.signal<ColumnHighlights>({});
  private readonly locatedColumn = this.reactiveState.signal<string | null>(null);
  private columnLocateTimer?: ReturnType<typeof setTimeout>;
  private nextColumnHighlight = 0;
  private readonly columnCategoryOverrides = this.reactiveState.signal<
    Record<string, string | undefined>
  >({});
  private readonly columnCategoryOrder = this.reactiveState.signal<readonly (string | undefined)[]>(
    [],
  );
  readonly filtersApplied = this.reactiveState.signal(false);
  readonly filterApplyStatus = this.reactiveState.signal('');
  private filterApplyTimer?: ReturnType<typeof setTimeout>;
  private appliedFilterKey = '';
  readonly advancedFilterBuilderParams: IAdvancedFilterBuilderParams = {
    buttons: ['reset', 'cancel', 'apply'],
    showMoveButtons: true,
  };
  readonly chartRecommendationsAvailable = computed(
    () => this.data.capabilities().chartRecommendationsAvailable,
  );
  readonly assistantOpen = this.reactiveState.signal(false);
  readonly workflowIntent = this.reactiveState.signal<WorkflowIntent>('data');
  readonly chartGuideOpen = this.reactiveState.signal(false);
  readonly builderAiOpen = this.reactiveState.signal(false);
  readonly chartGuideError = this.reactiveState.signal('');
  private guidedBaseFilter: GridModel = null;
  private guidedBaseDraftId?: string;
  private guidedBaseCaptured = false;
  readonly continuingView = this.reactiveState.signal(false);
  private readonly requestScope = this.reactiveState.signal<'current' | 'fresh'>('fresh');
  readonly dataSources = computed(
    () =>
      this.explorerContext.modelSources ?? [
        ...(this.hostData.sampleOptions ?? []),
        ...this.data.localSources(),
      ],
  );
  readonly dataSourceId = this.reactiveState.signal<ClientDataSourceId>(
    this.explorerContext.initialSource,
  );
  readonly source = computed(() => this.data.sourceMetadata(this.dataSourceId()));
  readonly modelDisplayName = computed(
    () =>
      this.dataSources().find((source) => source.id === this.dataSourceId())?.label ??
      this.source().label,
  );
  readonly localDataset = computed(() => this.data.getLocalDataset(this.dataSourceId()) ?? null);
  readonly localRecipes = computed(() => this.data.getLocalRecipes(this.dataSourceId()) ?? []);
  readonly sourceExamples = computed(
    () =>
      this.hostData.prompts?.[this.dataSourceId()] ??
      this.localRecipes().map((recipe) => recipe.example),
  );
  readonly libraryButtonLabel = computed(() => 'Library');
  readonly sourceLoading = this.reactiveState.signal(false);
  readonly sourceOpening = this.reactiveState.signal(false);
  readonly loadingElapsedMs = this.reactiveState.signal(0);
  private loadingElapsedTimer?: ReturnType<typeof setInterval>;
  readonly streamingEnabled = this.reactiveState.signal(false);
  readonly streamState = this.reactiveState.signal<
    'idle' | 'running' | 'completed' | 'cancelled' | 'error'
  >('idle');
  readonly dataLoading = computed(
    () =>
      this.sourceLoading() ||
      (this.streamState() === 'running' && this.rowCount() === null) ||
      (!this.ready() && !this.rowError() && !this.error()),
  );
  readonly actionsLocked = computed(
    () => this.sourceLoading() || !this.ready() || this.streamState() !== 'completed',
  );
  readonly filterExpressionOpen = this.reactiveState.signal(false);
  readonly filterExpressionDirty = this.reactiveState.signal(false);
  readonly filterCanApply = this.reactiveState.signal(false);
  readonly filterSummaryLabel = computed(() =>
    this.hasActiveFilter() ? this.current() : 'All records',
  );
  readonly tableFilterDescription = computed(() => {
    this.currentJson();
    return describeFilterScope({ mode: this.mode(), filterModel: this.model() }, this.columns());
  });
  readonly filterSearchWidth = this.reactiveState.signal(300);
  private filterMeasureContext?: CanvasRenderingContext2D | null;
  private appliedFilterExpression = '';
  private filterBaselinePending = true;
  private filterInputObserver?: MutationObserver;
  private filterHeaderObserver?: ResizeObserver;
  private filterInputSyncFrame = 0;
  private filterCaretFrame = 0;
  readonly streamProgress = this.reactiveState.signal<StreamProgress>(emptyStreamProgress());
  readonly streamError = this.reactiveState.signal('');
  readonly cachedRowCount = this.reactiveState.signal(0);
  readonly streamGridMetrics = this.reactiveState.signal<AsyncGridStreamStats | null>(null);
  readonly footerTotalRows = computed(() => this.streamProgress().totalRows);
  readonly footerReceivedRows = computed(() => this.streamProgress().receivedRows);
  readonly footerLoading = computed(() => !this.ready() || this.serverPending() > 0);
  readonly footerProgress = computed(() => {
    const total = this.footerTotalRows();
    if (total === null) return 0;
    if (total === 0) return this.footerLoading() ? 0 : 100;
    return Math.min(100, Math.max(0, (this.footerReceivedRows() / total) * 100));
  });
  readonly loadingPercent = computed(() => {
    if (this.streamState() === 'completed') return 100;
    const total = this.footerTotalRows();
    if (!total) return 0;
    return Math.min(99, Math.floor((this.cachedRowCount() / total) * 100));
  });
  readonly hasActiveFilter = computed(() => !['null', '{}'].includes(this.currentJson()));
  readonly activeFilterCount = computed(() => {
    try {
      const count = (model: any): number =>
        !model || typeof model !== 'object'
          ? 0
          : Array.isArray(model.conditions)
            ? model.conditions.reduce((sum: number, child: unknown) => sum + count(child), 0)
            : model.filterType
              ? 1
              : Object.values(model).reduce<number>((sum, child) => sum + count(child), 0);
      return count(JSON.parse(this.currentJson()));
    } catch {
      return 0;
    }
  });
  readonly serverGridSettings = this.reactiveState.signal(
    normalizeServerGridSettings(this.explorerContext.configuration?.serverGrid),
  );
  readonly gridRenderVersion = this.reactiveState.signal(0);
  private pendingGridConfiguration?: WidgetConfiguration;
  private baselineAfterRemount = false;
  private readonly configuredDisplayMode = this.reactiveState.signal<'grid' | 'chart' | 'both'>(
    this.explorerContext.configuration?.displayMode ??
      (this.explorerContext.configuration && viewCharts(this.explorerContext.configuration).length
        ? 'chart'
        : 'grid'),
  );
  get serverBlockSize() {
    return this.serverGridSettings().cacheBlockSize;
  }
  private readonly queryExecutor = inject(STUDIO_QUERY_EXECUTOR);
  get serverCacheBlocks() {
    return this.serverGridSettings().maxBlocksInCache;
  }
  readonly serverPending = this.reactiveState.signal(0);
  private serverDatasource?: IServerSideDatasource;
  private lastStudioQuery?: StudioQuery;
  private serverInitialResolve?: () => void;
  readonly getChildCount = (data: Record<string, unknown>): number =>
    typeof data?.['__groupCount'] === 'number' ? data['__groupCount'] : 0;
  readonly getRowId = (params: GetRowIdParams): string => {
    if (params.rowPinned) return JSON.stringify([this.dataSourceId(), 'total']);
    const groups = params.api.getRowGroupColumns();
    const group = groups[params.level];
    if (group)
      return JSON.stringify([
        this.dataSourceId(),
        'group',
        groups.map((c) => c.getColId()),
        params.parentKeys ?? [],
        params.data[group.getColId()],
      ]);
    const rowKey = this.source().sqlDataset.rowIdColumn;
    return JSON.stringify([
      this.dataSourceId(),
      params.api.isPivotMode() ? 'aggregate' : 'row',
      params.parentKeys ?? [],
      params.data[rowKey] ?? 'summary',
    ]);
  };
  private sourceInitialState: GridState = {};
  readonly chartPreviewRequest = this.reactiveState.signal<ChartRequest | null>(null);
  readonly proposedRowCount = this.reactiveState.signal<number | null>(null);
  readonly dataPreviewRequest = computed<ProposalDataRequest | null>(() => {
    const result = this.gridResult();
    if (result?.status !== 'proposal') return null;
    const filterModel = this.proposedFilterModel(result.gridState);
    const chartFields = result.chart
      ? [result.chart.categoryColumnId, ...result.chart.measureColumnIds].filter(
          (id): id is string => !!id,
        )
      : [];
    const filterFields: string[] = [];
    const walk = (value: unknown): void => {
      if (!value || typeof value !== 'object') return;
      if (Array.isArray(value)) {
        value.forEach(walk);
        return;
      }
      for (const [key, child] of Object.entries(value)) {
        if (key === 'colId' && typeof child === 'string') filterFields.push(child);
        else walk(child);
      }
    };
    walk(filterModel);
    if (this.mode() === 'columns' && filterModel) filterFields.push(...Object.keys(filterModel));
    return {
      mode: this.mode(),
      filterModel,
      calculatedColumnIds: this.calculatedColumnIds(),
      columnIds: [...new Set([...chartFields, ...filterFields])],
    };
  });
  readonly chartPreviewExchange = this.reactiveState.signal<ChartPreviewExchange | null>(null);
  readonly chartPreviewPresentation = this.reactiveState.signal<ChartPresentation | null>(null);
  private draftBaseId?: string;
  private draftChart?: ChartPlan;
  readonly assistantMobile = this.reactiveState.signal(
    window.matchMedia('(max-width: 900px)').matches,
  );
  readonly assistantVisualHeight = this.reactiveState.signal(
    window.visualViewport?.height ?? window.innerHeight,
  );
  readonly assistantVisualTop = this.reactiveState.signal(window.visualViewport?.offsetTop ?? 0);
  private readonly assistantVisualViewportChanged = (): void => {
    this.assistantVisualHeight.set(window.visualViewport?.height ?? window.innerHeight);
    this.assistantVisualTop.set(window.visualViewport?.offsetTop ?? 0);
  };
  private readonly assistantViewport = window.matchMedia('(max-width: 900px)');
  private assistantReturnFocus?: HTMLElement;
  private readonly assistantViewportChanged = (event: MediaQueryListEvent): void => {
    this.assistantMobile.set(event.matches);
    if (event.matches && this.assistantOpen()) this.focusComposer();
  };
  readonly chatMessages = this.reactiveState.signal<ChatMessage[]>([]);
  readonly activeChatId = this.reactiveState.signal<string | null>(null);
  readonly busyLabel = this.reactiveState.signal('Thinking through your request');
  private revision = 0;
  private destroyed = false;
  private signature = '';
  private pendingAggregateColumn?: string;
  private pendingIntent?: PendingGridIntent;
  private lastInterpretation?: {
    text: string;
    conversation: GridChatTurn[];
    chartContext: ChartPlan | null;
  };
  private retryConversation?: GridChatTurn[];
  readonly retryText = this.reactiveState.signal<string | null>(null);
  readonly retryLabel = this.reactiveState.signal('Retry request');
  readonly mode = this.reactiveState.signal<Mode>('advanced');
  readonly assistant = this.reactiveState.signal<'grid' | 'verified'>('grid');
  readonly operation = this.reactiveState.signal<Operation>('replace');
  readonly text = this.reactiveState.signal('');
  readonly busy = this.reactiveState.signal(false);
  readonly result = this.reactiveState.signal<InterpretResult | null>(null);
  readonly gridResult = this.reactiveState.signal<GridCopilotResult | null>(null);
  readonly analyticsActive = this.reactiveState.signal(false);
  readonly activeFeatures = this.reactiveState.signal<string[]>([]);
  readonly stateJson = this.reactiveState.signal('{}');
  readonly error = this.reactiveState.signal('');
  readonly hints = this.reactiveState.signal<string[]>([]);
  readonly notice = this.reactiveState.signal('');
  readonly current = this.reactiveState.signal('All records');
  readonly currentJson = this.reactiveState.signal('null');
  readonly schemaJson = this.reactiveState.signal('{}');
  readonly rowCount = this.reactiveState.signal<number | null>(null);
  readonly headerRecordCount = computed(() =>
    this.dataLoading() ? this.footerTotalRows() : this.rowCount(),
  );
  readonly rowError = this.reactiveState.signal('');
  readonly visible = this.reactiveState.signal(true);
  readonly ready = this.reactiveState.signal(false);
  readonly timeZone = this.reactiveState.signal('America/New_York');
  readonly provider = this.reactiveState.signal('mock');
  readonly gridProvider = this.reactiveState.signal('mock');
  readonly calculatedColumnsEnabled = this.reactiveState.signal(true);
  readonly nativeCalculationBusy = this.reactiveState.signal(false);
  readonly nativeCalculationError = this.reactiveState.signal('');
  readonly nativeCalculationDraft = this.reactiveState.signal<{
    requestId: string;
    label: string;
    expression: string;
    calculatedColumnIds: string[];
  } | null>(null);
  private nativeCalculationRequest?: AbortController;
  readonly nativeCalculatedColumns = computed<CalculatedColumnsGridOption>(() =>
    this.calculatedColumnsEnabled() &&
    this.streamState() === 'completed' &&
    this.execution() === 'mock' &&
    this.assistant() === 'grid' &&
    !this.nativeCalculationBusy() &&
    !this.busy() &&
    this.calculatedColumns().length < this.calculatedColumnLimit
      ? {
          applyMode: 'deferred',
          dataTypes: ['number'],
          expressionPickers: ['columns', 'operators'],
        }
      : false,
  );
  readonly calculatedColumnLimit = CALCULATION_LIMITS.columns;
  readonly calculatedColumns = this.reactiveState.signal<CalculatedColumnDefinition[]>([]);
  readonly calculatedColumnIds = computed(() => this.calculatedColumns().map((c) => c.id));
  readonly columns = computed(() => [
    ...this.source().columns,
    ...this.calculatedColumns().map((column) =>
      calculatedColumnSpec(column, this.source().columns),
    ),
  ]);
  private readonly columnsById = computed(
    () => new Map(this.columns().map((column) => [column.id, column])),
  );
  readonly execution = this.reactiveState.signal('mock');
  readonly setFiltersAllowed = this.reactiveState.signal(false);
  readonly setFiltersEnabled = this.reactiveState.signal(false);
  readonly dashboardsEnabled = this.reactiveState.signal(false);
  // Dashboard remains hidden; one shared grid drives every saved chart.
  readonly dashboardTabVisible = false;
  readonly chartsEnabled = this.reactiveState.signal(false);
  readonly resultView = this.reactiveState.signal<'grid' | 'sql' | 'dashboard' | 'chart' | 'both'>(
    'grid',
  );
  readonly chartPlan = this.reactiveState.signal<ChartPlan | null>(null);
  readonly chartData = this.reactiveState.signal<ChartResponse | null>(null);
  readonly chartPresentation = this.reactiveState.signal<ChartPresentation | null>(null);
  readonly dashboardPlan = this.reactiveState.signal<DashboardPlan>({
    template: 'portfolio',
    period: null,
  });
  readonly dashboardData = this.reactiveState.signal<DashboardResponse | null>(null);
  readonly dashboardBusy = this.reactiveState.signal(false);
  readonly dashboardError = this.reactiveState.signal('');
  readonly promptLibraryOpen = this.reactiveState.signal(false);
  readonly dashboardPeriods = DASHBOARD_PERIODS;
  readonly sqlJson = this.reactiveState.signal('');
  readonly sqlPreviewMode = this.reactiveState.signal<'filters' | 'query'>('query');
  readonly sqlBusy = this.reactiveState.signal(false);
  readonly sqlTail = computed(() => {
    const sql = this.sqlJson();
    const where = sql.indexOf(' WHERE ');
    // Calculated columns use CTEs with their own WHERE clause. Keep those definitions
    // intact so the preview never starts inside a subquery or drops its calculations.
    const preview = /^\s*WITH\b/i.test(sql) || where < 0 ? sql : sql.slice(where + 1);
    return preview.replace(' ORDER BY ', '\nORDER BY ').replace(' LIMIT ', '\nLIMIT ');
  });
  readonly bindsJson = this.reactiveState.signal('[]');
  readonly countSql = this.reactiveState.signal('');
  readonly sqlError = this.reactiveState.signal('');
  readonly schemaSearch = this.reactiveState.signal('');
  readonly filteredColumns = computed(() => {
    const q = this.schemaSearch().trim().toLowerCase();
    return this.columns()
      .filter((c) => !q || `${c.id} ${c.label} ${c.aliases.join(' ')}`.toLowerCase().includes(q))
      .slice(0, 30);
  });
  private tenant = '';
  private schemaReady: Promise<void>;
  private toolkitSchema: Record<string, unknown> = {};
  initialState: GridState = {};
  readonly theme = inject(AppThemeService);
  readonly defaultColDef: ColDef = {
    resizable: true,
    sortable: true,
    minWidth: 135,
    // Loading/ready column-definition swaps must not reset saved or resized widths.
    initialFlex: 1,
    filter: true,
    filterParams: { maxNumConditions: 2 },
  };
  readonly filterLocaleText = { advancedFilterApply: 'Apply filters' };
  readonly loadingColDef: ColDef = {
    ...this.defaultColDef,
    sortable: false,
    resizable: false,
    suppressHeaderMenuButton: true,
    suppressHeaderFilterButton: true,
  };
  readonly showRowNumbers = this.reactiveState.signal(false);
  readonly cellSelection = { enableHeaderHighlight: true, handle: { mode: 'range' as const } };
  readonly selectionStatusBar = {
    statusPanels: [
      {
        statusPanel: 'agAggregationComponent',
        align: 'right',
        statusPanelParams: { aggFuncs: ['count', 'sum', 'avg'] },
      },
    ],
  };
  readonly safeCsvExport = {
    processCellCallback: (params: { value: unknown }): string => {
      const value = String(params.value ?? '');
      return typeof params.value === 'string' && /^[\s]*[=+@\-\t\r]/.test(value)
        ? `'${value}`
        : value;
    },
  };
  async downloadAll(): Promise<void> {
    if (this.downloadingView()) return;
    if (this.actionsLocked() || this.busy() || !this.api || this.api.isDestroyed()) {
      throw new Error('Wait for the complete view before downloading.');
    }
    this.downloadingView.set(true);
    this.downloadError.set('');
    try {
      if (this.explorerContext.serverSideOnly && !this.data.cache.getRows(this.dataSourceId())) {
        const rows = await this.explorerContext.loadSnapshotRows?.();
        if (!rows)
          throw new Error(
            'Complete exports require an authorized snapshot or a server export adapter.',
          );
        this.data.cache.setRows(this.dataSourceId(), rows, this.source().columns);
        this.data.setServerSideOnly(false);
      }
      // Capture the grid and chart configurations together before querying any missing data.
      const csv = this.exportTableCsv();
      if (csv == null) throw new Error('The table could not be exported.');
      const charts = structuredClone(this.savedCharts());
      const fallback = { mode: this.mode(), filterModel: structuredClone(this.model()) };
      const calculatedColumnIds = this.calculatedColumnIds();
      const name = this.source().label;
      const items = await Promise.all(
        charts.map(async (chart) => ({
          data:
            chart.data && !chart.loading && !chart.error
              ? chart.data
              : await this.data.request<ChartResponse>('analytics/chart', {
                  plan: chart.plan,
                  ...chartDataScope(chart, fallback),
                  calculatedColumnIds,
                }),
          presentation: chart.presentation,
        })),
      );
      await this.viewExport.downloadAll(items, csv, name);
    } catch (error) {
      this.downloadError.set(
        error instanceof Error ? error.message : 'The view could not be downloaded.',
      );
      throw error;
    } finally {
      this.downloadingView.set(false);
    }
  }
  private exportTableCsv(): string {
    // Export the full filtered fixture, never just the SSRM cache. A real executor supplies an export operation.
    const rows = this.data.cache.getGridRows(this.dataSourceId());
    if (!rows)
      throw new Error(
        'Use Download all to request a complete authorized snapshot; server grid blocks are not a complete export.',
      );
    const state = this.api!.getState();
    const records = filteredExportRows(
      rows,
      this.columns(),
      state,
      this.mode(),
      this.source().sqlDataset.rowIdColumn,
    );
    return viewCsv(records, this.columns(), state);
  }
  downloadAllFromToolbar(): void {
    void this.downloadAll().catch(() => undefined);
  }
  gridTool(action: 'columns' | 'fit' | 'size' | 'csv' | 'excel' | 'rowNumbers'): void {
    if (this.actionsLocked() || this.busy() || !this.api || this.api.isDestroyed()) return;
    this.setResultView('grid');
    if (action === 'columns') this.openColumnsPanel();
    if (action === 'fit') this.api.sizeColumnsToFit();
    if (action === 'size') this.api.autoSizeColumns(this.api.getAllDisplayedColumns());
    if (action === 'rowNumbers') this.showRowNumbers.update((value) => !value);
    const fileName = this.source().label.replace(/[^a-z0-9_-]+/gi, '-');
    if ((action === 'csv' || action === 'excel') && !this.data.cache.getRows(this.dataSourceId())) {
      this.showError(
        new Error('Use Download all to request complete rows, or connect a server export adapter.'),
      );
      return;
    }
    if (action === 'csv') downloadCsv(this.exportTableCsv(), fileName);
    if (action === 'excel') {
      const records = filteredExportRows(
        this.data.cache.getGridRows(this.dataSourceId()) ?? [],
        this.columns(),
        this.api.getState(),
        this.mode(),
        this.source().sqlDataset.rowIdColumn,
      );
      const columns = viewExportColumns(this.columns(), this.api.getState());
      this.api.exportDataAsExcel({
        fileName: `${fileName}.xlsx`,
        sheetName: 'Data explorer',
        autoConvertFormulas: false,
        columnKeys: columns.map((column) => column.id),
        skipColumnHeaders: true,
        skipColumnGroupHeaders: true,
        shouldRowBeSkipped: () => true,
        skipPinnedTop: true,
        skipPinnedBottom: true,
        skipRowGroups: true,
        appendContent: [
          {
            cells: columns.map((column) => ({
              data: { type: 'String' as const, value: column.label },
            })),
          },
          ...records.map((row) => ({
            cells: columns.map((column) => {
              const value = row[column.id];
              return {
                data: {
                  type: typeof value === 'number' ? ('Number' as const) : ('String' as const),
                  value: value == null ? '' : String(value),
                },
              };
            }),
          })),
        ],
      });
    }
  }
  readonly autoGroupColumnDef: ColDef = {
    minWidth: 210,
    pinned: 'left',
    filter: false,
    // Leaf rows carry no group key; only group rows show the decoded label.
    valueFormatter: (params) => (params.node?.group ? groupKeyLabel(params.value) : ''),
  };
  readonly processPivotResultColDef: ProcessPivotResultColDef = (definition) => {
    if (definition.headerName) definition.headerName = pivotKeyLabel(definition.headerName);
    definition.filter = false;
  };
  readonly processPivotResultColGroupDef: ProcessPivotResultColGroupDef = (definition) => {
    if (definition.headerName) definition.headerName = pivotKeyLabel(definition.headerName);
  };
  readonly advancedSideBar: SideBarDef = {
    hideButtons: true,
    position: 'left',
    toolPanels: [
      {
        id: EXPLORER_COLUMNS_PANEL,
        labelDefault: 'Columns',
        labelKey: 'columns',
        iconKey: 'columns',
        toolPanel: ColumnsToolPanelComponent,
        toolPanelParams: {
          panelId: this.domId('columns-tool-panel'),
          getColumns: () => this.columns(),
          isLocked: () => this.actionsLocked() || this.busy(),
          closePanel: () => this.closeColumnsPanel(),
          onHighlight: (id: string | null, color?: ColumnHighlightColor) =>
            this.highlightColumn(id, color),
          onLocate: (id: string) => this.locateColumn(id),
          getHighlights: () => this.columnHighlights(),
          getCategory: (id: string) => this.columnCategory(id),
          setCategory: (id: string, category: string | undefined) =>
            this.setColumnCategory(id, category),
          setCategories: (assignments: Record<string, string | undefined>) =>
            this.setColumnCategories(assignments),
          getCategoryOrder: () => this.columnCategoryOrder(),
          setCategoryOrder: (order: readonly (string | undefined)[]) => {
            if (
              !this.actionsLocked() &&
              !this.busy() &&
              order.every((category) => category === undefined || isColumnGroupTag(category))
            )
              this.columnCategoryOrder.set([...new Set(order)]);
          },
          config: DEFAULT_COLUMN_PANEL_CONFIG,
        },
      },
      {
        id: EXPLORER_FILTER_PANEL,
        labelDefault: 'Filters',
        labelKey: 'explorerFilters',
        iconKey: 'filter',
        toolPanel: FilterToolPanelComponent,
        toolPanelParams: {
          panelId: this.domId('filter-tool-panel'),
          getColumns: () => this.orderedFilterColumns(),
          getModel: () =>
            this.mode() === 'advanced'
              ? (this.api?.getAdvancedFilterModel() ?? null)
              : (toModel(
                  fromModel(this.model(), this.mode(), this.columns()),
                  'advanced',
                  this.columns(),
                  this.setFiltersEnabled(),
                ) as AdvancedFilterModel | null),
          isLocked: () => this.actionsLocked() || this.busy(),
          applyModel: (model: AdvancedFilterModel | null) => this.applyFilterBuilder(model),
          clearModel: () => this.clearCurrentFilters(),
          closePanel: () => this.closeFilterPanel(),
        },
      },
    ],
  };
  readonly columnDefs: ColDef[] = this.source().columns.map((c, index) =>
    this.columnDefinition(c, index),
  );
  private rebuildColumnDefinitions(): void {
    this.columnDefs.splice(
      0,
      this.columnDefs.length,
      ...this.columns().map((column, index) =>
        this.columnDefinition(column, index < this.source().columns.length ? index : 0),
      ),
    );
    this.api?.setGridOption('columnDefs', this.columnDefs);
  }
  setSetFiltersEnabled(enabled: boolean): void {
    // Set domains must never become part of an AI planning schema.
    if (enabled) return;
    if (
      !this.api ||
      !this.ready() ||
      !this.setFiltersAllowed() ||
      enabled === this.setFiltersEnabled()
    )
      return;
    if (!enabled && JSON.stringify(this.model()).includes('"filterType":"set"')) {
      this.showError(
        new Error(
          'Clear the active Set Filters before turning this capability off. Your filters have been preserved.',
        ),
      );
      return;
    }
    const previous = this.api.getState();
    const target = toModel(
      fromModel(this.model(), this.mode(), this.columns()),
      this.mode(),
      this.columns(),
      enabled,
    );
    this.invalidate();
    this.setFiltersEnabled.set(enabled);
    this.rebuildColumnDefinitions();
    this.api.setState({
      ...previous,
      filter:
        this.mode() === 'advanced'
          ? { advancedFilterModel: target as AdvancedFilterModel | null }
          : { filterModel: target ?? {} },
    } as GridState);
    this.refreshSchema();
    this.signature = this.currentQueryKey();
    this.updateCurrent();
  }
  private columnDefinition(c: ColumnSpec, index: number): ColDef {
    const useSetFilter = !!c.values && this.setFiltersEnabled();
    return {
      field: c.id,
      contextMenuItems: (params) => {
        const items = params.defaultItems ?? [];
        return this.nativeCalculatedColumns() && params.column?.isPrimary()
          ? [...items, ...(items.length ? ['separator' as const] : []), 'calculatedColumn']
          : items;
      },
      enableRowGroup: true,
      enablePivot: c.kind !== 'number',
      enableValue: c.kind === 'number',
      ...(c.kind === 'number'
        ? { allowedAggFuncs: ['sum', 'avg', 'min', 'max', 'count', 'first', 'last'] }
        : {}),
      // Only the initial value: a stateful `hide` would be re-applied on every column
      // definition refresh (defaultColDef swaps, calculated columns) and silently undo
      // the visibility a saved view restored through api.setState.
      initialHide:
        index > 0 &&
        !this.source().defaultVisibleColumnIds.includes(c.id) &&
        !c.id.startsWith('calc_'),
      headerName: c.label,
      headerTooltip: c.description || c.label,
      headerClass: () => {
        const color = this.columnHighlights()[c.id];
        return [
          ...(color ? ['explorer-column-highlight', columnHighlightClass(color)] : []),
          ...(this.locatedColumn() === c.id ? ['explorer-column-located'] : []),
        ];
      },
      cellClassRules: {
        'explorer-column-located': () => this.locatedColumn() === c.id,
        'explorer-column-highlight': () => !!this.columnHighlights()[c.id],
        ...Object.fromEntries(
          COLUMN_HIGHLIGHT_COLORS.map((color) => [
            columnHighlightClass(color.id),
            () => this.columnHighlights()[c.id] === color.id,
          ]),
        ),
      },
      minWidth: c.kind === 'datetime' ? 195 : 140,
      cellDataType:
        c.kind === 'date' ? 'dateString' : c.kind === 'datetime' ? 'dateTimeString' : c.kind,
      filter: useSetFilter
        ? 'agSetColumnFilter'
        : c.kind === 'text'
          ? 'agTextColumnFilter'
          : c.kind === 'number'
            ? 'agNumberColumnFilter'
            : 'agDateColumnFilter',
      filterParams: {
        maxNumConditions: 2,
        numAlwaysVisibleConditions: 1,
        filterOptions: [
          ...operators(c),
          ...(c.kind !== 'text' ? ['inRange'] : []),
          ...(useSetFilter ? ['isAnyOf', 'isNoneOf'] : []),
        ],
        ...(useSetFilter ? { values: [...c.values!, ...(c.nullable ? [null] : [])] } : {}),
        buttons: ['apply', 'reset'],
        includeTime: c.kind === 'datetime',
        inRangeInclusive: true,
        debounceMs: 250,
        includeBlanksInEquals: false,
        includeBlanksInNotEqual: false,
        includeBlanksInLessThan: false,
        includeBlanksInGreaterThan: false,
      },
      ...(c.unit === 'USD'
        ? {
            valueFormatter: (p: any) => {
              if (p.value == null) return '—';
              const pivotValueColumn = p.colDef.pivotValueColumn;
              const aggregate = pivotValueColumn?.getAggFunc() ?? p.column?.getAggFunc();
              const isCount =
                aggregate === 'count' && (p.node?.group || p.node?.footer || !!pivotValueColumn);
              return (isCount ? countFormatter : currencyFormatter).format(p.value);
            },
          }
        : {}),
    };
  }
  readonly examples = computed(() =>
    assistantStarters(this.sourceExamples(), {
      source: this.dataSourceId(),
      columnIds: this.columns().map((column) => column.id),
      assistant: this.assistant(),
      mode: this.mode(),
      chartsEnabled: this.chartsEnabled(),
      setFiltersEnabled: this.setFiltersEnabled(),
      chartOnly: this.workflowIntent() === 'chart',
    }).map((example) => ({ id: example.id, label: example.title, value: example.prompt })),
  );
  constructor() {
    registerGridRuntime();
    this.current.set(this.allRecordsLabel());
    effect(() => {
      const available = this.chartRecommendationsAvailable();
      const ready = this.streamState() === 'completed';
      const source = this.dataSourceId();
      if (available && ready)
        untracked(() => {
          void this.data.ensureChartRecommendations(source).catch((error) => {
            if (!this.destroyed && (error as Error).name !== 'AbortError') this.showError(error);
          });
        });
    });
    this.assistantViewport.addEventListener('change', this.assistantViewportChanged);
    window.visualViewport?.addEventListener('resize', this.assistantVisualViewportChanged);
    window.visualViewport?.addEventListener('scroll', this.assistantVisualViewportChanged);
    window.addEventListener('resize', this.assistantVisualViewportChanged);
    this.schemaReady = this.loadSchema();
    void this.schemaReady.catch(() => {});
  }
  domId(name: string): string {
    return `${this.explorerContext.id}-${name}`;
  }
  isActiveExplorer(): boolean {
    return !this.destroyed && (this.explorerContext.isActive?.() ?? true);
  }
  async selectDataSource(value: string): Promise<void> {
    if (this.destroyed || this.sourceOpening()) return;
    const id = value;
    const selected = this.dataSources().find((source) => source.id === id);
    if (!selected) return;
    if (this.explorerContext.activateExisting?.(selected.id)) return;
    if (id === this.dataSourceId()) return;
    if (this.explorerContext.modelSources) {
      this.explorerContext.openTab?.({ id: selected.id, label: selected.label });
      return;
    }
    this.sourceOpening.set(true);
    try {
      await this.prepareDataSource(selected.id);
      if (this.destroyed) return;
      this.explorerContext.openTab?.({
        id: selected.id,
        label: selected.label,
        dataset: this.data.getLocalDataset(selected.id),
        capabilities: this.data.capabilities(),
      });
    } catch (error) {
      if (!this.destroyed) this.showError(error);
    } finally {
      if (!this.destroyed) this.sourceOpening.set(false);
    }
  }
  private async prepareDataSource(id: ClientDataSourceId): Promise<void> {
    if (this.data.getLocalDataset(id)) return;
    const dataset = await this.hostData.loadSample?.(id);
    if (dataset) this.data.registerLocalDataset(dataset);
  }
  private loadSchema(): Promise<void> {
    const source = this.source();
    if (this.explorerContext.serverSideOnly) {
      this.execution.set('server');
      this.provider.set('host');
      this.gridProvider.set('host');
      this.timeZone.set('UTC');
      this.calculatedColumnsEnabled.set(false);
      this.setFiltersAllowed.set(false);
      this.setFiltersEnabled.set(false);
      this.dashboardsEnabled.set(false);
      this.chartsEnabled.set(false);
      this.streamingEnabled.set(false);
      return Promise.resolve();
    }
    return this.data
      .request<{
        version: string;
        timeZone: string;
        provider: string;
        gridProvider?: string;
        liveAiAvailable?: boolean;
        liveAiProvider?: string | null;
        calculatedColumnsEnabled?: boolean;
        setFiltersEnabled?: boolean;
        dashboardsEnabled?: boolean;
        chartsEnabled?: boolean;
        streamingEnabled?: boolean;
        tenant: string;
        execution: string;
      }>('schema')
      .then((c) => {
        // An earlier source's schema must never replace the active source's capabilities.
        if (this.destroyed || source.id !== this.dataSourceId()) return;
        if (c.version !== source.version)
          throw new Error(
            'The browser and server schema versions differ. Reload after deploying matching builds.',
          );
        this.tenant = c.tenant;
        this.execution.set(c.execution);
        this.timeZone.set(c.timeZone);
        this.provider.set(c.provider);
        this.gridProvider.set(c.gridProvider ?? c.provider);
        this.calculatedColumnsEnabled.set(c.calculatedColumnsEnabled ?? true);
        this.setFiltersAllowed.set(false);
        this.setFiltersEnabled.set(false);
        this.dashboardsEnabled.set(this.dashboardTabVisible && (c.dashboardsEnabled ?? false));
        this.chartsEnabled.set(c.chartsEnabled ?? false);
        this.streamingEnabled.set(c.streamingEnabled ?? false);
      })
      .catch((e) => {
        if (this.destroyed || source.id !== this.dataSourceId()) return;
        this.showError(e);
        throw e;
      });
  }
  async switchDataSource(value: string): Promise<void> {
    if (this.explorerContext.modelSources) {
      await this.selectDataSource(value);
      return;
    }
    if (value === this.dataSourceId() || this.dataLoading() || this.busy()) return;
    const selected = this.dataSources().find((source) => source.id === value);
    if (!selected) return;
    this.sourceLoading.set(true);
    try {
      await this.prepareDataSource(selected.id);
    } catch (error) {
      this.sourceLoading.set(false);
      this.showError(error);
      return;
    }
    this.cancelServerGrid();
    this.streamState.set('idle');
    this.streamProgress.set(emptyStreamProgress());
    this.streamError.set('');
    this.streamingEnabled.set(false);
    this.cachedRowCount.set(0);
    this.ready.set(false);
    this.invalidate();
    this.previewRequest?.abort();
    this.previewRequest = undefined;
    this.sqlBusy.set(false);
    this.dashboardRequest?.abort();
    this.nativeCalculationRequest?.abort();
    this.clearChartData();
    this.visible.set(false);
    this.api = undefined;
    this.dataSourceId.set(selected.id);
    clearTimeout(this.columnLocateTimer);
    this.locatedColumn.set(null);
    this.columnCategoryOverrides.set({});
    this.columnCategoryOrder.set([]);
    this.columnHighlights.set({});
    this.nextColumnHighlight = 0;
    this.columnsPanelOpen.set(false);
    this.filterBuilderOpen.set(false);
    this.data.setDataSource(selected.id);
    this.explorerContext.sourceChanged?.({
      id: selected.id,
      label: selected.label,
      dataset: this.data.getLocalDataset(selected.id),
    });
    this.chatMessages.set([]);
    this.text.set('');
    this.calculatedColumns.set([]);
    this.data.cache.setCalculatedColumns(selected.id, []);
    this.nativeCalculationDraft.set(null);
    this.nativeCalculationBusy.set(false);
    this.nativeCalculationError.set('');
    this.rowCount.set(null);
    this.rowError.set('');
    this.chartPlan.set(null);
    this.chartPresentation.set(null);
    this.savedCharts.set([]);
    this.selectedChartId = null;
    this.editingChartId = null;
    this.resetBuilder();
    this.dashboardData.set(null);
    this.dashboardBusy.set(false);
    this.dashboardError.set('');
    this.dashboardPlan.set({ template: 'portfolio', period: null });
    this.resultView.set('grid');
    this.mode.set('advanced');
    this.assistant.set('grid');
    this.operation.set('replace');
    this.requestScope.set('fresh');
    this.workflowIntent.set('data');
    this.chartGuideOpen.set(false);
    this.chartGuideError.set('');
    this.continuingView.set(false);
    this.initialState = {};
    this.sourceInitialState = {};
    this.signature = '';
    this.previewSignature = '';
    this.dashboardSignature = '';
    this.sqlJson.set('');
    this.bindsJson.set('[]');
    this.countSql.set('');
    this.sqlError.set('');
    this.schemaSearch.set('');
    this.promptLibraryOpen.set(false);
    this.current.set(this.allRecordsLabel());
    this.rebuildColumnDefinitions();
    // Destroy the prior grid before creating one with this source's column IDs.
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    this.schemaReady = this.loadSchema();
    try {
      await this.schemaReady;
      this.visible.set(true);
    } catch {
      this.rowError.set('Could not load this data source. Select another source to retry.');
    } finally {
      this.sourceLoading.set(false);
    }
  }
  async importLocalDataset(dataset: LocalDataset): Promise<void> {
    if (this.sourceLoading()) return;
    this.data.registerLocalDataset(dataset);
    await this.selectDataSource(dataset.metadata.id);
    this.notice.set(
      'File added to this browser tab. Open Example library for suggestions based on its columns.',
    );
  }
  private allRecordsLabel(): string {
    return `All ${this.source().rowLabel}s in ${this.localDataset() ? 'this file' : 'your permitted dataset'}`;
  }
  async onGridReady(e: GridReadyEvent): Promise<void> {
    const configuration = this.pendingGridConfiguration ?? this.explorerContext.configuration;
    const remounted = !!this.pendingGridConfiguration;
    this.pendingGridConfiguration = undefined;
    this.api = e.api;
    e.api.addEventListener('stateUpdated', this.onGridStateUpdated);
    try {
      await this.schemaReady;
    } catch {
      return;
    }
    if (e.api.isDestroyed()) return;
    this.rebuildColumnDefinitions();
    if (!remounted) this.sourceInitialState = e.api.getState();
    this.ready.set(true);
    this.host.nativeElement
      .querySelector<HTMLInputElement>('.advanced-filter-host input')
      ?.setAttribute('placeholder', 'Explore Data');
    const apply = this.host.nativeElement.querySelector<HTMLButtonElement>(
      '.ag-filter-apply-panel-apply-button',
    );
    apply?.setAttribute('aria-label', 'Apply filters');
    apply?.setAttribute('title', 'Apply filters');
    this.refreshSchema();
    this.signature = this.currentQueryKey();
    this.updateCurrent();
    this.appliedFilterKey = JSON.stringify(this.model());
    this.observeFilterInput();
    if (configuration) this.restoreWorkspace(configuration);
    else {
      const recipe = this.localDataset()?.initialAnalysisChart;
      if (recipe?.chart)
        this.restoreWorkspace({
          schemaVersion: 1,
          modelSchemaVersion: this.source().version,
          mode: 'advanced',
          gridState: recipe.gridState,
          calculatedColumns: [],
          chart: { id: crypto.randomUUID(), plan: recipe.chart, presentation: null },
        });
    }
    // Restore the authored query before attaching a datasource. AG applies some
    // filter state asynchronously, so allow it and Angular's options to settle.
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    if (this.destroyed || e.api.isDestroyed() || this.api !== e.api) return;
    await this.startServerGrid();
    if (this.destroyed || e.api.isDestroyed() || this.api !== e.api) return;
    if (!remounted || this.baselineAfterRemount) {
      this.baselineAfterRemount = false;
      await this.settleWorkspaceBaseline();
    } else this.workspaceRevision.update((value) => value + 1);
    if (this.destroyed) return;
    this.explorerContext.attachEditor?.({
      canCapture: () =>
        !!this.api &&
        !this.api.isDestroyed() &&
        this.ready() &&
        !this.pendingGridConfiguration &&
        this.streamState() === 'completed' &&
        !this.busy() &&
        !this.savedCharts().some((chart) => chart.loading) &&
        !(this.chartGuideOpen() && this.builderDirty()),
      capture: () => this.captureWorkspace(),
      hasChanges: () => this.workspaceDirty(),
      hasMeaningfulWork: () => this.hasMeaningfulWork(),
      markSaved: () => this.requestWorkspaceBaseline(),
      restore: (config) => this.restoreWorkspace(config),
      downloadAll: () => this.downloadAll(),
      reset: () => {
        this.restoreWorkspace({
          schemaVersion: 1,
          modelSchemaVersion:
            this.explorerContext.modelDefinition?.schemaVersion ?? this.source().version,
          mode: 'advanced',
          gridState: structuredClone(this.sourceInitialState ?? {}),
          calculatedColumns: [],
          chart: null,
          columnCategories: {},
          categoryOrder: [],
          showRowNumbers: false,
        });
        void this.settleWorkspaceBaseline();
      },
    });
  }
  private captureWorkspace(): WidgetConfiguration {
    if (
      !this.api ||
      this.api.isDestroyed() ||
      !this.ready() ||
      this.pendingGridConfiguration ||
      this.streamState() !== 'completed'
    )
      throw new Error('Wait for the complete model before saving.');
    if (this.busy())
      throw new Error('Wait for the current chart or grid operation to finish before saving.');
    if (this.chartGuideOpen() && this.builderDirty())
      throw new Error('Add or apply your chart changes before saving this configuration.');
    const saved =
      this.savedCharts().find((c) => c.id === this.selectedChartId) ?? this.savedCharts().at(-1);
    if (this.savedCharts().some((chart) => chart.loading))
      throw new Error('Wait for the chart previews before saving.');
    const matchingRecords = this.rowCount() ?? 0;
    const preview = saved?.data
      ? capturePreview(saved.data)
      : {
          schemaVersion: 1 as const,
          type: 'summary' as const,
          label: 'Matching records',
          value: matchingRecords,
        };
    return structuredClone({
      schemaVersion: 1,
      modelSchemaVersion:
        this.explorerContext.modelDefinition?.schemaVersion ?? this.source().version,
      displayMode: this.savedDisplayMode(),
      serverGrid: this.serverGridSettings(),
      bothChartCount: this.bothChartCount(),
      viewLayout: this.viewLayout(),
      grid: {
        id: this.gridEntityId,
        ...(this.gridFilterControls ? { filterControls: this.gridFilterControls } : {}),
      },
      mode: this.mode(),
      gridState: persistedGridState(this.api.getState()),
      calculatedColumns: this.calculatedColumns(),
      chart: saved ? captureViewCharts([saved])[0] : null,
      charts: captureViewCharts(this.savedCharts()),
      preview,
      recordCount: matchingRecords,
      columnHighlights: this.columnHighlights(),
      columnCategories: Object.fromEntries(
        Object.entries(this.columnCategoryOverrides()).filter(
          (entry): entry is [string, string] => typeof entry[1] === 'string',
        ),
      ),
      categoryOrder: this.columnCategoryOrder().filter((v): v is string => typeof v === 'string'),
      showRowNumbers: this.showRowNumbers(),
    });
  }
  private restoreWorkspace(config: WidgetConfiguration): void {
    if (!this.api || this.api.isDestroyed()) return;
    const policy = normalizeServerGridSettings(config.serverGrid);
    this.configuredDisplayMode.set(
      config.displayMode ?? (viewCharts(config).length ? 'chart' : 'grid'),
    );
    if (JSON.stringify(policy) !== JSON.stringify(this.serverGridSettings())) {
      // AG's cache and concurrency controls are initialization options. Recreate its
      // grid with the complete supplied state instead of silently changing only labels.
      this.pendingGridConfiguration = structuredClone(config);
      this.serverGridSettings.set(policy);
      this.cancelServerGrid();
      this.api.removeEventListener('stateUpdated', this.onGridStateUpdated);
      this.ready.set(false);
      this.gridRenderVersion.update((value) => value + 1);
      return;
    }
    this.gridEntityId = config.grid?.id ?? crypto.randomUUID();
    this.gridFilterControls = config.grid?.filterControls
      ? structuredClone(config.grid.filterControls)
      : undefined;
    this.viewFilterControls.set(
      config.filterControls ? structuredClone(config.filterControls) : undefined,
    );
    this.chartPage.set(0);
    this.carouselChartId.set(config.chart?.id ?? null);
    this.bothChartCount.set(config.bothChartCount ?? 2);
    this.viewLayout.set(structuredClone(config.viewLayout ?? {}));
    this.focusedChartId.set(null);
    this.mode.set(config.mode);
    this.api.setGridOption('enableAdvancedFilter', config.mode === 'advanced');
    this.calculatedColumns.set(structuredClone(config.calculatedColumns ?? []));
    this.columnCategoryOverrides.set({ ...config.columnCategories });
    this.columnCategoryOrder.set(config.categoryOrder ?? []);
    this.columnHighlights.set({ ...config.columnHighlights });
    this.showRowNumbers.set(config.showRowNumbers ?? false);
    this.data.cache.setCalculatedColumns(this.dataSourceId(), this.calculatedColumns());
    this.rebuildColumnDefinitions();
    this.refreshServerGrid(this.api);
    this.api.setState(structuredClone(config.gridState));
    // Grid state omits flex for a fixed-width column. Explicitly clear the
    // editor's default flex so reopening/saving does not convert it to flex: 1.
    if (config.gridState.columnSizing?.columnSizingModel.length) {
      this.api.applyColumnState({
        state: config.gridState.columnSizing.columnSizingModel.map((column) => ({
          colId: column.colId,
          width: column.width,
          flex: column.flex ?? null,
        })),
      });
    }
    this.clearChartData();
    const tableScope = {
      mode: config.mode,
      filterModel:
        ((config.mode === 'advanced'
          ? config.gridState.filter?.advancedFilterModel
          : config.gridState.filter?.filterModel) as GridModel) ?? null,
    };
    this.savedCharts.set(
      viewCharts(config).map((chart) => ({
        ...structuredClone(chart),
        dataScope: structuredClone(chartDataScope(chart, tableScope)),
        data: null,
        loading: false,
        error: '',
        signature: '',
      })),
    );
    this.selectSavedChart(
      this.savedCharts().find((chart) => chart.id === config.chart?.id) ??
        this.savedCharts()[0] ??
        null,
    );
    this.resultView.set(
      !this.explorerContext.serverSideOnly && this.savedCharts().length
        ? (config.displayMode ?? 'chart')
        : 'grid',
    );
    this.updateCurrent();
    this.updateChart();
  }
  private filterInput(): HTMLInputElement | null {
    return this.host.nativeElement.querySelector('.advanced-filter-host input');
  }
  private nativeFilterApply(): HTMLButtonElement | null {
    return this.host.nativeElement.querySelector(
      '.advanced-filter-host .ag-filter-apply-panel-apply-button',
    );
  }
  private observeFilterInput(): void {
    this.filterInputObserver?.disconnect();
    this.filterHeaderObserver?.disconnect();
    const host = this.host.nativeElement.querySelector('.advanced-filter-host');
    if (!host) return;
    this.filterBaselinePending = true;
    this.filterInputObserver = new MutationObserver(() => this.scheduleFilterInputSync());
    this.filterInputObserver.observe(host, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['disabled'],
    });
    const header = this.host.nativeElement.querySelector('.results-header');
    if (header) {
      let previousWidth = -1;
      this.filterHeaderObserver = new ResizeObserver(([entry]) => {
        const width = entry?.contentRect.width ?? 0;
        if (width === previousWidth) return;
        previousWidth = width;
        if (width > 0) this.scheduleFilterInputSync();
      });
      this.filterHeaderObserver.observe(header);
    }
    void this.host.nativeElement.ownerDocument.fonts.ready.then(() => {
      if (!this.destroyed) this.scheduleFilterInputSync();
    });
    this.scheduleFilterInputSync();
  }
  scheduleFilterInputSync(): void {
    cancelAnimationFrame(this.filterInputSyncFrame);
    this.filterInputSyncFrame = requestAnimationFrame(() => {
      if (this.destroyed) return;
      const input = this.filterInput();
      if (!input) {
        this.filterExpressionDirty.set(false);
        this.filterCanApply.set(false);
        this.filterSearchWidth.set(300);
        return;
      }
      if (this.filterBaselinePending) {
        this.appliedFilterExpression = input.value;
        this.filterBaselinePending = false;
      }
      this.filterExpressionDirty.set(input.value.trim() !== this.appliedFilterExpression.trim());
      this.filterCanApply.set(this.nativeFilterApply()?.disabled === false);
      this.measureFilterSearch(input);
    });
  }
  private measureFilterSearch(input: HTMLInputElement): void {
    if (!this.isActiveExplorer()) return;
    const toolbar = input.closest<HTMLElement>('.filter-toolbar');
    if (!toolbar?.clientWidth || !input.clientWidth) return;
    const document = input.ownerDocument;
    this.filterMeasureContext ??= document.createElement('canvas').getContext('2d');
    const context = this.filterMeasureContext;
    if (!context) return;
    const style = getComputedStyle(input);
    const measure = (value: string, textStyle: CSSStyleDeclaration): number => {
      context.font = textStyle.font;
      return (
        context.measureText(value).width +
        Math.max(0, value.length - 1) * (parseFloat(textStyle.letterSpacing) || 0)
      );
    };
    const inputPadding = parseFloat(style.paddingLeft) + parseFloat(style.paddingRight);
    const textWidth = measure(input.value || input.placeholder, style);
    // Reserve Apply before it appears, so typing does not steal space from the
    // editor. Canvas measurement avoids inserting layout-measurement elements.
    const applySpace = toolbar.querySelector('.filter-apply-action') ? 0 : 46;
    const chrome = toolbar.offsetWidth - input.clientWidth + applySpace;
    this.filterSearchWidth.set(Math.ceil(textWidth + inputPadding + chrome + 24));

    cancelAnimationFrame(this.filterCaretFrame);
    if (document.activeElement !== input) return;
    this.filterCaretFrame = requestAnimationFrame(() => {
      if (this.destroyed || !this.isActiveExplorer() || document.activeElement !== input) return;
      // Run after Angular applies the new width. At the viewport limit, retain
      // ordinary input scrolling and keep the cursor visible after resizing.
      const available = input.clientWidth - inputPadding;
      const caret =
        input.selectionDirection === 'backward' ? input.selectionStart : input.selectionEnd;
      const caretWidth = measure(input.value.slice(0, caret ?? input.value.length), style);
      if (measure(input.value, style) <= available) input.scrollLeft = 0;
      else if (caretWidth < input.scrollLeft + 12) input.scrollLeft = Math.max(0, caretWidth - 12);
      else if (caretWidth > input.scrollLeft + available - 12)
        input.scrollLeft = Math.max(0, caretWidth - available + 12);
    });
  }
  startFilterSearch(): void {
    void this.builder();
  }
  onFilterSearchBlur(): void {
    setTimeout(() => {
      if (this.destroyed || this.filterExpressionDirty()) return;
      if (this.filterInput() !== this.host.nativeElement.ownerDocument.activeElement)
        this.filterExpressionOpen.set(false);
    });
  }
  onFilterSearchKeydown(event: KeyboardEvent): void {
    this.scheduleFilterInputSync();
    if (event.key !== 'Escape' || event.defaultPrevented) return;
    event.preventDefault();
    this.api?.setAdvancedFilterModel(this.api.getAdvancedFilterModel());
    this.filterBaselinePending = true;
    this.scheduleFilterInputSync();
    this.filterExpressionOpen.set(false);
    this.host.nativeElement
      .querySelector<HTMLButtonElement>('.filter-summary-action')
      ?.focus({ preventScroll: true });
  }
  applyFilterExpression(): void {
    if (this.actionsLocked() || this.busy()) return;
    const apply = this.nativeFilterApply();
    if (!apply || apply.disabled) return;
    apply.click();
    if (this.api?.getOpenedToolPanel() === EXPLORER_FILTER_PANEL) this.closeFilterPanel();
    this.filterExpressionOpen.set(false);
    this.host.nativeElement
      .querySelector<HTMLButtonElement>('.filter-summary-action')
      ?.focus({ preventScroll: true });
  }
  private refreshSchema(): void {
    const schema = primaryColumnToolkitSchema({
      columnDefs: this.columnDefs,
      defaultColDef: this.defaultColDef,
      columns: this.columns(),
      mode: this.mode(),
      setFiltersEnabled: this.setFiltersEnabled(),
    });
    if (!schema) throw new Error('The AG Grid AI Toolkit schema is unavailable. Reload the grid.');
    this.toolkitSchema = schema;
    this.schemaJson.set(JSON.stringify(schema, null, 2));
  }
  cancelServerGrid(): void {
    this.serverDatasource?.destroy?.();
    this.serverDatasource = undefined;
    this.serverInitialResolve?.();
    this.serverInitialResolve = undefined;
    if (this.streamState() === 'running') this.streamState.set('cancelled');
  }
  private publishRecordCount(): void {
    if (!this.destroyed) this.explorerContext.recordsChanged?.(this.headerRecordCount());
  }
  onModelUpdated(_force = false): void {
    const api = this.api;
    if (!api || api.isDestroyed()) return;
    this.revealPendingAggregate();
    let loaded = 0;
    api.forEachNode((node) => {
      if (node.data && !node.stub) loaded++;
    });
    this.cachedRowCount.set(loaded);
    this.publishRecordCount();
    if (this.streamState() !== 'completed') return;
    this.updateDashboard();
    this.updateChart();
  }
  private refreshServerGrid(api: GridApi): void {
    this.data.cache.setCalculatedColumns(this.dataSourceId(), this.calculatedColumns());
    if (this.serverDatasource && !api.isDestroyed()) api.refreshServerSide({ purge: true });
  }
  /** Only the mock executor can inspect all fixture rows. AG Grid receives bounded blocks. */
  async startServerGrid(): Promise<void> {
    const api = this.api;
    if (!api || api.isDestroyed() || !this.ready()) return;
    this.cancelServerGrid();
    const source = this.dataSourceId();
    this.data.cache.setCalculatedColumns(source, this.calculatedColumns());
    this.streamState.set('running');
    this.streamError.set('');
    this.rowError.set('');
    this.lastStudioQuery = undefined;
    const startedAt = performance.now();
    const firstBlock = new Promise<void>((resolve) => {
      this.serverInitialResolve = resolve;
    });
    const executor =
      (source.startsWith('local_') ? null : this.queryExecutor) ??
      new MockStudioQueryExecutor(() => ({
        rows: (this.data.cache.getGridRows(source) ?? []) as readonly AnalyticsSourceRow[],
        columns: this.columns(),
        rowIdColumn: this.source().sqlDataset.rowIdColumn,
      }));
    this.serverDatasource = createStudioDatasource({
      context: () => {
        this.data.cache.setCalculatedColumns(source, this.calculatedColumns());
        return {
          sourceId: this.explorerContext.modelDefinition?.sourceKey ?? this.source().id,
          mode: this.mode(),
          tenant: this.tenant,
          dataset: this.source().sqlDataset,
          definitions: this.calculatedColumns(),
        };
      },
      executor,
      loading: (pending) => {
        if (!this.destroyed) this.serverPending.set(pending);
      },
      compiled: (query) => {
        this.lastStudioQuery = query;
        this.updateSql();
      },
      loaded: (_query, result) => {
        if (this.destroyed || api.isDestroyed()) return;
        this.rowCount.set(result.matchedRowCount);
        this.streamProgress.set({
          ...emptyStreamProgress(),
          totalRows: result.totalRowCount,
          receivedRows: result.rowData.length,
        });
        this.streamState.set('completed');
        this.streamError.set('');
        this.rowError.set('');
        this.loadingElapsedMs.set(Math.round(performance.now() - startedAt));
        this.serverInitialResolve?.();
        this.serverInitialResolve = undefined;
        this.onModelUpdated(true);
      },
      error: (error) => {
        this.streamError.set(error.message);
        this.rowError.set(error.message);
        // Keep controls available so invalid group/pivot/filter choices can be corrected.
        this.streamState.set('completed');
        this.sqlError.set(error.message);
        this.serverInitialResolve?.();
        this.serverInitialResolve = undefined;
      },
    });
    api.setGridOption('serverSideDatasource', this.serverDatasource);
    await firstBlock;
  }
  onFilterChanged(): void {
    const previous = this.appliedFilterKey;
    this.appliedFilterKey = JSON.stringify(this.model());
    this.onGridStateChanged();
    this.filterBaselinePending = true;
    this.scheduleFilterInputSync();
    if (previous !== this.appliedFilterKey && this.ready() && !this.dataLoading()) {
      const wasSearching = this.filterExpressionOpen();
      const restoreSearchFocus =
        wasSearching && this.filterInput() === this.host.nativeElement.ownerDocument.activeElement;
      this.filterExpressionOpen.set(false);
      if (wasSearching && this.api?.getOpenedToolPanel() === EXPLORER_FILTER_PANEL)
        this.closeFilterPanel();
      if (restoreSearchFocus)
        this.host.nativeElement
          .querySelector<HTMLButtonElement>('.filter-summary-action')
          ?.focus({ preventScroll: true });
      clearTimeout(this.filterApplyTimer);
      this.filtersApplied.set(true);
      const count = this.activeFilterCount();
      this.filterApplyStatus.set(
        count
          ? count + (count === 1 ? ' filter applied' : ' filters applied')
          : 'Filters cleared. Showing all records.',
      );
      this.filterApplyTimer = setTimeout(() => this.filtersApplied.set(false), 450);
    }
  }
  private readonly onGridStateUpdated = (event: StateUpdatedEvent): void => {
    this.workspaceRevision.update((value) => value + 1);
    // Scrolling, focus, selection and column sizing do not change the data query.
    // Listen outside the template so these events also avoid marking its view dirty.
    if (
      event.sources.some((source) =>
        ['filter', 'sort', 'rowGroup', 'pivot', 'aggregation', 'api'].includes(source),
      )
    )
      this.onGridStateChanged();
  };
  onGridStateChanged(): void {
    if (!this.api || this.api.isDestroyed()) return;
    const next = this.currentQueryKey();
    if (next === this.signature) return;
    if (next !== this.signature) {
      this.signature = next;
      this.invalidate();
      this.clearChartData();
      this.dashboardRequest?.abort();
      this.dashboardData.set(null);
      this.dashboardBusy.set(false);
      this.dashboardError.set('');
      this.dashboardSignature = '';
      this.updateCurrent();
    }
    this.onModelUpdated(true);
  }
  private currentQueryKey(): string {
    const displaySort = (this.api?.getAllGridColumns() ?? [])
      .filter((c) => c.getSort())
      .sort((a, b) => (a.getSortIndex() ?? 0) - (b.getSortIndex() ?? 0))
      .map((c) => ({ colId: c.getColId(), sort: c.getSort() }));
    return (
      this.dataSourceId() +
      this.mode() +
      JSON.stringify(this.currentGridState()) +
      JSON.stringify(displaySort) +
      JSON.stringify(this.calculatedColumnIds())
    );
  }
  private currentGridState(): Record<string, unknown> {
    // Pivot result columns are presentation fields, not source schema columns.
    // Native result-column sorting is kept when the reviewed proposal ignores sort.
    const sourceIds = new Set(this.columns().map((column) => column.id));
    const columns = (this.api?.getColumnState() ?? []).filter(
      (column) => sourceIds.has(column.colId) || column.colId === 'ag-Grid-AutoColumn',
    );
    return {
      filter:
        this.mode() === 'advanced'
          ? { advancedFilterModel: this.model() }
          : { filterModel: this.model() },
      sort: {
        sortModel: columns
          .filter((c) => c.sort)
          .sort((a, b) => (a.sortIndex ?? 0) - (b.sortIndex ?? 0))
          .map((c) => ({ colId: c.colId, sort: c.sort })),
      },
      rowGroup: { groupColIds: this.api?.getRowGroupColumns().map((c) => c.getColId()) ?? [] },
      pivot: {
        pivotMode: this.api?.isPivotMode() ?? false,
        pivotColIds: this.api?.getPivotColumns().map((c) => c.getColId()) ?? [],
      },
      aggregation: {
        aggregationModel: columns
          .filter((c) => c.aggFunc)
          .map((c) => ({
            colId: c.colId,
            aggFunc: c.aggFunc,
          })),
      },
    };
  }
  onSortChanged(): void {
    this.onGridStateChanged();
  }
  private model(): GridModel {
    return (
      this.mode() === 'advanced'
        ? (this.api?.getAdvancedFilterModel() ?? null)
        : (this.api?.getFilterModel() ?? {})
    ) as GridModel;
  }
  private updateCurrent(): void {
    const model = this.model();
    this.currentJson.set(JSON.stringify(model, null, 2));
    const state = this.currentGridState();
    this.stateJson.set(JSON.stringify(state, null, 2));
    this.activeFeatures.set(this.describeGridState(state).slice(1));
    this.analyticsActive.set(
      !!(
        this.api?.getRowGroupColumns().length ||
        this.api?.getValueColumns().length ||
        this.api?.getPivotColumns().length ||
        this.api?.isPivotMode()
      ),
    );
    this.data.cache.setCalculatedColumns(this.dataSourceId(), this.calculatedColumns());
    this.updateSql();
    try {
      const ast = fromModel(model, this.mode(), this.columns());
      this.current.set(ast ? expression(ast, true, this.columns()) : this.allRecordsLabel());
    } catch {
      this.current.set(
        'The current filter is unsupported by the server. Clear it or revise the expression.',
      );
    }
  }
  private updateSql(): void {
    const query = this.lastStudioQuery;
    if (!query) return;
    this.sqlBusy.set(false);
    this.sqlError.set('');
    this.sqlJson.set(query.rows.sql);
    this.bindsJson.set(JSON.stringify(query.rows.binds, null, 2));
    this.countSql.set(query.count.sql);
  }
  setResultView(view: 'grid' | 'sql' | 'dashboard' | 'chart' | 'both'): void {
    if (this.actionsLocked()) return;
    if (view === 'dashboard' && !this.dashboardsEnabled()) return;
    if ((view === 'chart' || view === 'both') && !this.chartsEnabled()) return;
    this.resultView.set(view);
    if (view === 'sql') this.updateSql();
    if (view === 'dashboard') this.updateDashboard();
    if (view === 'chart' || view === 'both') this.updateChart();
  }
  private savedDisplayMode(): 'grid' | 'chart' | 'both' {
    if (this.explorerContext.serverSideOnly) return this.configuredDisplayMode();
    const view = this.resultView();
    return view === 'chart' || view === 'both' ? view : 'grid';
  }
  onResultTabKeydown(event: KeyboardEvent): void {
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    const tablist = event.currentTarget as HTMLElement;
    const tabs = Array.from(
      tablist.querySelectorAll<HTMLButtonElement>('[role="tab"]:not(:disabled)'),
    );
    const index = tabs.indexOf(event.target as HTMLButtonElement);
    if (index < 0) return;
    event.preventDefault();
    const next =
      event.key === 'Home'
        ? 0
        : event.key === 'End'
          ? tabs.length - 1
          : (index + (event.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length;
    tabs[next].focus();
    tabs[next].click();
  }
  chooseDashboard(template: DashboardTemplate): void {
    if (this.actionsLocked()) return;
    this.dashboardPlan.set({ template, period: template === 'financial' ? '2026Q3' : null });
    this.updateDashboard();
  }
  chooseDashboardPeriod(period: string): void {
    if (this.actionsLocked()) return;
    this.dashboardPlan.set({ template: 'financial', period });
    this.updateDashboard();
  }
  private updateDashboard(): void {
    if (
      this.resultView() !== 'dashboard' ||
      this.streamState() !== 'completed' ||
      !this.dashboardsEnabled() ||
      !this.ready() ||
      this.rowCount() === null ||
      !this.api ||
      this.api.isDestroyed()
    )
      return;
    const plan = this.dashboardPlan();
    const body = {
      template: plan.template,
      ...(plan.period ? { period: plan.period } : {}),
      mode: this.mode(),
      filterModel: this.model(),
      calculatedColumnIds: this.calculatedColumnIds(),
    };
    const signature = JSON.stringify(body);
    if (signature === this.dashboardSignature) return;
    this.dashboardSignature = signature;
    this.dashboardRequest?.abort();
    const controller = new AbortController();
    this.dashboardRequest = controller;
    this.dashboardData.set(null);
    this.dashboardError.set('');
    this.dashboardBusy.set(true);
    void this.data
      .request<DashboardResponse>('analytics/dashboard', body, controller.signal)
      .then((data) => {
        if (!controller.signal.aborted && signature === this.dashboardSignature)
          this.dashboardData.set(data);
      })
      .catch((error: Error) => {
        if (controller.signal.aborted || signature !== this.dashboardSignature) return;
        this.dashboardError.set(error.message);
        this.dashboardSignature = '';
      })
      .finally(() => {
        if (!controller.signal.aborted) this.dashboardBusy.set(false);
      });
  }
  private clearChartData(): void {
    for (const controller of this.savedChartRequests.values()) controller.abort();
    this.savedChartRequests.clear();
    this.savedCharts.update((charts) =>
      charts.map((chart) => ({ ...chart, data: null, loading: false, error: '', signature: '' })),
    );
    this.chartData.set(null);
  }
  startChartGuide(): void {
    this.continueExploration('chart');
  }
  private openContextualChartHelp(
    message = 'Choose a chart type, then its fields. Your current filters and calculated columns are available in the builder.',
  ): void {
    const draft = this.gridResult();
    const builder = this.chartGuideOpen() ? this.builderDraft() : null;
    const filter = builder
      ? this.builderFilter(builder)
      : draft?.status === 'proposal'
        ? this.proposedFilterModel(draft.gridState)
        : this.chartEditingFilter();
    const draftId = draft?.status === 'proposal' ? draft.id : this.draftBaseId;
    this.finishActive('answered');
    this.pendingIntent = undefined;
    this.lastInterpretation = undefined;
    this.retryConversation = undefined;
    this.retryText.set(null);
    this.error.set('');
    this.hints.set([]);
    if (!builder) {
      this.editingChartId ??= this.followUpChartId;
      this.resetBuilder();
    }
    // An open builder already combines its own conditions with this base. Keep
    // that base intact instead of adding its conditions a second time.
    if (!builder) this.guidedBaseFilter = structuredClone(filter);
    this.guidedBaseCaptured = true;
    this.guidedBaseDraftId = draftId;
    this.draftBaseId = draftId;
    this.requestScope.set('current');
    this.continuingView.set(true);
    this.workflowIntent.set('chart');
    this.chartGuideError.set('');
    this.chartGuideOpen.set(true);
    this.notice.set(message);
    this.gridResult.set(draft?.status === 'proposal' ? draft : null);
    this.addMessage({ role: 'assistant', text: message, status: 'answered' });
    this.openAssistant();
    this.focusChartGuide();
  }
  chooseWorkflow(intent: WorkflowIntent): void {
    if (this.busy() || this.actionsLocked()) return;
    if (intent === 'chart') {
      this.editingChartId = null;
      this.resetBuilder();
      this.requestScope.set('current');
      this.continuingView.set(true);
    }
    this.workflowIntent.set(intent);
    this.chartGuideOpen.set(intent === 'chart');
    this.chartGuideError.set('');
    this.openAssistant();
    if (intent === 'chart') this.focusChartGuide();
  }
  addNewChart(): void {
    if (this.busy() || this.actionsLocked() || !this.chartsEnabled()) return;
    this.invalidate();
    this.editingChartId = null;
    this.resetBuilder();
    this.requestScope.set('current');
    this.continuingView.set(true);
    this.workflowIntent.set('chart');
    this.chartGuideOpen.set(true);
    this.openAssistant();
    this.focusChartGuide();
  }
  cancelChartEditing(): void {
    if (this.busy() || this.actionsLocked()) return;
    this.invalidate();
    this.editingChartId = null;
    this.resetBuilder();
    this.notice.set('Chart changes discarded.');
  }
  continueExploration(intent: WorkflowIntent = this.workflowIntent()): void {
    if (this.busy() || this.actionsLocked()) return;
    // An unapplied filter proposal is the data source for the next chart, not the grid behind it.
    if (!this.draftBaseId) this.invalidate();
    this.requestScope.set('current');
    this.continuingView.set(true);
    this.workflowIntent.set(intent);
    this.chartGuideOpen.set(intent === 'chart');
    this.chartGuideError.set('');
    this.text.set('');
    this.notice.set(
      intent === 'chart'
        ? 'Describe the comparison or trend to chart. The selected filters will be retained.'
        : 'Describe what to change. The current filters will be retained unless you ask to replace them.',
    );
    this.openAssistant();
    if (intent === 'chart') this.focusChartGuide();
  }
  toggleChartGuide(): void {
    if (this.busy() || this.actionsLocked()) return;
    this.chartGuideOpen.update((open) => !open);
    if (this.chartGuideOpen()) this.focusChartGuide();
  }
  openChartBuilder(): void {
    if (this.busy() || this.actionsLocked() || !this.chartsEnabled()) return;
    if (this.workflowIntent() === 'chart' && this.builderDraft()) {
      this.chartGuideOpen.set(true);
      this.focusChartGuide();
    } else this.chooseWorkflow('chart');
  }
  backToChat(): void {
    this.chartGuideOpen.set(false);
    this.focusComposer();
  }
  toggleBuilderAi(): void {
    if (this.busy() || this.actionsLocked()) return;
    this.builderAiOpen.update((open) => !open);
    if (this.builderAiOpen()) this.focusComposer();
    else this.focusChartGuide();
  }
  private resetBuilder(): void {
    this.builderAiOpen.set(false);
    this.builderResetToken.update((value) => value + 1);
    this.builderPreviewController?.abort();
    clearTimeout(this.builderPreviewTimer);
    ++this.builderPreviewRevision;
    this.builderDraft.set(null);
    this.builderEditorMode.set('new');
    this.builderBaseline.set(null);
    this.builderReadySnapshot.set(null);
    this.builderInitialPlan.set(null);
    this.builderInitialFilterControls.set(undefined);
    this.builderDescription.set('');
    this.builderDescriptionBaseline.set('');
    this.builderPresentation.set(null);
    this.builderPresentationBaseline.set(null);
    this.builderInitialFilters.set([]);
    this.builderDataFilter.set(null);
    this.builderLiveData.set(null);
    this.builderLiveBusy.set(false);
    this.builderLiveError.set('');
    this.builderSuggestions.set([]);
  }
  private builderFilter(selection: ChartGuideSubmission): GridModel {
    if (!this.guidedBaseCaptured) {
      const draft = this.gridResult();
      this.guidedBaseFilter =
        draft?.status === 'proposal'
          ? this.proposedFilterModel(draft.gridState)
          : this.requestScope() === 'current'
            ? this.chartEditingFilter()
            : null;
      this.guidedBaseDraftId = draft?.status === 'proposal' ? draft.id : undefined;
      this.guidedBaseCaptured = true;
    }
    const existing = fromModel(this.guidedBaseFilter, this.mode(), this.columns());
    const conditions = [...(existing ? [existing] : []), ...selection.filters];
    return toModel(
      conditions.length ? group('AND', conditions) : null,
      this.mode(),
      this.columns(),
      this.setFiltersEnabled(),
    );
  }
  private builderDraftKey(draft: ChartGuideDraft): string {
    return JSON.stringify({
      chart: chartEditorKey(draft.plan, draft.filters),
      filter: this.builderDataFilter(),
      filterControls: draft.filterControls,
    });
  }
  private builderPresentationKey(presentation: ChartPresentation | null): string {
    return JSON.stringify(
      presentation
        ? { signature: presentation.signature, options: presentation.model.chartOptions }
        : null,
    );
  }
  private matchingBuilderPresentation(): ChartPresentation | null {
    const presentation = this.builderPresentation();
    const data = this.builderLiveData();
    if (!presentation || !data) return null;
    const signature = JSON.stringify({
      type: data.type,
      columns: data.columns,
      seriesChartTypes: data.seriesChartTypes ?? null,
    });
    return presentation.signature === signature ? presentation : null;
  }
  onBuilderPresentation(presentation: ChartPresentation): void {
    const draft = this.builderDraft();
    const data = this.builderLiveData();
    if (!draft?.valid || draft.stage === 'gallery' || !data || this.builderLiveBusy()) return;
    const signature = JSON.stringify({
      type: data.type,
      columns: data.columns,
      seriesChartTypes: data.seriesChartTypes ?? null,
    });
    if (
      presentation.signature !== signature ||
      presentation.requestedTitle !== data.title ||
      JSON.stringify(presentation.requestedAppearance) !== JSON.stringify(data.appearance ?? null)
    )
      return;
    this.builderPresentation.set(structuredClone(presentation));
    if (this.builderPresentationBaseline() === null)
      this.builderPresentationBaseline.set(this.builderPresentationKey(presentation));
  }
  editBuilderFilter(model: AdvancedFilterModel | null): void {
    if (this.busy() || this.actionsLocked()) return;
    try {
      const node = fromModel(model, 'advanced', this.columns());
      // Validate before replacing the complete draft filter, including inherited conditions.
      toModel(node, this.mode(), this.columns(), this.setFiltersEnabled());
      this.guidedBaseFilter = null;
      this.guidedBaseCaptured = true;
      this.builderReadySnapshot.set(null);
      this.builderInitialFilters.set(node ? [node] : []);
      this.chartGuideError.set('');
    } catch (error) {
      this.chartGuideError.set((error as Error).message);
    }
  }
  editBuilderDescription(description: string): void {
    if (!this.busy() && !this.actionsLocked())
      this.builderDescription.set(description.slice(0, 1000));
  }
  askBuilderFilterAi(draft: ChartGuideDraft): void {
    if (this.busy() || this.actionsLocked()) return;
    this.builderAiOpen.set(true);
    this.builderDraft.set(draft);
    this.workflowIntent.set('chart');
    this.chartGuideOpen.set(true);
    if (!this.text().trim())
      this.text.set('Keep this chart configuration and help me filter its records. ');
    this.focusComposer();
  }
  onBuilderDraft(draft: ChartGuideDraft): void {
    this.builderDraft.set(draft);
    let filterError = '';
    try {
      this.builderDataFilter.set(
        toModel(
          fromModel(this.builderFilter(draft), this.mode(), this.columns()),
          'advanced',
          this.columns(),
        ) as AdvancedFilterModel | null,
      );
    } catch (error) {
      filterError = (error as Error).message;
    }
    const key = this.builderDraftKey(draft);
    if (
      this.builderEditorMode() === 'edit' &&
      this.builderBaseline() === null &&
      draft.stage !== 'gallery'
    )
      this.builderBaseline.set(key);
    const previous = this.builderReadySnapshot();
    if (
      draft.valid &&
      !filterError &&
      previous?.key === key &&
      previous.queryKey === this.currentQueryKey()
    )
      return;
    this.builderPreviewController?.abort();
    clearTimeout(this.builderPreviewTimer);
    const revision = ++this.builderPreviewRevision;
    this.builderReadySnapshot.set(null);
    if (draft.stage === 'gallery') this.builderLiveData.set(null);
    this.builderLiveError.set(
      filterError || (draft.stage !== 'gallery' && !draft.valid ? draft.validationMessage : ''),
    );
    this.builderLiveBusy.set(false);
    if (
      !draft.valid ||
      filterError ||
      draft.stage === 'gallery' ||
      this.streamState() !== 'completed'
    )
      return;
    this.builderLiveBusy.set(true);
    this.builderPreviewTimer = setTimeout(() => {
      const controller = new AbortController();
      this.builderPreviewController = controller;
      const queryKey = this.currentQueryKey();
      const source = this.dataSourceId();
      let request: ChartRequest;
      void Promise.resolve()
        .then(() => {
          request = {
            plan: draft.plan,
            mode: this.mode(),
            filterModel: this.builderFilter(draft),
            calculatedColumnIds: this.calculatedColumnIds(),
          };
          return this.data.request<ChartResponse>('analytics/chart', request, controller.signal);
        })
        .then((data) => {
          if (!controller.signal.aborted && revision === this.builderPreviewRevision) {
            this.builderLiveData.set(data);
            this.builderReadySnapshot.set({ key, request, queryKey, source });
          }
        })
        .catch((error: Error) => {
          if (!controller.signal.aborted && revision === this.builderPreviewRevision)
            this.builderLiveError.set(error.message);
        })
        .finally(() => {
          if (!controller.signal.aborted && revision === this.builderPreviewRevision)
            this.builderLiveBusy.set(false);
        });
    }, 100);
  }
  async applyBuilderDraft(): Promise<void> {
    if (this.actionsLocked()) return;
    const snapshot = this.builderReadySnapshot();
    if (!this.builderCanApply() || !snapshot || snapshot.queryKey !== this.currentQueryKey())
      return;
    const revision = this.revision;
    const editingId = this.editingChartId ?? this.followUpChartId;
    // Descriptions are local chart metadata, never part of a plan or model request.
    const description = this.builderDescription();
    const filterControls = structuredClone(this.builderDraft()?.filterControls);
    const state = this.currentGridState();
    const controller = new AbortController();
    this.request = controller;
    this.busy.set(true);
    this.busyLabel.set(editingId ? 'Saving chart changes' : 'Adding your chart');
    this.chartGuideError.set('');
    try {
      // The form has already previewed these exact values locally. Validate and
      // confirm the same plan without another interpretation or model request.
      const proposal = await this.data.proposeChart(
        {
          ...snapshot.request,
          currentState: state,
          requestScope: this.requestScope(),
          ...(this.draftBaseId ? { draftId: this.draftBaseId } : {}),
        },
        controller.signal,
      );
      if (revision !== this.revision || controller.signal.aborted) return;
      if (proposal.status !== 'proposal' || !proposal.chart) {
        this.chartGuideError.set(
          proposal.status === 'proposal' ? 'Choose a chart to save.' : proposal.message,
        );
        return;
      }
      const confirmed = await this.data.confirmGrid(
        proposal.id,
        this.mode(),
        state,
        this.calculatedColumnIds(),
        controller.signal,
      );
      if (
        revision !== this.revision ||
        controller.signal.aborted ||
        !this.api ||
        this.api.isDestroyed()
      )
        return;
      if (
        snapshot.queryKey !== this.currentQueryKey() ||
        snapshot.source !== this.dataSourceId() ||
        editingId !== (this.editingChartId ?? this.followUpChartId) ||
        !this.builderDraft()?.valid ||
        snapshot.key !== this.builderDraftKey(this.builderDraft()!)
      ) {
        this.chartGuideError.set(
          'The data or chart changed. Review the latest preview before saving.',
        );
        return;
      }
      // Keep native formatting for this exact chart layout. The renderer compares
      // requestedTitle/Appearance, so explicit form edits still override older options.
      this.chartPreviewPresentation.set(this.matchingBuilderPresentation());
      const generation = this.gridResult();
      this.applyConfirmedView(confirmed, {
        description,
        filterControls,
        ...(generation?.status === 'proposal' && generation.chart
          ? { generationResponse: structuredClone(generation) }
          : {}),
      });
      this.finishActive('applied');
      this.gridResult.set(null);
      this.draftBaseId = undefined;
      this.draftChart = undefined;
      this.chartPreviewRequest.set(null);
      this.chartPreviewExchange.set(null);
      this.chartGuideOpen.set(false);
      this.text.set('');
      this.notice.set(editingId ? 'Chart updated.' : 'Chart added.');
      if (this.assistantMobile()) this.closeAssistant();
    } catch (error) {
      if (revision === this.revision && (error as Error).name !== 'AbortError')
        this.chartGuideError.set(
          error instanceof Error ? error.message : 'Could not save this chart. Please try again.',
        );
    } finally {
      if (revision === this.revision) this.busy.set(false);
    }
  }
  askBuilderAi(draft: ChartGuideDraft): void {
    if (this.busy() || this.actionsLocked()) return;
    this.builderAiOpen.set(true);
    this.builderDraft.set(draft);
    this.workflowIntent.set('chart');
    this.chartGuideOpen.set(true);
    if (!this.text().trim())
      this.text.set(
        'Help me improve this chart. Suggest suitable fields and a clear configuration.',
      );
    this.focusComposer();
  }
  loadBuilderSuggestion(suggestion: { plan: ChartPlan; filters: Node[] }): void {
    if (this.busy() || this.actionsLocked()) return;
    // Suggested filters become the builder's explicit conditions, not an applied grid change.
    this.guidedBaseFilter = null;
    this.guidedBaseCaptured = true;
    this.guidedBaseDraftId = this.draftBaseId;
    this.builderInitialFilters.set(structuredClone(suggestion.filters));
    this.builderInitialPlan.set(structuredClone(suggestion.plan));
    this.workflowIntent.set('chart');
    this.chartGuideOpen.set(true);
    this.focusChartGuide();
  }
  private offerBuilderSuggestions(result: GridCopilotResult): void {
    if (result.status !== 'proposal' || !result.chart) return;
    const plan = result.chart;
    const filter = fromModel(
      this.proposedFilterModel(result.gridState),
      this.mode(),
      this.columns(),
    );
    const filters = filter ? [filter] : [];
    const family = CHART_DEMO_VARIANTS.find(
      (variant) => variant.id === normalizeChartDemoType(plan.type),
    )?.family;
    const options = [{ label: plan.title || 'Suggested chart', plan, filters }];
    const alternatives = CHART_DEMO_VARIANTS.filter(
      (variant) =>
        (variant.family === family ||
          (['Column', 'Bar'].includes(family ?? '') &&
            ['groupedColumn', 'groupedBar'].includes(variant.id))) &&
        variant.id !== normalizeChartDemoType(plan.type),
    );
    for (const variant of alternatives) {
      const alternate = {
        ...plan,
        type: variant.id,
        title: `${plan.title || 'Chart'} — ${variant.label}`,
      };
      const missingMeasure = chartGuideRoles(alternate).some(
        (role) => role.kind === 'measure' && !alternate.measureColumnIds[role.slot ?? 0],
      );
      if (!missingMeasure && !guidePlanError(alternate, this.columns()))
        options.push({ label: `Same values: ${variant.label}`, plan: alternate, filters });
      if (options.length === 3) break;
    }
    this.builderSuggestions.set(options);
  }
  private focusChartGuide(): void {
    setTimeout(() => {
      if (this.isActiveExplorer())
        this.host.nativeElement
          .querySelector<HTMLElement>(
            '.chart-guide-container:not([hidden]) .step-button[aria-current="step"]',
          )
          ?.focus({ preventScroll: true });
    }, 0);
  }
  private revealBuilderHelp(): void {
    afterNextRender(
      () => {
        if (this.chartGuideOpen() && this.isActiveExplorer())
          this.host.nativeElement
            .querySelector<HTMLElement>('.chart-guide-container .guide-scroll')
            ?.scrollTo({ top: 0 });
      },
      { injector: this.injector },
    );
  }
  async previewGuidedChart(selection: ChartGuideSubmission): Promise<void> {
    if (!this.ready() || this.streamState() !== 'completed' || this.busy()) return;
    const draft = this.gridResult();
    const draftId = draft?.status === 'proposal' ? draft.id : this.draftBaseId;
    if (!this.guidedBaseCaptured || draftId !== this.guidedBaseDraftId) {
      this.guidedBaseFilter =
        draft?.status === 'proposal'
          ? this.proposedFilterModel(draft.gridState)
          : this.requestScope() === 'current'
            ? this.chartEditingFilter()
            : null;
      this.guidedBaseDraftId = draftId;
      this.guidedBaseCaptured = true;
    }
    const revision = this.revision;
    const controller = new AbortController();
    this.request = controller;
    this.busy.set(true);
    this.busyLabel.set('Checking the data and chart options');
    this.chartGuideError.set('');
    try {
      const existing = fromModel(this.guidedBaseFilter, this.mode(), this.columns());
      const conditions = [...(existing ? [existing] : []), ...selection.filters];
      const predicate = conditions.length ? group('AND', conditions) : null;
      const result = await this.data.proposeChart(
        {
          plan: selection.plan,
          mode: this.mode(),
          currentState: this.currentGridState(),
          filterModel: toModel(predicate, this.mode(), this.columns(), this.setFiltersEnabled()),
          requestScope: this.requestScope(),
          ...(this.draftBaseId ? { draftId: this.draftBaseId } : {}),
          calculatedColumnIds: this.calculatedColumnIds(),
        },
        controller.signal,
      );
      if (revision !== this.revision) return;
      if (result.status !== 'proposal') {
        this.chartGuideError.set(result.message);
        return;
      }
      this.finishActive('superseded');
      this.proposedRowCount.set(null);
      this.chartPreviewExchange.set(null);
      this.chartPreviewPresentation.set(null);
      this.chartPreviewRequest.set(null);
      this.addMessage({ role: 'user', text: `Preview ${selection.plan.title}` });
      this.receiveGridResult(result);
      this.guidedBaseDraftId = result.id;
      this.chartGuideOpen.set(false);
      this.text.set('');
      this.scrollChat();
    } catch (error) {
      if (revision === this.revision && (error as Error).name !== 'AbortError') {
        this.chartGuideError.set(
          error instanceof Error
            ? error.message
            : 'Could not prepare this chart. Adjust the options and try again.',
        );
        const code = (error as { code?: string }).code;
        if (code === 'EXPIRED_PROPOSAL' || code === 'STALE_STATE') {
          this.invalidate();
          this.chartGuideOpen.set(true);
          this.chartGuideError.set(
            'The earlier preview expired or the grid changed. Review the data scope and preview again.',
          );
        }
      }
    } finally {
      if (revision === this.revision) this.busy.set(false);
    }
  }
  workflowContext(): string {
    if (this.draftBaseId) return 'Using the proposed data; the grid has not changed.';
    return this.requestScope() === 'current'
      ? 'Using the current grid results and filters.'
      : 'New request using all data. Review before replacing the current view.';
  }
  draftBaseLabel(): string {
    return this.draftBaseId
      ? 'Proposed data'
      : this.continuingView()
        ? 'Current results'
        : 'All data';
  }
  private updateChart(): void {
    if (!['chart', 'both'].includes(this.resultView()) || this.streamState() !== 'completed')
      return;
    if (
      !this.chartsEnabled() ||
      !this.ready() ||
      this.rowCount() === null ||
      !this.api ||
      this.api.isDestroyed()
    )
      return;
    for (const chart of this.savedCharts()) {
      const body: ChartRequest = {
        plan: chart.plan,
        ...chartDataScope(chart, { mode: this.mode(), filterModel: this.model() }),
        calculatedColumnIds: this.calculatedColumnIds(),
      };
      const signature = JSON.stringify(body);
      if (signature === chart.signature) continue;
      this.savedChartRequests.get(chart.id)?.abort();
      const controller = new AbortController();
      this.savedChartRequests.set(chart.id, controller);
      this.patchSavedChart(chart.id, { signature, data: null, error: '', loading: true });
      void this.data
        .request<ChartResponse>('analytics/chart', body, controller.signal)
        .then((data) => {
          if (!controller.signal.aborted && this.savedChartRequests.get(chart.id) === controller) {
            this.patchSavedChart(chart.id, { data });
            if (this.selectedChartId === chart.id) {
              this.chartData.set(data);
            }
          }
        })
        .catch((error: Error) => {
          if (!controller.signal.aborted) this.patchSavedChart(chart.id, { error: error.message });
        })
        .finally(() => {
          if (!controller.signal.aborted && this.savedChartRequests.get(chart.id) === controller) {
            this.patchSavedChart(chart.id, { loading: false });
            this.savedChartRequests.delete(chart.id);
          }
        });
    }
  }
  private patchSavedChart(id: string, patch: Partial<SavedChartState>): void {
    this.savedCharts.update((charts) =>
      charts.map((chart) => (chart.id === id ? { ...chart, ...patch } : chart)),
    );
  }
  saveChartPresentation(id: string, presentation: ChartPresentation): void {
    this.patchSavedChart(id, { presentation });
    if (id === this.selectedChartId) this.chartPresentation.set(presentation);
  }
  toggleChartSize(id: string): void {
    const chart = this.savedCharts().find((item) => item.id === id);
    if (!chart || this.actionsLocked() || this.busy()) return;
    this.patchSavedChart(id, { size: chart.size === 'wide' ? 'standard' : 'wide' });
  }
  chartScope(chart: SavedChartItem): ViewChartDataScope {
    return chartDataScope(chart, { mode: this.mode(), filterModel: this.model() });
  }
  saveChartFilters(id: string, scope: ViewChartDataScope): void {
    if (this.actionsLocked() || this.busy()) return;
    this.patchSavedChart(id, { dataScope: structuredClone(scope), signature: '' });
    this.updateChart();
  }
  retrySavedChart(id: string): void {
    if (this.actionsLocked() || this.busy()) return;
    this.patchSavedChart(id, { signature: '' });
    this.updateChart();
  }
  /** Table and chart filters side by side, with bulk actions over every chart. */
  async openFiltersOverview(): Promise<void> {
    if (this.actionsLocked()) return;
    const { FiltersOverviewDialogComponent, describeReaderAccess } = await import(
      '../rendering/filters-overview-dialog.component'
    );
    const overview = computed(() => {
      this.currentJson();
      this.workspaceRevision();
      const viewControls = this.viewFilterControls();
      const tableScope = { mode: this.mode(), filterModel: structuredClone(this.model()) };
      return {
        columns: this.columns(),
        locked: this.actionsLocked() || this.busy(),
        table: {
          id: 'table',
          title: 'Table',
          preview: this.filterPreviewSource(),
          scope: tableScope,
          independent: true,
          readers: describeReaderAccess(this.gridFilterControls, viewControls),
        },
        charts: this.savedCharts().map((chart) => ({
          id: chart.id,
          title: chart.plan.title,
          preview: this.filterPreviewSource(chart),
          chartType: chart.plan.type,
          scope: chartDataScope(chart, tableScope),
          independent: !!chart.dataScope,
          readers: describeReaderAccess(chart.filterControls, viewControls),
        })),
      };
    });
    this.dialog.open(FiltersOverviewDialogComponent, {
      width: '760px',
      maxWidth: 'calc(100vw - 24px)',
      data: {
        overview,
        setTableScope: (scope: ViewChartDataScope) => {
          const error = this.applyFilterBuilder(
            toModel(
              fromModel(scope.filterModel, scope.mode, this.columns()),
              'advanced',
              this.columns(),
              this.setFiltersEnabled(),
            ) as AdvancedFilterModel | null,
          );
          if (error) this.showError(new Error(error));
        },
        setChartScope: (id: string, scope: ViewChartDataScope) => this.saveChartFilters(id, scope),
        applyTableToAll: () => {
          const scope = { mode: this.mode(), filterModel: structuredClone(this.model()) };
          for (const chart of this.savedCharts())
            this.saveChartFilters(chart.id, structuredClone(scope));
          this.notice.set('Every chart now uses the table filter as its own filter.');
        },
        clearAllCharts: () => {
          for (const chart of this.savedCharts())
            this.saveChartFilters(chart.id, { mode: this.mode(), filterModel: null });
          this.notice.set('Chart filters cleared. Each chart now covers all records.');
        },
      },
    });
  }
  /** Removing a chart is destructive and only ever asks in the application dialog. */
  async confirmRemoveSavedChart(id: string): Promise<void> {
    const chart = this.savedCharts().find((item) => item.id === id);
    if (!chart || this.busy() || this.actionsLocked()) return;
    const { ConfirmDialogComponent } = await import('../ui/confirm-dialog.component');
    const confirmed = await firstValueFrom(
      this.dialog
        .open(ConfirmDialogComponent, {
          data: {
            title: `Remove ${chart.plan.title}?`,
            message: 'The chart and its filter are removed from this view when you next save.',
            confirmLabel: 'Remove chart',
            destructive: true,
          },
          width: '440px',
          maxWidth: 'calc(100vw - 24px)',
        })
        .afterClosed(),
    );
    if (confirmed) this.removeSavedChart(id);
  }
  /** A copy keeps the plan, filter and formatting; it gets its own identity and title. */
  duplicateSavedChart(id: string): void {
    if (this.busy() || this.actionsLocked()) return;
    const charts = this.savedCharts();
    const index = charts.findIndex((item) => item.id === id);
    const source = charts[index];
    if (!source) return;
    const copy: SavedChartState = {
      ...structuredClone({ ...source, data: null }),
      id: crypto.randomUUID(),
      plan: { ...structuredClone(source.plan), title: `${source.plan.title} copy` },
      presentation: source.presentation
        ? { ...structuredClone(source.presentation), requestedTitle: `${source.plan.title} copy` }
        : null,
      data: null,
      loading: false,
      error: '',
      signature: '',
    };
    this.savedCharts.set([...charts.slice(0, index + 1), copy, ...charts.slice(index + 1)]);
    this.chartPage.set(Math.floor((index + 1) / this.chartPageSize()));
    this.updateChart();
    this.notice.set(`Duplicated ${source.plan.title}.`);
  }
  removeSavedChart(id: string): void {
    if (this.busy() || this.actionsLocked()) return;
    const removed = this.savedCharts().find((chart) => chart.id === id);
    if (!removed) return;
    // Discard the editor and any proposal tied to this chart, so its live preview
    // cannot remain visible or recreate the removed chart when applied later.
    if (this.editingChartId === id || this.followUpChartId === id) {
      this.invalidate();
      this.editingChartId = null;
      this.resetBuilder();
      this.closeAssistant();
    }
    this.savedChartRequests.get(id)?.abort();
    this.savedChartRequests.delete(id);
    this.savedCharts.update((charts) => charts.filter((chart) => chart.id !== id));
    if (this.focusedChartId() === id) this.focusedChartId.set(null);
    if (this.selectedChartId === id) this.selectSavedChart(this.savedCharts().at(-1) ?? null);
    if (!this.savedCharts().length) {
      this.selectSavedChart(null);
      if (this.resultView() === 'both') this.resultView.set('grid');
    }
    this.notice.set(`Removed ${removed.plan.title}. Save the view to keep this change.`);
  }
  private selectSavedChart(chart: SavedChartState | null): void {
    this.selectedChartId = chart?.id ?? null;
    this.chartPlan.set(chart?.plan ?? null);
    this.chartPresentation.set(chart?.presentation ?? null);
    this.chartData.set(chart?.data ?? null);
  }
  refineSavedChart(id: string): void {
    const chart = this.savedCharts().find((entry) => entry.id === id);
    if (!chart || this.busy() || this.actionsLocked()) return;
    this.invalidate();
    this.resetBuilder();
    this.builderDescription.set(chart.description ?? '');
    this.builderDescriptionBaseline.set(chart.description ?? '');
    this.builderInitialFilterControls.set(structuredClone(chart.filterControls));
    this.selectSavedChart(chart);
    this.editingChartId = id;
    this.builderPresentation.set(chart.presentation ? structuredClone(chart.presentation) : null);
    this.builderEditorMode.set('edit');
    this.requestScope.set('current');
    this.continuingView.set(true);
    this.workflowIntent.set('chart');
    this.builderInitialFilters.set([]);
    this.guidedBaseFilter = this.savedChartFilter(chart);
    this.guidedBaseCaptured = true;
    this.guidedBaseDraftId = undefined;
    this.builderInitialPlan.set(structuredClone(this.currentChartContext()!));
    this.chartGuideOpen.set(true);
    this.openAssistant();
    this.focusChartGuide();
  }
  /** The table's active filter in the advanced shape the chart builder edits. */
  tableFilterAsAdvanced(): AdvancedFilterModel | null {
    this.currentJson();
    if (!this.hasActiveFilter()) return null;
    try {
      return toModel(
        fromModel(this.model(), this.mode(), this.columns()),
        'advanced',
        this.columns(),
        this.setFiltersEnabled(),
      ) as AdvancedFilterModel | null;
    } catch {
      return null;
    }
  }
  private savedChartFilter(chart: SavedChartItem): GridModel {
    const scope = chartDataScope(chart, { mode: this.mode(), filterModel: this.model() });
    return toModel(
      fromModel(scope.filterModel, scope.mode, this.columns()),
      this.mode(),
      this.columns(),
      this.setFiltersEnabled(),
    );
  }
  private chartEditingFilter(): GridModel {
    const chart = this.savedCharts().find(
      (item) => item.id === (this.editingChartId ?? this.followUpChartId),
    );
    return chart ? this.savedChartFilter(chart) : this.model();
  }
  describeGridState(state: Record<string, unknown>): string[] {
    const value = state as GridState;
    const columnLabel = (id: string) => this.columns().find((c) => c.id === id)?.label ?? id;
    let filter = `All ${this.source().rowLabel}s`;
    if (value.filter) {
      const model =
        this.mode() === 'advanced'
          ? (value.filter.advancedFilterModel ?? null)
          : (value.filter.filterModel ?? {});
      try {
        const ast = fromModel(model, this.mode(), this.columns());
        filter = ast ? expression(ast, true, this.columns()) : filter;
      } catch {
        filter = 'See the proposed filter model below';
      }
    }
    const sort = value.sort?.sortModel.map((c) => `${columnLabel(c.colId)} ${c.sort}`).join(', ');
    const groups = value.rowGroup?.groupColIds.map(columnLabel).join(' → ');
    const pivots = value.pivot?.pivotColIds.map(columnLabel).join(', ');
    const values = value.aggregation?.aggregationModel
      .map((c) => `${c.aggFunc.toUpperCase()}(${columnLabel(c.colId)})`)
      .join(', ');
    return [
      `Filters: ${filter}`,
      `Sort: ${sort || 'None'}`,
      `Groups: ${groups || 'None'}`,
      `Pivot: ${value.pivot?.pivotMode ? pivots || 'On (no pivot columns)' : 'Off'}`,
      `Aggregations: ${values || 'None'}`,
    ];
  }
  proposalFeatures(result: Extract<GridCopilotResult, { status: 'proposal' }>): string[] {
    const merged = { ...this.currentGridState() };
    for (const feature of GRID_FEATURES) {
      if (!result.propertiesToIgnore.includes(feature) && feature in result.gridState) {
        merged[feature] = result.gridState[feature];
      }
    }
    const features = this.describeGridState(merged);
    if (result.dashboard) features.push(`Dashboard: ${this.dashboardLabel(result.dashboard)}`);
    if (result.chart) features.push(`Chart: ${result.chart.title} (${result.chart.type})`);
    return features;
  }
  dashboardLabel(plan: DashboardPlan): string {
    return (
      {
        portfolio: 'Portfolio balances',
        financial: 'Quarterly financial performance',
        market: 'Historical market prices',
      }[plan.template] + (plan.period ? ` · ${plan.period.replace('Q', ' Q')}` : '')
    );
  }
  proposalJson(result: Extract<GridCopilotResult, { status: 'proposal' }>): string {
    return JSON.stringify(result.gridState, null, 2);
  }
  showMarketColumns(): void {
    this.api?.setColumnsVisible(
      this.source()
        .columns.slice(8, 16)
        .map((c) => c.id),
      true,
    );
    this.api?.ensureColumnVisible('marketDate');
  }
  editText(value: string): void {
    this.text.set(value);
  }
  setOperation(value: Operation): void {
    this.operation.set(value);
    this.invalidate();
  }
  setAssistant(value: 'grid' | 'verified'): void {
    if (this.nativeCalculationBusy()) return;
    if (value === 'verified' && this.calculatedColumns().length) {
      this.notice.set('Use the Grid assistant while calculated columns are active.');
      return;
    }
    if (value === 'verified' && JSON.stringify(this.model()).includes('"filterType":"set"')) {
      this.showError(new Error('Clear active Set Filters before switching to Verified filters.'));
      return;
    }
    if (value === 'verified' && this.setFiltersEnabled()) this.setSetFiltersEnabled(false);
    this.assistant.set(value);
    this.invalidate();
  }
  useExample(value: string): void {
    if (!this.isActiveExplorer() || !this.examples().some((example) => example.value === value))
      return;
    this.useLibraryPrompt({ prompt: value, followUp: false });
    this.focusComposer();
  }
  switchMode(mode: Mode): void {
    if (mode === this.mode() || !this.ready()) return;
    let target: GridModel;
    try {
      target = toModel(
        fromModel(this.model(), this.mode(), this.columns()),
        mode,
        this.columns(),
        this.setFiltersEnabled(),
      );
    } catch (e) {
      this.showError(e);
      this.hints.set([
        'Clear the current grid filters before changing mode, or keep Advanced mode.',
      ]);
      return;
    }
    this.invalidate();
    this.ready.set(false);
    this.cancelServerGrid();
    this.visible.set(false);
    this.mode.set(mode);
    this.initialState = {
      ...this.api?.getState(),
      filter:
        mode === 'advanced'
          ? { advancedFilterModel: (target ?? undefined) as AdvancedFilterModel | undefined }
          : { filterModel: target ?? {} },
    };
    setTimeout(() => this.visible.set(true), 0);
  }
  clear(): void {
    void this.hardReset();
  }
  resetAnalysis(): void {
    void this.hardReset();
  }
  filterPreviewSource(chart?: SavedChartItem): FilterPreviewSource {
    return {
      rows: this.data.cache.getGridRows(this.dataSourceId()) as StreamRow[],
      chart,
      gridState: this.api?.getState(),
    };
  }
  async builder(): Promise<void> {
    if (!this.api || this.api.isDestroyed() || this.actionsLocked() || this.busy()) return;
    const { FilterFocusDialogComponent } = await import(
      '../rendering/filter-focus-dialog.component'
    );
    this.closeFilterPanel();
    const scope = await firstValueFrom(
      this.dialog
        .open(FilterFocusDialogComponent, {
          width: '820px',
          maxWidth: '96vw',
          maxHeight: '94dvh',
          autoFocus: 'first-heading',
          data: {
            title: this.modelDisplayName(),
            columns: this.columns(),
            scope: { mode: this.mode(), filterModel: structuredClone(this.model()) },
            source: this.filterPreviewSource(),
            access: 'expression',
          },
        })
        .afterClosed(),
    );
    if (scope) {
      const error = this.applyFilterBuilder(
        toModel(
          fromModel(scope.filterModel, scope.mode, this.columns()),
          'advanced',
          this.columns(),
          this.setFiltersEnabled(),
        ) as AdvancedFilterModel | null,
      );
      if (error) this.showError(new Error(error));
    }
  }
  closeFilterPanel(): void {
    if (this.api && !this.api.isDestroyed()) this.api.closeToolPanel();
    this.syncToolPanelState();
    if (this.isActiveExplorer())
      this.host.nativeElement
        .querySelector<HTMLButtonElement>('.filter-builder-icon')
        ?.focus({ preventScroll: true });
  }
  toggleColumnsPanel(): void {
    if (!this.api || this.api.isDestroyed()) return;
    if (this.isToolPanelVisible(EXPLORER_COLUMNS_PANEL)) {
      this.closeColumnsPanel();
      return;
    }
    this.openColumnsPanel();
  }
  private openColumnsPanel(): void {
    this.openExplorerToolPanel(EXPLORER_COLUMNS_PANEL);
  }
  private isToolPanelVisible(panel: string): boolean {
    return !!(
      this.api &&
      !this.api.isDestroyed() &&
      (this.resultView() === 'grid' || this.resultView() === 'both') &&
      this.api.isSideBarVisible() &&
      this.api.getOpenedToolPanel() === panel
    );
  }
  private openExplorerToolPanel(panel: string): void {
    if (!this.api || this.api.isDestroyed() || this.actionsLocked() || this.busy()) return;
    if (this.resultView() !== 'both') this.setResultView('grid');
    // Restored grid state can hide the sidebar without clearing its selected panel.
    // AG's openToolPanel selects a panel, but does not reveal a hidden sidebar.
    this.api.setSideBarPosition('left');
    this.api.setSideBarVisible(true);
    this.api.openToolPanel(panel);
    this.syncToolPanelState();
    if (this.resultView() === 'both') {
      requestAnimationFrame(() => {
        if (!this.isActiveExplorer() || !this.isToolPanelVisible(panel)) return;
        this.host.nativeElement
          .querySelector<HTMLElement>('.ag-tool-panel-wrapper:not(.ag-hidden)')
          ?.scrollIntoView({ block: 'nearest', inline: 'nearest' });
      });
    }
  }
  closeColumnsPanel(): void {
    if (this.api && !this.api.isDestroyed()) this.api.closeToolPanel();
    this.syncToolPanelState();
    if (this.isActiveExplorer())
      this.host.nativeElement
        .querySelector<HTMLButtonElement>('.columns-panel-icon')
        ?.focus({ preventScroll: true });
  }
  private columnCategory(id: string): string | undefined {
    const overrides = this.columnCategoryOverrides();
    return Object.hasOwn(overrides, id) ? overrides[id] : this.columnsById().get(id)?.groupByTag;
  }
  private setColumnCategory(id: string, category: string | undefined): void {
    this.setColumnCategories({ [id]: category });
  }
  private setColumnCategories(assignments: Record<string, string | undefined>): void {
    if (this.actionsLocked() || this.busy()) return;
    const knownColumns = this.columnsById();
    const changes: Record<string, string | undefined> = {};
    for (const [id, category] of Object.entries(assignments)) {
      if (!knownColumns.has(id)) return;
      const tag = category?.trim() || undefined;
      if (tag !== undefined && !isColumnGroupTag(tag)) return;
      changes[id] = tag;
    }
    this.columnCategoryOverrides.update((overrides) => ({ ...overrides, ...changes }));
  }
  private highlightColumn(id: string | null, color?: ColumnHighlightColor): void {
    const api = this.api;
    if (!api || api.isDestroyed() || this.actionsLocked() || this.busy()) return;
    if (id !== null && !this.columnsById().has(id)) return;
    if (color !== undefined && !isColumnHighlightColor(color)) return;
    const previous = this.columnHighlights();
    const changed = id === null ? Object.keys(previous) : [id];
    if (!changed.length || (id !== null && color !== undefined && previous[id] === color)) return;
    if (id === null) {
      this.columnHighlights.set({});
      this.nextColumnHighlight = 0;
    } else {
      const next = { ...previous };
      if (color !== undefined) next[id] = color;
      else if (Object.hasOwn(previous, id)) delete next[id];
      else {
        next[id] = COLUMN_HIGHLIGHT_COLORS[this.nextColumnHighlight]!.id;
        this.nextColumnHighlight = (this.nextColumnHighlight + 1) % COLUMN_HIGHLIGHT_COLORS.length;
      }
      this.columnHighlights.set(next);
    }
    api.refreshCells({ columns: changed, force: true, suppressFlash: true });
    api.refreshHeader();
  }
  private locateColumn(id: string): void {
    const api = this.api;
    if (
      !api ||
      api.isDestroyed() ||
      this.actionsLocked() ||
      this.busy() ||
      this.explorerContext.isActive?.() === false ||
      !api.getAllDisplayedColumns().some((column) => column.getColId() === id)
    )
      return;
    clearTimeout(this.columnLocateTimer);
    const previous = this.locatedColumn();
    this.locatedColumn.set(id);
    api.refreshCells({
      columns: previous && previous !== id ? [previous, id] : [id],
      force: true,
      suppressFlash: true,
    });
    api.refreshHeader();
    // A visible target also needs feedback when no horizontal scroll is necessary.
    api.setFocusedHeader(id);
    this.columnLocateTimer = setTimeout(() => {
      this.locatedColumn.set(null);
      if (this.api !== api || api.isDestroyed()) return;
      api.refreshCells({ columns: [id], force: true, suppressFlash: true });
      api.refreshHeader();
    }, 2200);
  }
  readonly columnMenuItems = (
    params: GetColumnMenuItemsParams,
  ): (DefaultColumnMenuItem | MenuItemDef)[] => {
    if (this.actionsLocked() || this.busy()) return [];
    const items: (DefaultColumnMenuItem | MenuItemDef)[] = params.defaultItems.map((item) =>
      item === 'columnChooser'
        ? { name: 'Choose columns', action: () => this.openColumnsPanel() }
        : item,
    );
    const id = params.column?.getColId();
    if (!id || !this.columnsById().has(id)) return items;
    if (!items.includes('scrollIntoView')) items.unshift('scrollIntoView');
    items.push(
      'separator',
      {
        name: this.columnHighlights()[id] ? 'Remove column highlight' : 'Highlight column',
        action: () => this.highlightColumn(id),
      },
      {
        name: 'Highlight color',
        subMenu: COLUMN_HIGHLIGHT_COLORS.map((color) => ({
          name: color.label,
          checked: this.columnHighlights()[id] === color.id,
          icon: `<span class="column-highlight-menu-swatch ${columnHighlightClass(color.id)}" aria-hidden="true"></span>`,
          action: () => this.highlightColumn(id, color.id),
        })),
      },
    );
    if (Object.keys(this.columnHighlights()).length)
      items.push({ name: 'Clear all column highlights', action: () => this.highlightColumn(null) });
    return items;
  };
  onToolPanelVisibleChanged(event: ToolPanelVisibleChangedEvent): void {
    if (event.api === this.api) this.syncToolPanelState();
  }
  private syncToolPanelState(): void {
    const opened =
      this.api && !this.api.isDestroyed() && this.api.isSideBarVisible()
        ? this.api.getOpenedToolPanel()
        : null;
    this.filterBuilderOpen.set(opened === EXPLORER_FILTER_PANEL);
    this.columnsPanelOpen.set(opened === EXPLORER_COLUMNS_PANEL);
  }
  private orderedFilterColumns(): readonly ColumnSpec[] {
    const byId = new Map(this.columns().map((column) => [column.id, column]));
    const ordered = (this.api?.getAllGridColumns() ?? []).flatMap((column) => {
      const spec = byId.get(column.getColId());
      if (!spec) return [];
      byId.delete(spec.id);
      return [spec];
    });
    return [...ordered, ...byId.values()];
  }
  applyFilterBuilder(model: AdvancedFilterModel | null): string | null {
    if (!this.api || this.actionsLocked() || this.busy())
      return 'Wait for the current request to finish before applying filters.';
    try {
      if (this.mode() === 'advanced') this.api.setAdvancedFilterModel(model);
      else
        this.api.setFilterModel(
          toModel(
            fromModel(model, 'advanced', this.columns()),
            'columns',
            this.columns(),
            this.setFiltersEnabled(),
          ) as Record<string, unknown> | null,
        );
      return null;
    } catch (error) {
      return error instanceof Error
        ? error.message
        : 'These conditions cannot be applied in the current filter mode.';
    }
  }
  clearCurrentFilters(): string | null {
    if (this.actionsLocked() || this.busy() || !this.api)
      return 'Wait for the current request to finish before clearing filters.';
    // Clear is immediate in the explorer. Keep its editor available for the next
    // condition, and discard both expression and panel drafts in the same action.
    this.filterExpressionOpen.set(false);
    const error = this.applyFilterBuilder(null);
    if (error) return error;
    this.api.getToolPanelInstance<FilterToolPanelComponent>(EXPLORER_FILTER_PANEL)?.resetDraft();
    this.filterBaselinePending = true;
    this.scheduleFilterInputSync();
    return null;
  }
  private invalidate(keepPendingIntent = false): void {
    this.queuedLibraryPrompt = undefined;
    this.guidedBaseCaptured = false;
    this.proposedRowCount.set(null);
    if (!keepPendingIntent) {
      this.followUpChartId = null;
      this.chartGuideOpen.set(false);
      this.chartGuideError.set('');
      this.pendingIntent = undefined;
      this.lastInterpretation = undefined;
      this.retryConversation = undefined;
      this.draftBaseId = undefined;
      this.draftChart = undefined;
      this.chartPreviewPresentation.set(null);
    }
    this.chartPreviewRequest.set(null);
    this.chartPreviewExchange.set(null);
    this.retryText.set(null);
    this.retryLabel.set('Retry request');
    this.finishActive('superseded');
    ++this.revision;
    this.request?.abort();
    this.busy.set(false);
    this.result.set(null);
    this.gridResult.set(null);
    this.error.set('');
    this.hints.set([]);
    this.notice.set('');
    this.pendingAggregateColumn = undefined;
  }
  private showError(e: unknown): void {
    const err = e as { name?: string; message?: string; code?: string; hints?: string[] };
    if (err.name === 'AbortError') return;
    this.error.set(err.message ?? 'The request failed.');
    this.hints.set(err.hints ?? []);
    this.result.set(null);
    this.gridResult.set(null);
    this.finishActive('error');
    this.addMessage({
      role: 'assistant',
      text: [err.message ?? 'The request failed.', ...(err.hints ?? [])].join('\n'),
      status: 'error',
    });
  }
  private showConfirmationError(error: unknown): void {
    this.draftBaseId = undefined;
    this.draftChart = undefined;
    this.chartPreviewRequest.set(null);
    this.chartPreviewExchange.set(null);
    if (this.lastInterpretation) {
      this.showInterpretRecovery(error, this.lastInterpretation.text);
      this.retryLabel.set('Review request again');
    } else this.showError(error);
  }
  private showInterpretRecovery(_error: unknown, request: string): void {
    const chart =
      this.workflowIntent() === 'chart' ||
      /\b(chart|graph|plot|bars?|columns?|pie|donut|scatter|histogram)\b/i.test(request);
    const subject = chart ? 'chart' : 'filter';
    const message = chart
      ? 'I could not prepare that chart. Your request is still available below. Open the chart builder to choose fields and preview the result.'
      : 'I could not prepare that filter. Your request is still available below. Try it again, or tell me which field or value to change.';
    this.error.set('');
    this.hints.set([]);
    this.result.set(null);
    this.gridResult.set(null);
    this.finishActive('answered');
    if (this.assistant() === 'grid') {
      const recovery: GridCopilotResult = {
        status: 'needs_input',
        reason: 'recovery',
        message,
        options: chart
          ? [
              {
                label: 'Build chart',
                answer: 'Open the chart builder.',
                action: 'open_chart_builder',
              },
            ]
          : [
              {
                label: 'Adjust filter',
                answer: 'Help me choose an available field and value for that filter.',
              },
            ],
      };
      this.pendingIntent = { request, answers: [], question: message };
      this.receiveGridResult(recovery);
    } else this.receiveFilterResult({ status: 'needs_input', message });
    this.retryText.set(request);
    this.retryLabel.set(`Try ${subject} again`);
    this.notice.set('The request is ready to retry or adjust. No changes were applied.');
  }
  private addMessage(message: Omit<ChatMessage, 'id'>): string {
    const id = crypto.randomUUID();
    const modelContext =
      message.modelContext ??
      (message.role === 'user' ||
      (message.gridResult && message.gridResult.status !== 'proposal') ||
      (message.filterResult && message.filterResult.status !== 'proposal')
        ? 'dialogue'
        : 'display');
    this.chatMessages.update((messages) => [...messages, { ...message, modelContext, id }]);
    this.scrollChat();
    return id;
  }
  private scrollChat(): void {
    setTimeout(() => {
      const element = this.chatScroll?.nativeElement;
      if (element && this.assistantOpen())
        element.scrollTo({
          top: element.scrollHeight,
          behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches
            ? 'auto'
            : 'smooth',
        });
    }, 0);
  }
  private finishActive(status: ChatMessage['status']): void {
    const id = this.activeChatId();
    if (id)
      this.chatMessages.update((messages) =>
        messages.map((message) => (message.id === id ? { ...message, status } : message)),
      );
    this.activeChatId.set(null);
  }
  private conversationContext(): GridChatTurn[] {
    if (this.pendingIntent) return clarificationContext(this.pendingIntent);
    return gridChatContext(this.chatMessages());
  }
  private receiveGridResult(result: GridCopilotResult): void {
    if (result.status === 'needs_input' && result.action === 'open_chart_builder') {
      this.openContextualChartHelp(result.message);
      return;
    }
    this.gridResult.set(result);
    if (
      result.status === 'needs_input' &&
      result.reason === 'recovery' &&
      this.lastInterpretation
    ) {
      this.retryText.set(this.lastInterpretation.text);
      this.retryLabel.set('Try request again');
    }
    if (result.status === 'proposal') {
      this.draftBaseId = result.id;
      this.draftChart = result.chart ?? undefined;
      if (result.chart) {
        this.workflowIntent.set('chart');
        // A follow-up preview starts with the applied native formatting; the
        // renderer reuses it only when the chart's fields and types still match.
        if (
          !this.chartPreviewPresentation() &&
          this.requestScope() === 'current' &&
          !result.resetView
        ) {
          this.chartPreviewPresentation.set(this.chartPresentation());
        }
        this.chartPreviewRequest.set({
          plan: result.chart,
          mode: this.mode(),
          filterModel: this.proposedFilterModel(result.gridState),
          calculatedColumnIds: this.calculatedColumnIds(),
        });
      }
    }
    const text = result.status === 'proposal' ? result.summary : result.message;
    const active = !(result.status === 'needs_input' && result.reason === 'unsupported');
    if (!active) this.pendingIntent = undefined;
    const id = this.addMessage({
      role: 'assistant',
      text,
      gridResult: result,
      ...(result.status === 'proposal' ? { features: this.proposalFeatures(result) } : {}),
      status: active ? 'active' : 'answered',
    });
    this.activeChatId.set(active ? id : null);
  }
  private receiveFilterResult(result: InterpretResult): void {
    if (result.status === 'rejected')
      result = {
        status: 'needs_input',
        message:
          'I could not prepare that filter. Your request is still available below. Try it again, or tell me which field or value to change.',
      };
    this.result.set(result);
    if (result.status === 'needs_input' && this.lastInterpretation) {
      this.retryText.set(this.lastInterpretation.text);
      this.retryLabel.set('Try filter again');
    }
    const text =
      result.status === 'proposal'
        ? result.summary
        : result.status === 'clarification'
          ? result.question.message
          : result.message;
    const active = result.status === 'proposal' || result.status === 'clarification';
    const id = this.addMessage({
      role: 'assistant',
      text,
      filterResult: result,
      ...(active ? { status: 'active' as const } : {}),
    });
    this.activeChatId.set(active ? id : null);
  }
  submitMessage(): void {
    void this.interpret();
  }
  toggleAssistant(): void {
    if (this.actionsLocked()) return;
    if (this.assistantOpen()) this.closeAssistant();
    else {
      this.openAssistant();
      this.assistantReturnFocus = this.assistantToggle?.nativeElement;
    }
  }
  openAssistant(): void {
    if (!this.assistantOpen()) {
      this.assistantReturnFocus = document.activeElement as HTMLElement;
      this.assistantOpen.set(true);
    }
    this.focusComposer();
    this.scrollChat();
  }
  closeAssistant(): void {
    this.assistantOpen.set(false);
    afterNextRender(
      () => {
        if (!this.isActiveExplorer()) return;
        const candidate = this.assistantReturnFocus;
        const target =
          candidate?.isConnected && candidate.checkVisibility() && !candidate.closest('[inert]')
            ? candidate
            : this.assistantToggle?.nativeElement;
        target?.focus({ preventScroll: true });
      },
      { injector: this.injector },
    );
  }
  private focusComposer(): void {
    afterNextRender(
      () => {
        if (this.assistantOpen() && this.isActiveExplorer())
          this.composerInput?.nativeElement?.focus({ preventScroll: true });
      },
      { injector: this.injector },
    );
  }
  onAssistantKeydown(event: KeyboardEvent): void {
    if (this.promptLibraryOpen() || event.defaultPrevented) return;
    if (event.key === 'Escape') {
      // Material's document-level dispatcher closes its popup after this event
      // bubbles through the assistant. Let the popup consume the first Escape.
      // MatSelect may already have detached the popup before the event gets here.
      if (
        event.target instanceof Element &&
        event.target.closest('mat-select, input[role="combobox"], [aria-haspopup="listbox"]')
      )
        return;
      if (
        document.querySelector(
          '.cdk-overlay-container [role="listbox"], .cdk-overlay-container [role="menu"]',
        )
      )
        return;
      event.preventDefault();
      event.stopPropagation();
      this.closeAssistant();
      return;
    }
    if (event.key !== 'Tab' || !this.assistantMobile()) return;
    const controls = Array.from(
      this.assistantPanel?.nativeElement.querySelectorAll<HTMLElement>(
        'button:not(:disabled), textarea:not(:disabled), input:not(:disabled), select:not(:disabled), summary, a[href], [tabindex="0"]',
      ) ?? [],
    ).filter((element) => element.getClientRects().length > 0);
    const first = controls[0];
    const last = controls.at(-1);
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last?.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first?.focus();
    }
  }
  retryRows(): void {
    if (!this.ready() || !this.api || this.api.isDestroyed()) return;
    this.rowError.set('');
    void this.startServerGrid();
  }
  retrySql(): void {
    if (!this.sqlBusy()) {
      this.previewSignature = '';
      this.updateSql();
    }
  }
  retryDashboard(): void {
    if (!this.dashboardBusy()) {
      this.dashboardSignature = '';
      this.updateDashboard();
    }
  }
  reloadExplorer(): void {
    window.location.reload();
  }
  answerGridClarification(option: GridClarificationOption): void {
    if (this.actionsLocked()) return;
    const result = this.gridResult();
    if (
      this.busy() ||
      !this.activeChatId() ||
      result?.status !== 'needs_input' ||
      result.reason === 'unsupported'
    )
      return;
    if (option.action === 'open_chart_builder') {
      this.openContextualChartHelp();
      if (option.chart) {
        this.guidedBaseFilter = structuredClone(option.chart.filterModel);
        this.builderInitialPlan.set(structuredClone(option.chart.plan));
        this.requestScope.set(option.chart.requestScope);
        this.draftBaseId = option.chart.draftId ?? this.draftBaseId;
        this.guidedBaseDraftId = this.draftBaseId;
      }
      return;
    }
    if (option.chart) {
      void this.previewChartChoice(option);
      return;
    }
    const answer = option.answer;
    if (
      result.clarificationKind === 'column' &&
      result.options?.some((option) => option.answer === answer)
    ) {
      this.finishActive('answered');
      this.pendingIntent = undefined;
      this.retryConversation = [];
    }
    this.text.set(answer);
    void this.interpret();
  }
  private async previewChartChoice(option: GridClarificationOption): Promise<void> {
    if (this.busy() || this.actionsLocked()) return;
    const choice = option.chart!;
    this.finishActive('answered');
    this.pendingIntent = undefined;
    this.retryConversation = undefined;
    this.retryText.set(null);
    this.requestScope.set(choice.requestScope);
    this.workflowIntent.set('chart');
    this.addMessage({ role: 'user', text: option.label });
    const revision = this.revision;
    const controller = new AbortController();
    this.request = controller;
    this.busy.set(true);
    this.busyLabel.set('Preparing the selected chart');
    try {
      const proposal = await this.data.proposeChart(
        {
          plan: choice.plan,
          mode: this.mode(),
          currentState: this.currentGridState(),
          filterModel: choice.filterModel,
          requestScope: choice.requestScope,
          ...((choice.draftId ?? this.draftBaseId)
            ? { draftId: choice.draftId ?? this.draftBaseId }
            : {}),
          calculatedColumnIds: this.calculatedColumnIds(),
        },
        controller.signal,
      );
      if (revision === this.revision) this.receiveGridResult(proposal);
    } catch (error) {
      if (revision === this.revision && (error as Error).name !== 'AbortError') {
        this.openContextualChartHelp(
          'The chart data changed. Review the selected fields and filters.',
        );
        this.guidedBaseFilter = structuredClone(choice.filterModel);
        this.builderInitialPlan.set(structuredClone(choice.plan));
      }
    } finally {
      if (revision === this.revision) this.busy.set(false);
    }
  }
  startDifferentRequest(): void {
    if (this.busy() || this.actionsLocked()) return;
    this.finishActive('cancelled');
    this.invalidate();
    this.requestScope.set('fresh');
    this.continuingView.set(false);
    this.workflowIntent.set('data');
    this.operation.set('replace');
    this.text.set('');
    this.addMessage({
      role: 'assistant',
      text: 'The previous request is cancelled. Your next request starts from all data; the grid changes only after Apply.',
    });
    setTimeout(() => {
      if (this.isActiveExplorer()) this.composerInput?.nativeElement?.focus();
    }, 0);
  }
  retryLastRequest(): void {
    const text = this.retryText();
    if (!text || this.busy() || this.actionsLocked()) return;
    this.retryConversation = this.lastInterpretation?.conversation;
    this.text.set(text);
    void this.interpret();
  }
  onComposerKeydown(event: KeyboardEvent): void {
    if (
      event.key === 'Enter' &&
      !event.shiftKey &&
      !event.isComposing &&
      (!this.assistantMobile() || event.ctrlKey || event.metaKey)
    ) {
      event.preventDefault();
      this.submitMessage();
    }
  }
  newConversation(): void {
    this.clearChat();
  }
  clearChat(): void {
    if (this.busy() || this.actionsLocked()) return;
    this.invalidate();
    this.data.resetAiSession();
    this.resetBuilder();
    this.editingChartId = null;
    this.chatMessages.set([]);
    this.activeChatId.set(null);
    this.text.set('');
    this.operation.set('replace');
    this.requestScope.set('current');
    this.continuingView.set(false);
    this.workflowIntent.set('data');
    this.focusComposer();
  }
  async hardReset(): Promise<void> {
    if (this.actionsLocked() || this.busy()) return;
    this.ready.set(false);
    this.cancelServerGrid();
    this.invalidate();
    this.data.resetAiSession();
    this.previewRequest?.abort();
    this.dashboardRequest?.abort();
    this.nativeCalculationRequest?.abort();
    this.resetBuilder();
    this.chatMessages.set([]);
    this.activeChatId.set(null);
    this.text.set('');
    this.mode.set('advanced');
    this.assistant.set('grid');
    this.operation.set('replace');
    this.requestScope.set('fresh');
    this.continuingView.set(false);
    this.workflowIntent.set('data');
    this.assistantOpen.set(false);
    this.promptLibraryOpen.set(false);
    this.schemaSearch.set('');
    this.calculatedColumns.set([]);
    this.data.cache.setCalculatedColumns(this.dataSourceId(), []);
    this.nativeCalculationDraft.set(null);
    this.nativeCalculationBusy.set(false);
    this.nativeCalculationError.set('');
    this.savedCharts.set([]);
    this.selectedChartId = null;
    this.editingChartId = null;
    this.chartPlan.set(null);
    this.chartPresentation.set(null);
    this.clearChartData();
    this.dashboardData.set(null);
    this.dashboardPlan.set({ template: 'portfolio', period: null });
    this.dashboardBusy.set(false);
    this.dashboardError.set('');
    this.dashboardSignature = '';
    this.previewSignature = '';
    this.sqlJson.set('');
    this.bindsJson.set('[]');
    this.sqlBusy.set(false);
    this.sqlError.set('');
    this.countSql.set('');
    this.resultView.set('grid');
    // Recreate the grid, including column layout and native UI state, from defaults.
    clearTimeout(this.columnLocateTimer);
    this.locatedColumn.set(null);
    this.columnCategoryOverrides.set({});
    this.columnCategoryOrder.set([]);
    this.columnHighlights.set({});
    this.nextColumnHighlight = 0;
    this.columnsPanelOpen.set(false);
    this.filterBuilderOpen.set(false);
    // The cached source remains available, including locally uploaded JSON.
    this.visible.set(false);
    this.api = undefined;
    this.initialState = {};
    this.sourceInitialState = {};
    this.signature = '';
    this.rowCount.set(null);
    this.rowError.set('');
    this.streamError.set('');
    this.rebuildColumnDefinitions();
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    this.visible.set(true);
    this.viewLayout.set({});
    this.notice.set('Page reset. Filters, layout, charts and conversation cleared.');
  }
  setRequestScope(scope: 'current' | 'fresh'): void {
    if (this.busy() || this.actionsLocked()) return;
    this.invalidate();
    this.requestScope.set(scope);
    this.continuingView.set(scope === 'current');
    this.operation.set('replace');
    this.focusComposer();
  }
  refineChartPreview(change: { prompt: string; reason?: string; plan?: ChartPlan }): void {
    if (this.busy() || this.actionsLocked() || !change.prompt.trim()) return;
    if (change.plan && this.draftBaseId) {
      void this.updateChartOptions(change.plan, change.prompt);
      return;
    }
    this.text.set(change.prompt);
    void this.interpret();
  }
  editProposedChart(): void {
    if (this.actionsLocked()) return;
    const proposal = this.gridResult();
    if (this.busy() || proposal?.status !== 'proposal' || !proposal.chart) return;
    const existing = this.savedCharts().find(
      (chart) => chart.id === (this.editingChartId ?? this.followUpChartId),
    );
    const description = this.builderDraft()
      ? this.builderDescription()
      : (existing?.description ?? '');
    const descriptionBaseline = this.builderDraft()
      ? this.builderDescriptionBaseline()
      : (existing?.description ?? '');
    const filterControls = this.builderDraft()
      ? this.builderDraft()!.filterControls
      : existing?.filterControls;
    this.resetBuilder();
    this.builderDescription.set(description);
    this.builderDescriptionBaseline.set(descriptionBaseline);
    this.builderInitialFilterControls.set(structuredClone(filterControls));
    if (existing) {
      this.builderEditorMode.set('edit');
      this.builderBaseline.set('unapplied-proposal');
    }
    this.guidedBaseFilter = this.proposedFilterModel(proposal.gridState);
    this.guidedBaseDraftId = proposal.id;
    this.guidedBaseCaptured = true;
    this.builderInitialPlan.set(structuredClone(proposal.chart));
    this.builderPresentation.set(
      this.chartPreviewPresentation() ? structuredClone(this.chartPreviewPresentation()) : null,
    );
    this.builderInitialFilters.set([]);
    this.requestScope.set('current');
    this.workflowIntent.set('chart');
    this.chartGuideOpen.set(true);
    this.chartGuideError.set('');
    this.openAssistant();
    this.focusChartGuide();
  }
  private async updateChartOptions(plan: ChartPlan, summary: string): Promise<void> {
    if (this.actionsLocked()) return;
    const id = this.draftBaseId;
    if (!id || this.busy()) return;
    const revision = this.revision;
    const controller = new AbortController();
    this.request = controller;
    this.busy.set(true);
    this.busyLabel.set('Updating chart options — no AI request');
    try {
      const result = await this.data.reviseChart(
        id,
        plan,
        this.mode(),
        this.currentGridState(),
        this.calculatedColumnIds(),
        controller.signal,
      );
      if (revision !== this.revision) return;
      if (result.status === 'needs_input') {
        this.addMessage({
          role: 'assistant',
          text: `${result.message} Your previous preview is still available. Choose different chart options or describe the change below.`,
          status: 'answered',
        });
        return;
      }
      this.finishActive('superseded');
      this.addMessage({ role: 'user', text: summary });
      this.proposedRowCount.set(null);
      this.chartPreviewExchange.set(null);
      this.chartPreviewRequest.set(null);
      this.receiveGridResult(result);
    } catch (error) {
      if (revision === this.revision) {
        const code = (error as { code?: string })?.code;
        if (code === 'EXPIRED_PROPOSAL' || code === 'STALE_STATE')
          this.showConfirmationError(error);
        else
          this.addMessage({
            role: 'assistant',
            text: `${error instanceof Error ? error.message : 'Could not update these options.'} The previous preview is unchanged; adjust the options and try again.`,
            status: 'answered',
          });
      }
    } finally {
      if (revision === this.revision) this.busy.set(false);
    }
  }
  refineAppliedChart(): void {
    if (!this.chartPlan() || this.busy() || this.actionsLocked()) return;
    if (this.selectedChartId) this.refineSavedChart(this.selectedChartId);
    else this.continueExploration('chart');
    this.notice.set(
      'Describe the chart or filter change below. Nothing is sent until you choose Send.',
    );
  }
  proposedFilterModel(state: Record<string, unknown>): GridModel {
    const filter = state['filter'] as
      | { advancedFilterModel?: GridModel; filterModel?: GridModel }
      | undefined;
    return (this.mode() === 'advanced' ? filter?.advancedFilterModel : filter?.filterModel) ?? null;
  }
  proposedFilterText(state: Record<string, unknown>): string {
    try {
      return filterPreview(this.proposedFilterModel(state), this.mode(), this.columns());
    } catch {
      return 'See the reviewed filter fields above.';
    }
  }
  useLibraryPrompt(selection: { prompt: string; followUp: boolean }): void {
    if (this.actionsLocked()) return;
    this.promptLibraryOpen.set(false);
    if (this.busy()) {
      this.queuedLibraryPrompt = selection;
      this.editText(selection.prompt);
      this.busyLabel.set('Finishing the current request; the next prompt is ready');
      this.openAssistant();
      return;
    }
    this.prepareLibraryPrompt(selection, selection.prompt);
    this.editText(selection.prompt);
    this.openAssistant();
  }
  private prepareLibraryPrompt(
    selection: { prompt: string; followUp: boolean },
    composerText: string,
  ): void {
    this.editingChartId = null;
    this.resetBuilder();
    if (!selection.followUp) this.setRequestScope('fresh');
    else this.requestScope.set('current');
    const chartExample = this.sourceExamples().some(
      (example) => example.chartType && example.prompt === composerText,
    );
    this.workflowIntent.set(
      chartExample
        ? 'chart'
        : requestedWorkflow(composerText, selection.followUp ? this.workflowIntent() : 'data'),
    );
    this.continuingView.set(selection.followUp);
    this.chartGuideOpen.set(false);
  }
  dismissProposal(): void {
    if (this.busy() || this.actionsLocked()) return;
    this.finishActive('cancelled');
    this.invalidate();
    this.addMessage({ role: 'assistant', text: 'Cancelled. Your current view is unchanged.' });
  }
  async interpret(): Promise<void> {
    if (this.destroyed || !this.isActiveExplorer()) return;
    if (!this.ready() || this.streamState() !== 'completed' || !this.text().trim() || this.busy())
      return;
    if (this.queuedLibraryPrompt) {
      const selection = this.queuedLibraryPrompt;
      this.queuedLibraryPrompt = undefined;
      this.prepareLibraryPrompt(selection, this.text().trim());
    }
    const text = this.text().trim();
    let builder = this.chartGuideOpen() ? this.builderDraft() : null;
    const newChart =
      startsNewChartRequest(text) &&
      !(this.pendingIntent && isChartTypeChoice(text)) &&
      !(builder && usesChartBuilderSettings(text));
    const newData = !!this.pendingIntent && startsIndependentDataRequest(text);
    if (newChart || newData) {
      // A self-contained creation starts a new review even if a previous request
      // left a proposal or clarification open. Referenced rows may still be reused.
      const usesCurrentRows = refersToCurrentResults(text);
      const retainedDataDraft = usesCurrentRows ? this.draftBaseId : undefined;
      this.invalidate();
      this.editingChartId = null;
      this.resetBuilder();
      builder = null;
      this.draftBaseId = retainedDataDraft;
      this.requestScope.set(usesCurrentRows ? 'current' : 'fresh');
      this.continuingView.set(usesCurrentRows);
      this.operation.set('replace');
      if (newData) this.workflowIntent.set('data');
    }
    let builderFilterModel = builder ? this.builderFilter(builder) : null;
    if (builder) this.requestScope.set('current');
    if (!builder) this.chartGuideOpen.set(false);
    this.workflowIntent.set(requestedWorkflow(text, this.workflowIntent()));
    const updatesSavedChart = targetsExistingChart(text);
    if (
      !this.draftBaseId &&
      !this.pendingIntent &&
      (refersToCurrentResults(text) || updatesSavedChart)
    ) {
      this.requestScope.set('current');
      this.continuingView.set(true);
    }
    const pending = this.pendingIntent;
    const draftId = this.draftBaseId;
    if (!builder && !pending && !draftId) {
      // Bind a typed edit to the selected saved card before requesting a proposal.
      // Retain that binding while the proposal is refined; cancellation clears it.
      this.followUpChartId = updatesSavedChart ? this.selectedChartId : null;
    }
    const scopedChart =
      !builder && !draftId && !newChart
        ? this.savedCharts().find(
            (chart) => chart.id === (this.editingChartId ?? this.followUpChartId),
          )
        : undefined;
    if (scopedChart) builderFilterModel = this.savedChartFilter(scopedChart);
    const chartContext = builder?.valid
      ? builder.plan
      : this.draftChart
        ? {
            ...this.draftChart,
            appearance: this.chartPreviewPresentation()?.appearance ?? this.draftChart.appearance,
          }
        : pending && this.lastInterpretation
          ? this.lastInterpretation.chartContext
          : !newChart && this.requestScope() === 'current'
            ? this.currentChartContext()
            : null;
    if (pending) this.finishActive('answered');
    this.invalidate(true);
    // AI suggestions remain optional. Sending a message must not replace the
    // authoritative draft filter with the grid or an unselected AI proposal.
    if (builder) this.guidedBaseCaptured = true;
    const revision = this.revision;
    const controller = new AbortController();
    this.request = controller;
    this.busy.set(true);
    this.busyLabel.set('Thinking through your request');
    this.scrollChat();
    try {
      const conversation =
        this.retryConversation ??
        (this.requestScope() === 'fresh' && !pending && !draftId ? [] : this.conversationContext());
      this.retryConversation = undefined;
      this.lastInterpretation = {
        text,
        conversation: structuredClone(conversation),
        chartContext: structuredClone(chartContext),
      };
      this.addMessage({ role: 'user', text });
      this.text.set('');
      this.refreshSchema();
      if (this.assistant() === 'grid') {
        const result = await this.data.interpretGrid(
          {
            text,
            useLiveAi: true,
            conversation,
            setFiltersEnabled: this.setFiltersEnabled(),
            dashboardsEnabled: this.dashboardsEnabled(),
            chartsEnabled: this.chartsEnabled(),
            workflowIntent: this.workflowIntent(),
            currentChart: chartContext,
            ...(builder || scopedChart ? { builderFilterModel } : {}),
            requestScope: draftId ? 'current' : this.requestScope(),
            ...(draftId ? { draftId } : {}),
            mode: this.mode(),
            operation: this.operation(),
            currentState: this.currentGridState(),
            toolkitSchema: this.toolkitSchema,
            calculatedColumnIds: this.calculatedColumnIds(),
          },
          controller.signal,
        );
        if (revision === this.revision) {
          this.pendingIntent =
            result.status === 'needs_input' && result.reason !== 'unsupported'
              ? {
                  request: pending?.request ?? text,
                  answers: pending
                    ? [...pending.answers, { question: pending.question, answer: text }]
                    : [],
                  question: result.message,
                }
              : undefined;
          this.receiveGridResult(result);
          if (builder) {
            this.offerBuilderSuggestions(result);
            this.chartGuideOpen.set(true);
            this.revealBuilderHelp();
          }
        }
        return;
      }
      if (this.calculatedColumns().length)
        throw new Error(
          'Verified filters do not support calculated columns. Use the Grid assistant.',
        );
      const result = await this.data.interpret(
        {
          text,
          useLiveAi: true,
          mode: this.mode(),
          operation: this.operation(),
          currentModel: this.model(),
          toolkitSchema: this.toolkitSchema,
        },
        controller.signal,
      );
      if (revision === this.revision) this.receiveFilterResult(result);
    } catch (e) {
      if (revision === this.revision) {
        this.showInterpretRecovery(e, text);
        if (builder) this.revealBuilderHelp();
      }
    } finally {
      if (revision === this.revision) this.busy.set(false);
    }
  }
  async clarify(choice: string): Promise<void> {
    if (this.actionsLocked()) return;
    const result = this.result();
    if (result?.status !== 'clarification' || this.busy()) return;
    this.finishActive('superseded');
    this.addMessage({
      role: 'user',
      text: result.question.choices.find((item) => item.id === choice)?.label ?? choice,
    });
    const revision = this.revision,
      controller = new AbortController();
    this.request = controller;
    this.busy.set(true);
    this.busyLabel.set('Updating the proposed filter');
    try {
      const next = await this.data.clarify(result.id, choice, controller.signal, true);
      if (revision === this.revision) this.receiveFilterResult(next);
    } catch (e) {
      if (revision === this.revision) this.showConfirmationError(e);
    } finally {
      if (revision === this.revision) this.busy.set(false);
    }
  }
  async apply(): Promise<void> {
    const result = this.result();
    if (result?.status !== 'proposal' || this.busy() || this.actionsLocked()) return;
    const revision = this.revision,
      controller = new AbortController();
    this.request = controller;
    this.busy.set(true);
    this.busyLabel.set('Checking and applying your filter');
    try {
      const confirmed = await this.data.confirm(
        result.id,
        this.mode(),
        this.model(),
        controller.signal,
      );
      if (revision !== this.revision || !this.api || this.api.isDestroyed()) return;
      // Validate locally too; the server remains the authoritative enforcement point.
      fromModel(confirmed.model, this.mode(), this.columns());
      this.applyConfirmedView({
        gridState: {
          filter:
            this.mode() === 'advanced'
              ? { advancedFilterModel: confirmed.model }
              : { filterModel: confirmed.model ?? {} },
        },
        propertiesToIgnore: [],
        summary: confirmed.summary,
      });
      this.finishActive('applied');
      this.result.set(null);
      this.updateCurrent();
      this.notice.set('Applied the reviewed filter.');
      this.addMessage({
        role: 'assistant',
        text: 'Filter applied. The results and Snowflake SQL now follow this view.',
      });
    } catch (e) {
      if (revision === this.revision) this.showConfirmationError(e);
    } finally {
      if (revision === this.revision) this.busy.set(false);
    }
  }
  async applyGrid(): Promise<void> {
    const result = this.gridResult();
    if (result?.status !== 'proposal' || this.busy() || this.actionsLocked()) return;
    if (result.chart && !this.chartPreviewExchange()) return;
    const metadata = result.chart
      ? {
          generationResponse: structuredClone(result),
          ...(this.builderDraft() &&
          this.workflowIntent() === 'chart' &&
          this.requestScope() === 'current'
            ? { description: this.builderDescription() }
            : {}),
        }
      : undefined;
    const revision = this.revision;
    const controller = new AbortController();
    this.request = controller;
    this.busy.set(true);
    this.busyLabel.set('Checking and applying your changes');
    try {
      const confirmed = await this.data.confirmGrid(
        result.id,
        this.mode(),
        this.currentGridState(),
        this.calculatedColumnIds(),
        controller.signal,
      );
      if (revision !== this.revision || !this.api || this.api.isDestroyed()) return;
      this.applyConfirmedView(confirmed, metadata);
      this.finishActive('applied');
      this.gridResult.set(null);
      this.draftBaseId = undefined;
      this.draftChart = undefined;
      this.chartPreviewRequest.set(null);
      this.chartPreviewExchange.set(null);
      this.chartPreviewPresentation.set(null);
      this.requestScope.set('fresh');
      this.continuingView.set(false);
      this.busy.set(false);
      this.notice.set(
        confirmed.chart
          ? 'Saved the configured chart in the Chart tab.'
          : 'Applied the reviewed grid changes.',
      );
      this.addMessage({
        role: 'assistant',
        text: confirmed.chart
          ? 'Chart saved with its own filters. Use Table and charts to show both together.'
          : this.chartPlan()
            ? 'Grid changes applied. Your configured chart remains available in the Chart tab.'
            : 'Grid changes applied.',
      });
    } catch (e) {
      if (revision === this.revision) this.showConfirmationError(e);
    } finally {
      if (revision === this.revision) this.busy.set(false);
    }
  }
  cancelCalculatedColumn(): void {
    this.dismissProposal();
  }
  openNativeCalculationMenu(): void {
    if (!this.ready() || !this.api || this.api.isDestroyed() || !this.nativeCalculatedColumns())
      return;
    this.host.nativeElement
      .querySelector<HTMLDetailsElement>('details.settings')
      ?.removeAttribute('open');
    const numeric = new Set(
      this.columns()
        .filter((column) => column.kind === 'number')
        .map((column) => column.id),
    );
    const column =
      this.api
        .getAllDisplayedColumns()
        .find((candidate) => candidate.isPrimary() && numeric.has(candidate.getColId())) ??
      this.api
        .getColumns()
        ?.find((candidate) => candidate.isPrimary() && numeric.has(candidate.getColId())) ??
      this.api.getColumns()?.find((candidate) => candidate.isPrimary());
    if (!column) return;
    const anchor = this.assistantToggle?.nativeElement.getBoundingClientRect();
    // This public API also works in pivot views, which have no source header.
    this.api.showContextMenu({
      column,
      value: null,
      source: 'api',
      x: Math.max(16, (anchor?.right ?? 260) - 240),
      y: anchor?.bottom ?? 80,
    });
  }
  onNativeCalculatedColumnCreated(event: CalculatedColumnCreatedEvent): void {
    const id = event.column.getColId();
    if (this.calculatedColumnIds().includes(id)) return;
    const state = event.api.getState();
    // A native dialog drafts the formula, but only server-approved fields enter SSRM or the Toolkit.
    event.api.setState({
      ...state,
      userColumns: (state.userColumns ?? []).filter((column) => column.colId !== id),
      columnOrder: state.columnOrder
        ? { orderedColIds: state.columnOrder.orderedColIds.filter((colId) => colId !== id) }
        : undefined,
    });
    this.nativeCalculationDraft.set({
      requestId: crypto.randomUUID(),
      label: event.column.getColDef().headerName ?? 'Calculated column',
      expression: event.expression,
      calculatedColumnIds: this.calculatedColumnIds(),
    });
    void this.saveNativeCalculation();
  }
  editNativeCalculation(field: 'label' | 'expression', value: string): void {
    if (this.nativeCalculationBusy()) return;
    this.nativeCalculationDraft.update((draft) =>
      draft
        ? {
            ...draft,
            [field]: value,
            requestId: crypto.randomUUID(),
            calculatedColumnIds: this.calculatedColumnIds(),
          }
        : null,
    );
  }
  dismissNativeCalculation(): void {
    if (this.nativeCalculationBusy()) return;
    this.nativeCalculationDraft.set(null);
    this.nativeCalculationError.set('');
  }
  async saveNativeCalculation(): Promise<void> {
    const draft = this.nativeCalculationDraft();
    if (
      !draft ||
      this.nativeCalculationBusy() ||
      !this.nativeCalculatedColumns() ||
      !this.api ||
      this.api.isDestroyed()
    )
      return;
    this.nativeCalculationError.set('');
    this.nativeCalculationBusy.set(true);
    const controller = new AbortController();
    this.nativeCalculationRequest = controller;
    try {
      parseNativeCalculation(draft, this.source().columns);
      const { column } = await this.data.request<{ column: CalculatedColumnDefinition }>(
        'calculated-columns',
        draft,
        controller.signal,
      );
      if (controller.signal.aborted || !this.api || this.api.isDestroyed()) return;
      const columnSpec = calculatedColumnSpec(column, this.source().columns);
      if (!this.calculatedColumnIds().includes(column.id)) {
        const previousState = this.api.getState();
        this.invalidate();
        this.dashboardRequest?.abort();
        this.dashboardSignature = '';
        this.dashboardData.set(null);
        this.dashboardBusy.set(false);
        this.rowCount.set(null);
        this.calculatedColumns.update((columns) => [...columns, column]);
        this.data.cache.setCalculatedColumns(this.dataSourceId(), this.calculatedColumns());
        this.columnDefs.push(this.columnDefinition(columnSpec, 0));
        this.api.setGridOption('columnDefs', this.columnDefs);
        this.api.setState(previousState);
        this.refreshSchema();
        this.signature = this.currentQueryKey();
        this.updateCurrent();
        this.refreshServerGrid(this.api);
        this.api.ensureColumnVisible(column.id, 'end');
      }
      this.nativeCalculationDraft.set(null);
      this.notice.set(
        `Created ${column.label}. The column is ready to filter, sort and aggregate.`,
      );
      this.addMessage({
        role: 'assistant',
        text: `Created ${column.label} from your reviewed formula. It is available in this session for filtering, sorting and aggregation.`,
      });
    } catch (error) {
      if (!controller.signal.aborted)
        this.nativeCalculationError.set(
          error instanceof Error
            ? error.message
            : 'The calculated column could not be saved. Your formula is still available below.',
        );
    } finally {
      if (!controller.signal.aborted) this.nativeCalculationBusy.set(false);
    }
  }
  private currentChartContext(): ChartPlan | null {
    const plan = this.chartPlan();
    const data = this.chartData();
    const presentation = this.chartPresentation();
    return plan && data && presentation && JSON.stringify(data.plan) === JSON.stringify(plan)
      ? { ...plan, appearance: presentation.appearance }
      : plan;
  }
  private applyConfirmedView(
    confirmed: GridConfirmation,
    metadata?: {
      description?: string;
      generationResponse?: GridCopilotResult;
      filterControls?: WidgetConfiguration['filterControls'];
    },
  ): void {
    if (!this.api || this.api.isDestroyed()) return;
    confirmed = prepareReviewedGridView(
      confirmed,
      confirmed.chart
        ? { ...this.currentGridState(), filter: confirmed.gridState['filter'] }
        : this.currentGridState(),
      this.mode(),
      this.columns(),
    );
    const existing = confirmed.chart
      ? this.savedCharts().find(
          (chart) => chart.id === (this.editingChartId ?? this.followUpChartId),
        )
      : undefined;
    // Chart scopes query the shared dataset independently of the visible table.
    // Grid-only proposals still update the table's state as before.
    if (!confirmed.chart)
      this.api.setState(
        {
          ...this.sourceInitialState,
          ...confirmed.gridState,
        } as GridState,
        ['sideBar'],
      );
    const previewPresentation = this.chartPreviewPresentation();
    // Each saved chart owns its reviewed filters; siblings retain their scopes.
    this.clearChartData();
    this.dashboardRequest?.abort();
    this.dashboardData.set(null);
    this.dashboardSignature = '';
    this.resultView.set('grid');
    if (confirmed.chart) {
      this.savedCharts.update((charts) =>
        charts.map((chart) => ({
          ...chart,
          dataScope: structuredClone(
            chartDataScope(chart, { mode: this.mode(), filterModel: this.model() }),
          ),
        })),
      );
      const filterControls =
        metadata && Object.hasOwn(metadata, 'filterControls')
          ? metadata.filterControls
          : existing?.filterControls;
      const chart: SavedChartState = {
        id: existing?.id ?? crypto.randomUUID(),
        size: existing?.size ?? 'standard',
        ...(filterControls ? { filterControls: structuredClone(filterControls) } : {}),
        plan: structuredClone(confirmed.chart),
        dataScope: {
          mode: this.mode(),
          filterModel: structuredClone(this.proposedFilterModel(confirmed.gridState)),
        },
        description: metadata?.description ?? existing?.description ?? '',
        generationResponse: metadata?.generationResponse ?? existing?.generationResponse,
        presentation: previewPresentation ? structuredClone(previewPresentation) : null,
        data: null,
        loading: false,
        error: '',
        signature: '',
      };
      this.savedCharts.update((charts) =>
        existing ? charts.map((item) => (item.id === chart.id ? chart : item)) : [...charts, chart],
      );
      this.selectSavedChart(chart);
      this.editingChartId = null;
      this.followUpChartId = null;
      this.resetBuilder();
      this.resultView.set('chart');
      this.carouselChartId.set(chart.id);
      this.chartPage.set(
        Math.floor(
          this.savedCharts().findIndex((item) => item.id === chart.id) / this.chartPageSize(),
        ),
      );
      this.closeAssistant();
    }
    if (confirmed.dashboard && this.dashboardsEnabled()) {
      this.dashboardPlan.set(confirmed.dashboard);
      this.resultView.set('dashboard');
    }
    this.signature = this.currentQueryKey();
    this.updateCurrent();
    this.updateDashboard();
    this.updateChart();
    if (!confirmed.chart && !confirmed.propertiesToIgnore.includes('aggregation')) {
      const values = (confirmed.gridState as GridState).aggregation?.aggregationModel ?? [];
      if (values.length) {
        this.api.setColumnsVisible(
          values.map((value) => value.colId),
          true,
        );
        this.pendingAggregateColumn = values[0].colId;
        this.revealPendingAggregate();
      }
    }
  }
  async createCalculatedColumn(): Promise<void> {
    if (this.actionsLocked()) return;
    const result = this.gridResult();
    if (result?.status !== 'calculated_column_proposal' || this.busy()) return;
    const revision = this.revision;
    const controller = new AbortController();
    this.request = controller;
    this.busy.set(true);
    this.busyLabel.set(
      result.plan
        ? 'Creating the column and applying your view'
        : 'Creating your calculated column',
    );
    try {
      const confirmed = await this.data.confirmCalculatedColumn(
        result.id,
        this.mode(),
        this.currentGridState(),
        this.calculatedColumnIds(),
        controller.signal,
      );
      if (revision !== this.revision || !this.api || this.api.isDestroyed()) return;
      const columnSpec = calculatedColumnSpec(confirmed.column, this.source().columns);
      if (this.calculatedColumns().length >= this.calculatedColumnLimit)
        throw new Error('The active calculated-column limit has been reached.');
      if (this.calculatedColumns().some((column) => column.id === columnSpec.id))
        throw new Error('This calculated column is already active.');
      if (confirmed.plan) {
        const confirmedColumns = [...this.columns(), columnSpec];
        prepareReviewedGridView(
          confirmed.plan,
          confirmed.plan.chart
            ? { ...this.currentGridState(), filter: confirmed.plan.gridState['filter'] }
            : this.currentGridState(),
          this.mode(),
          confirmedColumns,
        );
      }
      const previousState = this.api.getState();
      this.finishActive('applied');
      this.gridResult.set(null);
      this.dashboardRequest?.abort();
      this.dashboardSignature = '';
      this.dashboardData.set(null);
      this.dashboardBusy.set(false);
      this.rowCount.set(null);
      this.calculatedColumns.update((columns) => [...columns, confirmed.column]);
      this.data.cache.setCalculatedColumns(this.dataSourceId(), this.calculatedColumns());
      // Evaluate the reviewed arithmetic over cached rows using the shared interpreter.
      this.columnDefs.push(this.columnDefinition(columnSpec, 0));
      this.api.setGridOption('columnDefs', this.columnDefs);
      this.api.setState(previousState);
      if (confirmed.plan) this.applyConfirmedView(confirmed.plan);
      this.draftBaseId = undefined;
      this.draftChart = undefined;
      this.chartPreviewRequest.set(null);
      this.chartPreviewExchange.set(null);
      this.chartPreviewPresentation.set(null);
      this.requestScope.set('fresh');
      this.continuingView.set(false);
      this.refreshSchema();
      this.signature = this.currentQueryKey();
      this.updateCurrent();
      this.refreshServerGrid(this.api);
      if (this.api.getAllDisplayedColumns().some((c) => c.getColId() === confirmed.column.id))
        this.api.ensureColumnVisible(confirmed.column.id, 'start');
      this.busy.set(false);
      this.notice.set(
        confirmed.plan
          ? `Created ${confirmed.column.label} and applied your requested view.`
          : `Created ${confirmed.column.label}. The column is ready to use.`,
      );
      this.addMessage({
        role: 'assistant',
        text: confirmed.plan
          ? `Created ${confirmed.column.label} and applied the reviewed filters and analysis. The results and Snowflake SQL now follow your request.`
          : `Created ${confirmed.column.label}. It is available in your grid for this session.`,
      });
    } catch (e) {
      if (revision === this.revision) this.showConfirmationError(e);
    } finally {
      if (revision === this.revision) this.busy.set(false);
    }
  }
  revealPendingAggregate(): void {
    if (!this.pendingAggregateColumn || !this.api || this.api.isDestroyed()) return;
    const target = this.api.isPivotMode()
      ? this.api
          .getPivotResultColumns()
          ?.find(
            (column) =>
              column.getColDef().pivotValueColumn?.getColId() === this.pendingAggregateColumn,
          )
      : this.api.getColumn(this.pendingAggregateColumn);
    if (!target || !this.api.getAllDisplayedColumns().includes(target)) return;
    this.api.ensureColumnVisible(target, 'start');
    this.pendingAggregateColumn = undefined;
  }
  ngOnDestroy(): void {
    this.explorerContext.attachEditor?.(null);
    this.destroyed = true;
    clearTimeout(this.columnLocateTimer);
    if (this.api && !this.api.isDestroyed())
      this.api.removeEventListener('stateUpdated', this.onGridStateUpdated);
    this.filterInputObserver?.disconnect();
    this.filterHeaderObserver?.disconnect();
    cancelAnimationFrame(this.filterInputSyncFrame);
    cancelAnimationFrame(this.filterCaretFrame);
    clearTimeout(this.filterApplyTimer);
    this.revision++;
    this.resetBuilder();
    for (const controller of this.savedChartRequests.values()) controller.abort();
    this.cancelServerGrid();
    this.assistantViewport.removeEventListener('change', this.assistantViewportChanged);
    window.visualViewport?.removeEventListener('resize', this.assistantVisualViewportChanged);
    window.visualViewport?.removeEventListener('scroll', this.assistantVisualViewportChanged);
    window.removeEventListener('resize', this.assistantVisualViewportChanged);
    this.request?.abort();
    this.previewRequest?.abort();
    this.dashboardRequest?.abort();
    this.nativeCalculationRequest?.abort();
  }
}
