import { Fault } from '../core/domain/engine';
import { normalizeAnalyticsValue } from '../core/domain/analytics-values';
import type { SqlDataset } from '../core/domain/sql-dataset';
import type { StudioQuery, StudioQueryResult } from '../core/domain/studio-query';

/** Detect broken API result aliases, unstable keys and inconsistent snapshots before AG caches them. */
export function validateStudioQueryResult(
  query: StudioQuery,
  result: StudioQueryResult,
  dataset: SqlDataset,
): void {
  const fail = (message: string): never => {
    throw new Fault('QUERY_RESULT', message);
  };
  if (!result || typeof result !== 'object' || !Array.isArray(result.rowData))
    fail('The executor must return a rowData array and explicit record counts.');
  for (const count of [result.rowCount, result.matchedRowCount, result.totalRowCount])
    if (!Number.isSafeInteger(count) || count < 0)
      fail('Executor counts must be nonnegative safe integers.');
  if (result.rowCount > result.matchedRowCount || result.matchedRowCount > result.totalRowCount)
    fail('Route, matching and tenant counts describe inconsistent source snapshots.');
  const { startRow, endRow } = query.request.request;
  const length = Math.min(endRow - startRow, Math.max(0, result.rowCount - startRow));
  if (result.rowData.length !== length)
    fail('The executor block length must match its route count and requested page.');
  if (
    result.pivotResultFields &&
    JSON.stringify(result.pivotResultFields) !== JSON.stringify(query.pivotResultFields)
  )
    fail('Executor pivot result fields must match the compiled discovery schema.');
  const keyColumn = dataset.columns.find(
    (column) => column.id === (query.groupField ?? dataset.rowIdColumn),
  );
  const keys = new Set<string>();
  for (const row of result.rowData) {
    if (!row || typeof row !== 'object' || Array.isArray(row))
      fail('Every executor row must be an object.');
    if (query.groupField) {
      if (!Object.prototype.hasOwnProperty.call(row, query.groupField))
        fail('Group rows must include the compiled group-field alias, including null groups.');
      const value = row[query.groupField];
      if (value !== null && typeof value !== 'string' && typeof value !== 'number')
        fail('Group keys must be strings, numbers or null.');
      // Calculated numeric groups are already typed by the compiled schema; source groups validate dates too.
      const normalized = keyColumn ? normalizeAnalyticsValue(value, keyColumn) : value;
      if (normalized !== value) fail('Group rows must contain canonical typed group values.');
      const count = row['__groupCount'];
      if (
        typeof count !== 'number' ||
        !Number.isSafeInteger(count) ||
        count < 1 ||
        count > result.matchedRowCount
      )
        fail('Group rows must include a positive __groupCount from the filtered source.');
      const key = JSON.stringify(value);
      if (keys.has(key)) fail('An executor block cannot contain duplicate groups.');
      keys.add(key);
    } else if (!query.summarized) {
      const value = row[dataset.rowIdColumn];
      if (
        !keyColumn ||
        (keyColumn.kind === 'text' ? typeof value !== 'string' : typeof value !== 'number') ||
        (typeof value === 'number' &&
          (!Number.isFinite(value) || (Number.isInteger(value) && !Number.isSafeInteger(value))))
      )
        fail('Leaf rows need the configured nonnull, precision-safe row-ID alias.');
      const key = JSON.stringify(value);
      if (keys.has(key)) fail('The executor returned duplicate leaf row IDs within a block.');
      keys.add(key);
    }
  }
}
