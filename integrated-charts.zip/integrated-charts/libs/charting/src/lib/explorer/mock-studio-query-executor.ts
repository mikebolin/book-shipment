import type { AnalyticsRowsRequest } from '../core/domain/analytics-query';
import { ANALYTICS_LIMITS, analyticsPivotKey } from '../core/domain/analytics-query';
import { queryAnalyticsRows, type AnalyticsSourceRow } from '../core/domain/analytics-engine';
import { fromModel } from '../core/domain/grid-model';
import { evaluate, Fault } from '../core/domain/engine';
import type { ColumnSpec } from '../core/domain/schema';
import type {
  SqlStatement,
  SqlValue,
  StudioQuery,
  StudioQueryExecutor,
  StudioQueryResult,
  StudioSummaryRow,
  StudioSummaryStatement,
} from '../core/domain/studio-query';

const pad = (value: number) => String(value).padStart(2, '0');
/** UTC `YYYY-MM-DD HH:mm:ss`, the representation the filter engine and grid share. */
export function utcTimestamp(ms: number): string {
  const d = new Date(ms);
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}`;
}
function compareValues(a: SqlValue, b: SqlValue): number {
  if (a === b) return 0;
  if (a === null) return 1;
  if (b === null) return -1;
  return a < b ? -1 : 1;
}

export interface MockStudioSource {
  rows: readonly AnalyticsSourceRow[];
  columns: readonly ColumnSpec[];
  rowIdColumn: string;
}

/** Frontend fixture executor. Evaluates the validated plan, not a Snowflake SQL interpreter. */
export class MockStudioQueryExecutor implements StudioQueryExecutor {
  constructor(private readonly source: () => MockStudioSource) {}
  private async yield(signal: AbortSignal): Promise<void> {
    signal.throwIfAborted();
    await new Promise<void>((resolve) => setTimeout(resolve, 12));
    signal.throwIfAborted();
  }
  async discoverPivots(
    _statement: SqlStatement,
    input: AnalyticsRowsRequest,
    signal: AbortSignal,
  ): Promise<SqlValue[][]> {
    await this.yield(signal);
    const source = this.source();
    const ast = fromModel(input.request.filterModel, input.mode, source.columns);
    const unique = new Map<string, SqlValue[]>();
    for (const row of source.rows) {
      if (!evaluate(ast, row)) continue;
      const tuple = input.request.pivotCols.map((c) => row[c.id] ?? null);
      unique.set(tuple.map(analyticsPivotKey).join('|'), tuple);
      if (unique.size * input.request.valueCols.length > ANALYTICS_LIMITS.pivotFields)
        throw new Fault(
          'PIVOT_LIMIT',
          `The pivot exceeds ${ANALYTICS_LIMITS.pivotFields} result columns. Filter the data or choose fewer dimensions.`,
        );
    }
    signal.throwIfAborted();
    return [...unique.values()];
  }
  /** Bucket starts align to the epoch like Snowflake TIME_SLICE; null timestamps have no bucket. */
  async summarize(
    statement: StudioSummaryStatement,
    signal: AbortSignal,
  ): Promise<StudioSummaryRow[]> {
    await this.yield(signal);
    const source = this.source();
    const { request } = statement;
    const ast = fromModel(request.filterModel, request.mode, source.columns);
    const size = request.bucket.seconds * 1_000;
    const groups = new Map<string, StudioSummaryRow>();
    for (const row of source.rows) {
      if (!evaluate(ast, row)) continue;
      const started = row[request.bucket.field];
      if (typeof started !== 'string') continue;
      const ms = Date.parse(started.replace(' ', 'T') + 'Z');
      if (!Number.isFinite(ms)) continue;
      const bucket = utcTimestamp(Math.floor(ms / size) * size);
      const values = request.dimensions.map((id) => row[id] ?? null);
      const key = JSON.stringify([bucket, ...values]);
      let entry = groups.get(key);
      if (!entry) {
        entry = { __bucket: bucket, __count: 0 };
        request.dimensions.forEach((id, index) => {
          entry![id] = values[index];
        });
        groups.set(key, entry);
      }
      entry.__count++;
    }
    signal.throwIfAborted();
    return [...groups.values()].sort((a, b) => {
      const byBucket = compareValues(a.__bucket, b.__bucket);
      if (byBucket) return byBucket;
      for (const id of request.dimensions) {
        const order = compareValues(a[id] ?? null, b[id] ?? null);
        if (order) return order;
      }
      return 0;
    });
  }
  async execute(query: StudioQuery, signal: AbortSignal): Promise<StudioQueryResult> {
    await this.yield(signal);
    const source = this.source();
    // Calculated values are materialized in the fixture source before filter/group/sort.
    const result = queryAnalyticsRows(
      null,
      { ...query.request, calculatedColumnIds: [] },
      { ...source, rawGroupKeys: true, includeGroupCount: true },
      signal,
    );
    const ast = fromModel(query.request.request.filterModel, query.request.mode, source.columns);
    let matchedRowCount = 0;
    for (const row of source.rows) if (evaluate(ast, row)) matchedRowCount++;
    signal.throwIfAborted();
    return { ...result, matchedRowCount, totalRowCount: source.rows.length };
  }
}
