import { injectUiState } from '../core/state/index';
import { DOCUMENT } from '@angular/common';
import { Injectable, InjectionToken, computed, inject } from '@angular/core';
import { createChartTheme, createGridTheme, type AppTheme } from './app-theme';
import { MATERIAL_THEMES } from './material-theme-presets';

export const APP_THEMES = new InjectionToken<readonly AppTheme[]>('Application Material themes', {
  providedIn: 'root',
  factory: () => MATERIAL_THEMES,
});
export const THEME_STORAGE_KEY = 'data-explorer.material-theme';
export const DEFAULT_THEME_ID = 'azure-blue';

/** One theme owner for document surfaces, overlay panels, every grid and chart canvas. */
@Injectable({ providedIn: 'root' })
export class AppThemeService {
  private readonly reactiveState = injectUiState('AppThemeService');

  readonly choices = inject(APP_THEMES);
  private readonly document = inject(DOCUMENT);
  private readonly selected = this.reactiveState.signal(
    this.choices.find((theme) => theme.id === DEFAULT_THEME_ID)?.id ?? this.choices[0]!.id,
  );
  readonly selectedTheme = this.selected.asReadonly();
  readonly current = computed(() => this.choices.find((theme) => theme.id === this.selected())!);
  readonly gridTheme = computed(() => createGridTheme(this.current()));
  readonly chartTheme = computed(() => createChartTheme(this.current()));
  readonly chartThemeName = computed(() => `app-material-${this.selectedTheme()}`);
  readonly customChartThemes = Object.fromEntries(
    this.choices.map((theme) => [`app-material-${theme.id}`, createChartTheme(theme)]),
  );
  readonly loading = this.reactiveState.signal(false);
  readonly error = this.reactiveState.signal('');
  private generation = 0;
  private appliedTokens = new Set<string>();

  constructor() {
    this.applyTokens(this.current());
  }

  setTheme(id: string): void {
    const theme = this.choices.find((item) => item.id === id);
    if (!theme || (id === this.selected() && !this.loading())) return;
    const generation = ++this.generation;
    const link = this.document.createElement('link');
    link.rel = 'stylesheet';
    link.href = `assets/material-themes/${theme.id}.css`;
    // Load before swapping so selecting another theme never leaves an unstyled page.
    link.media = 'not all';
    this.loading.set(true);
    this.error.set('');
    link.onload = () => {
      // Activating a previously non-matching media query can emit another load
      // event. Handle completion once so a second event cannot remove this link.
      link.onload = null;
      link.onerror = null;
      if (generation !== this.generation) {
        link.remove();
        return;
      }
      const previous = this.document.getElementById('application-material-theme');
      link.id = 'application-material-theme';
      link.media = 'all';
      if (previous !== link) previous?.remove();
      this.applyTokens(theme);
      this.selected.set(theme.id);
      this.loading.set(false);
    };
    link.onerror = () => {
      link.remove();
      if (generation !== this.generation) return;
      this.loading.set(false);
      this.error.set('The theme could not be loaded. Please try again.');
    };
    // Keep the shipped theme before application/component styles. Appending it
    // after Angular's runtime style tags changes equal-specificity density and
    // outline rules every time the user switches a palette.
    const active = this.document.getElementById('application-material-theme');
    this.document.head.insertBefore(link, active ?? this.document.head.firstChild);
  }

  private applyTokens(theme: AppTheme): void {
    const root = this.document.documentElement;
    root.dataset['appTheme'] = theme.id;
    root.dataset['themeMode'] = theme.dark ? 'dark' : 'light';
    root.style.colorScheme = theme.dark ? 'dark' : 'light';
    // Legacy Material presets expose fewer system tokens. Never retain colors from
    // the previous palette when switching between Material generations.
    for (const name of this.appliedTokens)
      if (!(name in theme.tokens)) root.style.removeProperty(`--mat-sys-${name}`);
    for (const [name, value] of Object.entries(theme.tokens))
      root.style.setProperty(`--mat-sys-${name}`, value);
    this.appliedTokens = new Set(Object.keys(theme.tokens));
    theme.colors.forEach((color, index) =>
      root.style.setProperty(`--app-chart-${index + 1}`, color),
    );
  }
}
