import type { ColumnSpec } from '../core/domain/schema';
import type { ChartPlan } from '../core/domain/integrated-chart';
import { guideFields, isRawChart, isTimeChart } from './chart-guide';

export type ProfileRow = Readonly<Record<string, unknown>>;
export interface ObservedChartField {
  count: number;
  distinct: number;
  magnitude: number;
  minimum: number;
  maximum: number;
}
export interface ChartDataProfile {
  rows: readonly ProfileRow[];
  fields: ReadonlyMap<string, ObservedChartField>;
}

/** Inspect only the bounded real-record sample. Values are never rescaled or fabricated. */
export function profileChartRows(
  columns: readonly ColumnSpec[],
  rows: readonly ProfileRow[],
): ChartDataProfile {
  const fields = new Map<string, ObservedChartField>();
  for (const column of columns) {
    let count = 0;
    let minimum = Infinity;
    let maximum = -Infinity;
    const distinct = new Set<unknown>();
    const magnitudes: number[] = [];
    for (const row of rows) {
      const value = row[column.id];
      if (value === null || value === undefined || value === '') continue;
      if (column.kind === 'number' && (typeof value !== 'number' || !Number.isFinite(value)))
        continue;
      count++;
      distinct.add(value);
      const number =
        column.kind === 'number'
          ? (value as number)
          : ['date', 'datetime'].includes(column.kind)
            ? Date.parse(String(value))
            : NaN;
      if (Number.isFinite(number)) {
        minimum = Math.min(minimum, number);
        maximum = Math.max(maximum, number);
        if (column.kind === 'number') magnitudes.push(Math.abs(number));
      }
    }
    magnitudes.sort((a, b) => a - b);
    fields.set(column.id, {
      count,
      distinct: distinct.size,
      magnitude: magnitudes[Math.floor(magnitudes.length / 2)] ?? 0,
      minimum,
      maximum,
    });
  }
  return { rows, fields };
}

export function preferredAggregation(column?: ColumnSpec): 'sum' | 'avg' {
  return column &&
    /\b(?:prices?|ratios?|percent(?:age)?|rates?|yield|temperature|score|duration|risk|age)\b/i.test(
      `${column.label} ${column.description}`,
    )
    ? 'avg'
    : 'sum';
}

/** Rank real variation, coverage and readable scales ahead of a field's attractive name. */
export function observedMeasureScore(column: ColumnSpec, profile: ChartDataProfile): number {
  const field = profile.fields.get(column.id);
  if (!field?.count) return -1000;
  return (
    (field.distinct > 1 ? 35 : -100) +
    (field.count < profile.rows.length / 2 ? -60 : 0) +
    (20 * field.count) / Math.max(1, profile.rows.length) +
    (field.magnitude > 0 ? 5 : -25)
  );
}

export function comparableObservedMeasures(
  first: ColumnSpec,
  next: ColumnSpec,
  profile: ChartDataProfile,
): boolean {
  const left = profile.fields.get(first.id);
  const right = profile.fields.get(next.id);
  if (
    !left ||
    !right ||
    left.distinct < 2 ||
    right.distinct < 2 ||
    left.magnitude <= 0 ||
    right.magnitude <= 0
  )
    return false;
  if (Math.min(left.count, right.count) / Math.max(left.count, right.count) < 0.6) return false;
  let compared = 0;
  let different = 0;
  for (const row of profile.rows) {
    const a = row[first.id];
    const b = row[next.id];
    if (typeof a !== 'number' || typeof b !== 'number') continue;
    compared++;
    if (Math.abs(a - b) > Math.max(Math.abs(a), Math.abs(b), 1) * 0.005) different++;
  }
  if (!compared || different / compared < 0.1) return false;
  const total = preferredAggregation(first) === 'sum';
  const ratio =
    (left.magnitude * (total ? left.count : 1)) / (right.magnitude * (total ? right.count : 1));
  return ratio >= 1 / 8 && ratio <= 8 && preferredAggregation(first) === preferredAggregation(next);
}

export function observedCategoryScore(
  column: ColumnSpec,
  plan: ChartPlan,
  profile: ChartDataProfile,
): number {
  const field = profile.fields.get(column.id);
  if (!field?.count || field.distinct < 2) return -200;
  if (isTimeChart(plan.type)) return 35 + Math.min(20, field.distinct);
  let score = field.distinct <= 12 ? 45 : field.distinct <= 25 ? 25 : -30;
  // Equal category totals create a poor demonstration even when records vary.
  // Prefer an actual grouping whose values reveal a useful difference.
  const groups = new Map<string, { sum: number; count: number }>();
  for (const row of profile.rows) {
    const value = plan.measureColumnIds.length ? row[plan.measureColumnIds[0]!] : 1;
    if (typeof value !== 'number' || !Number.isFinite(value)) continue;
    const key = String(row[column.id] ?? '(Blank)');
    const group = groups.get(key) ?? { sum: 0, count: 0 };
    group.sum += value;
    group.count++;
    groups.set(key, group);
  }
  const values = [...groups.values()].map((group) =>
    plan.aggregation === 'avg' ? group.sum / group.count : group.sum,
  );
  const maximum = Math.max(...values.map(Math.abs), 0);
  const spread = maximum ? (Math.max(...values) - Math.min(...values)) / maximum : 0;
  score += Math.min(30, spread * 30);
  return score;
}

export function observedTimeBucket(
  column: ColumnSpec | undefined,
  profile: ChartDataProfile,
): ChartPlan['timeBucket'] {
  if (!column || !['date', 'datetime'].includes(column.kind)) return null;
  const field = profile.fields.get(column.id);
  const days = field ? (field.maximum - field.minimum) / 86_400_000 : Infinity;
  return days <= 62 ? 'day' : days <= 730 ? 'month' : days <= 3650 ? 'quarter' : 'year';
}

export function chartObservationNote(
  plan: ChartPlan,
  columns: readonly ColumnSpec[],
  profile: ChartDataProfile,
): string {
  if (!profile.rows.length)
    return 'No records match these filters. Change the filters to see a preview.';
  const fields = guideFields(columns);
  if (plan.measureColumnIds.some((id) => (profile.fields.get(id)?.distinct ?? 0) < 2))
    return 'Some selected values barely vary in these records. Try another measure or date range.';
  if (!isRawChart(plan.type) && plan.measureColumnIds.length > 1) {
    const first = columns.find((column) => column.id === plan.measureColumnIds[0]);
    const comparison =
      first &&
      plan.measureColumnIds.slice(1).find((id) => {
        const next = columns.find((column) => column.id === id)!;
        return (
          fields.metadata.get(id)?.unit === fields.metadata.get(first.id)?.unit &&
          !comparableObservedMeasures(first, next, profile)
        );
      });
    if (comparison && first) {
      const next = columns.find((column) => column.id === comparison)!;
      const left = profile.fields.get(first.id)!;
      const right = profile.fields.get(next.id)!;
      if (Math.min(left.count, right.count) / Math.max(left.count, right.count) < 0.6)
        return 'One series is missing values in many records. Choose another measure for an easier comparison.';
      if (preferredAggregation(first) !== preferredAggregation(next))
        return 'These fields usually use different calculations. Compare totals with totals, or averages with averages.';
      const total = plan.aggregation === 'sum';
      const ratio =
        (left.magnitude * (total ? left.count : 1)) / (right.magnitude * (total ? right.count : 1));
      if (ratio < 1 / 8 || ratio > 8)
        return 'These values have different scales. Try a 100% style or a combination with a separate axis.';
      return 'These fields contain nearly the same values. Choose a different measure to show a clearer comparison.';
    }
  }
  return '';
}
