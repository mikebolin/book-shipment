import { injectUiState } from '../core/state/index';
import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  OnDestroy,
  Output,
  Input,
  computed,
} from '@angular/core';
import { DecimalPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { parseLocalJsonFile } from './local-json-dataset';
import type { LocalDataset } from './client-data-sources';
import type { GridReviewPreview } from './demo-grid-preview-loader';
import { ExampleDataTableComponent } from './example-data-table.component';
import { DatasetAnalysisComponent } from './dataset-analysis.component';
import type { LocalDataRecipe } from './local-data-recipes';

@Component({
  selector: 'app-json-import',
  standalone: true,
  imports: [
    DecimalPipe,
    FormsModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    MatFormFieldModule,
    MatInputModule,
    ExampleDataTableComponent,
    DatasetAnalysisComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section aria-labelledby="import-title" [attr.aria-busy]="busy()">
      <div class="import-heading">
        <div>
          <h3 id="import-title">Import your data</h3>
          <p>Choose a JSON array of objects or a CSV file with a header row.</p>
        </div>
        <div class="actions">
          <input
            #fileInput
            type="file"
            accept=".json,.csv,application/json,text/csv"
            aria-label="JSON or CSV data file"
            hidden
            (change)="choose($event)"
          />
          @if (dataset() || busy()) {
            <button
              mat-button
              type="button"
              matTooltip="Choose JSON or CSV file"
              aria-label="Choose JSON or CSV file"
              (click)="fileInput.click()"
            >
              <mat-icon>upload_file</mat-icon>Choose file
            </button>
          }
          @if (showBack) {
            <button
              mat-icon-button
              type="button"
              matTooltip="Back to examples"
              aria-label="Back to examples"
              (click)="cancelled.emit()"
            >
              <mat-icon>arrow_back</mat-icon>
            </button>
          }
        </div>
      </div>
      <p class="local-note">
        The file stays in this browser and is available while this explorer is open.
      </p>
      @if (busy()) {
        <p role="status">{{ progress() }}</p>
      }
      @if (error()) {
        <p class="error" role="alert">{{ error() }}</p>
      }
      @if (dataset(); as data) {
        <div class="import-summary">
          <mat-form-field appearance="outline" subscriptSizing="dynamic"
            ><mat-label>Data source name</mat-label
            ><input
              matInput
              aria-label="Data source name"
              maxlength="80"
              [ngModel]="name()"
              (ngModelChange)="name.set($event)"
          /></mat-form-field>
          <span
            >{{ data.rows.length | number }} records ·
            {{ data.originalFields.length | number }} inferred fields
            @if (data.preparedRecipes; as recipes) {
              · {{ recipes.length }} generated examples
            }
          </span>
          <button
            mat-button
            class="confirm"
            type="button"
            matTooltip="Explore all imported records"
            aria-label="Explore data"
            [disabled]="busy() || !name().trim()"
            (click)="confirm()"
          >
            <mat-icon>arrow_forward</mat-icon>Explore data
          </button>
        </div>
        <app-dataset-analysis [dataset]="data" (useChart)="exploreChart($event)" />
        <details class="field-details">
          <summary>
            Fields and data types <span>{{ data.originalFields.length }} fields</span>
          </summary>
          <div class="inferred-fields" aria-label="Inferred field types">
            @for (field of data.originalFields; track field.columnId) {
              <div>
                <strong>{{ field.originalName }}</strong
                ><span
                  >{{ field.inferredType }}{{ field.identifier ? ' · key' : ''
                  }}{{ field.nullable ? ' · nullable' : '' }}</span
                >
              </div>
            }
          </div>
        </details>
        @if (data.warnings.length) {
          <ul class="notes">
            @for (warning of data.warnings; track $index) {
              <li>{{ warning }}</li>
            }
          </ul>
        }
        <p class="sample-caption">
          Review the first {{ data.rows.length > 20 ? 20 : data.rows.length }} records. Add the
          source to explore every record and examples generated from its fields.
        </p>
        @if (sample(); as preview) {
          <app-example-data-table [preview]="preview" />
        }
      } @else if (!busy()) {
        <button
          type="button"
          class="empty-import"
          [class.dragging]="dragging()"
          (click)="fileInput.click()"
          (dragover)="$event.preventDefault(); dragging.set(true)"
          (dragleave)="leaveDrop($event)"
          (drop)="drop($event)"
          aria-label="Choose a CSV or JSON file"
        >
          <span class="drop-icon"><mat-icon>upload_file</mat-icon></span>
          <strong>Choose a CSV or JSON file</strong>
          <span class="drop-hint">or drag and drop it here</span>
          <span class="drop-formats"><span>CSV</span><span>JSON</span></span>
          <span class="drop-detail">Preview your records, review the fields, then explore.</span>
        </button>
        <p class="import-format-note">
          CSV with a header row or a JSON array of objects. Files up to 800 MiB.
        </p>
      }
    </section>
  `,
  styles: [
    `
      :host {
        display: block;
        min-width: 0;
        max-width: 1000px;
        margin: 0 auto;
      }
      section {
        color: var(--mat-sys-on-surface);
        font-size: 13px;
      }
      .import-heading,
      .import-summary {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
      }
      h3 {
        margin: 0 0 6px;
        font-size: 20px;
        font-weight: 500;
      }
      p {
        line-height: 1.6;
      }
      .import-heading p {
        margin: 0;
        color: var(--mat-sys-on-surface-variant);
      }
      .actions {
        display: flex;
        flex-shrink: 0;
      }
      .local-note,
      .sample-caption,
      .notes {
        color: var(--mat-sys-on-surface-variant);
        font-size: 12px;
      }
      .import-summary {
        flex-wrap: wrap;
        margin: 22px 0 16px;
      }
      mat-form-field {
        flex: 1;
        min-width: 200px;
      }
      .inferred-fields {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(170px, 1fr));
        max-height: 220px;
        overflow: auto;
        gap: 8px;
      }
      .field-details {
        margin: 18px 0;
      }
      .field-details summary {
        cursor: pointer;
        font-weight: 500;
        margin-bottom: 12px;
      }
      .field-details summary span {
        font-weight: 400;
        color: var(--mat-sys-on-surface-variant);
        margin-left: 8px;
        font-size: 12px;
      }
      .inferred-fields > div {
        padding: 10px;
        border: 1px solid var(--mat-sys-outline-variant);
        border-radius: 8px;
        min-width: 0;
        overflow-wrap: anywhere;
      }
      strong {
        display: block;
        font-weight: 500;
        margin-bottom: 5px;
      }
      .inferred-fields span {
        color: var(--mat-sys-on-surface-variant);
        font-size: 11px;
      }
      .notes {
        padding-left: 20px;
        line-height: 1.6;
      }
      .error {
        color: var(--mat-sys-error);
      }
      .empty-import {
        width: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 10px;
        padding: 48px 24px;
        text-align: center;
        color: var(--mat-sys-on-surface);
        font: inherit;
        cursor: pointer;
        background: var(--mat-sys-surface-container-low);
        border: 1px dashed var(--mat-sys-outline-variant);
        border-radius: 16px;
        margin-top: 28px;
        transition:
          border-color 140ms,
          background 140ms;
      }
      .empty-import:hover,
      .empty-import.dragging {
        border-color: var(--mat-sys-primary);
        background: var(--mat-sys-primary-container);
      }
      .empty-import:focus-visible {
        outline: 2px solid var(--mat-sys-primary);
        outline-offset: 4px;
      }
      .empty-import strong {
        font-size: 18px;
        font-weight: 600;
        margin: 8px 0 0;
      }
      .drop-icon {
        display: grid;
        place-items: center;
        width: 60px;
        height: 60px;
        border-radius: 18px;
        background: var(--mat-sys-surface);
        border: 1px solid var(--mat-sys-outline-variant);
        color: var(--mat-sys-primary);
      }
      .drop-icon mat-icon {
        width: 30px;
        height: 30px;
        font-size: 30px;
      }
      .drop-hint,
      .drop-detail {
        color: var(--mat-sys-on-surface-variant);
        font-size: 13px;
      }
      .drop-detail {
        font-size: 12px;
        margin-top: 6px;
      }
      .drop-formats {
        display: flex;
        gap: 8px;
        margin-top: 14px;
      }
      .drop-formats span {
        font-size: 10px;
        font-weight: 600;
        letter-spacing: 0.08em;
        padding: 4px 9px;
        border-radius: 5px;
        border: 1px solid var(--mat-sys-outline-variant);
        background: var(--mat-sys-surface);
      }
      .import-format-note {
        font-size: 12px;
        text-align: center;
        color: var(--mat-sys-on-surface-variant);
        margin: 14px 0 0;
      }
      @media (max-width: 600px) {
        .import-heading {
          align-items: flex-start;
        }
        .inferred-fields {
          grid-template-columns: repeat(2, minmax(0, 1fr));
        }
      }
    `,
  ],
})
export class JsonImportComponent implements OnDestroy {
  private readonly reactiveState = injectUiState('JsonImportComponent');

  @Input() showBack = true;
  @Output() imported = new EventEmitter<LocalDataset>();
  @Output() cancelled = new EventEmitter<void>();
  readonly busy = this.reactiveState.signal(false);
  readonly progress = this.reactiveState.signal('');
  readonly error = this.reactiveState.signal('');
  readonly dataset = this.reactiveState.signal<LocalDataset | null>(null);
  readonly name = this.reactiveState.signal('');
  readonly dragging = this.reactiveState.signal(false);
  private controller?: AbortController;
  readonly sample = computed<GridReviewPreview | null>(() => {
    const data = this.dataset();
    if (!data) return null;
    const columns = data.metadata.columns.filter((column) => column.id !== 'id').slice(0, 8);
    return {
      prompt: '',
      status: 'ready',
      filterText: '',
      operations: [],
      columns,
      rows: data.rows.slice(0, 20),
      rowCount: data.rows.length,
      previewKind: 'unchanged-rows',
      explanation: 'Uploaded data sample.',
    };
  });
  async choose(event: Event): Promise<void> {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    input.value = '';
    if (!file) return;
    await this.readFile(file);
  }
  leaveDrop(event: DragEvent): void {
    if (!(event.currentTarget as HTMLElement).contains(event.relatedTarget as Node | null))
      this.dragging.set(false);
  }
  async drop(event: DragEvent): Promise<void> {
    event.preventDefault();
    this.dragging.set(false);
    const files = event.dataTransfer?.files;
    if (!files?.length) return;
    if (files.length > 1) {
      this.error.set('Choose one file at a time.');
      return;
    }
    await this.readFile(files[0]);
  }
  private async readFile(file: File): Promise<void> {
    if (!/\.(json|csv)$/i.test(file.name)) {
      this.error.set('Choose a file ending in .csv or .json.');
      return;
    }
    this.controller?.abort();
    const controller = new AbortController();
    this.controller = controller;
    this.busy.set(true);
    this.error.set('');
    this.dataset.set(null);
    this.progress.set('Reading data file…');
    try {
      const data = await parseLocalJsonFile(file, {
        signal: controller.signal,
        onProgress: (progress) => {
          this.progress.set(
            progress.phase === 'reading'
              ? 'Reading data file…'
              : progress.phase === 'parsing'
                ? 'Parsing records…'
                : progress.phase === 'recipes'
                  ? 'Preparing examples from your data…'
                  : 'Inferring field types…',
          );
        },
      });
      if (controller.signal.aborted) return;
      this.dataset.set(data);
      this.name.set(data.metadata.label);
    } catch (error) {
      if (!controller.signal.aborted)
        this.error.set(error instanceof Error ? error.message : 'Could not read this data file.');
    } finally {
      if (!controller.signal.aborted) this.busy.set(false);
    }
  }
  confirm(): void {
    const data = this.dataset(),
      label = this.name().trim();
    if (data && label && !this.busy())
      this.imported.emit({ ...data, metadata: { ...data.metadata, label } });
  }
  exploreChart(recipe: LocalDataRecipe): void {
    const data = this.dataset(),
      label = this.name().trim();
    if (data && label && !this.busy())
      this.imported.emit({
        ...data,
        metadata: { ...data.metadata, label },
        initialAnalysisChart: recipe,
      });
  }
  ngOnDestroy(): void {
    this.controller?.abort();
  }
}
