import type { ColumnSpec } from '../core/domain/schema';
import {
  calculatedColumnSpec,
  evaluateCalculation,
  type CalculationExpression,
  type CalculatedColumnDefinition,
} from '../core/domain/calculated-columns';
import type { Account, GridModel, Mode } from '../core/domain/contracts';
import type { ClientDataSourceId } from './client-data-sources';
import { evaluate, Fault } from '../core/domain/engine';
import { fromModel } from '../core/domain/grid-model';
import { assertSetFiltersEnabled } from '../core/domain/set-filters';
import { queryAnalyticsRows, type AnalyticsSourceRow } from '../core/domain/analytics-engine';
import type { AnalyticsRowsRequest } from '../core/domain/analytics-query';
import {
  buildChartDataset,
  chartRequestSchema,
  resolveChartTimeRange,
} from '../core/domain/chart-data';
import { suggestCharts } from '../core/domain/chart-suggestion-engine';
import { buildDashboardDataset, dashboardRequestSchema } from '../core/domain/dashboard-data';
import type { StreamRow } from './ndjson-row-stream';

const LOCAL_DATA_PATHS = new Set([
  'analytics/rows',
  'analytics/chart',
  'analytics/chart-suggestions',
  'analytics/dashboard',
  'query-preview',
  'execute-query',
]);

interface CachedSource {
  rows: readonly StreamRow[];
  columns: readonly ColumnSpec[];
  cohort?: { signature: string; rows: AnalyticsSourceRow[]; columns: ColumnSpec[] };
  materialized?: { signature: string; rows: readonly StreamRow[] };
  chartSample?: { signature: string; rows: readonly StreamRow[]; matchedRowCount: number };
}

const calculationFields = new WeakMap<CalculationExpression, string[]>();

/** Preserve the evaluator's own-property boundary while reading compact streamed records. */
export function evaluateCachedCalculation(
  expression: CalculationExpression,
  row: Readonly<Record<string, unknown>>,
  columns: readonly ColumnSpec[],
): number | null {
  let fields = calculationFields.get(expression);
  if (!fields) {
    const collected = new Set<string>();
    const visited = new Set<CalculationExpression>();
    const collect = (node: CalculationExpression) => {
      if (!node || visited.has(node) || visited.size > 31) return;
      visited.add(node);
      if (node.kind === 'field') collected.add(node.field);
      if (node.kind === 'binary') {
        collect(node.left);
        collect(node.right);
      }
    };
    collect(expression);
    fields = [...collected];
    calculationFields.set(expression, fields);
  }
  const operands: Record<string, unknown> = Object.create(null);
  for (const field of fields) operands[field] = row[field];
  return evaluateCalculation(expression, operands, columns);
}

/**
 * Demo-only browser memory cache. A source enters the cache only after a complete
 * authorized stream. Data operations never fall back to another HTTP request.
 * Reloading the page starts a fresh cache; switching grids reuses loaded sources.
 */
export class BrowserDataCache {
  private readonly sources = new Map<ClientDataSourceId, CachedSource>();
  private readonly calculations = new Map<ClientDataSourceId, CalculatedColumnDefinition[]>();

  handles(path: string): boolean {
    return LOCAL_DATA_PATHS.has(path);
  }

  setRows(
    source: ClientDataSourceId,
    rows: readonly StreamRow[],
    columns: readonly ColumnSpec[],
  ): void {
    if (!columns.length) throw new Error('Local data requires its inferred schema before caching.');
    this.sources.set(source, { rows, columns });
  }

  getRows(source: ClientDataSourceId): readonly StreamRow[] | undefined {
    return this.sources.get(source)?.rows;
  }

  getGridRows(source: ClientDataSourceId): readonly StreamRow[] | undefined {
    const cached = this.sources.get(source);
    return cached ? this.materialize(cached, this.calculations.get(source) ?? []) : undefined;
  }

  /** A bounded, reproducible sample across the entire matching cohort, without copying full rows. */
  async sampleChartRows(
    source: ClientDataSourceId,
    input: { mode: Mode; filterModel: GridModel; calculatedColumnIds?: string[] },
    signal?: AbortSignal,
  ): Promise<{ rows: readonly StreamRow[]; matchedRowCount: number }> {
    signal?.throwIfAborted();
    assertSetFiltersEnabled(input.filterModel, false);
    const cached = this.sources.get(source);
    if (!cached) throw new Error('The data is still loading.');
    const definitions = this.definitions(source, input.calculatedColumnIds);
    const signature = JSON.stringify([input.mode, input.filterModel, definitions]);
    if (cached.chartSample?.signature === signature) return cached.chartSample;
    const columns = [
      ...cached.columns,
      ...definitions.map((column) => calculatedColumnSpec(column, cached.columns)),
    ];
    const filter = fromModel(input.filterModel, input.mode, columns);
    const rows = this.materialize(cached, definitions);
    const sample: StreamRow[] = [];
    const sampleSize = 256;
    let count = 0;
    let random = 0x51f15e;
    for (let offset = 0; offset < rows.length; offset += 512) {
      // Yield between small chunks so gallery search, scrolling and cancellation stay responsive.
      await new Promise<void>((resolve) => setTimeout(resolve, 0));
      signal?.throwIfAborted();
      for (let index = offset; index < Math.min(rows.length, offset + 512); index++) {
        const row = rows[index]!;
        if (!evaluate(filter, row as AnalyticsSourceRow)) continue;
        count++;
        if (sample.length < sampleSize) sample.push(row);
        else {
          random ^= random << 13;
          random ^= random >>> 17;
          random ^= random << 5;
          const slot = Math.floor(((random >>> 0) / 0x100000000) * count);
          if (slot < sampleSize) sample[slot] = row;
        }
      }
    }
    signal?.throwIfAborted();
    const result = { signature, rows: sample, matchedRowCount: count };
    if (this.sources.get(source) === cached) cached.chartSample = result;
    return result;
  }

  private materialize(
    cached: CachedSource,
    definitions: readonly CalculatedColumnDefinition[],
  ): readonly StreamRow[] {
    if (!definitions.length) return cached.rows;
    const signature = JSON.stringify(definitions);
    if (cached.materialized?.signature === signature) return cached.materialized.rows;
    const rows = cached.rows.map((row) => {
      const result: StreamRow = Object.create(row);
      for (const definition of definitions) {
        Object.defineProperty(result, definition.id, {
          value: evaluateCachedCalculation(definition.expression, row, cached.columns),
          enumerable: true,
          writable: true,
          configurable: true,
        });
      }
      return result;
    });
    cached.materialized = { signature, rows };
    return rows;
  }

  setCalculatedColumns(
    source: ClientDataSourceId,
    definitions: readonly CalculatedColumnDefinition[],
  ): void {
    const previous = this.calculations.get(source) ?? [];
    if (JSON.stringify(previous) === JSON.stringify(definitions)) return;
    this.calculations.set(source, [...definitions]);
    const cached = this.sources.get(source);
    if (cached) {
      cached.cohort = undefined;
      cached.materialized = undefined;
      cached.chartSample = undefined;
    }
  }

  addCalculatedColumn(source: ClientDataSourceId, definition: CalculatedColumnDefinition): void {
    const previous = this.calculations.get(source) ?? [];
    this.setCalculatedColumns(source, [
      ...previous.filter((column) => column.id !== definition.id),
      definition,
    ]);
  }

  getCalculatedColumns(source: ClientDataSourceId): readonly CalculatedColumnDefinition[] {
    return this.calculations.get(source) ?? [];
  }

  private definitions(
    source: ClientDataSourceId,
    ids: readonly string[] = [],
  ): CalculatedColumnDefinition[] {
    const known = new Map(
      (this.calculations.get(source) ?? []).map((column) => [column.id, column]),
    );
    return ids.map((id) => {
      const column = known.get(id);
      if (!column)
        throw new Fault(
          'CALCULATED_COLUMNS',
          'This calculated column is not available in the browser cache.',
        );
      return column;
    });
  }

  private cohort(
    cached: CachedSource,
    input: { mode: Mode; filterModel: GridModel; calculatedColumnIds?: string[] },
    definitions: CalculatedColumnDefinition[],
  ): { rows: AnalyticsSourceRow[]; columns: ColumnSpec[] } {
    const signature = JSON.stringify([input.mode, input.filterModel, definitions]);
    if (cached.cohort?.signature === signature) return cached.cohort;
    const columns = [
      ...cached.columns,
      ...definitions.map((column) => calculatedColumnSpec(column, cached.columns)),
    ];
    const filter = fromModel(input.filterModel, input.mode, columns);
    // Schema fields are text/number/date. StreamRow also permits boolean metadata;
    // it remains untouched and is never interpreted as a numeric measure.
    const rows = (this.materialize(cached, definitions) as readonly AnalyticsSourceRow[]).filter(
      (row) => evaluate(filter, row),
    );
    cached.cohort = { signature, rows, columns };
    return cached.cohort;
  }

  query(source: ClientDataSourceId, path: string, body: unknown, signal?: AbortSignal): unknown {
    signal?.throwIfAborted();
    assertSetFiltersEnabled(body, false);
    if (!this.handles(path)) throw new Error('Not a browser data operation: ' + path);
    const input = (body ?? {}) as { calculatedColumnIds?: string[] };
    const definitions = this.definitions(source, input.calculatedColumnIds);
    if (path === 'query-preview') {
        if (!this.sources.has(source))
          throw new Error('Import this local dataset again before querying it.');
        return {
          sql: '-- Imported JSON is filtered and aggregated in this browser. No SQL is executed.',
          binds: [],
          countSql: '',
          countBinds: [],
          scope: 'filtered-source-rows',
        };
    }
    const cached = this.sources.get(source);
    if (!cached)
      throw new Fault(
        'DEMO_DATA_LOADING',
        'Wait for this grid to finish loading its data, then try again.',
      );
    if (path === 'analytics/rows' || path === 'execute-query') {
      const request = body as AnalyticsRowsRequest;
      const { rows, columns } = this.cohort(
        cached,
        {
          mode: request.mode,
          filterModel: request.request.filterModel,
          calculatedColumnIds: request.calculatedColumnIds,
        },
        definitions,
      );
      return queryAnalyticsRows(
        null,
        {
          mode: request.mode,
          calculatedColumnIds: [],
          request: Object.assign(
            { rowGroupCols: [], valueCols: [], pivotCols: [], pivotMode: false, groupKeys: [] },
            request.request,
            { filterModel: request.mode === 'columns' ? {} : null },
          ),
        },
        { columns, rows, preserveRowReferences: true },
        signal,
      );
    }
    if (path === 'analytics/dashboard') {
      const request = dashboardRequestSchema.parse(body);
      const { rows } = this.cohort(cached, request, definitions);
      const result = buildDashboardDataset(request, rows as Account[]);
      result.notes.push('Computed locally from the streamed browser cache.');
      return result;
    }
    const request =
      path === 'analytics/chart'
        ? chartRequestSchema.parse(body)
        : chartRequestSchema.omit({ plan: true }).strict().parse(body);
    const { rows, columns } = this.cohort(cached, request, definitions);
    // The server's 50,000-row service limit does not apply to an already loaded
    // browser cohort. Every cached matching row participates in the calculation.
    const capacity = Math.max(cached.rows.length, 1);
    const result =
      path === 'analytics/chart'
        ? buildChartDataset(
            // A zero-filled time axis follows the filter's bounds on its category column.
            resolveChartTimeRange(
              chartRequestSchema.parse(body).plan,
              fromModel(request.filterModel, request.mode, columns),
            ),
            columns,
            rows,
            capacity,
          )
        : suggestCharts(columns, rows, capacity);
    result.notes.push('Computed locally from the streamed browser cache.');
    signal?.throwIfAborted();
    return { ...result, source: 'mock', scope: 'filtered-source-rows' };
  }
}
