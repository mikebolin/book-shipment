import { injectUiState } from '../core/state/index';
import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTooltipModule } from '@angular/material/tooltip';
import type { ColumnSpec } from '../core/domain/schema';

@Component({
  selector: 'app-chart-field-picker',
  standalone: true,
  imports: [
    FormsModule,
    MatAutocompleteModule,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatTooltipModule,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <mat-form-field floatLabel="always" appearance="outline" subscriptSizing="dynamic">
      <mat-label>{{ label }}</mat-label>
      <mat-icon matPrefix aria-hidden="true">search</mat-icon>
      <input
        matInput
        type="text"
        autocomplete="off"
        [attr.aria-label]="ariaLabel || label"
        [disabled]="disabled"
        [ngModel]="search()"
        (ngModelChange)="editSearch($event)"
        (blur)="touched.set(true)"
        [errorStateMatcher]="selectionMatcher"
        [matAutocomplete]="fields"
        placeholder="Search suitable fields"
        (focus)="selectInput($event)"
      />
      @if (selectedField(); as field) {
        <button
          mat-icon-button
          matSuffix
          type="button"
          [disabled]="disabled"
          [attr.aria-label]="'About ' + field.label"
          [matTooltip]="field.description || field.kind"
        >
          <mat-icon>info_outline</mat-icon>
        </button>
      }
      <mat-autocomplete #fields="matAutocomplete" (optionSelected)="select($event.option.value)">
        @for (column of matches(); track column.id) {
          <mat-option [value]="column.id"
            ><span>{{ column.label }}</span
            ><small
              >{{ column.kind }}{{ column.unit ? ' · ' + column.unit : '' }}</small
            ></mat-option
          >
        }
        @if (!matches().length) {
          <mat-option disabled>No eligible fields match this search</mat-option>
        }
      </mat-autocomplete>
      @if (hint) {
        <mat-hint>{{ hint }}</mat-hint>
      }
      <mat-error>Choose a matching field from the list.</mat-error>
    </mat-form-field>
  `,
  styles: [
    `
      :host {
        display: block;
        min-width: 0;
      }
      mat-form-field {
        display: block;
        width: 100%;
        --mat-form-field-container-height: 44px;
        --mat-form-field-container-vertical-padding: 10px;
        --mat-form-field-container-text-size: 13px;
      }
      mat-icon[matPrefix] {
        font-size: 17px;
        width: 17px;
        height: 17px;
        padding: 0 7px 0 9px;
        box-sizing: content-box;
        color: var(--muted);
      }
      mat-option small {
        display: block;
        color: var(--muted);
        font-size: 11px;
        margin-top: 3px;
      }
      mat-hint,
      mat-error {
        font-size: 11px;
        line-height: 1.4;
      }
      button[matSuffix] {
        --mat-icon-button-state-layer-size: 40px;
        --mat-icon-button-touch-target-display: none;
        width: 40px;
        height: 40px;
        padding: 10px;
        margin-right: 3px;
        color: var(--muted);
      }
      button[matSuffix] mat-icon {
        width: 20px;
        height: 20px;
        font-size: 20px;
      }
      @media (pointer: coarse) {
        mat-form-field {
          --mat-form-field-container-text-size: 16px;
        }
      }
    `,
  ],
})
export class ChartFieldPickerComponent implements OnChanges {
  private readonly reactiveState = injectUiState('ChartFieldPickerComponent');

  @Input() options: readonly ColumnSpec[] = [];
  @Input() selected = '';
  @Input() label = 'Choose a field';
  @Input() ariaLabel = '';
  @Input() hint = '';
  @Input() disabled = false;
  @Output() readonly chosen = new EventEmitter<string>();
  @Output() readonly validSelection = new EventEmitter<boolean>();
  readonly search = this.reactiveState.signal('');
  readonly touched = this.reactiveState.signal(false);
  readonly selectionMatcher = {
    isErrorState: () =>
      this.touched() && this.search().trim() !== (this.selectedField()?.label ?? ''),
  };
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['label'] || changes['selected']) {
      this.search.set(this.selectedField()?.label ?? '');
      this.validSelection.emit(true);
    }
  }
  editSearch(value: string): void {
    this.search.set(value);
    this.touched.set(false);
    this.validSelection.emit(value.trim() === (this.selectedField()?.label ?? ''));
  }
  selectedField() {
    return this.options.find((field) => field.id === this.selected);
  }
  matches() {
    const entered = this.search().trim().toLocaleLowerCase();
    const query = entered === this.selectedField()?.label.toLocaleLowerCase() ? '' : entered;
    return this.options
      .filter(
        (field) =>
          !query ||
          `${field.label} ${field.id} ${field.unit ?? ''} ${field.description} ${field.aliases.join(' ')}`
            .toLocaleLowerCase()
            .includes(query),
      )
      .slice(0, 8);
  }
  select(id: string) {
    if (this.disabled || !this.options.some((field) => field.id === id)) return;
    this.chosen.emit(id);
    this.validSelection.emit(true);
    this.touched.set(false);
    this.search.set(this.options.find((field) => field.id === id)?.label ?? '');
  }
  selectInput(event: FocusEvent): void {
    (event.target as HTMLInputElement).select();
  }
}
