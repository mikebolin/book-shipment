import { injectUiState } from '../core/state/index';
import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnDestroy,
  ViewChild,
  computed,
  inject,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CdkVirtualScrollViewport, ScrollingModule } from '@angular/cdk/scrolling';
import { CdkDragDrop, DragDropModule } from '@angular/cdk/drag-drop';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTooltipModule } from '@angular/material/tooltip';
import type { IToolPanelAngularComp } from 'ag-grid-angular';
import type { GridApi, IToolPanelParams } from 'ag-grid-community';
import type { ColumnSpec } from '../core/domain/schema';
import { isColumnGroupTag } from '../core/domain/column-grouping';
import { COLUMN_HIGHLIGHT_COLORS, type ColumnHighlightColor } from './column-highlights';
import {
  ColumnCategoryManagerComponent,
  type ColumnCategoryManagerResult,
} from './column-category-manager.component';
import {
  DEFAULT_COLUMN_PANEL_CONFIG,
  type ColumnPanelAction,
  type ColumnPanelConfig,
} from './column-panel-config';

export const EXPLORER_COLUMNS_PANEL = 'columns';

export interface ColumnsToolPanelParams extends IToolPanelParams {
  panelId: string;
  getColumns: () => readonly ColumnSpec[];
  isLocked: () => boolean;
  closePanel: () => void;
  onHighlight: (id: string | null, color?: ColumnHighlightColor) => void;
  onLocate?: (id: string) => void;
  getHighlights?: () => Readonly<Record<string, ColumnHighlightColor>>;
  getCategory?: (id: string) => string | undefined;
  setCategory?: (id: string, category: string | undefined) => void;
  setCategories?: (assignments: Record<string, string | undefined>) => void;
  getCategoryOrder?: () => readonly (string | undefined)[];
  setCategoryOrder?: (order: readonly (string | undefined)[]) => void;
  config?: ColumnPanelConfig;
}

interface ColumnRow {
  type: 'column';
  key: string;
  id: string;
  spec: ColumnSpec;
  label: string;
  category: string | undefined;
  searchText: string;
  visible: boolean;
  pinned: 'left' | 'right' | null;
  grouped: boolean;
  value: boolean;
  pivot: boolean;
  aggFunc: string;
  canHide: boolean;
  canPin: boolean;
  canMove: boolean;
  canGroup: boolean;
  canValue: boolean;
  canPivot: boolean;
  aggregations: readonly string[];
}
interface CategoryRow {
  type: 'category';
  key: string;
  label: string;
  count: number;
  category: string | undefined;
  totalCount: number;
  visibleCount: number;
  visibilityChecked: boolean;
  visibilityIndeterminate: boolean;
  canToggle: boolean;
  canMove: boolean;
  expanded: boolean;
}
type PanelRow = ColumnRow | CategoryRow;
type VisibilityFilter = 'all' | 'visible' | 'hidden';
@Component({
  selector: 'app-columns-tool-panel',
  standalone: true,
  imports: [
    FormsModule,
    ScrollingModule,
    DragDropModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatMenuModule,
    MatSelectModule,
    MatSlideToggleModule,
    MatTooltipModule,
  ],
  templateUrl: './columns-tool-panel.component.html',
  styleUrl: './columns-tool-panel.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ColumnsToolPanelComponent implements IToolPanelAngularComp, AfterViewInit, OnDestroy {
  private readonly reactiveState = injectUiState('ColumnsToolPanelComponent');

  private readonly dialog = inject(MatDialog);
  private readonly element = inject<ElementRef<HTMLElement>>(ElementRef);
  @ViewChild(CdkVirtualScrollViewport) private viewport?: CdkVirtualScrollViewport;
  readonly params = this.reactiveState.signal<ColumnsToolPanelParams | null>(null);
  readonly config = computed(() => ({ ...DEFAULT_COLUMN_PANEL_CONFIG, ...this.params()?.config }));
  readonly columns = this.reactiveState.signal<readonly ColumnRow[]>([]);
  readonly organizing = this.reactiveState.signal(false);
  readonly query = this.reactiveState.signal('');
  readonly visibility = this.reactiveState.signal<VisibilityFilter>('all');
  readonly collapsed = this.reactiveState.signal<ReadonlySet<string>>(new Set());
  readonly analysisOpen = this.reactiveState.signal(false);
  readonly pivotMode = this.reactiveState.signal(false);
  readonly functionsReadOnly = this.reactiveState.signal(false);
  readonly status = this.reactiveState.signal('');
  private readonly localCategories = new Map<string, string | undefined>();
  private readonly localHighlights = this.reactiveState.signal<
    Readonly<Record<string, ColumnHighlightColor>>
  >({});
  readonly highlightColors = COLUMN_HIGHLIGHT_COLORS;
  readonly highlights = computed(() => {
    const settings = this.params();
    return settings?.getHighlights ? settings.getHighlights() : this.localHighlights();
  });
  readonly highlightCount = computed(() => Object.keys(this.highlights()).length);
  private readonly localCategoryOrder = this.reactiveState.signal<readonly (string | undefined)[]>(
    [],
  );
  readonly locked = computed(() => this.params()?.isLocked() ?? true);
  readonly visibleCount = computed(() => this.columns().filter((column) => column.visible).length);
  readonly canShowAll = computed(() =>
    this.columns().some((column) => column.canHide && !column.visible),
  );
  readonly canHideAll = computed(() =>
    this.columns().some((column) => column.canHide && column.visible),
  );
  readonly categories = computed(() => {
    const byId = new Map(this.columns().map((column) => [column.id, column.category]));
    // Configured categories lead; source metadata keeps core fields ahead of time periods.
    const sourceOrder =
      this.params()
        ?.getColumns()
        .map((column) => byId.get(column.id)) ?? [];
    return [
      ...new Set(
        [...this.config().categories, ...sourceOrder].filter(
          (category): category is string => !!category,
        ),
      ),
    ];
  });
  readonly matchingColumns = computed(() => {
    const query = this.query().trim().toLocaleLowerCase();
    const visibility = this.visibility();
    return this.columns().filter(
      (column) =>
        (!query || column.searchText.includes(query)) &&
        (visibility === 'all' || column.visible === (visibility === 'visible')),
    );
  });
  readonly matchingCategoryKeys = computed(() => [
    ...new Set(this.matchingColumns().map((column) => column.category ?? '')),
  ]);
  readonly allMatchingCategoriesCollapsed = computed(() => {
    const categories = this.matchingCategoryKeys();
    return categories.length > 0 && categories.every((category) => this.collapsed().has(category));
  });
  readonly categoryExpansionLabel = computed(() =>
    this.allMatchingCategoriesCollapsed() ? 'Expand all categories' : 'Collapse all categories',
  );
  readonly categoryOrder = computed(() => {
    const known = new Set<string | undefined>([...this.categories(), undefined]);
    const settings = this.params();
    const preferred = settings?.getCategoryOrder
      ? settings.getCategoryOrder()
      : this.localCategoryOrder();
    return [...new Set([...preferred, ...this.categories(), undefined])].filter((category) =>
      known.has(category),
    );
  });
  readonly rows = computed<readonly PanelRow[]>(() => {
    const columns = this.matchingColumns();
    if (!this.organizing()) return [...columns].sort((a, b) => a.label.localeCompare(b.label));
    const groups = new Map<string, ColumnRow[]>();
    for (const column of columns) {
      const category = column.category ?? '';
      const group = groups.get(category) ?? [];
      group.push(column);
      groups.set(category, group);
    }
    const order = this.categoryOrder();
    const result: PanelRow[] = [];
    for (const category of order) {
      const group = groups.get(category ?? '');
      if (!group?.length) continue;
      const expanded = !this.collapsed().has(category ?? '');
      const members = this.columns().filter((column) => column.category === category);
      const editableMembers = members.filter((column) => column.canHide);
      // Locked columns cannot follow the group checkbox. Including a locked hidden
      // column in its state would leave it mixed forever and prevent hiding others.
      const checkboxMembers = editableMembers.length ? editableMembers : members;
      const checkboxVisibleCount = checkboxMembers.filter((column) => column.visible).length;
      result.push({
        type: 'category',
        key: `category:${category ?? ''}`,
        label: category || this.config().uncategorizedLabel,
        count: group.length,
        category,
        totalCount: members.length,
        visibleCount: members.filter((column) => column.visible).length,
        visibilityChecked: checkboxVisibleCount === checkboxMembers.length,
        visibilityIndeterminate:
          checkboxVisibleCount > 0 && checkboxVisibleCount < checkboxMembers.length,
        canToggle: editableMembers.length > 0,
        canMove: members.every((column) => column.canMove),
        expanded,
      });
      if (expanded) result.push(...group);
    }
    return result;
  });
  private readonly groupIds = this.reactiveState.signal<readonly string[]>([]);
  private readonly valueIds = this.reactiveState.signal<readonly string[]>([]);
  private readonly pivotIds = this.reactiveState.signal<readonly string[]>([]);
  readonly groups = computed(() => this.analysisColumns(this.groupIds()));
  readonly measures = computed(() => this.analysisColumns(this.valueIds()));
  readonly pivots = computed(() => this.analysisColumns(this.pivotIds()));
  readonly analysisCount = computed(
    () => this.groups().length + this.measures().length + this.pivots().length,
  );
  readonly reorderAvailable = computed(() => !this.pivotMode() && this.hasAction('move'));
  readonly categoryReorderAvailable = this.reorderAvailable;
  readonly trackRow = (_index: number, row: PanelRow) => row.key;
  private frame = 0;
  private revealFrame = 0;
  private resizeObserver?: ResizeObserver;
  private alive = true;
  private columnDragRows: readonly PanelRow[] = [];
  private draggedId: string | null = null;
  private dragKind: 'column' | 'category' | null = null;
  private draggedCategory: string | undefined;
  private categoryDragRows: readonly PanelRow[] = [];
  private categoryDragOrder: readonly (string | undefined)[] = [];
  private categoryManager?: MatDialogRef<ColumnCategoryManagerComponent>;
  private readonly stateChanged = () => this.scheduleSync();
  private readonly visibilityChanged = (event: { key: string; visible: boolean }) => {
    if (event.key === EXPLORER_COLUMNS_PANEL && event.visible) this.scheduleSync();
  };
  private readonly events = [
    'columnVisible',
    'columnPinned',
    'columnMoved',
    'columnRowGroupChanged',
    'columnValueChanged',
    'columnPivotChanged',
    'columnPivotModeChanged',
    'columnHeaderNameChanged',
    'newColumnsLoaded',
  ] as const;

  agInit(params: ColumnsToolPanelParams): void {
    this.params.set(params);
    for (const event of this.events) params.api.addEventListener(event, this.stateChanged);
    params.api.addEventListener('toolPanelVisibleChanged', this.visibilityChanged);
    this.sync();
  }

  refresh(params: ColumnsToolPanelParams): boolean {
    this.params.set(params);
    this.scheduleSync();
    return true;
  }

  ngAfterViewInit(): void {
    this.resizeObserver = new ResizeObserver(() => this.viewport?.checkViewportSize());
    this.resizeObserver.observe(this.element.nativeElement);
    this.viewport?.checkViewportSize();
  }

  private api(): GridApi | undefined {
    const api = this.params()?.api;
    return this.alive && api && !api.isDestroyed() ? api : undefined;
  }

  private scheduleSync(): void {
    if (this.frame || !this.alive) return;
    this.frame = requestAnimationFrame(() => {
      this.frame = 0;
      this.sync();
      this.viewport?.checkViewportSize();
    });
  }

  private sync(): void {
    const settings = this.params();
    const api = this.api();
    if (!settings || !api) return;
    const specs = new Map(settings.getColumns().map((column) => [column.id, column]));
    const primary = api.getColumns() ?? [];
    const ordered = [...api.getAllGridColumns().filter((column) => column.isPrimary()), ...primary];
    const seen = new Set<string>();
    const functionsReadOnly = !!api.getGridOption('functionsReadOnly');
    const groupIds = api.getRowGroupColumns().map((column) => column.getColId());
    this.groupIds.set(groupIds);
    this.valueIds.set(api.getValueColumns().map((column) => column.getColId()));
    this.pivotIds.set(api.getPivotColumns().map((column) => column.getColId()));
    const lockedGroups = api.getGridOption('groupLockGroupColumns') ?? 0;
    this.functionsReadOnly.set(functionsReadOnly);
    this.pivotMode.set(api.isPivotMode());
    const rows: ColumnRow[] = [];
    for (const column of ordered) {
      const id = column.getColId();
      const spec = specs.get(id);
      if (!spec || seen.has(id)) continue;
      seen.add(id);
      const def = column.getColDef();
      // A supplied callback is authoritative, including an explicit cleared category.
      const category = settings.getCategory
        ? settings.getCategory(id)
        : this.localCategories.has(id)
          ? this.localCategories.get(id)
          : spec.groupByTag;
      const label = api.getDisplayNameForColumn(column, 'columnToolPanel') || spec.label;
      const groupIndex = groupIds.indexOf(id);
      const lockedGroup = groupIndex >= 0 && (lockedGroups === -1 || groupIndex < lockedGroups);
      rows.push({
        type: 'column',
        key: id,
        id,
        spec,
        label,
        category,
        searchText: [label, id, spec.description, category, spec.kind, ...spec.aliases]
          .filter(Boolean)
          .join(' ')
          .toLocaleLowerCase(),
        visible: column.isVisible(),
        pinned:
          column.getPinned() === 'left' ? 'left' : column.getPinned() === 'right' ? 'right' : null,
        grouped: column.isRowGroupActive(),
        value: column.isValueActive(),
        pivot: column.isPivotActive(),
        aggFunc: typeof column.getAggFunc() === 'string' ? (column.getAggFunc() as string) : 'sum',
        canHide: !def.lockVisible,
        canPin: !def.lockPinned,
        canMove:
          !def.lockPosition && !def.suppressMovable && !api.getGridOption('suppressMovableColumns'),
        canGroup: !functionsReadOnly && !lockedGroup && column.isAllowRowGroup(),
        canValue: !functionsReadOnly && column.isAllowValue(),
        canPivot: !functionsReadOnly && column.isAllowPivot(),
        aggregations: def.allowedAggFuncs ?? ['sum', 'avg', 'count', 'min', 'max', 'first', 'last'],
      });
    }
    this.columns.set(rows);
  }

  private analysisColumns(ids: readonly string[]): ColumnRow[] {
    const byId = new Map(this.columns().map((column) => [column.id, column]));
    return ids.map((id) => byId.get(id)).filter((column): column is ColumnRow => !!column);
  }

  hasAction(action: ColumnPanelAction): boolean {
    return (
      this.config().actions.includes(action) &&
      (this.organizing() || ['pin', 'reveal'].includes(action))
    );
  }
  setMode(organize: boolean): void {
    this.organizing.set(organize);
    this.viewport?.scrollToIndex(0);
    this.viewport?.checkViewportSize();
  }
  setMatchingVisible(visible: boolean): void {
    const api = this.api();
    if (!api || this.locked()) return;
    const ids = this.matchingColumns()
      .filter((c) => c.canHide)
      .map((c) => c.id);
    api.setColumnsVisible(ids, visible);
    this.status.set(`${ids.length} matching columns ${visible ? 'shown' : 'hidden'}.`);
    this.sync();
  }
  setQuery(value: string): void {
    this.query.set(value);
    this.viewport?.scrollToIndex(0);
  }
  setVisibility(value: VisibilityFilter): void {
    this.visibility.set(value);
    this.viewport?.scrollToIndex(0);
  }
  toggleCategory(row: CategoryRow): void {
    if (this.locked()) return;
    const category = row.key.slice('category:'.length);
    this.collapsed.update((old) => {
      const next = new Set(old);
      next.has(category) ? next.delete(category) : next.add(category);
      return next;
    });
  }

  toggleAllCategories(): void {
    if (this.locked()) return;
    const categories = this.matchingCategoryKeys();
    if (!categories.length) return;
    const expand = this.allMatchingCategoriesCollapsed();
    this.collapsed.update((old) => {
      const next = new Set(old);
      for (const category of categories) {
        expand ? next.delete(category) : next.add(category);
      }
      return next;
    });
    this.viewport?.scrollToIndex(0);
    this.status.set(
      categories.length +
        (categories.length === 1 ? ' category ' : ' categories ') +
        (expand ? 'expanded.' : 'collapsed.'),
    );
  }

  toggleCategoryVisible(row: CategoryRow, visible: boolean): void {
    const api = this.api();
    if (!api || this.locked()) return;
    const members = this.columns().filter(
      (column) =>
        column.category === row.category && !api.getColumn(column.id)?.getColDef().lockVisible,
    );
    if (!members.length) return;
    const changed = members.filter((column) => api.getColumn(column.id)?.isVisible() !== visible);
    api.setColumnsVisible(
      changed.map((column) => column.id),
      visible,
    );
    this.sync();
    this.status.set(
      `${row.label}: ${changed.length} ${changed.length === 1 ? 'column' : 'columns'} ${visible ? 'shown' : 'hidden'}.` +
        (members.length < row.totalCount ? ' Locked columns keep their visibility.' : ''),
    );
  }

  moveCategory(row: CategoryRow, direction: -1 | 1): void {
    const order = this.categoryOrder().filter((category) =>
      this.columns().some((column) => column.category === category),
    );
    const index = order.indexOf(row.category);
    const targetIndex = index + direction;
    if (index < 0 || targetIndex < 0 || targetIndex >= order.length) return;
    this.moveCategoryRelative(row.category, order[targetIndex], direction > 0);
  }

  private moveCategoryRelative(
    category: string | undefined,
    target: string | undefined,
    after: boolean,
  ): void {
    const api = this.api();
    if (
      !api ||
      this.locked() ||
      api.isPivotMode() ||
      !this.hasAction('move') ||
      category === target
    )
      return;
    const members = this.columns().filter((column) => column.category === category);
    const targetIds = new Set(
      this.columns()
        .filter((column) => column.category === target)
        .map((column) => column.id),
    );
    if (!members.length || !targetIds.size || members.some((column) => !column.canMove)) return;
    const memberIds = new Set(members.map((column) => column.id));
    const all = api.getAllGridColumns();
    const affectedIndexes = all
      .map((column, index) =>
        memberIds.has(column.getColId()) || targetIds.has(column.getColId()) ? index : -1,
      )
      .filter((index) => index >= 0);
    if (
      !affectedIndexes.length ||
      all
        .slice(Math.min(...affectedIndexes), Math.max(...affectedIndexes) + 1)
        .some((column) => column.getColDef().lockPosition)
    ) {
      this.status.set('This category cannot move across a locked column.');
      return;
    }
    const moving = all
      .filter((column) => memberIds.has(column.getColId()))
      .map((column) => column.getColId());
    const remaining = all.filter((column) => !memberIds.has(column.getColId()));
    const targets = remaining
      .map((column, index) => (targetIds.has(column.getColId()) ? index : -1))
      .filter((index) => index >= 0);
    if (!moving.length || !targets.length) return;
    api.moveColumns(moving, after ? Math.max(...targets) + 1 : Math.min(...targets));
    const order = this.categoryOrder().filter((value) => value !== category);
    const targetIndex = order.indexOf(target);
    if (targetIndex < 0) return;
    order.splice(targetIndex + (after ? 1 : 0), 0, category);
    this.localCategoryOrder.set(order);
    this.params()?.setCategoryOrder?.(order);
    this.status.set(
      `${category || this.config().uncategorizedLabel} moved as a group. All ${moving.length} columns keep their relative order.`,
    );
  }

  toggleVisible(row: ColumnRow, visible: boolean): void {
    if (this.locked() || !row.canHide) return;
    this.api()?.setColumnsVisible([row.id], visible);
    this.status.set(`${row.label} ${visible ? 'shown' : 'hidden'}.`);
  }

  setAllColumnsVisible(visible: boolean): void {
    const api = this.api();
    if (!api || this.locked()) return;
    const changed: string[] = [];
    let lockedCount = 0;
    for (const row of this.columns()) {
      const column = api.getColumn(row.id);
      if (!column) continue;
      if (column.getColDef().lockVisible) {
        lockedCount++;
        continue;
      }
      if (column.isVisible() !== visible) changed.push(row.id);
    }
    if (changed.length) api.setColumnsVisible(changed, visible);
    this.sync();
    this.status.set(
      `${changed.length} ${changed.length === 1 ? 'column' : 'columns'} ${visible ? 'shown' : 'hidden'}.` +
        (lockedCount ? ' Locked columns keep their visibility.' : ''),
    );
  }

  reveal(row: ColumnRow): void {
    const api = this.api();
    if (!api || this.locked() || api.isPivotMode() || (!row.visible && !row.canHide)) return;
    if (!row.visible) api.setColumnsVisible([row.id], true);
    cancelAnimationFrame(this.revealFrame);
    // Material restores focus to the menu trigger when closing. Locate afterward,
    // once AG Grid has also laid out a newly shown column.
    this.revealFrame = requestAnimationFrame(() => {
      this.revealFrame = 0;
      if (this.api() !== api || this.locked() || api.isPivotMode()) return;
      if (!api.getAllDisplayedColumns().some((column) => column.getColId() === row.id)) {
        this.status.set(`${row.label} is not displayed in the current grouped view.`);
        return;
      }
      api.ensureColumnVisible(row.id, 'middle');
      const locate = this.params()?.onLocate;
      if (locate) locate(row.id);
      else api.setFocusedHeader(row.id);
      this.status.set(`${row.label} located in the grid.`);
    });
  }

  pin(row: ColumnRow, position: 'left' | 'right' | null): void {
    if (this.locked() || !row.canPin) return;
    this.api()?.setColumnsPinned([row.id], position);
    this.status.set(`${row.label} ${position ? 'pinned ' + position : 'unpinned'}.`);
  }

  highlight(row: ColumnRow, color?: ColumnHighlightColor): void {
    if (this.locked()) return;
    const current = this.highlights();
    const next = { ...current };
    if (!color && next[row.id]) delete next[row.id];
    else
      next[row.id] =
        color ??
        COLUMN_HIGHLIGHT_COLORS[Object.keys(current).length % COLUMN_HIGHLIGHT_COLORS.length]!.id;
    this.localHighlights.set(next);
    this.params()?.onHighlight(row.id, color);
    this.status.set(next[row.id] ? `${row.label} highlighted.` : `${row.label} highlight cleared.`);
  }

  clearHighlights(): void {
    if (this.locked()) return;
    this.localHighlights.set({});
    this.params()?.onHighlight(null);
    this.status.set('All column highlights cleared.');
  }

  toggleAnalysis(row: ColumnRow, kind: 'group' | 'value' | 'pivot'): void {
    const api = this.api();
    if (!api || this.locked() || this.functionsReadOnly()) return;
    if (kind === 'group' && row.canGroup)
      row.grouped ? api.removeRowGroupColumns([row.id]) : api.addRowGroupColumns([row.id]);
    if (kind === 'value' && row.canValue)
      row.value ? api.removeValueColumns([row.id]) : api.addValueColumns([row.id]);
    if (kind === 'pivot' && row.canPivot)
      row.pivot ? api.removePivotColumns([row.id]) : api.addPivotColumns([row.id]);
    this.analysisOpen.set(true);
  }

  setAggregation(row: ColumnRow, aggregation: string): void {
    if (!this.locked() && row.canValue && row.aggregations.includes(aggregation))
      this.api()?.setColumnAggFunc(row.id, aggregation);
  }
  setPivotMode(enabled: boolean): void {
    if (!this.locked() && !this.functionsReadOnly())
      this.api()?.setGridOption('pivotMode', enabled);
  }

  move(row: ColumnRow, direction: -1 | 1): void {
    const members = this.columns().filter((column) => column.category === row.category);
    const index = members.findIndex((column) => column.id === row.id);
    const target = members[index + direction];
    if (index < 0 || !target) return;
    this.moveColumnRelative(row, target, direction > 0);
  }

  private moveColumnRelative(row: ColumnRow, target: ColumnRow, after: boolean): void {
    const api = this.api();
    if (
      !api ||
      this.locked() ||
      !this.reorderAvailable() ||
      !row.canMove ||
      row.id === target.id ||
      row.category !== target.category
    )
      return;
    const all = api.getAllGridColumns();
    const original = all.findIndex((column) => column.getColId() === row.id);
    const targetOriginal = all.findIndex((column) => column.getColId() === target.id);
    if (
      original < 0 ||
      targetOriginal < 0 ||
      all
        .slice(Math.min(original, targetOriginal), Math.max(original, targetOriginal) + 1)
        .some((column) => column.getColDef().lockPosition)
    )
      return;
    const remaining = all.filter((column) => column.getColId() !== row.id);
    const targetIndex = remaining.findIndex((column) => column.getColId() === target.id);
    api.moveColumns([row.id], targetIndex + (after ? 1 : 0));
    this.status.set(
      row.label +
        ' moved ' +
        (after ? 'later' : 'earlier') +
        ' in ' +
        (row.category || this.config().uncategorizedLabel) +
        '.',
    );
  }

  beginDrag(row: ColumnRow): void {
    this.dragKind = 'column';
    this.columnDragRows = this.rows();
    this.draggedId = row.id;
  }
  beginCategoryDrag(row: CategoryRow): void {
    this.dragKind = 'category';
    this.draggedCategory = row.category;
    this.categoryDragRows = this.rows();
    this.categoryDragOrder = this.categoryOrder();
  }
  drop(event: CdkDragDrop<readonly PanelRow[]>): void {
    if (this.dragKind === 'category') {
      this.dropCategory(event);
      return;
    }
    const api = this.api();
    const viewport = this.viewport;
    const row = this.columnDragRows.find(
      (item): item is ColumnRow => item.type === 'column' && item.id === this.draggedId,
    );
    if (
      !api ||
      !viewport ||
      !row ||
      this.locked() ||
      !this.reorderAvailable() ||
      !row.canMove ||
      !event.isPointerOverContainer
    )
      return;
    const rows = this.rows();
    // Virtual row indexes include category headings and omit collapsed members.
    if (
      rows.length !== this.columnDragRows.length ||
      rows.some((item, index) => item.key !== this.columnDragRows[index]?.key)
    )
      return;
    const bounds = viewport.elementRef.nativeElement.getBoundingClientRect();
    const logicalIndex = Math.max(
      0,
      Math.min(
        rows.length - 1,
        Math.floor((event.dropPoint.y - bounds.top + viewport.measureScrollOffset()) / 56),
      ),
    );
    const targetRow = rows[logicalIndex];
    if (!targetRow) return;
    if (targetRow.category !== row.category) {
      this.status.set(
        'Move columns within their category. Use the category handle to move a whole category.',
      );
      return;
    }
    const target =
      targetRow.type === 'column'
        ? targetRow
        : rows.find(
            (item): item is ColumnRow => item.type === 'column' && item.category === row.category,
          );
    if (!target) return;
    const sourceIndex = rows.findIndex((item) => item.key === row.key);
    this.moveColumnRelative(row, target, targetRow.type === 'column' && sourceIndex < logicalIndex);
  }

  private dropCategory(event: CdkDragDrop<readonly PanelRow[]>): void {
    const viewport = this.viewport;
    if (
      !viewport ||
      this.locked() ||
      !this.categoryReorderAvailable() ||
      !event.isPointerOverContainer
    )
      return;
    const rows = this.rows();
    const order = this.categoryOrder();
    if (
      rows.length !== this.categoryDragRows.length ||
      rows.some((row, index) => row.key !== this.categoryDragRows[index]?.key) ||
      order.length !== this.categoryDragOrder.length ||
      order.some((category, index) => category !== this.categoryDragOrder[index])
    )
      return;
    const bounds = viewport.elementRef.nativeElement.getBoundingClientRect();
    const index = Math.max(
      0,
      Math.min(
        rows.length - 1,
        Math.floor((event.dropPoint.y - bounds.top + viewport.measureScrollOffset()) / 56),
      ),
    );
    const target = rows[index]?.category;
    if (!rows[index] || target === this.draggedCategory) return;
    const sourceIndex = order.indexOf(this.draggedCategory);
    const targetIndex = order.indexOf(target);
    if (sourceIndex < 0 || targetIndex < 0) return;
    this.moveCategoryRelative(this.draggedCategory, target, sourceIndex < targetIndex);
  }

  manageCategories(): void {
    if (this.locked() || !this.config().allowCategoryEditing || !this.hasAction('category')) return;
    this.sync();
    this.categoryManager?.close();
    this.categoryManager = this.dialog.open(ColumnCategoryManagerComponent, {
      data: {
        columns: this.columns().map((column) => ({
          id: column.id,
          label: column.label,
          kind: column.spec.kind,
          description: column.spec.description,
          category: column.category,
        })),
        categories: this.categoryOrder().filter(
          (category): category is string => category !== undefined,
        ),
      },
      width: '900px',
      maxWidth: 'calc(100vw - 24px)',
      maxHeight: 'calc(100dvh - 24px)',
      autoFocus: 'first-heading',
      restoreFocus: true,
    });
    this.categoryManager
      .afterClosed()
      .subscribe((result: ColumnCategoryManagerResult | undefined) => {
        if (!this.alive || !result || this.locked()) return;
        const ids = new Set(this.columns().map((column) => column.id));
        const changes = Object.entries(result.assignments);
        if (
          !changes.length ||
          changes.some(
            ([id, category]) =>
              !ids.has(id) || (category !== undefined && !isColumnGroupTag(category)),
          )
        )
          return;
        const settings = this.params();
        const previousOrder = this.categoryOrder();
        if (settings?.setCategories) settings.setCategories(result.assignments);
        else
          for (const [id, category] of changes) {
            if (settings?.setCategory) settings.setCategory(id, category);
            else this.localCategories.set(id, category);
          }
        this.sync();
        if (result.categoryOrder?.every(isColumnGroupTag)) {
          const order: (string | undefined)[] = [...new Set(result.categoryOrder)];
          const ungroupedIndex = previousOrder.indexOf(undefined);
          const nextIndex =
            ungroupedIndex >= 0 && ungroupedIndex < previousOrder.length - 1
              ? Math.min(ungroupedIndex, order.length)
              : order.length;
          order.splice(nextIndex, 0, undefined);
          this.localCategoryOrder.set(order);
          settings?.setCategoryOrder?.(order);
        }
        this.status.set(changes.length + ' column categories updated.');
      });
  }

  close(event?: Event): void {
    if (event?.defaultPrevented) return;
    event?.preventDefault();
    event?.stopPropagation();
    this.params()?.closePanel();
  }

  ngOnDestroy(): void {
    this.alive = false;
    cancelAnimationFrame(this.frame);
    cancelAnimationFrame(this.revealFrame);
    this.resizeObserver?.disconnect();
    this.categoryManager?.close();
    const api = this.params()?.api;
    if (api && !api.isDestroyed()) {
      for (const event of this.events) api.removeEventListener(event, this.stateChanged);
      api.removeEventListener('toolPanelVisibleChanged', this.visibilityChanged);
    }
  }
}
