import { injectUiState } from '../core/state/index';
import {
  Component,
  Input,
  Output,
  EventEmitter,
  OnChanges,
  OnDestroy,
  inject,
  ChangeDetectionStrategy,
} from '@angular/core';
import { DecimalPipe, NgTemplateOutlet } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { ExplorerDataService } from './explorer-data.service';
import type { ColumnSpec } from '../core/domain/schema';
import type { Mode, GridModel } from '../core/domain/contracts';

export interface ProposalDataRequest {
  mode: Mode;
  filterModel: GridModel;
  calculatedColumnIds: string[];
  columnIds: string[];
}

@Component({
  selector: 'app-proposal-data-preview',
  standalone: true,
  imports: [
    DecimalPipe,
    NgTemplateOutlet,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    MatProgressSpinnerModule,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section
      class="data-review"
      [class.compact]="compact"
      aria-label="Proposed data preview"
      [attr.aria-busy]="loading()"
    >
      @if (!compact) {
        <strong class="data-review-label"
          ><mat-icon aria-hidden="true">table_rows</mat-icon>Matching data</strong
        >
      }
      @if (loading()) {
        <p class="data-preview-pending" role="status">
          <mat-spinner diameter="14" aria-hidden="true" />Checking matching records…
        </p>
      } @else if (error()) {
        <p role="alert">{{ error() }}</p>
        <button
          mat-icon-button
          type="button"
          (click)="load()"
          aria-label="Retry data preview"
          matTooltip="Retry data preview"
        >
          <mat-icon aria-hidden="true">refresh</mat-icon>
        </button>
      } @else if (data(); as result) {
        @if (compact) {
          <details>
            <summary>
              <span>Data included</span>
              <span class="record-count">{{ result.rowCount | number }} records</span>
            </summary>
            @if (result.rowCount) {
              <p>A few matching records, before they are grouped into the chart.</p>
              <ng-container [ngTemplateOutlet]="sampleRows" />
            }
          </details>
          @if (!result.rowCount) {
            <p role="status">No records match. Adjust your filters to continue.</p>
          }
        } @else {
          <div class="data-review-metrics">
            <div>
              <strong>{{ result.rowCount | number }}</strong
              ><span>matching records</span>
            </div>
            <div>
              <strong>{{ result.rowData.length | number }}</strong
              ><span>sample records</span>
            </div>
          </div>
          @if (!result.rowCount) {
            <p>No records match. Refine the filters before creating a chart.</p>
          } @else {
            <details>
              <summary>Review sample data</summary>
              <ng-container [ngTemplateOutlet]="sampleRows" />
            </details>
          }
          <small>This checks the proposed filters. Your applied grid is unchanged.</small>
        }
      }
    </section>
    <ng-template #sampleRows>
      @if (data(); as result) {
        <div class="table-scroll">
          <table>
            <thead>
              <tr>
                @for (column of shownColumns(); track column.id) {
                  <th>{{ column.label }}</th>
                }
              </tr>
            </thead>
            <tbody>
              @for (row of result.rowData; track $index) {
                <tr>
                  @for (column of shownColumns(); track column.id) {
                    <td>{{ row[column.id] ?? '—' }}</td>
                  }
                </tr>
              }
            </tbody>
          </table>
        </div>
      }
    </ng-template>
  `,
  styles: [
    `
      .data-review {
        margin: 12px 0;
        padding: 12px;
        background: var(--mat-sys-surface-container-low, #f6f8fb);
        border: 1px solid var(--mat-sys-outline-variant, #e0e5ed);
        border-radius: 8px;
        font-size: 12px;
      }
      .data-review p {
        margin: 8px 0;
        line-height: 1.5;
      }
      .data-review-label {
        display: flex;
        align-items: center;
        gap: 6px;
        font-weight: 500;
        font-size: 11px;
        color: var(--mat-sys-on-surface-variant);
      }
      .data-review-label mat-icon {
        width: 16px;
        height: 16px;
        font-size: 16px;
      }
      .data-preview-pending {
        display: flex;
        align-items: center;
        gap: 8px;
        color: var(--mat-sys-on-surface-variant);
      }
      .data-review-metrics {
        display: flex;
        align-items: center;
        gap: 28px;
        margin: 12px 0;
      }
      .data-review-metrics > div {
        display: flex;
        flex-direction: column;
        gap: 3px;
        min-width: 0;
      }
      .data-review-metrics strong {
        font-size: 19px;
        font-weight: 500;
        line-height: 1.2;
        font-variant-numeric: tabular-nums;
        color: var(--mat-sys-on-surface);
      }
      .data-review-metrics span {
        font-size: 10px;
        color: var(--mat-sys-on-surface-variant);
      }
      .data-review.compact {
        margin: 12px 0;
        padding: 0 12px;
        background: transparent;
      }
      .compact summary {
        padding: 13px 0;
        line-height: 1.5;
      }
      .record-count {
        display: inline-block;
        margin-left: 12px;
        color: var(--mat-sys-on-surface-variant);
      }
      summary:focus-visible {
        outline: 2px solid var(--mat-sys-primary);
        outline-offset: 3px;
      }
      .data-review small {
        display: block;
        margin-top: 8px;
        color: var(--mat-sys-on-surface-variant, #64748b);
      }
      .table-scroll {
        overflow: auto;
        margin: 8px 0;
      }
      table {
        border-collapse: collapse;
        min-width: 100%;
      }
      th,
      td {
        text-align: left;
        padding: 7px;
        border-bottom: 1px solid var(--mat-sys-outline-variant, #dce2ea);
        white-space: nowrap;
      }
      th {
        font-weight: 500;
      }
      summary {
        cursor: pointer;
      }
      button {
        margin-top: 8px;
      }
    `,
  ],
})
export class ProposalDataPreviewComponent implements OnChanges, OnDestroy {
  private readonly reactiveState = injectUiState('ProposalDataPreviewComponent');

  @Input() request: ProposalDataRequest | null = null;
  @Input() compact = false;
  @Input() columns: readonly ColumnSpec[] = [];
  @Output() checked = new EventEmitter<number | null>();
  readonly loading = this.reactiveState.signal(false);
  readonly error = this.reactiveState.signal('');
  readonly data = this.reactiveState.signal<{
    rowCount: number;
    rowData: Record<string, string | number | null>[];
  } | null>(null);
  private readonly api = inject(ExplorerDataService);
  private controller?: AbortController;
  private signature = '';
  shownColumns(): ColumnSpec[] {
    const chosen = this.request?.columnIds ?? [];
    return chosen.length
      ? chosen
          .map((id) => this.columns.find((column) => column.id === id))
          .filter((column): column is ColumnSpec => !!column)
          .slice(0, 4)
      : this.columns.filter((column) => column.chartRole !== 'identifier').slice(0, 4);
  }
  ngOnChanges(): void {
    const signature = JSON.stringify(this.request);
    if (signature === this.signature) return;
    this.signature = signature;
    void this.load();
  }
  ngOnDestroy(): void {
    this.controller?.abort();
  }
  async load(): Promise<void> {
    this.controller?.abort();
    this.data.set(null);
    this.error.set('');
    this.checked.emit(null);
    if (!this.request) {
      this.loading.set(false);
      return;
    }
    const controller = new AbortController();
    this.controller = controller;
    this.loading.set(true);
    try {
      const response = await this.api.request<{
        rowCount: number;
        rowData: Record<string, string | number | null>[];
      }>(
        'analytics/rows',
        {
          mode: this.request.mode,
          calculatedColumnIds: this.request.calculatedColumnIds,
          request: {
            startRow: 0,
            endRow: 5,
            filterModel: this.request.filterModel,
            sortModel: [],
            rowGroupCols: [],
            valueCols: [],
            pivotCols: [],
            pivotMode: false,
            groupKeys: [],
          },
        },
        controller.signal,
      );
      if (controller.signal.aborted) return;
      this.data.set(response);
      this.checked.emit(response.rowCount);
    } catch (error) {
      if (!controller.signal.aborted)
        this.error.set(
          error instanceof Error ? error.message : 'Could not check the proposed data.',
        );
    } finally {
      if (!controller.signal.aborted) this.loading.set(false);
    }
  }
}
