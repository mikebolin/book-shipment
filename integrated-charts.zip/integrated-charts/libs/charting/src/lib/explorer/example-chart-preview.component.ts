import { inject } from '@angular/core';
import { CHARTING_DATA } from '../core/data-access/charting-data';
import { injectUiState } from '../core/state/index';
import { Component, Input, OnChanges, OnDestroy, ChangeDetectionStrategy } from '@angular/core';
import { DecimalPipe, DatePipe } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { isLocalDataSource, type ClientDataSourceId } from './client-data-sources';
import type { LocalDataRecipe } from './local-data-recipes';
import { IntegratedChartComponent } from './integrated-chart.component';
import { loadExampleChartPreview, type ExampleChartPreview } from './demo-chart-preview-loader';

@Component({
  selector: 'app-example-chart-preview',
  standalone: true,
  imports: [
    IntegratedChartComponent,
    DecimalPipe,
    DatePipe,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section aria-label="Saved chart preview" [attr.aria-busy]="loading()">
      @if (loading()) {
        <p role="status">Loading saved chart values…</p>
      } @else if (error()) {
        <p role="alert">{{ error() }}</p>
        <button
          mat-icon-button
          type="button"
          matTooltip="Retry saved preview"
          aria-label="Retry saved preview"
          (click)="load()"
        >
          <mat-icon>refresh</mat-icon>
        </button>
      } @else if (preview(); as saved) {
        <div class="review-heading">
          <span
            >{{ localRecipe ? 'Uploaded data' : 'Saved fixture example' }} ·
            {{ saved.response.matchedRowCount | number }} matching records ·
            {{ saved.response.plottedRowCount | number }} chart observations</span
          >
          <button
            mat-icon-button
            type="button"
            matTooltip="Download saved chart values"
            aria-label="Download saved chart values"
            (click)="downloadValues()"
          >
            <mat-icon>data_object</mat-icon>
          </button>
        </div>
        <div class="filter-review">
          <span>Advanced Filter</span><code>{{ saved.filterText || 'All rows (no filter)' }}</code>
        </div>
        <app-integrated-chart [dataset]="saved.response" [compact]="true" />
        <details>
          <summary>Saved values and chart notes</summary>
          <p>
            {{
              localRecipe
                ? 'Calculated locally from the uploaded file.'
                : 'These counts describe the saved fixture snapshot, independently of your current grid.'
            }}
            Snapshot {{ snapshotDate() | date: 'mediumDate' : 'UTC' }}. All
            {{ saved.response.rows.length | number }} observations are supplied to the chart.
          </p>
          @if (saved.response.notes.length) {
            <ul>
              @for (note of saved.response.notes; track $index) {
                <li>{{ note }}</li>
              }
            </ul>
          }
          <button
            mat-icon-button
            type="button"
            [matTooltip]="valuesVisible() ? 'Hide saved values' : 'Show saved values'"
            [attr.aria-label]="valuesVisible() ? 'Hide saved values' : 'Show saved values'"
            [attr.aria-expanded]="valuesVisible()"
            (click)="valuesVisible.set(!valuesVisible())"
          >
            <mat-icon>{{ valuesVisible() ? 'visibility_off' : 'visibility' }}</mat-icon>
          </button>
          @if (valuesVisible()) {
            <pre>{{ valuesJson() }}</pre>
          }
        </details>
      }
    </section>
  `,
  styles: [
    `
      :host {
        display: block;
        min-width: 0;
      }
      section {
        font-size: 12px;
        color: var(--mat-sys-on-surface-variant);
      }
      .review-heading {
        display: flex;
        gap: 8px;
        align-items: center;
        justify-content: space-between;
      }
      .review-heading span {
        line-height: 1.5;
      }
      .filter-review {
        padding: 10px 12px;
        margin: 4px 0 10px;
        background: var(--mat-sys-surface-container);
        border-radius: 8px;
      }
      .filter-review span {
        display: block;
        font-size: 10px;
        font-weight: 500;
        margin-bottom: 5px;
      }
      code {
        display: block;
        color: var(--mat-sys-on-surface);
        font-size: 11px;
        line-height: 1.6;
        white-space: pre-wrap;
        overflow-wrap: anywhere;
      }
      p {
        line-height: 1.5;
        margin: 8px 0;
      }
      details {
        margin: 10px 0 0;
        line-height: 1.6;
      }
      summary {
        cursor: pointer;
      }
      pre {
        white-space: pre-wrap;
        overflow-wrap: anywhere;
        max-height: 240px;
        overflow: auto;
        background: var(--mat-sys-surface-container-lowest);
        padding: 10px;
        border: 1px solid var(--mat-sys-outline-variant);
        border-radius: 6px;
        font-size: 11px;
      }
      button {
        flex-shrink: 0;
        --mdc-icon-button-state-layer-size: 32px;
        width: 32px;
        height: 32px;
        padding: 6px;
      }
      mat-icon {
        font-size: 20px;
        width: 20px;
        height: 20px;
      }
      app-integrated-chart {
        display: block;
        --integrated-chart-height: 320px;
      }
    `,
  ],
})
export class ExampleChartPreviewComponent implements OnChanges, OnDestroy {
  private readonly hostData = inject(CHARTING_DATA);
  private readonly reactiveState = injectUiState('ExampleChartPreviewComponent');

  @Input() sourceId: ClientDataSourceId = 'accounts';
  @Input() localRecipe: LocalDataRecipe | null = null;
  @Input() localSnapshotDate = '';
  @Input() exampleId = '';
  @Input() title = 'Chart preview';
  readonly preview = this.reactiveState.signal<ExampleChartPreview | null>(null);
  readonly loading = this.reactiveState.signal(false);
  readonly error = this.reactiveState.signal('');
  readonly snapshotDate = this.reactiveState.signal('');
  readonly valuesVisible = this.reactiveState.signal(false);
  private revision = 0;
  ngOnChanges(): void {
    void this.load();
  }
  ngOnDestroy(): void {
    this.revision++;
  }
  valuesJson(): string {
    return JSON.stringify(this.preview()?.response, null, 2);
  }
  async load(): Promise<void> {
    const revision = ++this.revision;
    this.preview.set(null);
    this.error.set('');
    this.valuesVisible.set(false);
    this.loading.set(true);
    try {
      const loaded = this.localRecipe?.chartPreview
        ? {
            snapshotDate: this.localSnapshotDate,
            preview: {
              prompt: this.localRecipe.example.prompt,
              filterText: this.localRecipe.preview.filterText,
              response: structuredClone(this.localRecipe.chartPreview),
            },
          }
        : isLocalDataSource(this.sourceId)
          ? (() => {
              throw new Error('This uploaded example has no chart preview.');
            })()
          : await loadExampleChartPreview(this.sourceId, this.exampleId, this.hostData);
      if (revision !== this.revision) return;
      this.snapshotDate.set(loaded.snapshotDate);
      this.preview.set(loaded.preview);
    } catch (error) {
      if (revision === this.revision)
        this.error.set(
          error instanceof Error ? error.message : 'Could not load this saved preview.',
        );
    } finally {
      if (revision === this.revision) this.loading.set(false);
    }
  }
  downloadValues(): void {
    const url = URL.createObjectURL(
      new Blob(
        [
          JSON.stringify(
            { snapshotDate: this.snapshotDate(), sourceId: this.sourceId, ...this.preview() },
            null,
            2,
          ),
        ],
        { type: 'application/json' },
      ),
    );
    const link = document.createElement('a');
    link.href = url;
    link.download = this.exampleId + '-expected-values.json';
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
}
