import type {
  EditorBridge,
  WidgetConfiguration,
  ModelDefinition,
} from '../core/domain/workspace.types';
import type { StreamRow } from './ndjson-row-stream';
import { InjectionToken, type TemplateRef } from '@angular/core';
import type { ClientDataSourceId, LocalDataset } from './client-data-sources';

/** Server feature availability can be shared; source data and AI sessions remain private. */
export interface ExplorerCapabilities {
  readonly liveAiAvailable: boolean;
  readonly liveAiProvider: string | null;
  readonly chartRecommendationsAvailable: boolean;
}

export interface ExplorerSource {
  id: ClientDataSourceId;
  label: string;
  dataset?: LocalDataset;
  capabilities?: ExplorerCapabilities;
}

/** Each preserved explorer has its own source, API session and in-memory data cache. */
export interface ExplorerContext {
  sourcePicker?: TemplateRef<unknown>;
  toolbarActions?: TemplateRef<unknown>;
  /** Managed model editor: rows are borrowed from the root shared snapshot lease. */
  modelSources?: readonly { id: ClientDataSourceId; label: string }[];
  snapshotRows?: readonly StreamRow[];
  /** Metadata-only Studio: grid requests use the supplied host executor. */
  serverSideOnly?: boolean;
  /** Full authorized rows are optional and fetched only for complete exports. */
  loadSnapshotRows?: () => Promise<readonly StreamRow[]>;
  modelDefinition?: ModelDefinition;
  configuration?: WidgetConfiguration;
  attachEditor?: (bridge: EditorBridge | null) => void;
  id: string;
  initialSource: ClientDataSourceId;
  dataset?: LocalDataset;
  capabilities?: ExplorerCapabilities;
  sourceChanged?: (source: ExplorerSource) => void;
  openTab?: (source: ExplorerSource) => void;
  activateExisting?: (source: ClientDataSourceId) => boolean;
  /** Publish the current record count without replacing the tab collection. */
  recordsChanged?: (count: number | null) => void;
  /** Reactive per-tab visibility; background data and requests keep their lifetime. */
  isActive?: () => boolean;
}

export const EXPLORER_CONTEXT = new InjectionToken<ExplorerContext>('Explorer context', {
  providedIn: 'root',
  factory: () => ({ id: 'explorer', initialSource: 'local_unconfigured' }),
});
