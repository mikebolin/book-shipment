import type { DemoSourceMetadata } from '../core/domain/demo-sources';
import type { ColumnSpec } from '../core/domain/schema';
import type { StreamRow } from './ndjson-row-stream';
import type { LocalDataRecipe } from './local-data-recipes';

export type LocalDataSourceId = `local_${string}`;
export type ClientDataSourceId = string;
export interface ClientSourceMetadata extends Omit<DemoSourceMetadata, 'id'> {
  id: ClientDataSourceId;
  local?: true;
}
export interface LocalField {
  originalName: string;
  columnId: string;
  inferredType: 'number' | 'boolean' | 'date' | 'datetime' | 'text' | 'mixed' | 'json';
  gridType: ColumnSpec['kind'];
  nullable: boolean;
  identifier: boolean;
  unique: boolean;
}
export interface LocalDataset {
  /** SHA-256 of the original file contents, computed locally; independent of its filename. */
  contentHash?: string;
  metadata: ClientSourceMetadata & { id: ClientDataSourceId; local: true };
  rows: StreamRow[];
  originalFields: LocalField[];
  keyFieldId?: string;
  warnings: string[];
  preparedRecipes?: LocalDataRecipe[];
  /** Optional reviewed chart selected during the import flow; browser session only. */
  initialAnalysisChart?: LocalDataRecipe;
  provenance: {
    kind: 'local-json' | 'local-csv';
    fileName: string;
    bytes: number;
    importedAt: string;
    rowCount: number;
  };
}
export const isLocalDataSource = (source: string): source is LocalDataSourceId =>
  source.startsWith('local_');
/** Disposable computation registry; the root store owns the source records. */
export class ClientDatasetRegistry {
  private readonly datasets = new Map<ClientDataSourceId, LocalDataset>();
  register(dataset: LocalDataset): void {
    this.datasets.set(dataset.metadata.id, dataset);
  }
  get(source: ClientDataSourceId): LocalDataset | undefined {
    return this.datasets.get(source);
  }
  list(): LocalDataset[] {
    return [...this.datasets.values()];
  }
  metadata(source: ClientDataSourceId): ClientSourceMetadata {
    const dataset = this.datasets.get(source);
    if (!dataset)
      throw new Error('This local dataset is no longer available. Import the file again.');
    return dataset.metadata;
  }
}
