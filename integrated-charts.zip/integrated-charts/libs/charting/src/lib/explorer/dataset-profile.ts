import type { LocalDataset, LocalField } from './client-data-sources';
import type { LocalDataRecipe } from './local-data-recipes';
import type { DatasetAnalysisRequest } from '../core/domain/dataset-analysis';

export interface DatasetProfile {
  request: DatasetAnalysisRequest;
  charts: { id: string; text: string; recipe: LocalDataRecipe }[];
  missingCells: number;
  sampled: boolean;
}
const format = (value: number) =>
  new Intl.NumberFormat('en-US', { maximumFractionDigits: 3 }).format(value);
const missing = (value: unknown) => value === null || value === undefined || value === '';

/** Evenly spaced deterministic sample: avoids presenting just the first chunk as the whole file. */
export function profileDataset(dataset: LocalDataset): DatasetProfile {
  const count = dataset.rows.length;
  if (!count || !dataset.originalFields.length) throw new Error('There are no records to analyze.');
  const sampledRows = Math.min(count, 12_000);
  const rows = Array.from(
    { length: sampledRows },
    (_, i) => dataset.rows[Math.floor((i * count) / sampledRows)],
  );
  const fields = dataset.originalFields
    .filter((field) => !field.identifier)
    .concat(dataset.originalFields.filter((field) => field.identifier))
    .slice(0, 40);
  const facts: DatasetAnalysisRequest['facts'] = [];
  let missingCells = 0;
  const add = (text: string) => {
    if (facts.length < 80) facts.push({ id: `f${facts.length + 1}`, text: text.slice(0, 600) });
  };
  const label = (field: LocalField) => field.originalName.slice(0, 150);
  const numeric = new Map<string, number[]>();
  for (const field of fields) {
    const values = rows.map((row) => row[field.columnId]);
    const present = values.filter((value) => !missing(value));
    const absent = sampledRows - present.length;
    missingCells += absent;
    if (absent)
      add(
        `${label(field)} is missing in ${format(absent)} of ${format(sampledRows)} analyzed records (${format((absent / sampledRows) * 100)}%).`,
      );
    if (!present.length || field.identifier) continue;
    if (field.gridType === 'number') {
      const numbers = present.filter(
        (value): value is number => typeof value === 'number' && Number.isFinite(value),
      );
      if (!numbers.length) continue;
      numeric.set(field.columnId, numbers);
      numbers.sort((a, b) => a - b);
      const min = numbers[0],
        max = numbers[numbers.length - 1];
      // Scale the summands to keep valid, very large numeric columns finite.
      const mean = numbers.reduce((sum, value) => sum + value / numbers.length, 0);
      const median =
        numbers.length % 2
          ? numbers[Math.floor(numbers.length / 2)]
          : numbers[numbers.length / 2 - 1] / 2 + numbers[numbers.length / 2] / 2;
      add(
        `${label(field)} ranges from ${format(min)} to ${format(max)}; median ${format(median)}${Number.isFinite(mean) ? `, average ${format(mean)}` : ''} across ${format(numbers.length)} numeric records.`,
      );
      const q1 = numbers[Math.floor((numbers.length - 1) * 0.25)],
        q3 = numbers[Math.floor((numbers.length - 1) * 0.75)];
      const spread = q3 - q1;
      const outliers =
        spread > 0
          ? numbers.filter((value) => value < q1 - 1.5 * spread || value > q3 + 1.5 * spread).length
          : 0;
      if (outliers)
        add(
          `${label(field)} has ${format(outliers)} potential outliers using the 1.5 × interquartile-range rule. Review these records; unusual values are not necessarily errors.`,
        );
    } else if (field.gridType === 'date' || field.gridType === 'datetime') {
      const dates = present.map((value) => String(value)).sort();
      add(
        `${label(field)} spans ${dates[0].slice(0, 10)} through ${dates[dates.length - 1].slice(0, 10)} in the analyzed records.`,
      );
    } else {
      const frequencies = new Map<string, number>();
      for (const value of present) {
        const key = String(value);
        frequencies.set(key, (frequencies.get(key) ?? 0) + 1);
      }
      const highest = Math.max(...frequencies.values());
      if (frequencies.size === 1)
        add(
          `${label(field)} has one distinct value in all ${format(present.length)} populated records.`,
        );
      else if (frequencies.size <= 50)
        add(
          `${label(field)} has ${frequencies.size} categories; the largest represents ${format((highest / present.length) * 100)}% of populated records.`,
        );
    }
  }
  const numbers = fields.filter((field) => numeric.has(field.columnId)).slice(0, 6);
  for (let i = 0; i < numbers.length; i++)
    for (let j = i + 1; j < numbers.length; j++) {
      const a = numbers[i],
        b = numbers[j];
      const pairs = rows
        .map((row) => [row[a.columnId], row[b.columnId]])
        .filter((pair): pair is [number, number] =>
          pair.every((value) => typeof value === 'number' && Number.isFinite(value)),
        );
      if (pairs.length < 10) continue;
      let meanX = 0,
        meanY = 0,
        xx = 0,
        yy = 0,
        xy = 0,
        n = 0;
      for (const [x, y] of pairs) {
        n++;
        const dx = x - meanX,
          dy = y - meanY;
        meanX += dx / n;
        meanY += dy / n;
        xx += dx * (x - meanX);
        yy += dy * (y - meanY);
        xy += dx * (y - meanY);
      }
      const r = xy / Math.sqrt(xx * yy);
      if (Number.isFinite(r) && Math.abs(r) >= 0.7)
        add(
          `${label(a)} and ${label(b)} have a ${r < 0 ? 'negative' : 'positive'} linear association (Pearson r = ${format(Math.max(-1, Math.min(1, r)))}, ${format(n)} paired records). This does not establish causation.`,
        );
    }
  if (!facts.length)
    add(
      `${format(sampledRows)} records and ${fields.length} fields were profiled. No missing values or numeric patterns were found in the analyzed fields.`,
    );
  const seen = new Set<string>();
  const charts = (dataset.preparedRecipes ?? [])
    .filter((recipe) => {
      if (!recipe.chart || !recipe.chartPreview || recipe.chartPreview.plottedRowCount === 0)
        return false;
      const key = JSON.stringify(recipe.chart);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .slice(0, 16)
    .map((recipe, i) => ({
      id: `c${i + 1}`,
      text: (recipe.chart!.title || recipe.example.title).slice(0, 600),
      recipe,
    }));
  return {
    request: {
      rowCount: count,
      sampledRows,
      fieldCount: dataset.originalFields.length,
      analyzedFields: fields.length,
      facts,
      charts: charts.map(({ id, text }) => ({ id, text })),
    },
    charts,
    missingCells,
    sampled: sampledRows < count || fields.length < dataset.originalFields.length,
  };
}
