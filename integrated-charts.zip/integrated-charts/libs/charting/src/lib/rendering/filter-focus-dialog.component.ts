﻿import { Component, ViewChild, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import type { AdvancedFilterModel } from 'ag-grid-community';
import {
  AdvancedFilterBuilderComponent,
  type FilterDraftChange,
} from '../explorer/advanced-filter-builder.component';
import { DraftFilterEditorComponent } from '../explorer/draft-filter-editor.component';
import { registerGridRuntime } from '../explorer/grid-runtime';
import { injectUiState } from '../core/state/index';
import type { ColumnSpec } from '../core/domain/schema';
import type { ViewChartDataScope } from '../core/domain/workspace.types';
import { fromModel, toModel } from '../core/domain/grid-model';
import { FilterValuesFormComponent, type FilterValuesDraft } from './filter-values-form.component';
import type { FilterPreviewSource } from './filter-preview';

export interface FilterFocusData {
  title: string;
  columns: readonly ColumnSpec[];
  scope: ViewChartDataScope;
  source: FilterPreviewSource;
  access?: 'none' | 'values' | 'expression';
}

/** A private filter draft, with one hierarchy and one Apply action. No data query is needed. */
@Component({
  standalone: true,
  imports: [
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    AdvancedFilterBuilderComponent,
    DraftFilterEditorComponent,
    FilterValuesFormComponent,
  ],
  template: `
    <header class="focus-heading">
      <div>
        <p class="eyebrow">{{ data.source.chart ? 'Chart filters' : 'Table filters' }}</p>
        <h2 mat-dialog-title>{{ data.title }}</h2>
      </div>
      <button mat-icon-button aria-label="Close filters" (click)="cancel()">
        <mat-icon>close</mat-icon>
      </button>
    </header>
    <div class="focus-body">
      @if (data.access === 'none') {
        <p class="access-note">Saved filters. Expand a group to see its filters.</p>
        <app-advanced-filter-builder
          [columns]="data.columns"
          [model]="builderModel()"
          [embedded]="true"
          [dialogMode]="true"
          [readOnly]="true"
        />
      } @else if (data.access === 'values') {
        <p class="access-note">
          Update filter values. The columns and groups are set by this view.
        </p>
        <workspace-filter-values-form
          [columns]="data.columns"
          [scope]="data.scope"
          [compact]="true"
          [showActions]="false"
          label="Filters"
          (draftChange)="valuesChanged($event)"
        />
      } @else {
        <div class="editor-toolbar">
          <button
            mat-button
            (click)="clear()"
            [disabled]="valid() && !draft().filterModel && !builder?.conditionCount"
          >
            Clear all
          </button>
          <button mat-button (click)="toggleExpression()" [attr.aria-pressed]="expressionOpen()">
            {{ expressionOpen() ? 'Use filter builder' : 'Edit expression' }}
          </button>
        </div>
        @if (expressionOpen()) {
          <div class="expression-editor" (input)="expressionPending()">
            <app-draft-filter-editor
              [columns]="data.columns"
              [model]="expressionModel()"
              [showBuilder]="false"
              label="Filter"
              applyLabel="Use expression"
              (modelChange)="expressionChanged($event)"
            />
          </div>
        } @else {
          <app-advanced-filter-builder
            [columns]="data.columns"
            [model]="builderModel()"
            [embedded]="true"
            [dialogMode]="true"
            [resetRevision]="resetRevision()"
            (draftChange)="draftChanged($event)"
          />
        }
      }
      @if (validation() && data.access !== 'values') {
        <p class="draft-hint" role="status"><mat-icon>info_outline</mat-icon>{{ validation() }}</p>
      }
    </div>
    <footer class="focus-actions">
      @if (data.access === 'none') {
        <button mat-button (click)="cancel()">Done</button>
      } @else {
        <span>Changes apply to this {{ data.source.chart ? 'chart' : 'table' }}.</span>
        <button mat-button (click)="cancel()">Cancel</button>
        <button mat-button [disabled]="!valid() || !changed()" (click)="apply()">
          Apply changes
        </button>
      }
    </footer>
  `,
  styles: `
    :host {
      display: flex;
      flex-direction: column;
      height: min(640px, 90dvh);
      min-height: 0;
      overflow: hidden;
      color: var(--mat-sys-on-surface);
    }
    .focus-heading {
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      padding: 20px 24px 16px;
      border-bottom: 1px solid var(--mat-sys-outline-variant);
      gap: 16px;
    }
    .focus-heading h2 {
      padding: 0;
      margin: 0;
      font-size: 21px;
      line-height: 1.3;
    }
    .focus-heading h2:before {
      display: none;
    }
    .eyebrow {
      color: var(--mat-sys-primary);
      font-size: 12px;
      font-weight: 600;
      margin: 0 0 5px;
    }
    .focus-body {
      display: flex;
      flex-direction: column;
      flex: 1;
      min-height: 0;
      overflow: auto;
    }
    .editor-toolbar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      padding: 8px 16px 0;
    }
    .editor-toolbar button {
      font-size: 12px;
    }
    app-advanced-filter-builder {
      flex: 1;
      min-height: 0;
      min-width: 0;
    }
    .expression-editor {
      padding: 16px 20px;
    }
    .access-note {
      font-size: 12px;
      line-height: 1.5;
      color: var(--mat-sys-on-surface-variant);
      margin: 14px 20px 0;
    }
    .draft-hint {
      display: flex;
      align-items: flex-start;
      gap: 8px;
      margin: 0;
      padding: 10px 20px;
      font-size: 12px;
      color: var(--mat-sys-error);
      line-height: 1.5;
    }
    .draft-hint mat-icon {
      flex-shrink: 0;
      font-size: 18px;
      width: 18px;
      height: 18px;
    }
    .focus-actions {
      display: flex;
      align-items: center;
      justify-content: flex-end;
      gap: 8px;
      padding: 12px 20px;
      border-top: 1px solid var(--mat-sys-outline-variant);
    }
    .focus-actions > span {
      margin-right: auto;
      font-size: 12px;
      color: var(--mat-sys-on-surface-variant);
    }
    @media (max-width: 600px) {
      .focus-heading {
        padding: 16px;
      }
      .focus-heading h2 {
        font-size: 19px;
      }
      .focus-actions {
        padding: 12px;
      }
      .focus-actions > span {
        display: none;
      }
      .expression-editor {
        padding: 16px 12px;
      }
    }
  `,
})
export class FilterFocusDialogComponent {
  readonly data = inject<FilterFocusData>(MAT_DIALOG_DATA);
  private readonly dialog = inject(MatDialogRef<FilterFocusDialogComponent, ViewChartDataScope>);
  private readonly state = injectUiState('FilterFocusDialog');
  readonly draft = this.state.signal(structuredClone(this.data.scope));
  readonly validation = this.state.signal('');
  readonly valid = this.state.signal(true);
  readonly expressionOpen = this.state.signal(false);
  readonly resetRevision = this.state.signal(0);
  readonly builderModel = this.state.signal(this.advancedModel(this.data.scope));
  readonly expressionModel = this.state.signal(this.builderModel());
  @ViewChild(AdvancedFilterBuilderComponent) builder?: AdvancedFilterBuilderComponent;

  constructor() {
    registerGridRuntime();
  }

  private advancedModel(scope: ViewChartDataScope): AdvancedFilterModel | null {
    return toModel(
      fromModel(scope.filterModel, scope.mode, this.data.columns),
      'advanced',
      this.data.columns,
      false,
    ) as AdvancedFilterModel | null;
  }
  changed(): boolean {
    // Merely converting a saved column filter into a tree is not a user change.
    return (
      JSON.stringify(fromModel(this.draft().filterModel, this.draft().mode, this.data.columns)) !==
      JSON.stringify(
        fromModel(this.data.scope.filterModel, this.data.scope.mode, this.data.columns),
      )
    );
  }
  draftChanged(change: FilterDraftChange): void {
    this.valid.set(change.valid);
    this.validation.set(change.message);
    if (change.valid)
      this.acceptScope({
        mode: 'advanced',
        filterModel: change.model as ViewChartDataScope['filterModel'],
      });
  }
  valuesChanged(change: FilterValuesDraft): void {
    this.valid.set(change.valid);
    this.validation.set(change.message);
    if (change.valid && change.scope) this.acceptScope(change.scope);
  }
  private acceptScope(scope: ViewChartDataScope): void {
    try {
      // Validate against the same domain contract as server requests, without copying source rows.
      fromModel(scope.filterModel, scope.mode, this.data.columns);
      this.draft.set(structuredClone(scope));
      this.valid.set(true);
      this.validation.set('');
    } catch (error) {
      this.valid.set(false);
      this.validation.set(error instanceof Error ? error.message : 'Check the filter values.');
    }
  }
  toggleExpression(): void {
    const model = this.advancedModel(this.draft());
    this.builderModel.set(model);
    this.expressionModel.set(model);
    this.valid.set(true);
    this.validation.set('');
    this.expressionOpen.update((open) => !open);
  }
  expressionPending(): void {
    this.valid.set(false);
    this.validation.set('Use the expression to validate it, then apply changes.');
  }
  expressionChanged(model: AdvancedFilterModel | null): void {
    this.expressionModel.set(model);
    this.acceptScope({ mode: 'advanced', filterModel: model as ViewChartDataScope['filterModel'] });
  }
  clear(): void {
    if (this.data.access === 'none' || this.data.access === 'values') return;
    this.builder?.reset();
    this.builderModel.set(null);
    this.expressionModel.set(null);
    this.expressionOpen.set(false);
    this.resetRevision.update((n) => n + 1);
    this.acceptScope({ mode: this.data.scope.mode, filterModel: null });
  }
  apply(): void {
    if (this.data.access !== 'none' && this.valid() && this.changed())
      this.dialog.close(structuredClone(this.draft()));
  }
  cancel(): void {
    this.dialog.close();
  }
}
