/**
 * The lifecycle vocabulary shared by the studio, the published view page and the
 * dashboard composer. One state, one chip, at most one primary action.
 */
export type LifecycleState =
  | 'exploring'
  | 'draftDirty'
  | 'draftAhead'
  | 'draftCurrent'
  | 'published'
  | 'busy';

export type LifecycleTone = 'neutral' | 'tertiary' | 'accent' | 'pending';

export interface LifecycleAction {
  id: string;
  label: string;
  icon?: string;
  disabled?: boolean;
  tooltip?: string;
  destructive?: boolean;
  /** Separate this entry from the previous one in the overflow menu. */
  divider?: boolean;
}

export interface LifecycleStatus {
  state: LifecycleState;
  label: string;
  tone: LifecycleTone;
  icon: string;
  hint: string;
}

export interface LifecyclePlan {
  status: LifecycleStatus;
  primary: LifecycleAction | null;
  secondary: LifecycleAction[];
  overflow: LifecycleAction[];
}

export interface StudioLifecycleInput {
  mode: 'model' | 'new' | 'draft' | 'published';
  modelName: string;
  /** Present once the tab is backed by a saved view. */
  version?: number;
  publishedVersion?: number | null;
  /** Version of a newer draft when a published tab has one. */
  draftVersion?: number;
  /** Changes worth warning about (any edit on a draft; meaningful work in an exploration). */
  dirty: boolean;
  /** Any edit at all, layout included. */
  hasEdits: boolean;
  canEdit: boolean;
  canAddToDashboard?: boolean;
  /** Download lives beside the table and chart controls, not in the bar; kept for callers. */
  canDownload?: boolean;
  editorReady: boolean;
  operation?: 'naming' | 'saving' | 'publishing' | 'drafting' | 'deleting';
}

const busyLabels = {
  naming: 'Naming view…',
  saving: 'Saving…',
  publishing: 'Publishing…',
  drafting: 'Opening draft…',
  deleting: 'Deleting…',
};

export function studioLifecycleState(input: StudioLifecycleInput): LifecycleState {
  if (input.operation) return 'busy';
  if (input.mode === 'published') return 'published';
  if (input.version === undefined) return 'exploring';
  if (input.dirty) return 'draftDirty';
  return input.publishedVersion != null && input.version === input.publishedVersion
    ? 'draftCurrent'
    : 'draftAhead';
}

/** The complete header plan for one studio tab; copy lives here, not in templates. */
export function studioLifecycle(input: StudioLifecycleInput): LifecyclePlan {
  const state = studioLifecycleState(input);
  const locked = !input.editorReady;
  const editable = input.canEdit && input.mode !== 'published';
  const settings = (readOnly: boolean): LifecycleAction => ({
    id: 'settings',
    label: 'View settings',
    icon: 'tune',
    tooltip: readOnly
      ? 'View settings (read only)'
      : 'Name, description, group, tags and reader experience',
    disabled: locked,
  });
  const saveAsNew: LifecycleAction = {
    id: 'saveAsNew',
    label: 'Save as new',
    icon: 'copy_all',
    disabled: locked,
  };
  const openPublished: LifecycleAction[] =
    input.publishedVersion != null
      ? [
          {
            id: 'openPublished',
            label: `Open published v${input.publishedVersion}`,
            icon: 'public',
            disabled: locked,
          },
        ]
      : [];
  const remove: LifecycleAction = {
    id: 'delete',
    label: 'Delete view',
    icon: 'delete_outline',
    destructive: true,
    divider: true,
    disabled: locked,
  };
  const importData: LifecycleAction = {
    id: 'import',
    label: 'Import CSV or JSON',
    icon: 'upload_file',
  };
  const library: LifecycleAction = {
    id: 'library',
    label: 'Published library',
    icon: 'view_module',
    divider: true,
  };

  if (state === 'busy') {
    const label = busyLabels[input.operation ?? 'saving'];
    return {
      status: {
        state,
        label,
        tone: 'pending',
        icon: 'hourglass_top',
        hint: input.operation === 'naming' ? 'Choose a name for your draft.' : 'Please wait.',
      },
      primary: null,
      secondary: [],
      overflow: [],
    };
  }
  if (state === 'exploring') {
    return {
      status: {
        state,
        label: input.dirty
          ? `Exploring ${input.modelName} · unsaved work`
          : `Exploring ${input.modelName}`,
        tone: input.dirty ? 'tertiary' : 'neutral',
        icon: input.dirty ? 'edit_note' : 'storage',
        hint: input.dirty
          ? 'Charts, filters and calculations are kept only when you save them as a view.'
          : 'Explore freely. Save as a view to keep a configuration.',
      },
      primary: editable
        ? {
            id: 'save',
            label: 'Save as view',
            icon: 'save',
            disabled: locked,
            tooltip: 'Save as a view',
          }
        : null,
      secondary: editable
        ? [
            {
              id: 'publish',
              label: 'Publish',
              icon: 'publish',
              disabled: true,
              tooltip: 'Save as a view before publishing',
            },
          ]
        : [],
      overflow: [
        importData,
        {
          id: 'reset',
          label: 'Reset explorer',
          icon: 'restart_alt',
          disabled: locked || !input.hasEdits,
        },
        library,
      ],
    };
  }
  if (state === 'published') {
    const version = input.publishedVersion ?? input.version;
    return {
      status: {
        state,
        label: `Published v${version} · Read only`,
        tone: 'accent',
        icon: 'lock_outline',
        hint: input.canEdit
          ? 'Readers see this revision. Edit a draft to make changes.'
          : 'Viewing the published version.',
      },
      primary: input.canEdit
        ? {
            id: 'editDraft',
            label: input.draftVersion ? `Open draft v${input.draftVersion}` : 'Edit draft',
            icon: 'edit',
            tooltip: input.draftVersion
              ? 'A newer draft already exists'
              : 'Create the next draft version',
          }
        : null,
      secondary: input.canAddToDashboard
        ? [
            {
              id: 'addToDashboard',
              label: 'Add to dashboard',
              icon: 'dashboard_customize',
              tooltip: 'Place this view on a dashboard',
            },
          ]
        : [],
      overflow: [settings(true), { id: 'copyLink', label: 'Copy link', icon: 'link' }, library],
    };
  }
  const version = input.version!;
  if (state === 'draftDirty') {
    return {
      status: {
        state,
        label: `Draft v${version} · Unsaved changes`,
        tone: 'tertiary',
        icon: 'edit_note',
        hint: 'Save your changes to update this draft.',
      },
      primary: {
        id: 'save',
        label: 'Save',
        icon: 'save',
        disabled: locked,
        tooltip: 'Save draft (Ctrl+S)',
      },
      secondary: [
        {
          id: 'publish',
          label: 'Publish',
          icon: 'publish',
          disabled: locked,
          tooltip: 'Save, then publish this version',
        },
        { id: 'preview', label: 'Preview as reader', icon: 'visibility', disabled: locked },
      ],
      overflow: [
        { id: 'discard', label: 'Discard changes', icon: 'undo', disabled: locked },
        saveAsNew,
        settings(false),
        ...openPublished,
        remove,
        library,
      ],
    };
  }
  if (state === 'draftCurrent') {
    return {
      status: {
        state,
        label: `Published v${version} · Up to date`,
        tone: 'accent',
        icon: 'check_circle_outline',
        hint: 'This draft matches the published revision.',
      },
      primary: null,
      secondary: [
        { id: 'save', label: 'Save', icon: 'save', disabled: true, tooltip: 'No unsaved changes' },
        {
          id: 'publish',
          label: 'Publish',
          icon: 'publish',
          disabled: true,
          tooltip: 'This version is already published',
        },
        ...openPublished.map((action) => ({ ...action, label: 'Open published' })),
      ],
      overflow: [saveAsNew, settings(false), remove, library],
    };
  }
  return {
    status: {
      state,
      label: `Draft v${version} · Saved`,
      tone: 'neutral',
      icon: 'check_circle_outline',
      hint: 'Publish when you’re ready to share.',
    },
    primary: {
      id: 'publish',
      label: 'Publish',
      icon: 'publish',
      disabled: locked,
      tooltip: 'Publish this version to readers',
    },
    secondary: [
      { id: 'save', label: 'Save', icon: 'save', disabled: true, tooltip: 'No unsaved changes' },
      { id: 'preview', label: 'Preview as reader', icon: 'visibility', disabled: locked },
    ],
    overflow: [saveAsNew, settings(false), ...openPublished, remove, library],
  };
}
