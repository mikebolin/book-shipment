import type { GridState } from 'ag-grid-community';
import type { ColumnSpec } from '../core/domain/schema';
import type { Mode } from '../core/domain/contracts';
import { fromModel } from '../core/domain/grid-model';
import { evaluate } from '../core/domain/engine';

/** Explicit full-fixture export; never infer completeness from the grid's block cache. */
export function filteredExportRows<T extends Record<string, unknown>>(
  rows: readonly T[],
  columns: readonly ColumnSpec[],
  state: GridState,
  mode: Mode,
  rowId: string,
): T[] {
  const filter = fromModel(
    mode === 'advanced' ? state.filter?.advancedFilterModel : state.filter?.filterModel,
    mode,
    columns,
  );
  const result = rows.filter((row) =>
    evaluate(filter, row as Record<string, string | number | null>),
  );
  const ids = new Set(columns.map((c) => c.id));
  const sort = (state.sort?.sortModel ?? []).filter((s) => ids.has(s.colId));
  if (!sort.some((s) => s.colId === rowId)) sort.push({ colId: rowId, sort: 'asc' });
  return result.sort((a, b) => {
    for (const s of sort) {
      const x = a[s.colId] as string | number | null,
        y = b[s.colId] as string | number | null;
      if (x === y) continue;
      if (x == null) return 1;
      if (y == null) return -1;
      return (x < y ? -1 : 1) * (s.sort === 'asc' ? 1 : -1);
    }
    return 0;
  });
}
