import type { Node } from '../core/domain/contracts';
import { fromModel } from '../core/domain/grid-model';
import type { ColumnSpec } from '../core/domain/schema';
import type { ViewChartDataScope } from '../core/domain/workspace.types';

const operators: Record<string, string> = {
  equals: 'is',
  notEqual: 'is not',
  contains: 'contains',
  notContains: 'does not contain',
  startsWith: 'starts with',
  endsWith: 'ends with',
  greaterThan: 'is greater than',
  greaterThanOrEqual: 'is at least',
  lessThan: 'is less than',
  lessThanOrEqual: 'is at most',
  blank: 'is blank',
  notBlank: 'is not blank',
};

/** Keep Boolean grouping explicit: a flattened list loses the meaning of nested ORs. */
export function describeFilterScope(
  scope: ViewChartDataScope,
  columns: readonly ColumnSpec[],
): string {
  try {
    const root = fromModel(scope.filterModel, scope.mode, columns);
    if (!root) return 'All records';
    const value = (item: string | number | null, column?: ColumnSpec): string => {
      if (item === null) return '(blank)';
      if (typeof item === 'number') return String(item);
      const canonical = column?.values?.find(
        (option) =>
          typeof option === 'string' && option.toLocaleLowerCase() === item.toLocaleLowerCase(),
      );
      return JSON.stringify(canonical ?? item);
    };
    const describe = (node: Node, nested = false): string => {
      if (node.kind === 'group') {
        const text = node.children
          .map((child) => describe(child, true))
          .join(node.join === 'AND' ? ' and ' : ' or ');
        return nested && node.children.length > 1 ? `(${text})` : text;
      }
      const column = columns.find((column) => column.id === node.field);
      const label = column?.label ?? node.field;
      if (node.kind === 'set') {
        if (!node.values.length)
          return node.op === 'isAnyOf'
            ? `${label} matches no selected values`
            : `${label} may have any value`;
        return `${label} ${node.op === 'isAnyOf' ? 'is any of' : 'is none of'} ${node.values.map((item) => value(item, column)).join(', ')}`;
      }
      return `${label} ${operators[node.op] ?? node.op}${node.value === null ? '' : ' ' + value(node.value, column)}`;
    };
    return describe(root) || 'All records';
  } catch {
    return 'Saved filter expression is unavailable. Review the view configuration.';
  }
}
