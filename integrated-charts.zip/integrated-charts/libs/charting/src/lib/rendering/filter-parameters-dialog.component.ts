import { GridPopupLayerDirective } from '../ui/grid-popup-layer';
import { injectUiState } from '../core/state/index';
import { Component, ElementRef, ViewChild, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { AgGridAngular } from 'ag-grid-angular';
import type { AdvancedFilterModel, ColDef, GridApi, GridReadyEvent } from 'ag-grid-community';
import type { ColumnSpec } from '../core/domain/schema';
import { fromModel, toModel } from '../core/domain/grid-model';
import { AdvancedFilterBuilderComponent } from '../explorer/advanced-filter-builder.component';
import { AppThemeService } from '../explorer/app-theme.service';
import { registerGridRuntime } from '../explorer/grid-runtime';
import { filterParameters, parameterText } from './filter-parameters';

@Component({
  standalone: true,
  imports: [
    GridPopupLayerDirective,
    MatDialogModule,
    MatButtonModule,
    AgGridAngular,
    AdvancedFilterBuilderComponent,
  ],
  template: `
    <h2 mat-dialog-title>View filters</h2>
    <mat-dialog-content>
      <p class="hint">
        {{
          data.editable
            ? 'Build conditions or write an expression. Apply to update the chart and table together.'
            : 'Saved conditions for this published view.'
        }}
      </p>
      @if (data.editable) {
        <div class="filter-editor-tabs" role="group" aria-label="Filter editor">
          <button mat-button [attr.aria-pressed]="editor() === 'builder'" (click)="showBuilder()">
            Build conditions
          </button>
          <button
            mat-button
            [attr.aria-pressed]="editor() === 'expression'"
            (click)="showExpression()"
          >
            Write expression
          </button>
        </div>
        <div [hidden]="editor() !== 'builder'">
          <app-advanced-filter-builder
            [embedded]="true"
            [columns]="data.columns"
            [model]="model()"
            title="Filter conditions"
            (applied)="apply($event)"
            (cleared)="error.set('')"
            (closed)="ref.close()"
          />
        </div>
        <div class="expression-editor" [hidden]="editor() !== 'expression'">
          <p class="hint">
            Choose a field, its operator and a value. Combine conditions with AND / OR.
          </p>
          <div #expressionHost class="published-expression-host"></div>
          <button mat-button (click)="applyExpression()">Apply filters</button>
        </div>
        <ag-grid-angular
          prismPopupLayer
          class="expression-grid"
          aria-hidden="true"
          inert
          [theme]="theme.gridTheme()"
          [columnDefs]="columns"
          [defaultColDef]="defaults"
          [rowData]="[]"
          [enableAdvancedFilter]="true"
          [advancedFilterParams]="{ suppressBuilderButton: true }"
          [advancedFilterParent]="expressionHost"
          [initialState]="initialState"
          (gridReady)="gridReady($event)"
          (filterChanged)="syncExpression()"
        />
      } @else {
        @for (parameter of parameters; track parameter.id) {
          <p class="saved-condition">
            {{ parameter.label }} {{ parameter.operator }}
            <strong>{{ describe(parameter) }}</strong>
          </p>
        }
        @if (!parameters.length) {
          <p>All records.</p>
        }
      }
      @if (error()) {
        <p class="error" role="alert">{{ error() }}</p>
      }
    </mat-dialog-content>
    <mat-dialog-actions align="end"
      ><button mat-button (click)="ref.close()">
        {{ data.editable ? 'Cancel' : 'Close' }}
      </button></mat-dialog-actions
    >
  `,
  styles: `
    .hint {
      color: var(--ws-muted);
      font-size: 13px;
      line-height: 1.6;
    }
    .filter-editor-tabs {
      display: flex;
      gap: 8px;
      border-bottom: 1px solid var(--ws-border);
      margin-bottom: 16px;
    }
    [aria-pressed='true'] {
      color: var(--ws-accent);
      background: var(--mat-sys-surface-container-high);
    }
    .expression-editor {
      min-height: 180px;
    }
    .expression-editor > button {
      margin-top: 18px;
    }
    .expression-grid {
      position: absolute;
      width: 1px;
      height: 1px;
      overflow: hidden;
      opacity: 0;
      pointer-events: none;
    }
    .saved-condition {
      padding: 12px 0;
      border-bottom: 1px solid var(--ws-border);
      font-size: 13px;
    }
    .error {
      color: var(--mat-sys-error);
    }
  `,
})
export class FilterParametersDialogComponent {
  private readonly reactiveState = injectUiState('FilterParametersDialogComponent');

  readonly data = inject<{
    model: unknown;
    mode: 'advanced' | 'columns';
    columns: readonly ColumnSpec[];
    editable: boolean;
  }>(MAT_DIALOG_DATA);
  readonly ref = inject(MatDialogRef<FilterParametersDialogComponent>);
  readonly theme = inject(AppThemeService);
  readonly editor = this.reactiveState.signal<'builder' | 'expression'>('builder');
  readonly model = this.reactiveState.signal(
    toModel(
      fromModel(this.data.model, this.data.mode, this.data.columns),
      'advanced',
      this.data.columns,
    ) as AdvancedFilterModel | null,
  );
  readonly initialState = { filter: { advancedFilterModel: this.model() ?? undefined } };
  readonly parameters = filterParameters(this.data.model, this.data.mode, this.data.columns);
  readonly describe = parameterText;
  readonly error = this.reactiveState.signal('');
  readonly defaults: ColDef = { filter: true };
  readonly columns: ColDef[] = this.data.columns.map((column) => ({
    field: column.id,
    headerName: column.label,
    cellDataType:
      column.kind === 'number'
        ? 'number'
        : column.kind === 'date'
          ? 'dateString'
          : column.kind === 'datetime'
            ? 'dateTimeString'
            : 'text',
  }));
  @ViewChild('expressionHost') expressionHost?: ElementRef<HTMLElement>;
  @ViewChild(AdvancedFilterBuilderComponent) builder?: AdvancedFilterBuilderComponent;
  private api?: GridApi;
  constructor() {
    registerGridRuntime();
  }
  gridReady(event: GridReadyEvent) {
    this.api = event.api;
  }
  syncExpression() {
    if (this.api) {
      this.model.set(this.api.getAdvancedFilterModel());
    }
  }
  showExpression() {
    if (this.editor() === 'expression') return;
    if (this.builder?.validationMessage) {
      this.error.set(this.builder.validationMessage);
      return;
    }
    const root = this.builder?.root;
    const model = root?.conditions.length ? structuredClone(root) : null;
    this.api?.setAdvancedFilterModel(model);
    this.model.set(model);
    this.error.set('');
    this.editor.set('expression');
  }
  showBuilder() {
    if (this.editor() === 'builder' || !this.commitExpression()) return;
    this.editor.set('builder');
  }
  private commitExpression(): boolean {
    const host = this.expressionHost?.nativeElement;
    const input = host?.querySelector<HTMLInputElement>('input');
    const apply = host?.querySelector<HTMLButtonElement>('.ag-filter-apply-panel-apply-button');
    if (!this.api || !input || !apply || !input.validity.valid) {
      this.error.set(input?.validationMessage || 'Complete a valid expression before applying.');
      return false;
    }
    apply?.click();
    this.error.set('');
    this.syncExpression();
    return true;
  }
  applyExpression() {
    if (!this.commitExpression()) return;
    this.apply(this.api?.getAdvancedFilterModel() ?? this.model());
  }
  apply(model: AdvancedFilterModel | null) {
    if (!this.data.editable) return;
    try {
      fromModel(model, 'advanced', this.data.columns);
      this.ref.close({ model, mode: 'advanced' });
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : 'Check the filter expression.');
    }
  }
}
