import { injectUiState } from '../core/state/index';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTabsModule } from '@angular/material/tabs';
import {
  normalizeServerGridSettings,
  SERVER_GRID_LIMITS,
  type ServerGridSettings,
} from '../core/domain/server-grid-settings';
export interface PublicationSettings {
  serverGrid?: ServerGridSettings;
  allowDownload?: boolean;
  displayMode: 'grid' | 'chart' | 'both';
  filterControls: {
    visible: boolean;
    parameterizable: boolean;
    editMode?: 'values' | 'expression';
  };
}

export interface ViewSettings extends PublicationSettings {
  name: string;
  description: string;
  group: string;
  tags: string[];
}

export interface ViewSettingsDialogData {
  title: string;
  modelName: string;
  value: ViewSettings;
  hasChart: boolean;
  readOnly?: boolean;
  create?: boolean;
  /** Open on the reader experience tab. */
  tab?: 'details' | 'reader';
  submit?: (value: ViewSettings) => Promise<void>;
}

/**
 * Details (what the view is called and where it is filed) and the reader experience
 * (what readers may do). Chart titles are edited on the chart itself, never here.
 */
@Component({
  standalone: true,
  imports: [
    FormsModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatSelectModule,
    MatSlideToggleModule,
    MatTabsModule,
  ],
  template: `
    <h2 mat-dialog-title>{{ data.title }}</h2>
    <form #form="ngForm" (ngSubmit)="save()">
      <mat-dialog-content>
        <p class="context">
          {{ data.modelName }} ·
          {{
            data.readOnly
              ? 'Published settings · Read only'
              : data.create
                ? 'Create a draft, then build and publish your view.'
                : 'View details and the experience readers will see.'
          }}
        </p>
        @if (error()) {
          <p class="workspace-alert" role="alert">{{ error() }}</p>
        }
        <fieldset [disabled]="busy()">
          <mat-tab-group
            [selectedIndex]="data.tab === 'reader' ? 1 : 0"
            [animationDuration]="'0ms'"
            [mat-stretch-tabs]="false"
            aria-label="View settings"
          >
            <mat-tab label="Details">
              <div class="tab-body">
                <mat-form-field appearance="outline">
                  <mat-label>Name</mat-label>
                  <input
                    matInput
                    name="name"
                    [(ngModel)]="value.name"
                    [disabled]="!!data.readOnly"
                    required
                    maxlength="120"
                    cdkFocusInitial
                  />
                  <mat-error>Enter a name for this view.</mat-error>
                </mat-form-field>
                <mat-form-field appearance="outline">
                  <mat-label>Description</mat-label>
                  <textarea
                    matInput
                    name="description"
                    [(ngModel)]="value.description"
                    [disabled]="!!data.readOnly"
                    maxlength="2000"
                    rows="2"
                  ></textarea>
                </mat-form-field>
                <div class="metadata-row">
                  <mat-form-field appearance="outline"
                    ><mat-label>Group</mat-label
                    ><input
                      matInput
                      name="group"
                      [(ngModel)]="value.group"
                      maxlength="80"
                      [disabled]="!!data.readOnly"
                  /></mat-form-field>
                  <mat-form-field appearance="outline">
                    <mat-label>Tags</mat-label
                    ><input
                      matInput
                      name="tags"
                      [(ngModel)]="tags"
                      [disabled]="!!data.readOnly"
                      placeholder="Separate with commas"
                      maxlength="263"
                    />
                    <mat-hint>Up to 8 tags, 32 characters each</mat-hint>
                  </mat-form-field>
                </div>
                @if (invalidTags()) {
                  <p class="validation" role="alert">
                    Use up to 8 tags with no more than 32 characters each.
                  </p>
                }
              </div>
            </mat-tab>
            <mat-tab label="Reader experience">
              <div class="tab-body">
                @if (data.hasChart) {
                  <mat-form-field appearance="outline"
                    ><mat-label>Default display</mat-label>
                    <mat-select
                      name="displayMode"
                      [(ngModel)]="value.displayMode"
                      [disabled]="busy() || !!data.readOnly"
                    >
                      <mat-option value="grid">Table</mat-option
                      ><mat-option value="chart">Charts</mat-option
                      ><mat-option value="both">Table and charts · saved order</mat-option>
                    </mat-select>
                    <mat-hint>Readers can still switch between charts and the table.</mat-hint>
                  </mat-form-field>
                }
                <mat-slide-toggle
                  name="allowDownload"
                  [(ngModel)]="value.allowDownload"
                  [disabled]="busy() || !!data.readOnly"
                  >Show download controls</mat-slide-toggle
                >
                <p class="hint">
                  Readers can export matching table records as CSV and charts as PNG.
                </p>
                <mat-slide-toggle
                  name="visible"
                  [(ngModel)]="value.filterControls.visible"
                  [disabled]="busy() || !!data.readOnly"
                  >Show saved filters</mat-slide-toggle
                >
                <mat-slide-toggle
                  name="parameterizable"
                  [(ngModel)]="value.filterControls.parameterizable"
                  [disabled]="busy() || !!data.readOnly || !value.filterControls.visible"
                  >Let readers change filters</mat-slide-toggle
                >
                <p class="hint">
                  Reader changes apply to each chart or table separately and are never saved.
                  Individual charts can override this in the chart builder.
                </p>
                @if (value.filterControls.visible && value.filterControls.parameterizable) {
                  <mat-form-field appearance="outline"
                    ><mat-label>What readers can change</mat-label>
                    <mat-select
                      name="filterEditMode"
                      [(ngModel)]="value.filterControls.editMode"
                      [disabled]="busy() || !!data.readOnly"
                    >
                      <mat-option value="expression"
                        >Full expression and advanced filters</mat-option
                      >
                      <mat-option value="values">Values only</mat-option>
                    </mat-select>
                    <mat-hint>Values only locks fields, operators and Boolean grouping.</mat-hint>
                  </mat-form-field>
                }
              </div>
            </mat-tab>
            <mat-tab label="Grid loading">
              <div class="tab-body">
                <p class="hint">
                  Each request loads one page. Grouped rows and drilldowns use the same limits.
                </p>
                <div class="metadata-row">
                  <mat-form-field appearance="outline">
                    <mat-label>Rows per request</mat-label>
                    <input
                      matInput
                      type="number"
                      name="cacheBlockSize"
                      [(ngModel)]="value.serverGrid.cacheBlockSize"
                      [disabled]="!!data.readOnly"
                      required
                      [min]="limits.cacheBlockSize.min"
                      [max]="limits.cacheBlockSize.max"
                      step="1"
                    />
                    <mat-hint>25–500 rows</mat-hint>
                  </mat-form-field>
                  <mat-form-field appearance="outline">
                    <mat-label>Cached pages per group</mat-label>
                    <input
                      matInput
                      type="number"
                      name="maxBlocksInCache"
                      [(ngModel)]="value.serverGrid.maxBlocksInCache"
                      [disabled]="!!data.readOnly"
                      required
                      [min]="limits.maxBlocksInCache.min"
                      [max]="limits.maxBlocksInCache.max"
                      step="1"
                    />
                    <mat-hint>1–100 pages in each open group</mat-hint>
                  </mat-form-field>
                  <mat-form-field appearance="outline">
                    <mat-label>Concurrent requests</mat-label>
                    <input
                      matInput
                      type="number"
                      name="maxConcurrentRequests"
                      [(ngModel)]="value.serverGrid.maxConcurrentRequests"
                      [disabled]="!!data.readOnly"
                      required
                      [min]="limits.maxConcurrentRequests.min"
                      [max]="limits.maxConcurrentRequests.max"
                      step="1"
                    />
                    <mat-hint>1–4 requests</mat-hint>
                  </mat-form-field>
                  <mat-form-field appearance="outline">
                    <mat-label>Scroll debounce (ms)</mat-label>
                    <input
                      matInput
                      type="number"
                      name="blockLoadDebounceMillis"
                      [(ngModel)]="value.serverGrid.blockLoadDebounceMillis"
                      [disabled]="!!data.readOnly"
                      required
                      [min]="limits.blockLoadDebounceMillis.min"
                      [max]="limits.blockLoadDebounceMillis.max"
                      step="1"
                    />
                    <mat-hint>0–2,000 milliseconds</mat-hint>
                  </mat-form-field>
                </div>
                @if (invalidGridSettings()) {
                  <p class="validation" role="alert">{{ invalidGridSettings() }}</p>
                }
                <p class="hint">
                  Changing these settings reloads the table while keeping its filters, columns and
                  grouping. More open groups can retain more pages.
                </p>
              </div>
            </mat-tab>
          </mat-tab-group>
        </fieldset>
      </mat-dialog-content>
      <mat-dialog-actions align="end">
        <button mat-button type="button" mat-dialog-close [disabled]="busy()">
          {{ data.readOnly ? 'Close' : 'Cancel' }}
        </button>
        @if (!data.readOnly) {
          <button mat-button type="submit" [disabled]="busy() || form.invalid || !valid()">
            {{ busy() ? 'Creating…' : data.create ? 'Create view' : 'Apply settings' }}
          </button>
        }
      </mat-dialog-actions>
    </form>
  `,
  styles: `
    mat-dialog-content {
      padding-top: 0 !important;
    }
    fieldset {
      border: 0;
      padding: 0;
      margin: 0;
      min-width: 0;
    }
    .tab-body {
      padding: 18px 2px 4px;
      min-height: 250px;
    }
    mat-form-field {
      display: block;
      width: 100%;
    }
    .context,
    .hint {
      color: var(--ws-muted);
      font-size: 12px;
      line-height: 1.6;
      margin: 0 0 18px;
    }
    .metadata-row {
      display: grid;
      grid-template-columns: 1fr 1.4fr;
      gap: 12px;
    }
    mat-slide-toggle {
      display: block;
      margin: 14px 0;
    }
    .validation {
      color: var(--mat-sys-error);
      font-size: 12px;
    }
    mat-dialog-actions {
      padding: 12px 24px 20px;
      gap: 8px;
    }
    @media (max-width: 480px) {
      .metadata-row {
        grid-template-columns: 1fr;
        gap: 0;
      }
    }
  `,
})
export class ViewSettingsDialogComponent {
  private readonly reactiveState = injectUiState('ViewSettingsDialogComponent');

  readonly data = inject<ViewSettingsDialogData>(MAT_DIALOG_DATA);
  readonly ref = inject(MatDialogRef<ViewSettingsDialogComponent>);
  readonly limits = SERVER_GRID_LIMITS;
  readonly value = {
    ...structuredClone(this.data.value),
    serverGrid: normalizeServerGridSettings(this.data.value.serverGrid),
    filterControls: {
      ...this.data.value.filterControls,
      editMode: this.data.value.filterControls.editMode ?? ('expression' as const),
    },
  };
  readonly busy = this.reactiveState.signal(false);
  readonly error = this.reactiveState.signal('');
  private readonly tagsState = this.reactiveState.signal(this.value.tags.join(', '));
  get tags() {
    return this.tagsState();
  }
  set tags(value) {
    this.tagsState.set(value);
  }
  private tagValues() {
    return [
      ...new Set(
        this.tags
          .split(',')
          .map((tag) => tag.trim())
          .filter(Boolean),
      ),
    ];
  }
  invalidTags() {
    const tags = this.tagValues();
    return tags.length > 8 || tags.some((tag) => tag.length > 32);
  }
  valid() {
    return !!this.value.name.trim() && !this.invalidTags() && !this.invalidGridSettings();
  }
  invalidGridSettings(): string {
    try {
      normalizeServerGridSettings(this.value.serverGrid);
      return '';
    } catch (error) {
      return error instanceof Error ? error.message : 'Enter valid grid loading limits.';
    }
  }
  async save() {
    if (this.busy() || this.data.readOnly || !this.valid()) return;
    const value: ViewSettings = {
      ...this.value,
      name: this.value.name.trim(),
      description: this.value.description.trim(),
      group: this.value.group.trim(),
      tags: this.tagValues(),
      serverGrid: normalizeServerGridSettings(this.value.serverGrid),
      displayMode: this.data.hasChart ? this.value.displayMode : 'grid',
      filterControls: {
        editMode: this.value.filterControls.editMode,
        visible: this.value.filterControls.visible,
        parameterizable:
          this.value.filterControls.visible && this.value.filterControls.parameterizable,
      },
    };
    this.busy.set(true);
    this.ref.disableClose = true;
    this.error.set('');
    try {
      await this.data.submit?.(value);
      this.ref.close(value);
    } catch (error) {
      this.error.set(
        error instanceof Error ? error.message : 'Unable to create this view. Try again.',
      );
    } finally {
      this.busy.set(false);
      this.ref.disableClose = false;
    }
  }
}
