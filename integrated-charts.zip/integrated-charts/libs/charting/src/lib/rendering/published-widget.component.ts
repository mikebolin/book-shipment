import { CHARTING_ACTIONS } from '../core/data-access/charting-actions';
import { injectUiState } from '../core/state/index';
import { Component, inject, OnDestroy, ViewChild } from '@angular/core';
import { RouterLink, ActivatedRoute, Router } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import { Subscription } from 'rxjs';
import { WorkspaceRepository } from '../core/data-access/workspace-repository.service';
import { WidgetViewComponent } from './widget-view.component';
import type {
  ModelResource,
  WidgetResource,
  WidgetConfiguration,
} from '../core/domain/workspace.types';
import { viewCharts } from './view-charts';
@Component({
  standalone: true,
  imports: [RouterLink, MatIconModule, MatButtonModule, MatTooltipModule, WidgetViewComponent],
  template: `<div class="page-wrap">
    @if (error()) {
      <div class="workspace-alert" role="alert">{{ error() }}</div>
    }
    @if (widget(); as view) {
      <header class="page-heading">
        <div class="published-title">
          <a
            mat-icon-button
            routerLink="/library"
            aria-label="Back to published views"
            matTooltip="Back to published views"
            ><mat-icon>arrow_back</mat-icon></a
          >
          <div>
            <h1 [matTooltip]="view.name">
              {{ view.name }}
            </h1>
            <span class="publication-status"><mat-icon>check_circle</mat-icon>Published view</span>
            @if (view.description) {
              <p class="publication-hint">{{ view.description }}</p>
            }
          </div>
        </div>
        <div class="header-actions">
          @if (hostActions.addToDashboard) {
            <button
              mat-button
              (click)="addToDashboard()"
              [disabled]="busy()"
              aria-label="Add to dashboard"
            >
              <mat-icon>dashboard_customize</mat-icon>Add to dashboard
            </button>
          }
          @if (view.body.allowDownload !== false) {
            <button
              mat-button
              (click)="downloadAll()"
              [disabled]="downloading() || !model()"
              aria-label="Download all"
              matTooltip="Download all charts and the table"
            >
              <mat-icon>{{ downloading() ? 'hourglass_top' : 'download' }}</mat-icon>
              <span>{{ downloading() ? 'Preparing…' : 'Download all' }}</span>
            </button>
          }
          @if (model(); as source) {
            <button
              mat-button
              (click)="editDraft()"
              [disabled]="busy()"
              aria-label="Edit draft"
              matTooltip="Create or open an editable draft"
            >
              <mat-icon>edit</mat-icon>{{ busy() ? 'Opening draft…' : 'Edit draft' }}
            </button>
          }
          @if (view.body.chart || view.body.charts?.length) {
            <div class="view-toggle">
              <button
                (click)="mode.set('chart')"
                [class.selected]="mode() === 'chart'"
                [attr.aria-pressed]="mode() === 'chart'"
                aria-label="Show chart"
                matTooltip="Show chart"
              >
                <mat-icon>bar_chart</mat-icon>
                @if (mode() === 'chart') {
                  <span>Charts</span>
                }
                <span class="chart-count" aria-label="Total charts">{{
                  chartCount(view.body)
                }}</span></button
              ><button
                (click)="mode.set('grid')"
                [class.selected]="mode() === 'grid'"
                [attr.aria-pressed]="mode() === 'grid'"
                aria-label="Show grid"
                matTooltip="Show grid"
              >
                <mat-icon>table_chart</mat-icon>
                @if (mode() === 'grid') {
                  <span>Table</span>
                }
              </button>
              <button
                (click)="mode.set('both')"
                [class.selected]="mode() === 'both'"
                [attr.aria-pressed]="mode() === 'both'"
                aria-label="Show chart and grid"
                matTooltip="Show chart and grid"
              >
                <mat-icon>view_agenda</mat-icon>
                @if (mode() === 'both') {
                  <span>Both</span>
                }
              </button>
            </div>
          }
        </div>
      </header>
      @if (model(); as source) {
        <div class="published-focus">
          <workspace-widget-view
            [model]="source"
            [configuration]="view.body"
            [displayMode]="mode()"
            [showDownloadAll]="false"
          />
        </div>
      }
    }
  </div>`,
  styles: [
    `
      :host {
        display: flex;
        flex-direction: column;
        height: 100%;
        width: 100%;
        min-height: 0;
      }
      .page-wrap {
        display: flex;
        flex-direction: column;
        flex: 1;
        min-height: 0;
        height: 100%;
        width: 100%;
        max-width: none;
      }
      .page-heading {
        flex-shrink: 0;
      }
      .view-toggle button {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        width: auto;
        min-width: 34px;
        min-height: 34px;
        padding: 0 9px;
        font: inherit;
        font-size: 12px;
        white-space: nowrap;
      }
      .chart-count {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 18px;
        height: 18px;
        border-radius: 4px;
        padding: 0 4px;
        background: var(--mat-sys-secondary-container);
        color: var(--mat-sys-on-secondary-container);
        font-size: 10px;
        font-variant-numeric: tabular-nums;
      }
      .published-title {
        display: flex;
        align-items: center;
        gap: 8px;
        min-width: 0;
      }
      .published-title h1 {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .published-title > div {
        min-width: 0;
      }
      .publication-status {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        color: var(--ws-accent);
        font-size: 12px;
      }
      .publication-status mat-icon {
        font-size: 15px;
        width: 15px;
        height: 15px;
      }
      .publication-hint {
        font-size: 12px;
        color: var(--ws-muted);
        margin: 4px 0 0;
      }
      .page-heading {
        gap: 8px;
        flex-wrap: wrap;
      }
      .published-focus {
        flex: 1;
        min-height: 0;
        overflow: hidden;
        border: 1px solid var(--ws-border);
        border-radius: 12px;
      }
      .published-focus workspace-widget-view {
        height: 100%;
      }
      @media (max-width: 700px) {
        .view-toggle button {
          min-width: 44px;
          min-height: 44px;
        }
        .published-title {
          flex: 1;
        }
        .published-title h1 {
          font-size: 18px;
        }
        .header-actions {
          margin-left: auto;
        }
      }
    `,
  ],
})
export class PublishedWidgetComponent implements OnDestroy {
  private readonly reactiveState = injectUiState('PublishedWidgetComponent');

  readonly hostActions = inject(CHARTING_ACTIONS);
  readonly workspace = inject(WorkspaceRepository);
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  readonly busy = this.reactiveState.signal(false);
  readonly downloading = this.reactiveState.signal(false);
  @ViewChild(WidgetViewComponent) private reader?: WidgetViewComponent;
  chartCount(configuration: WidgetConfiguration): number {
    return viewCharts(configuration).length;
  }
  readonly widget = this.reactiveState.signal<WidgetResource | null>(null);
  readonly model = this.reactiveState.signal<ModelResource | null>(null);
  readonly mode = this.reactiveState.signal<'chart' | 'grid' | 'both'>('chart');
  readonly error = this.reactiveState.signal('');
  private subscription: Subscription;
  private generation = 0;
  async downloadAll(): Promise<void> {
    if (!this.reader || this.downloading()) return;
    this.downloading.set(true);
    this.error.set('');
    try {
      if (this.reader.loading()) throw new Error('The view is still loading. Please try again.');
      await this.reader.downloadAll();
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : 'Unable to download this view.');
    } finally {
      this.downloading.set(false);
    }
  }
  constructor() {
    this.subscription = this.route.paramMap.subscribe(
      (params) => void this.load(params.get('slug')!),
    );
  }
  private async load(slug: string) {
    const generation = ++this.generation;
    this.error.set('');
    this.widget.set(null);
    this.model.set(null);
    try {
      const widget = await this.workspace.get<WidgetConfiguration>('widgets', slug, true);
      const model = await this.workspace.get<any>('models', widget.modelId!);
      if (generation !== this.generation) return;
      this.widget.set(widget);
      this.mode.set(
        widget.body.chart || widget.body.charts?.length
          ? (widget.body.displayMode ?? 'chart')
          : 'grid',
      );
      this.model.set(model);
    } catch (e) {
      if (generation === this.generation)
        this.error.set(e instanceof Error ? e.message : String(e));
    }
  }
  ngOnDestroy() {
    this.generation++;
    this.subscription.unsubscribe();
  }
  async addToDashboard() {
    const widget = this.widget();
    if (!widget || this.busy()) return;
    this.busy.set(true);
    try {
      await this.hostActions.addToDashboard?.(widget);
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : String(error));
    } finally {
      this.busy.set(false);
    }
  }
  async editDraft() {
    const widget = this.widget(),
      model = this.model();
    if (!widget || !model || this.busy()) return;
    this.busy.set(true);
    this.error.set('');
    try {
      const current = await this.workspace.get<WidgetConfiguration>('widgets', widget.slug);
      const draft =
        current.version === current.publishedVersion
          ? await this.workspace.update<WidgetConfiguration>('widgets', current, {
              name: current.name,
              description: current.description,
              modelId: current.modelId,
              body: current.body,
            })
          : current;
      await this.router.navigate(['/studio', model.slug], {
        queryParams: { widget: draft.slug, view: 'draft' },
      });
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : String(error));
    } finally {
      this.busy.set(false);
    }
  }
}
