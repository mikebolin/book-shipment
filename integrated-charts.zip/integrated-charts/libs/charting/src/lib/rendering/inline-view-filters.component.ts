import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
} from '@angular/core';
import type { AdvancedFilterModel } from 'ag-grid-community';
import type { ColumnSpec } from '../core/domain/schema';
import { fromModel, toModel } from '../core/domain/grid-model';
import type { GridModel } from '../core/domain/contracts';
import { DraftFilterEditorComponent } from '../explorer/draft-filter-editor.component';
import { FilterValuesFormComponent } from './filter-values-form.component';
import type { ViewChartDataScope } from '../core/domain/workspace.types';
import { injectUiState } from '../core/state/index';
@Component({
  selector: 'workspace-inline-view-filters',
  standalone: true,
  imports: [DraftFilterEditorComponent, FilterValuesFormComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `@if (access === 'expression') {
      <app-draft-filter-editor
        [columns]="columns"
        [model]="advancedModel"
        [disabled]="disabled"
        [embedded]="true"
        [showBuilder]="showBuilder"
        [label]="label"
        [applyLabel]="applyLabel"
        (modelChange)="applyExpression($event)"
      />
    } @else if (access === 'values') {
      <workspace-filter-values-form
        [columns]="columns"
        [scope]="scope"
        [disabled]="disabled"
        [label]="label"
        [applyLabel]="applyLabel"
        (scopeChange)="scopeChange.emit($event)"
      />
    }
    @if (error()) {
      <p role="alert">{{ error() }}</p>
    }`,
  styles: `
    :host {
      display: block;
      min-width: 0;
    }
    p {
      color: var(--mat-sys-error);
      font-size: 12px;
    }
  `,
})
export class InlineViewFiltersComponent implements OnChanges {
  private readonly state = injectUiState('InlineViewFilters');
  @Input() columns: readonly ColumnSpec[] = [];
  @Input({ required: true }) scope!: ViewChartDataScope;
  @Input() access: 'none' | 'values' | 'expression' = 'none';
  @Input() disabled = false;
  @Input() applyLabel = 'Apply filters';
  @Input() showBuilder = true;
  @Input() label = 'Filters';
  @Output() readonly scopeChange = new EventEmitter<ViewChartDataScope>();
  readonly error = this.state.signal('');
  advancedModel: AdvancedFilterModel | null = null;
  private signature = '';
  ngOnChanges() {
    const signature = JSON.stringify([this.scope, this.columns, this.access]);
    if (signature === this.signature) return;
    this.signature = signature;
    this.error.set('');
    try {
      this.advancedModel = toModel(
        fromModel(this.scope.filterModel, this.scope.mode, this.columns),
        'advanced',
        this.columns,
      ) as AdvancedFilterModel | null;
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : 'Unable to read filters.');
    }
  }
  applyExpression(model: AdvancedFilterModel | null) {
    if (!this.disabled && this.access === 'expression')
      this.scopeChange.emit({ mode: 'advanced', filterModel: model as GridModel });
  }
}
