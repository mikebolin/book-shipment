import { injectUiState } from '../core/state/index';
import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { WidgetViewComponent } from './widget-view.component';
import { viewCharts } from './view-charts';
import type { ModelResource, WidgetConfiguration } from '../core/domain/workspace.types';

export interface ReaderPreviewData {
  name: string;
  model: ModelResource;
  configuration: WidgetConfiguration;
}

/** Exactly what `/views/:slug` would show for the current (possibly unsaved) configuration. */
@Component({
  standalone: true,
  imports: [MatDialogModule, MatButtonModule, MatIconModule, MatTooltipModule, WidgetViewComponent],
  template: `
    <header class="preview-header">
      <div class="preview-title">
        <mat-icon aria-hidden="true">visibility</mat-icon>
        <div>
          <h2>Preview as reader</h2>
          <p>{{ data.name }} · what readers see, including unsaved changes</p>
        </div>
      </div>
      @if (hasCharts) {
        <div class="preview-modes" role="group" aria-label="Display">
          <button
            mat-icon-button
            type="button"
            aria-label="Show chart"
            matTooltip="Charts"
            [class.selected]="mode() === 'chart'"
            [attr.aria-pressed]="mode() === 'chart'"
            (click)="mode.set('chart')"
          >
            <mat-icon>bar_chart</mat-icon>
          </button>
          <button
            mat-icon-button
            type="button"
            aria-label="Show grid"
            matTooltip="Table"
            [class.selected]="mode() === 'grid'"
            [attr.aria-pressed]="mode() === 'grid'"
            (click)="mode.set('grid')"
          >
            <mat-icon>table_chart</mat-icon>
          </button>
          <button
            mat-icon-button
            type="button"
            aria-label="Show chart and grid"
            matTooltip="Charts and table"
            [class.selected]="mode() === 'both'"
            [attr.aria-pressed]="mode() === 'both'"
            (click)="mode.set('both')"
          >
            <mat-icon>insert_chart</mat-icon>
          </button>
        </div>
      }
      <button
        mat-icon-button
        type="button"
        mat-dialog-close
        aria-label="Close preview"
        matTooltip="Close preview"
      >
        <mat-icon>close</mat-icon>
      </button>
    </header>
    <div class="preview-body">
      <workspace-widget-view
        [model]="data.model"
        [configuration]="data.configuration"
        [displayMode]="mode()"
        [showDownloadAll]="true"
      />
    </div>
  `,
  styles: `
    :host {
      display: flex;
      flex-direction: column;
      height: 100%;
      min-height: 0;
    }
    .preview-header {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 12px 12px 12px 20px;
      border-bottom: 1px solid var(--ws-border);
    }
    .preview-title {
      display: flex;
      align-items: center;
      gap: 12px;
      flex: 1;
      min-width: 0;
    }
    .preview-title mat-icon {
      color: var(--ws-accent);
    }
    h2 {
      margin: 0;
      font-size: 15px;
      font-weight: 600;
    }
    p {
      margin: 2px 0 0;
      color: var(--ws-muted);
      font-size: 12px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .preview-modes {
      display: flex;
      align-items: center;
      gap: 2px;
      padding: 2px;
      border-radius: 10px;
      background: var(--mat-sys-surface-container);
    }
    .preview-modes .selected {
      color: var(--ws-accent);
      background: var(--mat-sys-primary-container);
    }
    .preview-body {
      flex: 1;
      min-height: 0;
      padding: 12px;
      display: flex;
    }
    workspace-widget-view {
      flex: 1;
      min-height: 0;
    }
  `,
})
export class ReaderPreviewDialogComponent {
  private readonly reactiveState = injectUiState('ReaderPreviewDialogComponent');

  readonly data = inject<ReaderPreviewData>(MAT_DIALOG_DATA);
  readonly hasCharts = viewCharts(this.data.configuration).length > 0;
  readonly mode = this.reactiveState.signal<'grid' | 'chart' | 'both'>(
    this.hasCharts ? (this.data.configuration.displayMode ?? 'chart') : 'grid',
  );
}
