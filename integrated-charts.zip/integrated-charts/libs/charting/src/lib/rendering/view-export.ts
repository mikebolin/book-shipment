import type { ColumnSpec } from '../core/domain/schema';
import type { GridState } from 'ag-grid-community';

/** Escape CSV structure and neutralize spreadsheet formulas in untrusted text. */
export function csvCell(value: unknown): string {
  let text = value == null ? '' : String(value);
  if (typeof value === 'string' && /^[\s\u0000-\u001f]*[=+@-]/.test(text)) text = "'" + text;
  return '"' + text.replace(/"/g, '""') + '"';
}

export function viewExportColumns(columns: readonly ColumnSpec[], state: GridState): ColumnSpec[] {
  const hidden = new Set(state.columnVisibility?.hiddenColIds ?? []);
  const order = state.columnOrder?.orderedColIds ?? columns.map((c) => c.id);
  return columns
    .filter((c) => !hidden.has(c.id))
    .sort((a, b) => {
      const rank = (id: string) => (order.includes(id) ? order.indexOf(id) : order.length);
      return rank(a.id) - rank(b.id);
    });
}

export function viewCsv(
  rows: readonly Record<string, unknown>[],
  columns: readonly ColumnSpec[],
  state: GridState,
): string {
  const visible = viewExportColumns(columns, state);
  return (
    '\uFEFF' +
    [
      visible.map((c) => csvCell(c.label)),
      ...rows.map((row) => visible.map((c) => csvCell(row[c.id]))),
    ]
      .map((row) => row.join(','))
      .join('\r\n')
  );
}

export function downloadCsv(content: string, name: string): void {
  const url = URL.createObjectURL(new Blob([content], { type: 'text/csv;charset=utf-8' }));
  const link = document.createElement('a');
  link.href = url;
  link.download = (name.replace(/[^a-z0-9]+/gi, '-').slice(0, 80) || 'records') + '.csv';
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export interface ExportFile {
  name: string;
  data: Uint8Array;
}

const crcTable = Uint32Array.from({ length: 256 }, (_, value) => {
  for (let bit = 0; bit < 8; bit++) value = (value >>> 1) ^ (value & 1 ? 0xedb88320 : 0);
  return value >>> 0;
});

/** ZIP STORE keeps already-compressed PNGs fast and requires no runtime dependency. */
export function viewArchive(files: readonly ExportFile[]): Uint8Array {
  if (files.length > 65535) throw new Error('Too many files to export.');
  const encoder = new TextEncoder();
  const entries = files.map((file) => {
    const name = encoder.encode(file.name);
    if (!name.length || name.length > 65535 || /[\\/]/.test(file.name))
      throw new Error('Invalid export filename.');
    let crc = 0xffffffff;
    for (const byte of file.data) crc = (crc >>> 8) ^ crcTable[(crc ^ byte) & 255];
    return { ...file, name, crc: (crc ^ 0xffffffff) >>> 0 };
  });
  const localSize = entries.reduce(
    (sum, file) => sum + 30 + file.name.length + file.data.length,
    0,
  );
  const directorySize = entries.reduce((sum, file) => sum + 46 + file.name.length, 0);
  if (localSize + directorySize + 22 > 0xffffffff)
    throw new Error('This export exceeds the archive size limit.');
  const bytes = new Uint8Array(localSize + directorySize + 22);
  const view = new DataView(bytes.buffer);
  const word = (offset: number, value: number) => view.setUint16(offset, value, true);
  const dword = (offset: number, value: number) => view.setUint32(offset, value, true);
  let offset = 0;
  let directory = localSize;
  for (const file of entries) {
    dword(offset, 0x04034b50);
    word(offset + 4, 20);
    word(offset + 6, 0x0800);
    word(offset + 12, 33); // 1980-01-01, deterministic DOS date
    dword(offset + 14, file.crc);
    dword(offset + 18, file.data.length);
    dword(offset + 22, file.data.length);
    word(offset + 26, file.name.length);
    bytes.set(file.name, offset + 30);
    bytes.set(file.data, offset + 30 + file.name.length);
    dword(directory, 0x02014b50);
    word(directory + 4, 20);
    word(directory + 6, 20);
    word(directory + 8, 0x0800);
    word(directory + 14, 33);
    dword(directory + 16, file.crc);
    dword(directory + 20, file.data.length);
    dword(directory + 24, file.data.length);
    word(directory + 28, file.name.length);
    dword(directory + 42, offset);
    bytes.set(file.name, directory + 46);
    offset += 30 + file.name.length + file.data.length;
    directory += 46 + file.name.length;
  }
  dword(directory, 0x06054b50);
  word(directory + 8, entries.length);
  word(directory + 10, entries.length);
  dword(directory + 12, directorySize);
  dword(directory + 16, localSize);
  return bytes;
}

export function exportName(name: string): string {
  return (
    name
      .replace(/[^a-z0-9]+/gi, '-')
      .replace(/^-|-$/g, '')
      .slice(0, 80) || 'view'
  );
}

export function downloadArchive(files: readonly ExportFile[], name: string): void {
  const data = viewArchive(files);
  const url = URL.createObjectURL(
    new Blob([data as Uint8Array<ArrayBuffer>], { type: 'application/zip' }),
  );
  const link = document.createElement('a');
  link.href = url;
  link.download = exportName(name) + '.zip';
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
}
