/**
 * The four filter layers (handoff §3.3), resolved from what is known about a surface.
 * Pure so the chip, the inspector and the tests agree on labels and reset targets.
 */
export type FilterLayer = 'table' | 'chart' | 'inherited' | 'override' | 'session';

export interface ScopeLayerInput {
  component: 'table' | 'chart';
  /** A chart with its own `dataScope`; a legacy chart without one follows the table filter. */
  independent?: boolean;
  /** A dashboard override exists for this component and differs from the view. */
  overridden?: boolean;
  /** The reader changed the filter in this session (nothing is saved). */
  adjusted?: boolean;
  /** The current user is editing the view (author) rather than reading it. */
  editable?: boolean;
}

export interface ScopeLayer {
  layer: FilterLayer;
  /** Chip label after the summary, e.g. `Chart filter`. */
  label: string;
  tone: 'neutral' | 'secondary' | 'tertiary';
  /** Which layer an edit here writes to. */
  editsLabel: string;
  /** What reset returns to; null when there is nothing to reset. */
  resetLabel: string | null;
  /** The legacy "follows the table filter" chart can be pinned to its own filter. */
  canMakeIndependent: boolean;
}

export function scopeLayer(input: ScopeLayerInput): ScopeLayer {
  if (input.adjusted)
    return {
      layer: 'session',
      label: 'Adjusted · not saved',
      tone: 'tertiary',
      editsLabel: 'your session only',
      resetLabel: 'Reset',
      canMakeIndependent: false,
    };
  if (input.overridden)
    return {
      layer: 'override',
      label: 'Dashboard override',
      tone: 'secondary',
      editsLabel: 'this dashboard element only',
      resetLabel: 'Reset to view',
      canMakeIndependent: false,
    };
  if (input.component === 'chart' && input.independent === false)
    return {
      layer: 'inherited',
      label: 'Follows table filter',
      tone: 'neutral',
      editsLabel: 'this chart, once it is made independent',
      resetLabel: null,
      canMakeIndependent: !!input.editable,
    };
  if (input.component === 'chart')
    return {
      layer: 'chart',
      label: 'Chart filter',
      tone: 'neutral',
      editsLabel: 'this chart only',
      resetLabel: input.editable ? 'Clear' : null,
      canMakeIndependent: false,
    };
  return {
    layer: 'table',
    label: 'Table filter',
    tone: 'neutral',
    editsLabel: 'the table only',
    resetLabel: input.editable ? 'Clear' : null,
    canMakeIndependent: false,
  };
}

/** One sentence that answers "what does this layer affect". */
export function layerLegend(layer: ScopeLayer, componentLabel: string): string {
  switch (layer.layer) {
    case 'session':
      return `You are adjusting ${componentLabel} for this session. Nothing is saved; Reset returns to the published filter.`;
    case 'override':
      return `This dashboard overrides the view’s filter for ${componentLabel}. The view itself is unchanged; Reset to view removes the override.`;
    case 'inherited':
      return `${componentLabel} follows the table filter. Make it independent to give it its own filter.`;
    case 'chart':
      return `This filter belongs to ${componentLabel} only. The table and other charts keep their own filters.`;
    default:
      return `This filter applies to the table. Charts keep their own filters.`;
  }
}
