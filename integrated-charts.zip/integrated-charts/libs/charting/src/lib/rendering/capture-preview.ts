import type { ChartResponse } from '../core/domain/integrated-chart';
import type { WorkspacePreview } from '../core/domain/workspace-cards';

const plain = (value: string, limit: number) =>
  value
    .replace(/[<>\u0000-\u001f\u007f]/g, ' ')
    .trim()
    .slice(0, limit);

/** A small inert thumbnail of the saved result, independent of live chart configuration. */
export function capturePreview(chart: ChartResponse): WorkspacePreview {
  const sourceColumns = chart.columns.slice(0, 8);
  const columns = sourceColumns.map((column, index) => ({
    id: `p${index}`,
    label: plain(column.label, 120) || 'Value',
    dataType: column.dataType,
  }));
  const preview: WorkspacePreview = {
    schemaVersion: 1,
    type: 'chart',
    chartType: chart.type,
    title: plain(chart.title, 120) || 'Saved chart',
    columns,
    totalRows: chart.rows.length,
    rows: chart.rows.slice(0, 48).map((row) =>
      Object.fromEntries(
        sourceColumns.map((column, index) => {
          const value = row[column.id];
          return [
            `p${index}`,
            typeof value === 'string'
              ? plain(value, 64)
              : typeof value === 'number' && Number.isFinite(value)
                ? value
                : null,
          ];
        }),
      ),
    ),
  };
  const encoder = new TextEncoder();
  while (preview.rows!.length && encoder.encode(JSON.stringify(preview)).byteLength > 32_768)
    preview.rows!.pop();
  return preview;
}
