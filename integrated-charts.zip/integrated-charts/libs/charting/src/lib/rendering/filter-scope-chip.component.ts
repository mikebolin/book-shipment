import { injectUiState } from '../core/state/index';
import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output,
  inject,
  computed,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDialog } from '@angular/material/dialog';
import { firstValueFrom } from 'rxjs';
import type { FilterPreviewSource } from './filter-preview';
import { MatTooltipModule } from '@angular/material/tooltip';
import type { ColumnSpec } from '../core/domain/schema';
import type { ViewChartDataScope } from '../core/domain/workspace.types';
import { describeFilterScope } from './filter-summary';
import { layerLegend, scopeLayer, type ScopeLayerInput } from './filter-scope';

/** Opens the selected visual's private filter draft or saved filter hierarchy. */
@Component({
  selector: 'workspace-filter-scope-chip',
  standalone: true,
  imports: [MatButtonModule, MatIconModule, MatTooltipModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <button
      type="button"
      mat-button
      class="scope-chip"
      [class]="'scope-chip tone-' + layer().tone + (dense ? ' dense' : '')"
      [disabled]="disabled"
      (click)="openEditor()"
      [attr.aria-label]="
        'Filters for ' + componentLabel + ': ' + summary() + ' (' + layer().label + ')'
      "
      [matTooltip]="tooltip()"
      [attr.data-filter-scope]="scopeId"
      [attr.data-filter-layer]="layer().layer"
    >
      <mat-icon aria-hidden="true">{{ icon() }}</mat-icon>
      <span class="filter-action-label">Filters</span>
      @if (scope.filterModel) {
        <span class="chip-summary">{{ summary() }}</span>
      }
    </button>
  `,
  styles: `
    :host {
      display: inline-flex;
      min-width: 0;
      max-width: 100%;
    }
    .scope-chip {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      max-width: 100%;
      min-width: 0;
      padding: 0 8px;
      border: 0;
      border-radius: 4px;
      background: transparent;
      color: var(--mat-sys-primary);
      font: inherit;
      font-size: 12px;
      line-height: 1.4;
      cursor: pointer;
      text-align: left;
    }
    .scope-chip.dense {
      padding: 0 6px;
    }
    .scope-chip:hover:not(:disabled) {
      background: color-mix(in srgb, var(--mat-sys-primary) 8%, transparent);
    }
    .scope-chip:focus-visible {
      outline: 2px solid var(--ws-accent);
      outline-offset: 1px;
    }
    .scope-chip:disabled {
      cursor: default;
      opacity: 0.7;
    }
    .scope-chip.tone-secondary {
      background: transparent;
      color: var(--mat-sys-primary);
    }
    .scope-chip.tone-tertiary {
      background: transparent;
      color: var(--mat-sys-primary);
    }
    .scope-chip mat-icon {
      width: 16px;
      height: 16px;
      font-size: 16px;
      flex-shrink: 0;
    }
    .chip-summary {
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      max-width: 42ch;
      margin-left: 6px;
      color: var(--mat-sys-on-surface-variant);
      font-size: 11px;
    }
    .filter-action-label {
      flex-shrink: 0;
      white-space: nowrap;
    }
  `,
})
export class FilterScopeChipComponent {
  private readonly reactiveState = injectUiState('FilterScopeChipComponent');

  @Input({ required: true }) scope!: ViewChartDataScope;
  @Input() columns: readonly ColumnSpec[] = [];
  @Input() componentLabel = 'Table';
  @Input() component: 'table' | 'chart' = 'table';
  @Input() access: 'none' | 'values' | 'expression' = 'none';
  @Input() independent = true;
  @Input() overridden = false;
  @Input() adjusted = false;
  @Input() editable = false;
  @Input() disabled = false;
  @Input() dense = false;
  /** Test hook value for `data-filter-scope`: `table` or the chart id. */
  @Input() preview?: FilterPreviewSource;
  @Input() scopeId = 'table';
  @Output() readonly scopeChange = new EventEmitter<ViewChartDataScope>();
  @Output() readonly reset = new EventEmitter<void>();
  @Output() readonly makeIndependent = new EventEmitter<void>();
  private readonly dialogs = inject(MatDialog);
  readonly opened = this.reactiveState.signal(false);
  private readonly inputs = this.reactiveState.signal(0);

  readonly layer = computed(() => {
    this.inputs();
    return scopeLayer(this.layerInput());
  });
  readonly summary = computed(() => {
    this.inputs();
    return describeFilterScope(this.scope, this.columns);
  });
  readonly legend = computed(() => layerLegend(this.layer(), this.componentLabel));
  readonly icon = computed(() =>
    this.layer().layer === 'session'
      ? 'tune'
      : this.layer().layer === 'override'
        ? 'layers'
        : 'filter_alt',
  );
  readonly tooltip = computed(
    () =>
      `${this.componentLabel}: ${this.summary()} · ${this.layer().label}. Open filters to review or change.`,
  );
  private layerInput(): ScopeLayerInput {
    return {
      component: this.component,
      independent: this.independent,
      overridden: this.overridden,
      adjusted: this.adjusted,
      editable: this.editable,
    };
  }
  ngOnChanges() {
    this.inputs.update((value) => value + 1);
  }
  async openEditor() {
    if (this.disabled || this.opened()) return;
    this.opened.set(true);
    try {
      const { FilterFocusDialogComponent } = await import('./filter-focus-dialog.component');
      const scope = await firstValueFrom(
        this.dialogs
          .open(FilterFocusDialogComponent, {
            width: '820px',
            maxWidth: '96vw',
            maxHeight: '94dvh',
            autoFocus: 'first-heading',
            data: {
              title: this.componentLabel,
              columns: this.columns,
              scope: structuredClone(this.scope),
              source: this.preview ?? { rows: [] },
              access: this.access,
            },
          })
          .afterClosed(),
      );
      if (scope) this.scopeChange.emit(scope);
    } finally {
      this.opened.set(false);
    }
  }
}
