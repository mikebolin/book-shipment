import { DOCUMENT } from '@angular/common';
import {
  ApplicationRef,
  EnvironmentInjector,
  Injectable,
  createComponent,
  inject,
} from '@angular/core';
import type { ChartResponse } from '../core/domain/integrated-chart';
import {
  IntegratedChartComponent,
  type ChartPresentation,
} from '../explorer/integrated-chart.component';
import { downloadArchive, exportName, type ExportFile } from './view-export';

export interface ViewExportSection {
  name: string;
  charts: readonly { data: ChartResponse; presentation?: ChartPresentation | null }[];
  csv?: string;
}

@Injectable({ providedIn: 'root' })
export class ViewExportService {
  private readonly application = inject(ApplicationRef);
  private readonly environment = inject(EnvironmentInjector);
  private readonly document = inject(DOCUMENT);

  /** Render one chart at a time so large views do not mount every chart simultaneously. */
  async downloadAll(
    charts: readonly { data: ChartResponse; presentation?: ChartPresentation | null }[],
    csv: string,
    name: string,
  ): Promise<void> {
    await this.downloadPage([{ name, charts, csv }], name, false);
  }

  /** One archive for the entire page, including charts outside the visible carousel. */
  async downloadPage(
    sections: readonly ViewExportSection[],
    name: string,
    prefixSections = true,
  ): Promise<void> {
    const files: ExportFile[] = [];
    for (const [sectionIndex, section] of sections.entries()) {
      const prefix = prefixSections
        ? `${String(sectionIndex + 1).padStart(2, '0')}-${exportName(section.name)}-`
        : '';
      const charts = section.charts;
      for (const [index, chart] of charts.entries()) {
        const host = this.document.createElement('div');
        host.style.cssText =
          'position:fixed;left:-20000px;top:0;width:1200px;height:720px;pointer-events:none;';
        host.setAttribute('aria-hidden', 'true');
        host.inert = true;
        this.document.body.appendChild(host);
        const component = createComponent(IntegratedChartComponent, {
          environmentInjector: this.environment,
          hostElement: host,
        });
        try {
          component.setInput('dataset', chart.data);
          component.setInput('presentation', chart.presentation ?? null);
          component.setInput('readonlyView', true);
          component.setInput('allowDownload', true);
          component.setInput('showDownloadControl', false);
          component.setInput('compact', true);
          component.setInput('disabled', true);
          this.application.attachView(component.hostView);
          component.changeDetectorRef.detectChanges();
          const image = await component.instance.imageDataUrl();
          const binary = atob(image.slice(image.indexOf(',') + 1));
          files.push({
            name: `${prefix}${String(index + 1).padStart(2, '0')}-${exportName(chart.data.title)}.png`,
            data: Uint8Array.from(binary, (char) => char.charCodeAt(0)),
          });
        } finally {
          this.application.detachView(component.hostView);
          component.destroy();
          host.remove();
        }
      }
      if (section.csv !== undefined)
        files.push({
          name: `${prefix}${String(charts.length + 1).padStart(2, '0')}-table.csv`,
          data: new TextEncoder().encode(section.csv),
        });
    }
    if (!files.length) throw new Error('There are no downloadable charts or tables on this page.');
    downloadArchive(files, name);
  }
}
