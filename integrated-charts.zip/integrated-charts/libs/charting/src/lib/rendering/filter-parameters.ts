import type { ColumnSpec } from '../core/domain/schema';

type FilterNode = Record<string, unknown>;
type Path = (string | number)[];
export interface FilterParameter {
  id: string;
  path: Path;
  key: string;
  columnId: string;
  label: string;
  operator: string;
  group: string;
  kind: 'text' | 'number' | 'date' | 'datetime' | 'set' | 'boolean' | 'none';
  value: unknown;
  options: (string | null)[];
}
const object = (value: unknown): value is FilterNode =>
  !!value && typeof value === 'object' && !Array.isArray(value);
export const filterOperatorLabel = (value: unknown) =>
  String(value ?? 'matches')
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .toLowerCase();

/** Every saved predicate is retained; only its existing comparison values become parameters. */
export function filterParameters(
  model: unknown,
  mode: 'advanced' | 'columns',
  columns: readonly ColumnSpec[],
): FilterParameter[] {
  const result: FilterParameter[] = [];
  const walk = (node: unknown, path: Path, inheritedColumn = '', groups: string[] = []) => {
    if (!object(node)) return;
    const columnId = String(node['colId'] ?? inheritedColumn);
    if (Array.isArray(node['conditions'])) {
      const join = String(node['type'] ?? node['operator'] ?? 'AND');
      node['conditions'].forEach((condition, index) =>
        walk(condition, [...path, 'conditions', index], columnId, [...groups, join]),
      );
      return;
    }
    const column = columns.find((item) => item.id === columnId);
    const type = String(node['filterType']);
    const valueKeys = ['filter', 'filterTo', 'dateFrom', 'dateTo', 'values'].filter(
      (key) => Object.hasOwn(node, key) && node[key] != null,
    );
    const keys = valueKeys.length ? valueKeys : [''];
    for (const key of keys) {
      const value = key ? node[key] : null;
      result.push({
        id: JSON.stringify([...path, key]),
        path,
        key,
        columnId,
        label:
          (column?.label ?? columnId) +
          (key === 'filterTo' || key === 'dateTo' ? ' · upper bound' : ''),
        operator: filterOperatorLabel(node['type']),
        group: groups.join(' / '),
        kind: !key
          ? 'none'
          : key === 'values'
            ? 'set'
            : type === 'boolean'
              ? 'boolean'
              : (column?.kind ??
                (type === 'number'
                  ? 'number'
                  : type === 'dateString' || type === 'date'
                    ? 'date'
                    : type === 'dateTimeString'
                      ? 'datetime'
                      : 'text')),
        value: structuredClone(value),
        options: [
          ...new Set([
            ...(column?.values ?? []),
            ...(Array.isArray(value) ? (value as (string | null)[]) : []),
          ]),
        ],
      });
    }
  };
  if (mode === 'advanced') walk(model, []);
  else if (object(model))
    for (const [id, node] of Object.entries(model)) walk(node, [id], id, ['AND']);
  return result;
}

export function parameterText(parameter: FilterParameter): string {
  if (parameter.kind === 'none') return 'No comparison value';
  if (Array.isArray(parameter.value))
    return (
      parameter.value.map((value) => (value === null ? '(blank)' : String(value))).join(', ') ||
      'No values selected'
    );
  return String(parameter.value ?? '');
}

/** Copy-on-apply means typing, closing, Escape and Cancel never mutate the applied model. */
export function applyFilterParameters(
  model: unknown,
  parameters: readonly FilterParameter[],
  values: Readonly<Record<string, unknown>>,
): unknown {
  const updated = structuredClone(model);
  for (const parameter of parameters) {
    if (!parameter.key || !Object.hasOwn(values, parameter.id)) continue;
    let value = values[parameter.id];
    if (parameter.kind === 'number') {
      if (value === '' || value === null || value === undefined || !Number.isFinite(Number(value)))
        throw new Error(`${parameter.label} requires a number.`);
      value = Number(value);
    } else if (parameter.kind === 'set') {
      if (!Array.isArray(value) || value.some((item) => item !== null && typeof item !== 'string'))
        throw new Error(`${parameter.label} requires a list of values.`);
      value = [...new Set(value)];
    } else if (parameter.kind === 'boolean') {
      if (typeof value !== 'boolean') throw new Error(`${parameter.label} requires true or false.`);
    } else {
      const text = String(value ?? '');
      value = text;
      if (parameter.kind === 'date') {
        const day = text.slice(0, 10);
        if (
          !/^\d{4}-\d{2}-\d{2}(?:[ T]00:00:00)?$/.test(text) ||
          !Number.isFinite(Date.parse(day)) ||
          new Date(day).toISOString().slice(0, 10) !== day
        )
          throw new Error(`${parameter.label} requires a valid calendar date.`);
        value =
          parameter.key === 'dateFrom' || parameter.key === 'dateTo' ? day + ' 00:00:00' : day;
      }
      if (parameter.kind === 'datetime') {
        // Accept a datetime-local value, a UTC timestamp or an ISO timestamp with a zone, and
        // store AG Grid's canonical Advanced Filter form: UTC wall time with T and no zone.
        const match =
          /^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})(?::(\d{2}))?(?:\.\d+)?(Z|[+-]\d{2}:\d{2})?$/.exec(
            text.trim(),
          );
        const at = match
          ? Date.parse(`${match[1]}T${match[2]}:${match[3] ?? '00'}${match[4] ?? 'Z'}`)
          : NaN;
        if (!Number.isFinite(at))
          throw new Error(
            `${parameter.label} requires a UTC timestamp, for example 2026-01-01T00:00:00.`,
          );
        value = new Date(at).toISOString().slice(0, 19);
      }
    }
    let target = updated as FilterNode;
    for (const part of parameter.path) target = target[part] as FilterNode;
    target[parameter.key] = value;
  }
  return updated;
}
