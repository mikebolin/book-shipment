import type { FilterPreviewSource } from './filter-preview';
import { ChangeDetectionStrategy, Component, inject, type Signal } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import type { ColumnSpec } from '../core/domain/schema';
import type { ViewChartDataScope, ViewFilterControls } from '../core/domain/workspace.types';
import { FilterScopeChipComponent } from './filter-scope-chip.component';
import { ChartTypeIconComponent } from '../explorer/chart-type-icon.component';
import type { ChartPlan } from '../core/domain/integrated-chart';

export interface FiltersOverviewRow {
  preview: FilterPreviewSource;
  id: string;
  title: string;
  chartType?: ChartPlan['type'];
  scope: ViewChartDataScope;
  independent: boolean;
  readers: string;
}

export interface FiltersOverview {
  columns: readonly ColumnSpec[];
  table: FiltersOverviewRow;
  charts: FiltersOverviewRow[];
  locked: boolean;
}

export interface FiltersOverviewData {
  overview: Signal<FiltersOverview>;
  setTableScope: (scope: ViewChartDataScope) => void;
  setChartScope: (id: string, scope: ViewChartDataScope) => void;
  applyTableToAll: () => void;
  clearAllCharts: () => void;
}

/** Every filter layer of the view in one place: the table and each chart, with bulk actions. */
@Component({
  standalone: true,
  imports: [
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    FilterScopeChipComponent,
    ChartTypeIconComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <h2 mat-dialog-title>Filters overview</h2>
    <mat-dialog-content>
      <p class="intro">
        The table and every chart keep separate filters over the same model. Open Filters to review
        or change one; the bulk actions below change every chart at once.
      </p>
      @let view = data.overview();
      <table class="overview">
        <thead>
          <tr>
            <th scope="col">Component</th>
            <th scope="col">Filter</th>
            <th scope="col">Readers can</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row"><mat-icon aria-hidden="true">table_chart</mat-icon>Table</th>
            <td>
              <workspace-filter-scope-chip
                [scope]="view.table.scope"
                [preview]="view.table.preview"
                [columns]="view.columns"
                componentLabel="Table"
                component="table"
                scopeId="table"
                [editable]="true"
                access="expression"
                [disabled]="view.locked"
                (scopeChange)="data.setTableScope($event)"
                (reset)="data.setTableScope({ mode: view.table.scope.mode, filterModel: null })"
              />
            </td>
            <td class="readers">{{ view.table.readers }}</td>
          </tr>
          @for (chart of view.charts; track chart.id) {
            <tr>
              <th scope="row">
                <app-chart-type-icon [type]="chart.chartType ?? 'bar'" />{{ chart.title }}
              </th>
              <td>
                <workspace-filter-scope-chip
                  [scope]="chart.scope"
                  [preview]="chart.preview"
                  [columns]="view.columns"
                  [componentLabel]="chart.title"
                  component="chart"
                  [scopeId]="chart.id"
                  [independent]="chart.independent"
                  [editable]="true"
                  access="expression"
                  [disabled]="view.locked"
                  (scopeChange)="data.setChartScope(chart.id, $event)"
                  (reset)="
                    data.setChartScope(chart.id, { mode: chart.scope.mode, filterModel: null })
                  "
                  (makeIndependent)="data.setChartScope(chart.id, chart.scope)"
                />
              </td>
              <td class="readers">{{ chart.readers }}</td>
            </tr>
          }
        </tbody>
      </table>
      @if (view.charts.length) {
        <div class="bulk-actions">
          <button
            mat-button
            type="button"
            [disabled]="view.locked"
            (click)="data.applyTableToAll()"
          >
            <mat-icon aria-hidden="true">content_copy</mat-icon>Apply table filter to all charts
          </button>
          <button
            mat-button
            type="button"
            [disabled]="view.locked"
            (click)="data.clearAllCharts()"
          >
            <mat-icon aria-hidden="true">filter_alt_off</mat-icon>Clear all chart filters
          </button>
        </div>
      }
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button type="button" mat-dialog-close>Done</button>
    </mat-dialog-actions>
  `,
  styles: `
    .intro {
      margin: 0 0 14px;
      color: var(--ws-muted);
      font-size: 12px;
      line-height: 1.6;
    }
    .overview {
      width: 100%;
      border-collapse: collapse;
      font-size: 12px;
    }
    .overview th,
    .overview td {
      padding: 8px 10px;
      border-bottom: 1px solid var(--ws-border);
      text-align: left;
      vertical-align: middle;
    }
    .overview thead th {
      color: var(--ws-muted);
      font-size: 11px;
      font-weight: 600;
    }
    .overview tbody th {
      display: flex;
      align-items: center;
      gap: 8px;
      font-weight: 500;
      white-space: nowrap;
      max-width: 220px;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .overview tbody th mat-icon,
    .overview tbody th app-chart-type-icon {
      color: var(--ws-accent);
      --chart-icon-size: 18px;
      width: 18px;
      height: 18px;
      font-size: 18px;
      flex-shrink: 0;
    }
    .readers {
      color: var(--ws-muted);
      white-space: nowrap;
    }
    .bulk-actions {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin-top: 14px;
    }
    .bulk-actions mat-icon {
      margin-right: 4px;
    }
    mat-dialog-actions {
      padding: 12px 24px 20px;
    }
  `,
})
export class FiltersOverviewDialogComponent {
  readonly data = inject<FiltersOverviewData>(MAT_DIALOG_DATA);
}

export function describeReaderAccess(
  controls: ViewFilterControls | undefined,
  inherited?: ViewFilterControls,
): string {
  const effective = controls ?? inherited;
  if (!effective) return 'View setting';
  if (effective.visible === false) return 'Nothing (hidden)';
  if (!effective.parameterizable) return 'Nothing (shown)';
  return effective.editMode === 'values' ? 'Values only' : 'Full expression';
}
