import { FilterValuesFormComponent } from './filter-values-form.component';
import { GridPopupLayerDirective } from '../ui/grid-popup-layer';
import { injectUiState } from '../core/state/index';
import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  Output,
  QueryList,
  SimpleChanges,
  TemplateRef,
  ViewChildren,
  computed,
  inject,
} from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { AgGridAngular } from 'ag-grid-angular';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import type { ColDef, GridApi, GridOptions, GridReadyEvent, GridState } from 'ag-grid-community';
import {
  IntegratedChartComponent,
  type ChartPresentation,
} from '../explorer/integrated-chart.component';
import { BrowserDataCache } from '../explorer/browser-data-cache';
import { AppThemeService } from '../explorer/app-theme.service';
import { registerGridRuntime } from '../explorer/grid-runtime';
import { createStudioDatasource } from '../explorer/studio-server-datasource';
import { normalizeServerGridSettings } from '../core/domain/server-grid-settings';
import { MockStudioQueryExecutor } from '../explorer/mock-studio-query-executor';
import { combineFilterModels } from '../explorer/studio-server-datasource';
import { STUDIO_QUERY_EXECUTOR } from '../explorer/studio-query-executor.token';
import { groupKeyLabel } from '../core/domain/analytics-query';
import type { AnalyticsSourceRow } from '../core/domain/analytics-engine';
import type { GetRowIdParams } from 'ag-grid-community';
import { filteredExportRows } from './filtered-export-rows';
import { calculatedColumnSpec } from '../core/domain/calculated-columns';
import { fromModel } from '../core/domain/grid-model';
import { evaluate } from '../core/domain/engine';
import { downloadCsv, viewCsv } from './view-export';
import { ViewExportService } from './view-export.service';
import type { ColumnSpec } from '../core/domain/schema';
import type { GridModel } from '../core/domain/contracts';
import type { ChartPlan, ChartResponse } from '../core/domain/integrated-chart';
import type { ClientDataSourceId } from '../explorer/client-data-sources';
import type { StreamRow } from '../explorer/ndjson-row-stream';
import {
  WorkspaceRepository,
  type DashboardDataScope,
} from '../core/data-access/workspace-repository.service';
import type {
  ModelResource,
  ViewChart,
  ViewChartDataScope,
  ViewFilterControls,
  WidgetConfiguration,
} from '../core/domain/workspace.types';
import type { SnapshotLease } from '../core/domain/shared-snapshot';
import {
  DashboardDataService,
  type DashboardDataHandle,
} from '../core/data-access/dashboard-data.service';
import { CHART_GALLERY_PAGE_SIZE, chartDataScope, viewCharts } from './view-charts';
import { describeFilterScope } from './filter-summary';
import { FilterScopeChipComponent } from './filter-scope-chip.component';
import { ChartCarouselComponent } from './chart-carousel.component';
import { ChartFocusComponent } from './chart-focus.component';
import { columnHighlightClass, isColumnHighlightColor } from '../explorer/column-highlights';

interface RenderedViewChart {
  configuration: ViewChart;
  data: ChartResponse | null;
  error: string;
}

@Component({
  selector: 'workspace-widget-view',
  standalone: true,
  imports: [
    GridPopupLayerDirective,
    FilterValuesFormComponent,
    NgTemplateOutlet,
    AgGridAngular,
    IntegratedChartComponent,
    MatIconModule,
    MatButtonModule,
    MatTooltipModule,
    FilterScopeChipComponent,
    ChartCarouselComponent,
    ChartFocusComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (
      headerActions && (loading() || error() || (effectiveMode === 'chart' && !charts().length))
    ) {
      <header class="scope-header">
        <div class="scope-heading">
          <strong>{{ tableTitle }}</strong
          ><span class="toolbar-spacer"></span><ng-container [ngTemplateOutlet]="headerActions" />
        </div>
      </header>
    }
    @if (error()) {
      <div class="widget-status" role="alert">
        <strong>Unable to display this view</strong><span>{{ error() }}</span>
        <button
          type="button"
          mat-icon-button
          aria-label="Retry"
          matTooltip="Retry"
          (click)="reload()"
        >
          <mat-icon>refresh</mat-icon>
        </button>
      </div>
    } @else if (loading()) {
      <div class="widget-status" role="status">
        <span class="loading-line"></span><strong>Loading data</strong>
      </div>
    } @else {
      @if (showDownloadAll && showDownloadActions && configuration.allowDownload !== false) {
        <div class="view-toolbar">
          <span></span>
          <button mat-button (click)="downloadAll()" [disabled]="applying() || downloading()">
            <mat-icon>download</mat-icon
            >{{ downloading() ? 'Preparing download…' : 'Download all' }}
          </button>
        </div>
      }
      @if (filterError()) {
        <div class="filter-error" role="alert">{{ filterError() }}</div>
      }
      <div
        class="view-content"
        [class.combined]="effectiveMode === 'both'"
        [class.table-first]="configuration.viewLayout?.tablePosition === 'top'"
        [class.hide-counts]="configuration.viewLayout?.showRecordCounts === false"
        [class.hide-filters]="configuration.viewLayout?.showFilterSummaries === false"
        [class.hide-title]="configuration.viewLayout?.showTitle === false"
        [class.dashboard-flat]="integratedHeaders"
        [style.--chart-count]="visibleCarouselCharts().length"
      >
        @if (effectiveMode !== 'grid') {
          <section class="chart-pane" aria-label="Saved charts">
            @if (charts().length) {
              @if (effectiveMode === 'both') {
                @if (charts().length === 1 || integratedHeaders) {
                  <div
                    class="carousel-charts"
                    [style.--visible-charts]="visibleCarouselCharts().length || 1"
                  >
                    @for (item of visibleCarouselCharts(); track item.configuration.id) {
                      <ng-container
                        [ngTemplateOutlet]="chartCard"
                        [ngTemplateOutletContext]="{ $implicit: item, carousel: false }"
                      />
                    }
                  </div>
                } @else {
                  <workspace-chart-carousel
                    [items]="carouselItems()"
                    [activeId]="activeChart()?.configuration.id ?? null"
                    [visibleCount]="bothChartCount()"
                    (visibleCountChange)="setBothChartCount($event)"
                    (activeIdChange)="activeChartId.set($event)"
                  >
                    <div
                      class="carousel-charts"
                      [style.--visible-charts]="visibleCarouselCharts().length || 1"
                    >
                      @for (item of visibleCarouselCharts(); track item.configuration.id) {
                        <ng-container
                          [ngTemplateOutlet]="chartCard"
                          [ngTemplateOutletContext]="{ $implicit: item, carousel: true }"
                        />
                      }
                    </div>
                  </workspace-chart-carousel>
                }
              } @else {
                @if (chartPageCount() > 1) {
                  <nav class="gallery-pagination" aria-label="Chart gallery pages">
                    <span>{{ charts().length }} charts</span>
                    <span aria-live="polite"
                      >Page {{ currentChartPage() + 1 }} of {{ chartPageCount() }}</span
                    >
                    <button
                      type="button"
                      mat-icon-button
                      aria-label="Previous chart page"
                      matTooltip="Previous chart page"
                      [disabled]="currentChartPage() === 0"
                      (click)="chartPage.set(currentChartPage() - 1)"
                    >
                      <mat-icon>chevron_left</mat-icon>
                    </button>
                    <button
                      type="button"
                      mat-icon-button
                      aria-label="Next chart page"
                      matTooltip="Next chart page"
                      [disabled]="currentChartPage() + 1 >= chartPageCount()"
                      (click)="chartPage.set(currentChartPage() + 1)"
                    >
                      <mat-icon>chevron_right</mat-icon>
                    </button>
                  </nav>
                }
                <div
                  class="published-charts"
                  [class.single-chart]="charts().length === 1"
                  aria-label="Chart gallery"
                >
                  @for (item of galleryCharts(); track item.configuration.id) {
                    <article
                      class="gallery-card"
                      [class.has-values]="showValueForm(item.configuration)"
                      [class.wide]="item.configuration.size === 'wide'"
                      [attr.data-chart-id]="item.configuration.id"
                    >
                      <ng-container
                        [ngTemplateOutlet]="chartCard"
                        [ngTemplateOutletContext]="{ $implicit: item, carousel: false }"
                      />
                    </article>
                  }
                </div>
              }
            } @else {
              <div class="widget-status">This revision has no saved chart.</div>
            }
          </section>
        }
        @if (effectiveMode !== 'chart') {
          <section class="grid-pane" aria-label="Data table">
            <header class="scope-header table-header">
              <div class="scope-heading">
                <mat-icon>table_chart</mat-icon><strong>{{ tableTitle }}</strong
                ><span class="record-count">{{ tableRecordCount().toLocaleString() }} records</span>
                @if (showFilters()) {
                  <workspace-filter-scope-chip
                    [scope]="tableScope()"
                    [preview]="{ rows: rows(), gridState: initialState }"
                    [columns]="specs"
                    componentLabel="Table"
                    component="table"
                    scopeId="table"
                    [access]="filterAccess()"
                    [adjusted]="!editable && tableChanged()"
                    [overridden]="editable && tableChanged()"
                    [editable]="editable"
                    [disabled]="applying()"
                    [dense]="true"
                    (scopeChange)="applyTableFilters($event)"
                    (reset)="resetTableFilters()"
                  />
                }
                <span class="toolbar-spacer"></span>
                @if (grouped()) {
                  <button mat-button type="button" (click)="ungroupAll()" [disabled]="applying()">
                    <mat-icon>view_list</mat-icon>Ungroup all
                  </button>
                } @else if (groupingChanged()) {
                  <button
                    mat-button
                    type="button"
                    (click)="restoreGrouping()"
                    [disabled]="applying()"
                  >
                    <mat-icon>account_tree</mat-icon>Restore grouping
                  </button>
                }
                @if (tableChanged()) {
                  <button
                    mat-icon-button
                    (click)="resetTableFilters()"
                    [disabled]="applying()"
                    aria-label="Reset table filters"
                    [matTooltip]="editable ? 'Reset to the view’s filter' : 'Reset table filters'"
                  >
                    <mat-icon>restart_alt</mat-icon>
                  </button>
                }
                @if (showDownloadActions && configuration.allowDownload !== false) {
                  <button
                    mat-icon-button
                    (click)="exportRecords()"
                    [disabled]="applying()"
                    aria-label="Download filtered records as CSV"
                    matTooltip="Download filtered records as CSV"
                  >
                    <mat-icon>download</mat-icon>
                  </button>
                }
                @if (usesHeaderActions('grid')) {
                  <ng-container [ngTemplateOutlet]="headerActions ?? null" />
                }
              </div>
            </header>
            @for (renderKey of gridRenderKeys(); track renderKey) {
              <ag-grid-angular
                prismPopupLayer
                [theme]="theme.gridTheme()"
                rowModelType="serverSide"
                [cacheBlockSize]="serverBlockSize"
                [maxBlocksInCache]="serverCacheBlocks"
                [maxConcurrentDatasourceRequests]="serverGridSettings.maxConcurrentRequests"
                [blockLoadDebounceMillis]="serverGridSettings.blockLoadDebounceMillis"
                [getChildCount]="getChildCount"
                [serverSidePivotResultFieldSeparator]="'|'"
                [columnDefs]="columns"
                [gridOptions]="options"
                [initialState]="initialState"
                [enableAdvancedFilter]="tableScope().mode === 'advanced'"
                [advancedFilterParent]="hiddenFilter"
                [suppressContextMenu]="true"
                [sideBar]="false"
                [animateRows]="false"
                [getRowId]="getRowId"
                [rowNumbers]="configuration.showRowNumbers ?? false"
                (gridReady)="gridReady($event)"
                (columnRowGroupChanged)="updateGrouping()"
              />
            }
          </section>
        }
      </div>
    }
    @if (focusedChart(); as item) {
      <workspace-chart-focus
        [title]="item.configuration.plan.title"
        (closed)="focusedChartId.set(null)"
      >
        <ng-container
          [ngTemplateOutlet]="chartCard"
          [ngTemplateOutletContext]="{ $implicit: item, carousel: false, focused: true }"
        />
      </workspace-chart-focus>
    }
    <ng-template #chartCard let-item let-carousel="carousel" let-focused="focused">
      <div class="chart-card-content" [attr.data-chart-id]="item.configuration.id">
        <header class="scope-header">
          <div class="scope-heading">
            @if (headerActions || !carousel || bothChartCount() > 1) {
              <mat-icon>bar_chart</mat-icon><strong>{{ item.configuration.plan.title }}</strong>
            }
            <span class="record-count"
              >{{ item.data ? item.data.matchedRowCount.toLocaleString() : '—' }} records</span
            >
            @if (showFilters(item.configuration)) {
              <workspace-filter-scope-chip
                [scope]="chartScope(item.configuration)"
                [preview]="{ rows: rows(), chart: item.configuration }"
                [columns]="specs"
                [componentLabel]="item.configuration.plan.title"
                component="chart"
                [scopeId]="item.configuration.id"
                [access]="filterAccess(item.configuration)"
                [adjusted]="!editable && chartChanged(item.configuration.id)"
                [overridden]="editable && chartChanged(item.configuration.id)"
                [editable]="editable"
                [disabled]="applying()"
                [dense]="true"
                (scopeChange)="applyChartFilters(item.configuration.id, $event)"
                (reset)="resetChartFilters(item.configuration.id)"
              />
            }
            <span class="toolbar-spacer"></span>
            @if (chartChanged(item.configuration.id)) {
              <button
                mat-icon-button
                (click)="resetChartFilters(item.configuration.id)"
                [disabled]="applying()"
                aria-label="Reset chart filters"
                [matTooltip]="editable ? 'Reset to the view’s filter' : 'Reset chart filters'"
              >
                <mat-icon>restart_alt</mat-icon>
              </button>
            }
            @if (!focused) {
              <button
                type="button"
                mat-icon-button
                aria-label="Expand chart"
                matTooltip="Expand chart"
                (click)="focusedChartId.set(item.configuration.id)"
              >
                <mat-icon>open_in_full</mat-icon>
              </button>
            }
            @if (editable && !carousel && !focused) {
              <button
                mat-icon-button
                (click)="toggleChartSize(item.configuration.id)"
                [attr.aria-label]="
                  item.configuration.size === 'wide' ? 'Reduce chart size' : 'Increase chart size'
                "
                [matTooltip]="
                  item.configuration.size === 'wide' ? 'Reduce chart size' : 'Increase chart size'
                "
              >
                <mat-icon>{{
                  item.configuration.size === 'wide' ? 'width_normal' : 'width_wide'
                }}</mat-icon>
              </button>
            }
            @if (
              !focused &&
              integratedHeaders &&
              effectiveMode === 'both' &&
              charts().length > 1 &&
              item.configuration.id === visibleCarouselCharts()[0]?.configuration.id
            ) {
              <label class="chart-choice"
                ><span class="sr-only">Choose chart</span
                ><select
                  aria-label="Choose chart"
                  [value]="activeChart()?.configuration.id"
                  (change)="activeChartId.set($any($event.target).value)"
                >
                  @for (chart of charts(); track chart.configuration.id) {
                    <option [value]="chart.configuration.id">
                      {{ chart.configuration.plan.title }}
                    </option>
                  }
                </select></label
              >
              <label class="chart-choice"
                ><span class="sr-only">Visible charts</span
                ><select
                  aria-label="Visible charts"
                  [value]="bothChartCount()"
                  (change)="changeVisibleCharts($any($event.target).value)"
                >
                  <option value="1">1 chart</option>
                  <option value="2">2 charts</option>
                  <option value="3">3 charts</option>
                </select></label
              >
            }
            @if (!focused && usesHeaderActions(item.configuration.id)) {
              <ng-container [ngTemplateOutlet]="headerActions ?? null" />
            }
          </div>
        </header>
        @if (showValueForm(item.configuration)) {
          <workspace-filter-values-form
            [columns]="specs"
            [scope]="chartScope(item.configuration)"
            [label]="item.configuration.plan.title"
            [disabled]="applying()"
            (scopeChange)="applyChartFilters(item.configuration.id, $event)"
          />
        }
        @if (
          configuration.viewLayout?.showChartDescriptions !== false &&
          item.configuration.description
        ) {
          <p class="chart-description">{{ item.configuration.description }}</p>
        }
        @if (item.error) {
          <div class="widget-status" role="alert">
            <strong>Unable to display this chart</strong><span>{{ item.error }}</span>
          </div>
        } @else {
          <app-integrated-chart
            [dataset]="item.data"
            [captureInitialPresentation]="false"
            [presentation]="item.configuration.presentation"
            [disabled]="!editable"
            [readonlyView]="!editable"
            [allowDownload]="configuration.allowDownload !== false"
            [showDownloadControl]="false"
            [compact]="true"
            (presentationChange)="savePresentation(item.configuration.id, $event)"
          />
        }
      </div>
    </ng-template>
    <div #hiddenFilter hidden></div>
  `,
  styles: `
    :host {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-width: 0;
      min-height: 200px;
      container-type: inline-size;
    }
    .view-content {
      flex: 1;
      display: grid;
      min-height: 0;
      min-width: 0;
      grid-template-columns: minmax(0, 1fr);
    }
    .view-content.combined {
      grid-template-rows: minmax(490px, 1fr) minmax(280px, 0.85fr);
      gap: 12px;
      overflow: auto;
    }
    .view-content.combined.table-first {
      grid-template-rows: minmax(280px, 0.85fr) minmax(490px, 1fr);
    }
    .view-content.dashboard-flat.combined,
    .view-content.dashboard-flat.combined.table-first {
      grid-template-rows: minmax(260px, 1fr) minmax(240px, 0.9fr);
      gap: 0;
    }
    .dashboard-flat .grid-pane,
    .dashboard-flat .gallery-card,
    .dashboard-flat .carousel-charts .chart-card-content {
      border: 0;
      border-radius: 0;
    }
    .dashboard-flat .grid-pane,
    .dashboard-flat .chart-pane {
      background: var(--mat-sys-surface);
    }
    .dashboard-flat.combined .chart-pane,
    .dashboard-flat .chart-card-content {
      min-height: 240px;
    }
    .dashboard-flat.combined > :last-child {
      border-top: 1px solid var(--ws-border);
    }
    .dashboard-flat.table-first > .chart-pane {
      border-top: 1px solid var(--ws-border);
    }
    .dashboard-flat.table-first > .grid-pane {
      border-top: 0;
    }
    .dashboard-flat .published-charts,
    .dashboard-flat .carousel-charts {
      padding: 0;
      gap: 0;
    }
    .dashboard-flat .carousel-charts > :not(:first-child) {
      border-left: 1px solid var(--ws-border);
    }
    .dashboard-flat .scope-header {
      padding: 5px 8px;
    }
    .chart-choice select {
      max-width: 180px;
      min-height: 30px;
      border: 0;
      border-radius: 4px;
      padding: 4px 6px;
      font: inherit;
      font-size: 11px;
      background: var(--mat-sys-surface-container-low);
      color: var(--mat-sys-on-surface);
    }
    .chart-choice select:focus-visible {
      outline: 2px solid var(--mat-sys-primary);
    }
    .combined.table-first > .grid-pane {
      grid-row: 1;
    }
    .combined.table-first > .chart-pane {
      grid-row: 2;
    }
    .hide-counts .record-count,
    .hide-filters workspace-filter-scope-chip,
    .hide-title .table-header strong {
      display: none;
    }
    .chart-description {
      font-size: 12px;
      line-height: 1.5;
      color: var(--ws-muted);
      margin: 6px 12px;
    }
    .chart-pane,
    .grid-pane {
      min-width: 0;
      min-height: 0;
      display: flex;
      flex-direction: column;
      overflow: auto;
    }
    .combined .chart-pane {
      min-height: 350px;
    }
    .grid-pane {
      border: 1px solid var(--ws-border);
      border-radius: 12px;
      background: var(--mat-sys-surface-container-lowest);
    }
    ag-grid-angular {
      display: block;
      width: 100%;
      flex: 1 1 240px;
      min-width: 0;
      min-height: 220px;
    }
    app-integrated-chart {
      display: block;
      width: 100%;
      flex: 1 1 260px;
      min-width: 0;
      min-height: 240px;
    }
    .published-charts {
      display: grid;
      min-width: 0;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 12px;
      padding: 2px;
      align-items: stretch;
    }
    .gallery-card {
      display: flex;
      min-width: 0;
      min-height: 370px;
      border: 1px solid var(--ws-border);
      border-radius: 12px;
      overflow: hidden;
      background: var(--mat-sys-surface-container-lowest);
    }
    .gallery-card.wide {
      grid-column: span 2;
    }
    .published-charts.single-chart {
      grid-template-columns: minmax(0, 1fr);
      flex: 1;
    }
    .single-chart .gallery-card {
      grid-column: auto;
      min-height: 320px;
    }
    .carousel-charts {
      display: grid;
      grid-template-columns: repeat(var(--visible-charts, 2), minmax(0, 1fr));
      gap: 12px;
      min-width: 0;
      padding: 8px;
      flex: 1;
    }
    .carousel-charts .chart-card-content {
      border: 1px solid var(--ws-border);
      border-radius: 10px;
      overflow: hidden;
    }
    .gallery-card.has-values {
      grid-column: span 2;
    }
    workspace-filter-values-form {
      flex: 0 0 auto;
    }
    .chart-card-content {
      display: flex;
      flex-direction: column;
      flex: 1;
      min-width: 0;
      min-height: 330px;
    }
    .scope-header {
      flex-shrink: 0;
      padding: 8px 10px;
      border-bottom: 1px solid color-mix(in srgb, var(--ws-border) 75%, transparent);
    }
    .scope-heading {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      min-width: 0;
      gap: 6px;
    }
    .scope-heading > mat-icon {
      color: var(--ws-muted);
      width: 16px;
      height: 16px;
      font-size: 16px;
    }
    .scope-heading strong {
      min-width: 0;
      font-size: 12px;
      flex: 0 1 auto;
      max-width: 40%;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .scope-heading workspace-filter-scope-chip {
      min-width: 0;
      flex: 0 1 auto;
    }
    .record-count {
      font-size: 11px;
      color: var(--ws-muted);
      white-space: nowrap;
      font-variant-numeric: tabular-nums;
    }
    .toolbar-spacer {
      flex: 1;
    }
    .filter-summary {
      display: flex;
      align-items: flex-start;
      gap: 5px;
      margin: 6px 0;
      font-size: 11px;
      line-height: 1.5;
      color: var(--ws-muted);
      overflow-wrap: anywhere;
    }
    .filter-summary mat-icon {
      width: 14px;
      height: 16px;
      font-size: 14px;
      flex-shrink: 0;
      margin-top: 1px;
    }
    .modified {
      color: var(--ws-accent);
      background: var(--ws-accent-soft);
      border-radius: 5px;
      font-size: 10px;
      padding: 3px 5px;
    }
    .scope-header button[mat-icon-button],
    .gallery-pagination button {
      --mdc-icon-button-state-layer-size: 30px;
      width: 30px;
      height: 30px;
      padding: 6px;
    }
    .scope-header button mat-icon,
    .gallery-pagination button mat-icon {
      width: 18px;
      height: 18px;
      font-size: 18px;
    }
    .view-toolbar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      min-height: 36px;
      padding: 0 4px 6px;
    }
    .view-toolbar button {
      font-size: 12px;
    }
    .gallery-pagination {
      display: flex;
      align-items: center;
      justify-content: flex-end;
      gap: 8px;
      padding: 8px 4px;
      font-size: 11px;
      color: var(--ws-muted);
    }
    .gallery-pagination > span:first-child {
      margin-right: auto;
    }
    .filter-error {
      padding: 6px 8px;
      font-size: 12px;
      color: var(--mat-sys-error);
    }
    .widget-status {
      flex: 1;
      min-height: 180px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 10px;
      padding: 16px;
      box-sizing: border-box;
      text-align: center;
      font:
        13px/1.6 Roboto,
        Arial,
        sans-serif;
      color: var(--ws-muted);
    }
    .widget-status strong {
      color: var(--ws-ink);
    }
    .loading-line {
      height: 3px;
      width: 120px;
      background: linear-gradient(
        90deg,
        var(--mat-sys-surface-container),
        var(--ws-accent),
        var(--mat-sys-surface-container)
      );
      background-size: 200% 100%;
      animation: loading 1.2s linear infinite;
      border-radius: 8px;
    }
    @keyframes loading {
      to {
        background-position: -200% 0;
      }
    }
    @container (max-width:1000px) {
      .published-charts {
        grid-template-columns: repeat(2, minmax(0, 1fr));
      }
    }
    @container (max-width:620px) {
      .carousel-charts {
        grid-template-columns: minmax(0, 1fr);
      }
      .view-content.combined {
        grid-template-rows: minmax(calc(var(--chart-count, 2) * 400px + 120px), 1fr) minmax(
            320px,
            0.85fr
          );
      }
      .view-content.combined.table-first {
        grid-template-rows: minmax(320px, 0.85fr) minmax(
            calc(var(--chart-count, 2) * 400px + 120px),
            1fr
          );
      }
      .view-content.dashboard-flat.combined {
        grid-template-rows: minmax(calc(var(--chart-count, 1) * 300px), 1fr) minmax(260px, 0.9fr);
      }
      .view-content.dashboard-flat.combined.table-first {
        grid-template-rows: minmax(260px, 0.9fr) minmax(calc(var(--chart-count, 1) * 300px), 1fr);
      }
      .dashboard-flat .carousel-charts > :not(:first-child) {
        border-left: 0;
        border-top: 1px solid var(--ws-border);
      }
      .published-charts {
        grid-template-columns: minmax(0, 1fr);
      }
      .gallery-card.wide,
      .gallery-card.has-values {
        grid-column: auto;
      }
      .scope-header {
        padding: 6px;
      }
    }
    @media (prefers-reduced-motion: reduce) {
      .loading-line {
        animation: none;
      }
    }
  `,
})
export class WidgetViewComponent implements OnChanges, OnDestroy {
  private readonly reactiveState = injectUiState('WidgetViewComponent');

  @ViewChildren(IntegratedChartComponent)
  private renderedCharts?: QueryList<IntegratedChartComponent>;
  @Input({ required: true }) model!: ModelResource;
  @Input({ required: true }) configuration!: WidgetConfiguration;
  @Input() displayMode?: 'grid' | 'chart' | 'both';
  @Input() dataScope?: DashboardDataScope;
  /** A dashboard-level advanced filter ANDed into the grid, its counts, exports and every chart. */
  @Input() scopeFilter?: GridModel;
  /** Dashboard grouping control: a column to group the server grid by, null for none, absent to keep saved grouping. */
  @Input() scopeGroupBy?: string | null;
  /** Reader-selected fixed time-bucket width, shared with independent dashboard charts. */
  @Input() scopeBucketSeconds?: number;
  @Input() editable = false;
  @Input() showDownloadAll = false;
  @Input() showDownloadActions = true;
  @Input() exportLabel = '';
  /** Parent controls share the first visible component header. */
  @Input() headerActions?: TemplateRef<unknown>;
  /** Embed a view directly in a dashboard, without collection chrome or inner card frames. */
  @Input() integratedHeaders = false;
  @Input() tableTitle = 'Data table';
  @Output() readonly configurationChange = new EventEmitter<WidgetConfiguration>();
  readonly workspace = inject(WorkspaceRepository);
  readonly theme = inject(AppThemeService);
  private readonly exports = inject(ViewExportService);
  /** Inside a dashboard composer the rows come from the shared per-dashboard cache. */
  private readonly datasets = inject(DashboardDataService, { optional: true });
  private handle?: DashboardDataHandle;
  readonly loading = this.reactiveState.signal(true);
  readonly error = this.reactiveState.signal('');
  readonly filterError = this.reactiveState.signal('');
  readonly applying = this.reactiveState.signal(false);
  readonly downloading = this.reactiveState.signal(false);
  readonly rows = this.reactiveState.signal<StreamRow[]>([]);
  readonly tableRecordCount = this.reactiveState.signal(0);
  readonly tableScope = this.reactiveState.signal<ViewChartDataScope>({
    mode: 'advanced',
    filterModel: null,
  });
  readonly charts = this.reactiveState.signal<RenderedViewChart[]>([]);
  readonly chartPage = this.reactiveState.signal(0);
  readonly chartPageCount = computed(() =>
    Math.max(1, Math.ceil(this.charts().length / CHART_GALLERY_PAGE_SIZE)),
  );
  readonly currentChartPage = computed(() => Math.min(this.chartPage(), this.chartPageCount() - 1));
  readonly galleryCharts = computed(() =>
    this.charts().slice(
      this.currentChartPage() * CHART_GALLERY_PAGE_SIZE,
      (this.currentChartPage() + 1) * CHART_GALLERY_PAGE_SIZE,
    ),
  );
  readonly activeChartId = this.reactiveState.signal<string | null>(null);
  readonly bothChartCount = this.reactiveState.signal<1 | 2 | 3>(2);
  readonly focusedChartId = this.reactiveState.signal<string | null>(null);
  readonly focusedChart = computed(
    () => this.charts().find((item) => item.configuration.id === this.focusedChartId()) ?? null,
  );
  readonly visibleCarouselCharts = computed(() => {
    const charts = this.charts();
    const start = Math.max(
      0,
      charts.findIndex((item) => item.configuration.id === this.activeChartId()),
    );
    return Array.from(
      { length: Math.min(this.bothChartCount(), charts.length) },
      (_, offset) => charts[(start + offset) % charts.length],
    );
  });
  readonly activeChart = computed<RenderedViewChart | null>(
    () =>
      this.charts().find((item) => item.configuration.id === this.activeChartId()) ??
      this.charts()[0] ??
      null,
  );
  readonly carouselItems = computed(() =>
    this.charts().map((item) => ({
      id: item.configuration.id,
      title: item.configuration.plan.title,
    })),
  );
  readonly tableChanged = this.reactiveState.signal(false);
  readonly grouped = this.reactiveState.signal(false);
  readonly groupingChanged = this.reactiveState.signal(false);
  private readonly gridRenderKey = this.reactiveState.signal(0);
  readonly gridRenderKeys = computed(() => [this.gridRenderKey()]);
  private readonly changedCharts = this.reactiveState.signal<ReadonlySet<string>>(new Set());
  columns: ColDef[] = [];
  specs: ColumnSpec[] = [];
  initialState: GridState = {};
  private localConfiguration!: WidgetConfiguration;
  private originalTableScope!: ViewChartDataScope;
  private originalChartScopes = new Map<string, ViewChartDataScope>();
  private gridApi?: GridApi;
  private lease?: SnapshotLease;
  private generation = 0;
  private cache?: BrowserDataCache;
  private snapshotLoaded = false;
  private snapshotRequest?: Promise<void>;
  serverGridSettings = normalizeServerGridSettings();
  get serverBlockSize() {
    return this.serverGridSettings.cacheBlockSize;
  }
  private readonly queryExecutor = inject(STUDIO_QUERY_EXECUTOR);
  private get hostQueryExecutor() {
    // Imported data lives in the session store; it has no corresponding host SQL dataset.
    return this.model.body.sourceKey.startsWith('local_') ? null : this.queryExecutor;
  }
  get serverCacheBlocks() {
    return this.serverGridSettings.maxBlocksInCache;
  }
  readonly getChildCount = (data: Record<string, unknown>) =>
    typeof data?.['__groupCount'] === 'number' ? data['__groupCount'] : 0;
  readonly getRowId = (params: GetRowIdParams): string => {
    const groups = params.api.getRowGroupColumns();
    const group = groups[params.level];
    return group
      ? JSON.stringify([
          'group',
          groups.map((c) => c.getColId()),
          params.parentKeys ?? [],
          params.data[group.getColId()],
        ])
      : JSON.stringify([
          'row',
          params.parentKeys ?? [],
          params.data[this.model.body.sqlDataset.rowIdColumn] ?? 'summary',
        ]);
  };
  readonly options: GridOptions = {
    defaultColDef: {
      editable: false,
      resizable: false,
      sortable: false,
      suppressMovable: true,
      suppressHeaderMenuButton: true,
      suppressHeaderFilterButton: true,
      filter: true,
      minWidth: 40,
      width: 160,
    },
    suppressDragLeaveHidesColumns: true,
    suppressMovableColumns: true,
    suppressColumnMoveAnimation: true,
    suppressCellFocus: false,
    // groupDefaultExpanded does not apply to the Server-Side Row Model. Published grouped views
    // open their first drill level so readers see the next grouping (or records) immediately;
    // each open group requests only its own children.
    isServerSideGroupOpenByDefault: (params) => params.rowNode.level === 0,
    // Leaf rows carry no group key; only group rows show the decoded label.
    autoGroupColumnDef: {
      valueFormatter: (params) => (params.node?.group ? groupKeyLabel(params.value) : ''),
    },
    pagination: false,
    tooltipShowDelay: 500,
  };
  constructor() {
    registerGridRuntime();
  }
  get effectiveMode() {
    const requested =
      this.displayMode ??
      this.configuration.displayMode ??
      (viewCharts(this.configuration).length ? 'chart' : 'grid');
    return requested === 'both' && !viewCharts(this.configuration).length ? 'grid' : requested;
  }
  usesHeaderActions(componentId: string): boolean {
    if (!this.headerActions) return false;
    if (
      this.effectiveMode === 'grid' ||
      (this.effectiveMode === 'both' && this.configuration.viewLayout?.tablePosition === 'top')
    )
      return componentId === 'grid';
    const first =
      this.effectiveMode === 'both' ? this.visibleCarouselCharts()[0] : this.galleryCharts()[0];
    return first ? componentId === first.configuration.id : componentId === 'grid';
  }
  changeVisibleCharts(value: string) {
    const count = Number(value);
    if (count === 1 || count === 2 || count === 3) this.setBothChartCount(count);
  }
  private controls(chart?: ViewChart): ViewFilterControls | undefined {
    return chart
      ? (chart.filterControls ?? this.localConfiguration?.filterControls)
      : (this.localConfiguration?.grid?.filterControls ?? this.localConfiguration?.filterControls);
  }
  showValueForm(chart?: ViewChart) {
    const controls = this.controls(chart);
    return (
      this.configuration.viewLayout?.showFilterSummaries !== false &&
      controls?.visible !== false &&
      controls?.parameterizable &&
      controls.editMode === 'values'
    );
  }
  showFilters(chart?: ViewChart) {
    return this.controls(chart)?.visible !== false;
  }
  filterAccess(chart?: ViewChart): 'none' | 'values' | 'expression' {
    if (this.editable) return 'expression';
    const controls = this.controls(chart);
    return controls?.visible !== false && controls?.parameterizable
      ? (controls.editMode ?? 'expression')
      : 'none';
  }
  describe(scope: ViewChartDataScope) {
    return describeFilterScope(scope, this.specs);
  }
  chartScope(chart: ViewChart) {
    return chartDataScope(chart, this.originalTableScope);
  }
  chartChanged(id: string) {
    return this.changedCharts().has(id);
  }
  private savedTableScope(configuration = this.configuration): ViewChartDataScope {
    return {
      mode: configuration.mode,
      filterModel: (configuration.mode === 'advanced'
        ? (configuration.gridState.filter?.advancedFilterModel ?? null)
        : (configuration.gridState.filter?.filterModel ?? {})) as GridModel,
    };
  }
  ngOnChanges(changes: SimpleChanges) {
    const scopeChanged =
      changes['dataScope'] &&
      JSON.stringify(changes['dataScope'].previousValue) !==
        JSON.stringify(changes['dataScope'].currentValue);
    const configurationChanged =
      changes['configuration'] &&
      JSON.stringify(this.configuration) !== JSON.stringify(this.localConfiguration);
    const filterChanged =
      changes['scopeFilter'] &&
      JSON.stringify(changes['scopeFilter'].previousValue ?? null) !==
        JSON.stringify(changes['scopeFilter'].currentValue ?? null);
    const querySettingsOnly =
      changes['configuration']?.previousValue &&
      JSON.stringify({ ...changes['configuration'].previousValue, serverGrid: undefined }) ===
        JSON.stringify({ ...this.configuration, serverGrid: undefined });
    if (
      configurationChanged &&
      querySettingsOnly &&
      !changes['model'] &&
      !scopeChanged &&
      this.cache
    ) {
      try {
        this.serverGridSettings = normalizeServerGridSettings(this.configuration.serverGrid);
      } catch (error) {
        this.error.set(error instanceof Error ? error.message : 'Invalid server grid settings.');
        return;
      }
      if (this.gridApi && !this.gridApi.isDestroyed()) this.initialState = this.gridApi.getState();
      this.localConfiguration = {
        ...this.localConfiguration,
        serverGrid: structuredClone(this.configuration.serverGrid),
      };
      this.gridApi = undefined;
      // cacheBlockSize is an AG Grid initial option. Remount with the current reader state.
      this.gridRenderKey.update((key) => key + 1);
      if (filterChanged) this.applyScopeFilter();
      return;
    }
    if (changes['model'] || configurationChanged || scopeChanged || !this.cache) void this.reload();
    else {
      if (changes['displayMode']) {
        this.prepareInitialFilter();
        if (this.effectiveMode !== 'grid' && !this.snapshotLoaded) {
          void this.reload();
          return;
        }
      }
      if (filterChanged) this.applyScopeFilter();
      else if (changes['scopeBucketSeconds'] && this.cache && !this.loading())
        this.charts.set(this.charts().map((item) => this.queryChart(item.configuration)));
      if (changes['scopeGroupBy']) this.applyScopeGroupBy();
    }
  }
  /** Regroup the server grid from the dashboard control; AG Grid refreshes its stores itself. */
  private applyScopeGroupBy() {
    const api = this.gridApi;
    if (!api || api.isDestroyed()) return;
    const saved = this.configuration.gridState.rowGroup?.groupColIds ?? [];
    const next =
      this.scopeGroupBy === undefined ? saved : this.scopeGroupBy ? [this.scopeGroupBy] : [];
    const current = api.getRowGroupColumns().map((column) => column.getColId());
    if (JSON.stringify(current) !== JSON.stringify(next)) api.setRowGroupColumns(next);
    this.updateGrouping();
  }
  private savedGrouping(): string[] {
    return this.scopeGroupBy === undefined
      ? (this.configuration.gridState.rowGroup?.groupColIds ?? [])
      : this.scopeGroupBy
        ? [this.scopeGroupBy]
        : [];
  }
  updateGrouping() {
    const api = this.gridApi;
    if (!api || api.isDestroyed()) return;
    const current = api.getRowGroupColumns().map((column) => column.getColId());
    this.grouped.set(current.length > 0);
    this.groupingChanged.set(JSON.stringify(current) !== JSON.stringify(this.savedGrouping()));
  }
  /** Reading a published table can change its grouping without changing the saved revision. */
  ungroupAll() {
    const api = this.gridApi;
    if (!api || api.isDestroyed()) return;
    api.setGridOption('pivotMode', false);
    api.setRowGroupColumns([]);
    this.updateGrouping();
  }
  restoreGrouping() {
    const api = this.gridApi;
    if (!api || api.isDestroyed()) return;
    api.setGridOption('pivotMode', this.configuration.gridState.pivot?.pivotMode ?? false);
    api.setRowGroupColumns(this.savedGrouping());
    this.updateGrouping();
  }
  /** The dashboard filter combined with a table or chart scope; the SQL compiler sees the same AND. */
  private scopedFilter(scope: ViewChartDataScope): GridModel {
    return this.scopeFilter == null
      ? scope.filterModel
      : combineFilterModels(scope.mode, this.scopeFilter, scope.filterModel);
  }
  private countRows(scope: ViewChartDataScope): number {
    if (!this.snapshotLoaded) return this.tableRecordCount();
    const predicate = fromModel(this.scopedFilter(scope), scope.mode, this.specs);
    return this.rows().filter((row) => evaluate(predicate, row)).length;
  }
  /** A changed dashboard filter recounts, purges the server grid cache and re-queries charts. */
  private applyScopeFilter() {
    if (!this.cache || this.loading()) return;
    try {
      this.filterError.set('');
      this.tableRecordCount.set(this.countRows(this.tableScope()));
      this.charts.set(this.charts().map((item) => this.queryChart(item.configuration)));
      if (this.gridApi && !this.gridApi.isDestroyed())
        this.gridApi.refreshServerSide({ purge: true });
    } catch (error) {
      this.filterError.set(
        error instanceof Error ? error.message : 'Unable to apply the dashboard filter.',
      );
    }
  }
  private queryChart(configuration: ViewChart): RenderedViewChart {
    if (!this.snapshotLoaded)
      return {
        configuration,
        data: null,
        error: 'The host must provide a complete authorized snapshot for charts and downloads.',
      };
    try {
      const scope = this.chartScope(configuration);
      const data = this.cache!.query(
        this.model.body.clientSourceId as ClientDataSourceId,
        'analytics/chart',
        {
          mode: scope.mode,
          filterModel: this.scopedFilter(scope),
          calculatedColumnIds: (this.localConfiguration.calculatedColumns ?? []).map(
            (column) => column.id,
          ),
          plan: this.effectiveChartPlan(configuration),
        },
      ) as ChartResponse;
      return { configuration, data, error: '' };
    } catch (error) {
      return {
        configuration,
        data: null,
        error: error instanceof Error ? error.message : 'Unable to prepare this chart.',
      };
    }
  }
  private effectiveChartPlan(chart: ViewChart): ChartPlan {
    const seconds = this.scopeBucketSeconds;
    const plan = chart.plan;
    if (!seconds || !['second', 'minute', 'hour'].includes(plan.timeBucket ?? '')) return plan;
    const timeBucket = seconds % 3600 === 0 ? 'hour' : seconds % 60 === 0 ? 'minute' : 'second';
    const bucketSize = seconds / (timeBucket === 'hour' ? 3600 : timeBucket === 'minute' ? 60 : 1);
    const label = `${bucketSize} ${timeBucket === 'hour' ? 'h' : timeBucket === 'minute' ? 'min' : 's'}`;
    return {
      ...plan,
      timeBucket,
      bucketSize,
      title: plan.title.replace(/\d+\s*(?:s|min|h)\b/, label),
    };
  }
  private prepareInitialFilter() {
    if (this.gridApi && !this.gridApi.isDestroyed()) this.initialState = this.gridApi.getState();
    const scope = this.tableScope();
    this.initialState = {
      ...this.initialState,
      filter:
        scope.mode === 'advanced'
          ? {
              advancedFilterModel: structuredClone(scope.filterModel) as unknown as NonNullable<
                GridState['filter']
              >['advancedFilterModel'],
            }
          : {
              filterModel: structuredClone(scope.filterModel) as NonNullable<
                GridState['filter']
              >['filterModel'],
            },
    };
  }
  gridReady(event: GridReadyEvent) {
    this.gridApi = event.api;
    const executor =
      this.hostQueryExecutor ??
      new MockStudioQueryExecutor(() => ({
        rows: this.rows() as readonly AnalyticsSourceRow[],
        columns: this.specs,
        rowIdColumn: this.model.body.sqlDataset.rowIdColumn,
      }));
    event.api.setGridOption(
      'serverSideDatasource',
      createStudioDatasource({
        context: () => ({
          sourceId: this.model.body.sourceKey,
          mode: this.tableScope().mode,
          tenant: 'local',
          dataset: this.model.body.sqlDataset,
          definitions: this.localConfiguration.calculatedColumns ?? [],
        }),
        scope: () => this.scopeFilter ?? null,
        executor,
        loaded: (_query, result) => this.tableRecordCount.set(result.matchedRowCount),
        error: (error) => this.filterError.set(error.message),
      }),
    );
    if (this.scopeGroupBy !== undefined) this.applyScopeGroupBy();
    this.updateGrouping();
  }
  private csv(): string {
    const scope = this.tableScope();
    const state =
      this.gridApi && !this.gridApi.isDestroyed() ? this.gridApi.getState() : this.initialState;
    // Exports honor the dashboard filter too; the grid state alone only holds the view's filter.
    const exportState =
      this.scopeFilter == null || scope.mode !== 'advanced'
        ? state
        : {
            ...state,
            filter: {
              advancedFilterModel: this.scopedFilter(scope) as unknown as NonNullable<
                GridState['filter']
              >['advancedFilterModel'],
            },
          };
    const records = filteredExportRows(
      this.rows(),
      this.specs,
      exportState,
      scope.mode,
      this.model.body.sqlDataset.rowIdColumn,
    );
    return viewCsv(records, this.specs, state);
  }
  async exportRecords() {
    if (this.configuration.allowDownload === false || this.applying() || this.loading()) return;
    try {
      await this.ensureSnapshot();
      downloadCsv(this.csv(), this.model.name);
    } catch (error) {
      this.filterError.set(
        error instanceof Error ? error.message : 'Unable to export these records.',
      );
    }
  }
  exportCsv(): string {
    if (!this.snapshotLoaded)
      throw new Error(
        'Records have not been loaded for export. Use the asynchronous export action.',
      );
    return this.csv();
  }
  exportChart(id: string) {
    if (this.configuration.allowDownload === false || this.applying()) return;
    const data = this.charts().find((item) => item.configuration.id === id)?.data;
    this.renderedCharts?.find((chart) => chart.dataset === data)?.download();
  }
  async exportSection(): Promise<import('./view-export.service').ViewExportSection | null> {
    if (this.configuration.allowDownload === false) return null;
    if (this.loading() || this.applying())
      throw new Error('Data is still loading. Try again when the page is ready.');
    if (this.error()) throw new Error(this.error());
    await this.ensureSnapshot();
    const failed = this.charts().find((item) => !item.data);
    if (failed)
      throw new Error(`Cannot download ${failed.configuration.plan.title}: ${failed.error}`);
    return {
      name: this.exportLabel || this.model.name,
      charts: this.charts().map((item) => ({
        data: item.data!,
        presentation: item.configuration.presentation,
      })),
      csv: this.csv(),
    };
  }
  async downloadAll() {
    if (
      this.configuration.allowDownload === false ||
      this.loading() ||
      this.applying() ||
      this.downloading()
    )
      return;
    this.downloading.set(true);
    this.filterError.set('');
    try {
      await this.ensureSnapshot();
      const failed = this.charts().find((item) => !item.data);
      if (failed)
        throw new Error(`Cannot download ${failed.configuration.plan.title}: ${failed.error}`);
      await this.exports.downloadAll(
        this.charts().map((item) => ({
          data: item.data!,
          presentation: item.configuration.presentation,
        })),
        this.csv(),
        this.model.name,
      );
    } catch (error) {
      this.filterError.set(
        error instanceof Error ? error.message : 'Unable to prepare the download.',
      );
    } finally {
      this.downloading.set(false);
    }
  }
  resetTableFilters() {
    if (this.filterAccess() !== 'none')
      void this.applyTableFilters(structuredClone(this.originalTableScope));
  }
  resetChartFilters(id: string) {
    const scope = this.originalChartScopes.get(id);
    if (scope) void this.applyChartFilters(id, structuredClone(scope));
  }
  async applyTableFilters(scope: ViewChartDataScope) {
    if (this.filterAccess() === 'none' || this.applying()) return;
    const generation = this.generation;
    this.applying.set(true);
    this.filterError.set('');
    try {
      await new Promise<void>((resolve) => setTimeout(resolve, 0));
      if (generation !== this.generation) return;
      fromModel(scope.filterModel, scope.mode, this.specs);
      this.tableScope.set(structuredClone(scope));
      this.tableRecordCount.set(this.countRows(scope));
      this.prepareInitialFilter();
      if (this.gridApi && !this.gridApi.isDestroyed()) {
        this.gridApi.setGridOption('enableAdvancedFilter', scope.mode === 'advanced');
        if (scope.mode === 'advanced')
          this.gridApi.setAdvancedFilterModel(
            this.initialState.filter?.advancedFilterModel ?? null,
          );
        else this.gridApi.setFilterModel(this.initialState.filter?.filterModel ?? {});
      }
      this.tableChanged.set(JSON.stringify(scope) !== JSON.stringify(this.originalTableScope));
      this.localConfiguration = {
        ...this.localConfiguration,
        mode: scope.mode,
        gridState: structuredClone(this.initialState),
        recordCount: this.tableRecordCount(),
      };
      this.emitConfiguration();
    } catch (error) {
      this.filterError.set(
        error instanceof Error ? error.message : 'Unable to apply these filters.',
      );
    } finally {
      if (generation === this.generation) this.applying.set(false);
    }
  }
  async applyChartFilters(id: string, scope: ViewChartDataScope) {
    const item = this.charts().find((chart) => chart.configuration.id === id);
    if (!item || this.filterAccess(item.configuration) === 'none' || this.applying()) return;
    this.filterError.set('');
    try {
      fromModel(scope.filterModel, scope.mode, this.specs);
      const updated = this.queryChart({ ...item.configuration, dataScope: structuredClone(scope) });
      if (updated.error) throw new Error(updated.error);
      this.charts.update((charts) =>
        charts.map((chart) => (chart.configuration.id === id ? updated : chart)),
      );
      this.changedCharts.update((previous) => {
        const next = new Set(previous);
        if (JSON.stringify(scope) === JSON.stringify(this.originalChartScopes.get(id)))
          next.delete(id);
        else next.add(id);
        return next;
      });
      this.captureCharts();
    } catch (error) {
      this.filterError.set(
        error instanceof Error ? error.message : 'Unable to apply these chart filters.',
      );
    }
  }
  toggleChartSize(id: string) {
    if (!this.editable) return;
    this.charts.update((charts) =>
      charts.map((item) =>
        item.configuration.id === id
          ? {
              ...item,
              configuration: {
                ...item.configuration,
                size: item.configuration.size === 'wide' ? 'standard' : 'wide',
              },
            }
          : item,
      ),
    );
    this.captureCharts();
  }
  savePresentation(id: string, presentation: ChartPresentation) {
    if (!this.editable) return;
    const previous = this.charts().find((item) => item.configuration.id === id)?.configuration
      .presentation;
    if (JSON.stringify(previous) === JSON.stringify(presentation)) return;
    this.charts.update((charts) =>
      charts.map((item) =>
        item.configuration.id === id
          ? { ...item, configuration: { ...item.configuration, presentation } }
          : item,
      ),
    );
    this.captureCharts();
  }
  private captureCharts() {
    const charts = this.charts().map((item) => item.configuration);
    this.localConfiguration = {
      ...this.localConfiguration,
      charts,
      chart:
        charts.find((chart) => chart.id === this.localConfiguration.chart?.id) ?? charts[0] ?? null,
    };
    this.emitConfiguration();
  }
  private emitConfiguration() {
    if (this.editable) this.configurationChange.emit(structuredClone(this.localConfiguration));
  }
  setBothChartCount(count: 1 | 2 | 3) {
    this.bothChartCount.set(count);
    this.localConfiguration = { ...this.localConfiguration, bothChartCount: count };
    this.emitConfiguration();
  }
  async reload() {
    const generation = ++this.generation;
    this.lease?.release();
    this.handle?.release();
    this.handle = undefined;
    this.lease = undefined;
    this.snapshotRequest = undefined;
    this.snapshotLoaded = false;
    this.cache = undefined;
    this.gridApi = undefined;
    this.gridRenderKey.update((key) => key + 1);
    this.error.set('');
    this.filterError.set('');
    this.loading.set(true);
    this.charts.set([]);
    this.chartPage.set(0);
    this.tableChanged.set(false);
    this.grouped.set(false);
    this.groupingChanged.set(false);
    this.changedCharts.set(new Set());
    this.applying.set(false);
    try {
      if (this.configuration.modelSchemaVersion !== this.model.body.schemaVersion)
        throw new Error(
          'The model schema changed. Republish this view after reviewing its columns.',
        );
      this.serverGridSettings = normalizeServerGridSettings(this.configuration.serverGrid);
      this.localConfiguration = structuredClone(this.configuration);
      this.bothChartCount.set(this.configuration.bothChartCount ?? 2);
      this.focusedChartId.set(null);
      this.originalTableScope = structuredClone(this.savedTableScope());
      this.tableScope.set(structuredClone(this.originalTableScope));
      // Pin legacy inherited filters before any local table edit, preserving each chart's cohort.
      const charts = viewCharts(this.localConfiguration).map((chart) => ({
        ...chart,
        dataScope: structuredClone(chartDataScope(chart, this.originalTableScope)),
      }));
      this.localConfiguration.charts = charts;
      this.localConfiguration.chart =
        charts.find((chart) => chart.id === this.localConfiguration.chart?.id) ?? charts[0] ?? null;
      this.originalChartScopes = new Map(
        charts.map((chart) => [chart.id, structuredClone(chart.dataScope)]),
      );
      this.activeChartId.set(this.localConfiguration.chart?.id ?? null);
      const source = this.model.body.clientSourceId as ClientDataSourceId;
      this.cache = new BrowserDataCache();
      this.cache.setRows(source, [], this.model.body.columns);
      this.cache.setCalculatedColumns(source, this.configuration.calculatedColumns ?? []);
      this.specs = [
        ...this.model.body.columns,
        ...(this.configuration.calculatedColumns ?? []).map((column) =>
          calculatedColumnSpec(column, this.model.body.columns),
        ),
      ];
      this.rows.set([]);
      this.tableRecordCount.set(this.configuration.recordCount ?? 0);
      if (!this.hostQueryExecutor || this.effectiveMode !== 'grid') {
        await this.ensureSnapshot();
        if (generation !== this.generation) return;
      }
      this.columns = this.specs.map((column) => ({
        field: column.id,
        colId: column.id,
        headerName: column.label,
        headerClass: isColumnHighlightColor(this.configuration.columnHighlights?.[column.id])
          ? [
              'explorer-column-highlight',
              columnHighlightClass(this.configuration.columnHighlights![column.id]),
            ]
          : [],
        cellClass: isColumnHighlightColor(this.configuration.columnHighlights?.[column.id])
          ? [
              'explorer-column-highlight',
              columnHighlightClass(this.configuration.columnHighlights![column.id]),
            ]
          : [],
        cellDataType:
          column.kind === 'number'
            ? 'number'
            : column.kind === 'date'
              ? 'dateString'
              : column.kind === 'datetime'
                ? 'dateTimeString'
                : 'text',
        filter:
          column.kind === 'number'
            ? 'agNumberColumnFilter'
            : column.kind === 'date' || column.kind === 'datetime'
              ? 'agDateColumnFilter'
              : 'agTextColumnFilter',
        filterParams: { includeTime: column.kind === 'datetime', inRangeInclusive: true },
      }));
      this.initialState = structuredClone(this.configuration.gridState);
      this.prepareInitialFilter();
      this.tableRecordCount.set(this.countRows(this.tableScope()));
      // Prepare every saved scope even in table mode so Download all always includes all charts.
      this.charts.set(charts.map((chart) => this.queryChart(chart)));
    } catch (error) {
      if (generation === this.generation)
        this.error.set(error instanceof Error ? error.message : 'Unable to load this view.');
    } finally {
      if (generation === this.generation) this.loading.set(false);
    }
  }
  private async ensureSnapshot(): Promise<void> {
    if (this.snapshotLoaded) return;
    if (this.snapshotRequest) return this.snapshotRequest;
    const generation = this.generation;
    const request = this.loadSnapshot(generation);
    this.snapshotRequest = request;
    try {
      await request;
    } finally {
      if (this.snapshotRequest === request) this.snapshotRequest = undefined;
    }
  }
  private async loadSnapshot(generation: number): Promise<void> {
    const source = this.model.body.clientSourceId as ClientDataSourceId;
    let cache: BrowserDataCache;
    try {
      if (this.datasets) {
        const handle = this.datasets.acquire(
          this.model,
          this.dataScope,
          this.configuration.calculatedColumns ?? [],
        );
        this.handle = handle;
        cache = (await handle.ready).cache;
      } else {
        const lease = this.workspace.lease(this.model, this.dataScope);
        this.lease = lease;
        const snapshot = await lease.result;
        cache = new BrowserDataCache();
        cache.setRows(source, snapshot.rows as StreamRow[], this.model.body.columns);
        cache.setCalculatedColumns(source, this.configuration.calculatedColumns ?? []);
      }
      if (generation !== this.generation)
        throw new Error('The view changed while its data was loading.');
      this.cache = cache;
      this.rows.set(cache.getGridRows(source) as StreamRow[]);
      this.snapshotLoaded = true;
      this.charts.set(
        (this.localConfiguration.charts ?? []).map((chart) => this.queryChart(chart)),
      );
    } catch (error) {
      if (generation === this.generation) {
        this.handle?.release();
        this.handle = undefined;
        this.lease?.release();
        this.lease = undefined;
      }
      throw error;
    }
  }
  ngOnDestroy() {
    this.generation++;
    this.lease?.release();
    this.handle?.release();
  }
}
