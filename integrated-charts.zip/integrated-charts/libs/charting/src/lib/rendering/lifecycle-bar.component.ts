import { injectUiState } from '../core/state/index';
import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  Input,
  Output,
  ViewChild,
} from '@angular/core';
import { RouterLink } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import type { LifecycleAction, LifecyclePlan } from './lifecycle';

export interface LifecycleBreadcrumb {
  label: string;
  link?: unknown[];
  queryParams?: Record<string, string>;
}

/**
 * The shared header of every editor: navigation, title and breadcrumb, one status chip,
 * secondary icon actions, one labelled primary action and an overflow menu.
 * Destructive actions only ever live in the overflow and must confirm in a dialog.
 */
@Component({
  selector: 'workspace-lifecycle-bar',
  standalone: true,
  imports: [
    RouterLink,
    MatButtonModule,
    MatDividerModule,
    MatIconModule,
    MatMenuModule,
    MatTooltipModule,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { class: 'lifecycle-bar', '[class.lifecycle-busy]': 'busy' },
  template: `
    <div class="lifecycle-navigation"><ng-content select="[lifecycle-navigation]" /></div>
    <div class="lifecycle-location">
      @if (breadcrumb.length) {
        <nav class="lifecycle-breadcrumb" aria-label="Breadcrumb">
          @for (crumb of breadcrumb; track $index; let last = $last) {
            @if (crumb.link && !last) {
              <a [routerLink]="crumb.link" [queryParams]="crumb.queryParams ?? null">{{
                crumb.label
              }}</a>
            } @else {
              <span [attr.aria-current]="last ? 'page' : null">{{ crumb.label }}</span>
            }
            @if (!last) {
              <span class="separator" aria-hidden="true">/</span>
            }
          }
        </nav>
      }
      @if (editing()) {
        <input
          #titleInput
          class="lifecycle-title-input"
          type="text"
          aria-label="View name"
          maxlength="120"
          [value]="draft()"
          (input)="draft.set(titleInput.value)"
          (keydown.enter)="commitTitle($event)"
          (keydown.escape)="cancelTitle($event)"
          (blur)="commitTitle()"
        />
      } @else if (editableTitle && !busy) {
        <h1>
          <button
            type="button"
            class="lifecycle-title-button"
            (click)="startEditing()"
            (keydown.f2)="startEditing()"
            [attr.aria-label]="'Rename ' + title"
            matTooltip="Click or press F2 to rename"
          >
            <span>{{ title }}</span
            ><mat-icon aria-hidden="true">edit</mat-icon>
          </button>
        </h1>
      } @else {
        <h1>{{ title }}</h1>
      }
    </div>
    <div class="lifecycle-commands" role="group" [attr.aria-label]="commandsLabel">
      <span
        [class]="'studio-status-chip lifecycle-chip tone-' + plan.status.tone + ' ' + legacyTone()"
        [matTooltip]="plan.status.hint"
        role="status"
        [attr.data-lifecycle-state]="plan.status.state"
        ><mat-icon aria-hidden="true">{{ plan.status.icon }}</mat-icon
        ><span class="status-label">{{ plan.status.label }}</span></span
      >
      <ng-content select="[lifecycle-extra]" />
      @for (item of plan.secondary; track item.id) {
        <button
          mat-icon-button
          type="button"
          [disabled]="busy || item.disabled"
          [attr.aria-label]="item.label"
          [matTooltip]="item.tooltip ?? item.label"
          [attr.data-action]="item.id"
          (click)="action.emit(item.id)"
        >
          <mat-icon aria-hidden="true">{{ item.icon ?? 'more_horiz' }}</mat-icon>
        </button>
      }
      @if (plan.primary; as primary) {
        <button
          mat-button
          type="button"
          class="lifecycle-primary"
          [class.studio-save-action]="primary.id === 'save'"
          [disabled]="busy || primary.disabled"
          [attr.aria-label]="primary.label"
          [matTooltip]="primary.tooltip ?? primary.label"
          [attr.data-action]="primary.id"
          (click)="action.emit(primary.id)"
        >
          <mat-icon aria-hidden="true">{{ primary.icon ?? 'check' }}</mat-icon>
          {{ primary.label }}
        </button>
      }
      @if (plan.overflow.length) {
        <button
          mat-icon-button
          type="button"
          [matMenuTriggerFor]="overflowMenu"
          [disabled]="busy"
          [attr.aria-label]="overflowLabel"
          [matTooltip]="overflowLabel"
        >
          <mat-icon aria-hidden="true">more_horiz</mat-icon>
        </button>
        <mat-menu #overflowMenu="matMenu" class="lifecycle-overflow">
          @for (item of plan.overflow; track item.id) {
            @if (item.divider) {
              <mat-divider />
            }
            <button
              mat-menu-item
              [disabled]="item.disabled"
              [class.destructive]="item.destructive"
              [attr.data-action]="item.id"
              (click)="action.emit(item.id)"
            >
              @if (item.icon) {
                <mat-icon aria-hidden="true">{{ item.icon }}</mat-icon>
              }
              <span>{{ item.label }}</span>
            </button>
          }
        </mat-menu>
      }
    </div>
  `,
  styles: `
    :host {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 10px 16px 10px 10px;
      border-bottom: 1px solid var(--ws-border);
      background: var(--mat-sys-surface);
      flex-shrink: 0;
      min-width: 0;
    }
    .lifecycle-navigation:empty {
      display: none;
    }
    .lifecycle-location {
      flex: 1;
      min-width: 0;
    }
    .lifecycle-breadcrumb {
      display: flex;
      align-items: center;
      gap: 6px;
      color: var(--ws-muted);
      font-size: 11px;
      margin-bottom: 2px;
      min-width: 0;
    }
    .lifecycle-breadcrumb a {
      color: inherit;
      text-decoration: none;
      white-space: nowrap;
    }
    .lifecycle-breadcrumb a:hover {
      text-decoration: underline;
      color: var(--ws-ink);
    }
    .lifecycle-breadcrumb span[aria-current] {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    h1 {
      margin: 0;
      font-size: 18px;
      font-weight: 600;
      letter-spacing: -0.3px;
      line-height: 1.35;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      min-width: 0;
    }
    .lifecycle-title-button {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      max-width: 100%;
      margin: 0 0 0 -6px;
      padding: 2px 6px;
      border: 0;
      border-radius: 6px;
      background: transparent;
      color: inherit;
      font: inherit;
      cursor: text;
      min-width: 0;
    }
    .lifecycle-title-button span {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .lifecycle-title-button mat-icon {
      width: 15px;
      height: 15px;
      font-size: 15px;
      color: var(--ws-muted);
      opacity: 0;
      transition: opacity 120ms;
      flex-shrink: 0;
    }
    .lifecycle-title-button:hover,
    .lifecycle-title-button:focus-visible {
      background: var(--mat-sys-surface-container);
    }
    .lifecycle-title-button:hover mat-icon,
    .lifecycle-title-button:focus-visible mat-icon {
      opacity: 1;
    }
    .lifecycle-title-input {
      width: min(100%, 520px);
      margin-left: -7px;
      padding: 3px 7px;
      border: 1px solid var(--ws-accent);
      border-radius: 6px;
      background: var(--mat-sys-surface-container-lowest);
      color: var(--ws-ink);
      font: inherit;
      font-size: 18px;
      font-weight: 600;
      letter-spacing: -0.3px;
      outline: none;
      box-shadow: 0 0 0 3px color-mix(in srgb, var(--ws-accent) 22%, transparent);
    }
    .lifecycle-commands {
      display: flex;
      align-items: center;
      gap: 4px;
      flex-wrap: wrap;
      justify-content: flex-end;
    }
    .lifecycle-chip {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      margin-right: 6px;
      padding: 5px 9px 5px 7px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 500;
      color: var(--ws-muted);
      background: var(--mat-sys-surface-container);
      white-space: nowrap;
    }
    .lifecycle-chip mat-icon {
      font-size: 15px;
      width: 15px;
      height: 15px;
    }
    .lifecycle-chip.tone-tertiary {
      color: var(--mat-sys-on-tertiary-container);
      background: var(--mat-sys-tertiary-container);
    }
    .lifecycle-chip.tone-accent {
      color: var(--mat-sys-on-primary-container);
      background: var(--mat-sys-primary-container);
    }
    .lifecycle-chip.tone-pending {
      color: var(--ws-muted);
      background: var(--mat-sys-surface-container-high);
    }
    .lifecycle-primary {
      margin-left: 2px;
      color: var(--mat-sys-primary);
      background: transparent;
      font-size: 12px;
      white-space: nowrap;
      border-radius: 4px;
    }
    .lifecycle-primary:disabled {
      color: var(--mat-sys-on-surface);
      background: transparent;
      opacity: 0.5;
    }
    .lifecycle-overflow .destructive {
      color: var(--mat-sys-error);
    }
    @media (max-width: 1100px) {
      :host {
        flex-wrap: wrap;
      }
      .lifecycle-commands {
        width: 100%;
      }
    }
    @media (max-width: 700px) {
      :host {
        gap: 6px;
        padding: 8px 10px;
      }
      .lifecycle-commands {
        justify-content: flex-start;
        gap: 2px;
      }
      .lifecycle-chip {
        margin-right: auto;
        font-size: 10px;
        max-width: 160px;
      }
      .status-label {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      h1,
      .lifecycle-title-input {
        font-size: 16px;
      }
    }
  `,
})
export class LifecycleBarComponent {
  private readonly reactiveState = injectUiState('LifecycleBarComponent');

  @Input({ required: true }) plan!: LifecyclePlan;
  @Input() title = '';
  @Input() breadcrumb: LifecycleBreadcrumb[] = [];
  @Input() editableTitle = false;
  @Input() busy = false;
  @Input() overflowLabel = 'View actions';
  @Input() commandsLabel = 'View lifecycle';
  @Output() readonly titleChange = new EventEmitter<string>();
  @Output() readonly action = new EventEmitter<string>();
  @ViewChild('titleInput') private titleInput?: ElementRef<HTMLInputElement>;
  readonly editing = this.reactiveState.signal(false);
  readonly draft = this.reactiveState.signal('');
  private cancelling = false;

  /** Keep the tone classes the existing stylesheet knows about. */
  legacyTone() {
    return { tertiary: 'unsaved', accent: 'published', pending: 'pending', neutral: 'neutral' }[
      this.plan.status.tone
    ];
  }
  startEditing() {
    if (!this.editableTitle || this.busy) return;
    this.draft.set(this.title);
    this.editing.set(true);
    queueMicrotask(() => {
      this.titleInput?.nativeElement.focus();
      this.titleInput?.nativeElement.select();
    });
  }
  commitTitle(event?: Event) {
    event?.preventDefault();
    if (!this.editing() || this.cancelling) return;
    const value = this.draft().trim();
    this.editing.set(false);
    if (value && value !== this.title) this.titleChange.emit(value);
  }
  cancelTitle(event?: Event) {
    event?.preventDefault();
    this.cancelling = true;
    this.editing.set(false);
    queueMicrotask(() => (this.cancelling = false));
  }
  /** Ctrl+S saves whenever a save action is on offer. */
  @HostListener('document:keydown', ['$event'])
  onKeydown(event: KeyboardEvent) {
    if (!(event.ctrlKey || event.metaKey) || event.key.toLowerCase() !== 's') return;
    const save = [this.plan.primary, ...this.plan.secondary, ...this.plan.overflow].find(
      (item) => item?.id === 'save' && !item.disabled,
    );
    if (!save || this.busy) return;
    event.preventDefault();
    this.action.emit('save');
  }
  /** Actions that the host can trigger programmatically (toolbar shortcuts, tests). */
  find(id: string): LifecycleAction | undefined {
    return [this.plan.primary, ...this.plan.secondary, ...this.plan.overflow].find(
      (item): item is LifecycleAction => !!item && item.id === id,
    );
  }
}
