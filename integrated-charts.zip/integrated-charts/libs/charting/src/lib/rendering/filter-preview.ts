import type { GridState } from 'ag-grid-community';
import type { ViewChart, ViewChartDataScope } from '../core/domain/workspace.types';
import type { ColumnSpec } from '../core/domain/schema';
import type { StreamRow } from '../explorer/ndjson-row-stream';
import type { ChartResponse } from '../core/domain/integrated-chart';
import { fromModel } from '../core/domain/grid-model';
import { evaluate } from '../core/domain/engine';
import { buildChartDataset } from '../core/domain/chart-data';

/** Read-only source snapshot. Previewing never changes an active grid or chart. */
export interface FilterPreviewSource {
  rows: readonly StreamRow[];
  chart?: Pick<ViewChart, 'plan' | 'presentation'>;
  gridState?: GridState;
}
export function previewFilter(
  source: FilterPreviewSource,
  columns: readonly ColumnSpec[],
  scope: ViewChartDataScope,
) {
  const predicate = fromModel(scope.filterModel, scope.mode, columns);
  const rows = source.rows.filter((row) => evaluate(predicate, row));
  const chart: ChartResponse | null = source.chart
    ? {
        ...buildChartDataset(
          source.chart.plan,
          columns,
          rows as Parameters<typeof buildChartDataset>[2],
          Math.max(source.rows.length, 1),
        ),
        source: 'mock',
        scope: 'filtered-source-rows',
      }
    : null;
  return { rows, chart, count: rows.length };
}
