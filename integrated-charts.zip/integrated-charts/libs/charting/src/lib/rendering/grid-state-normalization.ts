import type { GridState } from 'ag-grid-community';
import type { ViewChart, WidgetConfiguration } from '../core/domain/workspace.types';

/**
 * AG Grid injects synthetic columns (auto group, selection, row numbers) into saved
 * column lists. They are recreated on every load, so they never belong in a view.
 */
export const SYNTHETIC_COLUMN_PREFIX = 'ag-Grid-';

/** Grid state blocks that describe the session, not the view. */
export const VOLATILE_GRID_STATE_KEYS = [
  'focusedCell',
  'scroll',
  'pagination',
  'rowSelection',
  'cellSelection',
  'rangeSelection',
  'rowGroupExpansion',
  'partialColumnState',
  'version',
] as const;

type ColumnEntry = { colId?: unknown } & Record<string, unknown>;

function isSyntheticColumnId(value: unknown): boolean {
  return typeof value === 'string' && value.startsWith(SYNTHETIC_COLUMN_PREFIX);
}

function withoutSyntheticColumns(value: unknown): unknown {
  if (Array.isArray(value)) {
    return value
      .filter((entry) =>
        entry && typeof entry === 'object'
          ? !isSyntheticColumnId((entry as ColumnEntry).colId)
          : !isSyntheticColumnId(entry),
      )
      .map(withoutSyntheticColumns);
  }
  if (value && typeof value === 'object')
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>).map(([key, child]) => [
        key,
        withoutSyntheticColumns(child),
      ]),
    );
  return value;
}

function isEmptyValue(value: unknown): boolean {
  return (
    value === undefined ||
    value === null ||
    (Array.isArray(value) && value.length === 0) ||
    (typeof value === 'object' &&
      !Array.isArray(value) &&
      Object.keys(value as object).length === 0)
  );
}

/** A filter block that matches every record, in any of the shapes AG Grid produces. */
function isEmptyFilter(filter: GridState['filter'] | undefined): boolean {
  if (!filter || typeof filter !== 'object') return true;
  const entries = Object.entries(filter).filter(([, value]) => !isEmptyValue(value));
  return entries.length === 0;
}

/**
 * The state worth persisting: session-only blocks and synthetic columns removed.
 * Everything a reader needs to reproduce the table (visibility, order, pinning,
 * sizing, sort, grouping, pivot, aggregation, filter, user columns) is kept as is.
 */
export function persistedGridState(state: GridState | undefined): GridState {
  const copy: Record<string, unknown> = { ...(state ?? {}) };
  for (const key of VOLATILE_GRID_STATE_KEYS) delete copy[key];
  if (isEmptyFilter(copy['filter'] as GridState['filter'])) delete copy['filter'];
  const stripped = withoutSyntheticColumns(copy) as Record<string, unknown>;
  // Auto-group columns are synthetic presentation columns, but their sort is user intent.
  // Preserve that sort separately so grouped views reopen in the selected order.
  if (state?.sort?.sortModel?.length) stripped['sort'] = structuredClone(state.sort);
  // A block that only held synthetic columns says nothing about the view.
  for (const [key, value] of Object.entries(stripped)) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) continue;
    const entries = Object.values(value as Record<string, unknown>);
    if (entries.length && entries.every((entry) => Array.isArray(entry) && entry.length === 0))
      delete stripped[key];
  }
  return stripped as GridState;
}

/**
 * Chart presentations carry AG Charts render ids that change on every restore.
 * They are never part of the saved view.
 */
export function persistedPresentation<T extends { chartId?: string; model?: { chartId?: string } }>(
  presentation: T | null | undefined,
): T | null {
  if (!presentation) return null;
  const { chartId: _chartId, ...rest } = presentation;
  const result = { ...rest } as T;
  if (rest.model && typeof rest.model === 'object') {
    const { chartId: _modelChartId, ...model } = rest.model;
    (result as { model?: unknown }).model = model;
  }
  return result;
}

/**
 * Comparison form of a grid state: everything `persistedGridState` drops, plus the
 * values that the grid normalizes after load without any user intent:
 * flex-managed widths, hidden column order and empty blocks.
 */
export function comparableGridState(state: GridState | undefined): Record<string, unknown> {
  const persisted = persistedGridState(state) as Record<string, unknown>;
  const result: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(persisted)) {
    if (key === 'columnSizing') {
      const model = ((value as { columnSizingModel?: ColumnEntry[] })?.columnSizingModel ?? [])
        .filter((entry) => entry.flex === undefined || entry.flex === null)
        .map((entry) => ({ colId: entry.colId, width: entry.width }));
      if (model.length) result[key] = { columnSizingModel: model };
      continue;
    }
    if (key === 'columnVisibility') {
      const hidden = [...((value as { hiddenColIds?: string[] })?.hiddenColIds ?? [])].sort();
      if (hidden.length) result[key] = { hiddenColIds: hidden };
      continue;
    }
    if (key === 'partialColumnState') continue;
    if (!isEmptyValue(value)) result[key] = value;
  }
  return result;
}

/** Comparison form of a chart: render ids dropped, empty scopes treated alike. */
export function comparableChart(chart: ViewChart): ViewChart {
  const presentation = persistedPresentation(chart.presentation);
  const dataScope =
    chart.dataScope && !isEmptyValue(chart.dataScope.filterModel)
      ? chart.dataScope
      : chart.dataScope
        ? { mode: chart.dataScope.mode }
        : undefined;
  return { ...chart, presentation, ...(dataScope ? { dataScope } : {}) } as ViewChart;
}

/**
 * Comparison form of a complete configuration. Two configurations with the same key
 * describe the same view; everything that differs is a change worth saving.
 */
export function comparableConfiguration(
  configuration: Partial<WidgetConfiguration>,
): Record<string, unknown> {
  const { preview: _preview, recordCount: _recordCount, ...saved } = configuration;
  const result: Record<string, unknown> = { ...saved };
  result['gridState'] = comparableGridState(saved.gridState);
  if (saved.charts) result['charts'] = saved.charts.map(comparableChart);
  if (saved.chart) result['chart'] = comparableChart(saved.chart);
  for (const key of Object.keys(result)) if (isEmptyValue(result[key])) delete result[key];
  return result;
}
