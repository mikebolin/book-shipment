import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { DomSanitizer } from '@angular/platform-browser';
import type { PowerBiReport } from '../core/domain/powerbi-library';
@Component({
  standalone: true,
  imports: [MatDialogModule, MatButtonModule],
  template: `<h2 mat-dialog-title>{{ report.name }}</h2>
    <mat-dialog-content
      ><p>Power BI / Local demonstration / {{ report.author }}</p>
      <div class="report">
        <iframe
          [src]="url"
          [title]="report.name"
          sandbox="allow-scripts"
          referrerpolicy="no-referrer"
        ></iframe></div></mat-dialog-content
    ><mat-dialog-actions
      ><a mat-button [href]="report.source" target="_blank" rel="noopener noreferrer"
        >Sample source</a
      ><a mat-button [href]="report.embedUrl" target="_blank" rel="noopener noreferrer"
        >Open mock report</a
      ><button mat-button mat-dialog-close>Close</button></mat-dialog-actions
    >`,
  styles: `
    p {
      color: var(--ws-muted);
      font-size: 12px;
    }
    iframe {
      width: 100%;
      height: 100%;
      border: 0;
    }
    .report {
      height: 65dvh;
      min-height: 300px;
    }
    mat-dialog-actions {
      gap: 8px;
      justify-content: flex-end;
    }
  `,
})
export class PowerBiReportDialogComponent {
  readonly report = inject<PowerBiReport>(MAT_DIALOG_DATA);
  readonly url = inject(DomSanitizer).bypassSecurityTrustResourceUrl(this.report.embedUrl);
}
