import {
  AfterViewInit,
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  Output,
  TemplateRef,
  ViewChild,
  inject,
} from '@angular/core';
import { MatDialog, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

/** One expanded chart, with dialog focus management and the same live configuration. */
@Component({
  selector: 'workspace-chart-focus',
  standalone: true,
  imports: [MatDialogModule, MatButtonModule, MatIconModule],
  template: `<ng-template #content>
    <section class="chart-focus">
      <header>
        <h2>{{ title }}</h2>
        <button type="button" mat-icon-button aria-label="Close expanded chart" (click)="close()">
          <mat-icon>close_fullscreen</mat-icon>
        </button>
      </header>
      <div class="focus-content"><ng-content /></div>
    </section>
  </ng-template>`,
  styles: `
    :host {
      display: none;
    }
    .chart-focus {
      display: flex;
      flex-direction: column;
      height: 100%;
      min-height: 0;
      min-width: 0;
      background: var(--mat-sys-surface);
    }
    header {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 8px 16px;
      border-bottom: 1px solid var(--mat-sys-outline-variant);
    }
    h2 {
      margin: 0;
      flex: 1;
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      font-size: 16px;
    }
    .focus-content {
      display: flex;
      flex-direction: column;
      flex: 1;
      min-height: 0;
      min-width: 0;
      overflow: auto;
      padding: 12px;
    }
    .focus-content ::ng-deep > app-saved-chart {
      flex: 1;
      min-height: 0;
    }
    .focus-content ::ng-deep .saved-chart-card {
      height: 100%;
    }
    .focus-content ::ng-deep app-integrated-chart {
      min-height: 320px;
      flex: 1;
    }
  `,
})
export class ChartFocusComponent implements AfterViewInit, OnDestroy {
  @Input() title = 'Expanded chart';
  @Output() readonly closed = new EventEmitter<void>();
  @ViewChild('content', { static: true }) private content!: TemplateRef<unknown>;
  private readonly dialogs = inject(MatDialog);
  private ref?: MatDialogRef<unknown>;
  ngAfterViewInit() {
    this.ref = this.dialogs.open(this.content, {
      width: '96vw',
      maxWidth: '1500px',
      height: '92dvh',
      ariaLabel: 'Expanded chart',
      autoFocus: 'first-tabbable',
      restoreFocus: true,
    });
    this.ref.afterClosed().subscribe(() => this.closed.emit());
  }
  close() {
    this.ref?.close();
  }
  ngOnDestroy() {
    this.ref?.close();
  }
}
