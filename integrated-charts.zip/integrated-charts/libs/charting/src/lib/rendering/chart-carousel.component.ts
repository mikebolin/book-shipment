import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';

export interface ChartCarouselItem {
  id: string;
  title: string;
}

/** Parents mount only the visible charts, keeping large collections responsive. */
@Component({
  selector: 'workspace-chart-carousel',
  standalone: true,
  imports: [MatButtonModule, MatIconModule, MatTooltipModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section class="carousel" role="region" aria-roledescription="carousel" aria-label="Charts">
      <header class="carousel-header">
        <div class="carousel-heading">
          <mat-icon aria-hidden="true">bar_chart</mat-icon>
          <div>
            <span class="eyebrow">CHART COLLECTION</span><strong>{{ heading }}</strong>
          </div>
        </div>
        <nav aria-label="Chart navigation" (keydown)="onKeydown($event)">
          <button
            type="button"
            mat-icon-button
            aria-label="Previous chart"
            matTooltip="Previous chart"
            [disabled]="items.length < 2"
            (click)="move(-1)"
          >
            <mat-icon>chevron_left</mat-icon>
          </button>
          <span class="position" aria-live="polite" aria-atomic="true"
            >{{ position }} <span>/ {{ items.length }}</span></span
          >
          <button
            type="button"
            mat-icon-button
            aria-label="Next chart"
            matTooltip="Next chart"
            [disabled]="items.length < 2"
            (click)="move(1)"
          >
            <mat-icon>chevron_right</mat-icon>
          </button>
        </nav>
      </header>
      <div
        class="carousel-stage"
        role="group"
        aria-roledescription="slide"
        [attr.aria-label]="visibleItems.map(itemTitle).join(', ')"
      >
        <ng-content />
      </div>
      @if (items.length > 1) {
        <footer>
          <label class="jump-to-chart"
            ><span>Jump to chart</span
            ><select
              aria-label="Choose chart"
              [value]="activeItem?.id"
              (change)="activeIdChange.emit($any($event.target).value)"
            >
              @for (item of items; track item.id; let index = $index) {
                <option [value]="item.id">{{ index + 1 }}. {{ item.title }}</option>
              }
            </select></label
          >
          <label class="visible-count">
            <span>Visible charts</span>
            <select
              aria-label="Visible charts"
              [value]="visibleCount"
              (change)="changeVisibleCount($any($event.target).value)"
            >
              <option value="1">1 chart</option>
              <option value="2">2 charts</option>
              <option value="3">3 charts</option>
            </select>
          </label>
          @if (items.length <= 8) {
            <div class="chart-dots" aria-label="Select a chart">
              @for (item of items; track item.id; let index = $index) {
                <button
                  type="button"
                  [attr.aria-label]="'Show chart ' + (index + 1) + ': ' + item.title"
                  [attr.aria-current]="index === activeIndex ? 'true' : null"
                  [class.active]="isVisible(item.id)"
                  [matTooltip]="item.title"
                  (click)="activeIdChange.emit(item.id)"
                ></button>
              }
            </div>
          }
        </footer>
      }
    </section>
  `,
  styles: `
    :host {
      display: flex;
      min-width: 0;
      min-height: 0;
      width: 100%;
      height: 100%;
      container-type: inline-size;
    }
    .carousel {
      display: flex;
      flex-direction: column;
      flex: 1;
      min-width: 0;
      min-height: 0;
      border: 1px solid var(--ws-border, var(--mat-sys-outline-variant));
      border-radius: 14px;
      overflow: hidden;
      background: var(--mat-sys-surface-container-lowest);
    }
    .carousel-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 12px;
      flex-shrink: 0;
      padding: 10px 14px;
      border-bottom: 1px solid var(--ws-border, var(--mat-sys-outline-variant));
      background: var(--mat-sys-surface-container-low);
    }
    .carousel-heading {
      display: flex;
      align-items: center;
      gap: 10px;
      min-width: 0;
    }
    .carousel-heading > mat-icon {
      color: var(--ws-accent, var(--mat-sys-primary));
      flex-shrink: 0;
    }
    .carousel-heading > div {
      min-width: 0;
    }
    .eyebrow {
      display: block;
      font-size: 9px;
      letter-spacing: 0.1em;
      color: var(--ws-muted, var(--mat-sys-on-surface-variant));
      margin-bottom: 3px;
    }
    strong {
      display: block;
      font-size: 13px;
      font-weight: 600;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    nav {
      display: flex;
      align-items: center;
      gap: 2px;
      flex-shrink: 0;
    }
    nav button {
      width: 32px;
      height: 32px;
      padding: 4px;
      --mdc-icon-button-state-layer-size: 32px;
    }
    .position {
      font-size: 12px;
      font-variant-numeric: tabular-nums;
      white-space: nowrap;
      min-width: 42px;
      text-align: center;
    }
    .position span {
      color: var(--ws-muted, var(--mat-sys-on-surface-variant));
    }
    .carousel-stage {
      flex: 1;
      display: flex;
      flex-direction: column;
      min-width: 0;
      min-height: 0;
      overflow: auto;
    }
    footer {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      flex-shrink: 0;
      padding: 8px 14px;
      border-top: 1px solid var(--ws-border, var(--mat-sys-outline-variant));
    }
    .visible-count {
      flex: 0 0 auto;
    }
    .visible-count select {
      width: auto;
    }
    label {
      display: flex;
      flex: 1;
      align-items: center;
      min-width: 0;
      gap: 8px;
      font-size: 11px;
      color: var(--ws-muted, var(--mat-sys-on-surface-variant));
    }
    label > span {
      white-space: nowrap;
    }
    select {
      min-width: 0;
      max-width: 300px;
      width: 100%;
      border: 1px solid var(--ws-border, var(--mat-sys-outline-variant));
      border-radius: 6px;
      padding: 5px 8px;
      font: inherit;
      color: var(--mat-sys-on-surface);
      background: var(--mat-sys-surface-container);
    }
    .chart-dots {
      display: flex;
      gap: 2px;
      flex-shrink: 0;
    }
    .chart-dots button {
      width: 24px;
      height: 24px;
      padding: 8px;
      background: none;
      border: 0;
      cursor: pointer;
    }
    .chart-dots button::after {
      content: '';
      display: block;
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: var(--mat-sys-outline-variant);
    }
    .chart-dots button.active::after {
      background: var(--ws-accent, var(--mat-sys-primary));
    }
    button:focus-visible,
    select:focus-visible {
      outline: 2px solid var(--ws-accent, var(--mat-sys-primary));
      outline-offset: 2px;
    }
    @container (max-width: 520px) {
      .chart-dots {
        display: none;
      }
      label > span {
        display: none;
      }
      .carousel-header {
        padding: 8px;
        gap: 6px;
      }
      footer {
        padding-inline: 8px;
      }
      select {
        max-width: none;
      }
    }
    @container (max-width: 300px) {
      .carousel-header {
        align-items: stretch;
        flex-direction: column;
      }
      nav {
        justify-content: space-between;
      }
    }
    @media (pointer: coarse) {
      nav button {
        width: 44px;
        height: 44px;
        padding: 10px;
        --mdc-icon-button-state-layer-size: 44px;
      }
      select {
        min-height: 44px;
        font-size: 16px;
      }
    }
  `,
})
export class ChartCarouselComponent {
  @Input() items: readonly ChartCarouselItem[] = [];
  @Input() activeId: string | null = null;
  @Input() visibleCount: 1 | 2 | 3 = 2;
  @Output() readonly activeIdChange = new EventEmitter<string>();
  @Output() readonly visibleCountChange = new EventEmitter<1 | 2 | 3>();
  readonly itemTitle = (item: ChartCarouselItem) => item.title;
  get activeIndex() {
    return Math.max(
      0,
      this.items.findIndex((item) => item.id === this.activeId),
    );
  }
  get activeItem(): ChartCarouselItem | undefined {
    return this.items[this.activeIndex];
  }
  get visibleItems(): readonly ChartCarouselItem[] {
    return Array.from(
      { length: Math.min(this.visibleCount, this.items.length) },
      (_, index) => this.items[(this.activeIndex + index) % this.items.length],
    );
  }
  get position(): string {
    if (!this.items.length) return '0';
    const start = this.activeIndex + 1;
    const count = Math.min(this.visibleCount, this.items.length);
    if (count === 1) return String(start);
    const end = ((this.activeIndex + count - 1) % this.items.length) + 1;
    return end >= start
      ? `${start}–${end}`
      : Array.from(
          { length: count },
          (_, index) => ((this.activeIndex + index) % this.items.length) + 1,
        ).join(', ');
  }
  get heading(): string {
    return this.visibleItems.length > 1
      ? `Charts ${this.position}`
      : this.activeItem?.title || 'Charts';
  }
  isVisible(id: string): boolean {
    return this.visibleItems.some((item) => item.id === id);
  }
  changeVisibleCount(value: string) {
    const count = Number(value);
    if (count === 1 || count === 2 || count === 3) this.visibleCountChange.emit(count);
  }
  move(offset: number) {
    if (this.items.length > 1)
      this.activeIdChange.emit(
        this.items[(this.activeIndex + offset + this.items.length) % this.items.length].id,
      );
  }
  onKeydown(event: KeyboardEvent) {
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key) || this.items.length < 2)
      return;
    event.preventDefault();
    if (event.key === 'Home' || event.key === 'End')
      this.activeIdChange.emit(this.items[event.key === 'Home' ? 0 : this.items.length - 1].id);
    else this.move(event.key === 'ArrowLeft' ? -1 : 1);
  }
}
