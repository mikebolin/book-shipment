import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  Output,
} from '@angular/core';
import { FormControl, FormRecord, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import type { Subscription } from 'rxjs';
import { injectUiState } from '../core/state/index';
import type { ColumnSpec } from '../core/domain/schema';
import type { ViewChartDataScope } from '../core/domain/workspace.types';
import { fromModel } from '../core/domain/grid-model';
import { applyFilterParameters, filterParameters, type FilterParameter } from './filter-parameters';
import { describeFilterScope } from './filter-summary';

export interface FilterValuesDraft {
  scope: ViewChartDataScope | null;
  valid: boolean;
  message: string;
}

/** A private reactive form changes values only. The parent receives a new scope on explicit Apply. */
@Component({
  selector: 'workspace-filter-values-form',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatButtonModule, MatIconModule],
  host: { '[class.compact]': 'compact' },
  template: `
    @if (parameters.length) {
      <form
        [formGroup]="form"
        (ngSubmit)="apply()"
        class="values-form"
        [attr.aria-label]="label + ' filter values'"
      >
        @if (!compact) {
          <header>
            <div>
              <mat-icon aria-hidden="true">tune</mat-icon><strong>Refine {{ label }}</strong>
            </div>
            <span class="draft-badge" [class.pending]="changed()">{{
              changed() ? 'Not applied' : 'Current filter'
            }}</span>
          </header>
          <p class="form-intro">Adjust the values, review the sentence below, then apply.</p>
        }
        <div class="value-fields">
          @for (parameter of parameters; track parameter.id; let i = $index) {
            <div class="value-field">
              <label [for]="id + '-' + i"
                >{{ parameter.label }}<span>{{ parameter.operator }}</span></label
              >
              @if (parameter.kind === 'none') {
                <p class="fixed-value">No value needed</p>
              } @else if (parameter.kind === 'set') {
                <select
                  [id]="id + '-' + i"
                  [formControlName]="parameter.id"
                  multiple
                  [attr.aria-label]="parameter.label + ' filter values'"
                >
                  @for (option of parameter.options; track $index) {
                    <option [ngValue]="option">
                      {{ option === null ? '(blank)' : option === '' ? '(empty)' : option }}
                    </option>
                  }
                </select>
              } @else if (parameter.kind === 'boolean') {
                <select
                  [id]="id + '-' + i"
                  [formControlName]="parameter.id"
                  [attr.aria-label]="parameter.label + ' filter value'"
                >
                  <option [ngValue]="true">True</option>
                  <option [ngValue]="false">False</option>
                </select>
              } @else if (parameter.kind === 'text' && parameter.options.length) {
                <select
                  [id]="id + '-' + i"
                  [formControlName]="parameter.id"
                  [attr.aria-label]="parameter.label + ' filter value'"
                >
                  @for (option of textOptions(parameter); track $index) {
                    <option [ngValue]="option">
                      {{ option === null ? '(blank)' : option === '' ? '(empty)' : option }}
                    </option>
                  }
                </select>
              } @else {
                <input
                  [id]="id + '-' + i"
                  [formControlName]="parameter.id"
                  [type]="
                    parameter.kind === 'number'
                      ? 'number'
                      : parameter.kind === 'date'
                        ? 'date'
                        : parameter.kind === 'datetime'
                          ? 'datetime-local'
                          : 'text'
                  "
                  [attr.step]="
                    parameter.kind === 'number' ? 'any' : parameter.kind === 'datetime' ? '1' : null
                  "
                  [attr.aria-label]="
                    parameter.label +
                    (parameter.kind === 'datetime' ? ' filter value (UTC)' : ' filter value')
                  "
                  autocomplete="off"
                />
              }
            </div>
          }
        </div>
        @if (hasValues && showActions) {
          <footer>
            @if (!compact) {
              <span>{{
                changed() ? 'The visual still shows the applied values.' : scopeNote
              }}</span>
            }
            <button mat-button type="button" (click)="reset()" [disabled]="disabled || !changed()">
              Reset draft</button
            ><button mat-button type="submit" [disabled]="disabled || !changed() || !!error()">
              {{ applyLabel }}
            </button>
          </footer>
        }
        <div class="natural-summary" aria-live="polite" aria-atomic="true">
          <span>{{ changed() ? 'Will show records where' : 'Showing records where' }}</span>
          <p data-testid="filter-values-summary">{{ summary() }}</p>
        </div>
        @if (error()) {
          <p class="form-error" role="alert">{{ error() }}</p>
        }
      </form>
    } @else {
      <p class="empty-values">
        This visual has no saved filter values. Add conditions in Studio to make them adjustable
        here.
      </p>
    }
  `,
  styles: `
    :host {
      display: block;
      min-width: 0;
      container-type: inline-size;
    }
    .values-form {
      padding: 14px 16px;
      border: 1px solid var(--mat-sys-outline-variant);
      border-radius: 12px;
      background: var(--mat-sys-surface-container-low);
      color: var(--mat-sys-on-surface);
      margin: 10px 12px;
    }
    header,
    header > div {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    header {
      justify-content: space-between;
    }
    header strong {
      font-size: 13px;
    }
    header mat-icon {
      color: var(--mat-sys-primary);
      font-size: 18px;
      width: 18px;
      height: 18px;
    }
    .draft-badge {
      font-size: 10px;
      white-space: nowrap;
      border-radius: 12px;
      padding: 4px 8px;
      background: var(--mat-sys-surface-container-high);
      color: var(--mat-sys-on-surface-variant);
    }
    .draft-badge.pending {
      background: var(--mat-sys-tertiary-container);
      color: var(--mat-sys-on-tertiary-container);
    }
    .form-intro {
      font-size: 12px;
      line-height: 1.5;
      color: var(--mat-sys-on-surface-variant);
      margin: 8px 0 12px;
    }
    .value-fields {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(min(100%, 170px), 1fr));
      gap: 12px;
      max-height: 240px;
      overflow: auto;
      padding: 2px;
    }
    .value-field {
      min-width: 0;
    }
    .value-field label {
      display: flex;
      flex-direction: column;
      gap: 3px;
      font-size: 12px;
      font-weight: 500;
      margin-bottom: 6px;
    }
    .value-field label span {
      font-size: 11px;
      font-weight: 400;
      color: var(--mat-sys-on-surface-variant);
    }
    input,
    select {
      box-sizing: border-box;
      width: 100%;
      min-width: 0;
      min-height: 38px;
      border: 1px solid var(--mat-sys-outline);
      border-radius: 7px;
      padding: 7px 10px;
      background: var(--mat-sys-surface-container-lowest);
      color: var(--mat-sys-on-surface);
      font: inherit;
      font-size: 13px;
    }
    select[multiple] {
      height: 84px;
    }
    input:focus-visible,
    select:focus-visible {
      outline: 2px solid var(--mat-sys-primary);
      outline-offset: 1px;
    }
    input:disabled,
    select:disabled {
      opacity: 0.6;
    }
    .fixed-value {
      font-size: 12px;
      color: var(--mat-sys-on-surface-variant);
    }
    .natural-summary {
      margin-top: 12px;
      padding: 10px 12px;
      border-radius: 8px;
      background: var(--mat-sys-surface-container-lowest);
      overflow-wrap: anywhere;
    }
    .natural-summary > span {
      font-size: 10px;
      color: var(--mat-sys-on-surface-variant);
      font-weight: 600;
    }
    .natural-summary p {
      font-size: 13px;
      line-height: 1.55;
      margin: 4px 0 0;
    }
    .form-error {
      font-size: 12px;
      line-height: 1.5;
      color: var(--mat-sys-error);
      margin: 10px 0 0;
    }
    footer {
      display: flex;
      align-items: center;
      justify-content: flex-end;
      flex-wrap: wrap;
      gap: 6px;
      margin-top: 12px;
    }
    footer > span {
      font-size: 11px;
      line-height: 1.4;
      color: var(--mat-sys-on-surface-variant);
      margin-right: auto;
    }
    footer button {
      font-size: 12px;
    }
    .empty-values {
      font-size: 12px;
      color: var(--mat-sys-on-surface-variant);
      margin: 12px;
      line-height: 1.5;
    }
    @container (max-width:450px) {
      .values-form {
        margin: 8px;
        padding: 12px;
      }
      header {
        align-items: flex-start;
      }
      footer > span {
        flex-basis: 100%;
        margin-bottom: 4px;
      }
    }
    /* Compact: one inline row of inputs with the actions, then the sentence. No card chrome. */
    :host(.compact) .values-form {
      display: flex;
      flex-wrap: wrap;
      align-items: flex-end;
      gap: 10px 14px;
      margin: 0;
      padding: 8px 12px 10px;
      border: 0;
      border-radius: 0;
      background: transparent;
    }
    :host(.compact) .value-fields {
      display: flex;
      flex-wrap: wrap;
      gap: 10px 14px;
      flex: 1 1 auto;
      max-height: none;
      overflow: visible;
      padding: 0;
    }
    :host(.compact) .value-field {
      flex: 0 1 200px;
    }
    :host(.compact) .value-field label {
      flex-direction: row;
      align-items: baseline;
      gap: 6px;
      margin-bottom: 4px;
      font-size: 11px;
    }
    :host(.compact) input,
    :host(.compact) select {
      min-height: 34px;
      padding: 5px 8px;
      font-size: 12px;
    }
    :host(.compact) select[multiple] {
      height: 60px;
    }
    :host(.compact) footer {
      margin: 0;
      flex: 0 0 auto;
    }
    :host(.compact) .natural-summary {
      flex-basis: 100%;
      margin: 0;
      padding: 0;
      background: transparent;
      font-size: 12px;
      color: var(--mat-sys-on-surface-variant);
    }
    :host(.compact) .natural-summary > span {
      display: none;
    }
    :host(.compact) .natural-summary p {
      margin: 0;
      font-size: 12px;
    }
    :host(.compact) .form-error {
      flex-basis: 100%;
      margin: 0;
    }
  `,
})
export class FilterValuesFormComponent implements OnChanges, OnDestroy {
  private readonly state = injectUiState('FilterValuesForm');
  @Input({ required: true }) scope!: ViewChartDataScope;
  @Input() columns: readonly ColumnSpec[] = [];
  @Input() label = 'chart';
  @Input() applyLabel = 'Apply filters';
  /** What the applied values affect; a dashboard filter reaches every element on the page. */
  @Input() scopeNote = 'Values apply only to this visual.';
  /** Inline inputs and actions without card chrome, for filter-controls tiles. */
  @Input() compact = false;
  /** A containing dialog can own the single Apply action. */
  @Input() showActions = true;
  @Input() disabled = false;
  @Output() readonly scopeChange = new EventEmitter<ViewChartDataScope>();
  @Output() readonly draftChange = new EventEmitter<FilterValuesDraft>();
  readonly id = 'filter-values-' + crypto.randomUUID();
  readonly summary = this.state.signal('');
  readonly error = this.state.signal('');
  readonly changed = this.state.signal(false);
  readonly draft = this.state.signal<ViewChartDataScope | null>(null);
  form = new FormRecord<FormControl<unknown>>({});
  parameters: FilterParameter[] = [];
  private signature = '';
  private subscription?: Subscription;
  private destroyed = false;
  get hasValues() {
    return this.parameters.some((parameter) => !!parameter.key);
  }
  ngOnChanges() {
    const signature = JSON.stringify([this.scope, this.columns]);
    if (signature !== this.signature) {
      this.signature = signature;
      this.reset();
    }
    if (this.disabled) this.form.disable({ emitEvent: false });
    else this.form.enable({ emitEvent: false });
  }
  reset() {
    this.subscription?.unsubscribe();
    this.error.set('');
    try {
      this.parameters = filterParameters(this.scope.filterModel, this.scope.mode, this.columns);
      this.form = new FormRecord(
        Object.fromEntries(
          this.parameters
            .filter((p) => p.key)
            .map((p) => [
              p.id,
              new FormControl<unknown>(
                p.kind === 'date'
                  ? String(p.value ?? '').slice(0, 10)
                  : p.kind === 'datetime'
                    ? // datetime-local shows the stored UTC wall time; the zone is implied.
                      String(p.value ?? '')
                        .replace(' ', 'T')
                        .slice(0, 19)
                    : structuredClone(p.value),
              ),
            ]),
        ),
      );
      this.updateDraft();
      this.subscription = this.form.valueChanges.subscribe(() => this.updateDraft());
      if (this.disabled) this.form.disable({ emitEvent: false });
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : 'Unable to read the saved filters.');
    }
  }
  textOptions(parameter: FilterParameter) {
    return [...new Set([...parameter.options, String(parameter.value ?? '')])];
  }
  private updateDraft() {
    try {
      const scope = {
        mode: this.scope.mode,
        filterModel: applyFilterParameters(
          this.scope.filterModel,
          this.parameters,
          this.form.getRawValue(),
        ) as ViewChartDataScope['filterModel'],
      };
      const predicate = fromModel(scope.filterModel, scope.mode, this.columns);
      this.draft.set(scope);
      this.summary.set(describeFilterScope(scope, this.columns));
      this.error.set('');
      this.changed.set(
        JSON.stringify(predicate) !==
          JSON.stringify(fromModel(this.scope.filterModel, this.scope.mode, this.columns)),
      );
    } catch (e) {
      this.changed.set(true);
      this.draft.set(null);
      this.summary.set('Complete the filter values.');
      this.error.set(e instanceof Error ? e.message : 'Check the filter values.');
    }
    const change = {
      scope: this.draft() ? structuredClone(this.draft()) : null,
      valid: !this.error(),
      message: this.error(),
    };
    queueMicrotask(() => {
      if (!this.destroyed) this.draftChange.emit(change);
    });
  }
  apply() {
    const draft = this.draft();
    if (!this.disabled && this.changed() && !this.error() && draft)
      this.scopeChange.emit(structuredClone(draft));
  }
  ngOnDestroy() {
    this.destroyed = true;
    this.subscription?.unsubscribe();
  }
}
