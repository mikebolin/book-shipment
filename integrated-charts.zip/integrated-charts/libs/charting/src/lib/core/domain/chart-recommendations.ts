import { z } from 'zod';
import { CHART_TYPES, CHART_AGGREGATIONS, CHART_TIME_BUCKETS } from './integrated-chart.js';

/** Closed semantic vocabulary: never transmit column names, values, titles, or row statistics. */
export const RECOMMENDATION_MEANINGS = [
  'balance',
  'revenue',
  'cost',
  'quantity',
  'volume',
  'price',
  'rate',
  'percentage',
  'score',
  'duration',
  'count',
  'other',
] as const;
export const RECOMMENDATION_CATEGORIES = [
  'status',
  'type',
  'geography',
  'organization',
  'product',
  'time',
  'other',
  'none',
] as const;
export const RECOMMENDATION_QUALITIES = [
  'varying',
  'complete',
  'comparable',
  'nonnegative',
  'additive',
  'lowCardinality',
] as const;
export const recommendationCandidateSchema = z
  .object({
    id: z.string().regex(/^r_[a-f0-9]{64}$/),
    chartType: z.enum(CHART_TYPES),
    intent: z.enum(['comparison', 'trend', 'distribution', 'relationship', 'composition']),
    category: z.enum(RECOMMENDATION_CATEGORIES),
    measures: z.array(z.enum(RECOMMENDATION_MEANINGS)).max(3),
    aggregation: z.enum(CHART_AGGREGATIONS).nullable(),
    timeBucket: z.enum(CHART_TIME_BUCKETS).nullable(),
    quality: z.array(z.enum(RECOMMENDATION_QUALITIES)).max(RECOMMENDATION_QUALITIES.length),
  })
  .strict();
/** Validate again immediately before transport; TypeScript types cannot enforce privacy. */
export const recommendationCandidatesSchema = z
  .array(recommendationCandidateSchema)
  .min(1)
  .max(64)
  .refine(
    (candidates) => new Set(candidates.map((candidate) => candidate.id)).size === candidates.length,
    {
      message: 'Candidate IDs must be unique.',
    },
  );
export const chartRecommendationsRequestSchema = z
  .object({
    datasetKey: z.string().regex(/^[a-f0-9]{64}$/),
    useLiveAi: z.boolean(),
    candidates: recommendationCandidatesSchema,
  })
  .strict();
export type RecommendationCandidate = z.infer<typeof recommendationCandidateSchema>;
export type ChartRecommendationsRequest = z.infer<typeof chartRecommendationsRequestSchema>;
export interface ChartRecommendationsResponse {
  candidateIds: string[];
  source: 'llm' | 'heuristic';
  status: 'ready' | 'pending' | 'failed' | 'unavailable' | 'disabled';
  cached: boolean;
}
export const CHART_RECOMMENDATION_VERSION = 'chart-recommendations-v1';
