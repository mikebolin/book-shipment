export type Mode = 'advanced' | 'columns';
export type Operation = 'replace' | 'refine';
export type Operator =
  | 'equals'
  | 'notEqual'
  | 'contains'
  | 'notContains'
  | 'startsWith'
  | 'endsWith'
  | 'greaterThan'
  | 'greaterThanOrEqual'
  | 'lessThan'
  | 'lessThanOrEqual'
  | 'blank'
  | 'notBlank';
export type Node =
  | { kind: 'rule'; field: string; op: Operator; value: string | number | null }
  | { kind: 'set'; field: string; op: 'isAnyOf' | 'isNoneOf'; values: (string | null)[] }
  | { kind: 'group'; join: 'AND' | 'OR'; children: Node[] };
export type GridModel = Record<string, unknown> | null;
export interface Principal {
  /** Optional per-tab context partition, never an authorization credential. */
  sessionId?: string;
  subject: string;
  tenant: string;
  scopes: string[];
  timeZone: string;
}
export interface Context {
  now: string;
  timeZone: string;
}
export interface Question {
  code: string;
  message: string;
  choices: { id: string; label: string }[];
}
export interface InterpretRequest {
  useLiveAi?: boolean;
  text: string;
  mode: Mode;
  operation: Operation;
  currentModel: GridModel;
  toolkitSchema: Record<string, unknown>;
}
export type InterpretResult =
  | { status: 'needs_input'; message: string }
  | {
      status: 'clarification';
      id: string;
      original: string;
      resolved: string;
      question: Question;
      expiresAt: string;
    }
  | {
      status: 'proposal';
      id: string;
      original: string;
      resolved: string;
      summary: string;
      model: GridModel;
      mode: Mode;
      operation: Operation;
      expiresAt: string;
      notes: string[];
    }
  | { status: 'rejected'; code: string; message: string; hints: string[] };
export interface Account {
  [key: string]: string | number | null;
  id: string;
  accountName: string;
  accountDate: string;
  createdDate: string;
  updatedAt: string;
  status: string | null;
  delivered: string | null;
  balance: number | null;
  tenant: string;
}
