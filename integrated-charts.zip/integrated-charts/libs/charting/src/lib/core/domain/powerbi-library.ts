export interface PowerBiReport {
  id: string;
  name: string;
  author: string;
  description: string;
  category: string;
  source: string;
  embedUrl: string;
}
export function isPowerBiDemoUrl(value: string): boolean {
  return /^assets\/mock-report\.html(?:\?report=[a-z-]+)?$/.test(value);
}
