import { z } from 'zod';
import type { ColumnSpec } from './schema.js';
import type { CalculatedColumnDefinition } from './calculated-columns.js';

/** Schema-only planning transport. Source rows and SQL are deliberately not accepted. */
export const uploadedDatasetSchema = z
  .object({
    id: z.string().regex(/^local_[A-Za-z0-9_-]{1,100}$/),
    version: z.string().min(1).max(150),
    columns: z
      .array(
        z
          .object({
            id: z
              .string()
              .regex(/^[A-Za-z][A-Za-z0-9_]{0,79}$/)
              .refine(
                (id) =>
                  !/^calc_/i.test(id) &&
                  !['constructor', 'prototype', '__proto__', 'tenant'].includes(id),
              ),
            label: z.string().min(1).max(200),
            kind: z.enum(['text', 'number', 'date', 'datetime']),
            aliases: z.array(z.string().min(1).max(200)).max(8),
            nullable: z.boolean(),
            description: z.string().min(1).max(4000).optional(),
            values: z.array(z.string().max(200)).max(20).optional(),
            scale: z.number().int().min(0).max(12).optional(),
            chartRole: z.enum(['identifier', 'dimension', 'measure', 'temporal']).optional(),
            unit: z.string().max(40).nullable().optional(),
          })
          .strict(),
      )
      .min(1)
      .max(501)
      .refine(
        (columns) => new Set(columns.map((column) => column.id)).size === columns.length,
        'Column IDs must be distinct.',
      ),
    calculatedColumns: z
      .array(
        z
          .object({
            id: z.string().regex(/^calc_[A-Za-z0-9_-]{1,70}$/),
            label: z.string().min(1).max(80),
            expression: z.unknown(),
          })
          .strict(),
      )
      .max(8)
      .default([]),
  })
  .strict();

export type UploadedDatasetSchema = z.infer<typeof uploadedDatasetSchema>;

export const UPLOADED_PLANNING_PATHS = new Set([
  'nl/interpret',
  'nl/clarify',
  'nl/confirm',
  'nl/grid/interpret',
  'nl/grid/confirm',
  'nl/grid/refine-chart',
  'nl/grid/calculated-column/confirm',
  'grid/chart-proposal',
  'calculated-columns',
]);

export function uploadedPlanningMetadata(
  metadata: { id: string; version: string; columns: readonly ColumnSpec[] },
  calculatedColumns: readonly CalculatedColumnDefinition[] = [],
): UploadedDatasetSchema {
  return uploadedDatasetSchema.parse({
    id: metadata.id,
    version: metadata.version,
    columns: metadata.columns.map((column) => ({
      id: column.id,
      label: column.label.slice(0, 200),
      kind: column.kind,
      aliases: column.aliases.slice(0, 8).map((alias) => alias.slice(0, 200)),
      nullable: column.nullable,
      description: column.description.slice(0, 4000),
      ...(column.values &&
      column.values.length <= 20 &&
      column.values.every((value) => value.length <= 200)
        ? { values: column.values }
        : {}),
      ...(column.scale === undefined ? {} : { scale: column.scale }),
      ...(column.chartRole === undefined ? {} : { chartRole: column.chartRole }),
      ...(column.unit === undefined ? {} : { unit: column.unit }),
    })),
    calculatedColumns,
  });
}
