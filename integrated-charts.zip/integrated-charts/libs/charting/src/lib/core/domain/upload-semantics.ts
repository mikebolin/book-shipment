import type { ColumnSpec } from './schema.js';
import { z } from 'zod';

/** A local upload may describe fields, but cannot change their inferred types or policy. */
const columnDescription = z
  .object({
    field: z.string().min(1).max(200),
    label: z.string().min(1).max(200).optional(),
    description: z.string().min(1).max(4000).optional(),
    synonyms: z.array(z.string().min(1).max(200)).max(8).optional(),
    role: z.enum(['identifier', 'dimension', 'measure', 'time', 'temporal']).optional(),
    unit: z.string().max(40).nullable().optional(),
    dataType: z
      .enum(['string', 'text', 'number', 'integer', 'date', 'datetime', 'boolean'])
      .optional(),
  })
  .passthrough();
const semanticMetadata = z
  .object({
    columns: z.array(columnDescription).min(1).max(500),
  })
  .passthrough();

/** Unknown metadata is ignored, never interpreted as expressions, policies or executable code. */
export function applyUploadSemantics(
  columns: readonly ColumnSpec[],
  fields: readonly { originalName: string; columnId: string; inferredType: string }[],
  input: unknown,
): ColumnSpec[] {
  const metadata = semanticMetadata.parse(input);
  const originals = new Map(fields.map((f) => [f.originalName, f]));
  const seen = new Set<string>();
  const descriptions = new Map<string, z.infer<typeof columnDescription>>();
  for (const d of metadata.columns) {
    const field = originals.get(d.field);
    if (!field || seen.has(d.field))
      throw new Error('Metadata must reference each existing field at most once.');
    seen.add(d.field);
    const expected =
      d.dataType === 'string' ? 'text' : d.dataType === 'integer' ? 'number' : d.dataType;
    if (expected && expected !== field.inferredType)
      throw new Error(`Metadata type for ${d.field} conflicts with its imported values.`);
    descriptions.set(field.columnId, d);
  }
  return columns.map((column) => {
    const d = descriptions.get(column.id);
    if (!d) return { ...column };
    const role = d.role === 'time' ? 'temporal' : d.role;
    if (
      (column.chartRole === 'identifier' && role && !['identifier', 'dimension'].includes(role)) ||
      (role === 'measure' && column.kind !== 'number') ||
      (role === 'temporal' && !['date', 'datetime'].includes(column.kind))
    )
      throw new Error(`Metadata role for ${d.field} conflicts with its imported field type.`);
    return {
      ...column,
      ...(d.label ? { label: d.label } : {}),
      ...(d.description ? { description: d.description } : {}),
      aliases: [
        ...new Set([column.id, d.field, d.label ?? column.label, ...(d.synonyms ?? [])]),
      ].slice(0, 8),
      ...(role ? { chartRole: role } : {}),
      ...(d.unit !== undefined ? { unit: d.unit } : {}),
    };
  });
}
