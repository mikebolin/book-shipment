/** Recognize a request for the guided UI, never a partially understood chart specification. */
export function requestsChartHelp(text: string): boolean {
  const input = text.normalize('NFKC').trim().toLowerCase();
  if (input.length > 240 || !/^[a-z\s,.!?]+$/.test(input)) return false;
  if (!/\b(?:chart|charts|graph|plot|visuali[sz]e|visuali[sz]ation)\b/.test(input)) return false;
  if (
    !/\b(?:help|create|creating|build|building|make|making|choose|pick|visuali[sz]e)\b/.test(input)
  )
    return false;
  const allowed = new Set(
    'now we i need want would like to could you can help me us please create creating make making build building choose pick a an the chart charts graph plot visualize visualise visualization visualisation for of with from this that these those it results result filtered current existing same data records rows accounts holdings transactions view based on'.split(
      ' ',
    ),
  );
  return input
    .split(/[\s,.!?]+/)
    .filter(Boolean)
    .every((word) => allowed.has(word));
}
