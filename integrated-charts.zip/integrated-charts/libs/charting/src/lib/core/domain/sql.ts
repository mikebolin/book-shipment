import { COLUMNS, LIMITS, type ColumnSpec } from './schema.js';
import {
  UNCONFIGURED_SQL_DATASET,
  quoteSqlIdentifier,
  validateSqlDataset,
  type SqlDataset,
} from './sql-dataset.js';
import type { Node } from './contracts.js';
import { Fault, validateNode } from './engine.js';

export interface Sort {
  colId: string;
  sort: 'asc' | 'desc';
}

/** NULL is a selectable Set key, so native set negation is a Boolean complement,
 * unlike SQL NOT IN with NULL. Keep all values bound and empty selections explicit. */
export function compileSetPredicate(
  node: Extract<Node, { kind: 'set' }>,
  identifier: string,
  parameter: (value: unknown) => string,
): string {
  const includesBlank = node.values.includes(null);
  const values = node.values.filter((value): value is string => value !== null);
  const membership = values.length
    ? `LOWER(${identifier}) IN (${values.map((value) => parameter(value.toLowerCase())).join(', ')})`
    : '';
  const positive = includesBlank
    ? membership
      ? `(${identifier} IS NULL OR ${membership})`
      : `${identifier} IS NULL`
    : membership
      ? `(${identifier} IS NOT NULL AND ${membership})`
      : '1 = 0';
  return node.op === 'isAnyOf' ? positive : `NOT (${positive})`;
}
export function validateSort(input: unknown, columns: readonly ColumnSpec[] = COLUMNS): Sort[] {
  const columnMap = new Map(columns.map((column) => [column.id, column]));
  if (!Array.isArray(input) || input.length > 3)
    throw new Fault('SORT', 'At most three sort columns are allowed.');
  const seen = new Set<string>();
  return input.map((v) => {
    if (
      !v ||
      typeof v !== 'object' ||
      Object.keys(v).some((k) => !['colId', 'sort'].includes(k)) ||
      !columnMap.has(v.colId) ||
      !['asc', 'desc'].includes(v.sort) ||
      seen.has(v.colId)
    )
      throw new Fault('SORT', 'Invalid or duplicate sort column.');
    seen.add(v.colId);
    return { colId: v.colId, sort: v.sort };
  });
}
/** Deterministic Snowflake SQL, NEVER model-supplied SQL. SQL identifiers come only from the schema. */
export function compileSql(
  node: Node | null,
  tenant: string,
  sort: Sort[],
  start = 0,
  end = 100,
  dataset: SqlDataset = UNCONFIGURED_SQL_DATASET,
  unpaged = false,
): { sql: string; binds: unknown[]; countSql: string; countBinds: unknown[] } {
  if (
    !Number.isInteger(start) ||
    !Number.isInteger(end) ||
    start < 0 ||
    end <= start ||
    end - start > LIMITS.maxRows ||
    end > 1_000_000
  )
    throw new Fault('PAGE', 'Invalid or excessive row range.');
  validateSqlDataset(dataset);
  const columns = dataset.columns;
  const columnMap = new Map(columns.map((column) => [column.id, column]));
  sort = validateSort(sort, columns);
  if (node) node = validateNode(node, columns);
  const binds: unknown[] = [tenant];
  const param = (v: unknown) => {
    binds.push(v);
    return '?';
  };
  const visit = (n: Node): string => {
    if (n.kind === 'group') return '(' + n.children.map(visit).join(` ${n.join} `) + ')';
    const c = columnMap.get(n.field)!;
    const id = quoteSqlIdentifier(c.sql);
    if (n.kind === 'set') return compileSetPredicate(n, id, param);
    if (n.op === 'blank') return `${id} IS NULL`;
    if (n.op === 'notBlank') return `${id} IS NOT NULL`;
    const lhs = c.kind === 'text' ? `LOWER(${id})` : id;
    let v = c.kind === 'text' ? String(n.value).toLowerCase() : n.value;
    if (['contains', 'notContains', 'startsWith', 'endsWith'].includes(n.op)) {
      v = String(v).replace(/[!%_]/g, (x) => '!' + x);
      if (n.op === 'contains' || n.op === 'notContains' || n.op === 'endsWith') v = '%' + v;
      if (n.op === 'contains' || n.op === 'notContains' || n.op === 'startsWith') v += '%';
      return `${lhs} ${n.op === 'notContains' ? 'NOT LIKE' : 'LIKE'} ${param(v)} ESCAPE '!'`;
    }
    const op = (
      {
        equals: '=',
        notEqual: '<>',
        greaterThan: '>',
        greaterThanOrEqual: '>=',
        lessThan: '<',
        lessThanOrEqual: '<=',
      } as Record<string, string>
    )[n.op];
    if (!op) throw new Fault('OPERATOR', 'Unsupported SQL operator.');
    const rhs = param(v);
    return `${lhs} ${op} ${c.kind === 'date' ? `TO_DATE(${rhs}, 'YYYY-MM-DD')` : c.kind === 'datetime' ? `TO_TIMESTAMP_NTZ(${rhs}, 'YYYY-MM-DD HH24:MI:SS')` : rhs}`;
  };
  // Tenant isolation is outside all user OR groups.
  const where = `${quoteSqlIdentifier(dataset.tenantColumn)} = ?${node ? ' AND (' + visit(node) + ')' : ''}`;
  const order = [
    ...sort,
    ...(sort.some((s) => s.colId === dataset.rowIdColumn)
      ? []
      : [{ colId: dataset.rowIdColumn, sort: 'asc' as const }]),
  ];
  const orderSql = order
    .map(
      (s) =>
        `${quoteSqlIdentifier(columnMap.get(s.colId)!.sql)} ${s.sort.toUpperCase()} NULLS LAST`,
    )
    .join(', ');
  const countBinds = [...binds];
  const table = dataset.table.map(quoteSqlIdentifier).join('.');
  const sql =
    `SELECT ${columns.map((c) => `${quoteSqlIdentifier(c.sql)} AS ${quoteSqlIdentifier(c.id)}`).join(', ')} FROM ${table} WHERE ${where} ${unpaged ? '' : `ORDER BY ${orderSql} LIMIT ? OFFSET ?`}`.trim();
  return {
    sql,
    binds: unpaged ? [...binds] : [...binds, end - start, start],
    countSql: `SELECT COUNT(*) AS "rowCount" FROM ${table} WHERE ${where}`,
    countBinds,
  };
}
