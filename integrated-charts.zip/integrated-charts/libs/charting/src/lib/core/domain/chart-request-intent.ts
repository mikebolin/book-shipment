/** Request lifecycle hints; these do not interpret fields, metrics or filters. */
function positiveRequests(text: string): string {
  return text.replace(
    /\b(?:do\s+not|don't|never)\s+(?:create|add|make|build|draw|update|edit|modify|refine|change|adjust|convert|switch)\b[^.!?;]*/gi,
    '',
  );
}

function separateChart(text: string): boolean {
  return /\b(?:create|add|make|build|draw|show)\s+(?:(?:a|an)\s+)?(?:new|another|additional|separate|second)\b[^.!?;]{0,60}\b(?:chart|graph|plot)\b/i.test(
    text,
  );
}

/** Explicit edits retain the existing chart identity and its unmodified settings. */
export function targetsExistingChart(text: string): boolean {
  const positive = positiveRequests(text);
  if (separateChart(positive)) return false;
  return (
    /\b(?:keep|retain|preserve|use|update|edit|modify|refine|change|adjust|convert|switch|show|build|create)\b[^.!?;]{0,50}\b(?:this|that|current|existing|same|selected|saved)\s+(?:chart|graph|plot)\b/i.test(
      positive,
    ) ||
    /\b(?:update|edit|modify|refine|change|adjust|convert)\s+(?:the\s+)?(?:chart|graph|plot)\b/i.test(
      positive,
    ) ||
    /\b(?:make|turn|convert|change|switch|show)\s+(?:it|this|that)\b[^.!?;]*\b(?:chart|graph|plot|bar|column|line|area|pie|donut|scatter|histogram)\b/i.test(
      positive,
    ) ||
    /^(?:please\s+)?(?:create|make|show|use|draw)\s+(?:(?:a|an|the)\s+)?(?:(?:stacked|normalized|horizontal|vertical|grouped)\s+)*(?:bar|column|line|area|pie|donut|scatter|bubble|histogram)(?:\s+(?:chart|graph|plot))?\s+instead[.!]?$/i.test(
      positive.trim(),
    ) ||
    (/\b(?:on|in)\s+(?:the|this|that)\b[^.!?;]{0,80}\b(?:chart|graph|plot)\b/i.test(positive) &&
      /\b(?:change|replace|keep|retain|update|edit|modify|refine|adjust)\b/i.test(positive))
  );
}

/** A short type selection can answer a real pending question without restarting it. */
export function isChartTypeChoice(text: string): boolean {
  return /^(?:please\s+)?(?:(?:use|show|create|make|draw)\s+)?(?:(?:a|an|the)\s+)?(?:(?:stacked|normalized|100%|horizontal|vertical|grouped)\s+)*(?:bar|column|line|area|pie|donut|doughnut|scatter|bubble|histogram)(?:\s+(?:chart|graph|plot))?[.!]?$/i.test(
    text.trim(),
  );
}

/** Generic builder actions do not discard the settings the user just selected. */
export function usesChartBuilderSettings(text: string): boolean {
  return /^(?:please\s+)?(?:(?:create|make|build|draw|show)\s+(?:(?:a|the|this)\s+)?(?:chart|graph|plot)(?:\s+(?:with|using)\s+(?:these|the|my)\s+settings)?|use\s+(?:these|the|my)\s+settings(?:\s+to\s+(?:create|make|build|draw|show)\s+(?:(?:a|the|this)\s+)?(?:chart|graph|plot))?)[.!]?$/i.test(
    text.trim(),
  );
}

/** A new visual must not borrow an unrelated saved chart's grain, range or metric. */
export function startsNewChartRequest(text: string): boolean {
  const positive = positiveRequests(text);
  if (separateChart(positive)) return true;
  if (targetsExistingChart(positive)) return false;
  return (
    /\b(?:create|add|make|build|draw|show|compare|visuali[sz]e)\b[^.!?;]*\b(?:chart|graph|plot|histogram|scatter|bubble|donut|pie)\b/i.test(
      positive,
    ) ||
    /\b(?:show|plot|draw|create|build|compare|visuali[sz]e)\b[^.!?;]*\bas\s+(?:(?:a|an|the)\s+)?(?:(?:horizontal|vertical|grouped|stacked|normalized|100%)\s+)*(?:bars?|columns?|lines?|areas?)\b/i.test(
      positive,
    ) ||
    /\b(?:count|sum|total|average)\b[^.!?;]{0,120}\bby\b[^.!?;]{0,80}\b(?:in|as)\s+(?:(?:horizontal|vertical|grouped|stacked|normalized)\s+)*(?:bars?|columns?|lines?|areas?)\b/i.test(
      positive,
    ) ||
    /^(?:please\s+)?(?:chart|graph|plot|visuali[sz]e)\b/i.test(positive) ||
    /\b(?:and|then)\s+(?:chart|graph|plot|visuali[sz]e)\b/i.test(positive)
  );
}

/** Explicit simple chart shapes can be enforced without interpreting any data fields. */
export function requestedSimpleChartType(
  text: string,
):
  | 'groupedBar'
  | 'stackedBar'
  | 'normalizedBar'
  | 'groupedColumn'
  | 'stackedColumn'
  | 'normalizedColumn'
  | 'pie'
  | 'donut'
  | null {
  const positive = positiveRequests(text);
  const shapes = [
    { name: 'bar', pattern: /\b(?:horizontal\s+bars?|bar\s+(?:chart|graph|plot))\b/i },
    {
      name: 'column',
      pattern: /\b(?:column\s+(?:chart|graph|plot)|vertical\s+columns?|(?:in|as)\s+columns?)\b/i,
    },
    { name: 'pie', pattern: /\bpie(?:\s+(?:chart|graph|plot))?\b/i },
    { name: 'donut', pattern: /\b(?:donut|doughnut)(?:\s+(?:chart|graph|plot))?\b/i },
  ] as const;
  const matches = shapes.filter((shape) => shape.pattern.test(positive));
  if (matches.length !== 1) return null;
  const shape = matches[0]!.name;
  if (shape === 'bar' || shape === 'column') {
    if (/\b(?:line|area|scatter|bubble|histogram|combo|combination)\b/i.test(positive)) return null;
    const suffix = shape === 'bar' ? 'Bar' : 'Column';
    const prefix = /(?:100\s*%|\bnormalized\b)/i.test(positive)
      ? 'normalized'
      : /\bstacked\b/i.test(positive)
        ? 'stacked'
        : 'grouped';
    return `${prefix}${suffix}` as
      | 'groupedBar'
      | 'stackedBar'
      | 'normalizedBar'
      | 'groupedColumn'
      | 'stackedColumn'
      | 'normalizedColumn';
  }
  return shape;
}
