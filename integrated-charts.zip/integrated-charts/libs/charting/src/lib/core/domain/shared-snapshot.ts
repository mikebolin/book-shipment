/** Finite, reference-counted dataset cache. Not a replay buffer for every NDJSON batch. */
export type SnapshotRow = Readonly<Record<string, string | number | boolean | null>>;
export interface SnapshotDescriptor {
  key: string;
  schemaVersion: string;
  datetimeColumns?: readonly string[];
}
export interface SnapshotData {
  readonly rows: readonly SnapshotRow[];
  readonly decodedBytes: number;
  readonly receivedAt: number;
}
export interface SnapshotLease {
  readonly result: Promise<SnapshotData>;
  release(): void;
}
export interface SnapshotOptions {
  maxConcurrent?: number;
  maxDecodedBytes?: number;
  maxRows?: number;
  maxCacheBytes?: number;
  maxLineBytes?: number;
}
interface Entry {
  key: string;
  refs: number;
  controller: AbortController;
  result: Promise<SnapshotData>;
  value?: SnapshotData;
  lastUsed: number;
}
export class SnapshotError extends Error {
  constructor(
    public readonly code: string,
    message: string,
  ) {
    super(message);
    this.name = 'SnapshotError';
  }
}

/** The filter engine and grid share UTC timestamps at second precision. */
export function snapshotTimestamp(value: unknown, field: string): unknown {
  if (value == null) return value;
  const match =
    typeof value === 'string' &&
    /^(\d{4}-\d{2}-\d{2})[ T](\d{2}):(\d{2}):(\d{2})(?:\.\d{1,9})?(Z|[+-]\d{2}:\d{2})?$/.exec(
      value,
    );
  if (!match || +match[2] > 23 || +match[3] > 59 || +match[4] > 59)
    throw new SnapshotError(
      'INVALID_TIMESTAMP',
      `Invalid timestamp in ${field}. Use a UTC timestamp or an ISO timestamp with a time zone.`,
    );
  const calendar = new Date(match[1] + 'T00:00:00Z');
  const instant = new Date(value.replace(' ', 'T') + (match[5] ? '' : 'Z'));
  if (
    !Number.isFinite(calendar.getTime()) ||
    calendar.toISOString().slice(0, 10) !== match[1] ||
    !Number.isFinite(instant.getTime())
  )
    throw new SnapshotError('INVALID_TIMESTAMP', `Invalid calendar date or timestamp in ${field}.`);
  return instant.toISOString().slice(0, 19).replace('T', ' ');
}
export async function readSnapshot(
  response: Response,
  expected: SnapshotDescriptor,
  signal: AbortSignal,
  options: SnapshotOptions = {},
): Promise<SnapshotData> {
  if (!response.ok || !response.body)
    throw new SnapshotError('HTTP', `Snapshot request failed (${response.status}).`);
  const reader = response.body.getReader(),
    decoder = new TextDecoder('utf-8', { fatal: true });
  const rows: SnapshotRow[] = [],
    ids = new Set<string>();
  let buffer = '',
    started = false,
    completed = false,
    total = -1,
    bytes = 0,
    lastYield = performance.now();
  const VALUES = Symbol('snapshot-values');
  let columns: string[] | undefined,
    prototype: object | undefined,
    idIndex = -1;
  const datetimeColumns = new Set(expected.datetimeColumns ?? []);
  let datetimeIndexes: number[] = [];
  const maxBytes = options.maxDecodedBytes ?? 256 * 1024 * 1024,
    maxLine = options.maxLineBytes ?? 1024 * 1024,
    maxRows = options.maxRows ?? 250000;
  const abort = () => void reader.cancel(signal.reason).catch(() => {});
  signal.addEventListener('abort', abort, { once: true });
  const consume = (line: string) => {
    if (!line.trim()) return;
    if (completed) throw new SnapshotError('PROTOCOL', 'Data appeared after completion.');
    let item: any;
    try {
      item = JSON.parse(line);
    } catch {
      throw new SnapshotError('PROTOCOL', 'Malformed NDJSON.');
    }
    if (item.type === 'start') {
      if (
        started ||
        item.schemaVersion !== expected.schemaVersion ||
        !Number.isSafeInteger(item.totalRows) ||
        item.totalRows < 0 ||
        item.totalRows > maxRows
      )
        throw new SnapshotError('PROTOCOL', 'Invalid snapshot schema or row count.');
      started = true;
      total = item.totalRows;
      if (item.encoding !== undefined && item.encoding !== 'column-rows-v1')
        throw new SnapshotError('PROTOCOL', 'Unsupported snapshot encoding.');
      if (item.encoding === 'column-rows-v1') {
        if (
          !Array.isArray(item.columns) ||
          item.columns.length > 2000 ||
          item.columns.some(
            (c: any) =>
              typeof c !== 'string' || !c || ['__proto__', 'constructor', 'prototype'].includes(c),
          ) ||
          new Set(item.columns).size !== item.columns.length ||
          !item.columns.includes('id')
        )
          throw new SnapshotError('PROTOCOL', 'Invalid compact snapshot schema.');
        columns = item.columns;
        datetimeIndexes = columns!.flatMap((field, index) =>
          datetimeColumns.has(field) ? [index] : [],
        );
        idIndex = columns!.indexOf('id');
        prototype = Object.create(null);
        columns!.forEach((field, index) => {
          if (field !== 'id')
            Object.defineProperty(prototype!, field, {
              enumerable: true,
              get(this: { [VALUES]: readonly unknown[] }) {
                return this[VALUES][index];
              },
            });
        });
        Object.freeze(prototype);
      }
    } else if (item.type === 'batch') {
      if (
        !started ||
        !Array.isArray(item.rows) ||
        item.rows.length > 1024 ||
        rows.length + item.rows.length > total
      )
        throw new SnapshotError('PROTOCOL', 'Invalid row batch.');
      for (const encoded of item.rows) {
        let row = encoded;
        if (columns) {
          if (
            !Array.isArray(encoded) ||
            encoded.length !== columns.length ||
            encoded.some(
              (v) =>
                !(
                  v === null ||
                  typeof v === 'string' ||
                  typeof v === 'boolean' ||
                  (typeof v === 'number' && Number.isFinite(v))
                ),
            )
          )
            throw new SnapshotError('PROTOCOL', 'Invalid compact row.');
          for (const index of datetimeIndexes)
            encoded[index] = snapshotTimestamp(encoded[index], columns[index]);
          row = Object.create(prototype!, {
            id: { value: encoded[idIndex], enumerable: true },
            [VALUES]: { value: Object.freeze(encoded) },
          });
        } else if (row && typeof row === 'object' && !Array.isArray(row)) {
          for (const field of datetimeColumns)
            if (Object.hasOwn(row, field)) row[field] = snapshotTimestamp(row[field], field);
        }
        if (
          !row ||
          Array.isArray(row) ||
          typeof row !== 'object' ||
          typeof row.id !== 'string' ||
          !row.id ||
          ids.has(row.id)
        )
          throw new SnapshotError('PROTOCOL', 'Rows require unique string IDs.');
        if (
          Object.keys(row).some(
            (k) => k === '__proto__' || k === 'constructor' || k === 'prototype',
          )
        )
          throw new SnapshotError('PROTOCOL', 'Unsafe row property.');
        ids.add(row.id);
        rows.push(Object.freeze(row));
      }
    } else if (item.type === 'complete') {
      if (!started || item.totalRows !== total || rows.length !== total)
        throw new SnapshotError('TRUNCATED', 'Snapshot row count did not reconcile.');
      completed = true;
    } else throw new SnapshotError('PROTOCOL', 'Unsupported snapshot event.');
  };
  try {
    while (true) {
      if (signal.aborted) throw signal.reason ?? new DOMException('Aborted', 'AbortError');
      const { value, done } = await reader.read();
      if (done) break;
      bytes += value.byteLength;
      if (bytes > maxBytes)
        throw new SnapshotError(
          'CAPACITY',
          'This model exceeds the browser snapshot budget. Choose a smaller sample.',
        );
      buffer += decoder.decode(value, { stream: true });
      let newline;
      while ((newline = buffer.indexOf('\n')) !== -1) {
        if (newline > maxLine)
          throw new SnapshotError('CAPACITY', 'NDJSON line exceeds its safety limit.');
        consume(buffer.slice(0, newline));
        buffer = buffer.slice(newline + 1);
        if (performance.now() - lastYield > 8) {
          await new Promise((r) => setTimeout(r, 0));
          lastYield = performance.now();
        }
      }
      if (buffer.length > maxLine)
        throw new SnapshotError('CAPACITY', 'NDJSON line exceeds its safety limit.');
    }
    if (signal.aborted) throw signal.reason ?? new DOMException('Aborted', 'AbortError');
    buffer += decoder.decode();
    if (buffer.trim()) consume(buffer);
    if (!completed)
      throw new SnapshotError('TRUNCATED', 'The stream ended before its completion marker.');
    return Object.freeze({
      rows: Object.freeze(rows),
      decodedBytes: bytes,
      receivedAt: Date.now(),
    });
  } finally {
    signal.removeEventListener('abort', abort);
    await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
}
export class SharedSnapshotCache {
  private entries = new Map<string, Entry>();
  private waiting: Array<() => void> = [];
  private running = 0;
  readonly metrics = {
    downloads: 0,
    coalesced: 0,
    hits: 0,
    failures: 0,
    decodedBytes: 0,
    peakConcurrent: 0,
  };
  constructor(private readonly options: SnapshotOptions = {}) {}
  acquire(
    descriptor: SnapshotDescriptor,
    load: (signal: AbortSignal) => Promise<Response>,
  ): SnapshotLease {
    let entry = this.entries.get(descriptor.key);
    if (entry) {
      entry.refs++;
      entry.lastUsed = Date.now();
      entry.value ? this.metrics.hits++ : this.metrics.coalesced++;
      return this.lease(entry);
    }
    const controller = new AbortController();
    entry = {
      key: descriptor.key,
      refs: 1,
      controller,
      lastUsed: Date.now(),
      result: Promise.resolve(null as never),
    };
    const current = entry;
    this.entries.set(descriptor.key, current);
    current.result = this.slot(controller.signal, async () => {
      this.metrics.downloads++;
      const value = await readSnapshot(
        await load(controller.signal),
        descriptor,
        controller.signal,
        this.options,
      );
      if (controller.signal.aborted) throw controller.signal.reason;
      this.evict(value.decodedBytes, current.key);
      const retained = [...this.entries.values()].reduce(
        (n, e) => n + (e.value?.decodedBytes ?? 0),
        0,
      );
      if (retained + value.decodedBytes > (this.options.maxCacheBytes ?? 384 * 1024 * 1024))
        throw new SnapshotError(
          'CAPACITY',
          'Active models exceed the shared cache budget. Close another model first.',
        );
      current.value = value;
      this.metrics.decodedBytes += value.decodedBytes;
      return value;
    }).catch((error) => {
      this.metrics.failures++;
      if (this.entries.get(current.key) === current) this.entries.delete(current.key);
      throw error;
    });
    // Consumers still receive the original rejecting promise; this prevents abandoned leases
    // from producing a global unhandled-rejection when a component is destroyed.
    void current.result.catch(() => {});
    return this.lease(current);
  }
  private lease(entry: Entry): SnapshotLease {
    let released = false;
    return {
      result: entry.result,
      release: () => {
        if (released) return;
        released = true;
        entry.refs--;
        entry.lastUsed = Date.now();
        if (entry.refs === 0 && !entry.value) {
          entry.controller.abort(new DOMException('No subscribers', 'AbortError'));
          if (this.entries.get(entry.key) === entry) this.entries.delete(entry.key);
        }
        this.evict(0);
      },
    };
  }
  private async slot<T>(signal: AbortSignal, work: () => Promise<T>): Promise<T> {
    while (this.running >= (this.options.maxConcurrent ?? 2)) {
      await new Promise<void>((resolve, reject) => {
        const wake = () => {
          signal.removeEventListener('abort', abort);
          resolve();
        };
        const abort = () => {
          this.waiting = this.waiting.filter((x) => x !== wake);
          reject(signal.reason);
        };
        this.waiting.push(wake);
        signal.addEventListener('abort', abort, { once: true });
        if (signal.aborted) abort();
      });
    }
    if (signal.aborted) throw signal.reason;
    this.running++;
    this.metrics.peakConcurrent = Math.max(this.metrics.peakConcurrent, this.running);
    try {
      return await work();
    } finally {
      this.running--;
      this.waiting.shift()?.();
    }
  }
  private evict(incoming: number, exclude?: string) {
    let bytes = [...this.entries.values()].reduce((n, e) => n + (e.value?.decodedBytes ?? 0), 0);
    const target = (this.options.maxCacheBytes ?? 384 * 1024 * 1024) - incoming;
    for (const entry of [...this.entries.values()]
      .filter((e) => e.refs === 0 && e.value && e.key !== exclude)
      .sort((a, b) => a.lastUsed - b.lastUsed)) {
      if (bytes <= target && Date.now() - entry.lastUsed < 60000) break;
      bytes -= entry.value!.decodedBytes;
      this.entries.delete(entry.key);
    }
  }
  clear() {
    for (const e of this.entries.values())
      e.controller.abort(new DOMException('Session ended', 'AbortError'));
    this.entries.clear();
  }
  diagnostics() {
    return {
      ...this.metrics,
      activeRequests: this.running,
      entries: this.entries.size,
      subscribers: [...this.entries.values()].reduce((s, e) => s + e.refs, 0),
      retainedDecodedBytes: [...this.entries.values()].reduce(
        (n, e) => n + (e.value?.decodedBytes ?? 0),
        0,
      ),
    };
  }
}
