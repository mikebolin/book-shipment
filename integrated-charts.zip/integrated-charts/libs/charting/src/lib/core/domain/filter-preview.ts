import type { ColumnSpec } from './schema.js';
import type { GridModel, Mode, Operator } from './contracts.js';
import { fromModel, toModel } from './grid-model.js';

/**
 * The English Advanced Filter expression for this application's column definitions.
 * Mirrors AG Grid 36.2's expression writer (including its type-specific operators,
 * quote selection, blank set label and parentheses). Browser tests compare this
 * text with the actual native input after setAdvancedFilterModel through Apply.
 * Keep these tests when upgrading AG Grid or introducing custom operand formatters,
 * set value formatters, tree lists or locale text.
 */
export function filterPreview(
  model: GridModel,
  mode: Mode,
  columns: readonly ColumnSpec[],
): string {
  const node = fromModel(model, mode, columns);
  if (!node) return '';
  const textOperators: Record<Operator, string> = {
    equals: 'equals',
    notEqual: 'does not equal',
    contains: 'contains',
    notContains: 'does not contain',
    startsWith: 'begins with',
    endsWith: 'ends with',
    greaterThan: '>',
    greaterThanOrEqual: '>=',
    lessThan: '<',
    lessThanOrEqual: '<=',
    blank: 'is blank',
    notBlank: 'is not blank',
  };
  const quote = (value: string, setValue = false): string => {
    if (!value.includes('"')) return `"${value}"`;
    if (!value.includes("'")) return `'${value}'`;
    // Native set operands escape embedded double quotes by doubling them.
    return `"${setValue ? value.replaceAll('"', '""') : value}"`;
  };
  const columnMap = new Map(columns.map((column) => [column.id, column]));
  type NativeModel = Record<string, unknown>;
  const format = (value: NativeModel, top = false): string => {
    if (value['filterType'] === 'join') {
      const children = value['conditions'] as NativeModel[];
      const expression = children.map((child) => format(child)).join(` ${value['type']} `);
      return top || children.length <= 1 ? expression : `(${expression})`;
    }
    const column = columnMap.get(value['colId'] as string)!;
    const field = `[${column.label}]`;
    if (value['filterType'] === 'set') {
      const values = [
        ...new Set(
          (value['values'] as (string | null)[]).map((entry) => quote(entry ?? '(Blanks)', true)),
        ),
      ];
      return `${field} ${value['type'] === 'isAnyOf' ? 'is any of' : 'is none of'} [${values.join(', ')}]`;
    }
    const op = value['type'] as Operator;
    const operator =
      column.kind !== 'text' && (op === 'equals' || op === 'notEqual')
        ? op === 'equals'
          ? '='
          : '!='
        : textOperators[op];
    const operand = value['filter'];
    if (operand == null) return `${field} ${operator}`;
    const displayed =
      column.kind === 'datetime' ? String(operand).replace(' ', 'T') : String(operand);
    return `${field} ${operator} ${column.kind === 'number' ? displayed : quote(displayed)}`;
  };
  // Validate above, but retain the reviewed advanced model's exact nesting. The
  // internal predicate representation legitimately flattens same-join groups.
  return format((mode === 'advanced' ? model : toModel(node, 'advanced', columns))!, true);
}
