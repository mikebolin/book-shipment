import type { Operator } from './contracts.js';
import { isColumnGroupTag } from './column-grouping.js';
export type Kind = 'text' | 'number' | 'date' | 'datetime';
export interface ColumnSpec {
  id: string;
  label: string;
  kind: Kind;
  aliases: string[];
  nullable: boolean;
  values?: string[];
  scale?: number;
  sql: string;
  description: string;
  /** Trusted application metadata; never accepted from chart requests. */
  chartRole?: 'identifier' | 'dimension' | 'measure' | 'temporal';
  unit?: string | null;
  /** Optional trusted column-panel category; one trimmed label, never row grouping or AI input. */
  groupByTag?: string;
}
/** Empty defaults require every host to provide its own model schema. */
export const COLUMNS: ColumnSpec[] = [];

/** The schema is application configuration, never a user-provided request body. */
export function validateSchema(columns: readonly ColumnSpec[]): void {
  const ids = new Set<string>(),
    sql = new Set<string>(),
    labels = new Set<string>();
  const aliases = new Map<string, string>();
  for (const c of columns) {
    if (
      !/^[A-Za-z][A-Za-z0-9_]*$/.test(c.id) ||
      ['constructor', 'prototype', '__proto__', 'tenant'].includes(c.id) ||
      !c.sql ||
      c.sql.length > 255 ||
      /[\u0000-\u001f\u007f]/.test(c.sql) ||
      ids.has(c.id) ||
      sql.has(c.sql) ||
      labels.has(c.label.toLowerCase()) ||
      !['text', 'number', 'date', 'datetime'].includes(c.kind) ||
      !c.description ||
      (c.groupByTag !== undefined && !isColumnGroupTag(c.groupByTag)) ||
      (c.chartRole !== undefined &&
        (!['identifier', 'dimension', 'measure', 'temporal'].includes(c.chartRole) ||
          (c.chartRole === 'measure' && c.kind !== 'number') ||
          (c.chartRole === 'temporal' && c.kind !== 'date' && c.kind !== 'datetime'))) ||
      (c.unit !== undefined &&
        c.unit !== null &&
        (typeof c.unit !== 'string' || !c.unit.trim() || c.unit.length > 64)) ||
      (c.values !== undefined &&
        (c.kind !== 'text' ||
          !c.values.length ||
          c.values.some((value) => typeof value !== 'string' || value.length > 256) ||
          new Set(c.values.map((value) => value.toLowerCase())).size !== c.values.length)) ||
      (c.scale !== undefined &&
        (c.kind !== 'number' || !Number.isInteger(c.scale) || c.scale < 0 || c.scale > 6))
    ) {
      throw new Error('Invalid or duplicate schema column: ' + c.id);
    }
    ids.add(c.id);
    sql.add(c.sql);
    labels.add(c.label.toLowerCase());
    for (const alias of [c.id, ...c.aliases]) {
      const normalized = alias.trim().toLowerCase();
      if (!normalized || (aliases.has(normalized) && aliases.get(normalized) !== c.id))
        throw new Error('Ambiguous schema alias: ' + alias);
      aliases.set(normalized, c.id);
    }
  }
}
validateSchema(COLUMNS);

export const COLUMN_MAP = new Map(COLUMNS.map((c) => [c.id, c]));
export const LIMITS = {
  text: 2000,
  leaves: 24,
  depth: 5,
  conditionsPerColumn: 2,
  ttlMs: 300_000,
  maxPending: 1000,
  maxRows: 500,
} as const;
export function operators(c: ColumnSpec): Operator[] {
  const basic: Operator[] = ['equals', 'notEqual'];
  const extra: Operator[] =
    c.kind === 'text'
      ? ['contains', 'notContains', 'startsWith', 'endsWith']
      : ['greaterThan', 'greaterThanOrEqual', 'lessThan', 'lessThanOrEqual'];
  return [...basic, ...extra, 'blank', 'notBlank'];
}
