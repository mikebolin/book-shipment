import { z } from 'zod';
import { COLUMNS, LIMITS } from './schema.js';
import type { ColumnSpec } from './schema.js';
import {
  calculatedColumnSpec,
  materializeCalculatedColumns,
  type CalculatedColumnDefinition,
} from './calculated-columns.js';
import { evaluate, Fault } from './engine.js';
import { fromModel } from './grid-model.js';
import { decodeAnalyticsGroupKey, normalizeAnalyticsValue } from './analytics-values';
import {
  ANALYTICS_AGG_FUNCS,
  ANALYTICS_LIMITS,
  PIVOT_FIELD_SEPARATOR,
  analyticsGroupKey,
  analyticsPivotKey,
} from './analytics-query.js';
import type {
  AnalyticsAggFunc,
  AnalyticsColumn,
  AnalyticsRowsRequest,
  AnalyticsRowsResponse,
} from './analytics-query.js';
export type AnalyticsSourceRow = Record<string, string | number | null>;

/** Only the server may extend the schema with its confirmed calculation definitions. */
export function createAnalyticsRowsSchema(columns: readonly ColumnSpec[] = COLUMNS) {
  const columnMap = new Map(columns.map((column) => [column.id, column]));
  const columnSchema = z
    .object({
      id: z.string().min(1).max(100),
      field: z.string().min(1).max(100).optional(),
      displayName: z.string().max(256).optional(),
      aggFunc: z.string().max(40).nullable().optional(),
    })
    .strict()
    .superRefine((column, ctx) => {
      if (!columnMap.has(column.id) || (column.field != null && column.field !== column.id))
        ctx.addIssue({ code: 'custom', message: 'Columns must match the allowed schema IDs.' });
    });

  return z
    .object({
      mode: z.enum(['advanced', 'columns']),
      calculatedColumnIds: z
        .array(z.string().regex(/^calc_[A-Za-z0-9_-]{1,70}$/))
        .max(8)
        .optional(),
      request: z
        .object({
          startRow: z.number().int().min(0).max(Number.MAX_SAFE_INTEGER),
          endRow: z.number().int().min(1).max(Number.MAX_SAFE_INTEGER),
          filterModel: z.record(z.unknown()).nullable(),
          sortModel: z
            .array(
              z
                .object({ colId: z.string().min(1).max(1000), sort: z.enum(['asc', 'desc']) })
                .strict(),
            )
            .max(3),
          rowGroupCols: z.array(columnSchema).max(ANALYTICS_LIMITS.groups),
          valueCols: z.array(columnSchema).max(ANALYTICS_LIMITS.values),
          pivotCols: z.array(columnSchema).max(ANALYTICS_LIMITS.pivots),
          pivotMode: z.boolean(),
          groupKeys: z
            .array(z.union([z.string().max(1000), z.number().finite(), z.null()]))
            .max(ANALYTICS_LIMITS.groups),
        })
        .strict(),
    })
    .strict()
    .superRefine(({ request: r, calculatedColumnIds }, ctx) => {
      const issue = (message: string) => ctx.addIssue({ code: 'custom', message });
      if (calculatedColumnIds) {
        if (new Set(calculatedColumnIds).size !== calculatedColumnIds.length)
          issue('Calculated column IDs must be unique.');
        if (calculatedColumnIds.some((id) => !columnMap.has(id)))
          issue('Calculated columns must be confirmed for this request.');
      }
      if (r.endRow <= r.startRow || r.endRow - r.startRow > LIMITS.maxRows)
        issue(`Request between 1 and ${LIMITS.maxRows} rows.`);
      if (r.groupKeys.length > r.rowGroupCols.length) issue('Group route exceeds grouping depth.');
      for (const columns of [r.rowGroupCols, r.valueCols, r.pivotCols]) {
        if (new Set(columns.map((c) => c.id)).size !== columns.length)
          issue('A column may occur only once in each analytics role.');
      }
      if (new Set(r.sortModel.map((s) => s.colId)).size !== r.sortModel.length)
        issue('Sort columns must be unique.');
      for (const column of r.valueCols) {
        if (
          columnMap.get(column.id)?.kind !== 'number' ||
          !ANALYTICS_AGG_FUNCS.includes(column.aggFunc as AnalyticsAggFunc)
        )
          issue(
            'Value columns require a numeric field and sum, avg, min, max, count, first, or last.',
          );
        if (r.rowGroupCols.some((group) => group.id === column.id))
          issue('A column cannot be both a row group and a value column.');
      }
      if (r.pivotCols.some((c) => columnMap.get(c.id)?.kind === 'number'))
        issue('Pivot columns must be text or date dimensions.');
      if (r.pivotMode && r.pivotCols.length > 0 && r.valueCols.length === 0)
        issue('Pivoting requires at least one value column.');
    });
}

export const analyticsRowsSchema = createAnalyticsRowsSchema();

type Row = AnalyticsRowsResponse['rowData'][number];
type Value = string | number | null;
type Pivot = { key: string; fields: string[] };

function aggregate(
  rows: AnalyticsSourceRow[],
  column: AnalyticsColumn,
  rowIdColumn = 'id',
): number | null {
  // AG Grid count counts rows, including rows with a blank measure.
  if (column.aggFunc === 'count') return rows.length;
  // AG Grid first/last include blank values. Source account-ID order is stable,
  // independent of display sorting, route expansion, and block pagination.
  // A chronology-based opening/closing balance needs a separately defined order.
  if (column.aggFunc === 'first' || column.aggFunc === 'last') {
    const selected = rows.reduce<AnalyticsSourceRow | undefined>((current, row) => {
      if (!current) return row;
      return (
        column.aggFunc === 'first'
          ? compare(row[rowIdColumn], current[rowIdColumn]) < 0
          : compare(row[rowIdColumn], current[rowIdColumn]) > 0
      )
        ? row
        : current;
    }, undefined)?.[column.id];
    return typeof selected === 'number' ? selected : null;
  }
  const values = rows
    .map((row) => row[column.id])
    .filter((v): v is number => typeof v === 'number');
  if (values.length === 0) return null;
  switch (column.aggFunc) {
    case 'sum':
      return values.reduce((sum, value) => sum + value, 0);
    case 'avg':
      return values.reduce((sum, value) => sum + value, 0) / values.length;
    case 'min':
      return values.reduce((result, value) => Math.min(result, value), Infinity);
    case 'max':
      return values.reduce((result, value) => Math.max(result, value), -Infinity);
    default:
      throw new Fault('INVALID_AGGREGATION', 'Unsupported aggregation.');
  }
}

function compare(a: Value | undefined, b: Value | undefined): number {
  if (a === b) return 0;
  if (a == null) return 1;
  if (b == null) return -1;
  return a < b ? -1 : 1;
}

function pivotKey(row: AnalyticsSourceRow, columns: AnalyticsColumn[]): string {
  return columns.map((column) => analyticsPivotKey(row[column.id])).join(PIVOT_FIELD_SEPARATOR);
}

/** Mock analytics always run over the local dataset's entire filtered fixture. */
export function queryAnalyticsRows(
  tenant: string | null,
  input: AnalyticsRowsRequest,
  source: {
    columns: readonly ColumnSpec[];
    rows: readonly AnalyticsSourceRow[];
    preserveRowReferences?: boolean;
    rowIdColumn?: string;
    rawGroupKeys?: boolean;
    includeGroupCount?: boolean;
  },
  signal?: AbortSignal,
  calculatedColumns: readonly CalculatedColumnDefinition[] = [],
): AnalyticsRowsResponse {
  signal?.throwIfAborted();
  const columns = [
    ...source.columns,
    ...calculatedColumns.map((column) => calculatedColumnSpec(column, source.columns)),
  ];
  const columnMap = new Map(columns.map((column) => [column.id, column]));
  // Revalidation also protects direct callers; the HTTP route uses the same schema.
  const { mode, request: r } = createAnalyticsRowsSchema(columns).parse(input);
  const ast = fromModel(r.filterModel, mode, columns);
  // Calculations must participate in filtering and global ordering before block paging.
  // Materialization copies each permitted row, leaving the shared mock fixture unchanged.
  const filtered = source.rows
    .filter((row) => tenant === null || row.tenant === tenant)
    .map((row) =>
      calculatedColumns.length
        ? materializeCalculatedColumns(row, calculatedColumns, source.columns)
        : row,
    )
    .filter((row) => evaluate(ast, row));
  const pivoting = r.pivotMode && r.pivotCols.length > 0;
  const pivots: Pivot[] = [];
  if (pivoting) {
    const keys = new Set(filtered.map((row) => pivotKey(row, r.pivotCols)));
    if (keys.size * r.valueCols.length > ANALYTICS_LIMITS.pivotFields)
      throw new Fault(
        'PIVOT_LIMIT',
        `The result exceeds ${ANALYTICS_LIMITS.pivotFields} pivot value columns. Filter the data or choose fewer dimensions.`,
      );
    for (const key of [...keys].sort())
      pivots.push({
        key,
        fields: r.valueCols.map((column) => key + PIVOT_FIELD_SEPARATOR + column.id),
      });
  }
  const pivotResultFields = pivots.flatMap((pivot) => pivot.fields);
  const allowedSort = new Set([...columnMap.keys(), ...pivotResultFields]);
  const currentGroup = r.rowGroupCols[r.groupKeys.length];
  const effectiveSort = r.sortModel.map((sort) => {
    if (sort.colId === 'ag-Grid-AutoColumn' || sort.colId.startsWith('ag-Grid-AutoColumn-')) {
      const group =
        sort.colId === 'ag-Grid-AutoColumn'
          ? currentGroup
          : r.rowGroupCols.find((column) => 'ag-Grid-AutoColumn-' + column.id === sort.colId);
      if (!group && sort.colId !== 'ag-Grid-AutoColumn')
        throw new Fault('INVALID_SORT', 'The group sort references an unknown grouping column.');
      return {
        ...sort,
        colId: group?.id ?? r.rowGroupCols.at(-1)?.id ?? source.rowIdColumn ?? 'id',
      };
    }
    if (!allowedSort.has(sort.colId))
      throw new Fault(
        'INVALID_SORT',
        'The sort references an unknown source or pivot result column.',
      );
    return sort;
  });
  const route = r.groupKeys.map((key, depth) => ({
    id: r.rowGroupCols[depth].id,
    value: normalizeAnalyticsValue(
      decodeAnalyticsGroupKey(key),
      columnMap.get(r.rowGroupCols[depth].id)!,
    ),
  }));
  const scoped = filtered.filter((row) =>
    route.every(({ id, value }) => (row[id] ?? null) === value),
  );
  const summarize = (rows: AnalyticsSourceRow[], keys: Row = {}): Row => {
    const result: Row = { ...keys };
    for (const column of r.valueCols)
      result[column.id] = aggregate(rows, column, source.rowIdColumn ?? 'id');
    if (pivoting) {
      const buckets = new Map<string, AnalyticsSourceRow[]>();
      for (const row of rows) {
        const key = pivotKey(row, r.pivotCols);
        const bucket = buckets.get(key);
        if (bucket) bucket.push(row);
        else buckets.set(key, [row]);
      }
      for (const pivot of pivots) {
        const bucket = buckets.get(pivot.key) ?? [];
        r.valueCols.forEach((column, index) => {
          result[pivot.fields[index]] = aggregate(bucket, column, source.rowIdColumn ?? 'id');
        });
      }
    }
    return result;
  };
  let rowData: Row[];
  const groupSortKeys = new Map<Row, Value>();
  if (currentGroup) {
    const groups = new Map<Value, AnalyticsSourceRow[]>();
    for (const row of scoped) {
      const key = row[currentGroup.id];
      const bucket = groups.get(key);
      if (bucket) bucket.push(row);
      else groups.set(key, [row]);
    }
    rowData = [...groups].map(([key, rows]) => {
      const result = summarize(rows, {
        [currentGroup.id]: source.rawGroupKeys ? key : analyticsGroupKey(key),
      });
      if (source.includeGroupCount) result['__groupCount'] = rows.length;
      groupSortKeys.set(result, key);
      return result;
    });
  } else if (pivoting || (r.pivotMode && r.valueCols.length > 0)) {
    rowData = scoped.length > 0 ? [summarize(scoped)] : [];
  } else {
    rowData = scoped;
  }
  const summarizedLeaves = pivoting || (r.pivotMode && r.valueCols.length > 0);
  // The same native sort model accompanies every SSRM route. A source-only sort
  // orders account leaves; it must not compare absent source cells on group rows.
  const routeSort =
    currentGroup || summarizedLeaves
      ? effectiveSort.filter(
          (sort) =>
            sort.colId === currentGroup?.id ||
            r.valueCols.some((column) => column.id === sort.colId) ||
            pivotResultFields.includes(sort.colId),
        )
      : effectiveSort;
  const order = [
    ...routeSort,
    ...(currentGroup
      ? [{ colId: currentGroup.id, sort: 'asc' as const }]
      : !summarizedLeaves
        ? [{ colId: source.rowIdColumn ?? 'id', sort: 'asc' as const }]
        : []),
  ];
  rowData.sort((a, b) => {
    for (const sort of order) {
      const x = sort.colId === currentGroup?.id ? groupSortKeys.get(a) : a[sort.colId];
      const y = sort.colId === currentGroup?.id ? groupSortKeys.get(b) : b[sort.colId];
      const cmp = compare(x, y);
      // Keep blanks last for both ascending and descending orders.
      if (cmp) return x == null || y == null || sort.sort === 'asc' ? cmp : -cmp;
    }
    return 0;
  });
  signal?.throwIfAborted();
  return {
    rowData: rowData.slice(r.startRow, r.endRow).map((sourceRow) => {
      if (source.preserveRowReferences) return sourceRow;
      // Bundled snapshots decode into compact rows whose fields are enumerable getters on a
      // shared prototype, and calculated-column materialization inherits the source row.
      // Object spread copies own properties only and would return a row with just its ID,
      // so copy every enumerable field, inherited or own, except the tenant partition.
      const row: Row = {};
      for (const key in sourceRow) if (key !== 'tenant') row[key] = sourceRow[key];
      return row;
    }),
    rowCount: rowData.length,
    ...(pivoting ? { pivotResultFields } : {}),
    ...(r.groupKeys.length === 0 && r.valueCols.length
      ? { grandTotalData: summarize(filtered) }
      : {}),
  };
}
