import { Temporal } from '@js-temporal/polyfill';
import { z } from 'zod';
import { COLUMNS, LIMITS, operators } from './schema.js';
import type { ColumnSpec } from './schema.js';
import type { Context, Node, Operator, Question } from './contracts.js';
import { SET_FILTER_MAX_VALUES, setFilterValues } from './set-filters.js';

export class Fault extends Error {
  constructor(
    public code: string,
    message: string,
    public hints: string[] = [],
  ) {
    super(message);
  }
}
export class Clarify extends Error {
  constructor(
    public question: Question,
    public replacements: Record<string, string>,
  ) {
    super(question.message);
  }
}
const OPS: Operator[] = [
  'equals',
  'notEqual',
  'contains',
  'notContains',
  'startsWith',
  'endsWith',
  'greaterThan',
  'greaterThanOrEqual',
  'lessThan',
  'lessThanOrEqual',
  'blank',
  'notBlank',
];
const nodeSchema: z.ZodType<Node> = z.lazy(() =>
  z.union([
    z
      .object({
        kind: z.literal('rule'),
        field: z.string().max(80),
        op: z.enum(OPS as [Operator, ...Operator[]]),
        value: z.union([z.string().max(256), z.number().finite(), z.null()]),
      })
      .strict(),
    z
      .object({
        kind: z.literal('set'),
        field: z.string().max(80),
        op: z.enum(['isAnyOf', 'isNoneOf']),
        values: z.array(z.string().max(256).nullable()).max(SET_FILTER_MAX_VALUES),
      })
      .strict(),
    z
      .object({
        kind: z.literal('group'),
        join: z.enum(['AND', 'OR']),
        children: z.array(nodeSchema).min(2).max(LIMITS.leaves),
      })
      .strict(),
  ]),
);

export const rule = (field: string, op: Operator, value: string | number | null): Node => ({
  kind: 'rule',
  field,
  op,
  value,
});
export function group(join: 'AND' | 'OR', children: Node[]): Node {
  const flat = children.flatMap((n) => (n.kind === 'group' && n.join === join ? n.children : [n]));
  return flat.length === 1 ? flat[0] : { kind: 'group', join, children: flat };
}
export function leaves(n: Node): Exclude<Node, { kind: 'group' }>[] {
  return n.kind !== 'group' ? [n] : n.children.flatMap(leaves);
}
export function canonical(n: Node | null): string {
  if (!n) return 'null';
  if (n.kind === 'rule') return JSON.stringify([n.field, n.op, n.value]);
  if (n.kind === 'set') return JSON.stringify([n.field, n.op, [...n.values].sort()]);
  return JSON.stringify([n.join, n.children.map(canonical).sort()]);
}
export function plainDate(value: string): string {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value) || value.startsWith('0000-'))
    throw new Fault('DATE_FORMAT', 'Use a complete YYYY-MM-DD calendar date.');
  try {
    return Temporal.PlainDate.from(value, { overflow: 'reject' }).toString();
  } catch {
    throw new Fault('INVALID_DATE', `The calendar date ${value} does not exist.`);
  }
}
export function utcTimestamp(value: string): string {
  if (
    !/^\d{4}-\d{2}-\d{2}T(?:[01]\d|2[0-3]):[0-5]\d:[0-5]\d(?:Z|[+-](?:[01]\d|2[0-3]):[0-5]\d)$/i.test(
      value,
    ) ||
    value.startsWith('0000-')
  )
    throw new Fault(
      'TIMESTAMP_ZONE',
      'An exact timestamp needs seconds and Z or an explicit offset, e.g. "2026-10-30T14:00:00Z".',
    );
  try {
    const timestamp = Temporal.Instant.from(value)
      .toString({ smallestUnit: 'second' })
      .replace('T', ' ')
      .replace('Z', '');
    if (!/^\d{4}-\d{2}-\d{2} /.test(timestamp) || timestamp.startsWith('0000-'))
      throw new Error('The normalized year is outside the application calendar range.');
    return timestamp;
  } catch {
    throw new Fault('INVALID_TIMESTAMP', 'The timestamp is invalid.');
  }
}
/** AG models use zone-free UTC wall-clock values; explicit ISO offsets normalize to UTC. */
export function filterTimestamp(value: string): string {
  if (/^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:Z|[+-]\d{2}:\d{2})$/i.test(value))
    return utcTimestamp(value.replace(' ', 'T'));
  const canonical = value.replace('T', ' ');
  if (!/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(canonical))
    throw new Fault(
      'INVALID_TIMESTAMP',
      'Use a complete UTC timestamp with seconds, optionally with Z or an explicit offset. Fractional seconds are not supported.',
    );
  return utcTimestamp(canonical.replace(' ', 'T') + 'Z');
}
export function numericLiteral(value: string, c: ColumnSpec): number {
  if (!/^-?\d+(?:\.\d+)?$/.test(value))
    throw new Fault('INVALID_NUMBER', 'Use a plain decimal number.');
  const trimmed = value
    .replace(/^-/, '')
    .replace(/^0+/, '')
    .replace(/(\.\d*?)0+$/, '$1')
    .replace(/\.$/, '');
  const significant = trimmed.replace('.', '').replace(/^0+/, '').length;
  const decimals = trimmed.split('.')[1]?.length ?? 0;
  if (significant > 15 || (c.scale !== undefined && decimals > c.scale))
    throw new Fault(
      'NUMBER_PRECISION',
      `${c.label} exceeds the supported numeric precision${c.scale === undefined ? '' : ` or ${c.scale}-decimal scale`}. No rounding is performed.`,
    );
  return Number(value);
}
export function dayRange(field: string, date: string, context: Context): Node {
  const d = Temporal.PlainDate.from(plainDate(date));
  // Calendar addition, not +24 hours: preserves 23/25-hour daylight saving days.
  const start = d.toZonedDateTime(context.timeZone).toInstant();
  const end = d.add({ days: 1 }).toZonedDateTime(context.timeZone).toInstant();
  return group('AND', [
    rule(field, 'greaterThanOrEqual', utcTimestamp(start.toString({ smallestUnit: 'second' }))),
    rule(field, 'lessThan', utcTimestamp(end.toString({ smallestUnit: 'second' }))),
  ]);
}

/** Validate depth BEFORE recursive schema validation, including hostile provider objects. */
export function validateNode(input: unknown, columns: readonly ColumnSpec[] = COLUMNS): Node {
  const columnMap = new Map(columns.map((column) => [column.id, column]));
  let count = 0;
  const seen = new Set<object>();
  const walk = (v: unknown, depth: number): void => {
    if (!v || typeof v !== 'object' || Array.isArray(v))
      throw new Fault('INVALID_AST', 'A filter node must be an object.');
    if (seen.has(v))
      throw new Fault('INVALID_AST', 'A filter cannot contain cycles or shared object references.');
    seen.add(v);
    if (depth > LIMITS.depth)
      throw new Fault(
        'TOO_DEEP',
        `At most ${LIMITS.depth} levels of filter nesting are supported.`,
      );
    const obj = v as Record<string, unknown>;
    if (obj['kind'] === 'group' && Array.isArray(obj['children'])) {
      if (obj['children'].length > LIMITS.leaves)
        throw new Fault('TOO_MANY_RULES', 'Too many filter conditions.');
      obj['children'].forEach((c) => walk(c, depth + 1));
    } else if (++count > LIMITS.leaves)
      throw new Fault('TOO_MANY_RULES', `At most ${LIMITS.leaves} predicates are supported.`);
  };
  walk(input, 1);
  const parsed = nodeSchema.safeParse(input);
  if (!parsed.success)
    throw new Fault(
      'INVALID_AST',
      'The provider returned a malformed or unsupported filter structure.',
    );
  const visit = (n: Node): Node => {
    if (n.kind === 'group') return group(n.join, n.children.map(visit));
    const c = columnMap.get(n.field);
    if (!c) throw new Fault('UNKNOWN_COLUMN', `Column ${n.field} is not permitted.`);
    if (n.kind === 'set') {
      const allowed = setFilterValues(c, columns);
      if (!allowed) throw new Fault('SET_COLUMN', `Set Filters are not enabled for ${c.label}.`);
      const values = n.values.map((value) => (value === null ? null : value.toLowerCase()));
      if (values.some((value) => !allowed.includes(value)))
        throw new Fault(
          'UNKNOWN_VALUE',
          `Set values for ${c.label} must come from the server-owned value list.`,
        );
      if (new Set(values).size !== values.length)
        throw new Fault('SET_VALUES', 'A Set Filter cannot contain duplicate values.');
      return { ...n, values };
    }
    if (!operators(c).includes(n.op))
      throw new Fault('UNSUPPORTED_OPERATOR', `${n.op} is not supported for ${c.label}.`);
    if (n.op === 'blank' || n.op === 'notBlank') {
      if (n.value !== null)
        throw new Fault('INVALID_VALUE', 'Blank predicates must have a null operand.');
      return n;
    }
    if (n.value === null)
      throw new Fault('NULL_COMPARISON', 'Use is blank or is not blank for NULL.');
    if (c.kind === 'number') {
      if (typeof n.value !== 'number' || !Number.isFinite(n.value) || Math.abs(n.value) > 1e12)
        throw new Fault(
          'INVALID_NUMBER',
          'A numeric comparison needs a finite number within ±1 trillion.',
        );
      const [mantissa, exponent] = String(n.value).split('e');
      const decimals = Math.max(0, (mantissa.split('.')[1]?.length ?? 0) - Number(exponent ?? 0));
      if (c.scale !== undefined && decimals > c.scale)
        throw new Fault(
          'NUMBER_PRECISION',
          `${c.label} permits at most ${c.scale} decimal places. No rounding is performed.`,
        );
    } else {
      if (typeof n.value !== 'string')
        throw new Fault('INVALID_VALUE', `${c.label} requires a string value.`);
      if (c.kind === 'date') plainDate(n.value);
      if (c.kind === 'datetime') {
        if (!/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(n.value))
          throw new Fault(
            'INVALID_TIMESTAMP',
            'Internal timestamps must be UTC YYYY-MM-DD HH:mm:ss.',
          );
        utcTimestamp(n.value.replace(' ', 'T') + 'Z');
      }
      if (c.kind === 'text') n.value = n.value.toLowerCase();
      if (
        c.values &&
        ['equals', 'notEqual'].includes(n.op) &&
        !c.values.some((value) => value.toLowerCase() === n.value)
      )
        throw new Fault(
          'UNKNOWN_VALUE',
          `${JSON.stringify(n.value)} is not a recognized ${c.label} value.`,
          [`Allowed values: ${c.values.join(', ')}. No approximate value substitutions are made.`],
        );
    }
    return n;
  };
  const node = visit(parsed.data);
  rejectContradictions(node);
  return node;
}

function rejectContradictions(n: Node): void {
  if (n.kind !== 'group') return;
  n.children.forEach(rejectContradictions);
  if (n.join !== 'AND') return;
  const direct = n.children.filter((c): c is Extract<Node, { kind: 'rule' }> => c.kind === 'rule');
  for (const field of new Set(direct.map((r) => r.field))) {
    const rules = direct.filter((r) => r.field === field);
    const equals = rules.filter((r) => r.op === 'equals');
    if (
      new Set(equals.map((r) => r.value)).size > 1 ||
      (rules.some((r) => r.op === 'blank') && rules.some((r) => r.op !== 'blank'))
    )
      throw new Fault(
        'CONTRADICTION',
        `The conditions for ${field} conflict. Check AND versus OR.`,
      );
    if (equals.some((e) => rules.some((r) => !testRule(r, e.value))))
      throw new Fault(
        'CONTRADICTION',
        `The conditions for ${field} cannot match the equality value.`,
      );
    const lows = rules.filter((r) => r.op === 'greaterThan' || r.op === 'greaterThanOrEqual');
    const highs = rules.filter((r) => r.op === 'lessThan' || r.op === 'lessThanOrEqual');
    if (
      lows.some((l) =>
        highs.some(
          (h) =>
            l.value! > h.value! ||
            (l.value === h.value && (l.op === 'greaterThan' || h.op === 'lessThan')),
        ),
      )
    )
      throw new Fault('CONTRADICTION', `The range for ${field} is empty or reversed.`);
  }
}
export function testRule(n: Extract<Node, { kind: 'rule' }>, value: unknown): boolean {
  if (n.op === 'blank') return value === null || value === undefined;
  if (n.op === 'notBlank') return value !== null && value !== undefined;
  if (value === null || value === undefined) return false; // Explicit SQL-like NULL contract, including negatives.
  const a = typeof value === 'string' ? value.toLowerCase() : (value as number);
  const b = typeof n.value === 'string' ? n.value.toLowerCase() : n.value!;
  switch (n.op) {
    case 'equals':
      return a === b;
    case 'notEqual':
      return a !== b;
    case 'contains':
      return String(a).includes(String(b));
    case 'notContains':
      return !String(a).includes(String(b));
    case 'startsWith':
      return String(a).startsWith(String(b));
    case 'endsWith':
      return String(a).endsWith(String(b));
    case 'greaterThan':
      return a > b;
    case 'greaterThanOrEqual':
      return a >= b;
    case 'lessThan':
      return a < b;
    case 'lessThanOrEqual':
      return a <= b;
  }
}
export function evaluate(n: Node | null, row: Record<string, unknown>): boolean {
  if (!n) return true;
  if (n.kind === 'rule') return testRule(n, row[n.field]);
  if (n.kind === 'set') {
    const value = row[n.field];
    const key = value == null ? null : typeof value === 'string' ? value.toLowerCase() : value;
    const matches = n.values.some((candidate) => candidate === key);
    return n.op === 'isAnyOf' ? matches : !matches;
  }
  return n.join === 'AND'
    ? n.children.every((c) => evaluate(c, row))
    : n.children.some((c) => evaluate(c, row));
}
const words: Record<Operator, string> = {
  equals: '=',
  notEqual: '!=',
  contains: 'contains',
  notContains: 'not contains',
  startsWith: 'starts with',
  endsWith: 'ends with',
  greaterThan: '>',
  greaterThanOrEqual: '>=',
  lessThan: '<',
  lessThanOrEqual: '<=',
  blank: 'is blank',
  notBlank: 'is not blank',
};
export function expression(
  n: Node,
  labels = false,
  columns: readonly ColumnSpec[] = COLUMNS,
): string {
  if (n.kind === 'group')
    return '(' + n.children.map((c) => expression(c, labels, columns)).join(` ${n.join} `) + ')';
  const column = columns.find((c) => c.id === n.field);
  if (!column) throw new Fault('UNKNOWN_COLUMN', `Column ${n.field} is not permitted.`);
  const field = labels ? column.label : n.field;
  if (n.kind === 'set')
    return `${field} ${n.op === 'isAnyOf' ? 'is any of' : 'is none of'} ${JSON.stringify(n.values)}`;
  let value = n.value;
  if (column.kind === 'datetime' && typeof value === 'string')
    value = value.replace(' ', 'T') + 'Z';
  return `${field} ${words[n.op]}${value === null ? '' : ' ' + JSON.stringify(value)}`;
}
