import { COLUMNS, type ColumnSpec } from './schema.js';
import { Fault } from './engine.js';

/** Only these server-owned, finite business domains have native Set Filters. */
export const SET_FILTER_COLUMN_IDS = COLUMNS.filter((column) => column.values).map(
  (column) => column.id,
);
export const SET_FILTER_MAX_VALUES = 500;

export function setFilterValues(
  column: Pick<ColumnSpec, 'id' | 'kind'>,
  columns: readonly ColumnSpec[] = COLUMNS,
): (string | null)[] | undefined {
  const trusted = columns.find((item) => item.id === column.id);
  if (!trusted || column.kind !== 'text' || !trusted.values) return undefined;
  const values = [
    ...trusted.values.map((value) => value.toLowerCase()),
    ...(trusted.nullable ? [null] : []),
  ];
  return values.length <= SET_FILTER_MAX_VALUES ? values : undefined;
}

/** Fail closed at every API boundary, including nested state, native models, and internal ASTs. */
export function assertSetFiltersEnabled(value: unknown, enabled: boolean): void {
  if (enabled) return;
  let count = 0;
  const seen = new Set<object>();
  const visit = (item: unknown, depth: number): void => {
    if (!item || typeof item !== 'object') return;
    if (++count > 10_000 || depth > 20 || seen.has(item))
      throw new Fault('INVALID_MODEL', 'The filter structure is too complex.');
    seen.add(item);
    if (!Array.isArray(item)) {
      const obj = item as Record<string, unknown>;
      if (obj['filterType'] === 'set' || obj['kind'] === 'set')
        throw new Fault('SET_FILTERS_DISABLED', 'Set Filters are disabled for this request.');
    }
    Object.values(item).forEach((child) => visit(child, depth + 1));
  };
  visit(value, 0);
}
