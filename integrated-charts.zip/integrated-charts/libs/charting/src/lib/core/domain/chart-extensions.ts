/** Bounded, declarative chart transformations. No SQL, JavaScript or eval is accepted. */
import { z } from 'zod';
import { Fault, plainDate } from './engine.js';
import { chartColumnMetadata, type ChartPlan } from './integrated-chart.js';
import type { ColumnSpec } from './schema.js';

const field = z.string().min(1).max(100);
export const dimensionSchema = z
  .object({
    id: z.string().regex(/^dimension_[A-Za-z0-9_]{1,60}$/),
    label: z.string().trim().min(1).max(100),
    operation: z.enum(['trimLower', 'sign', 'ratioBands', 'weekdayType']),
    columnId: field,
    denominatorColumnId: field.nullable(),
    thresholds: z.array(z.number().finite()).max(12),
    labels: z.array(z.string().min(1).max(100)).max(13),
    blankLabel: z.string().min(1).max(100),
  })
  .strict();
export type ChartDimension = z.infer<typeof dimensionSchema>;
export const windowSchema = z
  .object({
    id: z.string().regex(/^metric_[A-Za-z0-9_]{1,60}$/),
    label: z.string().trim().min(1).max(100),
    operation: z.enum(['cumulative', 'movingAverage', 'percentChange', 'rollingRatio']),
    sourceMetricId: field,
    denominatorMetricId: field.nullable(),
    size: z.number().int().min(1).max(200),
  })
  .strict();
export type ChartWindow = z.infer<typeof windowSchema>;
export const snapshotSchema = z
  .object({
    startColumnId: field,
    endColumnId: field,
    cutoffs: z
      .array(z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/))
      .min(1)
      .max(200),
  })
  .strict();
export type ChartSnapshot = z.infer<typeof snapshotSchema>;

export function compareChartValues(a: string | number | null, b: string | number | null): number {
  if (a === b) return 0;
  if (a === null) return 1;
  if (b === null) return -1;
  if (typeof a === 'number' && typeof b === 'number') return a - b;
  // Unicode code-point collation is deterministic across server/browser locales.
  const aa = Array.from(String(a)),
    bb = Array.from(String(b));
  for (let i = 0; i < Math.min(aa.length, bb.length); i++) {
    const d = aa[i].codePointAt(0)! - bb[i].codePointAt(0)!;
    if (d) return d;
  }
  return aa.length - bb.length;
}

export function dimensionColumns(plan: ChartPlan, columns: readonly ColumnSpec[]): ColumnSpec[] {
  const result = [...columns];
  const metadata = new Map(chartColumnMetadata(columns).map((c) => [c.id, c]));
  for (const d of plan.analytics?.dimensions ?? []) {
    const source = metadata.get(d.columnId);
    if (!source || result.some((c) => c.id === d.id))
      throw new Fault(
        'CHART_DIMENSION',
        'Derived dimensions require unique IDs and approved source fields.',
      );
    const numeric = source.kind === 'number' && source.role !== 'identifier';
    if (
      (d.operation === 'trimLower' && source.kind !== 'text') ||
      (['sign', 'ratioBands'].includes(d.operation) && !numeric) ||
      (d.operation === 'weekdayType' && source.role !== 'temporal')
    )
      throw new Fault(
        'CHART_DIMENSION',
        'The derived grouping operation is incompatible with its source field.',
      );
    const expectedLabels =
      d.operation === 'sign'
        ? 3
        : d.operation === 'weekdayType'
          ? 2
          : d.operation === 'ratioBands'
            ? d.thresholds.length + 1
            : 0;
    if (
      d.labels.length !== expectedLabels ||
      new Set(d.labels).size !== d.labels.length ||
      (d.operation !== 'ratioBands' &&
        (d.denominatorColumnId !== null || d.thresholds.length !== 0)) ||
      (d.operation === 'ratioBands' &&
        (!d.thresholds.length ||
          metadata.get(d.denominatorColumnId!)?.role !== 'measure' ||
          d.thresholds.some((v, i) => i > 0 && v <= d.thresholds[i - 1])))
    )
      throw new Fault(
        'CHART_DIMENSION',
        'Supply the exact labels and strictly increasing boundaries for this grouping operation.',
      );
    result.push({
      id: d.id,
      label: d.label,
      kind: 'text',
      aliases: [],
      nullable: false,
      sql: '',
      description: `Read-only ${d.operation} grouping`,
      chartRole: 'dimension',
    });
  }
  return result;
}

type Row = Readonly<Record<string, string | number | null>>;
const finite = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);
export function dimensionRows(plan: ChartPlan, rows: readonly Row[]): readonly Row[] {
  const definitions = plan.analytics?.dimensions ?? [];
  if (!definitions.length) return rows;
  return rows.map((row) => {
    const out = { ...row };
    for (const d of definitions) {
      const value = row[d.columnId];
      let result = d.blankLabel;
      if (d.operation === 'trimLower')
        result = value == null ? d.blankLabel : String(value).trim().toLowerCase() || d.blankLabel;
      else if (d.operation === 'sign' && finite(value))
        result = d.labels[value > 0 ? 0 : value === 0 ? 1 : 2];
      else if (d.operation === 'ratioBands' && finite(value)) {
        const divisor = row[d.denominatorColumnId!];
        if (finite(divisor) && divisor > 0) {
          const index = d.thresholds.findIndex((t) => value / divisor <= t);
          result = d.labels[index < 0 ? d.thresholds.length : index];
        }
      } else if (d.operation === 'weekdayType' && value != null) {
        const text = String(value).replace(' ', 'T');
        const at = Date.parse(
          text.length === 10
            ? text + 'T00:00:00Z'
            : /Z$|[+-]\d\d:\d\d$/.test(text)
              ? text
              : text + 'Z',
        );
        if (!Number.isFinite(at))
          throw new Fault('CHART_DATE', 'A weekday grouping contains an invalid timestamp.');
        result = d.labels[[0, 6].includes(new Date(at).getUTCDay()) ? 1 : 0];
      }
      out[d.id] = result;
    }
    return out;
  });
}

/** Most buckets a time axis may complete: twelve hours of six-second slices or five days of minutes. */
export const CHART_MAX_TIME_BUCKETS = 7200;
const FIXED_WIDTH_UNITS: Partial<Record<NonNullable<ChartPlan['timeBucket']>, number>> = {
  second: 1_000,
  minute: 60_000,
  hour: 3_600_000,
};

/** A calendar date or a UTC timestamp bound (`YYYY-MM-DD`, optionally `[T ]HH:mm:ss`). */
function timeBound(text: string): number {
  // Complete a bounded calendar domain below. Never infer a missing period as an observed zero.
  const day = plainDate(text.slice(0, 10));
  const clock = text.slice(10).replace(/^[T ]/, '') || '00:00:00';
  const at = Date.parse(`${day}T${clock}Z`);
  if (!/^\d{2}:\d{2}:\d{2}$/.test(clock) || !Number.isFinite(at))
    throw new Fault('CHART_TIME_RANGE', 'A time range bound must be a date or a UTC timestamp.');
  return at;
}
export function timeDomain(
  plan: ChartPlan,
  bucket: (v: string, b: ChartPlan['timeBucket']) => string | number | null,
): (string | number)[] {
  if (!plan.timeRange?.start || !plan.timeRange.endExclusive) return [];
  const start = timeBound(plan.timeRange.start),
    end = timeBound(plan.timeRange.endExclusive);
  if (start >= end || !plan.timeBucket)
    throw new Fault(
      'CHART_TIME_RANGE',
      'A calendar range must be increasing and have a time bucket.',
    );
  const size = Math.max(1, Math.floor(plan.bucketSize ?? 1));
  const d = new Date(start);
  // Bound the number of buckets, including a partially overlapping first bucket.
  const unit = FIXED_WIDTH_UNITS[plan.timeBucket];
  if (unit) {
    const width = size * unit;
    d.setTime(Math.floor(start / width) * width);
  } else {
    d.setUTCHours(0, 0, 0, 0);
    if (plan.timeBucket === 'month') d.setUTCDate(1);
    if (plan.timeBucket === 'quarter') {
      d.setUTCDate(1);
      d.setUTCMonth(Math.floor(d.getUTCMonth() / 3) * 3);
    }
    if (plan.timeBucket === 'year') {
      d.setUTCDate(1);
      d.setUTCMonth(0);
    }
  }
  const result: (string | number)[] = [];
  while (d.getTime() < end) {
    if (result.length >= CHART_MAX_TIME_BUCKETS)
      throw new Fault(
        'CHART_TIME_RANGE',
        `The requested time domain exceeds ${CHART_MAX_TIME_BUCKETS.toLocaleString('en-US')} buckets. Use a coarser bucket or a narrower window.`,
      );
    result.push(bucket(d.toISOString(), plan.timeBucket)!);
    if (unit) d.setTime(d.getTime() + size * unit);
    else if (plan.timeBucket === 'day') d.setUTCDate(d.getUTCDate() + 1);
    else
      d.setUTCMonth(
        d.getUTCMonth() +
          (plan.timeBucket === 'month' ? 1 : plan.timeBucket === 'quarter' ? 3 : 12),
      );
  }
  return result;
}

/** JSON-schema fragments use field references, never free-form executable expressions. */
export function extensionJsonSchemas(fields: string[]) {
  const f = { type: 'string', enum: fields };
  const nullableField = { anyOf: [f, { type: 'null' }] };
  const computed = { type: 'string', pattern: '^metric_[A-Za-z0-9_]{1,60}$' };
  const number = { type: 'number' };
  const text = { type: 'string', minLength: 1, maxLength: 100 };
  const obj = (properties: Record<string, unknown>) => ({
    type: 'object',
    additionalProperties: false,
    properties,
    required: Object.keys(properties),
  });
  return {
    dimensions: {
      type: ['array', 'null'],
      maxItems: 4,
      items: obj({
        id: { type: 'string', pattern: '^dimension_[A-Za-z0-9_]{1,60}$' },
        label: text,
        operation: { type: 'string', enum: ['trimLower', 'sign', 'ratioBands', 'weekdayType'] },
        columnId: f,
        denominatorColumnId: nullableField,
        thresholds: { type: 'array', maxItems: 12, items: number },
        labels: { type: 'array', maxItems: 13, items: text },
        blankLabel: text,
      }),
    },
    windows: {
      type: ['array', 'null'],
      maxItems: 4,
      items: obj({
        id: computed,
        label: text,
        operation: {
          type: 'string',
          enum: ['cumulative', 'movingAverage', 'percentChange', 'rollingRatio'],
        },
        sourceMetricId: computed,
        denominatorMetricId: { anyOf: [computed, { type: 'null' }] },
        size: { type: 'integer', minimum: 1, maximum: 200 },
      }),
    },
    snapshot: {
      anyOf: [
        { type: 'null' },
        obj({
          startColumnId: f,
          endColumnId: f,
          cutoffs: { type: 'array', minItems: 1, maxItems: 200, items: { type: 'string' } },
        }),
      ],
    },
  };
}
