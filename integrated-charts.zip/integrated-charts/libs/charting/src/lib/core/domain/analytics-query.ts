import type { GridModel, Mode } from './contracts.js';

export const ANALYTICS_AGG_FUNCS = ['sum', 'avg', 'min', 'max', 'count', 'first', 'last'] as const;
export type AnalyticsAggFunc = (typeof ANALYTICS_AGG_FUNCS)[number];
export const ANALYTICS_LIMITS = { groups: 3, pivots: 2, values: 8, pivotFields: 200 } as const;
export const PIVOT_FIELD_SEPARATOR = '|';
export const BLANK_GROUP_KEY = '(Blanks)';

export interface AnalyticsColumn {
  id: string;
  field?: string;
  displayName?: string;
  aggFunc?: string | null;
}

export interface AnalyticsRowsRequest {
  mode: Mode;
  calculatedColumnIds?: string[];
  request: {
    startRow: number;
    endRow: number;
    filterModel: GridModel;
    // Non-pivot source-field sorts apply to account leaves. Group routes apply
    // only the current group key / aggregate sorts and otherwise use group-key order.
    sortModel: { colId: string; sort: 'asc' | 'desc' }[];
    rowGroupCols: AnalyticsColumn[];
    valueCols: AnalyticsColumn[];
    pivotCols: AnalyticsColumn[];
    pivotMode: boolean;
    // AG Grid preserves numeric group values in its runtime route.
    groupKeys: (string | number | null)[];
  };
}

export interface AnalyticsRowsResponse {
  rowData: Record<string, string | number | null>[];
  rowCount: number;
  pivotResultFields?: string[];
  grandTotalData?: Record<string, string | number | null>;
}

/** SSRM requires a non-null key to expand a group. Escape sentinel collisions. */
export function analyticsGroupKey(value: string | number | null): string | number {
  if (value === null) return BLANK_GROUP_KEY;
  if (typeof value === 'string' && (value === BLANK_GROUP_KEY || value.startsWith('\\')))
    return '\\' + value;
  return value;
}

export function groupKeyLabel(value: string | number | null | undefined): string {
  if (value == null) return BLANK_GROUP_KEY;
  return typeof value === 'string' && value.startsWith('\\') ? value.slice(1) : String(value);
}

/** A separator-safe pivot segment; encoded literal blank labels stay distinct from NULL. */
export function analyticsPivotKey(value: string | number | null): string {
  if (value === null) return BLANK_GROUP_KEY;
  const encoded = encodeURIComponent(String(value));
  return encoded === BLANK_GROUP_KEY ? '%28Blanks%29' : encoded;
}

export function pivotKeyLabel(value: string): string {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}
