/** Column-panel grouping is trusted display metadata, never an analytics row group. */
export const MAX_COLUMN_GROUP_TAG_LENGTH = 80;

/** A column belongs to one named group, or has no tag and stays ungrouped. */
export function isColumnGroupTag(value: unknown): value is string {
  return (
    typeof value === 'string' &&
    value.length > 0 &&
    value.length <= MAX_COLUMN_GROUP_TAG_LENGTH &&
    value === value.trim() &&
    !/[\u0000-\u001f\u007f]/.test(value)
  );
}
