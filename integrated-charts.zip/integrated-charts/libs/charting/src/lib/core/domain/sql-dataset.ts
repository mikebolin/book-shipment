import { COLUMNS, validateSchema, type ColumnSpec } from './schema.js';
import { Fault } from './engine.js';

/** Trusted application configuration. Never accept this mapping from a query request or model. */
export interface SqlDataset {
  columns: readonly ColumnSpec[];
  /** Separate database/schema/table components; dots inside a component are literal. */
  table: readonly string[];
  tenantColumn: string;
  /** Non-null unique source key used to make pagination deterministic. */
  rowIdColumn: string;
}

export const UNCONFIGURED_SQL_DATASET: SqlDataset = {
  columns: COLUMNS,
  table: [],
  tenantColumn: 'TENANT_ID',
  rowIdColumn: '',
};

export function quoteSqlIdentifier(identifier: string): string {
  if (
    typeof identifier !== 'string' ||
    !identifier.length ||
    identifier.length > 255 ||
    /[\u0000-\u001f\u007f]/.test(identifier)
  )
    throw new Fault('SQL_DATASET', 'Invalid SQL identifier in the trusted dataset configuration.');
  return '"' + identifier.replaceAll('"', '""') + '"';
}

export function validateSqlDataset(dataset: SqlDataset): void {
  validateSchema(dataset.columns);
  if (
    !dataset.columns.length ||
    !Array.isArray(dataset.table) ||
    dataset.table.length < 1 ||
    dataset.table.length > 3
  )
    throw new Fault(
      'SQL_DATASET',
      'A dataset needs columns and a table with up to three name components.',
    );
  dataset.table.forEach(quoteSqlIdentifier);
  quoteSqlIdentifier(dataset.tenantColumn);
  const key = dataset.columns.find((column) => column.id === dataset.rowIdColumn);
  if (
    !key ||
    key.nullable ||
    !['text', 'number'].includes(key.kind) ||
    dataset.columns.some((column) => column.sql === dataset.tenantColumn)
  )
    throw new Fault(
      'SQL_DATASET',
      'Configure a non-null row key and keep the tenant column outside the public schema.',
    );
}
