/** Saved SSRM policy. Limits keep requests within the compiler's 500-row page contract. */
export interface ServerGridSettings {
  cacheBlockSize: number;
  maxBlocksInCache: number;
  maxConcurrentRequests: number;
  blockLoadDebounceMillis: number;
}

export const SERVER_GRID_DEFAULTS: Readonly<ServerGridSettings> = Object.freeze({
  cacheBlockSize: 250,
  maxBlocksInCache: 3,
  maxConcurrentRequests: 2,
  blockLoadDebounceMillis: 80,
});

export const SERVER_GRID_LIMITS = Object.freeze({
  cacheBlockSize: { min: 25, max: 500 },
  maxBlocksInCache: { min: 1, max: 100 },
  maxConcurrentRequests: { min: 1, max: 4 },
  blockLoadDebounceMillis: { min: 0, max: 2000 },
});

/** Older views inherit defaults; invalid supplied values fail before a grid is mounted. */
export function normalizeServerGridSettings(
  settings?: Partial<ServerGridSettings> | null,
): ServerGridSettings {
  if (settings != null && (typeof settings !== 'object' || Array.isArray(settings)))
    throw new Error('Grid loading settings must be an object.');
  const normalized = { ...SERVER_GRID_DEFAULTS };
  for (const key of Object.keys(SERVER_GRID_DEFAULTS) as (keyof ServerGridSettings)[]) {
    const value = settings?.[key] === undefined ? SERVER_GRID_DEFAULTS[key] : settings[key];
    const limits = SERVER_GRID_LIMITS[key];
    if (!Number.isInteger(value) || value < limits.min || value > limits.max)
      throw new Error(`${key} must be a whole number between ${limits.min} and ${limits.max}.`);
    normalized[key] = value;
  }
  return normalized;
}
