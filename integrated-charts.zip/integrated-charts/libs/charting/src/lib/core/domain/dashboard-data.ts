import { z } from 'zod';
import { CALCULATION_LIMITS } from './calculated-columns.js';
import type { Account } from './contracts.js';
import {
  DASHBOARD_DEFAULT_PERIOD,
  DASHBOARD_PERIODS,
  DASHBOARD_TEMPLATES,
  type DashboardChart,
  type DashboardMetric,
  type DashboardRequest,
  type DashboardResponse,
} from './dashboard.js';

export const dashboardRequestSchema = z
  .object({
    template: z.enum(DASHBOARD_TEMPLATES),
    mode: z.enum(['advanced', 'columns']),
    filterModel: z.record(z.unknown()).nullable(),
    calculatedColumnIds: z
      .array(z.string().regex(/^calc_[A-Za-z0-9_-]{1,70}$/))
      .max(CALCULATION_LIMITS.columns)
      .optional(),
    period: z
      .string()
      .length(6)
      .refine(
        (period) => DASHBOARD_PERIODS.includes(period),
        'Choose an available calendar quarter.',
      )
      .optional(),
  })
  .strict()
  .superRefine((request, ctx) => {
    const ids = request.calculatedColumnIds ?? [];
    if (new Set(ids).size !== ids.length)
      ctx.addIssue({ code: 'custom', message: 'Calculated column IDs must be unique.' });
    if (request.template !== 'financial' && request.period !== undefined)
      ctx.addIssue({ code: 'custom', message: 'Only the financial dashboard accepts a quarter.' });
  });

const finite = (value: unknown): value is number =>
  typeof value === 'number' && Number.isFinite(value);
function total(rows: readonly Account[], field: string): number | null {
  const values = rows.map((row) => row[field]).filter(finite);
  if (!values.length) return null;
  const sum = values.reduce((result, value) => result + value, 0);
  return Number.isFinite(sum) ? sum : null;
}
function mean(rows: readonly Account[], field: string): number | null {
  const count = rows.filter((row) => finite(row[field])).length;
  const sum = total(rows, field);
  return sum === null || !count ? null : sum / count;
}
const number = (value: number) => value.toLocaleString('en-US');
const money = (value: number) =>
  value.toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 2 });
const quarterLabel = (period: string) => period.slice(0, 4) + ' ' + period.slice(4);
const metric = (
  id: string,
  label: string,
  value: number | null,
  format: DashboardMetric['format'],
): DashboardMetric => ({ id, label, value, format });

function grouped(rows: readonly Account[], field: string): [string, Account[]][] {
  const groups = new Map<string | null, Account[]>();
  for (const row of rows) {
    const value = row[field] === null ? null : String(row[field]);
    const bucket = groups.get(value);
    if (bucket) bucket.push(row);
    else groups.set(value, [row]);
  }
  return [...groups]
    .sort(([left], [right]) =>
      left === right ? 0 : left === null ? 1 : right === null ? -1 : left.localeCompare(right),
    )
    .map(([key, bucket]) => [key === null ? '(Blank)' : key, bucket]);
}

function portfolio(
  rows: Account[],
): Pick<DashboardResponse, 'title' | 'subtitle' | 'metrics' | 'charts' | 'observations' | 'notes'> {
  const byStatus = grouped(rows, 'status');
  const missingBalance = rows.filter((row) => !finite(row.balance)).length;
  const balance = total(rows, 'balance');
  const observations: string[] = [];
  if (rows.length) {
    const largest = [...byStatus].sort(
      (a, b) => b[1].length - a[1].length || a[0].localeCompare(b[0]),
    )[0];
    observations.push(
      `${largest[0]} is the largest status group with ${number(largest[1].length)} matching accounts.`,
    );
    if (balance !== null)
      observations.push(
        `Matching accounts have ${money(balance)} in recorded balances across ${number(rows.length - missingBalance)} nonblank values.`,
      );
    if (missingBalance)
      observations.push(
        `${number(missingBalance)} matching accounts have no recorded balance; these are excluded from balance totals and averages.`,
      );
  }
  return {
    title: 'Portfolio balances',
    subtitle: 'Account counts and recorded USD balances across the entire filtered sample.',
    metrics: [
      metric('accounts', 'Matching accounts', rows.length, 'number'),
      metric('balance', 'Total recorded balance', balance, 'currency'),
      metric('averageBalance', 'Average recorded balance', mean(rows, 'balance'), 'currency'),
      metric('missingBalance', 'Accounts with blank balance', missingBalance, 'number'),
    ],
    charts: [
      {
        id: 'status-count',
        title: 'Accounts by status',
        kind: 'bar',
        categories: byStatus.map(([label]) => label),
        series: [
          {
            id: 'accounts',
            label: 'Accounts',
            format: 'number',
            values: byStatus.map(([, values]) => values.length),
          },
        ],
      },
      {
        id: 'status-balance',
        title: 'Recorded balance by status',
        kind: 'bar',
        categories: byStatus.map(([label]) => label),
        series: [
          {
            id: 'balance',
            label: 'Recorded balance',
            format: 'currency',
            values: byStatus.map(([, values]) => total(values, 'balance')),
          },
        ],
      },
    ],
    observations,
    notes: [
      'Account balances and statuses are synthetic demonstration data.',
      'Blank numeric values are excluded from sums and averages; blank statuses remain a separate group.',
    ],
  };
}

function financial(
  rows: Account[],
  period: string,
): Pick<
  DashboardResponse,
  'title' | 'subtitle' | 'period' | 'metrics' | 'charts' | 'observations' | 'notes'
> {
  const periodIndex = DASHBOARD_PERIODS.indexOf(period);
  const periods = DASHBOARD_PERIODS.slice(Math.max(0, periodIndex - 3), periodIndex + 1);
  const measures = [
    { id: 'revenue', label: 'Revenue' },
    { id: 'netIncome', label: 'Net income' },
    { id: 'operatingCashFlow', label: 'Operating cash flow' },
    { id: 'cash', label: 'Cash' },
  ];
  const field = (id: string, quarter: string) => `${id}_${quarter.slice(0, 4)}_${quarter.slice(4)}`;
  const metrics = measures.map(({ id, label }) =>
    metric(id, `${label} ${quarterLabel(period)}`, total(rows, field(id, period)), 'currency'),
  );
  const revenueCount = rows.filter((row) => finite(row[field('revenue', period)])).length;
  return {
    title: 'Quarterly financial performance',
    subtitle: `Explicit sums of synthetic financial fields for ${quarterLabel(period)} across matching accounts.`,
    period,
    metrics,
    charts: [
      {
        id: 'financial-quarter',
        title: `Recorded financial measures · ${quarterLabel(period)}`,
        kind: 'bar',
        categories: rows.length ? measures.map(({ label }) => label) : [],
        series: [
          {
            id: 'quarter-total',
            label: 'Recorded sum',
            format: 'currency',
            values: rows.length ? metrics.map((item) => item.value) : [],
          },
        ],
      },
      {
        id: 'financial-trend',
        title: 'Recorded sums by calendar quarter',
        kind: 'line',
        categories: rows.length ? periods.map(quarterLabel) : [],
        series: measures.slice(0, 3).map(({ id, label }) => ({
          id,
          label,
          format: 'currency',
          values: rows.length ? periods.map((quarter) => total(rows, field(id, quarter))) : [],
        })),
      },
    ],
    observations: rows.length
      ? [
          `${quarterLabel(period)} totals include all ${number(rows.length)} matching accounts, with blanks excluded separately for each measure.`,
          `${number(revenueCount)} accounts have a recorded revenue value for this quarter; ${number(rows.length - revenueCount)} are blank.`,
        ]
      : [],
    notes: [
      'Quarter labels refer to the selected financial field, not the account creation or business date.',
      'These synthetic metrics are independent demonstration values, not reported financial statements. They do not establish accounting identities, margins, or cash-flow relationships.',
      'The trend compares explicit sums from up to four available calendar-quarter fields ending at the selected quarter.',
    ],
  };
}

function market(
  rows: Account[],
): Pick<DashboardResponse, 'title' | 'subtitle' | 'metrics' | 'charts' | 'observations' | 'notes'> {
  const unique = new Map<string, Account>();
  for (const row of rows) unique.set(JSON.stringify([row.symbol, row.marketDate]), row);
  const observations = [...unique.values()].sort(
    (a, b) =>
      String(a.marketDate).localeCompare(String(b.marketDate)) ||
      String(a.symbol).localeCompare(String(b.symbol)),
  );
  const symbols = [...new Set(observations.map((row) => String(row.symbol)))].sort();
  const dates = [...new Set(observations.map((row) => String(row.marketDate)))].sort();
  const first = observations[0];
  const last = observations.at(-1);
  const firstPrice = first?.closePrice;
  const lastPrice = last?.closePrice;
  // The shipped fixture has one symbol. Cross-symbol prices are never combined into a return.
  const change =
    symbols.length === 1 && finite(firstPrice) && firstPrice !== 0 && finite(lastPrice)
      ? ((lastPrice - firstPrice) / firstPrice) * 100
      : null;
  const chart = (
    id: 'closePrice' | 'volume',
    title: string,
    kind: DashboardChart['kind'],
  ): DashboardChart => ({
    id,
    title,
    kind,
    categories: dates,
    series: symbols.map((symbol) => ({
      id: `${symbol}-${id}`,
      label: `${symbol} ${id === 'closePrice' ? 'close' : 'volume'}`,
      format: id === 'closePrice' ? 'currency' : 'number',
      values: dates.map((date) => {
        const value = unique.get(JSON.stringify([symbol, date]))?.[id];
        return finite(value) ? value : null;
      }),
    })),
  });
  return {
    title: 'Historical market observations',
    subtitle:
      first && last
        ? `${symbols.join(', ')} · ${first.marketDate} to ${last.marketDate} · deduplicated historical observations.`
        : 'Historical prices and volume for market observations represented by the filtered accounts.',
    metrics: [
      metric('observations', 'Unique market observations', observations.length, 'number'),
      metric(
        'latestClose',
        symbols.length === 1 ? `Latest ${symbols[0]} close` : 'Latest close',
        symbols.length === 1 && finite(lastPrice) ? lastPrice : null,
        'currency',
      ),
      metric(
        'closeChange',
        'First-to-last close change',
        finite(change) ? change : null,
        'percent',
      ),
      metric('volume', 'Deduplicated traded volume', total(observations, 'volume'), 'number'),
    ],
    charts: [
      chart('closePrice', 'Historical closing price', 'line'),
      chart('volume', 'Historical traded volume', 'bar'),
    ],
    observations:
      first && last
        ? [
            `${number(rows.length)} matching accounts represent ${number(observations.length)} unique symbol/date observations from ${first.marketDate} through ${last.marketDate}.`,
            'Each symbol and trading date contributes volume once, even when it appears on multiple matching accounts.',
          ]
        : [],
    notes: [
      'Historical Apple market observations come from the static 2015–2017 fixture; they are not current quotes.',
      'Filtering accounts selects the market observations represented by those accounts. Repeated symbol/date observations are deduplicated before charts and metrics.',
      'Close change compares the first and last observed closing prices; it is not a total return.',
    ],
  };
}

/** Pure dashboard processing over the complete, already-filtered browser or server cohort. */
export function buildDashboardDataset(input: DashboardRequest, rows: Account[]): DashboardResponse {
  const request = dashboardRequestSchema.parse(input);
  const result =
    request.template === 'portfolio'
      ? portfolio(rows)
      : request.template === 'financial'
        ? financial(rows, request.period ?? DASHBOARD_DEFAULT_PERIOD)
        : market(rows);

  return {
    template: request.template,
    source: 'mock',
    scope: 'filtered-source-rows',
    matchedAccountCount: rows.length,
    ...result,
    observations: rows.length
      ? result.observations
      : [
          'No accounts match the applied filter. Clear or adjust the filter to analyze this dataset.',
        ],
  };
}
