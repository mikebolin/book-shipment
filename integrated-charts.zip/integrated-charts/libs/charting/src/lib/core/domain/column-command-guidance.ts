import type { GridCopilotResult, GridFeature } from './grid-copilot.js';
import type { ValidGridState } from './grid-state.js';
import type { ColumnSpec } from './schema.js';

type Slot = { text: string; start: number; end: number; numeric: boolean };
type Command = {
  feature: Exclude<GridFeature, 'filter'>;
  slots: Slot[];
  directions?: ('asc' | 'desc')[];
  aggregation?: 'sum' | 'avg' | 'min' | 'max' | 'count' | 'first' | 'last';
};
const key = (value: string) =>
  value
    .normalize('NFKC')
    .replace(/^\[|\]$/g, '')
    .toLowerCase()
    .replace(/[\s_-]+/g, '');
const aliases = (column: ColumnSpec) => [column.id, column.label, ...column.aliases].map(key);

/** Only structural column slots are examined. Filter literals and arbitrary prose are never corrected. */
function commands(text: string): Command[] | null {
  // This shortcut only handles a complete grid-column command. A sentence
  // asking for a chart needs the full planner to choose its category and metric.
  if (/\b(?:chart|plot|graph|dashboard)\b/i.test(text)) return null;
  const result: Command[] = [];
  // Split at explicit command boundaries while retaining offsets for exact replacements.
  const parts = text.split(
    /\s*;\s*|\s*,?\s+and\s+(?=(?:sort|order|group|pivot)\s+by\b|(?:sum|avg|average|min|max|count|first|last)\s+)/i,
  );
  let offset = 0;
  for (const part of parts) {
    const start = text.indexOf(part, offset);
    offset = start + part.length;
    const match =
      /^\s*(?:please\s+)?(?:(group|pivot|sort|order)\s+by\s+|(sum|avg|average|min|max|count|first|last)\s+)(.+?)\s*[.!]?\s*$/i.exec(
        part,
      );
    if (!match) return null;
    const action = (match[1] ?? match[2]).toLowerCase();
    const feature =
      action === 'group'
        ? 'rowGroup'
        : action === 'pivot'
          ? 'pivot'
          : ['sort', 'order'].includes(action)
            ? 'sort'
            : 'aggregation';
    const body = match[3];
    const bodyStart = start + part.indexOf(body, match.index + match[0].indexOf(action));
    const pieces = feature === 'aggregation' ? [body] : body.split(/\s*,\s*|\s+then\s+|\s+and\s+/i);
    const slots: Slot[] = [];
    const directions: ('asc' | 'desc')[] = [];
    let pieceOffset = 0;
    for (const piece of pieces) {
      const pieceStart = body.indexOf(piece, pieceOffset);
      pieceOffset = pieceStart + piece.length;
      const sort =
        feature === 'sort' ? /^(.+?)\s+(ascending|descending|asc|desc)$/i.exec(piece) : null;
      if (feature === 'sort' && !sort) return null;
      const name = (sort?.[1] ?? piece).trim();
      if (!name || name.length > 120 || /["'=<>();]/.test(name)) return null;
      const nameStart = bodyStart + pieceStart + piece.indexOf(name);
      slots.push({
        text: name,
        start: nameStart,
        end: nameStart + name.length,
        numeric: feature === 'aggregation',
      });
      if (sort) directions.push(/^desc/i.test(sort[2]) ? 'desc' : 'asc');
    }
    result.push({
      feature,
      slots,
      directions,
      ...(feature === 'aggregation'
        ? { aggregation: (action === 'average' ? 'avg' : action) as Command['aggregation'] }
        : {}),
    });
  }
  return result.length ? result : null;
}

function distance(a: string, b: string): number {
  const rows = Array.from({ length: a.length + 1 }, () => new Array<number>(b.length + 1).fill(0));
  for (let i = 0; i <= a.length; i++) rows[i][0] = i;
  for (let j = 0; j <= b.length; j++) rows[0][j] = j;
  for (let i = 1; i <= a.length; i++)
    for (let j = 1; j <= b.length; j++) {
      rows[i][j] = Math.min(
        rows[i - 1][j] + 1,
        rows[i][j - 1] + 1,
        rows[i - 1][j - 1] + Number(a[i - 1] !== b[j - 1]),
      );
      if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1])
        rows[i][j] = Math.min(rows[i][j], rows[i - 2][j - 2] + 1);
    }
  return rows[a.length][b.length];
}

export function clarifyColumnCommand(
  text: string,
  columns: readonly ColumnSpec[],
): Extract<GridCopilotResult, { status: 'needs_input' }> | null {
  const parsed = commands(text);
  if (!parsed) return null;
  for (const command of parsed)
    for (const slot of command.slots) {
      const available = columns.filter((column) => !slot.numeric || column.kind === 'number');
      const normalized = key(slot.text);
      const exact = available.filter((column) => aliases(column).includes(normalized));
      if (exact.length === 1) continue;
      const candidates = exact.length
        ? exact
        : available
            .map((column) => ({
              column,
              distance: Math.min(
                ...aliases(column).map((alias) => {
                  if (
                    normalized.length < 4 ||
                    normalized.match(/\d+/g)?.join() !== alias.match(/\d+/g)?.join()
                  )
                    return Infinity;
                  return distance(normalized, alias);
                }),
              ),
            }))
            .filter((candidate) => candidate.distance <= (normalized.length >= 8 ? 2 : 1))
            .sort((a, b) => a.distance - b.distance || a.column.label.localeCompare(b.column.label))
            .slice(0, 6)
            .map((candidate) => candidate.column);
      if (!candidates.length) return null;
      return {
        status: 'needs_input',
        reason: 'clarification',
        clarificationKind: 'column',
        message:
          candidates.length === 1
            ? `Did you mean ${candidates[0].label}? Choose the column to continue; your current filters stay in place.`
            : `Which column did you mean by “${slot.text}”? Your current filters stay in place.`,
        options: candidates.map((column) => ({
          label: column.label,
          answer: text.slice(0, slot.start) + column.id + text.slice(slot.end),
        })),
      };
    }
  return null;
}

/** Fully consumed, exact structural commands can be applied without sending any data to a model. */
export function resolveColumnCommands(
  text: string,
  columns: readonly ColumnSpec[],
): Partial<Pick<ValidGridState, 'rowGroup' | 'sort' | 'pivot' | 'aggregation'>> | null {
  const parsed = commands(text);
  if (!parsed) return null;
  const patch: Partial<Pick<ValidGridState, 'rowGroup' | 'sort' | 'pivot' | 'aggregation'>> = {};
  for (const command of parsed) {
    const ids: string[] = [];
    for (const slot of command.slots) {
      const matches = columns.filter(
        (column) =>
          (!slot.numeric || column.kind === 'number') && aliases(column).includes(key(slot.text)),
      );
      if (matches.length !== 1) return null;
      ids.push(matches[0].id);
    }
    if (command.feature !== 'aggregation' && patch[command.feature]) return null;
    if (command.feature === 'rowGroup') patch.rowGroup = { groupColIds: ids };
    else if (command.feature === 'pivot') patch.pivot = { pivotMode: true, pivotColIds: ids };
    else if (command.feature === 'sort')
      patch.sort = {
        sortModel: ids.map((colId, index) => ({ colId, sort: command.directions![index] })),
      };
    else
      (patch.aggregation ??= { aggregationModel: [] }).aggregationModel.push({
        colId: ids[0],
        aggFunc: command.aggregation!,
      });
  }
  return patch;
}
