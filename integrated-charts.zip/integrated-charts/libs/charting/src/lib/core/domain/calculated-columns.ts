import { COLUMNS, COLUMN_MAP, type ColumnSpec } from './schema.js';
import { Fault } from './engine.js';

export type CalculationExpression =
  | { kind: 'field'; field: string }
  | { kind: 'number'; value: number }
  | {
      kind: 'binary';
      operator: 'add' | 'subtract' | 'multiply' | 'divide';
      left: CalculationExpression;
      right: CalculationExpression;
    };

export interface CalculationDraft {
  label: string;
  expression: CalculationExpression;
}

export interface CalculatedColumnDefinition extends CalculationDraft {
  id: string;
}

export const CALCULATION_LIMITS = {
  columns: 8,
  label: 80,
  depth: 5,
  nodes: 31,
  constant: 1e12,
} as const;

const operators = ['add', 'subtract', 'multiply', 'divide'] as const;
const normalize = (text: string) =>
  text.normalize('NFKC').trim().replace(/\s+/g, ' ').toLowerCase();

function object(value: unknown, keys: readonly string[]): Record<string, unknown> {
  if (
    !value ||
    typeof value !== 'object' ||
    Array.isArray(value) ||
    ![Object.prototype, null].includes(Object.getPrototypeOf(value)) ||
    Object.keys(value).length !== keys.length ||
    keys.some((key) => !Object.hasOwn(value, key)) ||
    Object.keys(value).some((key) => !keys.includes(key))
  )
    throw new Fault(
      'CALCULATION_FORMAT',
      'Use only the supported calculated-column formula fields.',
    );
  return value as Record<string, unknown>;
}

/** This parses data, never JavaScript, SQL, or AG Grid expression strings. */
export function validateCalculationDraft(
  input: unknown,
  columns: readonly ColumnSpec[] = COLUMNS,
): CalculationDraft {
  const columnMap =
    columns === COLUMNS ? COLUMN_MAP : new Map(columns.map((column) => [column.id, column]));
  const reservedLabels = new Set(
    columns.flatMap((column) => [column.id, column.label, ...column.aliases]).map(normalize),
  );
  const draft = object(input, ['label', 'expression']);
  if (
    typeof draft['label'] !== 'string' ||
    draft['label'].trim().length < 1 ||
    draft['label'].trim().length > CALCULATION_LIMITS.label ||
    /[\p{Cc}\p{Cf}]/u.test(draft['label']) ||
    reservedLabels.has(normalize(draft['label'])) ||
    ['constructor', 'prototype', '__proto__', 'tenant'].includes(normalize(draft['label']))
  )
    throw new Fault(
      'CALCULATION_LABEL',
      'Choose a distinct calculated-column name of 1 to 80 characters that does not reuse an existing column name.',
    );
  let nodes = 0;
  const seen = new Set<object>();
  const parse = (input: unknown, depth: number): CalculationExpression => {
    if (++nodes > CALCULATION_LIMITS.nodes || depth > CALCULATION_LIMITS.depth)
      throw new Fault('CALCULATION_LIMIT', 'The calculated-column formula is too complex.');
    if (!input || typeof input !== 'object' || Array.isArray(input) || seen.has(input))
      throw new Fault(
        'CALCULATION_FORMAT',
        'A formula must contain separate, supported expression nodes.',
      );
    seen.add(input);
    const kind = (input as Record<string, unknown>)['kind'];
    if (kind === 'field') {
      const node = object(input, ['kind', 'field']);
      if (typeof node['field'] !== 'string' || columnMap.get(node['field'])?.kind !== 'number')
        throw new Fault(
          'CALCULATION_FIELD',
          'Calculated columns may use only existing numeric source columns; calculated-column chaining is not supported.',
        );
      return { kind, field: node['field'] };
    }
    if (kind === 'number') {
      const node = object(input, ['kind', 'value']);
      if (
        typeof node['value'] !== 'number' ||
        !Number.isFinite(node['value']) ||
        Math.abs(node['value']) > CALCULATION_LIMITS.constant
      )
        throw new Fault(
          'CALCULATION_NUMBER',
          'Formula constants must be finite numbers within ±1 trillion.',
        );
      return { kind, value: node['value'] };
    }
    if (kind === 'binary') {
      const node = object(input, ['kind', 'operator', 'left', 'right']);
      if (!operators.includes(node['operator'] as (typeof operators)[number]))
        throw new Fault(
          'CALCULATION_OPERATOR',
          'Supported formula operations are addition, subtraction, multiplication, and division.',
        );
      return {
        kind,
        operator: node['operator'] as (typeof operators)[number],
        left: parse(node['left'], depth + 1),
        right: parse(node['right'], depth + 1),
      };
    }
    throw new Fault(
      'CALCULATION_FORMAT',
      'The calculated-column formula contains an unsupported expression.',
    );
  };
  return { label: draft['label'].trim(), expression: parse(draft['expression'], 1) };
}

/** SQL-like null arithmetic. Non-finite values and division by zero produce a blank. */
export function evaluateCalculation(
  expression: CalculationExpression,
  row: Readonly<Record<string, unknown>>,
  columns: readonly ColumnSpec[] = COLUMNS,
): number | null {
  const columnMap =
    columns === COLUMNS ? COLUMN_MAP : new Map(columns.map((column) => [column.id, column]));
  let nodes = 0;
  const seen = new Set<object>();
  const evaluate = (node: CalculationExpression, depth: number): number | null => {
    if (
      !node ||
      typeof node !== 'object' ||
      ++nodes > CALCULATION_LIMITS.nodes ||
      depth > CALCULATION_LIMITS.depth ||
      seen.has(node)
    )
      return null;
    seen.add(node);
    if (node.kind === 'field') {
      if (columnMap.get(node.field)?.kind !== 'number' || !Object.hasOwn(row, node.field))
        return null;
      const value = row[node.field];
      return typeof value === 'number' && Number.isFinite(value) ? value : null;
    }
    if (node.kind === 'number')
      return Number.isFinite(node.value) && Math.abs(node.value) <= CALCULATION_LIMITS.constant
        ? node.value
        : null;
    if (node.kind !== 'binary') return null;
    const left = evaluate(node.left, depth + 1);
    const right = evaluate(node.right, depth + 1);
    if (left === null || right === null) return null;
    let result: number;
    switch (node.operator) {
      case 'add':
        result = left + right;
        break;
      case 'subtract':
        result = left - right;
        break;
      case 'multiply':
        result = left * right;
        break;
      case 'divide':
        if (right === 0) return null;
        result = left / right;
        break;
      default:
        return null;
    }
    return Number.isFinite(result) ? (Object.is(result, -0) ? 0 : result) : null;
  };
  return evaluate(expression, 1);
}

export function describeCalculation(
  expression: CalculationExpression,
  columns: readonly ColumnSpec[] = COLUMNS,
): string {
  const columnMap =
    columns === COLUMNS ? COLUMN_MAP : new Map(columns.map((column) => [column.id, column]));
  const validated = validateCalculationDraft(
    {
      label: 'Calculated formula preview',
      expression,
    },
    columns,
  ).expression;
  const symbols = { add: '+', subtract: '−', multiply: '×', divide: '÷' };
  const describe = (node: CalculationExpression): string => {
    if (node.kind === 'field') return `[${columnMap.get(node.field)!.label}]`;
    if (node.kind === 'number') return String(node.value);
    return `(${describe(node.left)} ${symbols[node.operator]} ${describe(node.right)})`;
  };
  return describe(validated);
}

export function calculatedColumnSpec(
  definition: CalculatedColumnDefinition,
  columns: readonly ColumnSpec[] = COLUMNS,
): ColumnSpec {
  const columnMap =
    columns === COLUMNS ? COLUMN_MAP : new Map(columns.map((column) => [column.id, column]));
  if (!/^calc_[A-Za-z0-9_-]{1,70}$/.test(definition.id) || columnMap.has(definition.id))
    throw new Fault('CALCULATION_ID', 'The calculated column has an invalid identifier.');
  const draft = validateCalculationDraft(
    {
      label: definition.label,
      expression: definition.expression,
    },
    columns,
  );
  return {
    id: definition.id,
    label: draft.label,
    kind: 'number',
    nullable: true,
    aliases: [draft.label],
    // An empty mapping must never be admitted to the trusted physical SQL schema.
    sql: '',
    description: `Calculated per row: ${describeCalculation(draft.expression, columns)}. Missing inputs, division by zero, and non-finite results are blank. Grouped aggregations operate on the calculated row values.`,
  };
}

/** Preserve source rows; always evaluate against source fields rather than other calculations. */
export function materializeCalculatedColumns<T extends Record<string, unknown>>(
  row: T,
  definitions: readonly CalculatedColumnDefinition[],
  columns: readonly ColumnSpec[] = COLUMNS,
): T {
  const columnMap =
    columns === COLUMNS ? COLUMN_MAP : new Map(columns.map((column) => [column.id, column]));
  if (definitions.length > CALCULATION_LIMITS.columns)
    throw new Fault('CALCULATION_LIMIT', 'Too many calculated columns.');
  // Compact snapshot rows expose fields through prototype getters; copy inherited fields too.
  const result: Record<string, unknown> = {};
  for (const key in row) result[key] = row[key];
  const ids = new Set<string>();
  for (const definition of definitions) {
    if (
      !/^calc_[A-Za-z0-9_-]{1,70}$/.test(definition.id) ||
      columnMap.has(definition.id) ||
      ids.has(definition.id)
    )
      throw new Fault(
        'CALCULATION_ID',
        'Calculated-column identifiers must be distinct and cannot replace source columns.',
      );
    ids.add(definition.id);
    result[definition.id] = evaluateCalculation(definition.expression, row, columns);
  }
  return result as T;
}
