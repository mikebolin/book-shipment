import type { GridState } from 'ag-grid-community';
import type { GridModel, Mode } from './contracts';
import type { ChartPlan } from './integrated-chart';
import type { CalculatedColumnDefinition } from './calculated-columns';
import type { ClientSourceMetadata } from '../../explorer/client-data-sources';
import type { ChartPresentation } from '../../explorer/integrated-chart.component';
import type { WorkspacePreview } from './workspace-cards';
import type { ServerGridSettings } from './server-grid-settings';
export type Collection = 'models' | 'widgets' | 'dashboards';
export interface ModelDefinition extends ClientSourceMetadata {
  sourceKey: string;
  clientSourceId: string;
  schemaVersion: string;
  dataVersion: string;
  rowCount: number;
  uncompressedBytes?: number;
}
export interface ViewFilterControls {
  visible: boolean;
  parameterizable: boolean;
  /** Expression editing is the legacy default; values locks fields, operators and grouping. */
  editMode?: 'values' | 'expression';
}
export interface ViewLayout {
  tablePosition?: 'top' | 'bottom';
  showTitle?: boolean;
  showRecordCounts?: boolean;
  showFilterSummaries?: boolean;
  showChartDescriptions?: boolean;
}
export interface WidgetConfiguration {
  /** Bounded request and cache policy, shared by every renderer of this saved view. */
  serverGrid?: ServerGridSettings;
  /** Saved presentation, shared by Studio, published views and whole-view dashboard imports. */
  viewLayout?: ViewLayout;
  /** Reader-facing exports. This is a presentation preference, not an access policy. */
  allowDownload?: boolean;
  displayMode?: 'grid' | 'chart' | 'both';
  /** Number of charts visible together above the table; legacy views default to two. */
  bothChartCount?: 1 | 2 | 3;
  filterControls?: ViewFilterControls;
  preview?: WorkspacePreview;
  schemaVersion: 1;
  recordCount?: number;
  group?: string;
  tags?: string[];
  modelSchemaVersion: string;
  mode: 'advanced' | 'columns';
  gridState: GridState;
  /** Stable identity for the independently configured table in this view. */
  grid?: { id: string; filterControls?: ViewFilterControls };
  calculatedColumns: CalculatedColumnDefinition[];
  /** Primary chart, also used to reopen the editor's selected chart. */
  chart: ViewChart | null;
  /** Complete chart collection. Older configurations contain only chart. */
  charts?: ViewChart[];
  columnCategories?: Record<string, string>;
  columnHighlights?: import('../../explorer/column-highlights').ColumnHighlights;
  categoryOrder?: string[];
  showRowNumbers?: boolean;
}
export interface ViewChart {
  id: string;
  size?: 'standard' | 'wide';
  filterControls?: ViewFilterControls;
  plan: ChartPlan;
  presentation: ChartPresentation | null;
  description?: string;
  /** Saved query over the view's shared model. Absent on legacy charts that follow table filters. */
  dataScope?: ViewChartDataScope;
}
export interface ViewChartDataScope {
  mode: Mode;
  filterModel: GridModel;
}
export type Tone = 'neutral' | 'info' | 'success' | 'warning';
/**
 * Dashboard element kinds. `view` bundles every chart and the table of a pinned revision;
 * `chart` and `table` place one component of a pinned revision. `text` and `html` are the
 * deprecated v1 content kinds, still readable; `richtext` replaces them (schemaVersion 2).
 */
export type PlacementKind =
  | 'view'
  | 'chart'
  | 'table'
  | 'filter'
  | 'section'
  | 'richtext'
  | 'image'
  | 'powerbi'
  | 'text'
  | 'html';
export type ViewOverrides = Partial<
  Pick<
    WidgetConfiguration,
    | 'mode'
    | 'grid'
    | 'gridState'
    | 'filterControls'
    | 'chart'
    | 'charts'
    | 'showRowNumbers'
    | 'allowDownload'
    | 'bothChartCount'
    | 'viewLayout'
    | 'serverGrid'
  >
>;
/** Minimal diff against the pinned chart; absent keys inherit the published revision. */
export interface ChartOverrides {
  title?: string;
  chartType?: ChartPlan['type'];
  presentation?: ChartPresentation | null;
  dataScope?: ViewChartDataScope;
  filterControls?: ViewFilterControls;
  allowDownload?: boolean;
}
/** Minimal diff against the pinned table; a supplied gridState replaces the complete saved state. */
export interface TableOverrides {
  serverGrid?: ServerGridSettings;
  mode?: Mode;
  gridState?: GridState;
  filterControls?: ViewFilterControls;
  showRowNumbers?: boolean;
  allowDownload?: boolean;
}
/** Geometry is in 12-column units. Children of a section store x/y relative to the section's content grid. */
export interface PlacementBase {
  id: string;
  kind: PlacementKind;
  x: number;
  y: number;
  w: number;
  h: number;
  sectionId?: string;
  title?: string;
  description?: string;
}
export interface ViewPlacement extends PlacementBase {
  kind: 'view';
  widgetId: string;
  widgetRevision: number;
  displayMode: 'grid' | 'chart' | 'both';
  viewOverrides?: ViewOverrides;
  interactions?: PlacementInteractions;
}
export interface ChartPlacement extends PlacementBase {
  kind: 'chart';
  widgetId: string;
  widgetRevision: number;
  chartId: string;
  overrides?: ChartOverrides;
  interactions?: PlacementInteractions;
}
export interface TablePlacement extends PlacementBase {
  kind: 'table';
  widgetId: string;
  widgetRevision: number;
  overrides?: TableOverrides;
}
/**
 * Filter controls: a pinned view's saved advanced filter whose comparison values become inputs
 * for readers. The applied values scope every chart, table and view on the dashboard (they
 * replace an element's own conditions on the same columns), and a chart with
 * `interactions.selectFilter` rewrites them when a bucket or category is clicked.
 */
export interface FilterPlacement extends PlacementBase {
  kind: 'filter';
  widgetId: string;
  widgetRevision: number;
  filter: ViewChartDataScope;
  /** Toolbar controls; without them the element shows the filter's values as plain inputs. */
  controls?: DashboardControl[];
}
/**
 * Declarative reader controls of a filter-controls element. Each writes to the dashboard scope:
 * `window` rewrites the lower/upper bounds on a time column from a preset duration (anchored at
 * `endsAt`, else the current upper bound, else now); `values` sets equality rules on a column;
 * `bucket` overrides the bucket size of minute/hour charts; `groupBy` regroups server grids.
 */
export type DashboardControl =
  | {
      type: 'window';
      columnId: string;
      label?: string;
      options: number[];
      endsAt?: string;
      /** A rolling window is evaluated when the dashboard opens or the preset changes. */
      anchor?: 'now' | 'saved';
      minutes?: number;
    }
  | { type: 'bucket'; label?: string; seconds?: number; options: number[] }
  | {
      type: 'values';
      columnId: string;
      label?: string;
      multiple?: boolean;
      options?: string[];
      allowAll?: boolean;
    }
  | {
      type: 'groupBy';
      label?: string;
      options: { columnId: string; label?: string }[];
      allowNone?: boolean;
      /** The saved default; null means ungrouped, absent uses the first configured option. */
      columnId?: string | null;
    };
/** What readers currently apply through a filter-controls element (session state). */
export interface DashboardScopeState {
  filterModel: GridModel;
  /** Chart bucket width in seconds (6 s to hours); absent keeps each chart's saved bucket. */
  bucketSeconds?: number;
  /** A column to group server grids by, `null` for no grouping, absent to keep saved grouping. */
  groupBy?: string | null;
}
export interface SectionPlacement extends PlacementBase {
  kind: 'section';
  title: string;
  tone?: Tone;
  collapsed?: boolean;
  layout: 'grid';
}
export interface RichTextPlacement extends PlacementBase {
  kind: 'richtext';
  document: RichTextDocument;
  tone?: Tone;
}
export interface ImagePlacement extends PlacementBase {
  kind: 'image';
  imageUrl: string;
  alt: string;
  tone?: Tone;
}
export interface PowerBiPlacement extends PlacementBase {
  kind: 'powerbi';
  embedUrl: string;
  tone?: Tone;
}
/** Deprecated v1 content kinds; converted to richtext when edited. */
export interface TextPlacement extends PlacementBase {
  kind: 'text' | 'html';
  content: string;
  tone?: Tone;
}
export type DashboardElement =
  | ViewPlacement
  | ChartPlacement
  | TablePlacement
  | FilterPlacement
  | SectionPlacement
  | RichTextPlacement
  | ImagePlacement
  | PowerBiPlacement
  | TextPlacement;
export type DataPlacement = ViewPlacement | ChartPlacement | TablePlacement | FilterPlacement;
/**
 * Permissive record shared by the v1 composer and the readers of either schema version.
 * Every `DashboardElement` is assignable to it; narrow with the guards in dashboard-elements.ts.
 */
export interface Placement {
  id: string;
  kind?: PlacementKind;
  content?: string;
  tone?: Tone;
  widgetId?: string;
  widgetRevision?: number;
  chartId?: string;
  displayMode?: 'grid' | 'chart' | 'both';
  /** Settings for this view placement only; absent fields inherit the pinned source revision. */
  viewOverrides?: ViewOverrides;
  /** Chart or table element overrides (schemaVersion 2). */
  overrides?: ChartOverrides | TableOverrides;
  interactions?: PlacementInteractions;
  /** Filter-controls elements: the saved predicates whose values readers adjust, and their toolbar. */
  filter?: ViewChartDataScope;
  controls?: DashboardControl[];
  document?: RichTextDocument;
  layout?: 'grid';
  collapsed?: boolean;
  title?: string;
  description?: string;
  sectionId?: string;
  imageUrl?: string;
  alt?: string;
  embedUrl?: string;
  x: number;
  y: number;
  w: number;
  h: number;
}
export interface DashboardConfiguration {
  schemaVersion: 1 | 2;
  group?: string;
  tags?: string[];
  preview?: WorkspacePreview;
  items: Placement[];
}
/** Reader interactions an element offers on a dashboard. */
export interface PlacementInteractions {
  switchView?: boolean;
  /** Clicking a chart category or time bucket updates the dashboard filter's values. */
  selectFilter?: boolean;
}
/** ProseMirror-style JSON document; the server validates it against the same node and mark allow-list. */
export interface RichTextMark {
  type: 'bold' | 'italic' | 'underline' | 'strike' | 'code' | 'link' | 'highlight';
  attrs?: Record<string, unknown>;
}
export interface RichTextNode {
  type: string;
  attrs?: Record<string, unknown>;
  content?: RichTextNode[];
  marks?: RichTextMark[];
  text?: string;
}
export interface RichTextDocument extends RichTextNode {
  type: 'doc';
  content: RichTextNode[];
}
export interface Resource<T = ModelDefinition | WidgetConfiguration | DashboardConfiguration> {
  id: string;
  kind: 'MODEL' | 'WIDGET' | 'DASHBOARD';
  slug: string;
  name: string;
  description: string;
  modelId: string | null;
  version: number;
  publishedVersion: number | null;
  body: T;
  createdAt: string;
  updatedAt: string;
}
export type ModelResource = Resource<ModelDefinition>;
export type WidgetResource = Resource<WidgetConfiguration>;
export type DashboardResource = Resource<DashboardConfiguration>;
export interface EditorBridge {
  /** Reactive readiness for actions that capture a complete configuration. */
  canCapture?(): boolean;
  hasChanges(): boolean;
  /** Charts, a non-empty table filter or calculated columns: work worth protecting. */
  hasMeaningfulWork?(): boolean;
  markSaved(): void;
  capture(): WidgetConfiguration;
  restore(configuration: WidgetConfiguration): void;
  reset(): void;
  downloadAll?(): Promise<void>;
}
