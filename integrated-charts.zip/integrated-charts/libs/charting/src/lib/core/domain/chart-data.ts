import { z } from 'zod';
import { CHART_MAX_TIME_BUCKETS, compareChartValues, timeDomain } from './chart-extensions.js';
import { COLUMNS, type ColumnSpec } from './schema.js';
import type { Node } from './contracts.js';
import { Fault, plainDate } from './engine.js';
import {
  analyticColumns,
  buildAnalyticDataset,
  chartAnalyticsSchema,
  chartAnalyticsJsonSchema,
  metricIdPattern,
} from './chart-analytics.js';
import {
  CHART_AGGREGATIONS,
  CHART_TIME_BUCKETS,
  CHART_TYPES,
  ENTERPRISE_ONLY_CHART_TYPES,
  CHART_THEMES,
  CHART_LEGEND_POSITIONS,
  COMBO_SERIES_TYPES,
  chartColumnMetadata,
  type ChartPlan,
  type ChartResponse,
} from './integrated-chart.js';

export type ChartSourceRow = Readonly<Record<string, string | number | null>>;
export const CHART_MAX_SOURCE_ROWS = 50_000;
export const CHART_MAX_CATEGORIES = 200;
/** Buckets whose width is a multiple of one unit, aligned to the epoch. */
const FIXED_WIDTH_UNITS: Partial<Record<NonNullable<ChartPlan['timeBucket']>, number>> = {
  second: 1_000,
  minute: 60_000,
  hour: 3_600_000,
};
const FIXED_WIDTH_BUCKETS = new Set<ChartPlan['timeBucket']>(['second', 'minute', 'hour']);
const rawTypes = new Set<ChartPlan['type']>(['scatter', 'bubble', 'histogram']);
const temporalTypes = new Set<ChartPlan['type']>([
  'line',
  'stackedLine',
  'normalizedLine',
  'area',
  'stackedArea',
  'normalizedArea',
]);
const comboTypes = new Set<ChartPlan['type']>([
  'columnLineCombo',
  'areaColumnCombo',
  'customCombo',
]);
const proportionTypes = new Set<ChartPlan['type']>(['pie', 'donut']);

export const chartAppearanceSchema = z
  .object({
    theme: z.enum(CHART_THEMES).nullable(),
    legendPosition: z.enum(CHART_LEGEND_POSITIONS).nullable(),
    showLegend: z.boolean().nullable(),
    showLabels: z.boolean().nullable(),
    xAxisTitle: z.string().trim().max(100).nullable(),
    yAxisTitle: z.string().trim().max(100).nullable(),
  })
  .strict();

export const chartPlanSchema = z
  .object({
    type: z
      .enum([...CHART_TYPES, 'doughnut'])
      .transform((type) => (type === 'doughnut' ? ('donut' as const) : type)),
    categoryColumnId: z.string().min(1).max(100).nullable(),
    measureColumnIds: z.array(z.string().min(1).max(100)).max(3),
    aggregation: z.enum(CHART_AGGREGATIONS).nullable(),
    timeBucket: z.enum(CHART_TIME_BUCKETS).nullable(),
    bucketSize: z.number().int().min(1).max(60).optional(),
    title: z.string().trim().min(1).max(160),
    appearance: chartAppearanceSchema.nullable().optional(),
    analytics: chartAnalyticsSchema.optional(),
    histogram: z
      .object({
        binCount: z.number().int().min(1).max(100),
        edges: z.array(z.number().finite()).min(2).max(101).optional(),
      })
      .strict()
      .optional(),
    categoryAxis: z.literal('ordered').optional(),
    categoryOrder: z
      .array(z.union([z.string().max(256), z.number().finite()]))
      .min(1)
      .max(200)
      .optional(),
    rawPointSelection: z
      .object({
        orderBy: z
          .array(
            z
              .object({ field: z.string().min(1).max(100), direction: z.enum(['asc', 'desc']) })
              .strict(),
          )
          .min(1)
          .max(4),
        limit: z.number().int().min(1).max(10000),
      })
      .strict()
      .optional(),
    timeRange: z
      .object({
        start: z
          .string()
          .regex(/^\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2}:\d{2})?$/)
          .optional(),
        endExclusive: z
          .string()
          .regex(/^\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2}:\d{2})?$/)
          .optional(),
        fill: z.literal('zero'),
      })
      .strict()
      .optional(),
    seriesChartTypes: z
      .array(
        z
          .object({
            colId: z.string().min(1).max(100),
            chartType: z.enum(COMBO_SERIES_TYPES),
            secondaryAxis: z.boolean(),
          })
          .strict(),
      )
      .min(2)
      .max(3)
      .nullable()
      .optional(),
  })
  .strict();
export const chartRequestSchema = z
  .object({
    plan: chartPlanSchema,
    mode: z.enum(['advanced', 'columns']),
    filterModel: z.record(z.unknown()).nullable(),
    calculatedColumnIds: z
      .array(z.string().regex(/^calc_[A-Za-z0-9_-]{1,70}$/))
      .max(8)
      .optional(),
  })
  .strict();

export function chartPlanJsonSchema(
  columns: readonly ColumnSpec[] = COLUMNS,
  includeAppearance = false,
) {
  const metadata = chartColumnMetadata(columns);
  const categories = metadata
    .filter((c) => c.role === 'dimension' || c.role === 'temporal')
    .map((c) => c.id);
  const measures = metadata.filter((c) => c.role === 'measure').map((c) => c.id);
  const selectedMeasure = includeAppearance
    ? {
        anyOf: [
          { type: 'string', enum: measures },
          { type: 'string', pattern: metricIdPattern },
        ],
      }
    : { type: 'string', enum: measures };
  return {
    type: 'object',
    additionalProperties: false,
    properties: {
      type: { type: 'string', enum: [...CHART_TYPES] },
      categoryColumnId: {
        anyOf: [
          { type: 'string', enum: categories },
          { type: 'string', pattern: '^dimension_[A-Za-z0-9_]{1,60}$' },
          { type: 'null' },
        ],
      },
      measureColumnIds: { type: 'array', maxItems: 3, items: selectedMeasure },
      aggregation: { type: ['string', 'null'], enum: [...CHART_AGGREGATIONS, null] },
      timeBucket: { type: ['string', 'null'], enum: [...CHART_TIME_BUCKETS, null] },
      title: { type: 'string', minLength: 1, maxLength: 160 },
      ...(includeAppearance
        ? {
            categoryAxis: { type: ['string', 'null'], enum: ['ordered', null] },
            categoryOrder: {
              type: ['array', 'null'],
              minItems: 1,
              maxItems: 200,
              items: { type: ['string', 'number'] },
            },
            rawPointSelection: {
              type: ['object', 'null'],
              additionalProperties: false,
              required: ['orderBy', 'limit'],
              properties: {
                limit: { type: 'integer', minimum: 1, maximum: 10000 },
                orderBy: {
                  type: 'array',
                  minItems: 1,
                  maxItems: 4,
                  items: {
                    type: 'object',
                    additionalProperties: false,
                    required: ['field', 'direction'],
                    properties: {
                      field: { type: 'string', enum: columns.map((c) => c.id) },
                      direction: { type: 'string', enum: ['asc', 'desc'] },
                    },
                  },
                },
              },
            },
            analytics: {
              anyOf: [
                { type: 'null' },
                chartAnalyticsJsonSchema(
                  measures,
                  categories,
                  columns.map((c) => c.id),
                ),
              ],
            },
            histogram: {
              anyOf: [
                { type: 'null' },
                {
                  type: 'object',
                  additionalProperties: false,
                  properties: {
                    binCount: { type: 'integer', minimum: 1, maximum: 100 },
                    edges: {
                      type: ['array', 'null'],
                      minItems: 2,
                      maxItems: 101,
                      items: { type: 'number' },
                    },
                  },
                  required: ['binCount'],
                },
              ],
            },
            timeRange: {
              anyOf: [
                { type: 'null' },
                {
                  type: 'object',
                  additionalProperties: false,
                  properties: {
                    start: { type: 'string' },
                    endExclusive: { type: 'string' },
                    fill: { type: 'string', enum: ['zero'] },
                  },
                  required: ['start', 'endExclusive', 'fill'],
                },
              ],
            },
            seriesChartTypes: {
              anyOf: [
                { type: 'null' },
                {
                  type: 'array',
                  minItems: 2,
                  maxItems: 3,
                  items: {
                    type: 'object',
                    additionalProperties: false,
                    properties: {
                      colId: selectedMeasure,
                      chartType: { type: 'string', enum: [...COMBO_SERIES_TYPES] },
                      secondaryAxis: { type: 'boolean' },
                    },
                    required: ['colId', 'chartType', 'secondaryAxis'],
                  },
                },
              ],
            },
            appearance: {
              anyOf: [
                { type: 'null' },
                {
                  type: 'object',
                  additionalProperties: false,
                  properties: {
                    theme: { type: ['string', 'null'], enum: [...CHART_THEMES, null] },
                    legendPosition: {
                      type: ['string', 'null'],
                      enum: [...CHART_LEGEND_POSITIONS, null],
                    },
                    showLegend: { type: ['boolean', 'null'] },
                    showLabels: { type: ['boolean', 'null'] },
                    xAxisTitle: { type: ['string', 'null'], maxLength: 100 },
                    yAxisTitle: { type: ['string', 'null'], maxLength: 100 },
                  },
                  required: [
                    'theme',
                    'legendPosition',
                    'showLegend',
                    'showLabels',
                    'xAxisTitle',
                    'yAxisTitle',
                  ],
                },
              ],
            },
          }
        : {}),
    },
    required: [
      'type',
      'categoryColumnId',
      'measureColumnIds',
      'aggregation',
      'timeBucket',
      'title',
      ...(includeAppearance ? ['appearance', 'seriesChartTypes'] : []),
    ],
  };
}

export function validateChartPlan(
  input: unknown,
  columns: readonly ColumnSpec[] = COLUMNS,
): ChartPlan {
  const type = input && typeof input === 'object' ? (input as { type?: unknown }).type : null;
  if (
    typeof type === 'string' &&
    ENTERPRISE_ONLY_CHART_TYPES.some((chartType) => chartType === type)
  )
    throw new Fault(
      'CHART_MODULE',
      `${type} requires AG Charts Enterprise, which this host does not load. Choose a supported chart type or extend the host's chart module and data contract.`,
    );
  const parsed = chartPlanSchema.safeParse(input);
  if (!parsed.success)
    throw new Fault('CHART_PLAN', 'Choose a supported chart and valid chart settings.');
  const plan = parsed.data;
  const metadata = new Map(
    chartColumnMetadata(analyticColumns(plan, columns)).map((column) => [column.id, column]),
  );
  const category = plan.categoryColumnId ? metadata.get(plan.categoryColumnId) : undefined;
  const measures = plan.measureColumnIds.map((id) => metadata.get(id));
  if (plan.histogram && plan.type !== 'histogram')
    throw new Fault('CHART_BINS', 'Histogram bins can only be used with a histogram.');
  if (
    plan.histogram?.edges &&
    (plan.histogram.edges.length !== plan.histogram.binCount + 1 ||
      plan.histogram.edges.some((edge, i) => i > 0 && edge <= plan.histogram!.edges![i - 1]))
  )
    throw new Fault(
      'CHART_BINS',
      'Fixed histogram edges must be finite, strictly increasing, and match binCount.',
    );
  if (
    plan.rawPointSelection &&
    (!['scatter', 'bubble'].includes(plan.type) ||
      plan.analytics ||
      plan.rawPointSelection.orderBy.some((order) => !columns.some((c) => c.id === order.field)))
  )
    throw new Fault(
      'CHART_POINTS',
      'Bounded raw points require approved ordering fields and a raw scatter or bubble chart.',
    );
  if (
    plan.categoryOrder &&
    (new Set(plan.categoryOrder).size !== plan.categoryOrder.length ||
      !plan.categoryColumnId ||
      rawTypes.has(plan.type) ||
      (plan.analytics?.groupByColumnIds?.length ?? 1) > 1)
  )
    throw new Fault(
      'CHART_CATEGORY',
      'An explicit display domain requires one category and distinct values.',
    );
  if (plan.categoryAxis && (category?.role !== 'dimension' || plan.timeBucket !== null))
    throw new Fault(
      'CHART_CATEGORY',
      'An ordered category axis needs a dimension without a time bucket.',
    );
  if (plan.bucketSize !== undefined && !FIXED_WIDTH_BUCKETS.has(plan.timeBucket))
    throw new Fault('CHART_TIME', 'A bucket size applies only to second, minute or hour buckets.');
  if (plan.timeRange && !!plan.timeRange.start !== !!plan.timeRange.endExclusive)
    throw new Fault(
      'CHART_TIME_RANGE',
      'A time range needs both bounds, or neither to follow the filter.',
    );
  if (plan.timeRange) {
    const additiveBase = plan.analytics
      ? plan.analytics.metrics.length > 0 &&
        plan.analytics.metrics.every((metric) => ['sum', 'count'].includes(metric.operation))
      : ['sum', 'count'].includes(plan.aggregation ?? '');
    if (
      rawTypes.has(plan.type) ||
      category?.role !== 'temporal' ||
      !plan.timeBucket ||
      !additiveBase
    )
      throw new Fault(
        'CHART_TIME_RANGE',
        'A complete calendar domain requires a temporal category and additive base aggregation.',
      );
    timeDomain(plan, (value, bucket) => chartTimeBucket(value, bucket, plan.bucketSize));
  }
  if (plan.type === 'customCombo') {
    const series = plan.seriesChartTypes;
    if (
      !series ||
      series.length !== plan.measureColumnIds.length ||
      new Set(series.map((item) => item.colId)).size !== series.length ||
      series.some((item) => !plan.measureColumnIds.includes(item.colId))
    )
      throw new Fault(
        'CHART_SERIES',
        'Custom combinations require exactly one series configuration for each selected measure.',
      );
    if (series.some((item) => item.secondaryAxis && !['line', 'area'].includes(item.chartType)))
      throw new Fault(
        'CHART_SERIES_AXIS',
        'Only line and area series support a secondary axis in the installed chart engine.',
      );
  } else if (plan.seriesChartTypes != null) {
    throw new Fault(
      'CHART_SERIES',
      'Per-series chart types can only be used with a custom combination chart.',
    );
  }
  if (
    (!rawTypes.has(plan.type) &&
      new Set(plan.measureColumnIds).size !== plan.measureColumnIds.length) ||
    measures.some((column) => !column || column.role !== 'measure')
  )
    throw new Fault(
      'CHART_MEASURE',
      'Chart measures must be approved numeric measures; grouped series must be distinct and identifiers cannot be charted as measures.',
    );
  if (rawTypes.has(plan.type)) {
    const count = plan.type === 'bubble' ? 3 : plan.type === 'scatter' ? 2 : 1;
    if (
      (plan.analytics ? !plan.categoryColumnId : plan.categoryColumnId !== null) ||
      plan.aggregation !== null ||
      plan.timeBucket !== null ||
      measures.length !== count
    )
      throw new Fault(
        'CHART_PLAN',
        `${plan.type} requires ${count} numeric measure${count === 1 ? '' : 's'}, with no category, aggregation or time bucket. Bubble measure order is X, Y, size.`,
      );
    return plan;
  }
  const explicitMetrics =
    !!plan.analytics &&
    plan.measureColumnIds.length > 0 &&
    plan.measureColumnIds.every(
      (id) =>
        plan.analytics!.metrics.some((metric) => metric.id === id) ||
        plan.analytics!.windows?.some((window) => window.id === id),
    );
  if (
    !category ||
    !['dimension', 'temporal'].includes(category.role) ||
    (plan.aggregation === null && !explicitMetrics)
  )
    throw new Fault(
      'CHART_CATEGORY',
      'Choose a category or date field and an explicit aggregation for this chart.',
    );
  if (!measures.length && plan.aggregation !== 'count')
    throw new Fault(
      'CHART_MEASURE',
      'Choose at least one numeric measure, or use count to count matching rows.',
    );
  if (
    temporalTypes.has(plan.type) &&
    plan.categoryAxis !== 'ordered' &&
    (category.role !== 'temporal' || plan.timeBucket === null)
  )
    throw new Fault(
      'CHART_TIME',
      'Line and area charts need a date or timestamp field and a time bucket.',
    );
  if (category.role !== 'temporal' && plan.timeBucket !== null)
    throw new Fault(
      'CHART_TIME',
      'Time buckets can only be used with date or timestamp categories.',
    );
  if (comboTypes.has(plan.type) && measures.length < 2)
    throw new Fault('CHART_MEASURE', 'Combination charts require at least two numeric measures.');
  if (proportionTypes.has(plan.type) && measures.length > 1)
    throw new Fault(
      'CHART_MEASURE',
      'Pie and donut charts require one measure, or a count of rows.',
    );
  const sharedAxisMeasures =
    plan.type === 'customCombo'
      ? measures.filter(
          (column) =>
            !plan.seriesChartTypes!.find((series) => series.colId === column!.id)!.secondaryAxis,
        )
      : measures;
  if (
    plan.aggregation !== 'count' &&
    sharedAxisMeasures.length > 1 &&
    (sharedAxisMeasures.some((column) => !column?.unit) ||
      new Set(sharedAxisMeasures.map((column) => column?.unit)).size > 1)
  )
    throw new Fault(
      'CHART_UNITS',
      'These measures use different or unspecified units on a shared value axis. Choose one measure, configure trusted units, use independent secondary axes in a custom combination, or create separate charts.',
    );
  return plan;
}

const finite = (value: unknown): value is number =>
  typeof value === 'number' && Number.isFinite(value);
function aggregate(
  rows: readonly ChartSourceRow[],
  id: string,
  operation: NonNullable<ChartPlan['aggregation']>,
): number | null {
  const values = rows.map((row) => row[id]).filter(finite);
  if (operation === 'count') return values.length;
  if (!values.length) return null;
  const value =
    operation === 'min'
      ? values.reduce((minimum, item) => Math.min(minimum, item), Infinity)
      : operation === 'max'
        ? values.reduce((maximum, item) => Math.max(maximum, item), -Infinity)
        : values.reduce((sum, item) => sum + item, 0) / (operation === 'avg' ? values.length : 1);
  if (!Number.isFinite(value))
    throw new Fault(
      'CHART_RANGE',
      'This chart total is outside the supported numeric range. Try an average or a narrower filter.',
    );
  return value;
}
export function chartTimeBucket(
  value: string | number | null | undefined,
  timeBucket: ChartPlan['timeBucket'],
  bucketSize = 1,
): string | number | null {
  if (value == null) return null;
  const text = String(value);
  if (timeBucket === null) return typeof value === 'number' ? value : text;
  try {
    plainDate(text.slice(0, 10));
  } catch {
    throw new Fault('CHART_DATE', 'The selected date column contains an invalid date.');
  }
  const timestamp =
    text.length === 10
      ? text + 'T00:00:00Z'
      : /^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?$/.test(text)
        ? text.replace(' ', 'T') + 'Z'
        : text;
  const date = new Date(timestamp);
  if (!Number.isFinite(date.getTime()))
    throw new Fault('CHART_DATE', 'The selected date column contains an invalid date.');
  if (FIXED_WIDTH_BUCKETS.has(timeBucket)) {
    // Fixed-width slices aligned to the epoch, like Snowflake TIME_SLICE: `YYYY-MM-DD HH:mm`
    // for minutes and hours, `YYYY-MM-DD HH:mm:ss` for seconds.
    const size = Math.max(1, Math.floor(bucketSize)) * FIXED_WIDTH_UNITS[timeBucket!]!;
    return new Date(Math.floor(date.getTime() / size) * size)
      .toISOString()
      .slice(0, timeBucket === 'second' ? 19 : 16)
      .replace('T', ' ');
  }
  const iso = date.toISOString();
  if (timeBucket === 'year') return iso.slice(0, 4);
  if (timeBucket === 'quarter')
    return `${iso.slice(0, 4)} Q${Math.floor(date.getUTCMonth() / 3) + 1}`;
  return iso.slice(0, timeBucket === 'month' ? 7 : 10);
}

/** Pure schema-driven chart processing; caller supplies the complete dataset. */
export function buildChartDataset(
  input: ChartPlan,
  columns: readonly ColumnSpec[],
  rows: readonly ChartSourceRow[],
  maxSourceRows = CHART_MAX_SOURCE_ROWS,
): Omit<ChartResponse, 'source' | 'scope'> {
  if (rows.length > maxSourceRows)
    throw new Fault(
      'CHART_SIZE',
      'Too many matching source rows for this chart service. Apply a narrower filter.',
    );
  const plan = validateChartPlan(input, columns);
  // Native money amounts require one currency per view. This is a data-level
  // check after filtering, driven by semantic units rather than field names.
  const operands = new Set([
    ...plan.measureColumnIds,
    ...(plan.analytics?.metrics ?? []).flatMap((metric) =>
      [
        metric.columnId,
        metric.numeratorColumnId,
        metric.denominatorColumnId,
        metric.subtractColumnId,
      ].filter((id): id is string => typeof id === 'string'),
    ),
  ]);
  const nativeMoney = columns.filter(
    (column) => operands.has(column.id) && column.unit === 'local currency',
  );
  if (nativeMoney.length && rows.length) {
    const currencyFields = columns.filter(
      (column) => column.unit === 'ISO currency' && column.kind === 'text',
    );
    if (currencyFields.length !== 1)
      throw new Fault(
        'CHART_CURRENCY',
        'Native money requires an unambiguous currency field or an approved converted measure.',
      );
    const currencies = new Set(rows.map((row) => row[currencyFields[0].id]));
    if (
      currencies.size !== 1 ||
      typeof [...currencies][0] !== 'string' ||
      !/^[A-Z]{3}$/.test(String([...currencies][0]))
    )
      throw new Fault(
        'CHART_CURRENCY',
        'This view mixes or omits native currencies. Filter to one currency or select an approved converted measure.',
      );
    const currency = String([...currencies][0]);
    columns = columns.map((column) =>
      nativeMoney.some((money) => money.id === column.id) ? { ...column, unit: currency } : column,
    );
  }

  const bucketOf = (value: string | number | null | undefined, bucket: ChartPlan['timeBucket']) =>
    chartTimeBucket(value, bucket, plan.bucketSize);
  if (plan.analytics) return buildAnalyticDataset(plan, columns, rows, bucketOf);
  const map = new Map(columns.map((column) => [column.id, column]));
  const metadata = new Map(chartColumnMetadata(columns).map((column) => [column.id, column]));
  const result: Omit<ChartResponse, 'source' | 'scope'> = {
    type: plan.type,
    title: plan.title,
    ...(plan.appearance !== undefined ? { appearance: plan.appearance } : {}),
    ...(plan.seriesChartTypes !== undefined
      ? {
          seriesChartTypes:
            plan.seriesChartTypes?.map((series) => ({
              ...series,
              colId: `measure${plan.measureColumnIds.indexOf(series.colId)}`,
            })) ?? null,
        }
      : {}),
    plan,
    matchedRowCount: rows.length,
    plottedRowCount: 0,
    omittedRowCount: 0,
    missingValueCounts: Object.fromEntries(
      plan.measureColumnIds.map((id) => [id, rows.filter((row) => !finite(row[id])).length]),
    ),
    categoryMissingRowCount: plan.categoryColumnId
      ? rows.filter((row) => row[plan.categoryColumnId!] == null).length
      : 0,
    columns: [],
    rows: [],
    notes: ['Computed from all matching source rows.'],
  };
  if (rawTypes.has(plan.type)) {
    result.columns = plan.measureColumnIds.map((id, index) => ({
      id: `measure${index}`,
      label: map.get(id)!.label,
      dataType: 'series',
      sourceColumnId: id,
      unit: metadata.get(id)!.unit,
      aggregation: null,
    }));
    let measured = rows.filter((row) => plan.measureColumnIds.every((id) => finite(row[id])));
    const completeRows = measured.length;
    if (plan.rawPointSelection) {
      const selection = plan.rawPointSelection;
      measured = [...measured]
        .sort((a, b) => {
          for (const o of selection.orderBy) {
            const av = a[o.field] ?? null,
              bv = b[o.field] ?? null;
            const cmp =
              compareChartValues(av, bv) *
              (av === null || bv === null ? 1 : o.direction === 'desc' ? -1 : 1);
            if (cmp) return cmp;
          }
          return 0;
        })
        .slice(0, selection.limit);
      result.notes.push(
        `Explicit deterministic point selection: ${measured.length} of ${completeRows} complete observations, after filtering; not a random sample.`,
      );
    } else if (plan.type !== 'histogram' && measured.length > 10000) {
      throw new Fault(
        'CHART_POINTS',
        'More than 10,000 complete points require an explicit bounded ordering/limit or a grouped relationship chart. No silent sampling was applied.',
      );
    }
    if (plan.type === 'bubble' && measured.some((row) => Number(row[plan.measureColumnIds[2]]) < 0))
      throw new Fault(
        'CHART_NEGATIVE_SIZE',
        'Bubble sizes cannot be negative. Choose a nonnegative size measure or apply an explicit filter.',
      );
    result.rows = measured.map((row) =>
      Object.fromEntries(plan.measureColumnIds.map((id, index) => [`measure${index}`, row[id]])),
    );
    if (plan.histogram && measured.length) {
      const id = plan.measureColumnIds[0];
      const minimum = measured.reduce((min, row) => Math.min(min, Number(row[id])), Infinity);
      const maximum = measured.reduce((max, row) => Math.max(max, Number(row[id])), -Infinity);
      if (plan.histogram.edges) {
        const edges = plan.histogram.edges;
        if (minimum < edges[0] || maximum > edges[edges.length - 1])
          throw new Fault(
            'CHART_BINS_RANGE',
            'Matching observations fall outside the explicit histogram boundaries. Add the requested bounds as filters or extend the bins; no observations were silently dropped.',
          );
        result.histogramBins = edges.slice(0, -1).map((edge, i) => [edge, edges[i + 1]]);
      } else if (minimum === maximum) {
        const halfWidth = Math.max(0.5, Math.abs(minimum) * 0.01);
        result.histogramBins = [[minimum - halfWidth, maximum + halfWidth]];
        result.notes.push(
          'All observations have the same value; one nonzero-width bin contains them.',
        );
      } else {
        const width = (maximum - minimum) / plan.histogram.binCount;
        result.histogramBins = Array.from({ length: plan.histogram.binCount }, (_, index) => [
          minimum + index * width,
          index === plan.histogram!.binCount - 1 ? maximum : minimum + (index + 1) * width,
        ]);
      }
    }
    result.omittedRowCount = rows.length - measured.length;
    result.notes.push(
      plan.type !== 'histogram'
        ? 'Each point is one matching source row; repeated coordinates may overlap. Association does not establish causation.'
        : plan.histogram
          ? 'The histogram counts every nonblank matching observation in explicit bins; supplied boundaries are used exactly and otherwise equal-width boundaries span the observed range.'
          : 'The histogram uses every nonblank matching value; AG Charts chooses frequency bins.',
    );
    if (plan.type === 'bubble')
      result.notes.push(
        'The third measure controls bubble size; zero sizes remain in the API values and may be visually imperceptible.',
      );
    if (rows.length > completeRows)
      result.notes.push(
        `${rows.length - completeRows} matching rows have a blank selected measure and are excluded from this chart.`,
      );
  } else {
    const category = map.get(plan.categoryColumnId!)!;
    const groups = new Map<string | number | null, ChartSourceRow[]>();
    for (const row of rows) {
      const key = bucketOf(row[category.id], plan.timeBucket);
      const group = groups.get(key);
      if (group) group.push(row);
      else groups.set(key, [row]);
    }
    for (const key of timeDomain(plan, bucketOf)) if (!groups.has(key)) groups.set(key, []);
    for (const key of plan.categoryOrder ?? []) if (!groups.has(key)) groups.set(key, []);
    // A time axis may hold many fine buckets (hours of six-second slices); dimensions stay bounded.
    const maxCategories = plan.timeBucket ? CHART_MAX_TIME_BUCKETS : CHART_MAX_CATEGORIES;
    if (groups.size > maxCategories)
      throw new Fault(
        'CHART_CARDINALITY',
        `This chart has more than ${maxCategories.toLocaleString('en-US')} categories. Use a coarser time bucket or a narrower filter.`,
      );
    result.columns = [
      { id: 'category', label: category.label, dataType: 'category', sourceColumnId: category.id },
      ...(plan.measureColumnIds.length
        ? plan.measureColumnIds.map((id, index) => ({
            id: `measure${index}`,
            label: `${plan.aggregation!.toUpperCase()} ${map.get(id)!.label}`,
            dataType: 'series' as const,
            sourceColumnId: id,
            unit: plan.aggregation === 'count' ? 'rows' : metadata.get(id)!.unit,
            aggregation: plan.aggregation,
          }))
        : [
            {
              id: 'measure0',
              label: 'Matching rows',
              dataType: 'series' as const,
              sourceColumnId: null,
              unit: 'rows',
              aggregation: 'count' as const,
            },
          ]),
    ];
    let blankLabel = '(Blank)';
    while (groups.has(blankLabel)) blankLabel = `(${blankLabel})`;
    result.rows = [...groups]
      .sort(([a], [b]) => {
        if (plan.categoryOrder) {
          const ai = plan.categoryOrder.indexOf(a!),
            bi = plan.categoryOrder.indexOf(b!);
          if (ai !== bi && (ai >= 0 || bi >= 0)) return ai < 0 ? 1 : bi < 0 ? -1 : ai - bi;
        }
        return compareChartValues(a, b);
      })
      .map(([key, group]) => ({
        category: key === null ? blankLabel : key,
        ...(plan.measureColumnIds.length
          ? Object.fromEntries(
              plan.measureColumnIds.map((id, index) => [
                `measure${index}`,
                (plan.timeRange || plan.categoryOrder) &&
                group.length === 0 &&
                ['sum', 'count'].includes(plan.aggregation!)
                  ? 0
                  : aggregate(group, id, plan.aggregation!),
              ]),
            )
          : { measure0: group.length }),
      }));
    result.notes.push(
      plan.aggregation === 'count' && !plan.measureColumnIds.length
        ? 'Counts include every matching source row, including rows with blank measures.'
        : 'Blank numeric observations are excluded independently from each measure; categories with no measured values remain blank.',
    );
    if (FIXED_WIDTH_BUCKETS.has(plan.timeBucket)) {
      // Row values keep the full bucket key; the axis shows the clock time when one day is plotted.
      const keys = result.rows.map((row) => String(row['category']));
      const oneDay = new Set(keys.map((key) => key.slice(0, 10))).size <= 1;
      result.categoryDisplayLabels = Object.fromEntries(
        keys.map((key) => [key, key.length >= 16 ? (oneDay ? key.slice(11) : key.slice(5)) : key]),
      );
    }
    if (category.kind === 'datetime' && plan.timeBucket)
      result.notes.push('Timestamp buckets use UTC calendar boundaries.');
    if (temporalTypes.has(plan.type))
      result.notes.push(
        plan.timeRange
          ? 'Time buckets are ordered chronologically. Absent days in the explicitly requested range are included as zero; observed missing measures remain blank.'
          : 'Time buckets are ordered chronologically. Missing periods are not invented or filled with zero.',
      );
    const values = result.rows.flatMap((row) =>
      result.columns
        .filter((column) => column.dataType === 'series')
        .map((column) => row[column.id]),
    );
    if (
      (proportionTypes.has(plan.type) || plan.type.startsWith('normalized')) &&
      values.some((value) => finite(value) && value < 0)
    )
      throw new Fault(
        'CHART_NEGATIVE_PROPORTION',
        'Pie, donut and percentage charts cannot represent negative values faithfully. Choose a bar chart or apply an explicit filter.',
      );
    if (plan.type.startsWith('normalized'))
      result.notes.push(
        'AG Charts displays each category as percentages of its nonnegative series total. API values remain the original aggregates; zero totals cannot define a percentage.',
      );
    if (proportionTypes.has(plan.type)) {
      result.notes.push(
        'Slice proportions are calculated by AG Charts from the nonnegative API aggregates; null and zero values have no visible slice.',
      );
      if (values.length && !values.some((value) => finite(value) && value > 0))
        result.notes.push('No positive values are available, so this chart has no visible slices.');
    }
    if (plan.type === 'customCombo')
      result.notes.push(
        'Custom series follow the requested chart types. Primary series share the left value axis; each secondary series has its own right value axis. Values remain unchanged; compare axes and units before comparing magnitudes.',
      );
    else if (comboTypes.has(plan.type))
      result.notes.push(
        'The built-in combination chart assigns series in the supplied measure order; measures share a validated unit.',
      );
  }
  result.plottedRowCount = result.rows.length;
  return result;
}

/**
 * A zero-filled time axis without explicit bounds takes them from the filter's lower and upper
 * comparisons on its category column (only AND-connected rules narrow the domain). Without both
 * bounds the chart keeps its observed buckets and fills nothing.
 */
export function resolveChartTimeRange(plan: ChartPlan, filter: Node | null): ChartPlan {
  if (!plan.timeRange || plan.timeRange.start || plan.timeRange.endExclusive) return plan;
  let start: string | undefined, end: string | undefined;
  const visit = (node: Node | null): void => {
    if (!node) return;
    if (node.kind === 'group') {
      if (node.join === 'AND') node.children.forEach(visit);
      return;
    }
    if (
      node.kind !== 'rule' ||
      node.field !== plan.categoryColumnId ||
      typeof node.value !== 'string'
    )
      return;
    if (node.op === 'greaterThanOrEqual' || node.op === 'greaterThan')
      start = start === undefined || node.value > start ? node.value : start;
    if (node.op === 'lessThan' || node.op === 'lessThanOrEqual')
      end = end === undefined || node.value < end ? node.value : end;
  };
  visit(filter);
  if (start === undefined || end === undefined || start >= end) {
    const { timeRange: _unresolved, ...rest } = plan;
    return rest;
  }
  return { ...plan, timeRange: { start, endExclusive: end, fill: 'zero' } };
}
