import { COLUMNS, LIMITS } from './schema.js';
import type { ColumnSpec } from './schema.js';
import type { GridModel, Mode, Node, Operator } from './contracts.js';
import { evaluate, Fault, filterTimestamp, group, leaves, rule, validateNode } from './engine.js';
import { setFilterValues } from './set-filters.js';

type Obj = Record<string, unknown>;
function object(x: unknown): Obj {
  if (!x || typeof x !== 'object' || Array.isArray(x))
    throw new Fault('INVALID_MODEL', 'A filter model must be an object.');
  return x as Obj;
}
function keys(x: Obj, allowed: string[]): void {
  for (const k of Object.keys(x))
    if (!allowed.includes(k))
      throw new Fault('MODEL_PROPERTY', `Unsupported filter model property: ${k}.`);
}
const agType = (c: ColumnSpec) =>
  c.kind === 'date' ? 'dateString' : c.kind === 'datetime' ? 'dateTimeString' : c.kind;
function advanced(n: Node, columns: readonly ColumnSpec[]): Obj {
  if (n.kind === 'group')
    return {
      filterType: 'join',
      type: n.join,
      conditions: n.children.map((c) => advanced(c, columns)),
    };
  if (n.kind === 'set') {
    // AG Grid's Advanced Filter parser rejects [] instead of applying a false/true predicate.
    if (!n.values.length)
      throw new Fault(
        'EMPTY_ADVANCED_SET',
        'Advanced Set Filters need at least one selected value. An empty column Set Filter cannot be represented in Advanced mode.',
      );
    return { filterType: 'set', colId: n.field, type: n.op, values: [...n.values] };
  }
  return {
    filterType: agType(columns.find((c) => c.id === n.field)!),
    colId: n.field,
    type: n.op,
    ...(n.value === null ? {} : { filter: n.value }),
  };
}
function simple(n: Extract<Node, { kind: 'rule' }>, columns: readonly ColumnSpec[]): Obj {
  const c = columns.find((column) => column.id === n.field);
  if (!c) throw new Fault('UNKNOWN_COLUMN', `Column ${n.field} is not permitted.`);
  const isDate = c.kind === 'date' || c.kind === 'datetime';
  return {
    filterType: isDate ? 'date' : c.kind,
    type: n.op,
    ...(n.value === null
      ? {}
      : isDate
        ? { dateFrom: c.kind === 'date' ? `${n.value} 00:00:00` : n.value, dateTo: null }
        : { filter: n.value }),
  };
}
/** The application configures native range options with inRangeInclusive=true. */
function rangeOption(n: Node, columns: readonly ColumnSpec[]): Obj | null {
  if (n.kind !== 'group' || n.join !== 'AND' || n.children.length !== 2) return null;
  const lower = n.children.find((node) => node.kind === 'rule' && node.op === 'greaterThanOrEqual');
  const upper = n.children.find((node) => node.kind === 'rule' && node.op === 'lessThanOrEqual');
  if (
    !lower ||
    !upper ||
    lower.kind !== 'rule' ||
    upper.kind !== 'rule' ||
    lower.field !== upper.field
  )
    return null;
  const column = columns.find((column) => column.id === lower.field);
  if (!column || column.kind === 'text') return null;
  const from = simple(lower, columns),
    to = simple(upper, columns);
  return column.kind === 'number'
    ? { filterType: 'number', type: 'inRange', filter: from['filter'], filterTo: to['filter'] }
    : { filterType: 'date', type: 'inRange', dateFrom: from['dateFrom'], dateTo: to['dateFrom'] };
}
function columnOptions(n: Node, columns: readonly ColumnSpec[]): Obj[] | null {
  if (n.kind === 'rule') return [simple(n, columns)];
  const range = rangeOption(n, columns);
  if (range) return [range];
  if (n.kind !== 'group') return null;
  const options: Obj[] = [];
  for (let index = 0; index < n.children.length; index++) {
    const child = n.children[index];
    // Flattened AND ranges can still be encoded as one native option without dropping rules.
    const pair =
      n.join === 'AND' && index + 1 < n.children.length
        ? rangeOption(group('AND', [child, n.children[index + 1]]), columns)
        : null;
    if (pair) {
      options.push(pair);
      index++;
    } else if (child.kind === 'rule') options.push(simple(child, columns));
    else {
      const nestedRange = rangeOption(child, columns);
      if (!nestedRange) return null;
      options.push(nestedRange);
    }
  }
  return options;
}
function fields(n: Node): string[] {
  return n.kind !== 'group' ? [n.field] : n.children.flatMap(fields);
}

/** No distributive expansion, dropped predicates, mode switching, or global OR hack. */
export function toColumns(
  node: Node,
  columns: readonly ColumnSpec[] = COLUMNS,
  preferSetFilters = false,
): Obj {
  const pieces = node.kind === 'group' && node.join === 'AND' ? node.children : [node];
  const perField = new Map<string, Node[]>();
  for (const piece of pieces) {
    const ids = new Set(fields(piece));
    if (ids.size !== 1)
      throw new Fault(
        'CROSS_COLUMN_OR',
        'This expression requires cross-column OR. Column mode combines columns with ALL / AND.',
        [
          'Switch to Advanced mode, then interpret the request again. No automatic mode switch or approximation is performed.',
        ],
      );
    const id = [...ids][0];
    perField.set(id, [...(perField.get(id) ?? []), piece]);
  }
  const result: Obj = {};
  for (const [id, pieces] of perField) {
    const n = group('AND', pieces);
    const column = columns.find((column) => column.id === id);
    const domain = column && setFilterValues(column, columns);
    if (domain && (preferSetFilters || leaves(n).some((leaf) => leaf.kind === 'set'))) {
      // Exact finite-domain evaluation handles intersections, exclusions and mixed nested joins.
      // Keep []: a column Set Filter with nothing selected must match no rows.
      result[id] = {
        filterType: 'set',
        values: domain.filter((value) => evaluate(n, { [id]: value })),
      };
      continue;
    }
    if (n.kind === 'set') throw new Fault('SET_COLUMN', `Set Filters are not enabled for ${id}.`);
    const options = columnOptions(n, columns);
    if (options?.length === 1) {
      result[id] = options[0];
      continue;
    }
    if (!options)
      throw new Fault(
        'COLUMN_GROUPING',
        `Column mode cannot represent mixed nested AND/OR within ${id}.`,
        ['Use Advanced mode for nested groups.'],
      );
    if (options.length > LIMITS.conditionsPerColumn)
      throw new Fault(
        'COLUMN_LIMIT',
        `${id} requires ${options.length} filter options; column mode permits exactly two at most.`,
        ['Use Advanced mode or reduce the conditions. No predicates were removed.'],
      );
    const first = options[0];
    result[id] = {
      filterType: first['filterType'],
      operator: n.kind === 'group' ? n.join : 'AND',
      conditions: options,
    };
  }
  return result;
}
export function toModel(
  node: Node | null,
  mode: Mode,
  columns: readonly ColumnSpec[] = COLUMNS,
  preferSetFilters = false,
): GridModel {
  if (!node) return mode === 'advanced' ? null : {};
  const n = validateNode(node, columns);
  return mode === 'advanced' ? advanced(n, columns) : toColumns(n, columns, preferSetFilters);
}
export function fromModel(
  input: unknown,
  mode: Mode,
  columns: readonly ColumnSpec[] = COLUMNS,
): Node | null {
  const columnMap = new Map(columns.map((column) => [column.id, column]));
  if (input === null || input === undefined) return null;
  let top = object(input);
  // A chart over the whole dataset needs no filter. Some providers serialize
  // that as an empty top-level AND/OR join, or wrap one condition in a join.
  // An empty join is safe only at the top level. One-child joins at any depth
  // are equivalent to their child; malformed multi-child logic still fails.
  for (
    let unwraps = 0;
    mode === 'advanced' && top['filterType'] === 'join' && unwraps <= LIMITS.depth;
    unwraps++
  ) {
    keys(top, ['filterType', 'type', 'conditions']);
    if (!['AND', 'OR'].includes(String(top['type'])) || !Array.isArray(top['conditions'])) break;
    if (top['conditions'].length === 0) return null;
    if (top['conditions'].length !== 1) break;
    top = object(top['conditions'][0]);
  }
  if (Object.keys(top).length === 0) {
    if (mode === 'columns') return null;
    throw new Fault('INVALID_MODEL', 'An empty advanced model must be null.');
  }
  let count = 0;
  const decode = (value: unknown, depth: number, column?: ColumnSpec): Node => {
    if (depth > LIMITS.depth) throw new Fault('TOO_DEEP', 'The filter model is nested too deeply.');
    const obj = object(value);
    if (!column && obj['filterType'] === 'join') {
      keys(obj, ['filterType', 'type', 'conditions']);
      if (
        ['AND', 'OR'].includes(String(obj['type'])) &&
        Array.isArray(obj['conditions']) &&
        obj['conditions'].length === 1
      )
        return decode(obj['conditions'][0], depth + 1);
      if (
        !['AND', 'OR'].includes(String(obj['type'])) ||
        !Array.isArray(obj['conditions']) ||
        obj['conditions'].length < 2 ||
        obj['conditions'].length > LIMITS.leaves
      )
        throw new Fault('INVALID_JOIN', 'Invalid advanced Boolean group.');
      return group(
        obj['type'] as 'AND' | 'OR',
        obj['conditions'].map((n) => decode(n, depth + 1)),
      );
    }
    if (column && obj['conditions'] !== undefined) {
      keys(obj, ['filterType', 'operator', 'conditions']);
      const expected = ['date', 'datetime'].includes(column.kind) ? 'date' : column.kind;
      if (
        obj['filterType'] !== expected ||
        !['AND', 'OR'].includes(String(obj['operator'])) ||
        !Array.isArray(obj['conditions']) ||
        obj['conditions'].length < 1 ||
        obj['conditions'].length > 2
      )
        throw new Fault(
          'COLUMN_LIMIT',
          'Column groups must contain one or two predicates with a single AND/OR operator.',
        );
      return group(
        obj['operator'] as 'AND' | 'OR',
        obj['conditions'].map((n) => {
          if (object(n)['conditions'] !== undefined)
            throw new Fault('COLUMN_GROUPING', 'Nested column groups are unsupported.');
          return decode(n, depth + 1, column);
        }),
      );
    }
    if (++count > LIMITS.leaves) throw new Fault('TOO_MANY_RULES', 'Too many filter conditions.');
    if (obj['filterType'] === 'set') {
      keys(obj, column ? ['filterType', 'values'] : ['filterType', 'colId', 'type', 'values']);
      const c = column ?? columnMap.get(String(obj['colId']));
      if (!c)
        throw new Fault(
          'UNKNOWN_COLUMN',
          'The Set Filter references a column outside the allowed dataset.',
        );
      if (!Array.isArray(obj['values']) || (!column && obj['values'].length === 0))
        throw new Fault(
          'SET_VALUES',
          'A native Advanced Set Filter needs a nonempty values list; column Set Filters permit an empty list.',
        );
      return {
        kind: 'set',
        field: c.id,
        op: (column ? 'isAnyOf' : obj['type']) as 'isAnyOf' | 'isNoneOf',
        values: obj['values'] as (string | null)[],
      };
    }
    keys(
      obj,
      column
        ? ['filterType', 'type', 'filter', 'filterTo', 'dateFrom', 'dateTo']
        : ['filterType', 'colId', 'type', 'filter', 'filterTo'],
    );
    const c = column ?? columnMap.get(String(obj['colId']));
    if (!c)
      throw new Fault(
        'UNKNOWN_COLUMN',
        'The filter references a column outside the allowed dataset.',
      );
    const expected = column ? (['date', 'datetime'].includes(c.kind) ? 'date' : c.kind) : agType(c);
    if (obj['filterType'] !== expected)
      throw new Fault('FILTER_TYPE', `Wrong filter type for ${c.id}.`);
    if (column)
      keys(
        obj,
        c.kind === 'date' || c.kind === 'datetime'
          ? ['filterType', 'type', 'dateFrom', 'dateTo']
          : ['filterType', 'type', 'filter', 'filterTo'],
      );
    const op = obj['type'] as Operator | 'inRange';
    if (op !== 'inRange' && (obj['filterTo'] != null || obj['dateTo'] != null))
      throw new Fault('INVALID_RANGE', 'Only a range filter may carry an upper bound.');
    const normalize = (value: unknown): unknown => {
      if (c.kind === 'date' && typeof value === 'string' && column) {
        if (/^\d{4}-\d{2}-\d{2}(?:[ T]00:00:00)?$/.test(value)) return value.slice(0, 10);
        throw new Fault(
          'DATE_TIME_MISMATCH',
          'A calendar-date filter cannot carry a non-midnight timestamp.',
        );
      }
      if (c.kind === 'datetime' && typeof value === 'string')
        return filterTimestamp(
          column && /^\d{4}-\d{2}-\d{2}$/.test(value) ? value + ' 00:00:00' : value,
        );
      return value;
    };
    if (op === 'inRange') {
      if (c.kind === 'text')
        throw new Fault('UNSUPPORTED_RANGE', 'Ranges require a numeric, date or datetime column.');
      const from = normalize(column && c.kind !== 'number' ? obj['dateFrom'] : obj['filter']);
      const to = normalize(column && c.kind !== 'number' ? obj['dateTo'] : obj['filterTo']);
      if (from == null || to == null)
        throw new Fault('INVALID_RANGE', 'A range needs both lower and upper bounds.');
      return group('AND', [
        rule(c.id, 'greaterThanOrEqual', from as string | number),
        rule(c.id, 'lessThanOrEqual', to as string | number),
      ]);
    }
    let v = column && ['date', 'datetime'].includes(c.kind) ? obj['dateFrom'] : obj['filter'];
    if (op === 'blank' || op === 'notBlank') {
      if (v != null)
        throw new Fault('INVALID_VALUE', 'A blank predicate cannot carry a comparison value.');
      v = null;
    }
    // AG Grid canonicalizes Advanced Filter timestamps with T as well as date column models.
    // Keep one UTC representation in the validation/SQL engine for both filter modes.
    v = normalize(v);
    return rule(c.id, op, v as string | number | null);
  };
  let node: Node;
  if (mode === 'advanced') node = decode(top, 1);
  else {
    if (Object.keys(top).length > columns.length)
      throw new Fault('UNKNOWN_COLUMN', 'Too many column filters.');
    node = group(
      'AND',
      Object.entries(top).map(([id, v]) => {
        const c = columnMap.get(id);
        if (!c) throw new Fault('UNKNOWN_COLUMN', `Column ${id} is not permitted.`);
        return decode(v, 1, c);
      }),
    );
  }
  const valid = validateNode(node, columns);
  if (mode === 'columns') toColumns(valid, columns);
  return valid;
}
