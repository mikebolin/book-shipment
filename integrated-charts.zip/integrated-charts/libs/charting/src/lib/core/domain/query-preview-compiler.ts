import { z } from 'zod';
import {
  UNCONFIGURED_SQL_DATASET,
  quoteSqlIdentifier,
  validateSqlDataset,
  type SqlDataset,
} from './sql-dataset.js';
import {
  CALCULATION_LIMITS,
  calculatedColumnSpec,
  type CalculatedColumnDefinition,
  type CalculationExpression,
} from './calculated-columns.js';
import type { Node } from './contracts.js';
import { Fault } from './engine.js';
import { fromModel } from './grid-model.js';
import type { QueryPreviewRequest, QueryPreviewResponse } from './query-preview.js';
import { compileSetPredicate, compileSql } from './sql.js';

export const queryPreviewRequestSchema = z
  .object({
    mode: z.enum(['advanced', 'columns']),
    filterModel: z.record(z.unknown()).nullable(),
    sortModel: z
      .array(z.object({ colId: z.string().max(100), sort: z.enum(['asc', 'desc']) }).strict())
      .max(3),
    calculatedColumnIds: z
      .array(z.string().regex(/^calc_[A-Za-z0-9_-]{1,70}$/))
      .max(CALCULATION_LIMITS.columns)
      .optional(),
  })
  .strict();

type Fragment = { sql: string; binds: unknown[] };
const quote = quoteSqlIdentifier;

/**
 * A preview-only Snowflake compiler for the actual applied grid model. The HTTP caller must
 * resolve immutable calculated definitions for the local workspace before calling this.
 * No model-generated SQL, user table names, labels, or physical column mappings are accepted.
 */
export function compileQueryPreview(
  input: QueryPreviewRequest,
  tenant: string,
  definitions: readonly CalculatedColumnDefinition[] = [],
  dataset: SqlDataset = UNCONFIGURED_SQL_DATASET,
  unpaged = false,
): QueryPreviewResponse {
  validateSqlDataset(dataset);
  const baseColumns = dataset.columns;
  const baseColumnMap = new Map(baseColumns.map((column) => [column.id, column]));
  const request = queryPreviewRequestSchema.parse(input);
  const ids = request.calculatedColumnIds ?? [];
  if (
    definitions.length > CALCULATION_LIMITS.columns ||
    new Set(ids).size !== ids.length ||
    definitions.length !== ids.length ||
    definitions.some((column, index) => column.id !== ids[index])
  )
    throw new Fault(
      'CALCULATED_COLUMNS',
      'Only the approved calculated columns for this request may be previewed.',
    );
  const columns = [
    ...baseColumns,
    ...definitions.map((column) => calculatedColumnSpec(column, baseColumns)),
  ];
  const columnMap = new Map(columns.map((column) => [column.id, column]));
  const sort = request.sortModel;
  if (
    new Set(sort.map((item) => item.colId)).size !== sort.length ||
    sort.some((item) => !columnMap.has(item.colId))
  )
    throw new Fault(
      'SORT',
      'Source-row SQL can be sorted only by permitted source or calculated columns.',
    );
  const node = fromModel(request.filterModel, request.mode, columns);
  if (!definitions.length)
    return {
      ...compileSql(node, tenant, sort, 0, 100, dataset, unpaged),
      scope: 'filtered-source-rows',
    };

  const binds: unknown[] = [tenant];
  const ctes = [
    `"SCOPED_ROWS" AS (SELECT ${baseColumns.map((column) => `${quote(column.sql)} AS ${quote(column.id)}`).join(', ')} FROM ${dataset.table.map(quote).join('.')} WHERE ${quote(dataset.tenantColumn)} = ?)`,
  ];
  let source = 'SCOPED_ROWS';
  let operation = 0;
  // Snowflake FLOAT is IEEE-754 double precision and compares NaN equal to NaN.
  // Each arithmetic stage is sanitized before its parent, preserving null propagation
  // even for expressions such as 1 / (an overflowing multiplication).
  const finite = (sql: string) =>
    `IFF(${sql} IN (CAST('NaN' AS DOUBLE), CAST('inf' AS DOUBLE), CAST('-inf' AS DOUBLE)), NULL, ${sql})`;
  const calculation = (expression: CalculationExpression): Fragment => {
    if (expression.kind === 'number')
      return { sql: 'CAST(? AS DOUBLE)', binds: [expression.value] };
    if (expression.kind === 'field') {
      if (baseColumnMap.get(expression.field)?.kind !== 'number')
        throw new Fault(
          'CALCULATION_FIELD',
          'Only numeric source fields can be compiled in a calculation.',
        );
      return { sql: finite(`CAST(${quote(expression.field)} AS DOUBLE)`), binds: [] };
    }
    const left = calculation(expression.left);
    const right = calculation(expression.right);
    const symbol = { add: '+', subtract: '-', multiply: '*', divide: '/' }[expression.operator];
    const denominator = expression.operator === 'divide' ? `NULLIF(${right.sql}, 0)` : right.sql;
    const index = operation++;
    const raw = `__preview_raw_${index}`;
    const value = `__preview_value_${index}`;
    const rawStage = `CALCULATION_${index}`;
    const finiteStage = `FINITE_CALCULATION_${index}`;
    ctes.push(
      `${quote(rawStage)} AS (SELECT *, (${left.sql} ${symbol} ${denominator}) AS ${quote(raw)} FROM ${quote(source)})`,
    );
    binds.push(...left.binds, ...right.binds);
    ctes.push(
      `${quote(finiteStage)} AS (SELECT *, ${finite(quote(raw))} AS ${quote(value)} FROM ${quote(rawStage)})`,
    );
    source = finiteStage;
    return { sql: quote(value), binds: [] };
  };
  const projections = definitions.map((definition) => ({
    id: definition.id,
    value: calculation(definition.expression),
  }));
  ctes.push(
    `"DERIVED_ROWS" AS (SELECT *, ${projections.map(({ id, value }) => `${value.sql} AS ${quote(id)}`).join(', ')} FROM ${quote(source)})`,
  );
  for (const projection of projections) binds.push(...projection.value.binds);

  const parameter = (value: unknown) => {
    binds.push(value);
    return '?';
  };
  const filter = (node: Node): string => {
    if (node.kind === 'group') return '(' + node.children.map(filter).join(` ${node.join} `) + ')';
    const column = columnMap.get(node.field)!;
    const id = quote(column.id);
    if (node.kind === 'set') return compileSetPredicate(node, id, parameter);
    if (node.op === 'blank') return `${id} IS NULL`;
    if (node.op === 'notBlank') return `${id} IS NOT NULL`;
    const lhs = column.kind === 'text' ? `LOWER(${id})` : id;
    let value = column.kind === 'text' ? String(node.value).toLowerCase() : node.value;
    if (['contains', 'notContains', 'startsWith', 'endsWith'].includes(node.op)) {
      value = String(value).replace(/[!%_]/g, (character) => '!' + character);
      if (node.op === 'contains' || node.op === 'notContains' || node.op === 'endsWith')
        value = '%' + value;
      if (node.op === 'contains' || node.op === 'notContains' || node.op === 'startsWith')
        value += '%';
      return `${lhs} ${node.op === 'notContains' ? 'NOT LIKE' : 'LIKE'} ${parameter(value)} ESCAPE '!'`;
    }
    const comparisons: Record<string, string> = {
      equals: '=',
      notEqual: '<>',
      greaterThan: '>',
      greaterThanOrEqual: '>=',
      lessThan: '<',
      lessThanOrEqual: '<=',
    };
    const operator = comparisons[node.op];
    if (!operator) throw new Fault('OPERATOR', 'Unsupported SQL operator.');
    const rhs = parameter(value);
    return `${lhs} ${operator} ${column.kind === 'date' ? `TO_DATE(${rhs}, 'YYYY-MM-DD')` : column.kind === 'datetime' ? `TO_TIMESTAMP_NTZ(${rhs}, 'YYYY-MM-DD HH24:MI:SS')` : rhs}`;
  };
  const where = node ? ` WHERE ${filter(node)}` : '';
  const order = [
    ...sort,
    ...(sort.some((item) => item.colId === dataset.rowIdColumn)
      ? []
      : [{ colId: dataset.rowIdColumn, sort: 'asc' as const }]),
  ];
  const prefix = `WITH ${ctes.join(',\n')}\n`;
  const from = ` FROM "DERIVED_ROWS"${where}`;
  const countBinds = [...binds];
  return {
    sql: `${prefix}SELECT ${columns.map((column) => quote(column.id)).join(', ')}${from}${unpaged ? '' : ` ORDER BY ${order.map((item) => `${quote(item.colId)} ${item.sort.toUpperCase()} NULLS LAST`).join(', ')} LIMIT ? OFFSET ?`}`,
    binds: unpaged ? [...binds] : [...binds, 100, 0],
    countSql: `${prefix}SELECT COUNT(*) AS "rowCount"${from}`,
    countBinds,
    scope: 'filtered-source-rows',
  };
}
