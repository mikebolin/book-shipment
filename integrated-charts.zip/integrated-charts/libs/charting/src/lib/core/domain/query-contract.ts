import type { GridModel, Mode } from './contracts.js';
import { fromModel } from './grid-model.js';
import { compileSql, type Sort } from './sql.js';
import type { SqlDataset } from './sql-dataset.js';

export interface ExecuteQueryRequest {
  schemaVersion: string;
  mode: Mode;
  request: { startRow: number; endRow: number; filterModel: GridModel; sortModel: Sort[] };
  compiled: ReturnType<typeof compileSql>;
}

/** Build a source-row query envelope from the host's explicit schema and mapping. */
export function buildExecuteRequest(
  mode: Mode,
  request: ExecuteQueryRequest['request'],
  tenant: string,
  dataset: SqlDataset,
  schemaVersion: string,
): ExecuteQueryRequest {
  return {
    schemaVersion,
    mode,
    request,
    compiled: compileSql(
      fromModel(request.filterModel, mode, dataset.columns),
      tenant,
      request.sortModel,
      request.startRow,
      request.endRow,
      dataset,
    ),
  };
}
