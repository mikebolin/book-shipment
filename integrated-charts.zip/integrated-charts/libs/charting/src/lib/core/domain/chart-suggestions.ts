import type { GridModel, Mode } from './contracts.js';
import type { ChartColumnMetadata, ChartPlan } from './integrated-chart.js';

export interface ChartSuggestionsRequest {
  mode: Mode;
  filterModel: GridModel;
  calculatedColumnIds?: string[];
}
export interface ChartColumnProfile extends ChartColumnMetadata {
  nonNullCount: number;
  missingCount: number;
  distinctCount: number;
  excludedReason: string | null;
}
export interface ChartSuggestion {
  plan: ChartPlan;
  reason: string;
}
export interface ChartSuggestionsResponse {
  source: 'mock';
  scope: 'filtered-source-rows';
  matchedRowCount: number;
  suggestions: ChartSuggestion[];
  profiles: ChartColumnProfile[];
  notes: string[];
}
