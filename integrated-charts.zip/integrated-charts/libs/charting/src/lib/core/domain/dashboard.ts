import type { GridModel, Mode } from './contracts.js';

export const DASHBOARD_TEMPLATES = ['portfolio', 'financial', 'market'] as const;
export type DashboardTemplate = (typeof DASHBOARD_TEMPLATES)[number];
export const DASHBOARD_PERIODS = Array.from(
  { length: 12 },
  (_, quarter) => `${2024 + Math.floor(quarter / 4)}Q${(quarter % 4) + 1}`,
);
export const DASHBOARD_DEFAULT_PERIOD = '2026Q3';

/** A reviewed plan chooses a fixed renderer; it never contains executable code. */
export interface DashboardPlan {
  template: DashboardTemplate;
  period: string | null;
}

export interface DashboardRequest {
  template: DashboardTemplate;
  mode: Mode;
  filterModel: GridModel;
  calculatedColumnIds?: string[];
  /** Compact calendar-quarter identifier, e.g. 2026Q3, for the financial template only. */
  period?: string;
}

export type DashboardFormat = 'currency' | 'number' | 'percent';
export interface DashboardMetric {
  id: string;
  label: string;
  /** null means that no valid numeric observation exists; percentages use 0–100 units. */
  value: number | null;
  format: DashboardFormat;
}

export interface DashboardSeries {
  id: string;
  label: string;
  format: DashboardFormat;
  /** Values correspond to chart categories by index. */
  values: (number | null)[];
}

export interface DashboardChart {
  id: string;
  title: string;
  kind: 'bar' | 'line';
  categories: string[];
  series: DashboardSeries[];
}

export interface DashboardResponse {
  template: DashboardTemplate;
  title: string;
  subtitle: string;
  period?: string;
  matchedAccountCount: number;
  source: 'mock';
  scope: 'filtered-source-rows';
  metrics: DashboardMetric[];
  charts: DashboardChart[];
  observations: string[];
  notes: string[];
}
