export interface WorkspacePreview {
  schemaVersion: 1;
  type: 'chart' | 'summary' | 'dashboard';
  title?: string;
  label?: string;
  value?: string | number;
  columns?: { id: string; label: string; dataType: string }[];
  rows?: Record<string, unknown>[];
  chartType?: string;
  totalRows?: number;
  items?: { x: number; y: number; w: number; h: number; displayMode?: string; kind?: string }[];
}
export interface WorkspaceCard {
  canEdit?: boolean;
  canManage?: boolean;
  canDelete?: boolean;
  visibility?: 'private' | 'shared';
  id: string;
  slug: string;
  name: string;
  description: string;
  modelId?: string | null;
  modelName?: string;
  modelSlug?: string;
  version: number;
  publishedVersion: number | null;
  updatedAt: string;
  preview?: WorkspacePreview | null;
  group?: string;
  tags?: string[];
  itemCount?: number;
  chartCount?: number;
}
