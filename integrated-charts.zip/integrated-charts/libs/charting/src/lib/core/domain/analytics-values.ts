import type { ColumnSpec } from './schema';
import { Fault, filterTimestamp, plainDate } from './engine';
import { BLANK_GROUP_KEY } from './analytics-query';

export function decodeAnalyticsGroupKey(key: string | number | null): string | number | null {
  if (key === null || key === BLANK_GROUP_KEY) return null;
  return typeof key === 'string' && key.startsWith('\\') ? key.slice(1) : key;
}

/** Group routes and pivot discovery retain case, unlike case-insensitive filter operands. */
export function normalizeAnalyticsValue(
  value: string | number | null,
  column: ColumnSpec,
): string | number | null {
  if (value === null) return null;
  if (column.kind === 'number') {
    if (typeof value === 'string' && !/^-?(?:\d+(?:\.\d+)?|\.\d+)(?:e[+-]?\d+)?$/i.test(value))
      throw new Fault('GROUP_KEY', 'A numeric group key must be a plain finite number.');
    const number = typeof value === 'number' ? value : Number(value);
    if (!Number.isFinite(number) || (Number.isInteger(number) && !Number.isSafeInteger(number)))
      throw new Fault(
        'GROUP_KEY',
        'A numeric group key must be finite and preserve its precision.',
      );
    return number;
  }
  if (typeof value !== 'string')
    throw new Fault('GROUP_KEY', `${column.label} requires a string group or pivot key.`);
  if (column.kind === 'date') return plainDate(value);
  if (column.kind === 'datetime') return filterTimestamp(value);
  return value;
}
