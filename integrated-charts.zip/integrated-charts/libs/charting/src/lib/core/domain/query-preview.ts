import type { GridModel, Mode } from './contracts.js';
import type { Sort } from './sql.js';

export interface QueryPreviewRequest {
  mode: Mode;
  filterModel: GridModel;
  sortModel: Sort[];
  calculatedColumnIds?: string[];
}

/** Source rows before SSRM grouping/pivoting; this contract never executes the generated SQL. */
export interface QueryPreviewResponse {
  sql: string;
  binds: unknown[];
  countSql: string;
  countBinds: unknown[];
  scope: 'filtered-source-rows';
}
