import { COLUMNS, type ColumnSpec } from './schema.js';
import {
  validateCalculationDraft,
  type CalculationDraft,
  type CalculationExpression,
} from './calculated-columns.js';
import { Fault } from './engine.js';

/** Native dialog expressions are data. This deliberately never evaluates JavaScript. */
export function parseNativeCalculation(
  input: {
    label: string;
    expression: string;
  },
  columns: readonly ColumnSpec[] = COLUMNS,
): CalculationDraft {
  if (typeof input.expression !== 'string' || input.expression.length > 2000)
    throw new Fault(
      'CALCULATION_FORMAT',
      'Keep the calculated expression within 2,000 characters.',
    );
  const expression = input.expression.trim();
  let offset = 0;
  let nesting = 0;
  let nodes = 0;
  const invalid = () =>
    new Fault(
      'CALCULATION_FORMAT',
      'Use numeric source columns in brackets, numbers, parentheses, and +, -, *, or /. Functions and cross-row references are not available in the server calculation adapter yet.',
    );
  const whitespace = () => {
    while (/\s/.test(expression[offset] ?? '') && offset < expression.length) offset++;
  };
  const node = (value: CalculationExpression): CalculationExpression => {
    // Bound parser work before the common AST validator applies the tighter depth limit.
    if (++nodes > 31)
      throw new Fault('CALCULATION_LIMIT', 'The calculated expression is too complex.');
    return value;
  };
  const binary = (
    operator: 'add' | 'subtract' | 'multiply' | 'divide',
    left: CalculationExpression,
    right: CalculationExpression,
  ) => node({ kind: 'binary', operator, left, right });
  const primary = (): CalculationExpression => {
    whitespace();
    if (++nesting > 32)
      throw new Fault('CALCULATION_LIMIT', 'The calculated expression is too complex.');
    let result: CalculationExpression;
    const sign = expression[offset];
    if (sign === '+' || sign === '-') {
      offset++;
      const child = primary();
      if (sign === '+') result = child;
      else if (child.kind === 'number') result = { kind: 'number', value: -child.value };
      else result = binary('subtract', node({ kind: 'number', value: 0 }), child);
    } else if (expression[offset] === '(') {
      offset++;
      result = addition();
      whitespace();
      if (expression[offset++] !== ')') throw invalid();
    } else if (expression[offset] === '[') {
      const end = expression.indexOf(']', ++offset);
      if (end < 0) throw invalid();
      const field = expression.slice(offset, end);
      if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(field)) throw invalid();
      offset = end + 1;
      result = node({ kind: 'field', field });
    } else {
      const match = expression.slice(offset).match(/^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/);
      if (!match) throw invalid();
      offset += match[0].length;
      result = node({ kind: 'number', value: Number(match[0]) });
    }
    nesting--;
    return result;
  };
  const multiplication = (): CalculationExpression => {
    let result = primary();
    whitespace();
    while (expression[offset] === '*' || expression[offset] === '/') {
      const operator = expression[offset++] === '*' ? 'multiply' : 'divide';
      result = binary(operator, result, primary());
      whitespace();
    }
    return result;
  };
  const addition = (): CalculationExpression => {
    let result = multiplication();
    whitespace();
    while (expression[offset] === '+' || expression[offset] === '-') {
      const operator = expression[offset++] === '+' ? 'add' : 'subtract';
      result = binary(operator, result, multiplication());
      whitespace();
    }
    return result;
  };
  const ast = addition();
  whitespace();
  if (offset !== expression.length) throw invalid();
  return validateCalculationDraft({ label: input.label, expression: ast }, columns);
}
