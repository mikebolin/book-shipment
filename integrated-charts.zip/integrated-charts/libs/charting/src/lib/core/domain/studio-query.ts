import type {
  AnalyticsRowsRequest,
  AnalyticsRowsResponse,
  AnalyticsColumn,
} from './analytics-query';
import { ANALYTICS_LIMITS, analyticsPivotKey } from './analytics-query';
import { createAnalyticsRowsSchema } from './analytics-engine';
import { calculatedColumnSpec, type CalculatedColumnDefinition } from './calculated-columns';
import { compileQueryPreview } from './query-preview-compiler';
import { quoteSqlIdentifier as quote, type SqlDataset } from './sql-dataset';
import { Fault } from './engine';
import type { GridModel, Mode } from './contracts';
import { decodeAnalyticsGroupKey, normalizeAnalyticsValue } from './analytics-values';

export type SqlValue = string | number | null;
export interface SqlStatement {
  sql: string;
  binds: unknown[];
}
export interface StudioQuery {
  request: AnalyticsRowsRequest;
  rows: SqlStatement;
  count: SqlStatement;
  matching: SqlStatement;
  total: SqlStatement;
  grandTotal?: SqlStatement;
  groupField?: string;
  pivotResultFields?: string[];
  summarized: boolean;
}
export interface StudioQueryResult extends AnalyticsRowsResponse {
  matchedRowCount: number;
  totalRowCount: number;
}
export const STUDIO_SUMMARY_BUCKET_SECONDS = [6, 10, 15, 30, 60, 300, 900, 1800, 3600] as const;
export type StudioSummaryBucketSeconds = (typeof STUDIO_SUMMARY_BUCKET_SECONDS)[number];
/** One compact chart summary per refresh: counts per time bucket and dimension tuple. */
export interface StudioSummaryRequest {
  mode: Mode;
  filterModel: GridModel;
  calculatedColumnIds?: string[];
  /** A datetime field truncated to fixed-size UTC buckets. */
  bucket: { field: string; seconds: StudioSummaryBucketSeconds };
  /** Text or date fields that split every bucket further; at most the grouping limit. */
  dimensions: string[];
}
export interface StudioSummaryStatement extends SqlStatement {
  request: StudioSummaryRequest;
}
/** `__bucket` is the bucket start as UTC `YYYY-MM-DD HH:mm:ss`; `__count` is COUNT(*). */
export type StudioSummaryRow = Record<string, SqlValue> & { __bucket: string; __count: number };
/** Host transport metadata. The API must resolve its own approved source and authenticated tenant. */
export interface StudioExecutionContext {
  sourceId?: string;
  tenant: string;
  dataset: SqlDataset;
  definitions: readonly CalculatedColumnDefinition[];
}
/** Angular compiles every grid statement; the host can provide its JDBC API transport here. */
export interface StudioQueryExecutor {
  execute(
    query: StudioQuery,
    signal: AbortSignal,
    context?: StudioExecutionContext,
  ): Promise<StudioQueryResult>;
  discoverPivots(
    statement: SqlStatement,
    request: AnalyticsRowsRequest,
    signal: AbortSignal,
    context?: StudioExecutionContext,
  ): Promise<SqlValue[][]>;
  /** Runs a compiled chart summary. Map result labels to `__bucket`, each dimension and `__count`. */
  summarize(
    statement: StudioSummaryStatement,
    signal: AbortSignal,
    context?: StudioExecutionContext,
  ): Promise<StudioSummaryRow[]>;
}

export function decodeGroupKey(key: SqlValue): SqlValue {
  return decodeAnalyticsGroupKey(key);
}

function sourceQuery(
  input: AnalyticsRowsRequest,
  tenant: string,
  dataset: SqlDataset,
  definitions: readonly CalculatedColumnDefinition[],
) {
  const columns = [
    ...dataset.columns,
    ...definitions.map((d) => calculatedColumnSpec(d, dataset.columns)),
  ];
  if (columns.some((c) => c.id === '__groupCount'))
    throw new Fault('COLUMN', '__groupCount is reserved.');
  const request = createAnalyticsRowsSchema(columns).parse(input);
  const source = compileQueryPreview(
    {
      mode: request.mode,
      filterModel: request.request.filterModel,
      sortModel: [],
      calculatedColumnIds: request.calculatedColumnIds,
    },
    tenant,
    definitions,
    dataset,
    true,
  );
  return { request, columns, source, prefix: `WITH "SOURCE_ROWS" AS (${source.sql})` };
}

/** Pivot discovery is bounded and uses the whole filtered scope, not an expanded route. */
export function compileStudioPivotDiscovery(
  input: AnalyticsRowsRequest,
  tenant: string,
  dataset: SqlDataset,
  definitions: readonly CalculatedColumnDefinition[] = [],
): SqlStatement {
  const {
    request: { request: r },
    source,
    prefix,
  } = sourceQuery(input, tenant, dataset, definitions);
  if (!r.pivotMode || !r.pivotCols.length)
    throw new Fault('PIVOT', 'No pivot dimensions selected.');
  const fields = r.pivotCols.map((c) => quote(c.id)).join(', ');
  const limit = Math.floor(ANALYTICS_LIMITS.pivotFields / r.valueCols.length) + 1;
  return {
    sql: `${prefix}\nSELECT DISTINCT ${fields} FROM "SOURCE_ROWS" ORDER BY ${r.pivotCols.map((c) => `${quote(c.id)} ASC NULLS LAST`).join(', ')} LIMIT ?`,
    binds: [...source.binds, limit],
  };
}

/** Group-before-page SQL over a mapped, filtered and calculated source relation. */
export function compileStudioQuery(
  input: AnalyticsRowsRequest,
  tenant: string,
  dataset: SqlDataset,
  definitions: readonly CalculatedColumnDefinition[] = [],
  pivotValues: SqlValue[][] = [],
): StudioQuery {
  const { request, columns, source, prefix } = sourceQuery(input, tenant, dataset, definitions);
  const r = request.request;
  const columnMap = new Map(columns.map((c) => [c.id, c]));
  const group = r.rowGroupCols[r.groupKeys.length];
  const pivoting = r.pivotMode && r.pivotCols.length > 0;
  const summarized = !!group || pivoting || (r.pivotMode && r.valueCols.length > 0);
  if (pivotValues.length * r.valueCols.length > ANALYTICS_LIMITS.pivotFields)
    throw new Fault(
      'PIVOT_LIMIT',
      `Choose fewer pivot dimensions; at most ${ANALYTICS_LIMITS.pivotFields} result fields are allowed.`,
    );
  const pivots = pivoting
    ? pivotValues
        .map((tuple) => {
          if (
            tuple.length !== r.pivotCols.length ||
            tuple.some((v) => v !== null && typeof v !== 'string' && typeof v !== 'number')
          )
            throw new Fault('PIVOT', 'Invalid pivot discovery result.');
          const normalized = tuple.map((value, index) =>
            normalizeAnalyticsValue(value, columnMap.get(r.pivotCols[index].id)!),
          );
          return { tuple: normalized, key: normalized.map(analyticsPivotKey).join('|') };
        })
        .sort((a, b) => (a.key < b.key ? -1 : a.key > b.key ? 1 : 0))
    : [];
  if (new Set(pivots.map((p) => p.key)).size !== pivots.length)
    throw new Fault('PIVOT', 'Duplicate pivot keys.');
  const pivotResultFields = pivots.flatMap((p) => r.valueCols.map((c) => p.key + '|' + c.id));
  const routeBinds: unknown[] = [];
  const equality = (id: string, value: SqlValue, binds: unknown[]) => {
    value = normalizeAnalyticsValue(value, columnMap.get(id)!);
    if (value === null) return `${quote(id)} IS NULL`;
    const kind = columnMap.get(id)!.kind;
    binds.push(value);
    return `${quote(id)} = ${kind === 'date' ? "TO_DATE(?, 'YYYY-MM-DD')" : kind === 'datetime' ? "TO_TIMESTAMP_NTZ(?, 'YYYY-MM-DD HH24:MI:SS')" : '?'}`;
  };
  const route = r.groupKeys.map((key, index) =>
    equality(r.rowGroupCols[index].id, decodeGroupKey(key), routeBinds),
  );
  const routeSql = `${prefix},\n"ROUTE_ROWS" AS (SELECT * FROM "SOURCE_ROWS"${route.length ? ' WHERE ' + route.join(' AND ') : ''})`;
  const aggregate = (column: AnalyticsColumn, binds: unknown[], tuple?: SqlValue[]) => {
    const condition = tuple
      ?.map((value, i) => equality(r.pivotCols[i].id, value, binds))
      .join(' AND ');
    if (column.aggFunc === 'count')
      return condition ? `COUNT(IFF(${condition}, 1, NULL))` : 'COUNT(*)';
    if (column.aggFunc === 'first' || column.aggFunc === 'last') {
      const object = `OBJECT_CONSTRUCT_KEEP_NULL('value', ${quote(column.id)})`;
      return `GET(GET(ARRAY_AGG(${condition ? `IFF(${condition}, ${object}, NULL)` : object}) WITHIN GROUP (ORDER BY ${quote(dataset.rowIdColumn)} ${column.aggFunc === 'first' ? 'ASC' : 'DESC'}), 0), 'value')::DOUBLE`;
    }
    const field = condition ? `IFF(${condition}, ${quote(column.id)}, NULL)` : quote(column.id);
    return `${column.aggFunc!.toUpperCase()}(${field})`;
  };
  const projections = (binds: unknown[]) => [
    ...r.valueCols.map((c) => `${aggregate(c, binds)} AS ${quote(c.id)}`),
    ...pivots.flatMap((p) =>
      r.valueCols.map((c) => `${aggregate(c, binds, p.tuple)} AS ${quote(p.key + '|' + c.id)}`),
    ),
  ];
  const aggregateBinds: unknown[] = [];
  const select = summarized
    ? [
        ...(group ? [quote(group.id), 'COUNT(*) AS "__groupCount"'] : []),
        ...projections(aggregateBinds),
      ].join(', ')
    : columns.map((c) => quote(c.id)).join(', ');
  const resultSql = `${routeSql},\n"RESULT_ROWS" AS (SELECT ${select} FROM "ROUTE_ROWS"${group ? ` GROUP BY ${quote(group.id)}` : summarized ? ' HAVING COUNT(*) > 0' : ''})`;
  const binds = [...source.binds, ...routeBinds, ...aggregateBinds];
  const allowed = new Set([...columns.map((c) => c.id), ...pivotResultFields]);
  const sorts = r.sortModel
    .map((s) => {
      if (s.colId === 'ag-Grid-AutoColumn')
        return { ...s, colId: group?.id ?? r.rowGroupCols.at(-1)?.id ?? dataset.rowIdColumn };
      if (s.colId.startsWith('ag-Grid-AutoColumn-')) {
        const id = s.colId.slice('ag-Grid-AutoColumn-'.length);
        if (!r.rowGroupCols.some((c) => c.id === id))
          throw new Fault('SORT', 'Unknown group sort.');
        return { ...s, colId: id };
      }
      if (!allowed.has(s.colId)) throw new Fault('SORT', 'Unknown sort column.');
      return s;
    })
    .filter(
      (s) =>
        !summarized ||
        s.colId === group?.id ||
        r.valueCols.some((c) => c.id === s.colId) ||
        pivotResultFields.includes(s.colId),
    );
  const tie = group?.id ?? (!summarized ? dataset.rowIdColumn : undefined);
  if (tie && !sorts.some((s) => s.colId === tie)) sorts.push({ colId: tie, sort: 'asc' });
  const order = sorts.length
    ? ' ORDER BY ' +
      sorts.map((s) => `${quote(s.colId)} ${s.sort.toUpperCase()} NULLS LAST`).join(', ')
    : '';
  const total = compileQueryPreview(
    { mode: 'advanced', filterModel: null, sortModel: [] },
    tenant,
    [],
    dataset,
    true,
  );
  const grandBinds: unknown[] = [];
  const grandSelect = r.valueCols.length ? projections(grandBinds).join(', ') : '';
  return {
    request,
    groupField: group?.id,
    summarized,
    ...(pivoting ? { pivotResultFields } : {}),
    rows: {
      sql: `${resultSql}\nSELECT * FROM "RESULT_ROWS"${order} LIMIT ? OFFSET ?`,
      binds: [...binds, r.endRow - r.startRow, r.startRow],
    },
    count: {
      sql: `${resultSql}\nSELECT COUNT(*) AS "rowCount" FROM "RESULT_ROWS"`,
      binds: [...binds],
    },
    matching: {
      sql: `${prefix}\nSELECT COUNT(*) AS "matchedRowCount" FROM "SOURCE_ROWS"`,
      binds: [...source.binds],
    },
    total: {
      sql: `WITH "TOTAL_ROWS" AS (${total.sql}) SELECT COUNT(*) AS "totalRowCount" FROM "TOTAL_ROWS"`,
      binds: [...total.binds],
    },
    ...(r.groupKeys.length === 0 && grandSelect
      ? {
          grandTotal: {
            sql: `${prefix}\nSELECT ${grandSelect} FROM "SOURCE_ROWS"`,
            binds: [...source.binds, ...grandBinds],
          },
        }
      : {}),
  };
}

/**
 * Chart-query layer: one bucketed summary over the same filtered source relation as the grid.
 * Every returned row already represents many events, so chart measures sum `__count`.
 * Snowflake's DATE_TRUNC covers one-minute buckets; TIME_SLICE covers wider fixed slices.
 */
export function compileStudioSummary(
  input: StudioSummaryRequest,
  tenant: string,
  dataset: SqlDataset,
  definitions: readonly CalculatedColumnDefinition[] = [],
): StudioSummaryStatement {
  const { columns, source, prefix } = sourceQuery(
    {
      mode: input.mode,
      calculatedColumnIds: input.calculatedColumnIds ?? [],
      request: {
        startRow: 0,
        endRow: 1,
        filterModel: input.filterModel,
        sortModel: [],
        rowGroupCols: [],
        valueCols: [],
        pivotCols: [],
        pivotMode: false,
        groupKeys: [],
      },
    },
    tenant,
    dataset,
    definitions,
  );
  const columnMap = new Map(columns.map((c) => [c.id, c]));
  const bucket = columnMap.get(input.bucket.field);
  if (!bucket || bucket.kind !== 'datetime')
    throw new Fault('SUMMARY_BUCKET', 'Time buckets need a datetime field.');
  if (!STUDIO_SUMMARY_BUCKET_SECONDS.includes(input.bucket.seconds))
    throw new Fault(
      'SUMMARY_BUCKET',
      `Choose ${STUDIO_SUMMARY_BUCKET_SECONDS.join(', ')} second buckets.`,
    );
  if (
    input.dimensions.length > ANALYTICS_LIMITS.groups ||
    new Set(input.dimensions).size !== input.dimensions.length
  )
    throw new Fault(
      'SUMMARY_DIMENSIONS',
      `Choose up to ${ANALYTICS_LIMITS.groups} distinct summary dimensions.`,
    );
  for (const id of input.dimensions) {
    const column = columnMap.get(id);
    if (!column || column.kind === 'number' || id === bucket.id)
      throw new Fault('SUMMARY_DIMENSIONS', 'Summary dimensions must be text or date fields.');
  }
  // The slice length is validated against a fixed list, so it is a literal, not a bind.
  const truncated =
    input.bucket.seconds === 60
      ? `DATE_TRUNC('MINUTE', ${quote(bucket.id)})`
      : input.bucket.seconds === 3600
        ? `DATE_TRUNC('HOUR', ${quote(bucket.id)})`
        : input.bucket.seconds % 60 === 0
          ? `TIME_SLICE(${quote(bucket.id)}, ${input.bucket.seconds / 60}, 'MINUTE')`
          : `TIME_SLICE(${quote(bucket.id)}, ${input.bucket.seconds}, 'SECOND')`;
  const select = [
    `${truncated} AS "__bucket"`,
    ...input.dimensions.map(quote),
    'COUNT(*) AS "__count"',
  ].join(', ');
  const positions = Array.from({ length: input.dimensions.length + 1 }, (_, i) => i + 1);
  return {
    request: input,
    sql: `${prefix}\nSELECT ${select} FROM "SOURCE_ROWS" WHERE ${quote(bucket.id)} IS NOT NULL GROUP BY ${positions.join(', ')} ORDER BY ${positions.map((p) => `${p} ASC NULLS LAST`).join(', ')}`,
    binds: [...source.binds],
  };
}
