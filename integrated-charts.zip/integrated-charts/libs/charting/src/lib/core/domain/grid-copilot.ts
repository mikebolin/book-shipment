import type { GridModel, Mode, Operation } from './contracts.js';
import type { CalculationDraft, CalculatedColumnDefinition } from './calculated-columns.js';
import type { DashboardPlan } from './dashboard.js';
import type { ChartPlan } from './integrated-chart.js';

export const GRID_FEATURES = ['filter', 'sort', 'rowGroup', 'pivot', 'aggregation'] as const;
export type GridFeature = (typeof GRID_FEATURES)[number];
export const AGGREGATIONS = ['sum', 'avg', 'min', 'max', 'count', 'first', 'last'] as const;
export interface GridChatTurn {
  role: 'user' | 'assistant';
  text: string;
}
export interface GridClarificationOption {
  label: string;
  answer: string;
  /** Source-validated alternative that can be reviewed without another model call. */
  chart?: {
    plan: ChartPlan;
    filterModel: GridModel;
    requestScope: 'current' | 'fresh';
    draftId?: string;
  };
  action?: 'open_chart_builder';
}
export interface GridCopilotRequest {
  /** Explicit per-request opt-in. Missing or false always uses the local demo planner. */
  useLiveAi?: boolean;
  text: string;
  mode: Mode;
  operation: Operation;
  currentState: Record<string, unknown>;
  toolkitSchema: Record<string, unknown>;
  calculatedColumnIds?: string[];
  conversation?: GridChatTurn[];
  setFiltersEnabled?: boolean;
  dashboardsEnabled?: boolean;
  chartsEnabled?: boolean;
  /** Explicit user goal; selecting it locally never requires a classification call. */
  workflowIntent?: 'data' | 'chart';
  /** Applied chart context for validated natural-language follow-ups. */
  currentChart?: ChartPlan | null;
  /** Optional unapplied builder scope, separate from the actual confirmation baseline. */
  builderFilterModel?: GridModel;
  /** Fresh planning starts from no query features; changes remain subject to review. */
  requestScope?: 'current' | 'fresh';
  /** Server-owned unapplied proposal, bound to the actual current grid state. */
  draftId?: string;
}
export interface GridConfirmation {
  gridState: Record<string, unknown>;
  propertiesToIgnore: GridFeature[];
  summary: string;
  dashboard?: DashboardPlan | null;
  chart?: ChartPlan | null;
  resetView?: boolean;
}
/** Structured chart creation is deterministic and never invokes a language model. */
export interface ChartProposalRequest {
  plan: ChartPlan;
  mode: Mode;
  currentState: Record<string, unknown>;
  filterModel: GridModel;
  requestScope: 'fresh' | 'current';
  draftId?: string;
  calculatedColumnIds?: string[];
}
export interface CalculatedColumnConfirmation {
  column: CalculatedColumnDefinition;
  plan?: GridConfirmation;
}
export type GridCopilotResult =
  | {
      status: 'needs_input';
      message: string;
      reason?: 'clarification' | 'unsupported' | 'recovery';
      options?: GridClarificationOption[];
      action?: 'open_chart_builder';
      clarificationKind?: 'column';
    }
  | {
      status: 'calculated_column_proposal';
      id: string;
      column: CalculationDraft;
      formula: string;
      plannedColumnId?: string;
      plan?: GridConfirmation & { changes: string[] };
      message: string;
      expiresAt: string;
    }
  | (GridConfirmation & {
      status: 'proposal';
      id: string;
      changes: string[];
      expiresAt: string;
    });
