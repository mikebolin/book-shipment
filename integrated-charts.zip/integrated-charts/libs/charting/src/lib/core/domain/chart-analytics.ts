import { z } from 'zod';
import {
  dimensionSchema,
  windowSchema,
  snapshotSchema,
  extensionJsonSchemas,
  dimensionColumns,
  dimensionRows,
  compareChartValues,
  timeDomain,
} from './chart-extensions.js';
import { Fault } from './engine.js';
import {
  chartColumnMetadata,
  type ChartMetric,
  type ChartPlan,
  type ChartResponse,
} from './integrated-chart.js';
import type { ColumnSpec } from './schema.js';

export const metricIdPattern = '^metric_[A-Za-z0-9_]{1,60}$';
const field = z.string().min(1).max(100);
export const chartAnalyticsSchema = z
  .object({
    dimensions: z.array(dimensionSchema).max(4).optional(),
    windows: z.array(windowSchema).max(4).optional(),
    groupByColumnIds: z.array(field).min(1).max(3).optional(),
    partitionByColumnId: field.nullable().optional(),
    otherLabel: z.string().min(1).max(100).nullable().optional(),
    seriesValues: z
      .array(z.union([z.string().max(256), z.number().finite(), z.null()]))
      .max(12)
      .optional(),
    snapshot: snapshotSchema.nullable().optional(),
    metrics: z
      .array(
        z
          .object({
            id: z.string().regex(new RegExp(metricIdPattern)),
            label: z.string().trim().min(1).max(100),
            operation: z.enum([
              'sum',
              'avg',
              'min',
              'max',
              'count',
              'ratio',
              'percentile',
              'distinct',
              'missingPercent',
            ]),
            blankMode: z.enum(['null', 'nullOrEmpty']).optional(),
            conversion: z.enum(['minutesToHours', 'hoursToMinutes']).optional(),
            columnId: field.nullable(),
            numeratorColumnId: field.nullable(),
            denominatorColumnId: field.nullable(),
            subtractColumnId: field.optional(),
            scale: z.number().finite().nullable(),
            percentile: z.number().min(0).max(100).nullable(),
          })
          .strict(),
      )
      .max(8),
    groupFilter: z
      .array(
        z
          .object({
            metricId: field,
            operator: z.enum([
              'greaterThanOrEqual',
              'greaterThan',
              'lessThanOrEqual',
              'lessThan',
              'equals',
            ]),
            value: z.number().finite(),
          })
          .strict(),
      )
      .max(8),
    orderBy: z.array(z.object({ field, direction: z.enum(['asc', 'desc']) }).strict()).max(4),
    limit: z.number().int().min(1).max(200).nullable(),
    seriesByColumnId: field.nullable(),
  })
  .strict();

export function chartAnalyticsJsonSchema(
  measures: string[],
  categories: string[],
  allFields: string[] = [...measures, ...categories],
) {
  const nullableField = { type: ['string', 'null'], enum: [...measures, null] };
  const object = (properties: Record<string, unknown>) => ({
    type: 'object',
    additionalProperties: false,
    properties,
    required: Object.keys(properties),
  });
  const extensions = extensionJsonSchemas(allFields);
  const result = object({
    ...extensions,
    groupByColumnIds: {
      type: ['array', 'null'],
      minItems: 1,
      maxItems: 3,
      items: {
        anyOf: [
          { type: 'string', enum: categories },
          { type: 'string', pattern: '^dimension_[A-Za-z0-9_]{1,60}$' },
        ],
      },
    },
    partitionByColumnId: { type: ['string', 'null'], enum: [...categories, null] },
    otherLabel: { type: ['string', 'null'], maxLength: 100 },
    seriesValues: {
      type: ['array', 'null'],
      maxItems: 12,
      items: { type: ['string', 'number', 'null'] },
    },
    metrics: {
      type: 'array',
      maxItems: 8,
      items: object({
        id: { type: 'string', pattern: metricIdPattern },
        label: { type: 'string', minLength: 1, maxLength: 100 },
        operation: {
          type: 'string',
          enum: [
            'sum',
            'avg',
            'min',
            'max',
            'count',
            'ratio',
            'percentile',
            'distinct',
            'missingPercent',
          ],
        },
        blankMode: { type: ['string', 'null'], enum: ['null', 'nullOrEmpty', null] },
        conversion: { type: ['string', 'null'], enum: ['minutesToHours', 'hoursToMinutes', null] },
        columnId: { type: ['string', 'null'], enum: [...allFields, null] },
        numeratorColumnId: nullableField,
        denominatorColumnId: nullableField,
        subtractColumnId: nullableField,
        scale: { type: ['number', 'null'] },
        percentile: { type: ['number', 'null'], minimum: 0, maximum: 100 },
      }),
    },
    groupFilter: {
      type: 'array',
      maxItems: 8,
      items: object({
        metricId: { type: 'string' },
        operator: {
          type: 'string',
          enum: ['greaterThanOrEqual', 'greaterThan', 'lessThanOrEqual', 'lessThan', 'equals'],
        },
        value: { type: 'number' },
      }),
    },
    orderBy: {
      type: 'array',
      maxItems: 4,
      items: object({
        field: { type: 'string' },
        direction: { type: 'string', enum: ['asc', 'desc'] },
      }),
    },
    limit: { type: ['integer', 'null'], minimum: 1, maximum: 200 },
    seriesByColumnId: {
      anyOf: [
        { type: 'string', enum: categories },
        { type: 'string', pattern: '^dimension_[A-Za-z0-9_]{1,60}$' },
        { type: 'null' },
      ],
    },
  });
  // Extensions are optional for backwards-compatible manual/API plans.
  result.required = ['metrics', 'groupFilter', 'orderBy', 'limit', 'seriesByColumnId'];
  const metric = (result.properties as any).metrics.items;
  metric.required = metric.required.filter(
    (key: string) => !['blankMode', 'conversion', 'subtractColumnId'].includes(key),
  );
  return result;
}

/** Validate every dependency before reading rows. Derived IDs never name physical fields. */
export function analyticColumns(plan: ChartPlan, columns: readonly ColumnSpec[]): ColumnSpec[] {
  const analytics = plan.analytics;
  if (!analytics) return [...columns];
  const output = dimensionColumns(plan, columns);
  const metadata = new Map(chartColumnMetadata(output).map((c) => [c.id, c]));
  const sourceIds = new Set(output.map((column) => column.id));
  const numeric = (id: string | null) =>
    id != null && sourceIds.has(id) && metadata.get(id)?.role === 'measure';
  const ids = new Set(output.map((c) => c.id));
  for (const metric of analytics.metrics) {
    if (ids.has(metric.id))
      throw new Fault('CHART_METRIC', 'Each computed metric requires a unique metric_ ID.');
    ids.add(metric.id);
    const ratio = metric.operation === 'ratio';
    const categoricalAggregate =
      metric.operation === 'distinct' || metric.operation === 'missingPercent';
    if (
      ratio
        ? !numeric(metric.numeratorColumnId) ||
          !numeric(metric.denominatorColumnId) ||
          metric.columnId !== null ||
          metric.percentile !== null
        : (!(categoricalAggregate ? sourceIds.has(metric.columnId!) : numeric(metric.columnId)) &&
            !(metric.operation === 'count' && metric.columnId === null)) ||
          metric.numeratorColumnId !== null ||
          metric.denominatorColumnId !== null ||
          metric.scale !== null ||
          (metric.operation === 'percentile'
            ? metric.percentile === null
            : metric.percentile !== null)
    )
      throw new Fault('CHART_METRIC', 'The requested metric has invalid or unapproved operands.');
    if (metric.subtractColumnId !== undefined && (!ratio || !numeric(metric.subtractColumnId)))
      throw new Fault(
        'CHART_METRIC',
        'A subtraction operand is permitted only for a ratio of approved source totals.',
      );
    if (metric.blankMode && metric.operation !== 'missingPercent')
      throw new Fault(
        'CHART_METRIC',
        'Blank handling is only configurable for a missing-value percentage.',
      );
    if (
      metric.conversion &&
      (!['sum', 'avg', 'min', 'max', 'percentile'].includes(metric.operation) ||
        metadata.get(metric.columnId!)?.unit !==
          (metric.conversion === 'minutesToHours' ? 'minutes' : 'hours'))
    )
      throw new Fault('CHART_UNITS', 'A unit conversion needs a compatible trusted source unit.');
    const unit = ratio
      ? metric.scale === 100
        ? 'percent'
        : 'ratio'
      : metric.operation === 'missingPercent'
        ? 'percent'
        : ['count', 'distinct'].includes(metric.operation)
          ? 'rows'
          : metric.conversion
            ? metric.conversion === 'minutesToHours'
              ? 'hours'
              : 'minutes'
            : (metadata.get(metric.columnId!)?.unit ?? null);
    const spec: ColumnSpec = {
      id: metric.id,
      label: metric.label,
      kind: 'number',
      aliases: [],
      nullable: true,
      sql: metric.id,
      description: `Chart summary ${metric.operation}`,
      chartRole: 'measure',
      unit,
    };
    output.push(spec);
    metadata.set(metric.id, chartColumnMetadata([spec])[0]);
  }
  const baseMetricIds = new Set(analytics.metrics.map((m) => m.id));
  for (const w of analytics.windows ?? []) {
    if (
      ids.has(w.id) ||
      !baseMetricIds.has(w.sourceMetricId) ||
      (w.operation === 'rollingRatio'
        ? !baseMetricIds.has(w.denominatorMetricId!)
        : w.denominatorMetricId !== null)
    )
      throw new Fault(
        'CHART_WINDOW',
        'Window outputs require unique IDs and existing base metrics; cycles and chained windows are not permitted.',
      );
    if (
      !plan.timeBucket ||
      metadata.get(plan.categoryColumnId!)?.role !== 'temporal' ||
      analytics.seriesByColumnId ||
      analytics.snapshot ||
      (analytics.groupByColumnIds?.length ?? 1) > 1 ||
      (w.operation === 'percentChange' && w.size !== 2) ||
      (w.operation === 'cumulative' && w.size !== 1)
    )
      throw new Fault(
        'CHART_WINDOW',
        'Window calculations need one chronological category and a supported frame, without pivots or snapshots.',
      );
    const base = analytics.metrics.find((m) => m.id === w.sourceMetricId)!;
    if (
      ['cumulative', 'movingAverage'].includes(w.operation) &&
      !['sum', 'count'].includes(base.operation)
    )
      throw new Fault(
        'CHART_WINDOW',
        'These windows require an additive base total, not an average of averages.',
      );
    if (
      w.operation === 'rollingRatio' &&
      [base, analytics.metrics.find((m) => m.id === w.denominatorMetricId)!].some(
        (m) => !['sum', 'count'].includes(m.operation),
      )
    )
      throw new Fault(
        'CHART_WINDOW',
        'Rolling rates divide summed additive numerators by summed additive denominators.',
      );
    ids.add(w.id);
    const unit = ['percentChange', 'rollingRatio'].includes(w.operation)
      ? 'percent'
      : (metadata.get(w.sourceMetricId)?.unit ?? null);
    const spec: ColumnSpec = {
      id: w.id,
      label: w.label,
      kind: 'number',
      aliases: [],
      nullable: true,
      sql: w.id,
      description: `Read-only ${w.operation} window`,
      chartRole: 'measure',
      unit,
    };
    output.push(spec);
    metadata.set(w.id, chartColumnMetadata([spec])[0]);
  }
  const available = new Set([
    ...plan.measureColumnIds,
    ...analytics.metrics.map((m) => m.id),
    ...(analytics.windows ?? []).map((w) => w.id),
  ]);
  const grouping =
    analytics.groupByColumnIds ?? (plan.categoryColumnId ? [plan.categoryColumnId] : []);
  if (
    !grouping.length ||
    grouping[0] !== plan.categoryColumnId ||
    new Set(grouping).size !== grouping.length ||
    grouping.some((id) => !['dimension', 'temporal'].includes(metadata.get(id)?.role ?? ''))
  )
    throw new Fault(
      'CHART_CATEGORY',
      'Choose one to three approved grouping fields, starting with the chart category.',
    );
  if (
    analytics.groupFilter.some((f) => !available.has(f.metricId)) ||
    analytics.orderBy.some((o) => !grouping.includes(o.field) && !available.has(o.field))
  )
    throw new Fault(
      'CHART_ORDER',
      'Order and filter groups only by declared metrics or grouping fields.',
    );
  if (analytics.limit != null && !analytics.orderBy.length)
    throw new Fault('CHART_ORDER', 'A group limit requires explicit ordering.');
  if (
    analytics.partitionByColumnId &&
    (!grouping.includes(analytics.partitionByColumnId) ||
      grouping.length < 2 ||
      analytics.limit == null)
  )
    throw new Fault(
      'CHART_ORDER',
      'Partitioned ranking requires a grouping partition and an explicit ranked limit.',
    );
  if (
    analytics.otherLabel &&
    (analytics.limit == null ||
      analytics.partitionByColumnId ||
      analytics.seriesByColumnId ||
      (analytics.windows?.length ?? 0) > 0)
  )
    throw new Fault(
      'CHART_OTHER',
      'Other requires a non-pivoted global top-N plan without a window.',
    );
  if (plan.type === 'histogram')
    throw new Fault('CHART_METRIC', 'Histograms use raw observations, not grouped analytics.');
  if (
    ['scatter', 'bubble'].includes(plan.type) &&
    (!analytics.metrics.length || analytics.seriesByColumnId)
  )
    throw new Fault(
      'CHART_METRIC',
      'Grouped relationship charts require explicit metrics and no category pivot.',
    );
  if (
    analytics.seriesByColumnId &&
    (!['dimension', 'temporal'].includes(metadata.get(analytics.seriesByColumnId)?.role ?? '') ||
      grouping.includes(analytics.seriesByColumnId) ||
      plan.measureColumnIds.length !== 1 ||
      [
        'pie',
        'donut',
        'scatter',
        'bubble',
        'customCombo',
        'columnLineCombo',
        'areaColumnCombo',
      ].includes(plan.type) ||
      analytics.groupFilter.length ||
      analytics.orderBy.some((o) => !grouping.includes(o.field)) ||
      analytics.limit !== null)
  )
    throw new Fault(
      'CHART_SERIES',
      'A pivot needs one measure, a distinct grouping field, and category ordering without group-level ranking.',
    );
  if (
    analytics.seriesValues &&
    (!analytics.seriesByColumnId ||
      new Set(analytics.seriesValues).size !== analytics.seriesValues.length)
  )
    throw new Fault(
      'CHART_SERIES',
      'Explicit series values require a pivot and distinct categories.',
    );
  if (analytics.snapshot) {
    const s = analytics.snapshot;
    if (
      metadata.get(s.startColumnId)?.role !== 'temporal' ||
      metadata.get(s.endColumnId)?.role !== 'temporal' ||
      s.startColumnId === s.endColumnId ||
      !plan.timeBucket ||
      grouping.length !== 1 ||
      analytics.seriesByColumnId ||
      (analytics.windows?.length ?? 0) > 0 ||
      analytics.metrics.some((m) => m.operation !== 'count' || m.columnId !== null) ||
      s.cutoffs.some(
        (at, i) =>
          !Number.isFinite(Date.parse(at)) ||
          new Date(at).toISOString().replace('.000Z', 'Z') !== at ||
          (i > 0 && at <= s.cutoffs[i - 1]),
      )
    )
      throw new Fault(
        'CHART_SNAPSHOT',
        'Interval snapshots require ordered UTC cutoffs, start/end dates and a row-count metric only.',
      );
  }
  return output;
}

type Row = Readonly<Record<string, string | number | null>>;
const finite = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);
function value(rows: readonly Row[], metric: ChartMetric): number | null {
  if (metric.operation === 'count' && metric.columnId === null) return rows.length;
  if (metric.operation === 'distinct')
    return new Set(
      rows.map((r) => r[metric.columnId!]).filter((v) => v !== null && v !== undefined),
    ).size;
  if (metric.operation === 'missingPercent')
    return rows.length
      ? (100 *
          rows.filter(
            (r) =>
              r[metric.columnId!] == null ||
              (metric.blankMode === 'nullOrEmpty' && r[metric.columnId!] === ''),
          ).length) /
          rows.length
      : null;
  const collect = (id: string) => rows.map((r) => r[id]).filter(finite);
  let result: number | null;
  if (metric.operation === 'ratio') {
    // Sum independently so zero-sales return losses stay in the numerator.
    const numerator = collect(metric.numeratorColumnId!),
      denominator = collect(metric.denominatorColumnId!),
      subtract = metric.subtractColumnId ? collect(metric.subtractColumnId) : [0];
    const sum = denominator.reduce((a, b) => a + b, 0);
    result =
      !numerator.length || !denominator.length || !subtract.length || sum === 0
        ? null
        : ((metric.scale ?? 1) *
            (numerator.reduce((a, b) => a + b, 0) - subtract.reduce((a, b) => a + b, 0))) /
          sum;
  } else {
    const values = collect(metric.columnId!);
    if (metric.operation === 'count') return values.length;
    if (!values.length) return null;
    if (metric.operation === 'percentile') {
      values.sort((a, b) => a - b);
      const at = ((values.length - 1) * metric.percentile!) / 100,
        lower = Math.floor(at);
      result = values[lower] + (values[Math.ceil(at)] - values[lower]) * (at - lower);
    } else
      result =
        metric.operation === 'min'
          ? values.reduce((a, b) => Math.min(a, b), Infinity)
          : metric.operation === 'max'
            ? values.reduce((a, b) => Math.max(a, b), -Infinity)
            : values.reduce((a, b) => a + b, 0) / (metric.operation === 'avg' ? values.length : 1);
  }
  if (result !== null && metric.conversion)
    result *= metric.conversion === 'minutesToHours' ? 1 / 60 : 60;
  if (result !== null && !Number.isFinite(result))
    throw new Fault(
      'CHART_RANGE',
      'This chart metric is outside the supported numeric range. Choose a narrower filter.',
    );
  return result;
}

/** Read-only execution: group the entire filtered cohort, compute metrics/windows,
 * apply HAVING, rank, then limit. An Other bucket is recomputed from its source cohort. */
export function buildAnalyticDataset(
  plan: ChartPlan,
  columns: readonly ColumnSpec[],
  sourceRows: readonly Row[],
  bucket: (v: Row[string] | undefined, time: ChartPlan['timeBucket']) => string | number | null,
): Omit<ChartResponse, 'source' | 'scope'> {
  const a = plan.analytics!;
  const specs = analyticColumns(plan, columns);
  const metadata = new Map(chartColumnMetadata(specs).map((c) => [c.id, c]));
  const rows = dimensionRows(plan, sourceRows);
  const windows = a.windows ?? [];
  const metrics = [...a.metrics];
  for (const id of plan.measureColumnIds) {
    if (!metrics.some((m) => m.id === id) && !windows.some((w) => w.id === id)) {
      metrics.push({
        id,
        label: metadata.get(id)!.label,
        operation: plan.aggregation!,
        columnId: id,
        numeratorColumnId: null,
        denominatorColumnId: null,
        scale: null,
        percentile: null,
      });
    }
  }
  if (!metrics.length)
    metrics.push({
      id: '__count',
      label: 'Matching rows',
      operation: 'count',
      columnId: null,
      numeratorColumnId: null,
      denominatorColumnId: null,
      scale: null,
      percentile: null,
    });
  const selected = plan.measureColumnIds.length ? plan.measureColumnIds : ['__count'];
  const groupFields = a.groupByColumnIds ?? [plan.categoryColumnId!];
  type Key = string | number | null;
  type Group = {
    keys: Key[];
    cohorts: Map<Key, Row[]>;
    values: Map<Key, Record<string, number | null>>;
  };
  const groups = new Map<string, Group>();
  const seriesValues = new Set<Key>(a.seriesValues ?? []);
  const ensure = (keys: Key[]): Group => {
    const key = JSON.stringify(keys);
    if (!groups.has(key)) groups.set(key, { keys, cohorts: new Map(), values: new Map() });
    return groups.get(key)!;
  };
  const append = (g: Group, series: Key, row: Row) => {
    if (!g.cohorts.has(series)) g.cohorts.set(series, []);
    g.cohorts.get(series)!.push(row);
  };
  if (a.snapshot) {
    const timestamp = (v: string | number | null | undefined): number => {
      if (v == null) return NaN;
      const t = String(v).replace(' ', 'T');
      const at = Date.parse(
        t.length === 10 ? t + 'T00:00:00Z' : /Z$|[+-]\d\d:\d\d$/.test(t) ? t : t + 'Z',
      );
      if (!Number.isFinite(at))
        throw new Fault('CHART_DATE', 'An interval contains an invalid timestamp.');
      return at;
    };
    for (const cutoff of a.snapshot.cutoffs) {
      const at = Date.parse(cutoff);
      const g = ensure([bucket(new Date(at - 1).toISOString(), plan.timeBucket)]);
      for (const row of rows) {
        const start = timestamp(row[a.snapshot.startColumnId]);
        const end = timestamp(row[a.snapshot.endColumnId]);
        if (Number.isFinite(start) && start < at && (!Number.isFinite(end) || end >= at))
          append(g, null, row);
      }
    }
    seriesValues.add(null);
  } else {
    for (const row of rows) {
      const keys = groupFields.map((id, i) => bucket(row[id], i === 0 ? plan.timeBucket : null));
      const series = a.seriesByColumnId ? (row[a.seriesByColumnId] ?? null) : null;
      append(ensure(keys), series, row);
      seriesValues.add(series);
    }
  }
  const domain = timeDomain(plan, (v, b) => bucket(v, b));
  if (groupFields.length === 1) {
    for (const key of domain) ensure([key]);
    for (const key of plan.categoryOrder ?? []) ensure([key]);
  }
  // A three-month window cannot skip a missing calendar month. Scaffold within
  // the observed range only when a complete explicit domain was not requested.
  if (windows.length && !plan.timeRange && groups.size) {
    const ordered = [...groups.values()].map((g) => String(g.keys[0])).sort();
    const first = ordered[0],
      last = ordered[ordered.length - 1];
    const date = (key: string): string =>
      key.length === 7
        ? key + '-01'
        : key.length === 4
          ? key + '-01-01'
          : /^\d{4} Q[1-4]$/.test(key)
            ? `${key.slice(0, 4)}-${String((Number(key.slice(-1)) - 1) * 3 + 1).padStart(2, '0')}-01`
            : key;
    const end = new Date(date(last) + 'T00:00:00Z');
    if (plan.timeBucket === 'day') end.setUTCDate(end.getUTCDate() + 1);
    else
      end.setUTCMonth(
        end.getUTCMonth() +
          (plan.timeBucket === 'month' ? 1 : plan.timeBucket === 'quarter' ? 3 : 12),
      );
    const scaffold = {
      ...plan,
      timeRange: {
        start: date(first),
        endExclusive: end.toISOString().slice(0, 10),
        fill: 'zero' as const,
      },
    };
    for (const key of timeDomain(scaffold, (v, b) => bucket(v, b))) ensure([key]);
  }
  if (seriesValues.size > 12)
    throw new Fault(
      'CHART_SERIES',
      'More than 12 series were requested. Narrow the scope or choose a single-series comparison.',
    );
  const series: Key[] = a.seriesByColumnId
    ? a.seriesValues
      ? [
          ...a.seriesValues,
          ...[...seriesValues].filter((s) => !a.seriesValues!.includes(s)).sort(compareChartValues),
        ]
      : [...seriesValues].sort(compareChartValues)
    : [null];
  const filled = !!plan.timeRange || !!plan.categoryOrder || windows.length > 0;
  const calculate = (g: Group) => {
    for (const s of series) {
      const cohort = g.cohorts.get(s) ?? [];
      g.values.set(
        s,
        Object.fromEntries(
          metrics.map((m) => [
            m.id,
            !cohort.length &&
            (filled || a.snapshot) &&
            ['sum', 'count', 'distinct'].includes(m.operation)
              ? 0
              : value(cohort, m),
          ]),
        ),
      );
    }
  };
  groups.forEach(calculate);
  const byCategory = (x: Group, y: Group): number => {
    for (let i = 0; i < groupFields.length; i++) {
      if (i === 0 && plan.categoryOrder) {
        const xi = plan.categoryOrder.indexOf(x.keys[i]!),
          yi = plan.categoryOrder.indexOf(y.keys[i]!);
        if (xi !== yi && (xi >= 0 || yi >= 0)) return xi < 0 ? 1 : yi < 0 ? -1 : xi - yi;
      }
      const comparison = compareChartValues(x.keys[i], y.keys[i]);
      if (comparison) return comparison;
    }
    return 0;
  };
  const chronological = [...groups.values()].sort(byCategory);
  for (const w of windows) {
    let running = 0,
      valid = 0;
    chronological.forEach((g, index) => {
      const source = g.values.get(null)![w.sourceMetricId];
      let result: number | null = null;
      if (w.operation === 'cumulative') {
        if (finite(source)) {
          running += source;
          valid++;
        }
        result = valid ? running : null;
      } else if (w.operation === 'percentChange' && index > 0) {
        const previous = chronological[index - 1].values.get(null)![w.sourceMetricId];
        result =
          finite(source) && finite(previous) && previous !== 0
            ? (100 * (source - previous)) / previous
            : null;
      } else if (index + 1 >= w.size) {
        const frame = chronological.slice(index + 1 - w.size, index + 1);
        const numerator = frame.map((g) => g.values.get(null)![w.sourceMetricId]);
        if (numerator.every(finite)) {
          const total = (numerator as number[]).reduce((s, v) => s + v, 0);
          if (w.operation === 'movingAverage') result = total / w.size;
          else {
            const denominator = frame.map((g) => g.values.get(null)![w.denominatorMetricId!]);
            const sum = denominator.every(finite)
              ? (denominator as number[]).reduce((s, v) => s + v, 0)
              : 0;
            result = sum === 0 ? null : (100 * total) / sum;
          }
        }
      }
      if (result !== null && !Number.isFinite(result))
        throw new Fault('CHART_RANGE', 'A window result exceeded finite numeric range.');
      g.values.get(null)![w.id] = result;
    });
  }
  let eligible = chronological.filter((g) =>
    a.groupFilter.every((f) => {
      const v = g.values.get(null)?.[f.metricId];
      if (!finite(v)) return false;
      return f.operator === 'equals'
        ? v === f.value
        : f.operator === 'greaterThan'
          ? v > f.value
          : f.operator === 'greaterThanOrEqual'
            ? v >= f.value
            : f.operator === 'lessThan'
              ? v < f.value
              : v <= f.value;
    }),
  );
  const order = (x: Group, y: Group) => {
    for (const o of a.orderBy) {
      const index = groupFields.indexOf(o.field);
      const xv = index >= 0 ? x.keys[index] : (x.values.get(null)?.[o.field] ?? null);
      const yv = index >= 0 ? y.keys[index] : (y.values.get(null)?.[o.field] ?? null);
      const cmp =
        compareChartValues(xv, yv) *
        (xv === null || yv === null ? 1 : o.direction === 'desc' ? -1 : 1);
      if (cmp) return cmp;
    }
    return byCategory(x, y);
  };
  eligible.sort(order);
  const eligibleCount = eligible.length;
  if (a.limit != null) {
    if (a.partitionByColumnId) {
      const index = groupFields.indexOf(a.partitionByColumnId),
        seen = new Map<Key, number>();
      eligible = eligible.filter((g) => {
        const n = seen.get(g.keys[index]) ?? 0;
        seen.set(g.keys[index], n + 1);
        return n < a.limit!;
      });
      eligible.sort((x, y) => compareChartValues(x.keys[index], y.keys[index]) || order(x, y));
    } else {
      const remainder = eligible.slice(a.limit);
      eligible = eligible.slice(0, a.limit);
      if (a.otherLabel && remainder.length) {
        if (chronological.some((g) => g.keys.join(' / ') === a.otherLabel))
          throw new Fault(
            'CHART_OTHER',
            'The requested Other label collides with an observed category. Choose a distinct label.',
          );
        const cohort = remainder.flatMap((g) => [...g.cohorts.values()].flat());
        const other: Group = {
          keys: [a.otherLabel],
          cohorts: new Map([[null, cohort]]),
          values: new Map(),
        };
        calculate(other);
        eligible.push(other);
      }
    }
  }
  if (eligible.length > 200)
    throw new Fault(
      'CHART_CARDINALITY',
      'More than 200 chart categories remain. Choose a top-N ranking, coarser bucket or narrower scope.',
    );
  let blankLabel = '(Blank)';
  while (chronological.some((g) => g.keys[0] === blankLabel)) blankLabel = `(${blankLabel})`;
  const assignments = series.flatMap((s) => selected.map((id) => ({ series: s, id, output: '' })));
  const resultColumns: ChartResponse['columns'] = [
    {
      id: 'category',
      label: groupFields.map((id) => metadata.get(id)!.label).join(' / '),
      dataType: 'category',
      sourceColumnId: groupFields.length === 1 ? groupFields[0] : null,
    },
  ];
  assignments.forEach((assignment, index) => {
    assignment.output = `measure${index}`;
    const m = metrics.find((m) => m.id === assignment.id),
      w = windows.find((w) => w.id === assignment.id);
    resultColumns.push({
      id: assignment.output,
      label: a.seriesByColumnId ? String(assignment.series ?? '(Blank)') : (m?.label ?? w!.label),
      dataType: 'series',
      sourceColumnId: assignment.id,
      unit: metadata.get(assignment.id)?.unit ?? (m?.operation === 'count' ? 'rows' : null),
      aggregation:
        m && ['sum', 'avg', 'min', 'max', 'count'].includes(m.operation)
          ? (m.operation as ChartPlan['aggregation'])
          : null,
    });
  });
  let output = eligible.map(
    (g) =>
      ({
        category:
          g.keys.length === 1
            ? (g.keys[0] ?? blankLabel)
            : g.keys
                .map((k) => (k == null ? blankLabel : String(k).replaceAll(' / ', ' \\/ ')))
                .join(' / '),
        ...Object.fromEntries(
          assignments.map((x) => [x.output, g.values.get(x.series)?.[x.id] ?? null]),
        ),
      }) as Record<string, string | number | null>,
  );
  if (new Set(output.map((r) => String(r.category))).size !== output.length)
    throw new Fault(
      'CHART_CATEGORY',
      'Distinct groups have colliding display labels. Use a different grouping.',
    );
  const relationship = ['scatter', 'bubble'].includes(plan.type);
  if (relationship)
    output = output.filter((row) => assignments.every((x) => finite(row[x.output])));
  if (plan.type === 'bubble' && output.some((row) => Number(row.measure2) < 0))
    throw new Fault('CHART_NEGATIVE_SIZE', 'Bubble sizes must be nonnegative.');
  if (
    (['pie', 'donut'].includes(plan.type) || plan.type.startsWith('normalized')) &&
    output.some((row) =>
      assignments.some((x) => finite(row[x.output]) && Number(row[x.output]) < 0),
    )
  )
    throw new Fault(
      'CHART_NEGATIVE_PROPORTION',
      'Pie, donut and percentage charts cannot represent signed values faithfully.',
    );
  const operands = [
    ...new Set(
      metrics
        .flatMap((m) => [
          m.columnId,
          m.numeratorColumnId,
          m.denominatorColumnId,
          m.subtractColumnId,
        ])
        .filter((id): id is string => typeof id === 'string'),
    ),
  ];
  const notes = [
    'Computed from all matching source rows. Grouped metrics are calculated before eligibility thresholds, ordering and top-N selection.',
  ];
  if (a.limit != null)
    notes.push(
      `Showing ${output.length} of ${eligibleCount} eligible groups after ranking; no source rows were sampled.${a.otherLabel ? ' Remaining groups are recomputed as Other from their source rows.' : ''}`,
    );
  if (metrics.some((m) => m.operation === 'ratio'))
    notes.push(
      'Rates divide summed numerator by summed denominator at each group; a zero or missing denominator remains blank.',
    );
  if (metrics.some((m) => m.operation === 'percentile'))
    notes.push(
      'Percentiles use continuous linear interpolation over all nonblank values in each group.',
    );
  if (windows.length)
    notes.push(
      'Windows follow complete chronological calendar buckets before HAVING or ranking. Incomplete frames and zero denominators remain null.',
    );
  if (a.snapshot)
    notes.push(
      'Opening-to-final-exit interval inventory at explicit cutoffs; this does not reconstruct intermediate reopen or status history.',
    );
  if (relationship)
    notes.push('Each point represents one eligible group; bubble labels identify that group.');
  if (plan.type.startsWith('normalized'))
    notes.push(
      'Displayed percentages are normalized within each category; API values retain original nonnegative totals.',
    );
  if (
    ['pie', 'donut'].includes(plan.type) &&
    !output.some((row) =>
      assignments.some((x) => finite(row[x.output]) && Number(row[x.output]) > 0),
    )
  )
    notes.push('No positive values are available, so this chart has no visible slices.');
  return {
    plan,
    type: plan.type,
    title: plan.title,
    appearance: plan.appearance,
    columns: resultColumns,
    rows: output,
    ...(plan.seriesChartTypes
      ? {
          seriesChartTypes: plan.seriesChartTypes.map((s) => ({
            ...s,
            colId: `measure${selected.indexOf(s.colId)}`,
          })),
        }
      : {}),
    matchedRowCount: sourceRows.length,
    plottedRowCount: output.length,
    omittedRowCount: 0,
    missingValueCounts: Object.fromEntries(
      operands.map((id) => [id, rows.filter((r) => !finite(r[id])).length]),
    ),
    categoryMissingRowCount: rows.filter((r) => r[plan.categoryColumnId!] == null).length,
    notes,
  };
}
