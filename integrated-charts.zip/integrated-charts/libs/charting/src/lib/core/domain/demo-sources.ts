import type { ColumnSpec } from './schema';
import type { SqlDataset } from './sql-dataset';

/** Source IDs and metadata are supplied by the embedding host. */
export type DataSourceId = string;
export interface DemoSourceMetadata {
  id: DataSourceId;
  label: string;
  description: string;
  rowLabel: string;
  version: string;
  columns: ColumnSpec[];
  sqlDataset: SqlDataset;
  defaultVisibleColumnIds: string[];
}
