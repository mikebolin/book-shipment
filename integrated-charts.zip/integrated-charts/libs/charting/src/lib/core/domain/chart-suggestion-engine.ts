import type { ColumnSpec } from './schema.js';
import type {
  ChartColumnProfile,
  ChartSuggestion,
  ChartSuggestionsResponse,
} from './chart-suggestions.js';
import { Fault } from './engine.js';
import { chartColumnMetadata, type ChartPlan } from './integrated-chart.js';
import {
  buildChartDataset,
  CHART_MAX_SOURCE_ROWS,
  chartTimeBucket,
  type ChartSourceRow,
} from './chart-data.js';
const finite = (value: unknown): value is number =>
  typeof value === 'number' && Number.isFinite(value);

/** Deterministic recommendations based only on trusted schema and the filtered rows. */
export function suggestCharts(
  columns: readonly ColumnSpec[],
  rows: readonly ChartSourceRow[],
  maxSourceRows = CHART_MAX_SOURCE_ROWS,
): Omit<ChartSuggestionsResponse, 'source' | 'scope'> {
  if (rows.length > maxSourceRows)
    throw new Fault(
      'CHART_SIZE',
      'Too many matching source rows to profile. Apply a narrower filter.',
    );
  const profiles: ChartColumnProfile[] = chartColumnMetadata(columns).map((column) => {
    const values = rows
      .map((row) => row[column.id])
      .filter((value) =>
        column.role === 'measure' ? finite(value) : value !== null && value !== undefined,
      );
    const distinctCount = new Set(values).size;
    return {
      ...column,
      nonNullCount: values.length,
      missingCount: rows.length - values.length,
      distinctCount,
      excludedReason:
        column.role === 'identifier'
          ? 'Identifier or surrogate, primary or foreign key; excluded from chart axes and measures.'
          : !values.length
            ? 'No nonblank observations in the filtered cohort.'
            : distinctCount < 2
              ? 'Only one distinct observed value; no comparison or distribution.'
              : column.role === 'dimension' && distinctCount > 12
                ? 'More than 12 observed categories; too many for a suggested comparison.'
                : null,
    };
  });
  const notes = [
    'Recommendations profile the complete filtered dataset and trusted schema roles, units and data types. No rows are sampled.',
    'Identifiers are excluded using explicit chartRole metadata and identifier naming conventions. Declare chartRole and unit in the trusted schema for custom schemas.',
  ];
  const result = {
    matchedRowCount: rows.length,
    profiles,
    suggestions: [] as ChartSuggestion[],
    notes,
  };
  if (!rows.length) {
    notes.push('No matching rows; no chart is suggested.');
    return result;
  }
  const useful = profiles.filter((profile) => !profile.excludedReason);
  const ranked = (role: ChartColumnProfile['role']) =>
    useful
      .filter((profile) => profile.role === role)
      .sort((a, b) => b.nonNullCount - a.nonNullCount);
  const measures = ranked('measure').filter((profile) => profile.nonNullCount >= 3);
  const dimensions = ranked('dimension');
  const temporal = ranked('temporal');
  const measure = measures[0];
  const candidates: ChartSuggestion[] = [];
  const alternatives: ChartSuggestion[] = [];
  const base: ChartPlan = {
    type: 'bar',
    categoryColumnId: null,
    measureColumnIds: [],
    aggregation: 'count',
    timeBucket: null,
    title: 'Matching rows',
  };
  for (const [index, dimension] of dimensions.entries()) {
    (index === 0 ? candidates : alternatives).push({
      plan: {
        ...base,
        categoryColumnId: dimension.id,
        measureColumnIds: measure ? [measure.id] : [],
        aggregation: measure ? 'avg' : 'count',
        title: measure
          ? `Average ${measure.label} by ${dimension.label}`
          : `Matching rows by ${dimension.label}`,
      },
      reason: `${dimension.label} has ${dimension.distinctCount} observed categories across ${rows.length} matching rows.${measure ? ` ${measure.label} is a numeric measure; averages avoid assuming it is additive.` : ' Row counts support a comparison without requiring a numeric measure.'}`,
    });
  }
  let temporalCandidateFound = false;
  for (const date of temporal) {
    let chosen: { bucket: NonNullable<ChartPlan['timeBucket']>; count: number } | undefined;
    try {
      for (const bucket of ['day', 'month', 'quarter', 'year'] as const) {
        const count = new Set(
          rows
            .filter((row) => row[date.id] != null)
            .map((row) => chartTimeBucket(row[date.id], bucket)),
        ).size;
        if (count >= 2 && count <= 24) {
          chosen = { bucket, count };
          break;
        }
      }
    } catch {
      date.excludedReason = 'The temporal field contains an invalid date.';
    }
    if (!chosen) {
      date.excludedReason ??= 'No time bucket provides between 2 and 24 observed periods.';
      continue;
    }
    (temporalCandidateFound ? alternatives : candidates).push({
      plan: {
        ...base,
        type: 'line',
        categoryColumnId: date.id,
        timeBucket: chosen.bucket,
        measureColumnIds: measure ? [measure.id] : [],
        aggregation: measure ? 'avg' : 'count',
        title: `${measure ? `Average ${measure.label}` : 'Matching rows'} by ${date.label} (${chosen.bucket})`,
      },
      reason: `${date.label} is temporal and provides ${chosen.count} observed ${chosen.bucket} periods.${measure ? ` Average ${measure.label} shows change without assuming totals are meaningful.` : ' Row counts show changes in the number of matching observations.'} Missing periods are not filled with zero.`,
    });
    temporalCandidateFound = true;
  }
  for (const [index, measure] of measures.entries()) {
    (index === 0 ? candidates : alternatives).push({
      plan: {
        ...base,
        type: 'histogram',
        measureColumnIds: [measure.id],
        aggregation: null,
        title: `Distribution of ${measure.label}`,
      },
      reason: `${measure.label} has ${measure.nonNullCount} nonblank numeric observations and ${measure.distinctCount} distinct values. A histogram exposes its distribution and outliers without aggregation assumptions.`,
    });
  }
  if (measures.length >= 2) {
    const second = measures.slice(1).find((candidate) => {
      const paired = rows.filter((row) => finite(row[measure.id]) && finite(row[candidate.id]));
      return (
        paired.length >= 3 &&
        new Set(paired.map((row) => row[measure.id])).size >= 2 &&
        new Set(paired.map((row) => row[candidate.id])).size >= 2
      );
    });
    if (second)
      candidates.push({
        plan: {
          ...base,
          type: 'scatter',
          measureColumnIds: [measure.id, second.id],
          aggregation: null,
          title: `${measure.label} versus ${second.label}`,
        },
        reason:
          'Two varying numeric measures have paired nonblank observations. A scatter plot uses separate axes and does not infer causation.',
      });
  }
  for (const candidate of [...candidates, ...alternatives]) {
    if (result.suggestions.length === 2) break;
    try {
      const data = buildChartDataset(candidate.plan, columns, rows, maxSourceRows);
      if (data.rows.length >= 2) result.suggestions.push(candidate);
    } catch (error) {
      if (!(error instanceof Fault)) throw error;
    }
  }
  if (!measures.length)
    notes.push(
      'No varying numeric measure with at least three nonblank observations is available; only meaningful count comparisons or trends can be suggested.',
    );
  if (!result.suggestions.length)
    notes.push(
      'The filtered cohort does not contain enough variation or suitable categories for a meaningful chart.',
    );
  return result;
}
