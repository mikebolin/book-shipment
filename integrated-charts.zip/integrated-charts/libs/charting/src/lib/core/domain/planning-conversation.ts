import type { GridChatTurn } from './grid-copilot.js';

export const LEGACY_AI_BOUNDARY_MESSAGE =
  'Please use column names, supported grid/chart actions, and quote text comparison values. This request cannot be sent safely to AI.';

export const AI_REQUEST_CONTEXT_MESSAGE =
  'The request or its conversation context could not be prepared for the model. No changes were applied. You can edit or retry this request.';

/** Rendered UI messages are redundant with the separately validated grid/chart state. */
export function isPlanningDisplayMessage(text: string): boolean {
  return (
    text === LEGACY_AI_BOUNDARY_MESSAGE ||
    text === AI_REQUEST_CONTEXT_MESSAGE ||
    [
      'Chart saved in the Chart tab. Switch to Grid to explore its data, filters, sorting and groups.',
      'Grid changes applied. Your configured chart remains available in the Chart tab.',
      'Grid changes applied.',
      'Filter applied. The results and Snowflake SQL now follow this view.',
    ].includes(text) ||
    // Compatibility for existing tabs, which sent formatted proposals as prose.
    // Actual user requests and model clarification questions remain intact.
    (!text.includes('?') && /^(?:Filter:|Sort:|Chart:) /.test(text))
  );
}

export function planningConversation(turns: readonly GridChatTurn[]): GridChatTurn[] {
  return turns.flatMap((turn) => {
    if (turn.role === 'user') return [turn];
    const text = turn.text.replace(
      /^\[(?:active|applied|answered|cancelled|superseded|error)\]\s*/,
      '',
    );
    return isPlanningDisplayMessage(text) ? [] : [{ role: turn.role, text }];
  });
}
