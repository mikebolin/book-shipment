import { z } from 'zod';
import { COLUMNS, type ColumnSpec } from './schema.js';
import type { Mode } from './contracts.js';
import { AGGREGATIONS, GRID_FEATURES, type GridFeature } from './grid-copilot.js';
import { Fault, expression } from './engine.js';
import { fromModel, toModel } from './grid-model.js';

const column = z.string().max(80);
const columnList = (max: number) =>
  z
    .array(column)
    .max(max)
    .refine((ids) => new Set(ids).size === ids.length, 'Duplicate columns');
const stateSchema = z
  .object({
    filter: z.record(z.unknown()).nullable().optional(),
    sort: z
      .object({
        sortModel: z
          .array(
            z
              .object({
                colId: z.string().max(200),
                sort: z.enum(['asc', 'desc']),
                type: z.literal('default').optional(),
              })
              .strict(),
          )
          .max(3),
      })
      .strict()
      .nullable()
      .optional(),
    rowGroup: z
      .object({ groupColIds: columnList(3) })
      .strict()
      .nullable()
      .optional(),
    pivot: z
      .object({ pivotMode: z.boolean(), pivotColIds: columnList(2) })
      .strict()
      .nullable()
      .optional(),
    aggregation: z
      .object({
        aggregationModel: z
          .array(z.object({ colId: column, aggFunc: z.enum(AGGREGATIONS) }).strict())
          .max(8),
      })
      .strict()
      .nullable()
      .optional(),
  })
  .strict();

export interface ValidGridState {
  filter: Record<string, unknown>;
  sort: { sortModel: { colId: string; sort: 'asc' | 'desc' }[] };
  rowGroup: { groupColIds: string[] };
  pivot: { pivotMode: boolean; pivotColIds: string[] };
  aggregation: { aggregationModel: { colId: string; aggFunc: (typeof AGGREGATIONS)[number] }[] };
  [key: string]: unknown;
}

// AG Grid's Toolkit uses ISO T for timestamp filters. The SQL/filter engine uses a space.
function normalizedDates(value: unknown, depth = 0): unknown {
  if (depth > 12) throw new Fault('TOO_DEEP', 'The filter model is nested too deeply.');
  if (Array.isArray(value)) return value.map((item) => normalizedDates(item, depth + 1));
  if (!value || typeof value !== 'object') return value;
  const obj = value as Record<string, unknown>;
  return Object.fromEntries(
    Object.entries(obj).map(([key, val]) => [
      key,
      key === 'filter' && obj['filterType'] === 'dateTimeString' && typeof val === 'string'
        ? val.replace('T', ' ')
        : normalizedDates(val, depth + 1),
    ]),
  );
}

export function validateGridState(
  input: unknown,
  mode: Mode,
  columns: readonly ColumnSpec[] = COLUMNS,
  preferSetFilters = false,
): ValidGridState {
  const columnMap = new Map(columns.map((column) => [column.id, column]));
  const parsed = stateSchema.safeParse(input);
  if (!parsed.success)
    throw new Fault(
      'GRID_STATE',
      'The grid state contains unsupported properties or exceeds the supported limits.',
    );
  const s = parsed.data;
  const filterKey = mode === 'advanced' ? 'advancedFilterModel' : 'filterModel';
  if (s.filter && Object.keys(s.filter).some((key) => key !== filterKey))
    throw new Fault('FILTER_MODE', 'The proposal cannot switch filter modes.');
  let model = normalizedDates(s.filter?.[filterKey] ?? (mode === 'advanced' ? null : {}));
  if (mode === 'columns' && model && typeof model === 'object' && !Array.isArray(model))
    model = Object.fromEntries(Object.entries(model).filter(([, condition]) => condition !== null));
  const ast = fromModel(model, mode, columns);
  const rowGroup = s.rowGroup ?? { groupColIds: [] };
  const pivot = s.pivot ?? { pivotMode: false, pivotColIds: [] };
  const aggregation = s.aggregation ?? { aggregationModel: [] };
  const sort = { sortModel: (s.sort?.sortModel ?? []).map(({ colId, sort }) => ({ colId, sort })) };
  if (
    [
      ...rowGroup.groupColIds,
      ...pivot.pivotColIds,
      ...aggregation.aggregationModel.map((a) => a.colId),
    ].some((id) => !columnMap.has(id))
  )
    throw new Fault(
      'GRID_STATE',
      'The grid state references a column outside the allowed dataset.',
    );
  if (pivot.pivotColIds.some((id) => columnMap.get(id)?.kind === 'number'))
    throw new Fault(
      'PIVOT_COLUMN',
      'Pivot columns must be text or dates. Use numeric columns as values.',
    );
  if (
    new Set(aggregation.aggregationModel.map((a) => a.colId)).size !==
    aggregation.aggregationModel.length
  )
    throw new Fault('AGGREGATION', 'Each value column may have one aggregation.');
  for (const a of aggregation.aggregationModel) {
    if (columnMap.get(a.colId)?.kind !== 'number')
      throw new Fault('AGGREGATION', 'Only numeric columns may be aggregated.');
    if (rowGroup.groupColIds.includes(a.colId))
      throw new Fault(
        'AGGREGATION',
        'A column cannot be both a group key and an aggregated value.',
      );
  }
  if (pivot.pivotMode && pivot.pivotColIds.length && !aggregation.aggregationModel.length)
    throw new Fault('PIVOT_VALUES', 'Choose a value column and aggregation for the pivot.');
  if (new Set(sort.sortModel.map((s) => s.colId)).size !== sort.sortModel.length)
    throw new Fault('SORT', 'A column may only appear once in sorting.');
  for (const item of sort.sortModel) {
    // AG Grid's generated group column is a legitimate current/manual sort.
    if (
      !columnMap.has(item.colId) &&
      !(item.colId === 'ag-Grid-AutoColumn' && rowGroup.groupColIds.length)
    )
      throw new Fault('SORT', 'Sorting refers to an unsupported column.');
    if (
      pivot.pivotMode &&
      item.colId !== 'ag-Grid-AutoColumn' &&
      !rowGroup.groupColIds.includes(item.colId) &&
      !aggregation.aggregationModel.some((value) => value.colId === item.colId)
    )
      throw new Fault(
        'SORT',
        'Pivoted results contain aggregated rows, so sorting requires a group key or aggregated value. Clear other sorting or choose the requested value aggregation.',
      );
  }
  return {
    filter: { [filterKey]: toModel(ast, mode, columns, preferSetFilters) },
    sort,
    rowGroup,
    pivot,
    aggregation,
  };
}

export function filterFromState(
  state: ValidGridState,
  mode: Mode,
  columns: readonly ColumnSpec[] = COLUMNS,
) {
  return fromModel(
    state.filter[mode === 'advanced' ? 'advancedFilterModel' : 'filterModel'],
    mode,
    columns,
  );
}

export function describeGridChanges(
  state: ValidGridState,
  changed: GridFeature[],
  mode: Mode,
  columns: readonly ColumnSpec[] = COLUMNS,
): string[] {
  const label = (id: string) => columns.find((column) => column.id === id)?.label ?? 'Group';
  const result: string[] = [];
  for (const feature of changed) {
    switch (feature) {
      case 'filter': {
        const ast = filterFromState(state, mode, columns);
        result.push(ast ? `Filter: ${expression(ast, true, columns)}` : 'Clear all filters.');
        break;
      }
      case 'sort':
        result.push(
          state.sort.sortModel.length
            ? `Sort: ${state.sort.sortModel
                .map((s) => {
                  const leaves =
                    state.rowGroup.groupColIds.length > 0 &&
                    !state.pivot.pivotMode &&
                    !state.rowGroup.groupColIds.includes(s.colId) &&
                    s.colId !== 'ag-Grid-AutoColumn' &&
                    !state.aggregation.aggregationModel.some((value) => value.colId === s.colId);
                  return `${label(s.colId)} ${s.sort === 'asc' ? 'ascending' : 'descending'}${leaves ? ' for rows within each group' : ''}`;
                })
                .join(', ')}.`
            : 'Clear sorting.',
        );
        break;
      case 'rowGroup':
        result.push(
          state.rowGroup.groupColIds.length
            ? `Group by ${state.rowGroup.groupColIds.map(label).join(' → ')}.`
            : 'Remove row grouping.',
        );
        break;
      case 'pivot':
        result.push(
          state.pivot.pivotMode
            ? `Pivot on ${state.pivot.pivotColIds.map(label).join(', ') || 'no columns'}.`
            : 'Turn pivot mode off.',
        );
        break;
      case 'aggregation':
        result.push(
          state.aggregation.aggregationModel.length
            ? `Values: ${state.aggregation.aggregationModel.map((a) => `${a.aggFunc.toUpperCase()}(${label(a.colId)})`).join(', ')}.`
            : 'Remove value aggregations.',
        );
        break;
    }
  }
  return result;
}

export const publicGridColumns = (columns: readonly ColumnSpec[] = COLUMNS) =>
  columns.map(({ sql: _, ...c }) => ({
    ...c,
    sortable: true,
    groupable: true,
    pivotable: c.kind !== 'number',
    aggregations: c.kind === 'number' ? [...AGGREGATIONS] : [],
  }));

export function stableGridState(
  state: Record<string, unknown>,
  _columns: readonly ColumnSpec[] = COLUMNS,
): string {
  // Input already has a fixed property order; canonicalize nested filter object keys too.
  const sortKeys = (value: unknown): unknown =>
    Array.isArray(value)
      ? value.map(sortKeys)
      : value && typeof value === 'object'
        ? Object.fromEntries(
            Object.entries(value)
              .sort(([a], [b]) => a.localeCompare(b))
              .map(([k, v]) => [k, sortKeys(v)]),
          )
        : value;
  return JSON.stringify(
    sortKeys(Object.fromEntries(GRID_FEATURES.map((key) => [key, state[key]]))),
  );
}
