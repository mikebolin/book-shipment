import { Temporal } from '@js-temporal/polyfill';
import { COLUMNS, LIMITS } from './schema.js';
import type { ColumnSpec } from './schema.js';
import type { Context, Node, Operator } from './contracts.js';
import {
  Clarify,
  Fault,
  dayRange,
  expression,
  group,
  numericLiteral,
  plainDate,
  rule,
  utcTimestamp,
  validateNode,
} from './engine.js';

interface Token {
  raw: string;
  text: string;
  quoted: boolean;
  start: number;
  end: number;
}
const syntax =
  /\s*("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|\d{4}-\d{2}-\d{2}(?:T\d{2}:\d{2}:\d{2}(?:Z|[+-]\d{2}:\d{2}))?|\d{1,2}\/\d{1,2}\/\d{4}|-?\d+(?:\.\d+)?|>=|<=|!=|<>|[=><(),]|[A-Za-z_][A-Za-z0-9_.-]*)/gy;

function tokenize(text: string): Token[] {
  const result: Token[] = [];
  let offset = 0;
  while (offset < text.length) {
    if (!text.slice(offset).trim()) break;
    syntax.lastIndex = offset;
    const match = syntax.exec(text);
    if (!match)
      throw new Fault(
        'UNRECOGNIZED_TEXT',
        `Cannot safely interpret the text near ${JSON.stringify(text.slice(offset, offset + 32))}.`,
        [
          'Use explicit column names, operators, quoted text values, and parentheses. No part of a request is ignored.',
        ],
      );
    const raw = match[1],
      start = syntax.lastIndex - raw.length;
    const quoted = raw.startsWith('"') || raw.startsWith("'");
    let value = raw;
    if (quoted) {
      try {
        value = raw.startsWith('"')
          ? JSON.parse(raw)
          : raw.slice(1, -1).replace(/\\'/g, "'").replace(/\\\\/g, '\\');
      } catch {
        throw new Fault('INVALID_QUOTE', 'The quoted value is not valid.');
      }
    }
    result.push({ raw, text: value, quoted, start, end: syntax.lastIndex });
    offset = syntax.lastIndex;
    if (result.length > 300) throw new Fault('TOO_LONG', 'The request contains too many tokens.');
  }
  return result;
}

export function cleanText(input: string): string {
  if (!input.trim() || input.length > LIMITS.text)
    throw new Fault('TEXT_LENGTH', `Enter between 1 and ${LIMITS.text} characters.`);
  // Only documented conversational prefixes are removed, never trailing clauses.
  return input
    .trim()
    .replace(/^please\s+/i, '')
    .replace(/^(?:give me|show me|show|find|list|get)\s+(?:all\s+)?(?:the\s+)?accounts?\s*/i, '')
    .replace(/^(?:where|with)\s+/i, '')
    .trim();
}

/** A bounded-language semantic witness, separate from the untrusted provider response.
 * Full consumption is mandatory. Unsupported prose is never silently skipped.
 */
export function parseLanguage(
  input: string,
  context: Context,
  columns: readonly ColumnSpec[] = COLUMNS,
): Node {
  const text = cleanText(input),
    tokens = tokenize(text);
  let index = 0;
  const peek = () => tokens[index];
  const is = (value: string) =>
    !!peek() && !peek().quoted && peek().text.toLowerCase() === value.toLowerCase();
  const take = (): Token => {
    const t = tokens[index++];
    if (!t) throw new Fault('INCOMPLETE', 'The filter expression is incomplete.');
    return t;
  };
  const match = (phrase: string): boolean => {
    const parts = phrase.split(' ');
    if (
      parts.every(
        (p, i) =>
          tokens[index + i] &&
          !tokens[index + i].quoted &&
          tokens[index + i].text.toLowerCase() === p,
      )
    ) {
      index += parts.length;
      return true;
    }
    return false;
  };
  const ask = (
    code: string,
    message: string,
    start: number,
    end: number,
    options: { id: string; label: string; text: string }[],
  ): never => {
    throw new Clarify(
      { code, message, choices: options.map(({ id, label }) => ({ id, label })) },
      Object.fromEntries(
        options.map((o) => [o.id, text.slice(0, start) + o.text + text.slice(end)]),
      ),
    );
  };
  const field = (): ColumnSpec => {
    const t = peek();
    if (!t) throw new Fault('INCOMPLETE', 'Specify a column and comparison.');
    if (is('from') || is('date')) {
      const from = is('from');
      ask(
        'DATE_COLUMN',
        'Which date should this request filter?',
        t.start,
        t.end,
        columns
          .filter((c) => c.kind === 'date' || c.kind === 'datetime')
          .map((c, i) => ({
            id:
              c.id === 'accountDate' ? 'account' : c.id === 'createdDate' ? 'created' : 'date_' + i,
            label: c.id === 'accountDate' ? 'Account / business date' : c.label,
            text: `${c.id}${from ? ' on' : ''}`,
          })),
      );
    }
    const aliases = columns
      .flatMap((c) => [c.id, ...c.aliases].map((a) => ({ c, a })))
      .sort((a, b) => b.a.length - a.a.length);
    for (const a of aliases) if (match(a.a.toLowerCase())) return a.c;
    throw new Fault(
      'UNKNOWN_COLUMN',
      `Cannot identify a permitted column at ${JSON.stringify(t.raw)}.`,
      [
        'Use an exact column ID or alias from the searchable schema. Specify a period for quarterly metrics.',
      ],
    );
  };
  const value = (c: ColumnSpec, op: Operator, start: number): string | number => {
    const t = take();
    if (!t.quoted && ['and', 'or', ')', '('].includes(t.text.toLowerCase()))
      throw new Fault(
        'MISSING_VALUE',
        'A comparison value is missing. Quote literal AND/OR values.',
      );
    if (
      !t.quoted &&
      ['equals', 'notEqual'].includes(op) &&
      ['unknown', 'null', 'empty'].includes(t.text.toLowerCase())
    ) {
      const opts = [
        {
          id: 'literal',
          label: `Literal text ${JSON.stringify(t.text.toLowerCase())}`,
          text: `${c.id} ${op === 'notEqual' ? '!=' : '='} ${JSON.stringify(t.text.toLowerCase())}`,
        },
      ];
      if (c.nullable)
        opts.push({
          id: 'null',
          label: 'Missing value (database NULL)',
          text: `${c.id} is ${op === 'notEqual' ? 'not ' : ''}blank`,
        });
      ask(
        'MISSING_VS_LITERAL',
        `Does ${JSON.stringify(t.text)} mean a stored value or missing data?`,
        start,
        t.end,
        opts,
      );
    }
    if (c.kind === 'number') {
      if (!/^-?\d+(?:\.\d+)?$/.test(t.text))
        throw new Fault(
          'NUMBER_UNITS',
          `${c.label} needs a plain number in the column’s documented units.`,
          ['Use 1000, not 1k, $1,000, or an amount in another currency.'],
        );
      return numericLiteral(t.text, c);
    }
    if (c.kind === 'text') return c.values ? t.text.toLowerCase() : t.text;
    let v = t.text;
    if (!t.quoted && ['today', 'yesterday'].includes(v.toLowerCase())) {
      const today = Temporal.Instant.from(context.now)
        .toZonedDateTimeISO(context.timeZone)
        .toPlainDate();
      v = (v.toLowerCase() === 'yesterday' ? today.subtract({ days: 1 }) : today).toString();
    }
    const slash = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(v);
    if (slash) {
      const [, a, b, y] = slash;
      const x = Number(a),
        z = Number(b);
      const mdy = `${y}-${a.padStart(2, '0')}-${b.padStart(2, '0')}`;
      const dmy = `${y}-${b.padStart(2, '0')}-${a.padStart(2, '0')}`;
      if (x <= 12 && z <= 12 && x !== z)
        ask('DATE_ORDER', 'This numeric date has two possible interpretations.', t.start, t.end, [
          { id: 'mdy', label: mdy + ' (month/day/year)', text: mdy },
          { id: 'dmy', label: dmy + ' (day/month/year)', text: dmy },
        ]);
      v = x > 12 ? dmy : mdy;
    }
    if (c.kind === 'date' || /^\d{4}-\d{2}-\d{2}$/.test(v)) return plainDate(v);
    return utcTimestamp(v);
  };
  const predicate = (depth: number): Node => {
    if (depth > LIMITS.depth) throw new Fault('TOO_DEEP', 'Too many nested groups.');
    if (is('(')) {
      take();
      const n = parseGroup(depth + 1);
      if (!is(')')) throw new Fault('PARENTHESES', 'A closing parenthesis is missing.');
      take();
      return n;
    }
    const start = peek()?.start ?? 0;
    const c = field();
    if (match('is not blank') || match('is not null') || match('is not missing'))
      return rule(c.id, 'notBlank', null);
    if (match('is blank') || match('is null') || match('is missing'))
      return rule(c.id, 'blank', null);
    if (match('is empty'))
      ask('EMPTY_VALUE', 'Does empty mean NULL or an empty string?', start, tokens[index - 1].end, [
        { id: 'null', label: 'Database NULL', text: `${c.id} is blank` },
        { id: 'string', label: 'Empty string', text: `${c.id} = ""` },
      ]);
    if (match('between')) {
      const low = value(c, 'greaterThanOrEqual', start);
      if (!match('and')) throw new Fault('RANGE', 'Use between X and Y (inclusive).');
      const high = value(c, 'lessThanOrEqual', start);
      return group('AND', [
        rule(c.id, 'greaterThanOrEqual', low),
        rule(c.id, 'lessThanOrEqual', high),
      ]);
    }
    const choices: [string, Operator][] = [
      ['is greater than or equal to', 'greaterThanOrEqual'],
      ['is less than or equal to', 'lessThanOrEqual'],
      ['greater than or equal to', 'greaterThanOrEqual'],
      ['less than or equal to', 'lessThanOrEqual'],
      ['is not equal to', 'notEqual'],
      ['does not contain', 'notContains'],
      ['is greater than', 'greaterThan'],
      ['is less than', 'lessThan'],
      ['not equals', 'notEqual'],
      ['not equal to', 'notEqual'],
      ['not contains', 'notContains'],
      ['is not', 'notEqual'],
      ['greater than', 'greaterThan'],
      ['less than', 'lessThan'],
      ['at least', 'greaterThanOrEqual'],
      ['at most', 'lessThanOrEqual'],
      ['starts with', 'startsWith'],
      ['ends with', 'endsWith'],
      ['equal to', 'equals'],
      ['is equal to', 'equals'],
      ['>=', 'greaterThanOrEqual'],
      ['<=', 'lessThanOrEqual'],
      ['!=', 'notEqual'],
      ['<>', 'notEqual'],
      ['>', 'greaterThan'],
      ['<', 'lessThan'],
      ['=', 'equals'],
      ['equals', 'equals'],
      ['contains', 'contains'],
      ['after', 'greaterThan'],
      ['before', 'lessThan'],
      ['on', 'equals'],
      ['is', 'equals'],
    ];
    let op: Operator | undefined;
    for (const [phrase, result] of choices)
      if (match(phrase)) {
        op = result;
        break;
      }
    if (!op && c.values && peek()) op = 'equals';
    if (!op)
      throw new Fault('OPERATOR', `Specify how to filter ${c.label}.`, [
        'Use equals, contains, greater than, less than, between, is blank, or is not blank as appropriate.',
      ]);
    const v = value(c, op, start);
    if (c.kind === 'datetime' && typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v)) {
      if (op !== 'equals')
        throw new Fault(
          'DAY_BOUNDARY',
          'For timestamp comparisons, provide an exact timestamp with a zone; use on YYYY-MM-DD to select a whole day.',
        );
      return dayRange(c.id, v, context);
    }
    const result = rule(c.id, op, v);
    // Negatives on nullable columns require an explicit NULL choice. A surrounding
    // blank predicate on the same column documents the choice on the resolved prompt.
    if (c.nullable && ['notEqual', 'notContains'].includes(op)) {
      const explicitNull = new RegExp(`\\b${c.id}\\s+is\\s+(?:not\\s+)?blank\\b`, 'i').test(text);
      if (!explicitNull) {
        const p = expression(result, false, columns);
        ask(
          'NEGATIVE_NULLS',
          `Should missing ${c.label} values be included?`,
          start,
          tokens[index - 1].end,
          [
            {
              id: 'exclude',
              label: 'Exclude missing values',
              text: `(${c.id} is not blank AND ${p})`,
            },
            { id: 'include', label: 'Include missing values', text: `(${c.id} is blank OR ${p})` },
          ],
        );
      }
    }
    return result;
  };
  const parseGroup = (depth: number): Node => {
    const start = peek()?.start ?? 0;
    const nodes = [predicate(depth)],
      joins: ('AND' | 'OR')[] = [];
    while (is('and') || is('or') || is('where')) {
      const j = take().text.toUpperCase();
      joins.push(j === 'OR' ? 'OR' : 'AND');
      nodes.push(predicate(depth));
    }
    if (new Set(joins).size > 1) {
      if (nodes.length === 3) {
        const left = group(joins[1], [group(joins[0], nodes.slice(0, 2)), nodes[2]]);
        const right = group(joins[0], [nodes[0], group(joins[1], nodes.slice(1))]);
        ask(
          'BOOLEAN_SCOPE',
          'Which grouping matches your request? No SQL operator precedence is assumed.',
          start,
          tokens[index - 1].end,
          [
            {
              id: 'left',
              label: expression(left, true, columns),
              text: expression(left, false, columns),
            },
            {
              id: 'right',
              label: expression(right, true, columns),
              text: expression(right, false, columns),
            },
          ],
        );
      }
      throw new Fault('BOOLEAN_SCOPE', 'Mixed AND/OR requires explicit parentheses.', [
        'Example: account date on 2026-10-30 AND (status = "failed" OR delivered = "unknown").',
      ]);
    }
    return group(joins[0] ?? 'AND', nodes);
  };
  const ast = parseGroup(1);
  if (index !== tokens.length)
    throw new Fault(
      'UNCONSUMED_TEXT',
      `The request contains an unsupported or incomplete clause near ${JSON.stringify(peek().raw)}.`,
      [
        'Nothing has been applied. Split the request or use explicit comparisons; joins, calculations, ranking and aggregates are outside this filter-only feature.',
      ],
    );
  return validateNode(ast, columns);
}
