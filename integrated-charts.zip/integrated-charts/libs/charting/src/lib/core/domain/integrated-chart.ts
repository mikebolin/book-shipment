import type { ChartDimension, ChartWindow, ChartSnapshot } from './chart-extensions.js';
import type { ColumnSpec } from './schema.js';
import type { GridModel, Mode } from './contracts.js';

/** Families supported by the installed AG Charts Community integrated module, including API aliases. */
export const CHART_TYPES = [
  'bar',
  'groupedBar',
  'stackedBar',
  'normalizedBar',
  'column',
  'groupedColumn',
  'stackedColumn',
  'normalizedColumn',
  'line',
  'stackedLine',
  'normalizedLine',
  'area',
  'stackedArea',
  'normalizedArea',
  'pie',
  'donut',
  'scatter',
  'bubble',
  'histogram',
  'columnLineCombo',
  'areaColumnCombo',
  'customCombo',
] as const;
/** Recognized AG Grid families that require an AG Charts Enterprise module and separate data contracts. */
export const ENTERPRISE_ONLY_CHART_TYPES = [
  'radarLine',
  'radarArea',
  'nightingale',
  'radialColumn',
  'radialBar',
  'boxPlot',
  'rangeBar',
  'rangeArea',
  'treemap',
  'sunburst',
  'heatmap',
  'waterfall',
  'funnel',
  'coneFunnel',
  'pyramid',
] as const;
/** AG Grid's supported custom-combination series, verified against the installed engine. */
export const COMBO_SERIES_TYPES = [
  'line',
  'groupedColumn',
  'stackedColumn',
  'area',
  'stackedArea',
] as const;
export interface ChartSeriesType {
  /** Source measure ID in a plan; returned dataset series ID in a chart response. */
  colId: string;
  chartType: (typeof COMBO_SERIES_TYPES)[number];
  secondaryAxis: boolean;
}
export const CHART_AGGREGATIONS = ['sum', 'avg', 'min', 'max', 'count'] as const;
export const CHART_TIME_BUCKETS = [
  'second',
  'minute',
  'hour',
  'day',
  'month',
  'quarter',
  'year',
] as const;
export const CHART_THEMES = [
  'ag-default',
  'ag-default-dark',
  'ag-sheets',
  'ag-sheets-dark',
  'ag-polychroma',
  'ag-polychroma-dark',
  'ag-vivid',
  'ag-vivid-dark',
  'ag-material',
  'ag-material-dark',
  'ag-financial',
  'ag-financial-dark',
] as const;
export const CHART_LEGEND_POSITIONS = ['top', 'right', 'bottom', 'left'] as const;
export interface ChartAppearance {
  theme: (typeof CHART_THEMES)[number] | null;
  legendPosition: (typeof CHART_LEGEND_POSITIONS)[number] | null;
  showLegend: boolean | null;
  showLabels: boolean | null;
  xAxisTitle: string | null;
  yAxisTitle: string | null;
}
export interface ChartMetric {
  id: string;
  label: string;
  operation:
    | 'sum'
    | 'avg'
    | 'min'
    | 'max'
    | 'count'
    | 'ratio'
    | 'percentile'
    | 'distinct'
    | 'missingPercent';
  blankMode?: 'null' | 'nullOrEmpty';
  conversion?: 'minutesToHours' | 'hoursToMinutes';
  columnId: string | null;
  numeratorColumnId: string | null;
  denominatorColumnId: string | null;
  /** Optional subtraction of an independently summed approved measure before division. */
  subtractColumnId?: string;
  scale: number | null;
  /** Continuous percentile on a 0–100 scale. */
  percentile: number | null;
}
export interface ChartAnalytics {
  dimensions?: ChartDimension[];
  windows?: ChartWindow[];
  groupByColumnIds?: string[];
  partitionByColumnId?: string | null;
  otherLabel?: string | null;
  seriesValues?: (string | number | null)[];
  snapshot?: ChartSnapshot | null;
  metrics: ChartMetric[];
  groupFilter: {
    metricId: string;
    operator: 'greaterThanOrEqual' | 'greaterThan' | 'lessThanOrEqual' | 'lessThan' | 'equals';
    value: number;
  }[];
  orderBy: { field: string; direction: 'asc' | 'desc' }[];
  limit: number | null;
  seriesByColumnId: string | null;
}
export interface ChartPlan {
  type: (typeof CHART_TYPES)[number];
  categoryColumnId: string | null;
  measureColumnIds: string[];
  aggregation: (typeof CHART_AGGREGATIONS)[number] | null;
  timeBucket: (typeof CHART_TIME_BUCKETS)[number] | null;
  /** Seconds, minutes or hours per bucket for second/minute/hour buckets (1–60); other buckets are one unit. */
  bucketSize?: number;
  title: string;
  appearance?: ChartAppearance | null;
  seriesChartTypes?: ChartSeriesType[] | null;
  analytics?: ChartAnalytics;
  histogram?: { binCount: number; edges?: number[] };
  rawPointSelection?: { orderBy: { field: string; direction: 'asc' | 'desc' }[]; limit: number };
  categoryOrder?: (string | number)[];
  categoryAxis?: 'ordered';
  /**
   * Explicit display domain filled with zero for additive measures; never inferred from gaps.
   * Bounds are calendar dates or UTC timestamps. Without bounds, the domain comes from the
   * filter's lower and upper comparisons on the category column at query time.
   */
  timeRange?: { start?: string; endExclusive?: string; fill: 'zero' };
}
export interface ChartRequest {
  plan: ChartPlan;
  mode: Mode;
  filterModel: GridModel;
  calculatedColumnIds?: string[];
}
export interface ChartColumnMetadata {
  id: string;
  label: string;
  kind: ColumnSpec['kind'];
  role: 'identifier' | 'dimension' | 'measure' | 'temporal';
  unit: string | null;
}
export interface ChartDataset {
  type: ChartPlan['type'];
  title: string;
  appearance?: ChartAppearance | null;
  seriesChartTypes?: ChartSeriesType[] | null;
  histogramBins?: [number, number][];
  columns: {
    id: string;
    label: string;
    dataType: 'category' | 'series' | 'time';
    sourceColumnId?: string | null;
    unit?: string | null;
    aggregation?: ChartPlan['aggregation'];
  }[];
  rows: Record<string, string | number | null>[];
  /** Presentation-only category text; row values and aggregate data remain unchanged. */
  categoryDisplayLabels?: Record<string, string>;
}
export interface ChartResponse extends ChartDataset {
  plan: ChartPlan;
  source: 'mock';
  scope: 'filtered-source-rows';
  matchedRowCount: number;
  plottedRowCount: number;
  omittedRowCount: number;
  missingValueCounts: Record<string, number>;
  categoryMissingRowCount: number;
  notes: string[];
}

/** Describe an already validated plan using trusted schema labels, independently of its title. */
export function describeChartPlan(plan: ChartPlan, columns: readonly ColumnSpec[]): string {
  const byId = new Map(columns.map((column) => [column.id, column]));
  const label = (id: string) =>
    plan.analytics?.metrics.find((metric) => metric.id === id)?.label ??
    plan.analytics?.windows?.find((window) => window.id === id)?.label ??
    plan.analytics?.dimensions?.find((dimension) => dimension.id === id)?.label ??
    byId.get(id)?.label ??
    id;
  const measures = plan.measureColumnIds.map(label);
  let values: string;
  if (plan.type === 'scatter' || plan.type === 'bubble') {
    values = `X: ${measures[0]}; Y: ${measures[1]}`;
    if (plan.type === 'bubble') values += `; bubble size: ${measures[2]}`;
    values += plan.analytics
      ? `; one point per eligible ${label(plan.categoryColumnId!)} group`
      : '; one point per complete matching row';
  } else if (plan.type === 'histogram') {
    values = `Distribution of ${measures[0]}; one observation per nonblank matching value`;
  } else {
    values =
      plan.aggregation === 'count'
        ? measures.length
          ? `Count of nonblank numeric observations: ${measures.join(', ')}`
          : 'Count of matching rows'
        : `${plan.aggregation?.toUpperCase() ?? 'Computed metrics'}: ${measures.join(', ')}`;
    if (plan.categoryColumnId) {
      values += ` by ${label(plan.categoryColumnId)}`;
      if (plan.timeBucket) {
        const size = plan.bucketSize && plan.bucketSize > 1 ? `${plan.bucketSize}-` : '';
        values += ` (${size}${plan.timeBucket} buckets`;
        if (byId.get(plan.categoryColumnId)?.kind === 'datetime') values += ', UTC';
        values += ')';
      }
    }
    if (plan.type.startsWith('normalized'))
      values += '; display each category as percentages of its series total';
    if (plan.timeRange)
      values +=
        plan.timeRange.start && plan.timeRange.endExclusive
          ? `; include every ${plan.timeBucket === 'day' ? 'day' : plan.timeBucket + ' bucket'} from ${plan.timeRange.start} before ${plan.timeRange.endExclusive}, filling absent ${plan.timeBucket === 'day' ? 'days' : 'buckets'} with zero`
          : `; include every ${plan.timeBucket} bucket inside the filtered time range, filling absent buckets with zero`;
  }
  const presentation: string[] = [];
  if (plan.analytics) {
    for (const metric of plan.analytics.metrics) {
      values +=
        metric.operation === 'ratio'
          ? `; ${metric.label} = ${metric.scale ?? 1} × ${metric.subtractColumnId ? `(SUM(${label(metric.numeratorColumnId!)}) - SUM(${label(metric.subtractColumnId)}))` : `SUM(${label(metric.numeratorColumnId!)})`} / SUM(${label(metric.denominatorColumnId!)})`
          : `; ${metric.label}: ${metric.operation === 'percentile' ? `percentile ${metric.percentile}` : metric.operation.toUpperCase()} ${metric.columnId ? label(metric.columnId) : 'matching rows'}`;
    }
    if (plan.analytics.groupFilter.length)
      values += `; group eligibility: ${plan.analytics.groupFilter.map((filter) => `${label(filter.metricId)} ${filter.operator} ${filter.value}`).join(', ')}`;
    if (plan.analytics.orderBy.length)
      values += `; order grouped results by ${plan.analytics.orderBy.map((order) => `${label(order.field)} ${order.direction}`).join(', ')}`;
    if (plan.analytics.limit != null)
      values += `; take ${plan.analytics.limit} after aggregation and ranking`;
    if (plan.analytics.seriesByColumnId)
      values += `; separate series for ${label(plan.analytics.seriesByColumnId)}`;
  }
  if (plan.histogram)
    values += plan.histogram.edges
      ? `; ${plan.histogram.binCount} fixed frequency bins with edges ${plan.histogram.edges.join(', ')}`
      : `; ${plan.histogram.binCount} equal-width frequency bins across the observed minimum to maximum`;
  if (plan.type === 'customCombo' && plan.seriesChartTypes)
    values += `; series: ${plan.seriesChartTypes.map((series) => `${label(series.colId)} as ${series.chartType} on ${series.secondaryAxis ? 'its own right-side axis' : 'the shared left-side axis'}`).join(', ')}`;
  const appearance = plan.appearance;
  if (appearance?.theme != null) presentation.push(`theme ${appearance.theme}`);
  if (appearance?.showLegend != null)
    presentation.push(`legend ${appearance.showLegend ? 'shown' : 'hidden'}`);
  if (appearance?.legendPosition != null)
    presentation.push(`legend position ${appearance.legendPosition}`);
  if (appearance?.showLabels != null)
    presentation.push(`labels ${appearance.showLabels ? 'shown' : 'hidden'}`);
  if (appearance?.xAxisTitle != null)
    presentation.push(`X axis title ${JSON.stringify(appearance.xAxisTitle)}`);
  if (appearance?.yAxisTitle != null)
    presentation.push(`Y axis title ${JSON.stringify(appearance.yAxisTitle)}`);
  return `Chart: ${plan.title} (${plan.type}). ${values}, using all filtered source rows.${presentation.length ? ` Appearance: ${presentation.join('; ')}.` : ''}`;
}

/** Semantic roles are trusted schema configuration, never browser-supplied overrides. */
export function chartColumnMetadata(
  columns: readonly ColumnSpec[],
  overrides: Readonly<Record<string, Partial<Pick<ChartColumnMetadata, 'role' | 'unit'>>>> = {},
): ChartColumnMetadata[] {
  return columns.map((column) => {
    const words = `${column.id} ${column.label} ${column.sql}`.replace(
      /([a-z0-9])([A-Z])/g,
      '$1 $2',
    );
    const identifier =
      /(?:^|[ _])(?:id|identifier|key|sku|uuid|guid)(?:$|[ _])/i.test(words) ||
      /(?:account|order|invoice|customer|product|ticket|record|serial)[ _]+number\b/i.test(words) ||
      /(?:unique identifier|surrogate key|primary key|foreign key)/i.test(column.description);
    const unitText = `${column.label} ${column.description}`;
    const namedCurrencies = [
      ...new Set(
        (
          `${words} ${column.description}`
            .replace(/_/g, ' ')
            .match(/\b(?:USD|EUR|GBP|JPY|CAD|AUD|CHF)\b/gi) ?? []
        ).map((unit) => unit.toUpperCase()),
      ),
    ];
    const inferredUnit =
      /\b(USD|EUR|GBP|JPY|CAD|AUD|CHF)\b/.exec(unitText)?.[1] ??
      (namedCurrencies.length === 1
        ? namedCurrencies[0]
        : /\bshares\b/i.test(unitText)
          ? 'shares'
          : /\b(percent|percentage|pct)\b|%/i.test(`${words.replace(/_/g, ' ')} ${unitText}`)
            ? 'percent'
            : /\bcount\b/i.test(words.replace(/_/g, ' '))
              ? 'rows'
              : /\bseconds?\b/i.test(words.replace(/_/g, ' '))
                ? 'seconds'
                : /\bdays?\b/i.test(words.replace(/_/g, ' '))
                  ? 'days'
                  : /\bratio\b/i.test(unitText)
                    ? 'ratio'
                    : null);
    return {
      id: column.id,
      label: column.label,
      kind: column.kind,
      role:
        column.chartRole ??
        (identifier
          ? 'identifier'
          : column.kind === 'number'
            ? 'measure'
            : column.kind === 'date' || column.kind === 'datetime'
              ? 'temporal'
              : 'dimension'),
      unit:
        column.kind !== 'number'
          ? null
          : column.unit !== undefined
            ? column.unit
            : column.id.startsWith('calc_')
              ? null
              : inferredUnit,
      ...overrides[column.id],
    };
  });
}

/** Shared prompting guidance; the executor still validates every selected field and operation. */
export const CHART_PLANNING_GUIDANCE = `Create a chart only when requested. Use the chart types in the supplied schema. Bar/column compare categories; line/area show ordered trends; pie/donut show nonnegative shares; scatter/bubble compare measures; histogram shows raw distributions. Never treat numeric identifiers or keys as measures or categories. Use approved roles, units and metric meanings.
Chart the complete filtered dataset, not a cached page. Filter with gridState first. Category charts need a category and explicit sum/avg/min/max/count or declared analytic metrics. Count without measures counts rows; count with measures counts nonblank observations. Never sum prices, rates or percentages by default. Preserve negative values, nulls and outliers; do not sample or infer causation silently.
Raw scatter needs two measures, bubble three (X,Y,nonnegative size), histogram one; category, aggregation and timeBucket are null. Grouped scatter/bubble instead supply a category and analytics.metrics for axes/size, leaving aggregation and timeBucket null. Temporal line/area use a timeBucket in UTC; explicitly ordered ordinal categories use categoryAxis=ordered. Pie/donut select one measure or row count; negative values are rejected. Normalized charts retain nonnegative totals in returned data and normalize the display.
Combinations need at least two measures. columnLineCombo puts the first half (rounded up) in grouped columns and the rest in lines; areaColumnCombo puts the first half in stacked areas and the rest in columns. Presets share an axis and require seriesChartTypes=null. Preserve measure order. Explicit types or secondary axes require customCombo with exactly one seriesChartTypes entry per measure: colId, chartType and secondaryAxis. Only line and area allow secondaryAxis=true; each receives its own right axis. Other series share the left axis. Measures sharing an axis require the same known unit. Non-custom charts use seriesChartTypes=null. Use canonical donut; doughnut is a legacy alias.
analytics declares metric_ outputs, grouping, groupFilter, orderBy, limits and optional pivots. Aggregate before HAVING and top-N; use deterministic ties. Ratios divide independent summed numerators by summed denominators; scale=100 gives percent. Optional subtractColumnId computes scale*(SUM(numerator)-SUM(subtract))/SUM(denominator), such as budget variance, without creating a row calculation. Keep zero-sales losses in the numerator. Do not average row percentages. Unused metric operands are null. Zero denominators remain blank. Percentiles use all nonblank group values and continuous interpolation. Choose the implemented bounded windows, dimensions and snapshot contracts; never emit SQL, JavaScript or arbitrary options.
Histogram binCount specifies equal-width frequency bins; explicit edges specify exact boundaries. Do not clip observations. Explicit calendar completion uses timeRange {start,endExclusive,fill:zero} for supported additive/count metrics. Null measures are handled independently; missing averages are not zero. appearance permits only theme, legendPosition, showLegend, showLabels, xAxisTitle and yAxisTitle. Unrequested appearance fields are null; omit presentation changes by using appearance=null. Use ag-default-dark for unspecified dark themes. Presentation must not change data values.
Ask concise clarificationOptions for missing metric definitions, fields, aggregation, time grain or scope; never invent them. Preserve unedited state on follow-ups. Return a concise title and supplied field aliases. Clarify unimplemented capabilities instead of approximating. Return chart=null when no chart is requested or the response is clarification/unsupported; do not combine fixed dashboards and generic charts.`;
