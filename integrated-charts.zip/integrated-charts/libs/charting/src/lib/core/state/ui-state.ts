import {
  computed,
  DestroyRef,
  inject,
  untracked,
  type Signal,
  type WritableSignal,
} from '@angular/core';
import { WorkspaceStore } from './workspace.store';

/** Typed lenses over root SignalStore state. Each editor/dialog gets an isolated, disposable scope. */
export function injectUiState(owner: string) {
  const store = inject(WorkspaceStore);
  const scope = `${owner}:${crypto.randomUUID()}`;
  let sequence = 0;
  let destroyed = false;
  inject(DestroyRef).onDestroy(() => {
    destroyed = true;
    store.clearUi(scope);
  });
  return {
    signal<T>(initial: T): WritableSignal<T> {
      const key = String(++sequence);
      untracked(() => store.setUi(scope, key, initial));
      const read = computed(() => {
        const state = store.ui()[scope];
        return (state && key in state ? state[key] : initial) as T;
      });
      const lens = read as WritableSignal<T>;
      lens.set = (value: T) => {
        if (!destroyed) untracked(() => store.setUi(scope, key, value));
      };
      lens.update = (update: (value: T) => T) => lens.set(update(untracked(read)));
      lens.asReadonly = () => read as Signal<T>;
      return lens;
    },
  };
}
