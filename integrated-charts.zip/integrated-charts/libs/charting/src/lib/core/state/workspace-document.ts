import { z } from 'zod';
import type { ChartingSeed } from '../data-access/charting-data';
import type {
  Collection,
  ModelDefinition,
  Resource,
  WidgetConfiguration,
} from '../domain/workspace.types';
import { validateSchema, type ColumnSpec } from '../domain/schema';
import { validateSqlDataset } from '../domain/sql-dataset';
import { calculatedColumnSpec } from '../domain/calculated-columns';
import { validateChartPlan } from '../domain/chart-data';
import { fromModel } from '../domain/grid-model';
import { compileStudioQuery } from '../domain/studio-query';
import { normalizeServerGridSettings, SERVER_GRID_DEFAULTS } from '../domain/server-grid-settings';
import { isColumnHighlightColor } from '../../explorer/column-highlights';
import {
  persistedGridState,
  persistedPresentation,
} from '../../rendering/grid-state-normalization';
import { viewCharts } from '../../rendering/view-charts';
import {
  defaultPreferences,
  WorkspaceError,
  type Preferences,
  type WorkspaceState,
} from './workspace-state';

export const WORKSPACE_DOCUMENT_VERSION = 1 as const;
/** Portable configuration only. Rows, preferences and UI state have separate host boundaries. */
export interface WorkspaceDocument
  extends Pick<ChartingSeed, 'resources' | 'revisions' | 'sources'> {
  format: 'prism-charting-workspace';
  schemaVersion: typeof WORKSPACE_DOCUMENT_VERSION;
}

const record = (value: unknown, path: string): Record<string, any> => {
  if (!value || typeof value !== 'object' || Array.isArray(value))
    throw new Error(`${path} must be an object.`);
  return value as Record<string, any>;
};
const list = (value: unknown, path: string): any[] => {
  if (!Array.isArray(value)) throw new Error(`${path} must be an array.`);
  return value;
};
const string = (value: unknown, path: string): string => {
  if (typeof value !== 'string' || !value.trim())
    throw new Error(`${path} must be a nonempty string.`);
  return value;
};
const integer = (value: unknown, path: string, minimum = 0): number => {
  if (typeof value !== 'number' || !Number.isSafeInteger(value) || value < minimum)
    throw new Error(`${path} must be a safe integer of at least ${minimum}.`);
  return value;
};
const unique = (values: readonly string[], path: string) => {
  if (new Set(values).size !== values.length) throw new Error(`${path} must be unique.`);
};

/** Do not let JSON.stringify hide functions, NaN, cycles, accessors or prototype-owned configuration. */
function cloneJson(value: unknown, path = 'document', depth = 0, seen = new Set<object>()): any {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return value;
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (!value || typeof value !== 'object' || depth > 64 || seen.has(value))
    throw new Error(`${path} must contain finite, acyclic JSON values only.`);
  if (!Array.isArray(value) && ![Object.prototype, null].includes(Object.getPrototypeOf(value)))
    throw new Error(`${path} must use plain JSON objects.`);
  seen.add(value);
  if (Array.isArray(value)) {
    const result = Array.from({ length: value.length }, (_, index) => {
      const descriptor = Object.getOwnPropertyDescriptor(value, index);
      if (!descriptor || !Object.hasOwn(descriptor, 'value'))
        throw new Error(`${path}[${index}] must be a JSON value, without holes or accessors.`);
      return cloneJson(descriptor.value, `${path}[${index}]`, depth + 1, seen);
    });
    seen.delete(value);
    return result;
  }
  const result: Record<string, unknown> = {};
  for (const key of Object.keys(value)) {
    if (['__proto__', 'constructor', 'prototype'].includes(key))
      throw new Error(`${path} contains a reserved key.`);
    const descriptor = Object.getOwnPropertyDescriptor(value, key)!;
    if (!Object.hasOwn(descriptor, 'value'))
      throw new Error(`${path}.${key} cannot be an accessor.`);
    if (descriptor.value === undefined) continue; // Optional metadata fields follow JSON object serialization.
    result[key] = cloneJson(descriptor.value, `${path}.${key}`, depth + 1, seen);
  }
  seen.delete(value);
  return result;
}

const resourceSchema = z
  .object({
    id: z.string().min(1).max(200),
    kind: z.enum(['MODEL', 'WIDGET', 'DASHBOARD']),
    slug: z.string().min(1).max(240),
    name: z.string().min(1).max(160),
    description: z.string(),
    modelId: z.string().min(1).nullable(),
    version: z.number().int().min(1).max(Number.MAX_SAFE_INTEGER),
    publishedVersion: z.number().int().min(1).max(Number.MAX_SAFE_INTEGER).nullable(),
    body: z.record(z.unknown()),
    createdAt: z.string().datetime(),
    updatedAt: z.string().datetime(),
  })
  .strict();
const documentSchema = z
  .object({
    format: z.literal('prism-charting-workspace'),
    schemaVersion: z.literal(WORKSPACE_DOCUMENT_VERSION),
    resources: z
      .object({
        models: z.array(resourceSchema),
        widgets: z.array(resourceSchema),
        dashboards: z.array(resourceSchema),
      })
      .strict(),
    revisions: z.record(z.record(resourceSchema)),
    sources: z.array(z.record(z.unknown())),
  })
  .strict();

function rejectRowData(value: unknown, path: string): void {
  if (!value || typeof value !== 'object') return;
  for (const [key, child] of Object.entries(value)) {
    if (['rows', 'rowData', 'datasets'].includes(key))
      throw new Error(
        `${path}.${key} contains source or preview rows, which do not belong in workspace metadata.`,
      );
    rejectRowData(child, `${path}.${key}`);
  }
}

function validateModel(body: Record<string, any>, path: string): void {
  for (const field of [
    'id',
    'label',
    'rowLabel',
    'version',
    'sourceKey',
    'clientSourceId',
    'schemaVersion',
    'dataVersion',
  ])
    string(body[field], `${path}.${field}`);
  if (typeof body.description !== 'string')
    throw new Error(`${path}.description must be a string.`);
  integer(body.rowCount, `${path}.rowCount`);
  if (body.uncompressedBytes !== undefined)
    integer(body.uncompressedBytes, `${path}.uncompressedBytes`);
  const columns = list(body.columns, `${path}.columns`) as ColumnSpec[];
  for (const column of columns) {
    record(column, `${path}.columns`);
    string(column.label, `${path}.column.label`);
    list(column.aliases, `${path}.column.aliases`);
    if (typeof column.nullable !== 'boolean')
      throw new Error(`${path}.column.nullable must be Boolean.`);
  }
  validateSchema(columns);
  validateSqlDataset(record(body.sqlDataset, `${path}.sqlDataset`) as any);
  const mapping = body.sqlDataset.columns as ColumnSpec[];
  if (
    mapping.length !== columns.length ||
    columns.some(
      (column) =>
        !mapping.some(
          (mapped) =>
            mapped.id === column.id &&
            mapped.kind === column.kind &&
            mapped.sql === column.sql &&
            mapped.nullable === column.nullable,
        ),
    )
  )
    throw new Error(`${path}.sqlDataset must map the same typed schema as the model.`);
  const visible = list(body.defaultVisibleColumnIds, `${path}.defaultVisibleColumnIds`);
  unique(visible, `${path}.defaultVisibleColumnIds`);
  if (visible.some((id) => !columns.some((column) => column.id === id)))
    throw new Error(`${path} contains an unknown default visible column.`);
}

function validateSettings(settings: unknown, path: string): void {
  if (settings === undefined) return;
  const object = record(settings, path);
  if (Object.keys(object).some((key) => !Object.hasOwn(SERVER_GRID_DEFAULTS, key)))
    throw new Error(`${path} contains an unknown setting.`);
  if (Object.values(object).some((value) => value === null))
    throw new Error(`${path} cannot contain null settings.`);
  normalizeServerGridSettings(object);
}

function validateFilterControls(value: unknown, path: string): void {
  if (value === undefined) return;
  const controls = record(value, path);
  if (
    typeof controls.visible !== 'boolean' ||
    typeof controls.parameterizable !== 'boolean' ||
    (controls.editMode !== undefined && !['values', 'expression'].includes(controls.editMode))
  )
    throw new Error(`${path} contains invalid reader filter controls.`);
}

function validateGrid(
  body: Record<string, any>,
  model: ModelDefinition,
  columns: ColumnSpec[],
  path: string,
): void {
  if (!['advanced', 'columns'].includes(body.mode)) throw new Error(`${path}.mode is unsupported.`);
  const state = record(body.gridState, `${path}.gridState`);
  const ids = new Set(columns.map((column) => column.id));
  const groups = state.rowGroup?.groupColIds ?? [];
  const values = state.aggregation?.aggregationModel ?? [];
  const pivots = state.pivot?.pivotColIds ?? [];
  const pivotMode = state.pivot?.pivotMode ?? false;
  const sortModel = list(state.sort?.sortModel ?? [], `${path}.gridState.sortModel`);
  if (sortModel.length > 3) throw new Error(`${path}.gridState supports at most three sorts.`);
  unique(
    sortModel.map((sort) => string(sort.colId, `${path}.sort.colId`)),
    `${path}.sort`,
  );
  if (sortModel.some((sort) => !['asc', 'desc'].includes(sort.sort)))
    throw new Error(`${path}.sort direction is invalid.`);
  const pivotId = (id: string) => {
    if (!pivotMode || !Array.isArray(pivots) || !Array.isArray(values) || !pivots.length)
      return false;
    const segments = id.split('|');
    if (
      segments.length !== pivots.length + 1 ||
      !values.some((value) => value.colId === segments.at(-1))
    )
      return false;
    try {
      segments.slice(0, -1).forEach(decodeURIComponent);
      return true;
    } catch {
      return false;
    }
  };
  const columnId = (id: unknown) => {
    if (typeof id !== 'string' || (!ids.has(id) && !id.startsWith('ag-Grid-') && !pivotId(id)))
      throw new Error(`${path}.gridState references an unknown column.`);
  };
  const walk = (value: unknown) => {
    if (!value || typeof value !== 'object') return;
    for (const [childKey, child] of Object.entries(value)) {
      if (childKey === 'colId') columnId(child);
      else if (
        [
          'orderedColIds',
          'hiddenColIds',
          'groupColIds',
          'pivotColIds',
          'leftColIds',
          'rightColIds',
        ].includes(childKey)
      )
        list(child, `${path}.${childKey}`).forEach(columnId);
      else if (childKey === 'width' || childKey === 'flex') {
        if (child !== null && (typeof child !== 'number' || !Number.isFinite(child) || child < 0))
          throw new Error(`${path}.${childKey} must be a nonnegative number.`);
      } else walk(child);
    }
  };
  walk(state);
  if (state.filter) {
    const filter = record(state.filter, `${path}.gridState.filter`);
    const other = body.mode === 'advanced' ? filter.filterModel : filter.advancedFilterModel;
    if (other && Object.keys(other).length)
      throw new Error(`${path}.gridState contains a filter from the other mode.`);
  }
  // Pivot-result sort IDs cannot be resolved before data discovery. Source/group sorts still validate now.
  const sourceSorts = sortModel.filter(
    (sort: any) => ids.has(sort.colId) || String(sort.colId).startsWith('ag-Grid-AutoColumn'),
  );
  if (sortModel.length !== sourceSorts.length && !pivotMode)
    throw new Error(`${path}.gridState has an unknown sort field.`);
  compileStudioQuery(
    {
      mode: body.mode,
      calculatedColumnIds: (body.calculatedColumns ?? []).map((definition: any) => definition.id),
      request: {
        startRow: 0,
        endRow: 1,
        filterModel:
          body.mode === 'advanced'
            ? (state.filter?.advancedFilterModel ?? null)
            : (state.filter?.filterModel ?? {}),
        sortModel: sourceSorts,
        rowGroupCols: groups.map((id: string) => ({ id })),
        valueCols: values.map(({ colId, aggFunc }: any) => ({ id: colId, aggFunc })),
        pivotCols: pivots.map((id: string) => ({ id })),
        pivotMode,
        groupKeys: [],
      },
    },
    'metadata-validation',
    model.sqlDataset,
    body.calculatedColumns ?? [],
  );
  body.gridState = persistedGridState(state);
}

function validateWidget(body: Record<string, any>, model: ModelDefinition, path: string): void {
  if (body.schemaVersion !== 1) throw new Error(`${path}.schemaVersion is unsupported.`);
  string(body.modelSchemaVersion, `${path}.modelSchemaVersion`);
  const definitions = list(body.calculatedColumns, `${path}.calculatedColumns`);
  unique(
    definitions.map((definition) => string(definition.id, `${path}.calculatedColumn.id`)),
    `${path}.calculatedColumns`,
  );
  const columns = [
    ...model.columns,
    ...definitions.map((definition) => calculatedColumnSpec(definition, model.columns)),
  ];
  validateSettings(body.serverGrid, `${path}.serverGrid`);
  validateFilterControls(body.filterControls, `${path}.filterControls`);
  if (body.grid) validateFilterControls(body.grid.filterControls, `${path}.grid.filterControls`);
  if (body.displayMode !== undefined && !['grid', 'chart', 'both'].includes(body.displayMode))
    throw new Error(`${path}.displayMode is unsupported.`);
  if (body.bothChartCount !== undefined && ![1, 2, 3].includes(body.bothChartCount))
    throw new Error(`${path}.bothChartCount must be 1, 2 or 3.`);
  if (body.allowDownload !== undefined && typeof body.allowDownload !== 'boolean')
    throw new Error(`${path}.allowDownload must be Boolean.`);
  if (body.showRowNumbers !== undefined && typeof body.showRowNumbers !== 'boolean')
    throw new Error(`${path}.showRowNumbers must be Boolean.`);
  if (body.viewLayout !== undefined) {
    const layout = record(body.viewLayout, `${path}.viewLayout`);
    if (layout.tablePosition !== undefined && !['top', 'bottom'].includes(layout.tablePosition))
      throw new Error(`${path}.viewLayout.tablePosition is invalid.`);
    for (const key of [
      'showTitle',
      'showRecordCounts',
      'showFilterSummaries',
      'showChartDescriptions',
    ])
      if (layout[key] !== undefined && typeof layout[key] !== 'boolean')
        throw new Error(`${path}.viewLayout.${key} must be Boolean.`);
  }
  for (const [id, color] of Object.entries(body.columnHighlights ?? {})) {
    if (!columns.some((column) => column.id === id) || !isColumnHighlightColor(color))
      throw new Error(`${path}.columnHighlights is invalid.`);
  }
  for (const id of Object.keys(body.columnCategories ?? {}))
    if (!columns.some((column) => column.id === id))
      throw new Error(`${path}.columnCategories references an unknown field.`);
  validateGrid(body, model, columns, path);
  if (body.charts !== undefined) list(body.charts, `${path}.charts`);
  const charts = viewCharts(body as WidgetConfiguration);
  unique(
    charts.map((chart) => string(chart.id, `${path}.chart.id`)),
    `${path}.charts`,
  );
  if (
    body.charts?.length &&
    body.chart &&
    !body.charts.some((chart: any) => chart.id === body.chart.id)
  )
    throw new Error(`${path}.chart must select one of its saved charts.`);
  const validateChart = (chart: any) => {
    record(chart, `${path}.chart`);
    validateChartPlan(chart.plan, columns);
    validateFilterControls(chart.filterControls, `${path}.chart.filterControls`);
    if (chart.dataScope) {
      if (!['advanced', 'columns'].includes(chart.dataScope.mode))
        throw new Error(`${path}.chart.dataScope mode is invalid.`);
      fromModel(chart.dataScope.filterModel, chart.dataScope.mode, columns);
    }
    chart.presentation = persistedPresentation(chart.presentation);
  };
  charts.forEach(validateChart);
  if (body.chart && !charts.includes(body.chart)) validateChart(body.chart);
}

function validateDashboard(
  body: Record<string, any>,
  path: string,
  resources: Map<string, Resource<any>>,
  revisions: WorkspaceDocument['revisions'],
): void {
  if (![1, 2].includes(body.schemaVersion))
    throw new Error(`${path}.schemaVersion is unsupported.`);
  const items = list(body.items, `${path}.items`);
  unique(
    items.map((item) => string(item.id, `${path}.item.id`)),
    `${path}.items`,
  );
  const sections = new Set(items.filter((item) => item.kind === 'section').map((item) => item.id));
  for (const item of items) {
    record(item, `${path}.item`);
    for (const field of ['x', 'y']) integer(item[field], `${path}.item.${field}`);
    for (const field of ['w', 'h']) integer(item[field], `${path}.item.${field}`, 1);
    if (item.x + item.w > 12) throw new Error(`${path}.item is outside the twelve-column layout.`);
    if (
      item.sectionId &&
      (!sections.has(item.sectionId) || item.sectionId === item.id || item.kind === 'section')
    )
      throw new Error(`${path}.item has an invalid section parent.`);
    if (
      ![
        'view',
        'chart',
        'table',
        'filter',
        'section',
        'richtext',
        'image',
        'powerbi',
        'text',
        'html',
      ].includes(item.kind ?? 'view')
    )
      throw new Error(`${path}.item.kind is unsupported.`);
    if (item.widgetId) {
      const view = resources.get(item.widgetId);
      const version = integer(item.widgetRevision, `${path}.item.widgetRevision`, 1);
      const pinned = revisions[item.widgetId]?.[version];
      if (!view || view.kind !== 'WIDGET' || !pinned || pinned.kind !== 'WIDGET')
        throw new Error(`${path}.item must pin an available published view revision.`);
      const model = resources.get(pinned.modelId!)?.body as ModelDefinition;
      const columns = [
        ...model.columns,
        ...pinned.body.calculatedColumns.map((definition: any) =>
          calculatedColumnSpec(definition, model.columns),
        ),
      ];
      if (
        item.kind === 'chart' &&
        !viewCharts(pinned.body).some((chart) => chart.id === item.chartId)
      )
        throw new Error(`${path}.item.chartId is not in the pinned view.`);
      if (item.viewOverrides)
        validateWidget(
          { ...pinned.body, ...item.viewOverrides },
          model,
          `${path}.item.viewOverrides`,
        );
      if (item.kind === 'table' && item.overrides)
        validateWidget({ ...pinned.body, ...item.overrides }, model, `${path}.item.tableOverrides`);
      if (item.kind === 'chart' && item.overrides) {
        const chart = viewCharts(pinned.body).find((chart) => chart.id === item.chartId)!;
        validateChartPlan(
          {
            ...chart.plan,
            type: item.overrides.chartType ?? chart.plan.type,
            title: item.overrides.title ?? chart.plan.title,
          },
          columns,
        );
        validateFilterControls(
          item.overrides.filterControls,
          `${path}.item.chartOverrides.filterControls`,
        );
        if (item.overrides.dataScope)
          fromModel(item.overrides.dataScope.filterModel, item.overrides.dataScope.mode, columns);
      }
      if (item.kind === 'filter') {
        const filter = record(item.filter, `${path}.item.filter`);
        if (!['advanced', 'columns'].includes(filter.mode))
          throw new Error(`${path}.item.filter mode is invalid.`);
        fromModel(filter.filterModel, filter.mode, columns);
        for (const control of item.controls ?? []) {
          if (!['window', 'bucket', 'values', 'groupBy'].includes(control.type))
            throw new Error(`${path}.item.control type is unsupported.`);
          if (control.type === 'window' || control.type === 'values') {
            const field = columns.find((column) => column.id === control.columnId);
            if (!field || (control.type === 'window' && field.kind !== 'datetime'))
              throw new Error(`${path}.item.control references an unsupported field.`);
          }
          if (
            control.type === 'groupBy' &&
            list(control.options, `${path}.item.control.options`).some(
              (option) => !columns.some((column) => column.id === option.columnId),
            )
          )
            throw new Error(`${path}.item.control contains an unknown grouping field.`);
          if (control.type === 'window' || control.type === 'bucket')
            for (const option of list(control.options, `${path}.item.control.options`))
              integer(option, `${path}.item.control.option`, 1);
        }
      }
    } else if (['view', 'chart', 'table', 'filter'].includes(item.kind ?? 'view'))
      throw new Error(`${path}.item needs a pinned view.`);
  }
}

/** Validates the entire resource graph before returning an isolated, normalized JSON document. */
export function validateWorkspaceDocument(input: unknown): WorkspaceDocument {
  try {
    const document = documentSchema.parse(cloneJson(input)) as unknown as WorkspaceDocument;
    rejectRowData(document, 'document');
    const resources = new Map<string, Resource<any>>();
    for (const kind of ['models', 'widgets', 'dashboards'] as Collection[]) {
      unique(
        document.resources[kind].map((item) => item.slug),
        `${kind} slugs`,
      );
      for (const item of document.resources[kind]) {
        if (
          item.kind !==
            ({ models: 'MODEL', widgets: 'WIDGET', dashboards: 'DASHBOARD' } as const)[kind] ||
          resources.has(item.id)
        )
          throw new Error('Resource kinds and IDs must be consistent and unique.');
        if (
          !item.name.trim() ||
          (item.publishedVersion !== null && item.publishedVersion > item.version)
        )
          throw new Error(`Resource ${item.id} has invalid name or versions.`);
        resources.set(item.id, item);
      }
    }
    for (const model of document.resources.models) validateModel(model.body, `model ${model.id}`);
    unique(
      document.sources.map((source) => string(source.key, 'source.key')),
      'source keys',
    );
    for (const source of document.sources) {
      string(source.name, 'source.name');
      validateModel(source, `source ${source.key}`);
      if (source.key !== source.sourceKey) throw new Error('Source key and sourceKey must agree.');
    }
    const all = [...resources.values()];
    for (const [id, versions] of Object.entries(document.revisions)) {
      const current = resources.get(id);
      if (!current) throw new Error(`Revision owner ${id} is missing.`);
      for (const [version, item] of Object.entries(versions)) {
        if (
          !/^[1-9]\d*$/.test(version) ||
          item.id !== id ||
          item.kind !== current.kind ||
          item.version !== Number(version) ||
          item.publishedVersion !== item.version ||
          item.version > current.version ||
          item.slug !== current.slug
        )
          throw new Error(`Revision ${id}/${version} has inconsistent publication identity.`);
        all.push(item);
      }
    }
    for (const item of resources.values())
      if (item.publishedVersion !== null && !document.revisions[item.id]?.[item.publishedVersion])
        throw new Error(`Publication ${item.id}/${item.publishedVersion} is missing.`);
    for (const item of all) {
      if (item.kind === 'MODEL') {
        validateModel(item.body, `model ${item.id}`);
        continue;
      }
      if (item.modelId !== null && resources.get(item.modelId)?.kind !== 'MODEL')
        throw new Error(`Resource ${item.id} references a missing model.`);
      if (item.kind === 'WIDGET') {
        const model = resources.get(item.modelId!);
        if (!model || model.kind !== 'MODEL')
          throw new Error(`View ${item.id} needs an available model.`);
        validateWidget(item.body, model.body, `view ${item.id}`);
      }
    }
    for (const item of all)
      if (item.kind === 'DASHBOARD')
        validateDashboard(item.body, `dashboard ${item.id}`, resources, document.revisions);
    return document;
  } catch (error) {
    if (error instanceof WorkspaceError) throw error;
    throw new WorkspaceError(
      422,
      'WORKSPACE_DOCUMENT',
      error instanceof Error ? error.message : String(error),
    );
  }
}

/** Exports no rows, browser UI, preferences, volatile grid state or native chart render IDs. */
export function exportWorkspaceDocument(
  state: Pick<WorkspaceState, 'resources' | 'revisions' | 'sources'>,
): WorkspaceDocument {
  const document = cloneJson({
    format: 'prism-charting-workspace',
    schemaVersion: WORKSPACE_DOCUMENT_VERSION,
    resources: state.resources,
    revisions: state.revisions,
    sources: state.sources,
  });
  // Existing thumbnails can contain aggregate observations; preserve only their schematic metadata.
  for (const item of [
    ...Object.values(document.resources).flat(),
    ...Object.values(document.revisions).flatMap((versions) => Object.values(versions as object)),
  ] as Resource<any>[])
    if (item.body.preview) delete item.body.preview.rows;
  return validateWorkspaceDocument(document);
}

/** Atomic callers validate first, then replace metadata and discard snapshots/session UI. */
export function hydrateWorkspaceDocument(
  input: unknown,
  preferences: Preferences = defaultPreferences(),
): WorkspaceState {
  const document = validateWorkspaceDocument(input);
  return {
    resources: document.resources,
    revisions: document.revisions,
    sources: document.sources,
    datasets: {},
    preferences: structuredClone(preferences),
    ui: {},
  };
}
