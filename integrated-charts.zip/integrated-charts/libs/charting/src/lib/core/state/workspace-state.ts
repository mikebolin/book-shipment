import type { Collection, Resource, ModelDefinition } from '../domain/workspace.types';
import type { StreamRow } from '../../explorer/ndjson-row-stream';
import type { WorkspaceCard, WorkspacePreview } from '../domain/workspace-cards';
import type { ChartingSeed } from '../data-access/charting-data';
import { viewCharts } from '../../rendering/view-charts';
import type { WidgetConfiguration, DashboardConfiguration, ChartOverrides } from '../domain/workspace.types';

export interface Preferences {
  version: number;
  themeId: string;
  density: 'compact' | 'comfortable';
  reducedMotion: boolean;
  settings?: {
    skipPublishConfirmation?: boolean;
    chartGalleryPageSize?: 8 | 16 | 32;
    chartGalleryColumns?: 1 | 2 | 3 | 4;
    galleryDensity?: 'grid' | 'list';
    galleryGroupBy?: 'none' | 'model' | 'group';
  };
}
export interface WorkspaceState {
  resources: Record<Collection, Resource<any>[]>;
  revisions: Record<string, Record<number, Resource<any>>>;
  datasets: Record<string, readonly StreamRow[]>;
  sources: (ModelDefinition & { key: string; name: string })[];
  preferences: Preferences;
  ui: Record<string, Record<string, unknown>>;
}
export const defaultPreferences = (): Preferences => ({
  version: 0,
  themeId: 'azure-blue',
  density: 'compact',
  reducedMotion: false,
  settings: {},
});
export function createInitialState(
  seed: ChartingSeed = {
    resources: { models: [], widgets: [], dashboards: [] },
    revisions: {},
    datasets: {},
    sources: [],
  },
): WorkspaceState {
  return { ...structuredClone(seed), preferences: defaultPreferences(), ui: {} };
}
export class WorkspaceError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
  ) {
    super(message);
  }
}
export function getResource<T = any>(
  s: WorkspaceState,
  kind: Collection,
  key: string,
  published = false,
  revision?: number,
): Resource<T> {
  const item = s.resources[kind].find((r) => r.id === key || r.slug === key);
  if (!item) throw new WorkspaceError(404, 'NOT_FOUND', 'This resource is no longer available.');
  const selected = revision ?? (published ? item.publishedVersion : null);
  if (published && selected === null)
    throw new WorkspaceError(404, 'UNPUBLISHED', 'This resource has not been published.');
  const resource = selected === null ? item : s.revisions[item.id]?.[selected!];
  if (!resource)
    throw new WorkspaceError(404, 'REVISION_NOT_FOUND', 'The pinned publication is unavailable.');
  return structuredClone(resource);
}
export function checkVersion(actual: number, expected: number | undefined) {
  if (expected !== actual)
    throw new WorkspaceError(
      409,
      'VERSION_CONFLICT',
      'This item changed. Reload it before saving.',
    );
}
/** Prefer a real placed chart; configuration alone is enough for an honest schematic fallback. */
function resourcePreview(s: WorkspaceState, item: Resource<any>, kind: 'widgets' | 'dashboards'): WorkspacePreview {
  const chartPreview = (configuration: WidgetConfiguration, chartId?: string): WorkspacePreview | null => {
    const charts = viewCharts(configuration);
    const chart = chartId ? charts.find((chart) => chart.id === chartId) : charts[0];
    if (!chart) return null;
    const saved = configuration.preview;
    if (saved?.type === 'chart' && chart.id === configuration.chart?.id && saved.chartType === chart.plan.type)
      return { ...saved, title: chart.plan.title };
    return { schemaVersion: 1, type: 'chart', chartType: chart.plan.type, title: chart.plan.title };
  };
  if (kind === 'widgets')
    return chartPreview(item.body) ?? item.body.preview ?? { schemaVersion: 1, type: 'summary', label: 'Data table' };
  const body = item.body as DashboardConfiguration;
  for (const placement of [...body.items].sort((a, b) => a.y - b.y || a.x - b.x)) {
    if (!placement.widgetId || ['table', 'filter'].includes(placement.kind ?? '') || placement.displayMode === 'grid') continue;
    try {
      const view = getResource<WidgetConfiguration>(s, 'widgets', placement.widgetId, true, placement.widgetRevision);
      let configuration = { ...view.body, ...placement.viewOverrides };
      if (placement.kind === 'chart' && placement.overrides) {
        const overrides = placement.overrides as ChartOverrides;
        configuration = { ...configuration, charts: viewCharts(configuration).map((chart) => chart.id === placement.chartId
          ? { ...chart, plan: { ...chart.plan, type: overrides.chartType ?? chart.plan.type, title: overrides.title ?? chart.plan.title }, presentation: overrides.presentation ?? chart.presentation } : chart) };
        configuration.chart = configuration.charts?.find((chart) => chart.id === configuration.chart?.id) ?? null;
        configuration.preview = undefined;
      }
      const preview = chartPreview(configuration, placement.kind === 'chart' ? placement.chartId : undefined);
      if (preview) return preview;
    } catch {
      // Missing pinned views retain an inert layout thumbnail; the dashboard reports the error on open.
    }
  }
  return { schemaVersion: 1, type: 'dashboard', items: body.items };
}

export function cards(
  s: WorkspaceState,
  kind: 'widgets' | 'dashboards',
  published: boolean,
): WorkspaceCard[] {
  return s.resources[kind]
    .filter((r) => !published || r.publishedVersion !== null)
    .map((original) => {
      const item = getResource<any>(s, kind, original.id, published);
      const model = s.resources.models.find((m) => m.id === item.modelId);
      return {
        id: item.id,
        slug: item.slug,
        name: item.name,
        description: item.description,
        modelId: item.modelId,
        modelName: model?.name,
        modelSlug: model?.slug,
        version: original.version,
        publishedVersion: original.publishedVersion,
        updatedAt: item.updatedAt,
        preview: resourcePreview(s, item, kind),
        group: item.body.group,
        tags: item.body.tags ?? [],
        itemCount: item.body.items?.length,
        chartCount: item.body.charts?.length ?? (item.body.chart ? 1 : 0),
        canEdit: true,
        canManage: true,
        canDelete: true,
      };
    });
}
export interface ResourceInput {
  name: string;
  description?: string;
  modelId?: string | null;
  sourceKey?: string;
  body?: any;
}
function validateInput(
  s: WorkspaceState,
  kind: Collection,
  input: ResourceInput,
  prior?: Resource<any>,
) {
  if (!input.name?.trim() || input.name.length > 160)
    throw new WorkspaceError(422, 'NAME', 'Enter a name of 1–160 characters.');
  if (
    kind === 'widgets' &&
    !s.resources.models.some((m) => m.id === (input.modelId ?? prior?.modelId))
  )
    throw new WorkspaceError(422, 'MODEL', 'Select a model for this view.');
  const body = input.body ?? prior?.body;
  if (kind !== 'models' && (!body || typeof body !== 'object'))
    throw new WorkspaceError(422, 'BODY', 'Resource configuration is required.');
  if (kind === 'dashboards') {
    if (!Array.isArray(body.items))
      throw new WorkspaceError(422, 'ITEMS', 'Dashboard elements are required.');
    const ids = body.items.map((i: any) => i.id);
    if (new Set(ids).size !== ids.length)
      throw new WorkspaceError(422, 'ELEMENT_ID', 'Dashboard element IDs must be unique.');
    for (const placement of body.items)
      if (placement.widgetId) {
        const view = getResource(s, 'widgets', placement.widgetId, true, placement.widgetRevision);
        if (!view)
          throw new WorkspaceError(422, 'PUBLICATION', 'Publish each view before adding it.');
      }
  }
}
export function saveResource(
  s: WorkspaceState,
  kind: Collection,
  input: ResourceInput,
  prior?: Resource<any>,
): { state: WorkspaceState; resource: Resource<any> } {
  const current = prior ? getResource(s, kind, prior.id) : undefined;
  if (current) {
    checkVersion(current.version, prior!.version);
  }
  validateInput(s, kind, input, current);
  const id = current?.id ?? crypto.randomUUID();
  const source =
    kind === 'models'
      ? s.sources.find((source) => source.key === (input.sourceKey ?? current?.body.sourceKey))
      : undefined;
  if (kind === 'models' && !source)
    throw new WorkspaceError(422, 'SOURCE', 'Choose an available mock source.');
  const now = new Date().toISOString();
  const resource: Resource<any> = {
    id,
    kind: kind === 'models' ? 'MODEL' : kind === 'widgets' ? 'WIDGET' : 'DASHBOARD',
    slug:
      current?.slug ??
      input.name
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-|-$/g, '') +
        '-' +
        id.slice(0, 8),
    name: input.name.trim(),
    description: input.description ?? '',
    modelId: input.modelId ?? current?.modelId ?? null,
    version: (current?.version ?? 0) + 1,
    publishedVersion: current?.publishedVersion ?? null,
    body: structuredClone(source ?? input.body ?? current?.body),
    createdAt: current?.createdAt ?? now,
    updatedAt: now,
  };
  const resources = {
    ...s.resources,
    [kind]: current
      ? s.resources[kind].map((r) => (r.id === id ? resource : r))
      : [...s.resources[kind], resource],
  };
  return { state: { ...s, resources }, resource: structuredClone(resource) };
}
export function publishResource(
  s: WorkspaceState,
  kind: 'widgets' | 'dashboards',
  prior: Resource<any>,
) {
  const current = getResource(s, kind, prior.id);
  checkVersion(current.version, prior.version);
  const resource = { ...current, publishedVersion: current.version };
  return {
    state: {
      ...s,
      resources: {
        ...s.resources,
        [kind]: s.resources[kind].map((r) => (r.id === prior.id ? resource : r)),
      },
      revisions: {
        ...s.revisions,
        [prior.id]: { ...s.revisions[prior.id], [resource.version]: structuredClone(resource) },
      },
    },
    resource,
  };
}
export function removeResource(
  s: WorkspaceState,
  kind: Collection,
  prior: Resource<any>,
): WorkspaceState {
  const current = getResource(s, kind, prior.id);
  checkVersion(current.version, prior.version);
  if (kind === 'models' && s.resources.widgets.some((w) => w.modelId === prior.id))
    throw new WorkspaceError(409, 'IN_USE', 'This model is used by saved views.');
  // Both drafts and every immutable publication may pin a view.
  const dashboards = [
    ...s.resources.dashboards,
    ...Object.values(s.revisions)
      .flatMap((v) => Object.values(v))
      .filter((r) => r.kind === 'DASHBOARD'),
  ];
  if (
    kind === 'widgets' &&
    dashboards.some((d) => d.body.items.some((i: any) => i.widgetId === prior.id))
  )
    throw new WorkspaceError(409, 'IN_USE', 'This view is pinned by a dashboard.');
  const revisions = { ...s.revisions };
  delete revisions[prior.id];
  return {
    ...s,
    resources: { ...s.resources, [kind]: s.resources[kind].filter((r) => r.id !== prior.id) },
    revisions,
  };
}
