import { CHARTING_DATA } from '../data-access/charting-data';
import { computed, inject, untracked } from '@angular/core';
import {
  signalStore,
  withState,
  withMethods,
  withComputed,
  patchState,
  getState,
} from '@ngrx/signals';
import type { Collection, Resource, ModelResource } from '../domain/workspace.types';
import type { StreamRow } from '../../explorer/ndjson-row-stream';
import { exportWorkspaceDocument, hydrateWorkspaceDocument } from './workspace-document';
import {
  cards,
  checkVersion,
  createInitialState,
  defaultPreferences,
  getResource,
  publishResource,
  removeResource,
  saveResource,
  WorkspaceError,
  type Preferences,
  type ResourceInput,
} from './workspace-state';

/** The single root state owner. Facades perform local work and commit through these methods. */
export const WorkspaceStore = signalStore(
  { providedIn: 'root' },
  withState(() => createInitialState(inject(CHARTING_DATA).createSeed())),
  withComputed((s) => ({
    currentPreferences: computed(() => s.preferences()),
    modelList: computed(() => s.resources.models() as ModelResource[]),
  })),
  withMethods((s) => {
    let snapshotGeneration = 0;
    const data = inject(CHARTING_DATA);
    const snapshot = () => {
      s.resources();
      s.revisions();
      return untracked(() => getState(s));
    };
    return {
      exportDocument() {
        return exportWorkspaceDocument(getState(s));
      },
      importDocument(input: unknown) {
        const next = hydrateWorkspaceDocument(input, s.preferences());
        snapshotGeneration++;
        patchState(s, next);
      },
      snapshotGeneration() {
        return snapshotGeneration;
      },
      list<T>(kind: Collection, published = false): Resource<T>[] {
        return s
          .resources()
          [kind].filter((r) => !published || r.publishedVersion !== null)
          .map((r) => getResource<T>(snapshot(), kind, r.id, published));
      },
      get<T>(kind: Collection, key: string, published = false, revision?: number) {
        return getResource<T>(snapshot(), kind, key, published, revision);
      },
      cards(kind: 'widgets' | 'dashboards', published = true) {
        return cards(snapshot(), kind, published);
      },
      create<T>(kind: Collection, input: ResourceInput): Resource<T> {
        const result = saveResource(getState(s), kind, input);
        patchState(s, result.state);
        return result.resource;
      },
      update<T>(kind: Collection, prior: Resource<T>, input: ResourceInput): Resource<T> {
        const result = saveResource(getState(s), kind, input, prior);
        patchState(s, result.state);
        return result.resource;
      },
      publish<T>(kind: 'widgets' | 'dashboards', prior: Resource<T>): Resource<T> {
        const result = publishResource(getState(s), kind, prior);
        patchState(s, result.state);
        return structuredClone(result.resource);
      },
      remove(kind: Collection, prior: Resource<any>) {
        patchState(s, removeResource(getState(s), kind, prior));
      },
      refreshModel(prior: Resource<any>) {
        checkVersion(getResource(getState(s), 'models', prior.id).version, prior.version);
        const result = saveResource(
          getState(s),
          'models',
          { name: prior.name, description: prior.description, body: prior.body },
          prior,
        );
        patchState(s, result.state);
        return result.resource;
      },
      setDataset(key: string, rows: readonly StreamRow[]) {
        patchState(s, { datasets: { ...s.datasets(), [key]: rows } });
      },
      registerSource(source: any) {
        if (!s.sources().some((x) => x.key === source.key))
          patchState(s, { sources: [...s.sources(), source] });
      },
      savePreferences(value: Omit<Preferences, 'version'>, version: number) {
        checkVersion(s.preferences().version, version);
        const next = { ...structuredClone(value), version: version + 1 };
        patchState(s, { preferences: next });
        return next;
      },
      setUi(scope: string, key: string, value: unknown) {
        if (Object.is(s.ui()[scope]?.[key], value)) return;
        patchState(s, { ui: { ...s.ui(), [scope]: { ...s.ui()[scope], [key]: value } } });
      },
      clearUi(scope: string) {
        if (!Object.hasOwn(s.ui(), scope)) return;
        const ui = { ...s.ui() };
        delete ui[scope];
        patchState(s, { ui });
      },
      resetDemo() {
        snapshotGeneration++;
        patchState(s, createInitialState(data.createSeed()));
      },
    };
  }),
);
