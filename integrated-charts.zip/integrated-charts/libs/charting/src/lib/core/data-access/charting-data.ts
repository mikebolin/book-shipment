import type { GridReviewPreviewPack } from '../../explorer/demo-grid-preview-loader';
import type { ChartPreviewPack } from '../../explorer/demo-chart-preview-loader';
import { InjectionToken, makeEnvironmentProviders } from '@angular/core';
import type {
  Collection,
  ModelDefinition,
  ModelResource,
  Resource,
} from '../domain/workspace.types';
import type { StreamRow } from '../../explorer/ndjson-row-stream';
import type { ClientDataSourceId } from '../../explorer/client-data-sources';
import type { LocalDataset } from '../../explorer/client-data-sources';
import type { PromptExample } from '../../explorer/prompt-examples';
import type { PowerBiReport } from '../domain/powerbi-library';

export interface ChartingSeed {
  resources: Record<Collection, Resource<any>[]>;
  revisions: Record<string, Record<number, Resource<any>>>;
  datasets: Record<string, readonly StreamRow[]>;
  sources: (ModelDefinition & { key: string; name: string })[];
}

/** Host-owned data boundary. Charting never imports a host module or a sibling library. */
export interface ChartingDataSource {
  createSeed(): ChartingSeed;
  loadSnapshot(model: ModelResource, signal: AbortSignal): Promise<Response>;
  loadAsset(path: string, signal?: AbortSignal): Promise<Response>;
  sampleOptions?: readonly { id: ClientDataSourceId; label: string }[];
  /** Optional host-owned starter datasets; the library has no built-in sample catalog. */
  loadSample?(source: ClientDataSourceId): Promise<LocalDataset | undefined>;
  loadGridPreviews?(source: string): Promise<GridReviewPreviewPack>;
  loadChartPreviews?(source: string): Promise<ChartPreviewPack>;
  reports?: readonly PowerBiReport[];
  prompts?: Readonly<Record<string, readonly PromptExample[]>>;
}

export const CHARTING_DATA = new InjectionToken<ChartingDataSource>('Charting host data', {
  providedIn: 'root',
  factory: () => ({
    createSeed: () => ({
      resources: { models: [], widgets: [], dashboards: [] },
      revisions: {},
      datasets: {},
      sources: [],
    }),
    async loadSnapshot() {
      throw new Error('Provide model rows through CHARTING_DATA or import a file.');
    },
    async loadAsset() {
      throw new Error('This host does not provide bundled sample files.');
    },
    sampleOptions: [],
    reports: [],
  }),
});

export function provideChartingData(source: ChartingDataSource) {
  return makeEnvironmentProviders([{ provide: CHARTING_DATA, useValue: source }]);
}
