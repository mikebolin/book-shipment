import { InjectionToken } from '@angular/core';
import type { WorkspaceDocument } from '../state/workspace-document';

/** Optional, explicitly invoked host storage. The host owns authentication, revisions and conflict handling. */
export interface WorkspacePersistenceAdapter {
  load(signal: AbortSignal): Promise<unknown | null>;
  save(document: WorkspaceDocument, signal: AbortSignal): Promise<void>;
}
export const CHARTING_WORKSPACE_PERSISTENCE =
  new InjectionToken<WorkspacePersistenceAdapter | null>('Charting workspace persistence', {
    providedIn: 'root',
    factory: () => null,
  });
