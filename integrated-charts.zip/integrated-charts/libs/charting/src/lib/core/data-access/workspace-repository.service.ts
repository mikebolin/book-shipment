import { CHARTING_DATA } from './charting-data';
import { Injectable, inject } from '@angular/core';
import { WorkspaceStore, WorkspaceError } from '../state/index';
import type { ResourceInput, Preferences } from '../state/workspace-state';
import type { Collection, ModelResource, Resource } from '../domain/workspace.types';
import type { SnapshotLease, SnapshotData } from '../domain/shared-snapshot';
import { readSnapshot } from '../domain/shared-snapshot';
import type { StreamRow } from '../../explorer/ndjson-row-stream';
import { CHARTING_WORKSPACE_PERSISTENCE } from './workspace-persistence';

export { WorkspaceError as WorkspaceError };
export interface DashboardDataScope {
  dashboardSlug: string;
  placementId: string;
  view: 'published' | 'draft';
  revision?: number;
}

/** In-process facade. All durable-for-the-session state belongs to the root SignalStore. */
@Injectable({ providedIn: 'root' })
export class WorkspaceRepository {
  readonly store = inject(WorkspaceStore);
  private readonly data = inject(CHARTING_DATA);
  private readonly persistence = inject(CHARTING_WORKSPACE_PERSISTENCE, { optional: true });
  private readonly loading = new Map<string, Promise<SnapshotData>>();
  exportDocument() {
    return this.store.exportDocument();
  }
  importDocument(input: unknown) {
    this.store.importDocument(input);
    this.loading.clear();
  }
  async loadDocument(signal: AbortSignal = new AbortController().signal) {
    if (!this.persistence)
      throw new WorkspaceError(
        503,
        'PERSISTENCE_UNAVAILABLE',
        'Provide a host workspace storage adapter to load metadata.',
      );
    signal.throwIfAborted();
    const document = await this.persistence.load(signal);
    signal.throwIfAborted();
    if (document !== null) this.importDocument(document);
    return document === null ? null : this.exportDocument();
  }
  async saveDocument(signal: AbortSignal = new AbortController().signal) {
    if (!this.persistence)
      throw new WorkspaceError(
        503,
        'PERSISTENCE_UNAVAILABLE',
        'Provide a host workspace storage adapter to save metadata.',
      );
    signal.throwIfAborted();
    const document = this.exportDocument();
    await this.persistence.save(document, signal);
    signal.throwIfAborted();
  }
  async list<T>(kind: Collection, published = false) {
    return this.store.list<T>(kind, published);
  }
  async get<T>(kind: Collection, key: string, published = false) {
    return this.store.get<T>(kind, key, published);
  }
  async create<T>(kind: Collection, body: ResourceInput) {
    return this.store.create<T>(kind, body);
  }
  async update<T>(kind: Collection, resource: Resource<T>, body: ResourceInput) {
    return this.store.update<T>(kind, resource, body);
  }
  async publish<T>(kind: 'widgets' | 'dashboards', resource: Resource<T>) {
    return this.store.publish<T>(kind, resource);
  }
  async remove(kind: Collection, resource: Resource<any>) {
    this.store.remove(kind, resource);
  }
  async cards(kind: 'widgets' | 'dashboards', view = 'published') {
    return this.store.cards(kind, view === 'published');
  }
  async sources() {
    return structuredClone(this.store.sources());
  }
  async refreshModel(model: ModelResource) {
    return this.store.refreshModel(model);
  }
  async precache(slug: string) {
    const dashboard = this.store.get<any>('dashboards', slug, true);
    await Promise.all(
      dashboard.body.items
        .filter((item: any) => item.widgetId)
        .map(async (item: any) => {
          const { model } = await this.placement(slug, item.id, 'published', dashboard.version);
          await this.lease(model).result;
        }),
    );
  }
  async placement(slug: string, id: string, view: string, revision?: number) {
    const dashboard = this.store.get<any>('dashboards', slug, view === 'published', revision);
    const item = dashboard.body.items.find((p: any) => p.id === id);
    if (!item?.widgetId)
      throw new WorkspaceError(404, 'PLACEMENT', 'The dashboard element is unavailable.');
    const widget = this.store.get<any>('widgets', item.widgetId, true, item.widgetRevision);
    const model = this.store.get<any>('models', widget.modelId!) as ModelResource;
    return { widget, model };
  }
  async preferences(signal?: AbortSignal) {
    signal?.throwIfAborted();
    return structuredClone(this.store.currentPreferences());
  }
  async savePreferences(value: Omit<Preferences, 'version'>, version: number) {
    return this.store.savePreferences(value, version);
  }

  /** A single local fixture load per source; all tiles share the exact same stored row array. */
  lease(model: ModelResource, _scope?: DashboardDataScope): SnapshotLease {
    const key = model.body.sourceKey;
    const rows = this.store.datasets()[key];
    let result = rows
      ? Promise.resolve({ rows, decodedBytes: 0, receivedAt: 0 })
      : this.loading.get(key);
    if (!result) {
      result = this.loadFixture(model);
      this.loading.set(key, result);
      const current = result;
      void result
        .finally(() => {
          if (this.loading.get(key) === current) this.loading.delete(key);
        })
        .catch(() => undefined);
    }
    // The store owns the shared dataset for this page's lifetime. A released consumer cannot
    // cancel another tile's load; consumers already use generation checks during teardown.
    return { result, release() {} };
  }
  private async loadFixture(model: ModelResource): Promise<SnapshotData> {
    const generation = this.store.snapshotGeneration();
    const key = model.body.sourceKey;
    const decoded = await this.data.loadSnapshot(model, new AbortController().signal);
    const snapshot = await readSnapshot(
      decoded,
      {
        key,
        schemaVersion: model.body.schemaVersion,
        datetimeColumns: model.body.columns.filter((c) => c.kind === 'datetime').map((c) => c.id),
      },
      new AbortController().signal,
      { maxDecodedBytes: 512 * 1024 * 1024 },
    );
    if (generation !== this.store.snapshotGeneration())
      throw new WorkspaceError(
        409,
        'WORKSPACE_REPLACED',
        'The workspace changed while this snapshot was loading.',
      );
    this.store.setDataset(key, snapshot.rows as readonly StreamRow[]);
    return snapshot;
  }
}
