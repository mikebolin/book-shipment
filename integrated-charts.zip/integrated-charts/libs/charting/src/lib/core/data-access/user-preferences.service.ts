import { DOCUMENT } from '@angular/common';
import { Injectable, computed, effect, inject, untracked } from '@angular/core';
import { AppThemeService } from '../../explorer/app-theme.service';
import { WorkspaceStore, injectUiState } from '../state/index';
export interface UserSettings {
  skipPublishConfirmation?: boolean;
  chartGalleryPageSize?: 8 | 16 | 32;
  chartGalleryColumns?: 1 | 2 | 3 | 4;
  galleryDensity?: 'grid' | 'list';
  galleryGroupBy?: 'none' | 'model' | 'group';
}
export interface UserPreferences {
  version: number;
  themeId: string;
  density: 'compact' | 'comfortable';
  reducedMotion: boolean;
  settings?: UserSettings;
}
@Injectable({ providedIn: 'root' })
export class UserPreferencesService {
  private readonly store = inject(WorkspaceStore);
  private readonly theme = inject(AppThemeService);
  private readonly document = inject(DOCUMENT);
  private readonly state = injectUiState('Preferences');
  readonly current = this.store.currentPreferences;
  readonly loading = this.state.signal(false);
  readonly error = this.state.signal('');
  readonly settings = computed<Required<UserSettings>>(() => ({
    skipPublishConfirmation: false,
    chartGalleryPageSize: 8,
    chartGalleryColumns: 2,
    galleryDensity: 'grid',
    galleryGroupBy: 'none',
    ...(this.current().settings ?? {}),
  }));
  constructor() {
    effect(() => {
      const prefs = this.current();
      untracked(() => this.theme.setTheme(prefs.themeId));
      const root = this.document.documentElement;
      root.dataset['uiDensity'] = prefs.density;
      root.dataset['reducedMotion'] = String(prefs.reducedMotion);
    });
  }
  async reload() {
    this.error.set('');
  }
  async save(prefs: Omit<UserPreferences, 'version' | 'settings'> & { settings?: UserSettings }) {
    this.store.savePreferences(
      { ...prefs, settings: prefs.settings ?? this.current().settings ?? {} },
      this.current().version,
    );
    this.error.set('');
  }
  async updateSettings(patch: UserSettings) {
    const { version, settings, ...rest } = this.current();
    await this.save({ ...rest, settings: { ...settings, ...patch } });
  }
}
