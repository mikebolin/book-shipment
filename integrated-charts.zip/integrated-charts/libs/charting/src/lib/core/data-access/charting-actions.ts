import { InjectionToken } from '@angular/core';
import type { WidgetResource } from '../domain/workspace.types';

/** Optional integration points. Missing integrations hide the corresponding commands. */
export interface ChartingActions {
  addToDashboard?(view: WidgetResource): Promise<void>;
}
export const CHARTING_ACTIONS = new InjectionToken<ChartingActions>('Charting host actions', {
  providedIn: 'root',
  factory: () => ({}),
});
