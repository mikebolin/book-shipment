import { Injectable, inject } from '@angular/core';
import { BrowserDataCache } from '../../explorer/browser-data-cache';
import {
  calculatedColumnSpec,
  type CalculatedColumnDefinition,
} from '../domain/calculated-columns';
import type { ColumnSpec } from '../domain/schema';
import type { ClientDataSourceId } from '../../explorer/client-data-sources';
import type { StreamRow } from '../../explorer/ndjson-row-stream';
import { WorkspaceRepository, type DashboardDataScope } from './workspace-repository.service';
import type { SnapshotLease } from '../domain/shared-snapshot';
import type { ModelResource } from '../domain/workspace.types';

/** What a tile needs to render: the shared cache, the materialized grid rows and the column specs. */
export interface DashboardData {
  readonly source: ClientDataSourceId;
  readonly cache: BrowserDataCache;
  readonly rows: readonly StreamRow[];
  readonly specs: readonly ColumnSpec[];
}
export interface DashboardDataHandle {
  readonly key: string;
  readonly ready: Promise<DashboardData>;
  release(): void;
}
interface Entry {
  key: string;
  refs: number;
  lease: SnapshotLease;
  ready: Promise<DashboardData>;
}

/**
 * One dataset per (model, schema version, dashboard scope, calculated columns) per composer.
 * The snapshot download is already deduplicated by `SharedSnapshotCache`; this service also
 * builds the grid rows once and hands every chart and table tile the same cache, so a dashboard
 * with a dozen elements from one model holds its rows in memory once. Entries are reference
 * counted and released when the last tile goes away.
 */
@Injectable()
export class DashboardDataService {
  private readonly workspace = inject(WorkspaceRepository);
  private readonly entries = new Map<string, Entry>();

  static key(
    model: ModelResource,
    scope: DashboardDataScope | undefined,
    calculatedColumns: readonly CalculatedColumnDefinition[] = [],
  ): string {
    return JSON.stringify([
      model.id,
      model.body.schemaVersion,
      model.body.dataVersion,
      scope ? [scope.dashboardSlug, scope.view, scope.revision ?? null] : null,
      calculatedColumns.map((column) => [column.id, column.expression]),
    ]);
  }

  /** Number of live datasets (tests and the performance profile read this). */
  get size() {
    return this.entries.size;
  }
  refs(key: string) {
    return this.entries.get(key)?.refs ?? 0;
  }

  acquire(
    model: ModelResource,
    scope: DashboardDataScope | undefined,
    calculatedColumns: readonly CalculatedColumnDefinition[] = [],
  ): DashboardDataHandle {
    const key = DashboardDataService.key(model, scope, calculatedColumns);
    let entry = this.entries.get(key);
    if (!entry) {
      const lease = this.workspace.lease(model, scope);
      const source = model.body.clientSourceId as ClientDataSourceId;
      const definitions = structuredClone([...calculatedColumns]);
      const ready = lease.result.then((snapshot): DashboardData => {
        const cache = new BrowserDataCache();
        cache.setRows(source, snapshot.rows as StreamRow[], model.body.columns);
        cache.setCalculatedColumns(source, definitions);
        const specs = [
          ...model.body.columns,
          ...definitions.map((column) => calculatedColumnSpec(column, model.body.columns)),
        ];
        return { source, cache, rows: cache.getGridRows(source) as StreamRow[], specs };
      });
      entry = { key, refs: 0, lease, ready };
      this.entries.set(key, entry);
      // A failed download must not poison later tiles: drop the entry so the next acquire retries.
      ready.catch(() => {
        if (this.entries.get(key) === entry) {
          this.entries.delete(key);
          entry!.lease.release();
        }
      });
    }
    const current = entry;
    current.refs++;
    let released = false;
    return {
      key,
      ready: current.ready,
      release: () => {
        if (released) return;
        released = true;
        current.refs--;
        if (current.refs <= 0 && this.entries.get(key) === current) {
          this.entries.delete(key);
          current.lease.release();
        }
      },
    };
  }

  /** Release every dataset (composer teardown). */
  clear() {
    for (const entry of this.entries.values()) entry.lease.release();
    this.entries.clear();
  }
}
