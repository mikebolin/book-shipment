import { CHARTING_ACTIONS } from '../core/data-access/charting-actions';
import { CHARTING_DATA } from '../core/data-access/charting-data';
import { injectUiState } from '../core/state/index';
import { Component, DestroyRef, computed, inject } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDialog } from '@angular/material/dialog';
import { Clipboard } from '@angular/cdk/clipboard';
import { firstValueFrom } from 'rxjs';
import {
  WorkspaceRepository,
  WorkspaceError,
} from '../core/data-access/workspace-repository.service';
import type { WorkspaceCard } from '../core/domain/workspace-cards';
import type { ModelResource, WidgetConfiguration } from '../core/domain/workspace.types';
import { type PowerBiReport } from '../core/domain/powerbi-library';
import { PowerBiReportDialogComponent } from '../rendering/powerbi-report-dialog.component';
import { ResourceGalleryComponent } from './resource-gallery.component';
import { ResourceCardComponent, type CardAction } from '../ui/resource-card.component';
import { ConfirmDialogComponent } from '../ui/confirm-dialog.component';
import { UserPreferencesService } from '../core/data-access/user-preferences.service';
import {
  GALLERY_DEFAULTS,
  cardStatus,
  galleryStateFromParams,
  matchesCard,
  sortCards,
  writeGalleryState,
  type GalleryState,
} from './gallery-state';

/** The Views gallery: one grid of cards, each carrying its model, presentation and status. */
@Component({
  standalone: true,
  imports: [
    NgTemplateOutlet,
    RouterLink,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    MatTooltipModule,
    ResourceGalleryComponent,
    ResourceCardComponent,
  ],
  template: `
    <workspace-resource-gallery
      title="Views"
      description="Reusable charts and tables. Keep work in drafts, then publish views for readers and dashboards."
      noun="view"
      [count]="widgets().length + powerBiReports().length"
      searchPlaceholder="Search views"
      searchLabel="Search published views"
      [publicationTabs]="true"
      publicationLabel="View publication"
      [modelSort]="true"
      [groups]="groups()"
      [tags]="tags()"
      [quickFilters]="modelFilters()"
      [quickFilter]="modelFilter()"
      quickFilterLabel="Model"
      [summary]="summary()"
      [loading]="loading()"
      [error]="error()"
      [state]="state()"
      (stateChange)="update($event)"
      (quickFilterChange)="modelFilter.set($event)"
    >
      <ng-container gallery-primary>
        <button
          mat-button
          type="button"
          [matMenuTriggerFor]="createMenu"
          aria-label="Create a view"
          matTooltip="Start a new view on a data model"
        >
          <mat-icon>add</mat-icon>Create view
        </button>
        <mat-menu #createMenu="matMenu" class="create-view-menu">
          <ng-container *ngTemplateOutlet="modelChoices" />
        </mat-menu>
      </ng-container>

      <div class="resource-grid" [class.resource-list]="state().density === 'list'">
        @for (widget of filtered(); track widget.id) {
          <workspace-resource-card
            kind="view"
            [name]="widget.name"
            [description]="widget.description"
            fallbackDescription="Saved configuration."
            [preview]="widget.preview"
            [modelName]="widget.modelName || 'Data model'"
            [kicker]="presentation(widget)"
            [tags]="widget.tags ?? []"
            [selectedTag]="state().tag"
            [status]="status(widget)"
            [updatedAt]="widget.updatedAt"
            [density]="state().density"
            [openLink]="openLink(widget)"
            [openQuery]="openQuery(widget)"
            [actions]="actions(widget)"
            (action)="run(widget, $event)"
            (tagSelect)="update({ tag: state().tag === $event ? '' : $event })"
          />
        }
        @for (report of powerBiReports(); track report.id) {
          <workspace-resource-card
            kind="view"
            [name]="report.name"
            [description]="report.description"
            [modelName]="'Power BI · ' + report.category"
            kicker="Interactive demo report"
            [status]="{ label: 'Public sample', tone: 'neutral' }"
            [density]="state().density"
            [openLink]="['/library']"
            [openQuery]="{ report: report.id }"
            [actions]="[
              { id: 'open', label: 'Open report', icon: 'analytics' },
              { id: 'source', label: 'Source', icon: 'open_in_new' },
            ]"
            (action)="reportAction(report, $event)"
          />
        }
      </div>
      @if (!loading() && !filtered().length && !powerBiReports().length) {
        <div class="empty-state">
          <div class="empty-icon">
            <mat-icon>{{ widgets().length ? 'search_off' : 'view_module' }}</mat-icon>
          </div>
          <h2>
            {{
              widgets().length
                ? 'No matching views'
                : state().pub === 'draft'
                  ? 'No drafts in progress'
                  : 'No published views yet'
            }}
          </h2>
          <p>
            {{
              widgets().length
                ? 'Try another search, model, group or tag.'
                : 'Open a data model, build a view, and publish it here.'
            }}
          </p>
          @if (widgets().length) {
            <button
              mat-button
              type="button"
              (click)="update({ q: '', group: '', tag: '' }); modelFilter.set('all')"
            >
              Clear filters
            </button>
          } @else if (true) {
            <button mat-button type="button" [matMenuTriggerFor]="emptyCreateMenu">
              <mat-icon>add</mat-icon>Create a view
            </button>
            <mat-menu #emptyCreateMenu="matMenu" class="create-view-menu">
              <ng-container *ngTemplateOutlet="modelChoices" />
            </mat-menu>
          }
        </div>
      }
    </workspace-resource-gallery>
    <ng-template #modelChoices>
      <p class="menu-heading">Choose a data model</p>
      @for (model of models(); track model.id) {
        <a mat-menu-item [routerLink]="['/studio', model.slug]" [queryParams]="{ view: 'new' }">
          <mat-icon>storage</mat-icon><span>{{ model.name }}</span>
        </a>
      } @empty {
        <button mat-menu-item disabled>No data models yet</button>
      }
      <a mat-menu-item routerLink="/studio/import">
        <mat-icon>upload_file</mat-icon><span>Import CSV or JSON</span>
      </a>
    </ng-template>
  `,
  styles: `
    .resource-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(min(100%, 280px), min(100%, 344px)));
      gap: 20px;
      align-items: stretch;
    }
    @container (min-width: 480px) and (max-width: 720px) {
      .resource-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
      }
    }
    .resource-grid.resource-list {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .menu-heading {
      margin: 6px 16px 4px;
      font-size: 11px;
      font-weight: 600;
      color: var(--ws-muted);
    }
    .empty-state a mat-icon,
    .empty-state button mat-icon {
      margin-right: 6px;
    }
  `,
})
export class LibraryComponent {
  readonly hostActions = inject(CHARTING_ACTIONS);
  readonly hostData = inject(CHARTING_DATA);
  private readonly reactiveState = injectUiState('LibraryComponent');

  readonly workspace = inject(WorkspaceRepository);
  private readonly dialog = inject(MatDialog);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly clipboard = inject(Clipboard);
  private readonly preferences = inject(UserPreferencesService);
  readonly widgets = computed(() =>
    this.workspace.store.cards('widgets', this.state().pub === 'published'),
  );
  readonly models = this.workspace.store.modelList;
  readonly error = this.reactiveState.signal('');
  readonly loading = this.reactiveState.signal(true);
  readonly modelFilter = this.reactiveState.signal('all');
  private readonly defaults = computed<GalleryState>(() => ({
    ...GALLERY_DEFAULTS,
    density: this.preferences.settings().galleryDensity,
  }));
  readonly state = this.reactiveState.signal<GalleryState>(
    galleryStateFromParams(this.route.snapshot.queryParams, { ...GALLERY_DEFAULTS }),
  );
  private generation = 0;

  constructor() {
    const stored = this.defaults();
    const params = this.route.snapshot.queryParams;
    this.state.set(
      galleryStateFromParams(params, {
        ...stored,
        density: (params['density'] as GalleryState['density']) ?? stored.density,
      }),
    );
    // Power BI demo reports open from a shareable link: /library?report=<id>.
    const subscription = this.route.queryParamMap.subscribe((query) => {
      const id = query.get('report');
      const report = id ? (this.hostData.reports ?? []).find((item) => item.id === id) : undefined;
      if (!report) return;
      void this.router.navigate([], {
        relativeTo: this.route,
        queryParams: { report: null },
        queryParamsHandling: 'merge',
        replaceUrl: true,
      });
      this.openReport(report);
    });
    inject(DestroyRef).onDestroy(() => subscription.unsubscribe());
    void this.load();
  }

  update(patch: Partial<GalleryState>) {
    const previous = this.state();
    const next = { ...previous, ...patch };
    if (patch.pub && patch.pub !== previous.pub) {
      next.group = '';
      next.tag = '';
      this.modelFilter.set('all');
    }
    this.state.set(next);
    writeGalleryState(this.router, this.route, next, GALLERY_DEFAULTS);
    if (patch.density)
      void this.preferences
        .updateSettings({ galleryDensity: patch.density })
        .catch(() => undefined);
    if (patch.pub && patch.pub !== previous.pub) void this.load();
  }

  async load() {
    const generation = ++this.generation;
    this.loading.set(true);
    this.error.set('');
    try {
      const cards = await this.workspace.cards('widgets', this.state().pub);
      // Cards are derived directly from the root store.
    } catch (e) {
      if (generation === this.generation)
        this.error.set(e instanceof Error ? e.message : String(e));
    } finally {
      if (generation === this.generation) this.loading.set(false);
    }
  }

  readonly groups = computed(() =>
    [
      ...new Set(
        this.widgets()
          .map((w) => w.group || '')
          .filter(Boolean),
      ),
    ].sort(),
  );
  readonly tags = computed(() => [...new Set(this.widgets().flatMap((w) => w.tags ?? []))].sort());
  readonly filtered = computed(() => {
    const state = this.state();
    const model = this.modelFilter();
    return sortCards(
      this.widgets().filter(
        (w) =>
          (state.pub !== 'draft' || w.version !== w.publishedVersion) &&
          (model === 'all' || (w.modelId ?? 'unassigned') === model) &&
          matchesCard(w, state),
      ),
      state.sort,
    );
  });
  readonly modelFilters = computed(() => {
    const state = this.state();
    const visible = this.widgets().filter(
      (w) => (state.pub !== 'draft' || w.version !== w.publishedVersion) && matchesCard(w, state),
    );
    const counts = new Map<string, { label: string; count: number }>();
    for (const card of visible) {
      const key = card.modelId ?? 'unassigned';
      const entry = counts.get(key) ?? { label: card.modelName || 'Data model', count: 0 };
      entry.count++;
      counts.set(key, entry);
    }
    return [
      { key: 'all', label: 'All models', count: visible.length },
      ...[...counts.entries()]
        .map(([key, value]) => ({ key, ...value }))
        .sort((a, b) => a.label.localeCompare(b.label)),
    ];
  });
  readonly summary = computed(() => {
    const count = this.filtered().length + this.powerBiReports().length;
    const state = this.state();
    return `${count} ${count === 1 ? 'view' : 'views'}${state.pub === 'draft' ? ' · drafts with unpublished changes' : ''}`;
  });

  powerBiReports() {
    const state = this.state();
    const query = state.q.toLowerCase();
    return state.pub === 'draft' || state.group || state.tag || this.modelFilter() !== 'all'
      ? []
      : (this.hostData.reports ?? []).filter((report) =>
          `${report.name} ${report.description} Power BI`.toLowerCase().includes(query),
        );
  }
  openReport(report: PowerBiReport) {
    this.dialog.open(PowerBiReportDialogComponent, {
      data: report,
      width: '1280px',
      maxWidth: '96vw',
    });
  }
  reportAction(report: PowerBiReport, id: string) {
    if (id === 'open') this.openReport(report);
    else window.open(report.source, '_blank', 'noopener');
  }

  presentation(widget: WorkspaceCard) {
    if (widget.chartCount === undefined)
      return widget.preview?.chartType || (widget.preview?.type === 'chart' ? 'Chart' : 'Table');
    return widget.chartCount
      ? `${widget.chartCount} ${widget.chartCount === 1 ? 'chart' : 'charts'} · table`
      : 'Table';
  }
  status(widget: WorkspaceCard) {
    return cardStatus(widget, this.state().pub);
  }
  private opensPublished(widget: WorkspaceCard) {
    return !!widget.publishedVersion && this.state().pub === 'published';
  }
  openLink(widget: WorkspaceCard) {
    return this.opensPublished(widget) ? ['/views', widget.slug] : ['/studio', widget.modelSlug];
  }
  openQuery(widget: WorkspaceCard) {
    return this.opensPublished(widget) ? null : { widget: widget.slug, view: 'draft' };
  }
  actions(widget: WorkspaceCard): CardAction[] {
    const editor = true;
    return [
      ...(widget.publishedVersion
        ? [{ id: 'openPublished', label: 'Open published', icon: 'public' }]
        : []),
      ...(editor ? [{ id: 'editDraft', label: 'Edit draft', icon: 'edit' }] : []),
      { id: 'preview', label: 'Preview as reader', icon: 'visibility' },
      ...(widget.publishedVersion && this.hostActions.addToDashboard
        ? [{ id: 'addToDashboard', label: 'Add to dashboard', icon: 'dashboard_customize' }]
        : []),
      ...(editor ? [{ id: 'duplicate', label: 'Duplicate', icon: 'content_copy' }] : []),
      ...(widget.publishedVersion ? [{ id: 'copyLink', label: 'Copy link', icon: 'link' }] : []),
      ...(editor
        ? [
            {
              id: 'delete',
              label: 'Delete',
              icon: 'delete_outline',
              destructive: true,
              divider: true,
            },
          ]
        : []),
    ];
  }
  async run(widget: WorkspaceCard, id: string) {
    try {
      switch (id) {
        case 'openPublished':
          return void this.router.navigate(['/views', widget.slug]);
        case 'editDraft':
          return void this.router.navigate(['/studio', widget.modelSlug], {
            queryParams: { widget: widget.slug, view: 'draft' },
          });
        case 'preview':
          return this.preview(widget);
        case 'addToDashboard':
          return this.addToDashboard(widget);
        case 'duplicate':
          return this.duplicate(widget);
        case 'copyLink':
          this.clipboard.copy(new URL(`/views/${widget.slug}`, location.origin).toString());
          return;
        case 'delete':
          return this.remove(widget);
      }
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : String(error));
    }
  }
  private async preview(widget: WorkspaceCard) {
    const published = this.opensPublished(widget);
    const [resource, models] = await Promise.all([
      this.workspace.get<WidgetConfiguration>('widgets', widget.slug, published),
      this.workspace.list<ModelResource['body']>('models'),
    ]);
    const model = models.find((item) => item.id === resource.modelId);
    if (!model) throw new Error('The data model for this view is not available.');
    const { ReaderPreviewDialogComponent } = await import(
      '../rendering/reader-preview-dialog.component'
    );
    this.dialog.open(ReaderPreviewDialogComponent, {
      data: { name: resource.name, model, configuration: resource.body },
      width: '96vw',
      maxWidth: '1600px',
      height: '92vh',
      panelClass: 'reader-preview-dialog',
      autoFocus: 'dialog',
    });
  }
  private async addToDashboard(widget: WorkspaceCard) {
    if (!this.hostActions.addToDashboard) return;
    const resource = await this.workspace.get<WidgetConfiguration>('widgets', widget.slug, true);
    await this.hostActions.addToDashboard(resource);
  }
  private async duplicate(widget: WorkspaceCard) {
    const draft = await this.workspace.get<WidgetConfiguration>('widgets', widget.slug);
    const copy = await this.workspace.create<WidgetConfiguration>('widgets', {
      name: `${draft.name} copy`,
      description: draft.description,
      modelId: draft.modelId,
      body: draft.body,
    });
    await this.router.navigate(['/studio', widget.modelSlug], {
      queryParams: { widget: copy.slug, view: 'draft' },
    });
  }
  private async remove(widget: WorkspaceCard) {
    const confirmed = await firstValueFrom(
      this.dialog
        .open(ConfirmDialogComponent, {
          data: {
            title: `Delete ${widget.name}?`,
            message: widget.publishedVersion
              ? 'The draft and every published revision are removed. Readers lose access immediately.'
              : 'This draft has never been published; it is removed for everyone.',
            detail: 'Deletion is blocked while a dashboard uses this view.',
            confirmLabel: 'Delete view',
            destructive: true,
          },
          width: '480px',
          maxWidth: 'calc(100vw - 24px)',
        })
        .afterClosed(),
    );
    if (!confirmed) return;
    try {
      const draft = await this.workspace.get<WidgetConfiguration>('widgets', widget.slug);
      await this.workspace.remove('widgets', draft);
      await this.load();
    } catch (e) {
      this.error.set(
        e instanceof WorkspaceError && e.code === 'IN_USE'
          ? `${widget.name} is placed on a dashboard. Remove it from the dashboard first.`
          : e instanceof Error
            ? e.message
            : String(e),
      );
    }
  }
}
