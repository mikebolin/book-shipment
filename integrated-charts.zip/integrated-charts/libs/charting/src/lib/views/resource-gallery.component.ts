import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTooltipModule } from '@angular/material/tooltip';
import type { GalleryState } from './gallery-state';

export interface GalleryQuickFilter {
  key: string;
  label: string;
  count: number;
}

/**
 * The shared gallery shell: heading and primary action, one toolbar row (search, publication
 * tabs, model, group, tag, sort and layout), the result summary, skeletons and empty states.
 * Pages project their primary action and their cards.
 */
@Component({
  selector: 'workspace-resource-gallery',
  standalone: true,
  imports: [
    FormsModule,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatSelectModule,
    MatTooltipModule,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="page-wrap gallery-page gallery-shell">
      <header class="page-heading">
        <div>
          <h1>
            {{ title }}
            <span class="heading-count" aria-hidden="true">{{ count }}</span>
          </h1>
          @if (description) {
            <p class="page-description">{{ description }}</p>
          }
        </div>
        <div class="header-actions"><ng-content select="[gallery-primary]" /></div>
      </header>
      <div class="gallery-bar" role="group" aria-label="Browse and filter">
        <mat-form-field
          class="toolbar-field bar-search"
          appearance="outline"
          subscriptSizing="dynamic"
        >
          <mat-icon matPrefix aria-hidden="true">search</mat-icon>
          <input
            matInput
            type="search"
            autocomplete="off"
            [ngModel]="state.q"
            (ngModelChange)="patch({ q: $event })"
            [placeholder]="searchPlaceholder"
            [attr.aria-label]="searchLabel"
          />
          @if (state.q) {
            <button
              mat-icon-button
              matSuffix
              type="button"
              aria-label="Clear search"
              matTooltip="Clear search"
              (click)="patch({ q: '' })"
            >
              <mat-icon>close</mat-icon>
            </button>
          }
        </mat-form-field>
        @if (publicationTabs) {
          <div class="publication-tabs" role="group" [attr.aria-label]="publicationLabel">
            <button
              type="button"
              [class.selected]="state.pub === 'published'"
              [attr.aria-pressed]="state.pub === 'published'"
              (click)="patch({ pub: 'published' })"
            >
              Published
            </button>
            <button
              type="button"
              [class.selected]="state.pub === 'draft'"
              [attr.aria-pressed]="state.pub === 'draft'"
              (click)="patch({ pub: 'draft' })"
            >
              Drafts
            </button>
          </div>
        }
        @if (quickFilters.length > 1) {
          <mat-form-field class="toolbar-field" appearance="outline" subscriptSizing="dynamic">
            <mat-label>{{ quickFilterLabel }}</mat-label>
            <mat-select
              [value]="quickFilter"
              (selectionChange)="quickFilterChange.emit($event.value)"
              [attr.aria-label]="quickFilterLabel"
            >
              <mat-select-trigger>{{ quickFilterName() }}</mat-select-trigger>
              @for (filter of quickFilters; track filter.key) {
                <mat-option [value]="filter.key">
                  {{ filter.label }} <span class="option-count">{{ filter.count }}</span>
                </mat-option>
              }
            </mat-select>
          </mat-form-field>
        }
        @if (groups.length) {
          <mat-form-field class="toolbar-field" appearance="outline" subscriptSizing="dynamic">
            <mat-label>Group</mat-label>
            <mat-select
              [value]="state.group"
              (selectionChange)="patch({ group: $event.value })"
              [attr.aria-label]="'Filter ' + noun + ' group'"
            >
              <mat-option value="">All groups</mat-option>
              @for (value of groups; track value) {
                <mat-option [value]="value">{{ value }}</mat-option>
              }
            </mat-select>
          </mat-form-field>
        }
        @if (tags.length) {
          <mat-form-field class="toolbar-field" appearance="outline" subscriptSizing="dynamic">
            <mat-label>Tag</mat-label>
            <mat-select
              [value]="state.tag"
              (selectionChange)="patch({ tag: $event.value })"
              [attr.aria-label]="'Filter ' + noun + ' tag'"
            >
              <mat-option value="">All tags</mat-option>
              @for (value of tags; track value) {
                <mat-option [value]="value">{{ value }}</mat-option>
              }
            </mat-select>
          </mat-form-field>
        }
        <mat-form-field
          class="toolbar-field sort-field"
          appearance="outline"
          subscriptSizing="dynamic"
        >
          <mat-label>Sort</mat-label>
          <mat-select
            [value]="state.sort"
            (selectionChange)="patch({ sort: $event.value })"
            aria-label="Sort"
          >
            <mat-option value="recent">Recently updated</mat-option>
            <mat-option value="name">Name A–Z</mat-option>
            @if (modelSort) {
              <mat-option value="model">Model</mat-option>
            }
          </mat-select>
        </mat-form-field>
        <div class="density-toggle" role="group" aria-label="Layout">
          <button
            type="button"
            [class.selected]="state.density === 'grid'"
            [attr.aria-pressed]="state.density === 'grid'"
            aria-label="Grid layout"
            matTooltip="Grid"
            (click)="patch({ density: 'grid' })"
          >
            <mat-icon>grid_view</mat-icon>
          </button>
          <button
            type="button"
            [class.selected]="state.density === 'list'"
            [attr.aria-pressed]="state.density === 'list'"
            aria-label="List layout"
            matTooltip="List"
            (click)="patch({ density: 'list' })"
          >
            <mat-icon>view_list</mat-icon>
          </button>
        </div>
      </div>
      <div class="gallery-summary" role="status" aria-live="polite">
        <span>{{ summary }}</span>
        @if (state.q || state.group || state.tag || quickFilter !== 'all') {
          <button mat-button type="button" (click)="clearAll()">Clear filters</button>
        }
      </div>
      @if (error) {
        <div class="workspace-alert" role="alert">{{ error }}</div>
      }
      @if (loading) {
        <div class="resource-grid skeleton-grid" aria-busy="true" aria-label="Loading">
          @for (i of skeletons; track i) {
            <div class="skeleton-card">
              <div class="skeleton-preview"></div>
              <div class="skeleton-line short"></div>
              <div class="skeleton-line"></div>
              <div class="skeleton-line medium"></div>
            </div>
          }
        </div>
      } @else {
        <ng-content />
      }
    </div>
  `,
  styles: `
    :host {
      display: block;
      min-width: 0;
    }
    .gallery-shell {
      padding: 24px;
      container-type: inline-size;
    }
    .page-heading {
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 16px;
      flex-wrap: wrap;
      margin-bottom: 18px;
    }
    .page-heading h1 {
      font-size: 24px;
      line-height: 1.3;
      letter-spacing: -0.025em;
    }
    .heading-count {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 26px;
      height: 24px;
      margin-left: 8px;
      padding-inline: 6px;
      border-radius: 7px;
      background: var(--mat-sys-surface-container-high);
      color: var(--ws-muted);
      font-size: 12px;
      font-weight: 500;
      vertical-align: middle;
      box-sizing: border-box;
    }
    .page-description {
      display: block;
      margin: 7px 0 0;
      color: var(--ws-muted);
      font-size: 13px;
    }
    .gallery-bar {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 8px;
      margin: 0 0 8px;
      padding: 12px;
      border: 1px solid color-mix(in srgb, var(--ws-border) 72%, transparent);
      border-radius: 10px;
      background: var(--mat-sys-surface-container-lowest, var(--mat-sys-surface));
    }
    .toolbar-field {
      width: 150px;
      min-width: 0;
      max-width: 100%;
      flex: 0 0 auto;
      --mat-form-field-outlined-container-shape: 8px;
      --mat-form-field-container-height: 40px;
      --mat-form-field-container-vertical-padding: 8px;
      --mat-form-field-container-text-size: 13px;
    }
    .toolbar-field.bar-search {
      width: 240px;
      flex: 0 1 240px;
    }
    .bar-search input {
      appearance: none;
      min-width: 0;
      border: 0;
      border-radius: 0;
      padding: 0;
      background: transparent;
      box-shadow: none;
      outline: none;
    }
    .bar-search input::-webkit-search-cancel-button {
      display: none;
    }
    .toolbar-field.sort-field {
      width: 184px;
    }
    .toolbar-field mat-icon[matPrefix] {
      width: 18px;
      height: 18px;
      font-size: 18px;
      padding-inline: 10px 4px;
      box-sizing: content-box;
      color: var(--ws-muted);
    }
    .toolbar-field button[matSuffix] {
      margin-right: 2px;
    }
    .option-count {
      margin-left: 6px;
      color: var(--ws-muted);
      font-size: 11px;
    }
    .publication-tabs {
      display: flex;
      align-items: center;
      height: 38px;
      box-sizing: border-box;
      padding: 3px;
      border: 1px solid var(--ws-border);
      border-radius: 9px;
      background: var(--mat-sys-surface-container-low);
    }
    .publication-tabs button,
    .density-toggle button {
      border: 0;
      background: transparent;
      color: var(--ws-muted);
      border-radius: 6px;
      cursor: pointer;
      font:
        500 12px Roboto,
        Arial,
        sans-serif;
    }
    .publication-tabs button {
      height: 100%;
      padding: 0 13px;
    }
    .publication-tabs button.selected,
    .density-toggle button.selected {
      background: var(--mat-sys-surface);
      color: var(--ws-ink);
      box-shadow: 0 1px 3px rgb(15 23 42 / 8%);
    }
    .publication-tabs button:focus-visible,
    .density-toggle button:focus-visible {
      outline: 2px solid var(--ws-accent);
      outline-offset: 2px;
    }
    .density-toggle {
      display: flex;
      height: 38px;
      box-sizing: border-box;
      margin-left: auto;
      padding: 3px;
      border: 1px solid var(--ws-border);
      border-radius: 9px;
      background: var(--mat-sys-surface-container-low);
    }
    .density-toggle button {
      display: inline-flex;
      align-items: center;
      padding: 0 8px;
    }
    .density-toggle mat-icon {
      width: 18px;
      height: 18px;
      font-size: 18px;
    }
    .gallery-summary {
      display: flex;
      align-items: center;
      justify-content: space-between;
      min-height: 32px;
      margin: 0 0 14px;
      font-size: 12px;
      color: var(--ws-muted);
    }
    .gallery-summary button {
      font-size: 12px;
      height: 30px;
    }
    .resource-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(min(100%, 280px), min(100%, 344px)));
      gap: 20px;
      align-items: stretch;
    }
    .skeleton-card {
      border: 1px solid var(--ws-border);
      border-radius: 12px;
      padding: 0 14px 14px;
      background: var(--mat-sys-surface);
    }
    .skeleton-preview {
      aspect-ratio: 320 / 152;
      margin: 0 -14px 12px;
      border-radius: 8px;
      background: var(--mat-sys-surface-container);
    }
    .skeleton-line {
      height: 10px;
      margin: 8px 0;
      border-radius: 5px;
      background: var(--mat-sys-surface-container);
      animation: shimmer 1.4s ease-in-out infinite;
    }
    .skeleton-line.short {
      width: 40%;
    }
    .skeleton-line.medium {
      width: 70%;
    }
    @keyframes shimmer {
      50% {
        opacity: 0.45;
      }
    }
    @media (prefers-reduced-motion: reduce) {
      .skeleton-line {
        animation: none;
      }
    }
    @container (max-width: 760px) {
      .toolbar-field,
      .toolbar-field.bar-search {
        flex: 1 1 140px;
        width: auto;
      }
      .density-toggle {
        margin-left: 0;
      }
      .gallery-summary {
        flex-wrap: wrap;
      }
    }
    @container (min-width: 480px) and (max-width: 720px) {
      .resource-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
      }
    }
    @container (max-width: 480px) {
      .toolbar-field.bar-search {
        flex-basis: 100%;
      }
      .publication-tabs {
        margin-right: auto;
      }
      .toolbar-field.sort-field {
        flex-grow: 1;
        width: auto;
      }
    }
    @media (max-width: 600px) {
      .gallery-shell {
        padding: 16px;
      }
      .page-heading {
        gap: 12px;
      }
      .page-heading h1 {
        font-size: 22px;
      }
      .page-description {
        max-width: 32ch;
      }
    }
  `,
})
export class ResourceGalleryComponent {
  @Input({ required: true }) title = '';
  @Input() description = '';
  @Input() count = 0;
  @Input() noun = 'view';
  @Input() searchPlaceholder = 'Search';
  @Input() searchLabel = 'Search';
  @Input() publicationTabs = false;
  @Input() publicationLabel = 'Publication';
  /** Offer "Model" as a sort key (views only). */
  @Input() modelSort = false;
  @Input() groups: string[] = [];
  @Input() tags: string[] = [];
  /** A select in the toolbar row; the first entry is the "all" choice. */
  @Input() quickFilters: GalleryQuickFilter[] = [];
  @Input() quickFilter = 'all';
  @Input() quickFilterLabel = 'Model';
  @Input() summary = '';
  @Input() loading = false;
  @Input() error = '';
  @Input({ required: true }) state!: GalleryState;
  @Output() readonly stateChange = new EventEmitter<Partial<GalleryState>>();
  @Output() readonly quickFilterChange = new EventEmitter<string>();
  readonly skeletons = [0, 1, 2, 3, 4, 5];
  patch(patch: Partial<GalleryState>) {
    this.stateChange.emit(patch);
  }
  quickFilterName() {
    return this.quickFilters.find((filter) => filter.key === this.quickFilter)?.label ?? '';
  }
  clearAll() {
    this.patch({ q: '', group: '', tag: '' });
    if (this.quickFilter !== 'all') this.quickFilterChange.emit('all');
  }
}
