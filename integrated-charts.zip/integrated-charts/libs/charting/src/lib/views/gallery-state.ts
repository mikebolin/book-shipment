import type { ActivatedRoute, Params, Router } from '@angular/router';
import type { WorkspaceCard } from '../core/domain/workspace-cards';

export type GalleryDensity = 'grid' | 'list';
export type GalleryGroupBy = 'none' | 'model' | 'group';
export type GallerySort = 'recent' | 'name' | 'model';

export interface GalleryState {
  q: string;
  pub: 'published' | 'draft';
  sort: GallerySort;
  group: string;
  tag: string;
  density: GalleryDensity;
  by: GalleryGroupBy;
}

export const GALLERY_DEFAULTS: GalleryState = {
  q: '',
  pub: 'published',
  sort: 'recent',
  group: '',
  tag: '',
  density: 'grid',
  by: 'none',
};

/** Read the shareable part of a gallery's state from the URL. */
export function galleryStateFromParams(params: Params, defaults: GalleryState): GalleryState {
  const pick = <T extends string>(key: string, allowed: readonly T[], fallback: T): T => {
    const value = params[key];
    return typeof value === 'string' && (allowed as readonly string[]).includes(value)
      ? (value as T)
      : fallback;
  };
  const text = (key: string) => (typeof params[key] === 'string' ? (params[key] as string) : '');
  return {
    q: text('q') || defaults.q,
    pub: pick('pub', ['published', 'draft'], defaults.pub),
    sort: pick('sort', ['recent', 'name', 'model'], defaults.sort),
    group: text('group') || defaults.group,
    tag: text('tag') || defaults.tag,
    density: pick('density', ['grid', 'list'], defaults.density),
    by: pick('by', ['none', 'model', 'group'], defaults.by),
  };
}

/** Only values that differ from the defaults appear in the URL, so links stay short. */
export function galleryParams(state: GalleryState, defaults: GalleryState): Params {
  const params: Params = {};
  for (const key of Object.keys(defaults) as (keyof GalleryState)[])
    params[key] = state[key] !== defaults[key] && state[key] !== '' ? state[key] : null;
  return params;
}

export function writeGalleryState(
  router: Router,
  route: ActivatedRoute,
  state: GalleryState,
  defaults: GalleryState,
) {
  void router.navigate([], {
    relativeTo: route,
    queryParams: galleryParams(state, defaults),
    queryParamsHandling: 'merge',
    replaceUrl: true,
  });
}

export function matchesCard(
  card: WorkspaceCard,
  state: Pick<GalleryState, 'q' | 'group' | 'tag'>,
): boolean {
  const query = state.q.trim().toLowerCase();
  return (
    (!state.group || (card.group || card.modelName || '') === state.group) &&
    (!state.tag || !!card.tags?.includes(state.tag)) &&
    (!query ||
      [card.name, card.description, card.modelName, card.group, ...(card.tags ?? [])]
        .join(' ')
        .toLowerCase()
        .includes(query))
  );
}

export function sortCards(cards: WorkspaceCard[], sort: GallerySort): WorkspaceCard[] {
  return [...cards].sort((a, b) =>
    sort === 'name'
      ? a.name.localeCompare(b.name)
      : sort === 'model'
        ? (a.modelName ?? '').localeCompare(b.modelName ?? '') || a.name.localeCompare(b.name)
        : Date.parse(b.updatedAt) - Date.parse(a.updatedAt),
  );
}

export interface CardGroup {
  key: string;
  label: string;
  cards: WorkspaceCard[];
  modelSlug?: string;
}

export function groupCards(cards: WorkspaceCard[], by: GalleryGroupBy): CardGroup[] {
  if (by === 'none') return [{ key: 'all', label: 'All', cards }];
  const groups = new Map<string, CardGroup>();
  for (const card of cards) {
    const key = by === 'model' ? (card.modelId ?? 'unassigned') : card.group || '';
    const label = by === 'model' ? card.modelName || 'Data model' : card.group || 'Ungrouped';
    if (!groups.has(key)) groups.set(key, { key, label, cards: [], modelSlug: card.modelSlug });
    groups.get(key)!.cards.push(card);
  }
  return [...groups.values()].sort((a, b) => a.label.localeCompare(b.label));
}

/** Status pill copy shared by every card variant. */
export function cardStatus(
  card: WorkspaceCard,
  pub: 'published' | 'draft',
): { label: string; tone: 'neutral' | 'accent' | 'tertiary' } {
  if (card.publishedVersion && card.version !== card.publishedVersion && pub === 'draft')
    return { label: `Unpublished changes · v${card.version}`, tone: 'tertiary' };
  if (card.publishedVersion)
    return { label: `Published v${card.publishedVersion}`, tone: 'accent' };
  return { label: 'Draft', tone: 'neutral' };
}
