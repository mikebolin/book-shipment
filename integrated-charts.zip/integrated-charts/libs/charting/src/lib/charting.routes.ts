import type { CanDeactivateFn, Routes } from '@angular/router';
import type { StudioComponent } from './studio/studio.component';

const leaveStudio: CanDeactivateFn<StudioComponent> = (component, route, _state, next) => {
  let destination = next?.root;
  while (destination?.firstChild) destination = destination.firstChild;
  return destination?.routeConfig === route.routeConfig || component.canLeave();
};

/** Mount at the router root. All feature components are lazy loaded. */
export const CHARTING_ROUTES: Routes = [
  {
    path: 'library',
    loadComponent: () => import('./views/library.component').then((m) => m.LibraryComponent),
  },
  {
    path: 'views/:slug',
    loadComponent: () =>
      import('./rendering/published-widget.component').then((m) => m.PublishedWidgetComponent),
  },
  {
    path: 'studio/import',
    loadComponent: () =>
      import('./studio/import-data.component').then((m) => m.ImportDataComponent),
  },
  {
    path: 'studio',
    canDeactivate: [leaveStudio],
    runGuardsAndResolvers: 'always',
    loadComponent: () => import('./studio/studio.component').then((m) => m.StudioComponent),
  },
  {
    path: 'studio/:slug',
    canDeactivate: [leaveStudio],
    runGuardsAndResolvers: 'always',
    loadComponent: () => import('./studio/studio.component').then((m) => m.StudioComponent),
  },
];
