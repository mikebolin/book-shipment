/** Public host/platform entry. Keep interactive grid/chart renderers out of startup imports. */
export {
  CHARTING_DATA,
  provideChartingData,
  type ChartingDataSource,
  type ChartingSeed,
} from './lib/core/data-access/charting-data';
export { CHARTING_ACTIONS, type ChartingActions } from './lib/core/data-access/charting-actions';
export {
  WorkspaceRepository,
  WorkspaceError,
  type DashboardDataScope,
} from './lib/core/data-access/workspace-repository.service';
export {
  UserPreferencesService,
  type UserPreferences,
  type UserSettings,
} from './lib/core/data-access/user-preferences.service';
export { WorkspaceStore } from './lib/core/state/workspace.store';
export { injectUiState } from './lib/core/state/ui-state';
export {
  WORKSPACE_DOCUMENT_VERSION,
  exportWorkspaceDocument,
  validateWorkspaceDocument,
  hydrateWorkspaceDocument,
  type WorkspaceDocument,
} from './lib/core/state/workspace-document';
export {
  CHARTING_WORKSPACE_PERSISTENCE,
  type WorkspacePersistenceAdapter,
} from './lib/core/data-access/workspace-persistence';
export { AppThemeService } from './lib/explorer/app-theme.service';
export { STUDIO_QUERY_EXECUTOR } from './lib/explorer/studio-query-executor.token';
export type {
  StudioQueryExecutor,
  StudioExecutionContext,
  StudioQueryResult,
  StudioQuery,
  StudioSummaryStatement,
  StudioSummaryRow,
  SqlStatement,
  SqlValue,
} from './lib/core/domain/studio-query';
export type { SqlDataset } from './lib/core/domain/sql-dataset';
export type { ColumnSpec } from './lib/core/domain/schema';
export type { GridModel } from './lib/core/domain/contracts';
export type { ChartPlan, ChartResponse } from './lib/core/domain/integrated-chart';
export type { WorkspaceCard } from './lib/core/domain/workspace-cards';
export type {
  DashboardConfiguration,
  ModelResource,
  ModelDefinition,
  WidgetResource,
  WidgetConfiguration,
  DashboardResource,
} from './lib/core/domain/workspace.types';
export {
  SERVER_GRID_DEFAULTS,
  SERVER_GRID_LIMITS,
  normalizeServerGridSettings,
  type ServerGridSettings,
} from './lib/core/domain/server-grid-settings';
