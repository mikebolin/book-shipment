/** Public integration surface. Consumers must not import lib/ internals. */
export { CHARTING_ROUTES } from './lib/charting.routes';
export {
  CHARTING_DATA,
  provideChartingData,
  type ChartingDataSource,
  type ChartingSeed,
} from './lib/core/data-access/charting-data';
export { CHARTING_ACTIONS, type ChartingActions } from './lib/core/data-access/charting-actions';
export { DashboardDataService } from './lib/core/data-access/dashboard-data.service';
export type {
  DashboardData,
  DashboardDataHandle,
} from './lib/core/data-access/dashboard-data.service';
export { UserPreferencesService } from './lib/core/data-access/user-preferences.service';
export {
  WorkspaceRepository,
  WorkspaceError,
} from './lib/core/data-access/workspace-repository.service';
export type { DashboardDataScope } from './lib/core/data-access/workspace-repository.service';
export { calculatedColumnSpec } from './lib/core/domain/calculated-columns';
export type { GridModel } from './lib/core/domain/contracts';
export { evaluate } from './lib/core/domain/engine';
export { fromModel, toModel } from './lib/core/domain/grid-model';
export type { ChartResponse, ChartPlan } from './lib/core/domain/integrated-chart';
export { isPowerBiDemoUrl } from './lib/core/domain/powerbi-library';
export type { PowerBiReport } from './lib/core/domain/powerbi-library';
export { operators } from './lib/core/domain/schema';
export type { ColumnSpec } from './lib/core/domain/schema';
export type { WorkspaceCard } from './lib/core/domain/workspace-cards';
export {
  SERVER_GRID_DEFAULTS,
  SERVER_GRID_LIMITS,
  normalizeServerGridSettings,
  type ServerGridSettings,
} from './lib/core/domain/server-grid-settings';
export type {
  DashboardConfiguration,
  DashboardControl,
  DashboardScopeState,
  FilterPlacement,
  PlacementInteractions,
  Placement,
  WidgetResource,
  ModelResource,
  ModelDefinition,
  ViewChart,
  ViewChartDataScope,
  ViewFilterControls,
  WidgetConfiguration,
  DashboardResource,
  ChartOverrides,
  ChartPlacement,
  DashboardElement,
  PlacementKind,
  SectionPlacement,
  TableOverrides,
  TablePlacement,
  ViewPlacement,
  RichTextDocument,
  Tone,
  RichTextMark,
  RichTextNode,
} from './lib/core/domain/workspace.types';
export { injectUiState } from './lib/core/state/index';
export { AppThemeService } from './lib/explorer/app-theme.service';
export { columnHighlightClass, isColumnHighlightColor } from './lib/explorer/column-highlights';
export { registerGridRuntime } from './lib/explorer/grid-runtime';
export { STUDIO_QUERY_EXECUTOR } from './lib/explorer/studio-query-executor.token';
export {
  compileStudioQuery,
  compileStudioPivotDiscovery,
  compileStudioSummary,
  STUDIO_SUMMARY_BUCKET_SECONDS,
} from './lib/core/domain/studio-query';
export type {
  StudioQuery,
  StudioQueryExecutor,
  StudioExecutionContext,
  StudioQueryResult,
  StudioSummaryRequest,
  StudioSummaryRow,
  StudioSummaryStatement,
  SqlStatement,
  SqlValue,
} from './lib/core/domain/studio-query';
export type { SqlDataset } from './lib/core/domain/sql-dataset';
export type {
  AnalyticsRowsRequest,
  AnalyticsRowsResponse,
} from './lib/core/domain/analytics-query';
export { IntegratedChartComponent } from './lib/explorer/integrated-chart.component';
export type { ChartPresentation } from './lib/explorer/integrated-chart.component';
export type { StreamRow } from './lib/explorer/ndjson-row-stream';
export { ChartFocusComponent } from './lib/rendering/chart-focus.component';
export { filterParameters, parameterText } from './lib/rendering/filter-parameters';
export { describeFilterScope } from './lib/rendering/filter-summary';
export { combineFilterModels } from './lib/explorer/studio-server-datasource';
export { FilterScopeChipComponent } from './lib/rendering/filter-scope-chip.component';
export { InlineViewFiltersComponent } from './lib/rendering/inline-view-filters.component';
export {
  AdvancedFilterBuilderComponent,
  type FilterDraftChange,
} from './lib/explorer/advanced-filter-builder.component';
export {
  viewCharts,
  chartDataScope,
  independentChartConfiguration,
  captureViewCharts,
} from './lib/rendering/view-charts';
export { downloadCsv, viewCsv } from './lib/rendering/view-export';
export { WidgetViewComponent } from './lib/rendering/widget-view.component';
export { ConfirmDialogComponent } from './lib/ui/confirm-dialog.component';
export { ResourceCardComponent } from './lib/ui/resource-card.component';
export type { CardAction } from './lib/ui/resource-card.component';
export { ResourceDialogComponent } from './lib/ui/resource-dialog.component';
export { ResourcePreviewComponent } from './lib/ui/resource-preview.component';
export {
  GALLERY_DEFAULTS,
  cardStatus,
  galleryStateFromParams,
  matchesCard,
  sortCards,
  writeGalleryState,
} from './lib/views/gallery-state';
export type { GalleryState } from './lib/views/gallery-state';
export { ResourceGalleryComponent } from './lib/views/resource-gallery.component';
export * from './lib/ui/unsaved-changes-dialog.component';
export type { PromptExample } from './lib/explorer/prompt-examples';
export { WorkspaceStore } from './lib/core/state/workspace.store';
export {
  WORKSPACE_DOCUMENT_VERSION,
  exportWorkspaceDocument,
  validateWorkspaceDocument,
  hydrateWorkspaceDocument,
  type WorkspaceDocument,
} from './lib/core/state/workspace-document';
export {
  CHARTING_WORKSPACE_PERSISTENCE,
  type WorkspacePersistenceAdapter,
} from './lib/core/data-access/workspace-persistence';

export { GridPopupLayer, GridPopupLayerDirective } from './lib/ui/grid-popup-layer';
export { ViewExportService, type ViewExportSection } from './lib/rendering/view-export.service';

export type { GridReviewPreviewPack } from './lib/explorer/demo-grid-preview-loader';
export type { ChartPreviewPack } from './lib/explorer/demo-chart-preview-loader';

export type { FilterPreviewSource } from './lib/rendering/filter-preview';

export { FilterValuesFormComponent } from './lib/rendering/filter-values-form.component';
