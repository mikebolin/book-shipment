/** Public metadata gallery entry. Previews are inert schematics and never instantiate data engines. */
export * from './platform-api';
export { ResourceDialogComponent } from './lib/ui/resource-dialog.component';
export { ConfirmDialogComponent } from './lib/ui/confirm-dialog.component';
export { ResourceCardComponent, type CardAction } from './lib/ui/resource-card.component';
export { ResourcePreviewComponent } from './lib/ui/resource-preview.component';
export { ResourceGalleryComponent } from './lib/views/resource-gallery.component';
export {
  GALLERY_DEFAULTS,
  cardStatus,
  galleryStateFromParams,
  matchesCard,
  sortCards,
  writeGalleryState,
  type GalleryState,
} from './lib/views/gallery-state';
