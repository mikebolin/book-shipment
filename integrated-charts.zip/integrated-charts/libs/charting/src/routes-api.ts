/** Public lazy route entry. Import this instead of the rendering barrel in loadChildren. */
export { CHARTING_ROUTES } from './lib/charting.routes';
