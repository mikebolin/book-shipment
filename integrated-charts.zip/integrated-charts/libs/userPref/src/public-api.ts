export { WorkspaceShellComponent } from './lib/shell/workspace-shell.component';
export { WORKSPACE_ROUTES } from './lib/shell/workspace.routes';
