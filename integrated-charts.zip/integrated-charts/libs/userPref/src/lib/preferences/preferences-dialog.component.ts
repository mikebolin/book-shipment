import { injectUiState } from '@prism/charting';
import { Component, computed, effect, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { AppThemeService } from '@prism/charting';
import { UserPreferencesService } from '@prism/charting';

@Component({
  standalone: true,
  imports: [
    FormsModule,
    MatDialogModule,
    MatIconModule,
    MatButtonModule,
    MatTooltipModule,
    MatCheckboxModule,
  ],
  template: `
    <header class="preference-header">
      <div>
        <mat-icon>tune</mat-icon>
        <h2 mat-dialog-title>Preferences</h2>
      </div>
      <button mat-icon-button mat-dialog-close aria-label="Close preferences" matTooltip="Close">
        <mat-icon>close</mat-icon>
      </button>
    </header>
    <mat-dialog-content>
      @if (preferences.loading()) {
        <p role="status">Loading your preferences…</p>
      }
      @if (error() || preferences.error()) {
        <div class="preference-error" role="alert">
          {{ error() || preferences.error()
          }}<button
            mat-icon-button
            (click)="reload()"
            aria-label="Reload preferences"
            matTooltip="Reload saved preferences"
          >
            <mat-icon>refresh</mat-icon>
          </button>
        </div>
      }
      <h3>Appearance</h3>
      <p class="hint">
        Your theme applies across this workspace for this session. Refreshing restores the default.
      </p>
      <div class="theme-choices" role="group" aria-label="Application theme">
        @for (choice of theme.choices; track choice.id) {
          <button
            type="button"
            class="theme-choice"
            [class.selected]="themeId() === choice.id"
            [attr.aria-pressed]="themeId() === choice.id"
            [attr.aria-label]="choice.label"
            [disabled]="busy() || preferences.loading()"
            (click)="themeId.set(choice.id)"
          >
            <span
              class="palette-preview"
              [style.background]="choice.tokens['surface-container-low']"
              ><i [style.background]="choice.tokens['primary']"></i
              ><i [style.background]="choice.tokens['secondary']"></i
              ><i [style.background]="choice.tokens['tertiary'] || choice.tokens['primary']"></i
            ></span>
            <span>{{ choice.label }}</span
            ><mat-icon>{{
              themeId() === choice.id ? 'check_circle' : choice.dark ? 'dark_mode' : 'light_mode'
            }}</mat-icon>
          </button>
        }
      </div>
      <div class="preference-settings">
        <div>
          <h3>Layout density</h3>
          <p class="hint">Adjust spacing without changing touch targets.</p>
        </div>
        <div class="density-options" role="group" aria-label="Layout density">
          <button
            type="button"
            [attr.aria-pressed]="density() === 'compact'"
            (click)="density.set('compact')"
          >
            Compact</button
          ><button
            type="button"
            [attr.aria-pressed]="density() === 'comfortable'"
            (click)="density.set('comfortable')"
          >
            Comfortable
          </button>
        </div>
      </div>
      <mat-checkbox
        [ngModel]="reducedMotion()"
        (ngModelChange)="reducedMotion.set($event)"
        [disabled]="busy()"
        >Reduce motion</mat-checkbox
      >
      <p class="hint motion-hint">
        Keep panels and dialogs immediate. Your system preference is also respected.
      </p>
    </mat-dialog-content>
    <mat-dialog-actions
      ><span class="save-caption">Saved for this workspace session</span
      ><button mat-icon-button mat-dialog-close aria-label="Cancel preferences" matTooltip="Cancel">
        <mat-icon>close</mat-icon></button
      ><button
        mat-icon-button
        (click)="save()"
        aria-label="Save preferences"
        matTooltip="Save preferences"
        [disabled]="!dirty() || busy() || preferences.loading()"
      >
        <mat-icon>{{ busy() ? 'hourglass_empty' : 'check' }}</mat-icon>
      </button></mat-dialog-actions
    >
  `,
  styles: [
    `
      :host {
        display: block;
        color: var(--mat-sys-on-surface);
      }
      .preference-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 12px 16px;
        border-bottom: 1px solid var(--mat-sys-outline-variant);
      }
      .preference-header > div {
        display: flex;
        align-items: center;
        gap: 10px;
      }
      .preference-header h2 {
        padding: 0;
        font-size: 18px;
        margin: 0;
        line-height: 32px;
      }
      .preference-header h2:before {
        display: none;
      }
      .preference-header mat-icon {
        color: var(--mat-sys-primary);
      }
      mat-dialog-content {
        padding: 16px !important;
      }
      h3 {
        font-size: 13px;
        font-weight: 600;
        margin: 0 0 5px;
      }
      .hint {
        font-size: 12px;
        line-height: 1.5;
        color: var(--mat-sys-on-surface-variant);
        margin: 0 0 14px;
      }
      .theme-choices {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 8px;
      }
      .theme-choice {
        display: grid;
        grid-template-columns: 42px minmax(0, 1fr) 18px;
        align-items: center;
        gap: 8px;
        border: 1px solid var(--mat-sys-outline-variant);
        padding: 9px;
        border-radius: 8px;
        background: var(--mat-sys-surface-container-lowest);
        color: var(--mat-sys-on-surface);
        text-align: left;
        font:
          12px Roboto,
          Arial,
          sans-serif;
        cursor: pointer;
      }
      .theme-choice.selected {
        border-color: var(--mat-sys-primary);
        background: var(--mat-sys-primary-container);
        color: var(--mat-sys-on-primary-container);
      }
      .theme-choice > mat-icon {
        font-size: 18px;
        width: 18px;
        height: 18px;
      }
      .palette-preview {
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 3px;
        border-radius: 5px;
      }
      .palette-preview i {
        width: 8px;
        height: 15px;
        border-radius: 2px;
      }
      .palette-preview i:nth-child(2) {
        height: 22px;
      }
      .preference-settings {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        border-top: 1px solid var(--mat-sys-outline-variant);
        margin-top: 18px;
        padding-top: 16px;
      }
      .preference-settings .hint {
        margin-bottom: 0;
      }
      .density-options {
        display: flex;
        border: 1px solid var(--mat-sys-outline-variant);
        border-radius: 6px;
        overflow: hidden;
      }
      .density-options button {
        font:
          11px Roboto,
          Arial,
          sans-serif;
        border: 0;
        padding: 9px;
        background: transparent;
        color: var(--mat-sys-on-surface);
        cursor: pointer;
      }
      .density-options button[aria-pressed='true'] {
        background: var(--mat-sys-secondary-container);
        color: var(--mat-sys-on-secondary-container);
      }
      mat-checkbox {
        margin: 12px 0 0;
      }
      .motion-hint {
        margin: 0 0 0 36px;
        font-size: 11px;
      }
      .preference-error {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        background: var(--mat-sys-error-container);
        color: var(--mat-sys-on-error-container);
        padding: 8px;
        border-radius: 6px;
        font-size: 12px;
        margin-bottom: 12px;
      }
      mat-dialog-actions {
        border-top: 1px solid var(--mat-sys-outline-variant);
        padding: 8px 12px !important;
      }
      .save-caption {
        margin-right: auto;
        font-size: 11px;
        color: var(--mat-sys-on-surface-variant);
      }
      @media (max-width: 500px) {
        .preference-settings {
          display: block;
        }
        .density-options {
          margin-top: 10px;
          width: max-content;
        }
        .theme-choice {
          font-size: 11px;
          grid-template-columns: 32px minmax(0, 1fr) 16px;
          padding: 7px;
          gap: 5px;
        }
      }
    `,
  ],
})
export class PreferencesDialogComponent {
  private readonly reactiveState = injectUiState('PreferencesDialogComponent');

  readonly theme = inject(AppThemeService);
  readonly preferences = inject(UserPreferencesService);
  private readonly dialog = inject(MatDialogRef<PreferencesDialogComponent>);
  readonly themeId = this.reactiveState.signal('azure-blue');
  readonly density = this.reactiveState.signal<'compact' | 'comfortable'>('compact');
  readonly reducedMotion = this.reactiveState.signal(false);
  readonly busy = this.reactiveState.signal(false);
  readonly error = this.reactiveState.signal('');
  readonly dirty = computed(() => {
    const saved = this.preferences.current();
    return (
      saved.themeId !== this.themeId() ||
      saved.density !== this.density() ||
      saved.reducedMotion !== this.reducedMotion()
    );
  });
  constructor() {
    effect(() => {
      const saved = this.preferences.current();
      this.themeId.set(saved.themeId);
      this.density.set(saved.density);
      this.reducedMotion.set(saved.reducedMotion);
    });
  }
  async reload() {
    this.error.set('');
    await this.preferences.reload();
  }
  async save() {
    this.busy.set(true);
    this.error.set('');
    try {
      await this.preferences.save({
        themeId: this.themeId(),
        density: this.density(),
        reducedMotion: this.reducedMotion(),
      });
      this.dialog.close(true);
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : String(error));
    } finally {
      this.busy.set(false);
    }
  }
}
