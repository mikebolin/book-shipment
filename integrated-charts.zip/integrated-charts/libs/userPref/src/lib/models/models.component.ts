import { injectUiState } from '@prism/charting';
import { Component, computed, inject } from '@angular/core';
import { DatePipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDialog } from '@angular/material/dialog';
import { firstValueFrom } from 'rxjs';
import { WorkspaceRepository, WorkspaceError } from '@prism/charting';
import { ResourceDialogComponent } from '@prism/charting';
import { ConfirmDialogComponent } from '@prism/charting';
import type { WorkspaceCard } from '@prism/charting';
import type { ModelResource } from '@prism/charting';

/** Data models as rows: what they hold, how many views use them, and where to start. */
@Component({
  standalone: true,
  imports: [
    DatePipe,
    FormsModule,
    RouterLink,
    MatButtonModule,
    MatDividerModule,
    MatIconModule,
    MatMenuModule,
    MatTooltipModule,
  ],
  template: `<div class="page-wrap gallery-page models-page">
    <header class="page-heading">
      <div>
        <h1>
          Data models <span class="heading-count" aria-hidden="true">{{ models().length }}</span>
        </h1>
        <p class="page-description">
          Choose a shared data model to explore, or import a file to explore in your browser.
        </p>
      </div>
      <div class="header-actions">
        <button mat-button type="button" aria-label="Create model" (click)="edit()">
          <mat-icon>add</mat-icon>Create model
        </button>

        <a mat-button routerLink="/studio/import" aria-label="Import CSV or JSON"
          ><mat-icon>upload_file</mat-icon>Import data</a
        >
      </div>
    </header>
    <div class="gallery-toolbar">
      <label class="search-field"
        ><mat-icon>search</mat-icon
        ><input
          type="search"
          [(ngModel)]="search"
          placeholder="Search data models"
          aria-label="Search data models" /></label
      ><span class="result-count"
        >{{ filtered().length }} {{ filtered().length === 1 ? 'model' : 'models' }}</span
      >
    </div>
    @if (error()) {
      <div class="workspace-alert" role="alert">{{ error() }}</div>
    }
    @if (loading()) {
      <div class="model-rows" aria-busy="true" aria-label="Loading">
        @for (i of [0, 1, 2]; track i) {
          <div class="model-row skeleton">
            <span class="line"></span><span class="line short"></span>
          </div>
        }
      </div>
    } @else {
      <div class="model-rows" role="list">
        @for (model of filtered(); track model.id) {
          <article class="model-row" role="listitem" [attr.aria-label]="model.name">
            <a
              class="row-open"
              [routerLink]="['/studio', model.slug]"
              [attr.aria-label]="'Explore ' + model.name"
            ></a>
            <div class="row-icon"><mat-icon aria-hidden="true">storage</mat-icon></div>
            <div class="row-main">
              <h2>{{ model.name }}</h2>
              <p>{{ model.description || 'No description yet.' }}</p>
              <p class="row-source">
                <span [matTooltip]="'Source key'">{{ model.body.sourceKey }}</span>
                <span>schema {{ model.body.schemaVersion }}</span>
              </p>
            </div>
            <dl class="row-metrics">
              <div>
                <dt>Records</dt>
                <dd>{{ model.body.rowCount.toLocaleString() }}</dd>
              </div>
              <div>
                <dt>Fields</dt>
                <dd>{{ model.body.columns.length }}</dd>
              </div>
              <div>
                <dt>Views</dt>
                <dd>{{ viewCount(model) }}</dd>
              </div>
              <div>
                <dt>Refreshed</dt>
                <dd [matTooltip]="model.updatedAt | date: 'medium'">
                  {{ model.updatedAt | date: 'mediumDate' }}
                </dd>
              </div>
            </dl>
            <div class="row-actions">
              <a
                mat-button
                [routerLink]="['/studio', model.slug]"
                aria-label="Explore model"
              >
                <mat-icon>table_chart</mat-icon>Explore
              </a>

              <a
                mat-button
                [routerLink]="['/studio', model.slug]"
                [queryParams]="{ view: 'new' }"
                aria-label="Create view"
              >
                <mat-icon>add_chart</mat-icon>Create view
              </a>
              <button
                mat-icon-button
                type="button"
                [matMenuTriggerFor]="menu"
                [attr.aria-label]="'More actions for ' + model.name"
                matTooltip="More"
              >
                <mat-icon>more_vert</mat-icon>
              </button>
              <mat-menu #menu="matMenu">
                <button mat-menu-item (click)="refresh(model)">
                  <mat-icon>sync</mat-icon><span>Refresh source</span>
                </button>
                <button mat-menu-item (click)="edit(model)">
                  <mat-icon>edit</mat-icon><span>Edit details</span>
                </button>
                <mat-divider />
                <button
                  mat-menu-item
                  class="destructive"
                  [disabled]="viewCount(model) > 0"
                  [matTooltip]="viewCount(model) > 0 ? 'Delete its views first' : ''"
                  (click)="remove(model)"
                >
                  <mat-icon>delete_outline</mat-icon><span>Delete model</span>
                </button>
              </mat-menu>
            </div>
          </article>
        }
      </div>
    }
    @if (!loading() && !filtered().length) {
      <div class="empty-state">
        <div class="empty-icon"><mat-icon>search_off</mat-icon></div>
        <h2>{{ models().length ? 'No matching models' : 'No data models yet' }}</h2>
        <p>
          {{
            models().length
              ? 'Try another name or description.'
              : 'Import a CSV or JSON file to get started.'
          }}
        </p>
      </div>
    }
  </div>`,
  styles: `
    .page-heading {
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 16px;
      flex-wrap: wrap;
    }
    .page-description {
      margin: 4px 0 0;
      color: var(--ws-muted);
      font-size: 13px;
    }
    .header-actions {
      display: flex;
      gap: 8px;
      align-items: center;
    }
    .header-actions mat-icon {
      margin-right: 4px;
    }
    .gallery-toolbar {
      display: flex;
      align-items: center;
      gap: 10px;
      margin: 12px 0 10px;
      padding: 8px;
      border: 1px solid var(--ws-border);
      border-radius: 10px;
      background: var(--mat-sys-surface);
    }
    .gallery-toolbar .search-field {
      flex: 1;
      max-width: 420px;
      height: 36px;
    }
    .model-rows {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
    .model-row {
      position: relative;
      display: grid;
      grid-template-columns: 44px minmax(0, 1.4fr) minmax(0, 1fr) auto;
      align-items: center;
      gap: 14px;
      padding: 12px 14px;
      border: 1px solid var(--ws-border);
      border-radius: 12px;
      background: var(--mat-sys-surface);
      transition:
        border-color 160ms,
        box-shadow 160ms;
    }
    .model-row:hover,
    .model-row:focus-within {
      border-color: color-mix(in srgb, var(--mat-sys-primary) 55%, var(--ws-border));
      box-shadow: 0 8px 22px #00000014;
    }
    .row-open {
      position: absolute;
      inset: 0;
      border-radius: inherit;
      z-index: 1;
    }
    .row-open:focus-visible {
      outline: 2px solid var(--ws-accent);
      outline-offset: 2px;
    }
    .row-icon {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 44px;
      height: 44px;
      border-radius: 10px;
      background: var(--mat-sys-primary-container);
      color: var(--mat-sys-on-primary-container);
    }
    .row-main {
      min-width: 0;
    }
    .row-main h2 {
      margin: 0 0 2px;
      font-size: 15px;
      font-weight: 600;
      line-height: 1.35;
    }
    .row-main p {
      margin: 0;
      font-size: 12px;
      line-height: 1.5;
      color: var(--ws-muted);
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }
    .row-source {
      display: flex;
      gap: 10px;
      margin-top: 4px !important;
      font-size: 11px;
      font-family: ui-monospace, 'Cascadia Mono', Consolas, monospace;
    }
    .row-metrics {
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 8px;
      margin: 0;
    }
    .row-metrics dt {
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      color: var(--ws-muted);
    }
    .row-metrics dd {
      margin: 2px 0 0;
      font-size: 13px;
      font-weight: 500;
      font-variant-numeric: tabular-nums;
      color: var(--ws-ink);
    }
    .row-actions {
      position: relative;
      z-index: 2;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .row-actions mat-icon {
      margin-right: 4px;
    }
    .row-actions [mat-icon-button] mat-icon {
      margin: 0;
    }
    .destructive {
      color: var(--mat-sys-error);
    }
    .model-row.skeleton {
      display: flex;
      flex-direction: column;
      gap: 10px;
      min-height: 76px;
    }
    .skeleton .line {
      height: 10px;
      width: 60%;
      border-radius: 5px;
      background: var(--mat-sys-surface-container);
    }
    .skeleton .line.short {
      width: 30%;
    }
    @media (max-width: 1000px) {
      .model-row {
        grid-template-columns: 44px minmax(0, 1fr);
      }
      .row-metrics {
        grid-column: 2;
      }
      .row-actions {
        grid-column: 2;
        flex-wrap: wrap;
      }
    }
  `,
})
export class ModelsComponent {
  private readonly reactiveState = injectUiState('ModelsComponent');

  readonly workspace = inject(WorkspaceRepository);
  private readonly dialog = inject(MatDialog);
  readonly models = this.workspace.store.modelList;
  readonly views = computed(() => this.workspace.store.cards('widgets', false));
  readonly error = this.reactiveState.signal('');
  readonly loading = this.reactiveState.signal(true);
  private readonly searchState = this.reactiveState.signal('');
  get search() {
    return this.searchState();
  }
  set search(value) {
    this.searchState.set(value);
  }
  readonly viewCounts = computed(() => {
    const counts = new Map<string, number>();
    for (const card of this.views())
      if (card.modelId) counts.set(card.modelId, (counts.get(card.modelId) ?? 0) + 1);
    return counts;
  });
  filtered() {
    const q = this.search.trim().toLowerCase();
    return this.models().filter(
      (model) =>
        !q ||
        [model.name, model.description, model.body.sourceKey].join(' ').toLowerCase().includes(q),
    );
  }
  viewCount(model: ModelResource) {
    return this.viewCounts().get(model.id) ?? 0;
  }
  constructor() {
    void this.load();
  }
  async load() {
    this.loading.set(true);
    try {
      const [models, views] = await Promise.all([
        this.workspace.list<ModelResource['body']>('models'),
        true
          ? this.workspace.cards('widgets', 'draft').catch(() => [])
          : Promise.resolve([] as WorkspaceCard[]),
      ]);
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : String(e));
    } finally {
      this.loading.set(false);
    }
  }
  async edit(model?: ModelResource) {
    try {
      const sources = model ? undefined : await this.workspace.sources();
      const result = await firstValueFrom(
        this.dialog
          .open(ResourceDialogComponent, {
            data: {
              title: model ? 'Edit model' : 'Create a data model',
              name: model?.name,
              description: model?.description,
              sources,
            },
          })
          .afterClosed(),
      );
      if (!result) return;
      if (model) await this.workspace.update('models', model, result);
      else await this.workspace.create('models', result);
      await this.load();
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : String(e));
    }
  }
  async refresh(model: ModelResource) {
    try {
      await this.workspace.refreshModel(model);
      await this.load();
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : String(e));
    }
  }
  async remove(model: ModelResource) {
    const confirmed = await firstValueFrom(
      this.dialog
        .open(ConfirmDialogComponent, {
          data: {
            title: `Delete ${model.name}?`,
            message:
              'The model definition is removed from the workspace. Source files are not deleted.',
            detail: 'A model can only be deleted once all of its views are removed.',
            confirmLabel: 'Delete model',
            destructive: true,
          },
          width: '480px',
          maxWidth: 'calc(100vw - 24px)',
        })
        .afterClosed(),
    );
    if (!confirmed) return;
    try {
      await this.workspace.remove('models', model);
      await this.load();
    } catch (e) {
      this.error.set(
        e instanceof WorkspaceError && e.code === 'IN_USE'
          ? `${model.name} still has views. Delete them first.`
          : e instanceof Error
            ? e.message
            : String(e),
      );
    }
  }
}
