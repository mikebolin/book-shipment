import { Component, inject } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatMenuModule } from '@angular/material/menu';
import { MatDialog } from '@angular/material/dialog';
import { AppThemeService, UserPreferencesService } from '@prism/charting/platform';

@Component({
  selector: 'prism-workspace',
  standalone: true,
  imports: [
    RouterLink,
    RouterLinkActive,
    RouterOutlet,
    MatButtonModule,
    MatIconModule,
    MatTooltipModule,
    MatMenuModule,
  ],
  template: `<div class="workspace-shell">
    <a class="skip-link" href="#workspace-main">Skip to content</a>
    <aside class="workspace-nav" aria-label="Primary navigation">
      <a class="brand-mark" routerLink="/library" aria-label="Prism home" matTooltip="Prism home"
        ><mat-icon>hub</mat-icon></a
      >
      <nav aria-label="Workspace sections">
        <a
          routerLink="/library"
          routerLinkActive="nav-active"
          aria-label="Published views"
          ariaCurrentWhenActive="page"
          matTooltip="View library"
          matTooltipPosition="right"
          ><mat-icon>view_module</mat-icon><span class="nav-label">Views</span></a
        >
        <a
          routerLink="/dashboards"
          routerLinkActive="nav-active"
          aria-label="Dashboards"
          ariaCurrentWhenActive="page"
          matTooltip="Dashboards"
          matTooltipPosition="right"
          ><mat-icon>space_dashboard</mat-icon><span class="nav-label">Dashboards</span></a
        >
        <a
          routerLink="/studio"
          routerLinkActive="nav-active"
          aria-label="Data studio"
          ariaCurrentWhenActive="page"
          matTooltip="Data studio"
          matTooltipPosition="right"
          ><mat-icon>add_chart</mat-icon><span class="nav-label">Studio</span></a
        >
      </nav>
      <div class="nav-bottom">
        <span class="environment-marker" matTooltip="In-memory workspace">LOCAL</span>
        <button
          mat-icon-button
          [matMenuTriggerFor]="themeMenu"
          aria-label="Theme"
          matTooltip="Theme for this session"
        >
          <mat-icon>palette</mat-icon>
        </button>
        <mat-menu #themeMenu="matMenu">
          <p style="margin:8px 16px;font-size:12px">Theme · this session</p>
          @for (choice of theme.choices; track choice.id) {
            <button
              mat-menu-item
              (click)="chooseTheme(choice.id)"
              [attr.aria-pressed]="theme.selectedTheme() === choice.id"
            >
              <mat-icon>{{
                theme.selectedTheme() === choice.id
                  ? 'check'
                  : choice.dark
                    ? 'dark_mode'
                    : 'light_mode'
              }}</mat-icon
              >{{ choice.label }}
            </button>
          }
        </mat-menu>
        <button
          mat-icon-button
          aria-label="Preferences"
          matTooltip="Preferences"
          (click)="openPreferences()"
        >
          <mat-icon>tune</mat-icon>
        </button>
      </div>
    </aside>
    <div class="workspace-body">
      @if (theme.error()) {
        <div class="workspace-alert" role="alert">{{ theme.error() }}</div>
      }
      <main id="workspace-main" class="workspace-main" tabindex="-1"><router-outlet /></main>
    </div>
  </div>`,
})
export class WorkspaceShellComponent {
  readonly theme = inject(AppThemeService);
  readonly preferences = inject(UserPreferencesService);
  private readonly dialogs = inject(MatDialog);
  async chooseTheme(themeId: string) {
    const { version, ...current } = this.preferences.current();
    await this.preferences.save({ ...current, themeId });
  }
  async openPreferences() {
    const { PreferencesDialogComponent } = await import(
      '../preferences/preferences-dialog.component'
    );
    this.dialogs.open(PreferencesDialogComponent, {
      width: '600px',
      maxWidth: 'calc(100vw - 24px)',
      autoFocus: 'first-heading',
    });
  }
}
