import type { Routes } from '@angular/router';
export const WORKSPACE_ROUTES: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'library' },
  {
    path: 'dashboards',
    loadChildren: () => import('@prism/dashboards').then((m) => m.DASHBOARD_ROUTES),
  },
  {
    path: 'models',
    loadComponent: () => import('../models/models.component').then((m) => m.ModelsComponent),
  },
  { path: '', loadChildren: () => import('@prism/charting/routes').then((m) => m.CHARTING_ROUTES) },
  { path: '**', redirectTo: 'library' },
];
