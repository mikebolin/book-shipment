import assert from 'node:assert/strict';
import { mkdir, writeFile } from 'node:fs/promises';
import { chromium } from '@playwright/test';
import { spawn } from 'node:child_process';

// Run against the production static server. Timings are observations, not portable budgets.
const base = process.env.PLAYWRIGHT_BASE_URL ?? 'http://127.0.0.1:4200';
let server;
try {
  await fetch(base, { signal: AbortSignal.timeout(1000) });
} catch {
  const endpoint = new URL(base);
  assert.equal(endpoint.hostname, '127.0.0.1', 'Start a remote audit server separately');
  server = spawn(process.execPath, ['scripts/serve.mjs'], {
    env: { ...process.env, PORT: endpoint.port || '80' },
    stdio: 'ignore',
    windowsHide: true,
  });
  let listening = false;
  for (let attempt = 0; attempt < 50; attempt++) {
    try {
      await fetch(base, { signal: AbortSignal.timeout(1000) });
      listening = true;
      break;
    } catch {
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
  }
  if (!listening) {
    server.kill();
    throw new Error('Could not start the production performance audit server.');
  }
}
const browser = await chromium.launch({ args: ['--no-sandbox'] });
const results = [];
try {
  for (const route of ['/library', '/dashboards', '/studio/activity-monitor']) {
    const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
    const page = await context.newPage();
    const errors = [];
    const snapshots = [];
    page.on('pageerror', (error) => errors.push(error.message));
    page.on('request', (request) => {
      if (/\/assets\/bundled\//.test(request.url())) snapshots.push(request.url());
    });
    const started = performance.now();
    await page.goto(base + route);
    if (route.startsWith('/studio')) {
      await page
        .getByTestId('server-cache-rows')
        .filter({ hasText: '250 loaded' })
        .waitFor({ timeout: 60000 });
      await page.locator('.grid-shell .ag-row[row-id]').first().waitFor();
    } else {
      await page.locator('workspace-resource-card').first().waitFor();
    }
    const readyMs = Math.round(performance.now() - started);
    const metrics = await page.evaluate(() => ({
      domElements: document.querySelectorAll('*').length,
      cards: document.querySelectorAll('workspace-resource-card').length,
      previewElements: document.querySelectorAll('workspace-resource-card svg *').length,
      heavyweightPreviews: document.querySelectorAll(
        'workspace-resource-card canvas, workspace-resource-card img, workspace-resource-card ag-grid-angular',
      ).length,
      renderedGridRows: document.querySelectorAll('.grid-shell .ag-row[row-id]').length,
      cacheLabel:
        document.querySelector('[data-testid="server-cache-rows"]')?.textContent?.trim() ?? null,
      zoneLoaded: typeof window.Zone !== 'undefined',
      scriptTransferBytes: performance
        .getEntriesByType('resource')
        .filter((entry) => entry.name.includes('.js'))
        .reduce((sum, entry) => sum + entry.transferSize, 0),
    }));
    assert.deepEqual(errors, [], `${route}: runtime errors`);
    assert.equal(metrics.zoneLoaded, false, 'Zone.js must stay out of the zoneless host');
    assert.equal(metrics.heavyweightPreviews, 0, 'Gallery cards must remain inert SVG previews');
    if (!route.startsWith('/studio'))
      assert.equal(snapshots.length, 0, 'Browsing metadata must not load rows');
    else {
      assert.equal(metrics.cacheLabel, '250 loaded');
      assert.ok(
        metrics.renderedGridRows > 0 && metrics.renderedGridRows < 200,
        'AG Grid must virtualize loaded rows',
      );
    }
    results.push({ route, readyMs, snapshotAssetRequests: snapshots.length, ...metrics });
    await context.close();
  }
  await mkdir('evidence', { recursive: true });
  const report = {
    checkedAt: new Date().toISOString(),
    environment: 'Local Chromium, production build, 1440 × 1000, cold browser context per route',
    limitations:
      'Local observations; includes the bundled 60,000-row mock snapshot in Studio. Metadata-only host execution is checked separately by verify-server-grid.mjs. No live Snowflake latency or production load test.',
    routes: results,
  };
  await writeFile('evidence/performance-audit.json', JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify(report, null, 2));
} finally {
  await browser.close();
  server?.kill();
}
