import { mkdirSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { createWorkspaceSeed } from '../src/data/workspace-seed.js';

// A portable ChartingSeed: model mappings, draft resources and immutable pinned publications.
// Synthetic records stay in the replaceable fixture; configuration never embeds source rows.
const destination = new URL('../handoff/activity-monitor.configuration.json', import.meta.url);
mkdirSync(new URL('../handoff/', import.meta.url), { recursive: true });
writeFileSync(destination, JSON.stringify(createWorkspaceSeed(), null, 2) + '\n');
console.log(`Activity monitor configuration: ${fileURLToPath(destination)}`);
