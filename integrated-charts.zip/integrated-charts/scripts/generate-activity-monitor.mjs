/**
 * Generates the synthetic Activity Monitor fixture used by the Studio server grid and the
 * triage dashboards.
 *
 *   node scripts/generate-activity-monitor.mjs [rowCount]
 *
 * Output (all text, StackBlitz-safe):
 *   - src/data/assets/bundled/<hash>-NNN.txt   gzip + base64 chunks of a compact NDJSON snapshot
 *   - src/data/bundled-assets.json              manifest entry "mock-data/activity-monitor.ndjson"
 *   - src/data/source-catalog.json              model metadata, schema, SQL mapping and snapshot clock
 *
 * The generator is deterministic: the same row count always produces the same bytes.
 * Records imitate an operations activity monitor (ingestion feeds, inbound/outbound jobs,
 * SLA checks, data-quality controls, workflows, model and lookup refreshes). Most records
 * spread over 90 days; a dense final hour before the fixed 12:00 UTC snapshot carries two
 * incidents (an ingestion failure burst at 11:35 and an inbound breach wave at 11:50) so
 * the triage dashboards have something to find. Everything is invented.
 */
import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { gzipSync } from 'node:zlib';

const root = fileURLToPath(new URL('../', import.meta.url));
const ROW_COUNT = Number(process.argv[2] ?? 60000);
if (!Number.isInteger(ROW_COUNT) || ROW_COUNT < 1000 || ROW_COUNT > 250000)
  throw new Error('Row count must be an integer between 1,000 and 250,000.');
const KEY = 'activity-monitor';
const SCHEMA_VERSION = 'activity-monitor-v1';
const MANIFEST_KEY = `mock-data/${KEY}.ndjson`;
const CHUNK_CHARS = 524288; // multiple of 4: every base64 part ends on a quartet boundary
const BATCH_ROWS = 500;
/** The fixed snapshot clock: the latest activity starts just before 12:00 UTC. */
const END = Date.UTC(2026, 9, 3, 12, 0, 0);
const DAYS = 90;
/** Records in the final hour before the snapshot; the rest spread across the 90 days. */
const DENSE_ROWS = Math.min(ROW_COUNT, Math.round(ROW_COUNT * 0.2));

// ---------------------------------------------------------------------------------------------
// Schema. Column IDs must satisfy validateSchema(): unique IDs, SQL names, labels and aliases;
// "tenant" is reserved for the authorization partition and stays outside the public schema.
// ---------------------------------------------------------------------------------------------
const column = (id, label, kind, sql, description, extra = {}) => ({
  id,
  label,
  kind,
  aliases: [label.toLowerCase()],
  nullable: false,
  sql,
  description,
  chartRole: kind === 'number' ? 'measure' : kind === 'text' ? 'dimension' : 'temporal',
  ...extra,
});
const SOURCES = [
  'AUTOMATION',
  'CAMUNDA',
  'CONNECTIONS',
  'DBT TRANSFORMATIONS',
  'EAGLE',
  'INBOUND JOB',
  'INGESTION',
  'LOOKUPS',
  'MODEL UPDATES',
  'SLA',
  'WORKFLOW',
];
const TYPES = [
  'Ingestion',
  'Inbound Job',
  'Outbound Job',
  'SLA',
  'Data Quality',
  'Workflow',
  'Model Update',
  'Lookup Refresh',
  'Transformation',
  'Connection Check',
  'Automation',
];
const EXECUTION_STATUSES = [
  'Awaiting User Action',
  'Breached',
  'Canceled',
  'Completed',
  'Completed with exceptions',
  'Completed with no exceptions',
  'Failed',
  'In Progress',
  'No Data',
  'Waived',
];
const DATA_STATUSES = ['Completed', 'Partial', 'No Data', 'Pending', 'Failed'];
const TENANTS = ['e2eflex', 'e2eprod', 'northstar', 'harborcap', 'cedarfunds', 'summitam'];
const REGIONS = ['Americas', 'EMEA', 'APAC'];
const TEAMS = [
  'Data Operations',
  'Client Service',
  'Platform Engineering',
  'Risk & Controls',
  'Reconciliations',
  'Reporting',
];
const PRIORITIES = ['P1', 'P2', 'P3', 'P4'];
const ARCHIVE_STATES = ['Yes', 'No'];

const columns = [
  column(
    'id',
    'Activity ID',
    'text',
    'ACTIVITY_ID',
    'Unique activity identifier, prefixed by its activity type. Count activities; never sum identifiers.',
    { chartRole: 'identifier', groupByTag: 'Activity' },
  ),
  column('name', 'Activity name', 'text', 'NAME', 'Configured job, feed, check or workflow name.', {
    aliases: ['activity name', 'job name'],
    groupByTag: 'Activity',
  }),
  column(
    'type',
    'Activity type',
    'text',
    'TYPE',
    'Kind of monitored activity. A useful first grouping dimension.',
    { aliases: ['activity type'], values: TYPES, groupByTag: 'Activity' },
  ),
  column(
    'source',
    'Source system',
    'text',
    'SOURCE',
    'Platform or engine that produced the activity record.',
    { values: SOURCES, groupByTag: 'Activity' },
  ),
  column(
    'executionStatus',
    'Execution status',
    'text',
    'EXECUTION_STATUS',
    'Outcome of the activity run. Breached means an SLA deadline passed before completion.',
    {
      aliases: ['execution status', 'status', 'run status'],
      values: EXECUTION_STATUSES,
      groupByTag: 'Status',
    },
  ),
  column(
    'dataStatus',
    'Data status',
    'text',
    'DATA_STATUS',
    'State of the data produced or expected by the activity, independent of its execution outcome.',
    { aliases: ['data status'], values: DATA_STATUSES, groupByTag: 'Status' },
  ),
  column(
    'priority',
    'Priority',
    'text',
    'PRIORITY',
    'Operational priority from P1 (most urgent) to P4.',
    { values: PRIORITIES, groupByTag: 'Status' },
  ),
  column(
    'tenantCode',
    'Client tenant',
    'text',
    'CLIENT_TENANT',
    'Fictional client tenant that owns the activity.',
    { aliases: ['client tenant', 'tenant code'], values: TENANTS, groupByTag: 'Ownership' },
  ),
  column('region', 'Region', 'text', 'REGION', 'Operating region responsible for the activity.', {
    values: REGIONS,
    groupByTag: 'Ownership',
  }),
  column(
    'owner',
    'Owner team',
    'text',
    'OWNER_TEAM',
    'Fictional team accountable for resolving exceptions.',
    { aliases: ['owner team', 'team'], values: TEAMS, groupByTag: 'Ownership' },
  ),
  column(
    'businessDate',
    'Business date',
    'date',
    'BUSINESS_DATE',
    'Calendar date (UTC) on which the activity started. Group by this date for daily volumes.',
    { aliases: ['business date', 'activity date'], groupByTag: 'Timing' },
  ),
  column(
    'startedDateTime',
    'Started at (UTC)',
    'datetime',
    'STARTED_DATE_TIME',
    'UTC timestamp at which the activity started. The triage dashboards bucket this field.',
    { aliases: ['started at', 'start time', 'started'], groupByTag: 'Timing' },
  ),
  column(
    'updatedDateTime',
    'Updated at (UTC)',
    'datetime',
    'UPDATED_DATE_TIME',
    'UTC timestamp of the most recent status change.',
    { aliases: ['updated at', 'last updated', 'updated'], groupByTag: 'Timing' },
  ),
  column(
    'durationSeconds',
    'Duration (seconds)',
    'number',
    'DURATION_SECONDS',
    'Elapsed run time in whole seconds. Blank while an activity is still running or never produced data.',
    {
      aliases: ['duration', 'duration seconds', 'run time'],
      nullable: true,
      unit: 'seconds',
      scale: 0,
      groupByTag: 'Timing',
    },
  ),
  column(
    'breachMinutes',
    'Minutes past SLA',
    'number',
    'BREACH_MINUTES',
    'Whole minutes between the SLA deadline and completion. Present only for breached activities.',
    {
      aliases: ['minutes past sla', 'breach minutes', 'sla breach'],
      nullable: true,
      unit: 'minutes',
      scale: 0,
      groupByTag: 'Timing',
    },
  ),
  column(
    'processedRowCount',
    'Processed rows',
    'number',
    'PROCESSED_ROW_COUNT',
    'Number of records processed by the activity. Zero when no file or data arrived.',
    {
      aliases: ['processed rows', 'row count', 'rows processed'],
      unit: 'rows',
      scale: 0,
      groupByTag: 'Volume',
    },
  ),
  column(
    'eventCount',
    'Events',
    'number',
    'EVENT_COUNT',
    'Always 1. Summing this measure counts activities, and sorting grouped rows by its total ranks groups by activity count.',
    {
      aliases: ['events', 'event count', 'activity count'],
      unit: 'events',
      scale: 0,
      groupByTag: 'Volume',
    },
  ),
  column(
    'retryCount',
    'Retries',
    'number',
    'RETRY_COUNT',
    'Automatic or manual retries attempted for this activity.',
    { aliases: ['retries', 'retry count'], unit: 'retries', scale: 0, groupByTag: 'Volume' },
  ),
  column(
    'commentsCount',
    'Comments',
    'number',
    'COMMENTS_COUNT',
    'Number of operator comments recorded against the activity.',
    {
      aliases: ['comments count', 'comment count'],
      unit: 'comments',
      scale: 0,
      groupByTag: 'Volume',
    },
  ),
  column(
    'fileName',
    'File name',
    'text',
    'FILE_NAME',
    'Inbound or outbound file processed by the activity, or "File not received" when a feed never arrived. Blank for activities without files.',
    { aliases: ['file name', 'file'], nullable: true, groupByTag: 'Activity' },
  ),
  column(
    'parentActivityId',
    'Parent activity ID',
    'text',
    'PARENT_ACTIVITY_ID',
    'Orchestrating workflow or automation that launched this activity, when applicable.',
    {
      aliases: ['parent activity id', 'parent activity', 'parent'],
      nullable: true,
      groupByTag: 'Activity',
    },
  ),
  column(
    'context',
    'Context',
    'text',
    'CONTEXT',
    'Optional free-text run context such as the batch, cut-off or trigger.',
    { nullable: true, groupByTag: 'Activity' },
  ),
  column(
    'latestComment',
    'Latest comment',
    'text',
    'LATEST_COMMENT',
    'Most recent operator comment. Blank when nobody has commented.',
    { aliases: ['latest comment', 'comment'], nullable: true, groupByTag: 'Status' },
  ),
  column(
    'archived',
    'Archive state',
    'text',
    'ARCHIVED',
    'Whether the record has been archived from the active monitor.',
    { aliases: ['archive state', 'archived'], values: ARCHIVE_STATES, groupByTag: 'Status' },
  ),
];
const DEFAULT_VISIBLE = [
  'id',
  'name',
  'type',
  'source',
  'executionStatus',
  'dataStatus',
  'startedDateTime',
  'durationSeconds',
  'breachMinutes',
  'processedRowCount',
  'tenantCode',
  'fileName',
];

// ---------------------------------------------------------------------------------------------
// Deterministic generation
// ---------------------------------------------------------------------------------------------
function mulberry32(seed) {
  let state = seed >>> 0;
  return () => {
    state = (state + 0x6d2b79f5) >>> 0;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rng = mulberry32(20261003);
const pick = (items, weights) => {
  if (!weights) return items[Math.floor(rng() * items.length)];
  let total = 0;
  for (const w of weights) total += w;
  let roll = rng() * total;
  for (let i = 0; i < items.length; i++) {
    roll -= weights[i];
    if (roll <= 0) return items[i];
  }
  return items[items.length - 1];
};
const between = (min, max) => min + Math.floor(rng() * (max - min + 1));
const hex = (count) => {
  let out = '';
  for (let i = 0; i < count; i++) out += Math.floor(rng() * 16).toString(16);
  return out;
};
const uuid = () =>
  `${hex(8)}-${hex(4)}-4${hex(3)}-${['8', '9', 'a', 'b'][between(0, 3)]}${hex(3)}-${hex(12)}`;
const pad = (n) => String(n).padStart(2, '0');
const stamp = (ms) => {
  const d = new Date(ms);
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}`;
};

const SOURCE_WEIGHTS = [7, 6, 4, 10, 8, 18, 16, 5, 4, 14, 8];
const SOURCE_TYPES = {
  AUTOMATION: [
    ['Automation', 'Data Quality'],
    [7, 3],
  ],
  CAMUNDA: [['Workflow'], [1]],
  CONNECTIONS: [
    ['Connection Check', 'Outbound Job'],
    [7, 3],
  ],
  'DBT TRANSFORMATIONS': [['Transformation'], [1]],
  EAGLE: [
    ['Outbound Job', 'Data Quality', 'Ingestion'],
    [5, 3, 2],
  ],
  'INBOUND JOB': [['Inbound Job'], [1]],
  INGESTION: [
    ['Ingestion', 'Transformation'],
    [9, 1],
  ],
  LOOKUPS: [['Lookup Refresh'], [1]],
  'MODEL UPDATES': [['Model Update'], [1]],
  SLA: [['SLA'], [1]],
  WORKFLOW: [['Workflow'], [1]],
};
const NAMES = {
  Ingestion: [
    'Positions Feed',
    'Trades Feed',
    'Prices Feed',
    'Security Master Load',
    'Corporate Actions Feed',
    'FX Rates Ingest',
    'Benchmark Returns Ingest',
    'Cash Balances Feed',
  ],
  'Inbound Job': [
    'ProdIssueSLA4',
    'SLA_GJ',
    'Client Holdings Inbound',
    'Custodian Statement Inbound',
    'Broker Confirms Inbound',
    'Fund Accounting Inbound',
    'Transfer Agent Inbound',
  ],
  'Outbound Job': [
    'Client Reporting Extract',
    'Regulatory Filing Export',
    'Performance Pack Delivery',
    'Custody Statement Export',
    'Data Warehouse Publish',
    'Tax Lot Export',
  ],
  SLA: [
    'EOD Positions SLA',
    'Morning NAV SLA',
    'T+1 Reconciliation SLA',
    'Client Report Delivery SLA',
    'Price Availability SLA',
    'Trade Capture SLA',
  ],
  'Data Quality': [
    'Price Tolerance Check',
    'Position Break Check',
    'Missing Security Check',
    'Duplicate Trade Check',
    'Stale Price Check',
    'Cash Reconciliation Check',
  ],
  Workflow: [
    'Exception Review Workflow',
    'Break Resolution Workflow',
    'Client Onboarding Workflow',
    'Month-End Close Workflow',
    'Approval Routing Workflow',
  ],
  'Model Update': [
    'Risk Model Refresh',
    'Pricing Model Update',
    'Benchmark Model Rebuild',
    'Attribution Model Update',
  ],
  'Lookup Refresh': [
    'Country Codes Refresh',
    'Currency Lookup Refresh',
    'Counterparty Lookup Refresh',
    'Calendar Lookup Refresh',
  ],
  Transformation: [
    'Positions dbt Build',
    'Trades dbt Build',
    'Reference Data dbt Build',
    'Mart Refresh dbt Build',
  ],
  'Connection Check': [
    'SFTP Connectivity Check',
    'Snowflake Warehouse Check',
    'Kafka Topic Check',
    'API Gateway Health Check',
  ],
  Automation: [
    'Nightly Batch Orchestrator',
    'Alert Dispatcher',
    'Report Scheduler',
    'Archive Sweeper',
  ],
};
const PREFIX = {
  Ingestion: 'ingestion',
  'Inbound Job': 'inbound',
  'Outbound Job': 'outbound',
  SLA: 'sla',
  'Data Quality': 'dq',
  Workflow: 'workflow',
  'Model Update': 'model',
  'Lookup Refresh': 'lookup',
  Transformation: 'dbt',
  'Connection Check': 'connection',
  Automation: 'automation',
};
const FILE_TYPES = new Set(['Ingestion', 'Inbound Job', 'Outbound Job']);
const TEAM_BY_TYPE = {
  Ingestion: [
    ['Data Operations', 'Client Service'],
    [7, 3],
  ],
  'Inbound Job': [
    ['Data Operations', 'Client Service'],
    [6, 4],
  ],
  'Outbound Job': [
    ['Reporting', 'Client Service', 'Data Operations'],
    [5, 3, 2],
  ],
  SLA: [
    ['Client Service', 'Reporting', 'Data Operations'],
    [5, 3, 2],
  ],
  'Data Quality': [
    ['Risk & Controls', 'Reconciliations'],
    [6, 4],
  ],
  Workflow: [
    ['Reconciliations', 'Client Service', 'Risk & Controls'],
    [5, 3, 2],
  ],
  'Model Update': [
    ['Risk & Controls', 'Platform Engineering'],
    [7, 3],
  ],
  'Lookup Refresh': [
    ['Platform Engineering', 'Data Operations'],
    [7, 3],
  ],
  Transformation: [
    ['Platform Engineering', 'Data Operations'],
    [6, 4],
  ],
  'Connection Check': [['Platform Engineering'], [1]],
  Automation: [
    ['Platform Engineering', 'Data Operations'],
    [8, 2],
  ],
};
// Execution status weights per type. Index order follows EXECUTION_STATUSES.
const BASE_STATUS_WEIGHTS = [4, 5, 3, 15, 10, 45, 7, 5, 3, 3];
const STATUS_ADJUSTMENTS = {
  SLA: [3, 18, 1, 8, 6, 48, 2, 4, 2, 8],
  'Inbound Job': [6, 9, 3, 14, 10, 38, 8, 5, 6, 1],
  'Data Quality': [8, 3, 2, 12, 22, 40, 6, 4, 2, 1],
  Workflow: [14, 3, 5, 20, 8, 30, 5, 12, 1, 2],
  'Connection Check': [1, 1, 1, 10, 4, 70, 9, 2, 1, 1],
};
const TYPICAL_SECONDS = {
  Ingestion: 1800,
  'Inbound Job': 900,
  'Outbound Job': 1200,
  SLA: 2400,
  'Data Quality': 600,
  Workflow: 5400,
  'Model Update': 3600,
  'Lookup Refresh': 120,
  Transformation: 2700,
  'Connection Check': 20,
  Automation: 300,
};
const VOLUME_SCALE = {
  Ingestion: 5.9,
  'Inbound Job': 5.4,
  'Outbound Job': 5.2,
  SLA: 0,
  'Data Quality': 5.6,
  Workflow: 2.2,
  'Model Update': 5.3,
  'Lookup Refresh': 3.6,
  Transformation: 6.4,
  'Connection Check': 0,
  Automation: 2.4,
};
const CONTEXTS = [
  'Batch 1 of 4',
  'Batch 2 of 4',
  'Batch 3 of 4',
  'Batch 4 of 4',
  'EMEA cut-off',
  'APAC cut-off',
  'Americas close',
  'Reprocess requested',
  'Manual trigger',
  'Retry after connection reset',
  'Client escalation',
  'Month-end run',
];
const COMMENTS = [
  'Vendor confirmed late delivery; file expected by 18:30 UTC.',
  'Investigating duplicate trade identifiers before rerun.',
  'Waived by operations lead; downstream reports unaffected.',
  'Rerun completed successfully after upstream fix.',
  'Awaiting client confirmation of position breaks.',
  'Escalated to platform engineering for connectivity review.',
  'Tolerance threshold adjusted after review.',
  'Connection restored; retry succeeded.',
  'Partial file received; remaining records expected tomorrow.',
  'Cut-off extended by 30 minutes for the EMEA region.',
];
const HOUR_WEIGHTS = [6, 7, 7, 6, 5, 5, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 5, 3, 2, 2, 3, 4];
/** Final-hour profile: a batch window from 11:30 and two incidents the dashboards should surface. */
const MINUTE_WEIGHTS = Array.from(
  { length: 60 },
  (_, minute) =>
    1 + 0.35 * Math.sin((minute / 60) * Math.PI) + (minute >= 30 && minute < 45 ? 0.5 : 0),
);
const INCIDENTS = [
  {
    minutes: [35, 36, 37],
    probability: 0.55,
    source: 'INGESTION',
    type: 'Ingestion',
    status: 'Failed',
    names: [
      ['Positions Feed', 'Prices Feed', 'Trades Feed'],
      [5, 3, 2],
    ],
  },
  {
    minutes: [50, 51, 52],
    probability: 0.45,
    source: 'INBOUND JOB',
    type: 'Inbound Job',
    status: 'Breached',
    names: [
      ['Custodian Statement Inbound', 'ProdIssueSLA4', 'Client Holdings Inbound'],
      [5, 3, 2],
    ],
  },
  {
    minutes: [20, 21],
    probability: 0.4,
    source: 'DBT TRANSFORMATIONS',
    type: 'Transformation',
    status: 'Completed with exceptions',
    names: [
      ['Positions dbt Build', 'Mart Refresh dbt Build'],
      [6, 4],
    ],
  },
];
const slug = (value) =>
  value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_|_$/g, '');
const FINISHED = new Set([
  'Breached',
  'Canceled',
  'Completed',
  'Completed with exceptions',
  'Completed with no exceptions',
  'Failed',
  'Waived',
]);

const ids = new Set();
const orchestrators = [];
const rows = [];
const typeCounts = new Map();
let denseFailures = 0;
for (let i = 0; i < ROW_COUNT; i++) {
  const dense = i < DENSE_ROWS;
  let started;
  let day = 0;
  let incident = null;
  if (dense) {
    const minute = pick(
      Array.from({ length: 60 }, (_, m) => m),
      MINUTE_WEIGHTS,
    );
    started = END - 3_600_000 + minute * 60_000 + between(0, 59) * 1000;
    incident =
      INCIDENTS.find((item) => item.minutes.includes(minute) && rng() < item.probability) ?? null;
  } else {
    // Recent days are busier; weekends are quiet.
    day = Math.floor(DAYS * Math.pow(rng(), 1.35));
    let dayStart = Date.UTC(2026, 9, 3) - day * 86400000;
    for (let attempt = 0; attempt < 3; attempt++) {
      const weekday = new Date(dayStart).getUTCDay();
      if ((weekday !== 0 && weekday !== 6) || rng() < 0.35) break;
      day = Math.floor(DAYS * Math.pow(rng(), 1.35));
      dayStart = Date.UTC(2026, 9, 3) - day * 86400000;
    }
    const hour = pick(
      Array.from({ length: 24 }, (_, h) => h),
      HOUR_WEIGHTS,
    );
    started = dayStart + hour * 3600000 + between(0, 59) * 60000 + between(0, 59) * 1000;
    if (started >= END) started = END - between(1, 3600) * 1000 - 3_600_000;
  }
  const source = incident?.source ?? pick(SOURCES, SOURCE_WEIGHTS);
  const type = incident?.type ?? pick(...SOURCE_TYPES[source]);
  const name = incident ? pick(...incident.names) : pick(NAMES[type]);
  const status =
    incident?.status ?? pick(EXECUTION_STATUSES, STATUS_ADJUSTMENTS[type] ?? BASE_STATUS_WEIGHTS);
  const finished = FINISHED.has(status);
  const running = status === 'In Progress' || status === 'Awaiting User Action';
  let id;
  do id = `${PREFIX[type]}-${uuid()}`;
  while (ids.has(id));
  ids.add(id);
  const typical = TYPICAL_SECONDS[type];
  const durationSeconds =
    status === 'No Data' || running
      ? null
      : status === 'Canceled'
        ? Math.max(5, Math.round(typical * rng() * 0.6))
        : Math.max(
            5,
            Math.round(typical * (0.35 + rng() * 1.4) * (status === 'Breached' ? 1.8 : 1)),
          );
  const updated = started + (durationSeconds ?? between(60, 7200)) * 1000;
  const breachMinutes =
    status === 'Breached'
      ? incident
        ? between(3, 45)
        : Math.max(1, Math.round(1 + 719 * Math.pow(rng(), 2.2)))
      : null;
  const volumeScale = VOLUME_SCALE[type];
  let processedRowCount = 0;
  if (
    volumeScale &&
    (status.startsWith('Completed') || status === 'Breached' || status === 'Waived')
  )
    processedRowCount = Math.round(Math.pow(10, 1.5 + (volumeScale - 1.5) * rng()));
  else if (
    volumeScale &&
    (status === 'Failed' || status === 'In Progress' || status === 'Canceled')
  )
    processedRowCount = rng() < 0.5 ? 0 : Math.round(Math.pow(10, 1 + (volumeScale - 2) * rng()));
  const dataStatus =
    status === 'Completed with no exceptions' || status === 'Completed'
      ? 'Completed'
      : status === 'Completed with exceptions'
        ? pick(['Partial', 'Completed'], [6, 4])
        : status === 'Breached'
          ? pick(['Completed', 'No Data', 'Partial'], [5, 3, 2])
          : status === 'Failed'
            ? pick(['Failed', 'Partial', 'No Data'], [5, 3, 2])
            : status === 'Waived'
              ? pick(['No Data', 'Completed'], [6, 4])
              : status === 'Canceled'
                ? pick(['No Data', 'Partial'], [7, 3])
                : status === 'No Data'
                  ? 'No Data'
                  : 'Pending';
  const retryCount =
    status === 'Failed'
      ? between(1, 3)
      : status === 'Breached'
        ? between(0, 2)
        : rng() < 0.12
          ? 1
          : 0;
  const attention = ['Failed', 'Breached', 'Awaiting User Action'].includes(status);
  const commentsCount = attention
    ? rng() < 0.7
      ? between(1, 6)
      : 0
    : rng() < 0.08
      ? between(1, 2)
      : 0;
  const latestComment = commentsCount ? pick(COMMENTS) : null;
  const yyyymmdd = stamp(started).slice(0, 10).replaceAll('-', '');
  const fileName = FILE_TYPES.has(type)
    ? status === 'No Data' || (type === 'Inbound Job' && status === 'Breached' && rng() < 0.6)
      ? 'File not received'
      : `${slug(name)}_${yyyymmdd}_${between(1, 9)}.${pick(['csv', 'xml', 'json', 'dat'], [6, 2, 1, 1])}`
    : null;
  const parentActivityId =
    orchestrators.length && !['Workflow', 'Automation'].includes(type) && rng() < 0.18
      ? pick(orchestrators)
      : null;
  const context = incident
    ? incident.status === 'Failed'
      ? 'Upstream vendor outage'
      : incident.status === 'Breached'
        ? 'Custodian files delayed'
        : 'Tolerance review pending'
    : rng() < 0.32
      ? pick(CONTEXTS)
      : null;
  const priority = attention
    ? pick(PRIORITIES, [20, 40, 30, 10])
    : pick(PRIORITIES, [2, 15, 55, 28]);
  const archived = !dense && day > 60 && rng() < 0.3 ? 'Yes' : 'No';
  const row = {
    id,
    name,
    type,
    source,
    executionStatus: status,
    dataStatus,
    priority,
    tenantCode: pick(TENANTS, [30, 22, 14, 13, 11, 10]),
    region: pick(REGIONS, [45, 35, 20]),
    owner: pick(...TEAM_BY_TYPE[type]),
    businessDate: stamp(started).slice(0, 10),
    startedDateTime: stamp(started),
    updatedDateTime: stamp(finished || running ? updated : started),
    durationSeconds,
    breachMinutes,
    processedRowCount,
    eventCount: 1,
    retryCount,
    commentsCount,
    fileName,
    parentActivityId,
    context,
    latestComment,
    archived,
  };
  if ((type === 'Workflow' || type === 'Automation') && orchestrators.length < 400)
    orchestrators.push(id);
  typeCounts.set(type, (typeCounts.get(type) ?? 0) + 1);
  if (dense && (status === 'Failed' || status === 'Breached')) denseFailures++;
  rows.push(columns.map((c) => row[c.id]));
}

// ---------------------------------------------------------------------------------------------
// Compact NDJSON snapshot (column-rows-v1), gzip, base64 chunks
// ---------------------------------------------------------------------------------------------
const lines = [
  JSON.stringify({
    type: 'start',
    schemaVersion: SCHEMA_VERSION,
    totalRows: rows.length,
    encoding: 'column-rows-v1',
    columns: columns.map((c) => c.id),
  }),
];
for (let offset = 0; offset < rows.length; offset += BATCH_ROWS)
  lines.push(JSON.stringify({ type: 'batch', rows: rows.slice(offset, offset + BATCH_ROWS) }));
lines.push(JSON.stringify({ type: 'complete', totalRows: rows.length }));
const text = lines.join('\n') + '\n';
const uncompressedBytes = Buffer.byteLength(text);
const dataVersion = createHash('sha256').update(text).digest('hex');
const gzip = gzipSync(Buffer.from(text, 'utf8'), { level: 9 });
const base64 = gzip.toString('base64');
const prefix = createHash('sha256').update(gzip).digest('hex').slice(0, 12);

const bundledDir = path.join(root, 'src/data/assets/bundled');
mkdirSync(bundledDir, { recursive: true });
const manifestPath = path.join(root, 'src/data/bundled-assets.json');
const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'));
for (const stale of manifest[MANIFEST_KEY] ?? []) {
  const file = path.join(bundledDir, stale);
  if (existsSync(file)) rmSync(file);
}
const parts = [];
for (let start = 0, index = 0; start < base64.length; start += CHUNK_CHARS, index++) {
  const name = `${prefix}-${String(index).padStart(3, '0')}.txt`;
  writeFileSync(path.join(bundledDir, name), base64.slice(start, start + CHUNK_CHARS));
  parts.push(name);
}
manifest[MANIFEST_KEY] = parts;
writeFileSync(manifestPath, JSON.stringify(manifest, null, 2) + '\n');

// ---------------------------------------------------------------------------------------------
// Source catalog entry
// ---------------------------------------------------------------------------------------------
const catalogPath = path.join(root, 'src/data/source-catalog.json');
const catalog = JSON.parse(readFileSync(catalogPath, 'utf8'));
const entry = {
  key: KEY,
  metadata: {
    id: 'local_activity_monitor',
    label: 'Activity monitor',
    description: `${rows.length.toLocaleString('en-US')} synthetic operations activity records over ${DAYS} days: ingestion feeds, inbound and outbound jobs, SLA checks, data-quality controls, workflows and model or lookup refreshes. The final hour before the 12:00 UTC snapshot is dense and contains two incidents for the triage dashboards. Breaches, failures and retries are illustrative; no client or production data.`,
    rowLabel: 'activity record',
    version: SCHEMA_VERSION,
    category: 'Operations',
    tags: ['Featured', 'Operations', 'Server grid'],
    featured: true,
    columns,
    defaultVisibleColumnIds: DEFAULT_VISIBLE,
    sqlDataset: {
      table: ['ACTIVITY_MONITOR'],
      tenantColumn: 'TENANT_ID',
      rowIdColumn: 'id',
      columns,
    },
    schemaVersion: SCHEMA_VERSION,
    rowCount: rows.length,
    dataVersion,
    authorizedTenant: 'demo',
    synthetic: true,
    uncompressedBytes,
    /** Fixed clock for sliding-window dashboards; a live source omits this and uses the current time. */
    snapshotEndsAt: new Date(END).toISOString(),
  },
};
const existing = catalog.findIndex((source) => source.key === KEY);
if (existing >= 0) catalog[existing] = entry;
else catalog.push(entry);
writeFileSync(catalogPath, JSON.stringify(catalog, null, 2) + '\n');

console.log(
  `Activity monitor: ${rows.length.toLocaleString('en-US')} rows (${DENSE_ROWS.toLocaleString('en-US')} in the final hour, ${denseFailures.toLocaleString('en-US')} of them failed or breached), ${columns.length} columns, ` +
    `${(uncompressedBytes / 1048576).toFixed(1)} MB NDJSON, ${(gzip.length / 1048576).toFixed(2)} MB gzip in ${parts.length} chunks (${prefix}).`,
);
console.log(
  'Rows per type: ' +
    [...typeCounts.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([type, count]) => `${type} ${count.toLocaleString('en-US')}`)
      .join(', '),
);
console.log(
  'Run "npx prettier --write src/data/bundled-assets.json src/data/source-catalog.json" to keep the JSON style.',
);
