import http from 'node:http';
import { createReadStream, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { networkInterfaces } from 'node:os';
const root = path.resolve(fileURLToPath(new URL('./public/', import.meta.url)));
const port = Number(process.env.PORT || 4173);
const host = process.env.HOST || '127.0.0.1';
const types = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json',
  '.svg': 'image/svg+xml',
  '.woff2': 'font/woff2',
  '.png': 'image/png',
  '.gz': 'application/gzip',
  '.txt': 'text/plain; charset=utf-8',
  '.wasm': 'application/wasm',
};
const server = http.createServer((req, res) => {
  if (!['GET', 'HEAD'].includes(req.method)) {
    res.writeHead(405, { Allow: 'GET, HEAD' });
    res.end();
    return;
  }
  let file;
  try {
    const pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    file = path.resolve(root, '.' + pathname);
    if (file !== root && !file.startsWith(root + path.sep)) {
      res.writeHead(403);
      res.end();
      return;
    }
    let stat;
    try {
      stat = statSync(file);
    } catch {}
    if (!stat?.isFile()) {
      if (path.extname(pathname)) {
        res.writeHead(404);
        res.end('Not found');
        return;
      }
      file = path.join(root, 'index.html');
      stat = statSync(file);
    }
    res.writeHead(200, {
      'Content-Type': types[path.extname(file)] || 'application/octet-stream',
      'Content-Length': stat.size,
      'Cache-Control': path.basename(file) === 'index.html' ? 'no-store' : 'public, max-age=3600',
      'X-Content-Type-Options': 'nosniff',
    });
    if (req.method === 'HEAD') {
      res.end();
      return;
    }
    createReadStream(file)
      .on('error', () => res.destroy())
      .pipe(res);
  } catch {
    res.writeHead(400);
    res.end('Invalid request');
  }
});
server.on('error', (e) => {
  console.error(e.message);
  process.exitCode = 1;
});
server.listen(port, host, () => {
  console.log(`Prism: http://localhost:${port}`);
  if (host === '0.0.0.0')
    for (const entries of Object.values(networkInterfaces()))
      for (const item of entries ?? [])
        if (item.family === 'IPv4' && !item.internal)
          console.log(`Same-network link: http://${item.address}:${port}`);
  console.log('No API or database. Keep this terminal open. Ctrl+C to stop.');
});
