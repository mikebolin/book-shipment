import { cp, mkdtemp, readFile, writeFile, mkdir, symlink, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve, sep } from 'node:path';
import { spawnSync } from 'node:child_process';

// Build only Charting in a fresh application. Neither sibling library nor demo data is copied.
const project = resolve('.');
const isolated = await mkdtemp(join(tmpdir(), 'prism-charting-'));
const json = async (name) => JSON.parse(await readFile(join(project, name), 'utf8'));
try {
  await mkdir(join(isolated, 'libs'), { recursive: true });
  await cp(join(project, 'libs/charting'), join(isolated, 'libs/charting'), { recursive: true });
  await symlink(
    join(project, 'node_modules'),
    join(isolated, 'node_modules'),
    process.platform === 'win32' ? 'junction' : 'dir',
  );
  await writeFile(
    join(isolated, 'package.json'),
    JSON.stringify({ type: 'module', private: true }),
  );
  const config = await json('angular.json');
  delete config.projects.dashboards;
  delete config.projects.userPref;
  const options = config.projects.prism.architect.build.options;
  options.assets = options.assets.filter((asset) => !asset.input.startsWith('src/data'));
  options.outputPath = 'dist';
  await writeFile(join(isolated, 'angular.json'), JSON.stringify(config));
  const tsconfig = await json('tsconfig.json');
  tsconfig.compilerOptions.paths = { '@prism/charting': ['./libs/charting/src/public-api.ts'] };
  await writeFile(join(isolated, 'tsconfig.json'), JSON.stringify(tsconfig));
  for (const file of ['tsconfig.app.json', 'tsconfig.worker.json'])
    await cp(join(project, file), join(isolated, file));
  await mkdir(join(isolated, 'src'));
  await cp(join(project, 'src/index.html'), join(isolated, 'src/index.html'));
  await writeFile(
    join(isolated, 'src/main.ts'),
    `
import { Component, provideZonelessChangeDetection } from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';
import { RouterOutlet, provideRouter } from '@angular/router';
@Component({selector:'app-root', standalone:true, imports:[RouterOutlet], template:'<router-outlet />'})
class IsolatedApp {}
bootstrapApplication(IsolatedApp, {providers:[provideZonelessChangeDetection(), provideRouter([
  {path:'',pathMatch:'full',redirectTo:'studio/import'},
  {path:'',loadChildren:()=>import('@prism/charting').then(m=>m.CHARTING_ROUTES)}
])]}).catch(console.error);
`,
  );
  const result = spawnSync(
    process.execPath,
    [join(project, 'node_modules/@angular/cli/bin/ng.js'), 'build'],
    { cwd: isolated, stdio: 'inherit' },
  );
  if (result.status !== 0) throw new Error(`Isolated build failed (${result.status})`);
  console.log(
    'PASS: Charting builds without Dashboards, userPref, host fixtures, or a custom data provider.',
  );
  if (process.env.PRISM_KEEP_ISOLATION) console.log(`Isolated project: ${isolated}`);
} finally {
  if (!process.env.PRISM_KEEP_ISOLATION) {
    const temporaryRoot = resolve(tmpdir());
    const isolatedRoot = resolve(isolated);
    if (!isolatedRoot.startsWith(temporaryRoot + sep) || !isolatedRoot.slice(temporaryRoot.length + 1).startsWith('prism-charting-'))
      throw new Error('Refusing to remove an isolation folder outside the expected temporary location.');
    await rm(isolatedRoot, { recursive: true, force: true });
  }
}
