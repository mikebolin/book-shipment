import { existsSync, rmSync, mkdirSync, cpSync, copyFileSync, writeFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';
const root = fileURLToPath(new URL('../', import.meta.url));
const cli = path.join(root, 'node_modules/@angular/cli/bin/ng.js');
if (!existsSync(cli)) {
  const install = spawnSync(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['ci'], {
    cwd: root,
    stdio: 'inherit',
    shell: process.platform === 'win32',
  });
  if (install.status !== 0) process.exit(install.status ?? 1);
}
const build = spawnSync(process.execPath, [cli, 'build'], { cwd: root, stdio: 'inherit' });
if (build.status !== 0) process.exit(build.status ?? 1);
const destination = path.join(root, 'share-ready');
rmSync(destination, { recursive: true, force: true });
mkdirSync(destination, { recursive: true });
cpSync(path.join(root, 'dist/browser-app/browser'), path.join(destination, 'public'), {
  recursive: true,
});
const licenses = path.join(root, 'dist/browser-app/3rdpartylicenses.txt');
if (existsSync(licenses))
  copyFileSync(licenses, path.join(destination, 'THIRD-PARTY-LICENSES.txt'));
copyFileSync(path.join(root, 'scripts/portable-server.mjs'), path.join(destination, 'serve.mjs'));
writeFileSync(
  path.join(destination, 'package.json'),
  JSON.stringify(
    {
      name: 'prism-portable',
      private: true,
      type: 'module',
      scripts: { start: 'node serve.mjs' },
      engines: { node: '>=22' },
    },
    null,
    2,
  ) + '\n',
);
writeFileSync(
  path.join(destination, 'start.cmd'),
  '@echo off\r\ncd /d "%~dp0"\r\nnode serve.mjs\r\npause\r\n',
);
writeFileSync(
  path.join(destination, 'start.sh'),
  '#!/bin/sh\ncd "$(dirname "$0")" || exit 1\nexec node serve.mjs\n',
  { mode: 0o755 },
);
writeFileSync(
  path.join(destination, 'README.txt'),
  `PRISM - READY TO RUN\n\nRequires Node.js 22 or newer. No npm install or build needed here.\nRun: node serve.mjs\nOpen: http://localhost:4173\nWindows: double-click start.cmd. macOS/Linux: ./start.sh\n\nTo serve on your local network: set HOST=0.0.0.0 in your shell before starting.\nPORT can change the default port. Internet sharing: upload the public folder to static hosting.\nLazy routes, chart libraries, themes, fonts and mock data are included in public.\nDeep links need an SPA fallback to index.html; the bundled server includes it.\nData and theme changes are private to each browser session and reset on refresh.\nThis is a runnable build. Use the source project for code collaboration.\n`,
);
console.log('\nReady: share-ready/ — hand over this folder; run node serve.mjs.');
if (process.argv.includes('--serve')) {
  process.env.HOST ??= '0.0.0.0';
  await import(pathToFileURL(path.join(destination, 'serve.mjs')).href);
}
