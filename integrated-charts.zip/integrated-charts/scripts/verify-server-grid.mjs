import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createServer } from 'node:http';
import { cp, mkdir, mkdtemp, readFile, symlink, writeFile } from 'node:fs/promises';
import { extname, join, resolve, sep } from 'node:path';
import { chromium, expect } from '@playwright/test';

// Build an isolated consumer of Charting's public API with metadata and a host executor,
// no demo data, dashboards, sibling libraries or usable snapshot endpoint.
const project = resolve('.');
const isolationRoot = join(project, '.angular');
await mkdir(isolationRoot, { recursive: true });
const reuse = process.env.PRISM_SERVER_GRID_REUSE;
const isolated = reuse ? resolve(reuse) : await mkdtemp(join(isolationRoot, 'server-grid-host-'));
if (!isolated.startsWith(isolationRoot + sep + 'server-grid-host-'))
  throw new Error('The reused host must be an isolated server-grid-host project inside .angular.');
if (!reuse) {
  const json = async (name) => JSON.parse(await readFile(join(project, name), 'utf8'));
  await mkdir(join(isolated, 'libs'), { recursive: true });
  await cp(join(project, 'libs/charting'), join(isolated, 'libs/charting'), { recursive: true });
  await symlink(
    join(project, 'node_modules'),
    join(isolated, 'node_modules'),
    process.platform === 'win32' ? 'junction' : 'dir',
  );
  await writeFile(
    join(isolated, 'package.json'),
    JSON.stringify({ type: 'module', private: true }),
  );
  const angular = await json('angular.json');
  delete angular.projects.dashboards;
  delete angular.projects.userPref;
  angular.projects.prism.architect.build.options.assets =
    angular.projects.prism.architect.build.options.assets.filter(
      (asset) => !asset.input.startsWith('src/data'),
    );
  angular.projects.prism.architect.build.options.outputPath = 'dist';
  await writeFile(join(isolated, 'angular.json'), JSON.stringify(angular));
  const tsconfig = await json('tsconfig.json');
  tsconfig.compilerOptions.paths = { '@prism/charting': ['./libs/charting/src/public-api.ts'] };
  await writeFile(join(isolated, 'tsconfig.json'), JSON.stringify(tsconfig));
  for (const name of ['tsconfig.app.json', 'tsconfig.worker.json'])
    await cp(join(project, name), join(isolated, name));
  await mkdir(join(isolated, 'src'));
  await cp(join(project, 'src/index.html'), join(isolated, 'src/index.html'));
  // Keep the test-only internal fixture import at its documented relative location.
  await mkdir(join(isolated, 'tests/support/metadata-only-host'), { recursive: true });
  await cp(
    join(project, 'tests/support/metadata-only-host/main.ts'),
    join(isolated, 'tests/support/metadata-only-host/main.ts'),
  );
  await writeFile(
    join(isolated, 'src/main.ts'),
    "import '../tests/support/metadata-only-host/main';\n",
  );
  console.log(`Metadata-only host project: ${isolated}`);
  await new Promise((done, fail) => {
    const build = spawn(
      process.execPath,
      [
        join(project, 'node_modules/@angular/cli/bin/ng.js'),
        'build',
        '--configuration=development',
      ],
      { cwd: isolated, stdio: 'inherit', windowsHide: true },
    );
    build.once('error', fail);
    build.once('exit', (code) =>
      code === 0 ? done() : fail(new Error(`Metadata-only host build failed (${code}).`)),
    );
  });
}

const webRoot = resolve(isolated, 'dist/browser');
const mime = {
  '.js': 'text/javascript',
  '.css': 'text/css',
  '.html': 'text/html',
  '.json': 'application/json',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.woff2': 'font/woff2',
  '.wasm': 'application/wasm',
};
const server = createServer(async (request, response) => {
  const pathname = decodeURIComponent(new URL(request.url, 'http://localhost').pathname);
  const target = resolve(webRoot, '.' + pathname);
  if (target !== webRoot && !target.startsWith(webRoot + sep)) {
    response.writeHead(403).end();
    return;
  }
  try {
    const file = extname(target) ? target : join(webRoot, 'index.html');
    response.writeHead(200, { 'content-type': mime[extname(file)] ?? 'application/octet-stream' });
    response.end(await readFile(file));
  } catch {
    response.writeHead(404).end();
  }
});
await new Promise((done) => server.listen(0, '127.0.0.1', done));
const base = `http://127.0.0.1:${server.address().port}`;
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({
  viewport: { width: 1440, height: 1000 },
  acceptDownloads: true,
});
const page = await context.newPage();
page.setDefaultTimeout(30_000);
const downloads = [];
const uncaught = [];
page.on('download', (download) => downloads.push(download.suggestedFilename()));
page.on('pageerror', (error) => uncaught.push(error.message));
const probe = () => page.evaluate(() => structuredClone(window.__serverGridProbe));
const savedView = (slug) => page.evaluate((name) => window.__serverGridHost.view(name), slug);
const completed = (state) => state.queries.filter((query) => query.returnedRows !== undefined);
// AG Grid serializes datetime-string filters with T; the compiler accepts the saved UTC
// space separator too. Compare the rule structure and values without treating that as an edit.
function canonicalFilter(model) {
  if (model?.filterType === 'join')
    return { ...model, conditions: model.conditions.map(canonicalFilter) };
  return model &&
    ['dateTimeString', 'dateTime'].includes(model.filterType) &&
    typeof model.filter === 'string'
    ? { ...model, filter: model.filter.replace('T', ' ').replace(/Z$/, '') }
    : model;
}
function savedShape(query, configuration, size, label) {
  const request = query.request.request;
  assert.equal(query.request.mode, configuration.mode, `${label}: saved filter mode is used.`);
  assert.deepEqual(
    canonicalFilter(request.filterModel),
    canonicalFilter(configuration.gridState.filter.advancedFilterModel),
    `${label}: saved filters apply before the query is sent.`,
  );
  assert.deepEqual(
    request.rowGroupCols.map((column) => column.id),
    configuration.gridState.rowGroup.groupColIds,
    `${label}: saved hierarchy applies before the query is sent.`,
  );
  assert.deepEqual(
    request.valueCols.map((column) => ({ colId: column.id, aggFunc: column.aggFunc })),
    configuration.gridState.aggregation.aggregationModel,
    `${label}: saved aggregations are preserved.`,
  );
  assert.deepEqual(
    request.sortModel,
    (configuration.gridState.sort?.sortModel ?? []).map(({ colId, sort }) => ({ colId, sort })),
    `${label}: saved sort order is preserved.`,
  );
  assert.equal(
    request.endRow - request.startRow,
    size,
    `${label}: the saved page size controls the query.`,
  );
}
async function settings() {
  await page.getByRole('button', { name: 'View actions', exact: true }).click();
  await page.getByRole('menuitem', { name: 'View settings', exact: true }).click();
  return page.getByRole('dialog', { name: 'View settings', exact: true });
}
const visibleColumns = () =>
  page
    .locator('.studio-editor:not([hidden]) .grid-shell .ag-header-cell[col-id]')
    .evaluateAll((elements) =>
      elements
        .sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left)
        .map((element) => element.getAttribute('col-id'))
        .filter((id) => ['id', 'type', 'status', 'businessDate', 'started', 'events'].includes(id)),
    );
const validBlocks = (state) => {
  const queries = completed(state);
  assert.ok(queries.length, 'The supplied executor must receive a completed grid request.');
  for (const query of queries) {
    const block = query.request.request;
    assert.equal(query.sourceId, 'remote_activity');
    assert.equal(
      typeof query.tenant,
      'string',
      'Executor calls include transport context; the host resolves authenticated tenancy.',
    );
    assert.ok(query.sql.includes('"INTEGRATION"."PUBLIC"."ACTIVITY_EVENTS"'));
    assert.ok(query.sql.includes('"TENANT_ID" = ?'), 'Tenant restrictions stay parameterized.');
    assert.ok(
      block.endRow - block.startRow <= 500,
      'Each request respects the validated SQL row limit.',
    );
    assert.ok(
      query.returnedRows <= block.endRow - block.startRow,
      'Only the requested block is returned.',
    );
    assert.equal(query.totalRows, 1_000);
  }
  assert.equal(
    state.snapshotCalls,
    0,
    'Rendering/filtering/grouping must never fetch a full snapshot.',
  );
  assert.equal(state.assetCalls, 0, 'The host must not rely on bundled fixture assets.');
};
async function field(dialog, label, value, operator) {
  const count = await dialog.locator('.condition-row').count();
  await dialog.getByRole('button', { name: 'Add filter', exact: true }).first().click();
  await expect(dialog.locator('.condition-row')).toHaveCount(count + 1);
  const row = dialog.locator('.condition-row').last();
  await row.getByRole('combobox', { name: 'Choose filter column', exact: true }).fill(label);
  await page.getByRole('option').filter({ hasText: label }).first().click();
  await row.getByRole('textbox', { name: 'Condition value', exact: true }).fill(value);
  await row.getByRole('textbox', { name: 'Condition value', exact: true }).press('Tab');
  if (operator) {
    await row.getByRole('combobox', { name: 'Condition operator', exact: true }).click();
    await page.getByRole('option', { name: operator, exact: true }).click();
  }
}
try {
  await page.goto(`${base}/studio/remote-activity`);
  await expect(page.locator('.studio-editor:not([hidden]) .ag-row').first()).toBeVisible();
  await expect(page.locator('.dataset-record-count')).toContainText('1,000 records');
  validBlocks(await probe());
  await page.getByRole('combobox', { name: 'Data source or view', exact: true }).click();
  const sourcePicker = page.locator('.studio-source-panel');
  await expect(sourcePicker.locator('mat-option.current')).toHaveCount(1);
  await expect(sourcePicker.locator('mat-option.current .option-name')).toHaveText(
    'Remote activity',
  );
  await expect(sourcePicker.locator('.status-pill')).toHaveCount(0);
  await expect(sourcePicker.locator('.mat-mdc-optgroup-label')).toContainText([
    'Data sources',
    'Views in Remote activity',
  ]);
  await page.screenshot({
    path: join(isolated, 'studio-source-picker.png'),
    animations: 'disabled',
  });
  await page.keyboard.press('Escape');
  const initialCount = completed(await probe()).length;
  const gridViewport = page.locator(
    '.studio-editor:not([hidden]) .ag-body-vertical-scroll-viewport',
  );
  await gridViewport.evaluate((element) => {
    element.scrollTop = 700 * 31;
  });
  await expect
    .poll(async () => completed(await probe()).some((query) => query.request.request.startRow > 0))
    .toBe(true);
  validBlocks(await probe());
  await page.getByRole('button', { name: 'Advanced filters', exact: true }).click();
  const dialog = page.getByRole('dialog', { name: 'Remote activity', exact: true });
  await field(dialog, 'Business date', '10/03/2026', 'On or after');
  await field(dialog, 'Started at (UTC)', '2026-10-03T11:00:00Z', 'On or after');
  await field(dialog, 'Started at (UTC)', '2026-10-03T12:00:00Z', 'Before');
  await expect(dialog.getByRole('button', { name: 'Apply changes', exact: true })).toBeEnabled();
  await page.screenshot({ path: join(isolated, 'inline-filters.png'), animations: 'disabled' });
  await dialog.getByRole('button', { name: 'Apply changes', exact: true }).click();
  await expect
    .poll(async () =>
      completed(await probe()).some((query) => query.request.request.filterModel !== null),
    )
    .toBe(true);
  const studioState = await probe();
  validBlocks(studioState);
  const studioFiltered = completed(studioState).findLast(
    (query) => query.request.request.filterModel !== null,
  );
  assert.ok(studioFiltered.matchedRows > 0 && studioFiltered.matchedRows < 1_000);
  assert.ok(studioFiltered.sql.includes("TO_DATE(?, 'YYYY-MM-DD')"));
  assert.ok(studioFiltered.sql.includes("TO_TIMESTAMP_NTZ(?, 'YYYY-MM-DD HH24:MI:SS')"));
  assert.ok(studioFiltered.binds.includes('2026-10-03'));
  assert.ok(studioFiltered.binds.includes('2026-10-03 11:00:00'));
  assert.ok(studioFiltered.binds.includes('2026-10-03 12:00:00'));
  await page.screenshot({ path: join(isolated, 'studio-grid.png'), animations: 'disabled' });
  await page.getByRole('button', { name: 'Close view navigator', exact: true }).click();
  await page.setViewportSize({ width: 390, height: 844 });
  await page.getByRole('button', { name: 'Advanced filters', exact: true }).click();
  const mobileDialog = page.getByRole('dialog', { name: 'Remote activity', exact: true });
  await expect(mobileDialog.locator('.condition-row')).toHaveCount(3);
  const mobileGeometry = await mobileDialog
    .locator('.condition-row')
    .first()
    .evaluate((row) => {
      const fields = row.querySelector('.rule-fields');
      const selectors = [
        'input[aria-label="Choose filter column"]',
        '[aria-label="Condition operator"]',
        'input[aria-label="Condition value"]',
      ];
      const boxes = selectors.map((selector) =>
        fields.querySelector(selector).getBoundingClientRect(),
      );
      return {
        centers: boxes.map((box) => box.y + box.height / 2),
        scrolls: fields.scrollWidth > fields.clientWidth,
      };
    });
  assert.ok(
    mobileGeometry.scrolls,
    'Narrow screens retain the inline row through horizontal access.',
  );
  assert.ok(Math.max(...mobileGeometry.centers) - Math.min(...mobileGeometry.centers) < 4);
  await mobileDialog
    .getByRole('combobox', { name: 'Choose filter column', exact: true })
    .first()
    .fill('Business date');
  const columnSuggestion = page.getByRole('option').filter({ hasText: 'Business date' }).first();
  const columnPanel = await columnSuggestion.evaluate((option) => {
    const box = option.closest('[role="listbox"]').getBoundingClientRect();
    return { left: box.left, right: box.right };
  });
  assert.ok(
    columnPanel.left >= 0 && columnPanel.right <= 390,
    'Wide column suggestions stay inside a mobile viewport.',
  );
  await page.keyboard.press('Escape');
  await mobileDialog
    .getByRole('textbox', { name: 'Condition value', exact: true })
    .first()
    .scrollIntoViewIfNeeded();
  await page.screenshot({
    path: join(isolated, 'inline-filters-mobile.png'),
    animations: 'disabled',
  });
  await mobileDialog.getByRole('button', { name: 'Cancel', exact: true }).click();
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.getByRole('button', { name: 'Download all charts and table', exact: true }).click();
  await expect(
    page
      .getByText('Authorized snapshots are unavailable in this metadata-only host.', {
        exact: true,
      })
      .first(),
  ).toBeVisible();
  assert.equal(
    (await probe()).snapshotCalls,
    1,
    'An explicit complete export requests the unavailable snapshot.',
  );
  assert.deepEqual(downloads, [], 'Failed exports must not produce an empty CSV.');
  console.log(
    `PASS: Studio opens, pages and filters through the supplied executor (${completed(studioState).length - initialCount} additional blocks), with zero snapshot calls; unavailable complete exports display an error.`,
  );

  await page.goto(`${base}/studio/remote-activity?widget=remote-grid&view=published`);
  await expect(
    page.locator('.studio-readonly workspace-widget-view .grid-pane .ag-row').first(),
  ).toBeVisible();
  await expect.poll(async () => completed(await probe()).length).toBeGreaterThan(0);
  validBlocks(await probe());
  await page.getByRole('combobox', { name: 'Data source or view', exact: true }).click();
  await expect(sourcePicker.locator('mat-option.current')).toHaveCount(1);
  await expect(sourcePicker.locator('mat-option.current .option-name')).toHaveText(
    'Remote grouped activity',
  );
  await expect(sourcePicker.locator('.status-pill')).toHaveCount(0);
  await page.screenshot({ path: join(isolated, 'studio-view-picker.png'), animations: 'disabled' });
  await page.keyboard.press('Escape');
  const publishedStudioState = await probe();
  validBlocks(publishedStudioState);
  savedShape(
    publishedStudioState.queries[0],
    (await savedView('remote-grid')).body,
    250,
    'Published Studio first request',
  );

  // A remote authored view may contain charts while the host currently supplies only the grid
  // transport. Its saved presentation setting must still be editable and captured accurately.
  await page.goto(`${base}/studio/remote-activity?widget=remote-saved-draft&view=draft`);
  await expect(page.locator('.studio-editor:not([hidden]) .ag-row').first()).toBeVisible();
  await expect.poll(async () => completed(await probe()).length).toBeGreaterThan(0);
  const draftSeed = await savedView('remote-saved-draft');
  assert.equal(draftSeed.body.displayMode, 'both');
  const draftInitial = await probe();
  validBlocks(draftInitial);
  savedShape(draftInitial.queries[0], draftSeed.body, 250, 'Saved draft first request');
  assert.equal(draftInitial.queries[0].request.request.startRow, 0);
  assert.deepEqual(draftInitial.queries[0].request.request.groupKeys, []);
  await page.getByRole('button', { name: 'Close view navigator', exact: true }).click();
  await expect(page.locator('.grid-shell .ag-header-cell[col-id="status"]')).toHaveCount(0);
  const columnsBeforePolicy = await visibleColumns();
  assert.ok(columnsBeforePolicy.includes('started') && columnsBeforePolicy.includes('events'));
  let viewSettings = await settings();
  await viewSettings.getByRole('tab', { name: 'Reader experience', exact: true }).click();
  await expect(
    viewSettings.getByRole('combobox', { name: 'Default display', exact: true }),
  ).toContainText('Table and charts');
  await viewSettings.getByRole('combobox', { name: 'Default display', exact: true }).click();
  await page.getByRole('option', { name: 'Table', exact: true }).click();
  await viewSettings.getByRole('button', { name: 'Apply settings', exact: true }).click();
  const saveDraft = page.locator('.studio-command-bar button[data-action="save"]');
  await expect(saveDraft).toBeEnabled();
  await saveDraft.click();
  await expect
    .poll(async () => (await savedView('remote-saved-draft')).version)
    .toBeGreaterThan(draftSeed.version);
  const displaySaved = await savedView('remote-saved-draft');
  assert.equal(
    displaySaved.body.displayMode,
    'grid',
    'Saving a remote view captures the newly chosen Table setting, not its original Both setting.',
  );
  assert.equal(
    displaySaved.body.charts.length,
    1,
    'The authored chart configuration survives a table-only remote editing session.',
  );
  validBlocks(await probe());

  viewSettings = await settings();
  await viewSettings.getByRole('tab', { name: 'Reader experience', exact: true }).click();
  await expect(
    viewSettings.getByRole('combobox', { name: 'Default display', exact: true }),
  ).toContainText('Table');
  await viewSettings.getByRole('tab', { name: 'Grid loading', exact: true }).click();
  await viewSettings.getByLabel('Rows per request', { exact: true }).fill('100');
  await viewSettings.getByLabel('Cached pages per group', { exact: true }).fill('2');
  await viewSettings.getByLabel('Concurrent requests', { exact: true }).fill('1');
  await viewSettings.getByLabel('Scroll debounce (ms)', { exact: true }).fill('0');
  const previousGrid = await page
    .locator('.studio-editor:not([hidden]) .grid-shell ag-grid-angular')
    .elementHandle();
  const remountStart = (await probe()).queries.length;
  await viewSettings.getByRole('button', { name: 'Apply settings', exact: true }).click();
  await expect.poll(() => previousGrid.evaluate((node) => node.isConnected)).toBe(false);
  await expect
    .poll(
      async () =>
        (await probe()).queries
          .slice(remountStart)
          .filter((query) => query.returnedRows !== undefined).length,
    )
    .toBeGreaterThan(0);
  const remounted = await probe();
  validBlocks(remounted);
  const remountQueries = remounted.queries.slice(remountStart);
  assert.ok(remountQueries.length);
  for (const query of remountQueries) savedShape(query, displaySaved.body, 100, 'Policy remount');
  assert.deepEqual(
    await visibleColumns(),
    columnsBeforePolicy,
    'Remounting preserves the selected field order and visibility.',
  );
  await expect(page.locator('.grid-shell .ag-header-cell[col-id="status"]')).toHaveCount(0);
  await page.locator('.grid-shell .ag-row-level-0 .ag-group-contracted:visible').first().click();
  await expect(page.locator('.grid-shell .ag-row-level-1 .ag-group-value').first()).toBeVisible();
  await page
    .locator('.grid-shell .ag-row-level-1')
    .filter({ hasText: 'Ingestion' })
    .locator('.ag-group-contracted:visible')
    .click();
  await expect
    .poll(async () =>
      completed(await probe()).some(
        (query) =>
          query.request.request.groupKeys.length === 2 &&
          query.request.request.endRow - query.request.request.startRow === 100 &&
          query.returnedRows === 100,
      ),
    )
    .toBe(true);
  await page.locator('.grid-shell .ag-body-vertical-scroll-viewport').evaluate((element) => {
    element.scrollTop = 5_000;
  });
  await expect
    .poll(async () =>
      completed(await probe()).some(
        (query) =>
          query.request.request.groupKeys.length === 2 &&
          query.request.request.startRow > 0 &&
          query.request.request.endRow - query.request.request.startRow === 100,
      ),
    )
    .toBe(true);
  await expect(saveDraft).toBeEnabled();
  await saveDraft.click();
  await expect
    .poll(async () => (await savedView('remote-saved-draft')).version)
    .toBeGreaterThan(displaySaved.version);
  const policySaved = await savedView('remote-saved-draft');
  assert.equal(policySaved.body.displayMode, 'grid');
  assert.deepEqual(policySaved.body.serverGrid, {
    cacheBlockSize: 100,
    maxBlocksInCache: 2,
    maxConcurrentRequests: 1,
    blockLoadDebounceMillis: 0,
  });
  assert.deepEqual(policySaved.body.gridState.rowGroup.groupColIds, ['businessDate', 'type']);
  assert.deepEqual(policySaved.body.gridState.columnVisibility.hiddenColIds, ['status']);
  assert.deepEqual(
    canonicalFilter(policySaved.body.gridState.filter.advancedFilterModel),
    canonicalFilter(draftSeed.body.gridState.filter.advancedFilterModel),
  );
  assert.deepEqual(
    policySaved.body.gridState.sort.sortModel.map(({ colId, sort }) => ({ colId, sort })),
    draftSeed.body.gridState.sort.sortModel,
  );
  validBlocks(await probe());
  await page.screenshot({
    path: join(isolated, 'saved-remote-policy.png'),
    animations: 'disabled',
  });
  // Destroy Studio through the public router while retaining its workspace store, then reopen
  // the saved resource. This proves capture persistence rather than only an in-memory tab.
  await page.evaluate(() => window.__serverGridHost.navigate('/library'));
  await expect(page.getByLabel('Search published views')).toBeVisible();
  const reopenStart = (await probe()).queries.length;
  await page.evaluate(() =>
    window.__serverGridHost.navigate(
      '/studio/remote-activity?widget=remote-saved-draft&view=draft',
    ),
  );
  await expect
    .poll(
      async () =>
        (await probe()).queries
          .slice(reopenStart)
          .filter((query) => query.returnedRows !== undefined).length,
    )
    .toBeGreaterThan(0);
  const reopenedDraft = await probe();
  for (const query of reopenedDraft.queries.slice(reopenStart))
    savedShape(query, policySaved.body, 100, 'Reopened saved draft');
  await expect(page.locator('.grid-shell .ag-header-cell[col-id="status"]')).toHaveCount(0);
  assert.deepEqual(await visibleColumns(), columnsBeforePolicy);
  validBlocks(reopenedDraft);
  const savedRemote = {
    initial: draftInitial,
    remounted,
    displaySaved,
    policySaved,
    reopened: reopenedDraft.queries.slice(reopenStart),
  };
  console.log(
    'PASS: A saved remote view sends its authored filter/group/sort/aggregation on its FIRST request; changing Both to Table persists on save, a 100-row policy remount preserves fields and query shape, and reopening sends only the saved 100-row requests with zero snapshots.',
  );

  await page.goto(`${base}/views/remote-grid`);
  await expect(
    page.getByRole('heading', { name: 'Remote grouped activity', exact: true }),
  ).toBeVisible();
  await expect(page.locator('workspace-widget-view .ag-row').first()).toBeVisible();
  await expect
    .poll(async () =>
      completed(await probe()).some((query) => query.request.request.groupKeys.length > 0),
    )
    .toBe(true);
  let publishedState = await probe();
  validBlocks(publishedState);
  savedShape(
    publishedState.queries[0],
    (await savedView('remote-grid')).body,
    250,
    'Published view first request',
  );
  const grouped = completed(publishedState);
  assert.ok(
    grouped.some(
      (query) =>
        query.request.request.rowGroupCols.map((column) => column.id).join(',') ===
        'businessDate,type',
    ),
  );
  const dateRoute = grouped.find((query) => query.request.request.groupKeys.length === 1);
  assert.equal(dateRoute.request.request.groupKeys[0], '2026-10-03');
  assert.ok(
    dateRoute.sql.includes('"businessDate" = TO_DATE(?, \'YYYY-MM-DD\')'),
    'Date group routes use typed Snowflake equality.',
  );
  assert.ok(dateRoute.sql.includes("TO_TIMESTAMP_NTZ(?, 'YYYY-MM-DD HH24:MI:SS')"));
  assert.ok(dateRoute.binds.includes('2026-10-03 11:00:00'));
  // Expanding the next group must issue a leaf-route block rather than obtaining source rows.
  await page
    .locator('workspace-widget-view .ag-row')
    .filter({ hasText: 'Ingestion' })
    .first()
    .locator('.ag-group-contracted')
    .first()
    .click();
  await expect
    .poll(async () =>
      completed(await probe()).some((query) => query.request.request.groupKeys.length === 2),
    )
    .toBe(true);
  validBlocks(await probe());
  await page.getByRole('button', { name: 'Ungroup all', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Restore grouping', exact: true })).toBeVisible();
  await expect
    .poll(async () =>
      completed(await probe()).some((query) => query.request.request.rowGroupCols.length === 0),
    )
    .toBe(true);
  await page.locator('workspace-filter-scope-chip button').first().click();
  const tableDialog = page.getByRole('dialog', { name: 'Table', exact: true });
  await expect(tableDialog.locator('.condition-row')).toHaveCount(2);
  await tableDialog
    .getByRole('textbox', { name: 'Condition value', exact: true })
    .last()
    .fill('2026-10-03T12:00:00Z');
  await tableDialog.getByRole('button', { name: 'Apply changes', exact: true }).click();
  await expect
    .poll(async () =>
      completed(await probe()).some((query) => query.binds.includes('2026-10-03 12:00:00')),
    )
    .toBe(true);
  await page.getByRole('button', { name: 'Restore grouping', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Ungroup all', exact: true })).toBeVisible();
  publishedState = await probe();
  validBlocks(publishedState);
  await page.screenshot({ path: join(isolated, 'published-grid.png'), animations: 'disabled' });
  await page.getByRole('button', { name: 'Download filtered records as CSV', exact: true }).click();
  await expect(
    page.getByRole('alert').filter({ hasText: 'Authorized snapshots are unavailable' }).first(),
  ).toBeVisible();
  assert.equal((await probe()).snapshotCalls, 1);
  assert.deepEqual(downloads, []);
  await page.getByRole('button', { name: 'Download all', exact: true }).click();
  await expect(
    page.getByRole('alert').filter({ hasText: 'Authorized snapshots are unavailable' }).first(),
  ).toBeVisible();
  await expect.poll(async () => (await probe()).snapshotCalls).toBe(2);
  assert.deepEqual(downloads, []);
  assert.deepEqual(
    uncaught,
    [],
    'No uncaught browser exceptions occur during the metadata-only flows.',
  );
  await writeFile(
    join(isolated, 'verification.json'),
    JSON.stringify(
      {
        studio: studioState,
        publishedStudio: publishedStudioState,
        savedRemote,
        published: publishedState,
        unavailableExports: { snapshotCalls: (await probe()).snapshotCalls, downloads },
        uncaught,
      },
      null,
      2,
    ),
  );
  console.log(
    `PASS: Published grid uses supplied executor for date grouping, leaf expansion, ungroup/restore and datetime filter edits (${completed(publishedState).length} blocks), with zero snapshot calls; CSV and whole-view exports fail visibly without downloads.`,
  );
} catch (error) {
  await writeFile(join(isolated, 'failed-probe.html'), await page.content());
  await page.screenshot({ path: join(isolated, 'failed-probe.png'), animations: 'disabled' });
  await writeFile(
    join(isolated, 'failed-probe.json'),
    JSON.stringify({ state: await probe(), uncaught }, null, 2),
  );
  throw error;
} finally {
  await context.close();
  await browser.close();
  await new Promise((done) => server.close(done));
  console.log(`Probe artifacts retained for review: ${isolated}`);
}
