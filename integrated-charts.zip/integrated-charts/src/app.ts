import { DemoDataModule } from './data/data.module';
import { provideDashboardIntegration } from '@prism/dashboards';
import {
  Component,
  importProvidersFrom,
  type ApplicationConfig,
  provideZonelessChangeDetection,
} from '@angular/core';
import { provideRouter } from '@angular/router';
import { WorkspaceShellComponent, WORKSPACE_ROUTES } from '@prism/userPref';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [WorkspaceShellComponent],
  template: '<prism-workspace />',
})
export class AppComponent {}

export const appConfig: ApplicationConfig = {
  providers: [
    importProvidersFrom(DemoDataModule),
    provideDashboardIntegration(),
    provideZonelessChangeDetection(),
    provideRouter(WORKSPACE_ROUTES),
  ],
};
