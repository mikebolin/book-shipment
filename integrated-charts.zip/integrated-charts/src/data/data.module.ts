import { NgModule } from '@angular/core';
import { CHARTING_DATA, type ChartingDataSource, type ChartingSeed } from '@prism/charting/platform';
import { createWorkspaceSeed } from './workspace-seed.js';
import { readBundledGzip } from './bundled-assets';
import manifest from './bundled-assets.json';

/** The host retains only the Activity monitor fixture and its portable configurations. */
export const activityMonitorDataSource: ChartingDataSource = {
  createSeed: () => createWorkspaceSeed() as unknown as ChartingSeed,
  loadSnapshot: (model, signal) =>
    readBundledGzip(`mock-data/${model.body.sourceKey}.ndjson` as keyof typeof manifest, signal),
  async loadAsset(path, signal) {
    if (path in manifest) return readBundledGzip(path as keyof typeof manifest, signal);
    throw new Error('This host only includes the Activity monitor fixture. Import a file or configure a data provider.');
  },
  sampleOptions: [],
  reports: [],
  prompts: {},
};

@NgModule({ providers: [{ provide: CHARTING_DATA, useValue: activityMonitorDataSource }] })
export class DemoDataModule {}
