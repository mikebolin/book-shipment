import catalog from './source-catalog.json' with { type: 'json' };

/** Host-owned Activity monitor configurations; no other demos are seeded. */
export function createWorkspaceSeed() {
  let sequence = 0;
  const randomUUID = () => `seed-placement-${++sequence}`;
  const resources = { models: [], widgets: [], dashboards: [] };
  const revisions = {};
  const datasets = {};
  const sources = [];
  const timestamp = '2026-10-01T00:00:00.000Z';

  for (const source of catalog) {
    const metadata = source.metadata;
    const id = `model-${source.key}`;
    const definition = {
      ...metadata,
      sourceKey: source.key,
      clientSourceId: metadata.id,
      schemaVersion: metadata.version,
      dataVersion: metadata.version,
      rowCount: source.metadata.rowCount ?? 0,
    };
    sources.push({ key: source.key, name: metadata.label, ...definition });
    resources.models.push({
      id,
      kind: 'MODEL',
      slug: source.key,
      name: metadata.label,
      description: metadata.description,
      modelId: null,
      version: 1,
      publishedVersion: null,
      body: definition,
      createdAt: timestamp,
      updatedAt: timestamp,
    });

  }
  function seed(path, method = 'GET', input) {
    const [route, search] = path.split('?');
    const [collection, slug, action] = route.split('/');
    const items = resources[collection];
    if (method === 'GET') {
      if (!slug) return structuredClone(items);
      const item = items.find((item) => item.slug === slug || item.id === slug);
      return structuredClone(
        search === 'view=published' ? revisions[item.id][item.publishedVersion] : item,
      );
    }
    if (action === 'publish') {
      const item = items.find((item) => item.slug === slug);
      item.publishedVersion = item.version;
      (revisions[item.id] ??= {})[item.version] = structuredClone(item);
      return structuredClone(item);
    }
    const id = `seed-${collection}-${++sequence}`;
    const item = {
      id,
      kind: collection === 'widgets' ? 'WIDGET' : 'DASHBOARD',
      slug:
        input.name
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/-$/, '') +
        '-' +
        sequence,
      name: input.name,
      description: input.description ?? '',
      modelId: input.modelId ?? null,
      version: 1,
      publishedVersion: null,
      body: structuredClone(input.body),
      createdAt: timestamp,
      updatedAt: timestamp,
    };
    items.push(item);
    return structuredClone(item);
  }

  /**
   * Server-grid demonstrations over the bundled 60,000-record Activity monitor fixture
   * (scripts/generate-activity-monitor.mjs). The rows load lazily, so these views carry no
   * generated preview; their grouping, aggregation, sort and filter state is the demonstration.
   */
  const activityVisible = (model, visible) => ({
    columnOrder: {
      orderedColIds: [
        ...visible,
        ...model.body.columns.map((column) => column.id).filter((id) => !visible.includes(id)),
      ],
    },
    columnVisibility: {
      hiddenColIds: model.body.columns
        .map((column) => column.id)
        .filter((id) => !visible.includes(id)),
    },
    columnSizing: {
      columnSizingModel: visible.map((colId) => ({
        colId,
        width:
          colId === 'name'
            ? 240
            : colId === 'fileName'
              ? 250
              : colId.endsWith('DateTime')
                ? 185
                : 150,
      })),
    },
  });
  /**
   * The failed-events default: the hour before the 12:00 UTC snapshot, failed or breached. The view
   * saves it as its table filter (charts follow it), and the dashboards override those same columns
   * with their own windows through the dashboard filter.
   */
  const failedEventsFilterModel = (start) => ({
    filterType: 'join',
    type: 'AND',
    conditions: [
      {
        filterType: 'dateTimeString',
        colId: 'startedDateTime',
        type: 'greaterThanOrEqual',
        filter: start,
      },
      {
        filterType: 'dateTimeString',
        colId: 'startedDateTime',
        type: 'lessThan',
        filter: '2026-10-03T12:00:00',
      },
      {
        filterType: 'join',
        type: 'OR',
        conditions: [
          { filterType: 'text', colId: 'executionStatus', type: 'equals', filter: 'Failed' },
          { filterType: 'text', colId: 'executionStatus', type: 'equals', filter: 'Breached' },
        ],
      },
    ],
  });
  /** Charts of the failed-events view; they follow the view's table filter. */
  const failuresOverTime = (minutes) => ({
    id: `activity-failures-${minutes}min`,
    plan: {
      type: 'column',
      categoryColumnId: 'startedDateTime',
      measureColumnIds: [],
      aggregation: 'count',
      timeBucket: 'minute',
      bucketSize: minutes,
      timeRange: { fill: 'zero' },
      title: `Failures over time · ${minutes} min`,
      appearance: {
        theme: null,
        legendPosition: null,
        showLegend: false,
        showLabels: null,
        xAxisTitle: 'Time (UTC)',
        yAxisTitle: 'Failed events',
      },
    },
    presentation: null,
    description: `Failed or breached activities per ${minutes}-minute bucket inside the current window; buckets without events count zero.`,
  });
  const failuresByType = {
    id: 'activity-failures-by-type',
    plan: {
      type: 'bar',
      categoryColumnId: 'type',
      measureColumnIds: ['metric_events'],
      aggregation: null,
      timeBucket: null,
      title: 'Failures by type',
      appearance: {
        theme: null,
        legendPosition: null,
        showLegend: false,
        showLabels: true,
        xAxisTitle: null,
        yAxisTitle: null,
      },
      analytics: {
        metrics: [
          {
            id: 'metric_events',
            label: 'Failed events',
            operation: 'count',
            columnId: null,
            numeratorColumnId: null,
            denominatorColumnId: null,
            scale: null,
            percentile: null,
          },
        ],
        groupFilter: [],
        orderBy: [{ field: 'metric_events', direction: 'desc' }],
        limit: null,
        seriesByColumnId: null,
      },
    },
    presentation: null,
    description: 'Activity types ranked by failed or breached events inside the current window.',
  };
  const activityCharts = (template) => {
    const charts = template.charts ?? [
      {
        id: `demo-activity-monitor-${template.chart.categoryColumnId}-${template.chart.type}`,
        plan: {
          type: template.chart.type,
          categoryColumnId: template.chart.categoryColumnId,
          measureColumnIds: [],
          aggregation: 'count',
          timeBucket: null,
          title: template.chart.title,
          appearance: null,
        },
        presentation: null,
      },
    ];
    return { chart: charts[0], charts };
  };
  const activityTemplates = [
    {
      name: 'Activity monitor · failed events',
      description:
        'Failed and breached activities for the triage dashboards: a server-side table grouped by activity type with event totals, failures over time at one- and five-minute buckets, and failures ranked by type. The dashboards supply the time window and statuses through their shared filter.',
      visible: ['executionStatus', 'startedDateTime', 'name', 'id', 'eventCount'],
      gridState: {
        filter: { advancedFilterModel: failedEventsFilterModel('2026-10-03T11:00:00') },
        rowGroup: { groupColIds: ['type'] },
        aggregation: { aggregationModel: [{ colId: 'eventCount', aggFunc: 'sum' }] },
        sort: {
          sortModel: [
            { colId: 'eventCount', sort: 'desc' },
            { colId: 'startedDateTime', sort: 'desc' },
          ],
        },
      },
      charts: [failuresOverTime(5), failuresOverTime(1), failuresByType],
    },
    {
      name: 'Breached activities by source and type',
      description:
        'Breached activities grouped by source system, then activity type. Groups sort by the longest SLA breach; expanding a group requests only its records.',
      visible: [
        'name',
        'executionStatus',
        'breachMinutes',
        'processedRowCount',
        'durationSeconds',
        'startedDateTime',
        'tenantCode',
        'owner',
        'fileName',
      ],
      gridState: {
        filter: {
          advancedFilterModel: {
            filterType: 'text',
            colId: 'executionStatus',
            type: 'equals',
            filter: 'Breached',
          },
        },
        rowGroup: { groupColIds: ['source', 'type'] },
        aggregation: {
          aggregationModel: [
            { colId: 'breachMinutes', aggFunc: 'max' },
            { colId: 'processedRowCount', aggFunc: 'sum' },
            { colId: 'durationSeconds', aggFunc: 'avg' },
          ],
        },
        sort: { sortModel: [{ colId: 'breachMinutes', sort: 'desc' }] },
      },
      chart: { type: 'bar', categoryColumnId: 'type', title: 'Breached activities by type' },
    },
    {
      name: 'Activity volume by status and type',
      description:
        'Every activity grouped by execution status, then activity type, with processed rows, average duration and retries summarized for each group.',
      visible: [
        'name',
        'source',
        'processedRowCount',
        'durationSeconds',
        'retryCount',
        'startedDateTime',
        'priority',
        'owner',
      ],
      gridState: {
        rowGroup: { groupColIds: ['executionStatus', 'type'] },
        aggregation: {
          aggregationModel: [
            { colId: 'processedRowCount', aggFunc: 'sum' },
            { colId: 'durationSeconds', aggFunc: 'avg' },
            { colId: 'retryCount', aggFunc: 'sum' },
          ],
        },
        sort: { sortModel: [{ colId: 'processedRowCount', sort: 'desc' }] },
      },
      chart: {
        type: 'donut',
        categoryColumnId: 'executionStatus',
        title: 'Activities by execution status',
      },
    },
  ];

  const slugPrefix = (name) => `${name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-`;
  {
    const models = seed('models');
    const existing = seed('widgets');
    const widgets = [];
    let created = 0;
    for (const template of activityTemplates) {
      let widget = existing.find((item) => item.slug.startsWith(slugPrefix(template.name)));
      if (!widget) {
        const model = models.find((item) => item.body.sourceKey === 'activity-monitor');
        if (!model)
          throw new Error(
            'Missing activity-monitor model. Run node scripts/generate-activity-monitor.mjs.',
          );
        widget = seed('widgets', 'POST', {
          name: template.name,
          description: template.description,
          modelId: model.id,
          body: {
            schemaVersion: 1,
            modelSchemaVersion: model.body.schemaVersion,
            mode: 'advanced',
            displayMode: 'both',
            allowDownload: true,
            filterControls: { visible: true, parameterizable: true },
            viewLayout: { tablePosition: 'top', showRecordCounts: true },
            gridState: { ...activityVisible(model, template.visible), ...template.gridState },
            calculatedColumns: [],
            ...activityCharts(template),
            group: 'Operations',
            tags: ['Featured', 'Operations', 'Server grid'],
          },
        });
        widget = seed(`widgets/${widget.slug}/publish`, 'POST', {}, widget.version);
        created++;
      }
      if (widget.publishedVersion !== null) widget = seed(`widgets/${widget.slug}?view=published`);
      widgets.push({ widget, templateName: template.name, featured: false });
    }
    const dashboards = seed('dashboards');
    const monitorViews = widgets.filter((item) => !item.widget.body.charts?.some((chart) => chart.id === 'activity-failures-5min'));
    const monitor = seed('dashboards', 'POST', {
      name: 'Operations monitor',
      description: 'Activity volume and SLA breaches, grouped by source, type and status.',
      body: { schemaVersion: 2, group: 'Operations', tags: ['Operations'], items: monitorViews.map(({widget}, index) => ({
        id: randomUUID(), kind: 'view', widgetId: widget.id, widgetRevision: widget.publishedVersion,
        x: index * 6, y: 0, w: 6, h: 10, displayMode: 'both'
      })) }
    });
    seed(`dashboards/${monitor.slug}/publish`, 'POST');
    /**
     * Two triage dashboards over one published view and one shared, value-editable filter.
     * Nothing here is bespoke: chart and view elements, a dashboard filter whose comparison
     * values are inputs, and click-to-filter interactions declared on the chart elements.
     */
    const failed = widgets.find(
      (item) => item.templateName === 'Activity monitor · failed events',
    ).widget;
    /** The toolbar every triage dashboard starts with; readers change it, authors save defaults. */
    const filterTile = (start, bucketSeconds) => ({
      id: randomUUID(),
      kind: 'filter',
      widgetId: failed.id,
      widgetRevision: failed.publishedVersion,
      title: 'Filter controls',
      filter: { mode: 'advanced', filterModel: failedEventsFilterModel(start) },
      controls: [
        {
          type: 'window',
          columnId: 'startedDateTime',
          label: 'Recent window',
          options: [15, 30, 60, 180, 360, 720],
          endsAt: '2026-10-03T12:00:00',
        },
        {
          type: 'bucket',
          label: 'Time buckets',
          seconds: bucketSeconds,
          options: [6, 15, 30, 60, 300, 900],
        },
        { type: 'values', columnId: 'type', label: 'Event type', allowAll: true },
        {
          type: 'values',
          columnId: 'executionStatus',
          label: 'Status',
          multiple: true,
          options: ['Failed', 'Breached', 'Completed with exceptions', 'Awaiting User Action'],
        },
        {
          type: 'groupBy',
          label: 'Group grid by',
          options: [
            { columnId: 'type', label: 'Type' },
            { columnId: 'source', label: 'Source system' },
            { columnId: 'tenantCode', label: 'Client tenant' },
            { columnId: 'name', label: 'Activity name' },
          ],
          allowNone: true,
        },
      ],
      x: 0,
      y: 0,
      w: 12,
      h: 3,
    });
    const chartTile = (chartId, title, x, y, w, h) => ({
      id: randomUUID(),
      kind: 'chart',
      widgetId: failed.id,
      widgetRevision: failed.publishedVersion,
      chartId,
      title,
      x,
      y,
      w,
      h,
      interactions: { selectFilter: true },
    });
    const gridTile = (title, x, y, w, h) => ({
      id: randomUUID(),
      kind: 'view',
      widgetId: failed.id,
      widgetRevision: failed.publishedVersion,
      title,
      x,
      y,
      w,
      h,
      displayMode: 'grid',
      interactions: { switchView: false },
      viewOverrides: {
        allowDownload: true,
        filterControls: { visible: true, parameterizable: false },
      },
    });
    const triageDashboards = [
      {
        name: 'Explore failure activity',
        description:
          'Grid first: failed and breached events of the last 30 minutes grouped by activity type, then the timeline and the ranked types. The filter controls set the window, buckets, type, statuses and grouping for every element; click a bar to narrow further.',
        items: [
          filterTile('2026-10-03T11:30:00', 300),
          gridTile('Matching failed events', 0, 3, 12, 8),
          chartTile('activity-failures-5min', 'Failures over time', 0, 11, 6, 7),
          chartTile('activity-failures-by-type', 'Failures by type', 6, 11, 6, 7),
        ],
      },
      {
        name: 'Failure triage',
        description:
          'Timeline first: failed and breached events per minute over the last hour. Click a spike to retain that minute, then review the ranked types and the matching events beside it. Reset the filter controls to return to the saved hour.',
        items: [
          filterTile('2026-10-03T11:00:00', 60),
          chartTile('activity-failures-1min', 'Failures over time', 0, 3, 12, 7),
          chartTile('activity-failures-by-type', 'Failures by type', 0, 10, 5, 8),
          gridTile('Matching failed events', 5, 10, 7, 8),
        ],
      },
    ];
    for (const definition of triageDashboards) {
      let saved = dashboards.find((item) => item.slug.startsWith(slugPrefix(definition.name)));
      if (!saved) {
        saved = seed('dashboards', 'POST', {
          name: definition.name,
          description: definition.description,
          body: {
            schemaVersion: 2,
            group: 'Operations',
            tags: ['Featured', 'Operations', 'Triage'],
            items: definition.items,
          },
        });
        saved = seed(`dashboards/${saved.slug}/publish`, 'POST', {}, saved.version);
      }
    }

  }
  return { resources, revisions, datasets, sources };
}
