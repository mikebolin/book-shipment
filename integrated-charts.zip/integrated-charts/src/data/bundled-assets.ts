import manifest from './bundled-assets.json';
/** Static compressed text assets keep the complete original data portable to browser IDEs.
 * Only same-origin build assets are read; all queries and edits run in memory.
 */
export async function readBundledGzip(
  key: keyof typeof manifest,
  signal?: AbortSignal,
): Promise<Response> {
  signal?.throwIfAborted();
  const paths = manifest[key];
  if (!paths) throw new Error('Unknown bundled sample.');
  const parts: BlobPart[] = [];
  // At most four small asset reads at once. Each base64 part ends at a quartet boundary.
  for (let start = 0; start < paths.length; start += 4) {
    const batch = await Promise.all(
      paths.slice(start, start + 4).map(async (name) => {
        const response = await fetch(new URL(`assets/bundled/${name}`, document.baseURI), {
          signal,
        });
        if (!response.ok) throw new Error('A bundled data asset could not be loaded.');
        const binary = atob(await response.text());
        return Uint8Array.from(binary, (c) => c.charCodeAt(0));
      }),
    );
    parts.push(...batch);
    signal?.throwIfAborted();
  }
  return new Response(new Blob(parts).stream().pipeThrough(new DecompressionStream('gzip')));
}
